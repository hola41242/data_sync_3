



label banu_naked_photo_orxan:


    play music "audio/weakbanu.mp3"
    scene v20-238 with dissolve
    b_ "I can't stop thinking about Orxan."
    b_ "The way he looked at me, the way his words made me feel... It's driving me wild."
    b_ "That bulge, so close to me, teasing me, making me want more. My body is still reacting, still craving that touch."
    scene v20-239 with fade
    o "Banu..."
    b "Orxan, what are you doing here?"
    o "I couldn’t stay away, Banu. The way you looked at me, the way you responded... I had to see you again."
    scene v20-240 with fade
    b "This is so wrong, Orxan. Kamil is just outside."
    o "I know, but I can’t stop thinking about you. About how amazing you looked, how much I wanted to touch you, to feel you."
    b "This is dangerous, Orxan. But I can’t deny how much I want it."
    b "But even if I want this...I can't do this. I'm a faithful wife to my husband and I won't do anything behind his back."
    b "It wouldn’t be right."

    o "I understand, Banu. But we can make this professional. Let me capture your beauty in its purest form."
    o "Just you, completely naked. It’s still part of the shoot, but it can be so much more."
    scene v20-241
    b "Orxan, you’re making it so hard to resist. But... are you sure we can keep this professional?"
    o "I promise, Banu. This will be all about the art, about capturing your raw, natural beauty."
    o "You’re in control. Just let me see all of you, through my lens."
    b "If we do this, it has to stay professional. No crossing the line."
    o "I understand. It’s just you and the camera. I want to capture the real you, in all your beauty and strength."
    b "Alright, Orxan. Let’s do it. But remember, it’s just for the art."
    scene v20-242 with fade
    b "This is for the art, right, Orxan?"
    o "Absolutely, Banu. Just think about the beauty and strength you’re about to show. You’re incredible."
    b "I trust you, Orxan."
    o "You’re doing great. Just let go and be yourself. Show me the real you."
    scene v20-243
    b "Here goes nothing."
    "Slowly, she begins to slide her pants down, revealing more of her skin with each passing second."
    "She can feel the air against her bare skin, heightening her senses and her awareness of the moment."
    o "You’re stunning, Banu. Just let go and show your true self."
    scene v20-244
    o "Banu, you’re doing great. It’s natural to feel shy, but remember, this is about celebrating your beauty and strength. You’re in control here."
    b "I know, it’s just... it feels so vulnerable."
    o "I understand. Take your time. You’re amazing just as you are."
    o "Just look at the camera when you’re ready. You’re beautiful, Banu. Let’s capture that."
    b "Orxan, I’m still nervous. It’s so revealing."
    scene v20-245
    o "I understand, but think about how incredible it will feel to embrace your full beauty. Every inch of you is stunning. "
    b "You make it sound so tempting."
    o "Because it is. You’re not just a model; you’re a goddess."
    b "I want to feel that freedom. I want to trust you."
    o "You can trust me. You’re safe with me."
    scene v20-246
    o "You’re absolutely stunning. I want to capture every inch of your beauty. Can you feel how much I desire you?"
    b "Yes. I feel it."
    o "Let go, Banu. Embrace this moment. You’re perfect, and I want to see all of you."
    b "Oh, Orxan… I can’t hold back anymore."
    scene v20-247
    "Orxan steps closer to Banu, positioning himself behind her. His hand gently rests on her hip, while his other hand moves to guide her arm."
    b "Orxan...."
    o "Trust me, Banu. Let me guide you. "
    "With a gentle but firm touch, Orxan begins to pull Banu’s right arm away from her body."
    o "That’s it, Banu. You’re breathtaking. Let go and embrace this moment."
    b "Oh, Orxan…"
    scene v20-248
    "As Orxan steps back to grab his camera, Banu stands there, fully naked, feeling the cool air against her skin."
    o "You’re incredible, Banu. Just stay like that. Let’s capture your full beauty."
    b "Okay. I’m ready."
    o "Perfect. Just let yourself be natural. You’re stunning just as you are."
    scene v20-249
    "As Banu stands fully naked, embracing the moment, Orxan continues to capture her with his camera. "
    b "I’ve never felt so exposed... and so alive."
    o "Your body is a work of art, Banu. Let me see all of you. Don’t hold back."
    b "Is this what you want to see, Orxan?"
    o "Yes, Banu. You’re absolutely stunning. Show me everything."
    scene v20-250
    b "It feels so good to be seen like this. To be admired. You make me feel so powerful."
    o "You are powerful, Banu. Every part of you is mesmerizing. I want to capture your essence, your beauty. Don’t hold back."
    b "I’ve never felt this way before. Your words, your gaze... it’s driving me wild."
    o "That’s it, Banu. You’re doing amazing. Let go and show me your true self."
    scene v20-251
    o "Banu, you’re like a vision. Every move you make is pure artistry. Keep dancing for me."
    b "I’ve never felt so alive. So free. It’s like I’m on fire."
    o "You are on fire, Banu. You’re burning with beauty and passion. Show me everything you’ve got."
    b "Can you see how much you’re turning me on? I’m so wet, Orxan. This feeling... it’s overwhelming."
    o "I can see it, Banu. You’re breathtaking. Every curve, every line of your body is perfect. You’re driving me wild."
    scene v20-252
    b "I want you to see all of me. To capture this moment of pure, raw desire. It’s all for you, Orxan."
    o "You’re giving me everything, Banu. You’re incredible. Just let go completely. Feel the pleasure in every movement."
    b "Your words, your eyes on me... it’s making me so horny. I’ve never felt this way before."
    o "I can’t believe you’ve given birth from that pussy, Banu. It looks so tight, so perfect."
    b "Orxan... you have no idea how much that turns me on. Hearing you say that..."
    b "You’re making me feel things I’ve never felt before. I want you to see everything, to know how much I’m enjoying this."
    b "I want you to see it all, Orxan. I want you to know how much you’re turning me on."
    scene v20-253 with fade
    o "Come with me, Banu. I want to capture you from every angle."
    "Banu feels a rush of excitement as Orxan leads her to the middle of the room, where mirrors surround them, reflecting her naked body from all sides."
    "The mirrors amplify the intensity of the moment, showing her every movement, every curve."
    scene v20-254
    o "You’re incredible, Banu. The way you move, the way you look... it’s all stunning. Keep going."
    b "I’ve never felt this powerful. I want you to capture all of it. Every angle, every detail."
    o "You’re a goddess, Banu. Every shot is a masterpiece because of you. Show me more of that fire."
    scene v20-255
    b "I can feel your eyes on me, Orxan. It’s driving me wild. I want to give you everything."
    b "How’s this, Orxan? Do you like what you see?"
    o "God, Banu, your ass is perfect. I can't believe how tight and round it is. You're absolutely stunning."
    b "Tell me more, Orxan. I want to hear what you think."
    o "I can't stop thinking about how incredible you look. That ass of yours is mesmerizing. I bet it feels just as amazing as it looks."
    b "Your words are driving me wild, Orxan. Keep talking."
    o "You're so tight and perfect, Banu. I can’t believe you’ve given birth. It’s unbelievable how sexy you are. I could stare at your ass all day."
    b "I want you to see everything, Orxan. Capture every part of me."
    scene v20-256
    b "Is this what you want, Orxan? Do you like how I move for you?"
    o "Banu, you’re driving me insane. The way you move… it’s like you were made to be admired. That ass of yours is perfection."
    b "I love hearing that. Tell me more, Orxan. Tell me how much you want me."
    o "I can’t take my eyes off you. Your ass is hypnotizing."
    o "I can’t believe how tight and perfect you are. Every move you make is pure seduction."
    o "The way you’re teasing me… it’s making me want you even more."
    scene v20-257
    b "Do you like what you see, Orxan? I’m showing you everything."
    o "I can’t get enough of you."
    b "Your words are driving me wild. I want you to see how much you turn me on."
    o "I can see it, Banu. You’re so wet, so ready. I want to capture every drop, every moment of your arousal."
    b "You have no idea how good this feels, Orxan. Knowing you’re watching me, wanting me… it’s making me so wet."
    scene v20-258
    b "Do you want to see me up close, Orxan? I want you to capture every detail."
    o "Yes, Banu. Bring yourself closer. I want to see every inch of you, up close and personal."
    b "Is this what you wanted, Orxan? Can you see how wet I am for you?"
    o "God, Banu, you’re perfect. Every detail. You’re driving me insane."
    b "Tell me what you see, Orxan. Tell me how much you want me."
    o "I see perfection, Banu. Your pussy is so beautiful, so wet. I can’t stop thinking about how good it must feel. You’re making me lose control."
    b "I want you to see everything, Orxan. Capture it all. I want to be unforgettable."
    scene black with dissolve
    "As Orxan finishes taking the photos, he sets the camera aside, his eyes never leaving Banu. "
    "She leans back against the mirror, completely naked, her body still humming with the intensity of the shoot."
    scene v20-259
    b "I can see how much you enjoyed that. Your bulge… it’s so big."
    o "You have no idea how much you turn me on, Banu. Watching you, capturing you… it’s driving me wild."
    o "You’ve made me so hard, Banu. I’ve been wanting you from the moment you started posing."
    scene v20-260
    o "You’re so beautiful, Banu. I want you so badly. I can’t stop thinking about how perfect you are."
    o "You’re driving me crazy, Banu. I can feel how much you want this."
    b "Orxan, this is so intense. I can’t... Kamil..."
    o "I know, but right now, it’s just us. I can see how wet you are. You’re incredible."
    b "Orxan, I’m so close to losing control. You’re making it so hard to resist."
    o "Let go, Banu. Just for this moment. Show me how much you want it."


    menu:
        "Push him away":
            $ banuletorxankissher = False
            $ renpy.block_rollback()
            scene v20-261
            stop music
            b "No, Orxan. I can’t do this. Not with Kamil just outside. It’s not right."
            o "Banu, I... I understand. I’m sorry if I pushed too far."
            b "It’s not just about the shoot anymore. I can’t betray Kamil like this."
            o "You’re right. I respect your decision, Banu. I got carried away."
            "She looks at Orxan, appreciating his understanding and the space he’s giving her."
        "Let him kiss you":




            $ banuletorxankissher = True
            $ renpy.block_rollback()
            stop music
            play music "audio/heatedsex.mp3"
            b "Orxan, I can’t hold back anymore."
            o "Banu..."
            scene v20-262 with vpunch
            play sound "voices/fastmoan3.mp3"
            "Their lips meet in a passionate kiss, a release of all the pent-up emotions and desire."
            stop sound
            play music "voices/makeout.mp3"
            "The kiss is intense, filled with a mix of longing and urgency. Banu’s hands slide up Orxan’s chest, feeling the strength of his body against hers."
            b "Oh, Orxan..."
            o "Banu, you’re driving me crazy. I need you."
            "The feel of Orxan’s lips, his touch, sends waves of excitement through her body. She presses herself closer to him, her body craving more."
            b "Orxan, don’t stop. Please, don’t stop."
            b "Oh, Orxan... this feels incredible."
            o "Let me make you feel even better."
            scene v20-263
            "Orxan’s hand moves slowly down her body, exploring her curves with deliberate, skilled movements."
            "As his fingers reach her pussy, he begins to rub gently, his touch sending waves of pleasure through Banu's body."
            b "Orxan... oh my God..."
            o "I want to make you feel incredible, Banu. Let yourself go."
            b "Don’t stop, Orxan. Please, don’t stop."
            o "I won’t, Banu. I want to feel you lose yourself in pleasure."
            b "Oh, Orxan... I can't believe how good this feels..."
            b "Orxan... I... I can't hold on..."
            b "Oh God, Orxan... I'm so close... please, don't stop..."
            stop music
            scene v20-264
            play sound "voices/fastmoan2.mp3"
            "Just when she is about to reach her peak, Orxan suddenly stops, pulling his hand away."
            stop sound
            b "Orxan, why did you stop? Please, I need this..."
            o "You need what?"
            b "Orxan, please... I need you. I can’t take it anymore. Please, fuck me. I’m begging you."
            o "You’re so beautiful when you’re desperate for me."
            b "I am desperate. Please, Orxan, I need you inside me. I need to feel you. Just fuck me."
            o "I want to make you come, Banu. Just like this."
            scene v20-265
            "Banu moans into his mouth, her body trembling with need as Orxan's hand moves down between her legs. "
            "He starts to rub her pussy again, his fingers expertly finding her clit and moving in slow, deliberate circles."
            scene v20-266
            b "Oh, Orxan... please, don’t stop..."
            b "I’m so close... I can’t hold on..."
            o "Let go, Banu. Come for me. I want to feel you come undone."
            "The sensation of his fingers rubbing her clit, combined with the passionate kisses, pushes Banu over the edge. "
            scene v20-266 with flash
            play sound "voices/moanfinish.mp3"
            b "Orxan! Oh, God, yes!"
            "Orxan continues to rub her, prolonging her climax, his kisses never stopping."
            stop sound
            scene v20-267 with fade
            o "I want to teach you to be stronger. I don't want to fuck you just yet. I want you to really want this, not just from the pleasure."
            "Banu feels a wave of embarrassment wash over her, her cheeks flushing red. She looks down, avoiding his gaze, feeling vulnerable but also deeply touched by his words."
            b "You're such a gentleman, Orxan. I... I don't know what to say."
            o "You don’t need to say anything, Banu. Just know that I care about you. I want you to feel empowered, not just lost in the moment."
            o "When we take that step, I want it to be because you truly want it, with all your heart, not just because you’re caught up in the pleasure."
            b "Thank you, Orxan. That means a lot to me. You’re right. I want to be stronger, to really know what I want."
            scene v20-268
            "As Orxan looks down, he notices the wetness between Banu's legs, a clear sign of her arousal."
            o "Damn, Banu. You're dripping. You really needed this."
            b "I...."
            o "Banu, you have nothing to be embarrassed about. It’s a beautiful response, and it shows how much you were enjoying yourself."
            b "I... I didn't realize... I'm so sorry."
            o "It’s natural, and it’s a part of your beauty. Your body is responding honestly, and that’s something to be proud of, not ashamed."
            b "I feel terrible. I was about to cheat on Kamil. How can I face him after this?"
            o "You didn't cheat. We got caught up in a moment, but you stopped before things went too far."
            b "But I still feel like I betrayed him. How can I just pretend this didn’t happen?"
            o "You don’t have to pretend, Banu. What’s important is that you acknowledge what happened and learn from it."
            o "It’s clear that you care deeply for Kamil, and that’s what matters."





    $ renpy.end_replay()
    $ persistent.banu_naked_photo_orxan_unlocked = True
    jump banu_naked_photo_orxan_continue










label polad_nesrin_foursome:

    play music "audio/chill.mp3"
    scene black with dissolve
    "The next day, as the sun begins to set, casting a warm glow over the seaside villa, the four friends gather on the balcony, enjoying the view and each other's company."
    "Banu wears a beautiful hijab paired with a sexy dress that hints at the excitement to come."
    scene v20-271 with dissolve
    p "Cheers to new experiences and good friends! I'm glad we could all come together like this."
    k "Cheers! It's great to be here with all of you. This is going to be a memorable evening."
    n "Banu, you look absolutely stunning tonight. The hijab and the dress are beautiful."
    b "Thank you, Nesrin. You look amazing too. I'm really looking forward to tonight."
    scene v20-272
    "The four friends, now feeling the effects of the alcohol, begin to let their inhibitions slip away, laughing and joking openly with one another."
    p "So, Kamil, are you ready to see your wife in a whole new light tonight?"
    k "Oh, I'm definitely ready. But the real question is, are you ready for what Banu has in store?"
    n "Banu, you’re always so composed. I can’t wait to see you let loose tonight. Any secret talents we should know about?"
    b "Well, I guess you’ll just have to wait and see. I might have a few surprises up my sleeve."
    scene v20-273
    p "Kamil, just so you know, I'm going to fuck your wife real good tonight."
    k "You better bring your A-game then, because Banu's not easily impressed."
    n "You better not disappoint, mister Polad. We’ve all got high expectations now."
    p "Don’t worry, I plan on exceeding expectations."
    scene v20-274
    n "Banu, just a little heads up—be careful. Polad fucks really hard. You’re in for quite a ride tonight."
    b "Oh really?"
    p "And Kamil, don’t worry. Nesrin’s going to make you cum in no time. She’s got some moves that will blow your mind."
    scene v20-275
    b "Looks like we’ve got some stiff competition, love. Better bring your best game too."
    n "I’m sure we’re all going to have an amazing time. It’s about having fun and exploring together."
    b "Well, Polad, you’re going to have to keep up with me. I’m no less than you when it comes to stamina and intensity."
    p "Is that so, Banu? I love a good challenge. I guess we’ll see who’s left standing by the end of the night."
    k "That’s my girl. She’s full of surprises, Polad. Don’t underestimate her."
    p "Challenge accepted, Banu. Let’s make this an unforgettable night."

    scene v20-276
    b "You think you can handle me, Polad? I’ve got moves that will leave you breathless."
    p "Oh, Banu, I’ve got plenty of stamina. By the end of tonight, you’ll be begging for more."
    b "Is that so? I hope you’re ready for a challenge. I love making strong men lose control."
    p "Wow man, your wife is really hungry for getting fucked."
    b "Just make sure you can keep up, Polad. I’m not easy to satisfy."
    p "Oh, I’m more than up for the challenge. I’m going to make you cum so hard you’ll be seeing stars."
    b "Then let’s see who can last the longest. I’m not stopping until you’re completely spent."
    p "Bring it on, Banu. Tonight, we’re going to push each other to the limit."
    scene v20-277
    "Banu and Nesrin lead the way into the bedroom, the men following close behind."
    "Polad follows Banu with a confident stride, while Kamil trails after Nesrin, feeling a mix of excitement and nervousness."
    stop music
    scene v20-278
    play music "audio/heatedsex.mp3"
    n "It’s okay, Kamil. There’s no need to be nervous. We’re here to enjoy ourselves and explore together."
    k "I know, it’s just… this is all new to me. I don’t want to mess things up."
    n "Kamil, there’s something I’ve been wanting to tell you for a while now."
    k "What is it?"
    n "I’ve always admired you, Kamil. The way you love Banu so deeply and truly. It’s something I’ve always desired in a partner."
    n "I’ve watched you, and I’ve felt this growing... attraction towards you."
    k "Nesrin, I… I didn’t know you felt that way."
    n "I’ve kept it to myself because I didn’t want to cause any issues between us or our friendships."
    n "But being here with you tonight, I couldn’t keep it inside anymore. I’ve developed feelings for you, Kamil."
    n "I respect the love you have for Banu, and that’s part of what draws me to you even more."
    k "I care about you and Polad a lot. You’re both very special to us. I never realized you felt this way, but I’m glad you trusted me enough to tell me."
    n "Thank you, Kamil. I just needed you to know."
    n "Whatever happens tonight, I wanted to be honest with you about my feelings."
    n "I’ve wanted this for so long, Kamil."
    k "Nesrin…"
    scene v20-279
    "Nesrin suddenly leans in and kisses Kamil."
    "The kiss is filled with passion and years of unspoken desire, catching Kamil off guard but quickly drawing him in."
    "Meanwhile, on the other side of the room, the atmosphere between Banu and Polad is equally intense but in a different way."
    "Banu is seated on the sofa, her legs parted, while Polad is on all fours on the floor before her. "
    "His face is close to her, and he’s sniffing her through the fabric of her dress, the act both sensual and electrifying."
    scene v20-280
    p "Banu, you smell amazing. I can’t get enough of you."
    b "Polad, you’re driving me crazy."
    p "Just wait until I get this dress off you."
    "He continues his teasing, his breath hot against her through the fabric. The sensation sends shivers down Banu’s spine, her body responding eagerly to his touch."
    scene v20-281
    "Back with Nesrin and Kamil, their kiss grows more intense, their hands exploring each other’s bodies with increasing boldness."
    n "Kamil, I want you so much."
    k "I want you too, Nesrin."
    k "Nesrin, I didn’t expect this, but I’m starting to feel something real for you."
    n "I feel the same way, Kamil. This connection, it’s something special."
    k "You’ve always been an amazing friend, but now I see you in a new light. There’s something so genuine about you, something that draws me in."
    n "I’ve always admired you, Kamil. Your love for Banu, your kindness, your strength. It makes me feel safe and cherished."
    k "And I admire you, Nesrin. Your honesty, your courage. You make me feel things I didn’t know I could feel for someone else."
    scene v20-282
    "As Kamil and Nesrin continue their intimate exploration, they are suddenly interrupted by a loud, passionate moan from the other side of the room."
    "Kamil turns his head towards the sound, his eyes widening at the sight before him."
    k "Banu..."
    scene v20-283
    n "Kamil, focus on me. We’re here together."
    k "I know, but seeing her like that… it’s hard not to feel something."
    n "Kamil, I want you here with me. Let’s make our own memories tonight."
    k "I’m sorry, Nesrin. It’s just… seeing Banu like this, it’s making me feel things I didn’t expect."
    n "Kamil, I want you. Let’s make this moment about us."
    k "I’m sorry, Nesrin. I’m trying."
    n "I know, Kamil. Just focus on me."
    scene v20-284
    "As the atmosphere in the room intensifies, Kamil finds it increasingly difficult to focus on Nesrin. "
    "Her kisses trail down his neck, but his eyes are drawn to the other side of the room, where Banu and Polad are completely lost in their passionate embrace."
    p "Banu, you’re so fucking hot. I can’t get enough of you."
    b "Oh, Polad, don’t stop. You feel so good."
    p "I’m going to make you cum so hard, Banu. You’re going to scream my name."
    b "Yes, Polad! Fuck, I’m so close…"
    n "Let’s show them what we’ve got. Make me feel as good as she’s feeling."
    scene v20-285
    k_ "Look at her… she’s completely lost in him. The way she’s kissing Polad, so deeply and passionately…"
    k_ "I’ve never seen her like this before. It’s almost like she’s forgotten I’m even here. Why does this turn me on so much? Shouldn’t I be angry?"
    k_ "But instead, I feel this strange thrill watching them. It’s like I’m on the outside, looking in, and it’s so… intense."
    k_ "I wish I could be the one making her feel that way, but at the same time, I can’t look away."
    k_ "Does this make me weak? Am I less of a man for feeling this way? Or is it just another way to love her, to let her explore her desires and be happy?"
    k_ "She looks so beautiful, so free. And Polad… he’s everything I’m not right now – confident, dominant."
    k_ "Maybe that’s part of the allure, seeing her with someone so different."
    k_ "But now I can't let Nesrin down. I have to show her what I'm capable of."
    scene v20-286
    b "I can’t wait to see what you’ve been hiding from me, Polad. I bet it’s as impressive as the rest of you."
    p "You’ll find out soon enough, Banu. But I want to hear you tell me how much you want it first."
    n "Kamil, I’ve been dreaming about this moment. I can’t wait to show you what I can do. Are you ready for me?"
    p "Come on, Kamil. Show us what you've got. Let's see who can please these ladies the best tonight."
    k "Uh, yeah, sure..."
    scene v20-287
    "Banu and Kamil lock eyes from across the room, an unspoken connection passing between them."
    "Banu feels a flush of embarrassment at being naked and kneeling in front of Polad, but she doesn't look away from Kamil. "
    "Their eye contact speaks volumes, conveying a mix of emotions—love, vulnerability, and a mutual understanding of the situation they've chosen to explore together."
    "Kamil tries to offer a reassuring smile, wanting to comfort Banu despite his own swirling emotions of jealousy and insecurity."
    stop music
    scene v20-288
    play music "audio/suspense.mp3"
    "As Polad and Kamil finish undressing, Polad catches a glimpse of Kamil's small penis and suddenly bursts into laughter, breaking the charged silence of the room."
    p "Oh man, Kamil, I didn’t know it was that small! How do you even manage with that?"
    k "Polad, that's enough..."
    p "Come on, Kamil. I didn’t know they made them that small! Do you need a magnifying glass to find it?"
    b "That’s enough, Polad! You’re being cruel and disrespectful."
    n "Polad, stop it right now. This isn’t funny. You’re hurting Kamil and ruining the evening."
    p "Oh, come on. It’s just a joke."
    b "Polad, that's enough! How dare you treat Kamil like this? You’ve crossed the line."
    scene v20-289 with fade
    "As Banu steps in to protect Kamil from Polad's mocking, her eyes inadvertently fall on both men's exposed bodies."
    "The stark size difference between them shocks her, and her mind races with conflicting emotions."
    b_ "Oh my god, I can’t believe the size difference. Polad is... huge. I’ve never seen anything like that before. It’s so intimidating and strangely arousing."
    b_ "But Kamil... he’s always been enough for me, hasn’t he? Why am I feeling this way? I love Kamil so much, and he’s always satisfied me in ways beyond just physical."
    b_ "But seeing Polad like this, it’s stirring something unexpected inside me. Is it wrong to be curious? To wonder what it would feel like? "
    scene v20-290
    p "Seriously, Kamil, how do you even manage with that? I’ve seen bigger on a baby!"
    "Kamil’s face turns red with embarrassment and anger. Banu, seeing the pain on her husband's face, feels a surge of protectiveness."
    menu:
        "Kamil stops it and fights Polad":
            $ kamilfightpoladfoursome = True
            $ renpy.block_rollback()
            p "Seriously, Kamil, with that size, you must be a master of foreplay, right?"
            "Kamil’s face turns red with a mix of humiliation and rage. He’s had enough of the mockery."
            k "That’s it, Polad! I’ve had enough of your jokes!"
            k "You think you're funny, Polad? Mocking me like that? You’re nothing but a bully!"
            p "Oh, come on, Kamil. Grow a thicker skin! It's just a joke, don't be such a sensitive little prick!"
            scene v20-291
            k "A joke? You think it's funny to humiliate me in front of everyone? Fuck you, Polad!"
            p "Fuck you too, Kamil! If you can't handle a little teasing, maybe you shouldn't be here!"
            b "Stop it, both of you! This isn't helping anyone!"
            n "Polad, enough! You're taking it too far!"
            k "Oh, I'm sorry, Mr. Big Dick. I didn’t realize you were so perfect! Why don't you go fuck yourself?"
            scene v20-292
            p "You know what, Kamil? Maybe Banu would be happier with someone who can actually satisfy her!"
            b "Polad, how dare you say that! This is too far!"
            k "You piece of shit! You don’t know anything about us or our relationship!"
            p "Maybe I do. Maybe that’s why she’s here with me right now, on her knees!"
            b "Kamil, no! Don’t let him get to you!"
            n "Polad, shut up! You’re making this worse for everyone!"
            k "You know what, Polad? Fuck you. We’re done here."
            p "Fine by me, you fucking coward!"
            b "This is not what tonight was supposed to be about. We need to stop and think about why we’re really here."
            k "Banu, let’s go. We don’t need this."
            "The night ends in a mix of regret and contemplation, leaving much to be mended in the days to come."
            stop music
        "Kamil just keeps his mouth shut":



            $ kamilfightpoladfoursome = False
            $ renpy.block_rollback()
            stop music
            play music "audio/softromanticsex.mp3"
            "As the evening progresses and Kamil decides to keep his mouth shut despite Polad's earlier mockery, the atmosphere begins to relax."
            p "How about we make this more interesting? Let’s play a game. "
            p "If Banu or Kamil cums, I win a point. If Nesrin or I cum, Kamil wins a point."
            p "Whoever has the most points after a set time gets to fuck both girls at the same time. What do you say, Kamil?"
            "Kamil glances at Banu, who gives him an encouraging nod. He then looks back at Polad, his competitive spirit ignited."
            k "Alright, Polad. Let’s do it. Game on."
            n "This should be fun. May the best man win."
            p "Alright, Banu. Show me what you’ve got."
            scene v20-293
            b "Polad, I’m getting addicted to your smell. It’s intoxicating."
            p "I’m glad you like it, Banu. Let’s make sure you get plenty more."
            "Meanwhile, on the other side, Nesrin starts to blow Kamil’s dick, her movements slow and deliberate, her eyes locking onto his as she takes him into her mouth."
            b "I want to taste you, Polad. I want to feel you in my mouth."
            p "Then go ahead, Banu. I want to see you enjoy it."
            scene v20-294
            b "Polad, you have such an amazing body. Your six-pack is incredible."
            p "Banu, you’re driving me wild. Don’t stop."
            b "I can’t get enough of your body, Polad. You’re like a work of art."
            n "Kamil, you’re so close. Let me push you over the edge."
            k "Ohhh...Nesrin, you’re incredible. Please, don’t stop."
            show banuandnesrinsuckkamilpolad
            play music2 "voices/suckdick.mp3"
            b "Mmm..."
            p "Banu, that feels incredible. Don't stop."
            n "Mmm..."
            k "Nesrin, you're amazing. Keep going, please."
            p "Kamil, your wife is so good at this."
            b "Cum for me, Polad. I want to feel you."
            n "Let go, Kamil. I want to taste you."
            k "Nesrin, that was…"
            stop music2
            scene v20-295
            "Banu's efforts to make Polad cum become more fervent, her movements deliberate and passionate. "
            "Kamil, caught in the moment, can't help but be mesmerized by how dedicated Banu is to pleasuring Polad."
            "The sight of her taking Polad's big dick with such enthusiasm becomes overwhelming for him."
            b "You like that, Polad? I want to see you cum for me."
            p "Banu, you’re amazing. Keep going."
            k "Oh god, Nesrin... I’m so close..."
            "Watching Banu's dedication to Polad pushes Kamil over the edge. "
            scene v20-296 with flash
            play sound "voices/man2.mp3"
            "Unable to hold back any longer, he climaxes, his body trembling with the force of his release as Nesrin continues to suck him, ensuring every drop is savored."
            stop sound
            k "Nesrin, I can’t... I’m cumming!"
            "Nesrin feels the rush of Kamil's orgasm, her mouth and hands working to prolong his pleasure. She pulls back slightly, smiling up at him with satisfaction."
            n "Looks like I win this round."
            scene v20-297
            p "Well, looks like I get the first point. "
            k "Alright, Polad. You got this one. But the night’s not over yet. We’ll see who comes out on top."
            b_ "I need to make him cum. Kamil needs to win this. I can do this."
            n "You can do it, Banu. Just take your time."
            scene v20-298
            p "Come on, Banu. Is that all you’ve got? I thought you’d be able to handle this."
            p "Take it easy. You don’t have to push yourself so hard."
            "Polad watches Banu, his expression a mix of pleasure and admiration. Her efforts are intense and dedicated, but she’s pushing herself to her limits."
            "As she takes him deeper, her eyes begin to roll back, and she struggles to accommodate his size."
            k "That’s enough, Polad. "
            "As the night continues and Banu’s determination remains strong, she focuses on pleasuring Polad, her eyes filled with resolve."
            "She takes him deep into her mouth, pushing herself to take as much of him as she can."
            scene v20-299 with vpunch
            play sound "voices/fastmoan1.mp3"
            "As Banu chokes and pulls back, she eventually collapses on the bed, breathing heavily and feeling a mix of exhaustion and frustration. "
            stop sound
            k "Banu, are you okay?"
            "She looks up at Polad with a defeated expression, her eyes filled with a blend of determination and vulnerability."
            p "What's the matter, Banu? I thought you said you could handle me."
            b "You think you're so great, Polad? You think you're a real man because I couldn't make you cum? You're nothing but a joke."
            p "Oh, really? Is that what you think?"
            b "Yes, that's exactly what I think! You can't even make me cum. You're not a real man. You’re just full of talk and no action."
            p "Is that so? You want to see what a real man can do?"
            b "Yes, Polad. Prove it. Fuck me. Make me cum if you think you're so good. I bet you can't even do that."
            k "Banu..."
            p "You want to be fucked, Banu? Fine. I’ll show you exactly what I can do."
            b "Then do it. Show me what you’ve got."
            scene v20-300 with vpunch
            play sound "voices/hardfemaleorgasm.mp3"
            b "Ahhhhhhhhhhhhh........"
            "As soon as Banu finishes her words, Polad's eyes flash with renewed intensity."
            stop sound
            "Without hesitation, he gets on top of her and, with a powerful thrust, mercilessly enters her tight pussy with his giant cock."
            "The sudden, overwhelming sensation pushes Banu over the edge immediately."
            b "Oh my God, Polad!"
            "Her body convulses with the force of her orgasm, the unexpected climax catching everyone off guard. "
            "Kamil, Nesrin, and Polad are momentarily stunned by the sheer intensity of Banu’s reaction."
            scene v20-301
            n "Did she just...?"
            k "Banu..."
            "Polad, still deeply inside Banu, pauses for a moment, his eyes locking onto hers. He can feel her body trembling around him, the aftershocks of her orgasm still rippling through her."
            p "Looks like I found your sweet spot, Banu."
            b "Polad... I... I didn't expect that."
            p "I’m not done with you yet, Banu. I’m going to make you cum again and again."
            p "That’s another point for me! Now it’s 2-0. Looks like I’m winning, Kamil."
            k "Congratulations, Polad. You’re definitely putting up a strong game."
            b "This isn’t over yet, Polad....Ahhhhhhhhh.... We’re going to come back strong."
            scene v20-302
            n "Just relax, Kamil. Let me take care of you. We’re going to make this count."
            "Kamil, feeling a mix of excitement and anticipation, nods and tries to relax, focusing on Nesrin’s touch."
            "Nesrin starts by lightly running her fingers over his chest and abdomen, her touch gentle and teasing, sending shivers down his spine."
            scene v20-303
            play music2 "voices/threesome.mp3"
            "As Kamil tries to focus on Nesrin's efforts to pleasure him, he can't help but be distracted by the intense scene unfolding next to him."
            "Polad's powerful thrusts are driving Banu to the edge, her moans of pleasure filling the room as she loses herself in the moment."
            p "Banu, you feel incredible. I'm going to make you cum so hard."
            b "Oh my God, Polad! Don't stop! You're driving me crazy!"
            p "You like that, Banu? I'm going to make you cum over and over again."
            b "Yes, Polad! Oh God, yes! Don't stop!"
            scene v20-304
            p "Tell me, Banu. Who’s better? Who’s making you feel this good?"
            b "You are, Polad! Oh God, you are!"
            p "And whose dick is bigger, Banu? Tell everyone."
            b "Yours is, Polad. It’s so much bigger!"
            k "Banu...."
            n "Kamil, focus on us. This is our moment too. Let’s make it special."
            p "You’re going to cum for me again. I can feel it."
            b "Oh God, Polad! I can’t... I’m so close!"
            p "That’s it, Banu. Let go. Cum for me. Show everyone how much you want this."
            stop music2
            scene v20-304 with flash
            play sound "voices/hardfemaleorgasm.mp3"
            b "Polad! Oh my God, Polad! I’m cumming!"
            p "That’s 3-0, Kamil. Looks like I’m winning."
            stop sound
            b "You really are something, Polad."
            scene v20-305
            "Nesrin turns her attention fully to Kamil, her eyes filled with determination and affection."
            "She begins to suck his dick with a renewed fervor, her tongue skillfully working him over as her mouth moves up and down his shaft."
            k "Nesrin, that feels incredible."
            "Beside them, Polad isn't done with Banu. He shifts her position, raising her legs into the air and positioning himself for a deep, intense thrust in the missionary position."
            "Banu gasps as he enters her again, the force of his movements driving her wild."
            scene v20-306
            play music2 "voices/threesome.mp3"
            p "Get ready, Banu. I’m going to make you cum again."
            b "Polad, please... I can’t take much more."
            "Polad's thrusts are powerful and relentless, driving deep into Banu with each movement. Her moans grow louder, the intensity of their connection filling the room."
            "Kamil, despite the pleasure Nesrin is giving him, can't help but glance over at Banu and Polad, the sight of their passionate encounter both captivating and distracting."
            p "You’re mine right now, Banu. Cum for me again."
            b "Oh God, Polad! Yes, yes, yes!"
            stop music2
            scene v20-307 with flash
            "Nesrin, sensing Kamil’s distraction, doubles her efforts, taking him deeper into her mouth and using her hands to stroke his shaft."
            "Polad’s powerful thrusts push Banu over the edge once more. Her body convulses with a third intense orgasm, her cries of pleasure echoing through the room."
            "Polad doesn’t let up, driving into her with unrelenting force."
            play sound "voices/hardfemaleorgasm.mp3"
            b "Polad, I’m cumming again! Oh my God!"
            "Polad's triumphant grin widens as he watches Banu lose herself to the pleasure he's giving her. He glances over at Kamil, his eyes filled with a mixture of triumph and challenge."
            stop sound
            p "That’s another one, Kamil. Can you keep up?"
            scene v20-308
            "The sight of Banu melting under Polad's powerful thrusts, her body writhing with pleasure, fills him with a mix of emotions."
            "Seeing her completely lost in ecstasy, combined with the incredible sensation of Nesrin's mouth, pushes Kamil to his limit."
            k "Oh, Nesrin... I can't hold on..."
            n "Let go, Kamil. Cum for me."
            scene v20-308 with flash
            play sound "voices/man2.mp3"
            k "Oh God, Nesrin... I'm cumming!"
            p "That's another point, Kamil, you are getting destroyed."
            stop sound
            scene black with dissolve
            "After a brief respite, the group rearranges themselves for the next round of their intense evening."
            scene v20-309
            "Polad positions Banu in doggy style, his powerful thrusts continuing to drive her wild. Meanwhile, Kamil lies on his back, and Nesrin straddles him, riding him with deliberate intensity."
            "The two women, caught in the heat of the moment, lean in to kiss each other passionately."
            p "You like that, Banu? You feel so tight around me."
            scene v20-310
            play music2 "voices/threesome.mp3"
            b "Yes, Polad! Fuck, yes! Don't stop!"
            n "Oh, Kamil, you feel so good inside me. I love it."
            k "Nesrin, you’re amazing. Keep going. Just like that."
            b "Nesrin, you're so fucking hot. I love this."
            n "Banu, you're incredible. I can't get enough of you."
            p "Banu, tell me who’s making you feel this good. I want to hear it."
            b "You are, Polad! Fuck, you're driving me crazy!"
            scene v20-311
            k "Mmm, Nesrin, you taste so good."
            n "Oh, Kamil, yes! Just like that. Don’t stop."
            p "Banu, you feel so amazing. Keep moaning for me."
            scene v20-312
            b "Polad, fuck! You’re driving me wild!"
            n "Oh, Kamil, yes! Just like that. Don’t stop."
            k "Come for me, Nesrin. I want to feel you."
            n "Kamil, oh my God! I’m cumming!"
            stop music
            show kamileatnesrinpoladfuckbanu
            p "You like that, Banu? You’re mine right now. Tell me how much you want it."
            b "Yes, Polad! I want it so bad. Don’t stop!"
            p "Look at her, Kamil. She’s completely lost in me. You could never make her feel this good."
            p "Look at her, Kamil. She’s cumming for me. Not for you. You can’t satisfy her like I can."
            "Banu, caught in the overwhelming pleasure, moans loudly, her body trembling with another intense orgasm."
            play sound "voices/moanfinish.mp3"
            b "Polad! Oh God, Polad! I’m cumming!"
            p "Shit, I lost count how many times she came on my dick man."
            stop sound
            scene v20-313
            "As the tension in the room reaches its peak, Kamil and Polad decide to up the ante, betting on who can fuck better and last longer."
            "The competitive spirit ignites a new level of intensity. Both men position Banu and Nesrin in doggy style, ready to prove their prowess."
            show kamilpoladfuckbanunesrindoggy
            p "Ready to lose, Kamil? Let’s see who can make their girl cum harder."
            k "Bring it on, Polad. Let’s see if you can keep up."
            p "Look at Banu, Kamil. She’s losing her mind over my cock. You can’t compete with this."
            b "Oh God, Polad! Yes, yes, don’t stop!"
            k "We’ll see about that, Polad. Nesrin’s going to cum so hard for me."
            n "Kamil, you feel so good! Don’t stop!"
            p "Banu’s cumming again, Kamil. Can you handle that?"
            b "Polad, I’m cumming! Oh my God, yes!"
            stop music2
            scene v20-314 with hpunch
            p "You like that, Banu? You’re mine right now. Cum for me."
            play sound "voices/hardfemaleorgasm.mp3"
            b "Yes, Polad! I’m so close!"
            b "Polad! Oh my God, yes!"
            stop sound
            "Seeing Banu's intense orgasm, Kamil is unable to hold back any longer. "
            play sound "voices/man3.mp3"
            k "Banu! Oh God, yes!"
            n "Kamil! Yes, yes, yes!"
            stop sound
            "As the intensity subsides, they collapse together, their bodies still trembling from the force of their orgasms. "
            scene v20-315 with fade
            "As the intense session begins to wind down, Kamil, feeling utterly spent, gets off the bed and slumps into a nearby chair. "
            "He looks exhausted, his breath still coming in heavy gasps."
            "Despite his own pleasure and the connection he shared with Nesrin, he can’t help but notice Polad still on the bed, his dick hard and ready, a clear reminder of the bet."
            scene v20-316
            p "Well, Kamil, it looks like I won the bet. Now, it’s my turn to have some fun with these lovely ladies."
            menu:
                "Stop it":
                    $ kamilstopspoladfoursome = True
                    $ renpy.block_rollback()
                    "As the scene continues to unfold, Kamil’s feelings of jealousy and exhaustion begin to take over."
                    "He watches Polad with Banu and Nesrin, and despite his attempts to stay composed, he can’t shake the growing discomfort."
                    scene v20-317
                    k "That’s enough, Polad. Banu, this stops now. We’re leaving."
                    "The room falls silent as everyone turns to look at Kamil. Banu, still caught in the throes of passion, looks at him with a mix of surprise and concern."
                    scene v20-318
                    b "Kamil, what’s wrong?"
                    p "Are you serious, Kamil? We had a deal."
                    k "I don’t care about the deal. This has gone too far. Banu, we’re leaving."
                    n "Kamil, if you’re uncomfortable, it’s okay. We all need to respect each other’s boundaries."
                    p "Alright, Kamil. If that’s what you want. No hard feelings."
                    k "Thank you, Polad. Banu, let’s go."
                    "Banu, sensing the seriousness in Kamil’s voice, starts to disentangle herself from Polad."
                    "She gets off the bed and moves towards Kamil, her expression showing a mix of guilt and understanding."
                "Let Polad fuck them":


                    $ kamilstopspoladfoursome = False
                    $ renpy.block_rollback()
                    play music "audio/hardsex.mp3"
                    k "A bet’s a bet, Polad. Just… make sure they enjoy it too."
                    b "Don’t worry, Kamil. We’re all here to enjoy ourselves."
                    p "Alright, ladies. Let’s make this memorable. Banu, come here."
                    scene v20-319 with fade
                    "Polad, taking Kamil’s permission as a green light, immediately positions Banu in a side pose."
                    "He aligns himself and thrusts into her hard, eliciting a loud moan from Banu. The intensity of his movements drives her wild, and she responds eagerly."
                    p "That’s it, Banu. Take it all. You love this, don’t you?"
                    scene v20-320
                    b "Yes, Polad! Fuck, yes! Don’t stop!"
                    "Nesrin, wanting to add to Banu’s pleasure, moves closer and starts to rub Banu’s clit with skilled fingers. "
                    n "You’re doing amazing, Banu. Let go. Enjoy every moment."
                    b "Oh my God, Polad! Nesrin! I’m going to cum!"
                    p "That’s it, Banu. Cum for us. Show Kamil how much you love this."
                    b "Kamil! I’m cumming!"
                    "Kamil, watching the scene unfold, feels a mix of jealousy and arousal."
                    scene v20-321 with fade
                    "Kamil watches as Polad, filled with renewed energy and intensity, bends Banu over. "
                    "Without missing a beat, Polad thrusts into her hard, eliciting loud moans of pleasure from Banu. "
                    "Meanwhile, Nesrin positions herself so that Banu can eat her pussy, adding to the intensity of the scene."
                    p "That’s it, Banu. Take it all. Show Kamil how much you love this."
                    b "Yes, Polad! Oh God, don’t stop!"
                    n "Banu, you’re incredible. Just like that."
                    scene v20-322
                    p "You’re nothing but a slut for this cock, aren’t you, Banu? Tell Kamil how much you love being fucked like this."
                    b "Yes, Polad! I love it! I love being fucked like this!"
                    k "This is so intense..."
                    n "Banu, I’m cumming! Oh God, yes!"
                    b "Polad! Nesrin! I’m cumming again!"
                    p "That’s it, Banu. Cum for us. Show Kamil how much you love this."
                    scene v20-323 with fade
                    "He suddenly turns his attention to Nesrin, lifting her leg and positioning himself to enter her."
                    "His thrusts are powerful and unrelenting, driving deep into her as she moans loudly with pleasure."
                    p "Nesrin, you’re going to take this. Feel every inch of me."
                    scene v20-324
                    n "Oh God, Polad! Yes, don’t stop!"
                    b "Polad, you’re incredible..."
                    p "Banu, watch closely. This is what happens when you drive your man crazy."
                    p "Come on, Nesrin. Tell everyone who fucks better."
                    n "Polad, you fuck better. You’re amazing."
                    p "That’s what I like to hear. Now, let’s keep this going."
                    b "Polad, you think you’re so tough, but can you handle this?"
                    "Polad, catching the playful challenge in her eyes, responds with a mischievous grin."
                    p "Let’s see how tough you are, Banu."
                    scene v20-325 with vpunch
                    b "Oh my God, Polad!"
                    "Without warning, he grabs Banu, turning her upside down with surprising speed and strength."
                    "The sudden movement catches everyone off guard, and the room falls silent as Polad lowers his head to her exposed backside, his tongue teasing her sensitive area."
                    b "Oh my God, Polad! That's my asshole."
                    n "Wow, that was unexpected…"
                    play sound "voices/fart3.mp3"
                    p "What? Did you just fart in my mouth?"
                    k "You deserve that."
                    p "You'll pay for this."
                    "Polad’s tongue works expertly, his movements confident and deliberate as he licks Banu’s asshole, driving her wild with sensation."
                    p "You like that, Banu? Tell everyone how much you love it."
                    b "Yes, Polad! I love it! Oh God, yes!"
                    scene v20-326
                    b "Oh my goodness!"
                    "A loud, involuntary fart escapes Banu as Polad penetrates her, shocking everyone in the room."
                    "The suddenness of it all leaves them momentarily speechless, unsure of how to react."
                    n "Did that just happen?"
                    k "I think it did."
                    scene v20-327
                    b "Oh God, Polad! You’re destroying my ass!"
                    "Polad’s thrusts are powerful and relentless, driving into Banu with a force that leaves her gasping and moaning. "
                    n "Wow, Polad. You’re really going for it."
                    k "Banu, are you okay?"
                    b "Yes, Kamil! I’m okay! Oh God, Polad, don’t stop!"
                    stop music
                    show poladfuckbanuassholefoursome
                    play music "voices/slappingmedium.mp3"
                    play sound "voices/fart1.mp3"
                    "Banu's body reacts unexpectedly, and she farts involuntarily while Polad continues to thrust. "
                    b "Oh my God, I’m so sorry!"
                    p "Well, Banu, looks like you really know how to let loose. I must be doing something right."
                    p "Look, Kamil, how your wife likes to fart on my cock non stop. "
                    n "Banu, you’re full of surprises tonight. Polad must really be hitting all the right spots."
                    b "Ahhhhh..I guess I couldn’t hold it in with Polad going at it so hard."
                    p "That’s right, Banu. Let it all out. I’ll keep going until you can’t take it anymore."
                    b "Oh God, Polad! Don’t stop!"
                    p "Ohh shit...I'm cumminggg..."
                    p "Banu, I want you to swallow every drop."
                    stop music
                    scene v20-328 with fade
                    "Banu, caught up in the heat of the moment and eager to please, nods eagerly."
                    "With a final powerful thrust, Polad releases his load, and Banu eagerly swallows every drop."
                    b "Mmm, you taste so good, Polad."
                    scene v20-329
                    b_ "As I savored every drop, my mind raced with the realization of how much I loved that moment."
                    b_ "The mixture of Polad’s taste, the heat of the moment, and the awareness of Kamil’s eyes on me made the experience incredibly exhilarating."
                    b_ "I also remember the intense sensations as Polad pulled out and the air hit my gaping asshole."
                    b_ "I glanced over at Kamil and saw the shock on his face as he watched, his eyes wide, taking in the sight of his wife with cum dripping from her mouth."
                    scene v20-330
                    b_ "Swallowing, I felt a wave of pride and fulfillment wash over me."
                    b_ "I had taken everything Polad had to give, and I had loved every second of it."
                    scene v20-331 with fade
                    k "Banu, are you okay?"
                    "I felt a rush of embarrassment wash over me, my cheeks flushing as I nodded."
                    "Cum was dripping from my mouth, and I was caught between the intense pleasure of the moment and the sudden self-consciousness of being so exposed."
                    scene v20-332
                    b "Yes, Kamil, I'm okay. Just... overwhelmed."
                    b_ "Looking back, I realize that night brought us all closer together. It was an experience of trust and passion."
                    b_ "I’ll never forget how alive I felt, how deeply connected we all were, and how much I enjoyed every second of it."



    $ renpy.end_replay()
    $ persistent.polad_nesrin_foursome_unlocked = True
    jump polad_nesrin_foursome_continue





label rina_cuckolding_kamil:



    scene black with dissolve
    "After their wild night with Polad and Nesrin, Banu and Kamil found their relationship becoming more adventurous."
    "They wanted to push the boundaries even further, so Banu decided to call up her boss and close friend, Rina. "
    "Now, Rina was no ordinary boss. She was a tough, no-nonsense Japanese woman who ran a successful prostitution business and loved exploring various fetishes."
    "She also had a thing for keeping men as servants and believed women were superior."
    "Banu, knowing Rina’s expertise and their close friendship, decided to contact her with an intriguing proposition. "
    "She wanted to take her relationship with Kamil to new heights by introducing him to some domme activities and making their experiences even more memorable."
    "Rina, always eager for new and exciting challenges, was thrilled by Banu’s request and invited them to her mysterious and luxurious place."
    scene v20-333 with pixellate
    play music "audio/action.mp3"
    "Banu, Kamil, and Orxan arrived at Rina's place, stepping into a grand, mysterious room that was both luxurious and enchanting."
    "The room was adorned with intricate designs, columns, and a shimmering pool that reflected the soft, ambient lighting."
    "The atmosphere was a mix of elegance and dominance, perfectly fitting Rina's style."
    scene v20-334
    b "Wow, this place never ceases to amaze me. Orxan, you're in for a treat."
    o "This place is incredible. So, tell me more about Rina. She sounds like quite the character."
    b "Oh, she is. Rina is one of my bosses and a close friend. She's tough as nails, runs a successful business, and has a knack for exploring all sorts of fetishes. "
    b "She believes women are superior to men and even keeps male servants in her house."
    k "Yeah, she's definitely one of a kind. She's helped us a lot in exploring new things in our relationship."
    o "Sounds like she's got quite the setup here. And she's cool with us taking photos?"
    b "Absolutely. Rina loves documenting these experiences. She thinks it's important to capture every moment, so we can look back and learn from them."
    scene v20-335 with fade
    "Banu, Kamil, and Orxan walked further into the grand room, their steps echoing softly against the marble floor. "
    "As they approached the center of the room, Rina came into view. She stood confidently, her presence commanding attention."
    scene v20-336
    "Dressed in a striking red outfit that highlighted her dominant personality, she exuded both elegance and power."
    b "There she is, the one and only Rina. Get ready, this is going to be an interesting night."
    o "She certainly knows how to make an entrance."
    ri "Welcome, Banu, Kamil, and Orxan. I hope you’re ready for an unforgettable experience."
    scene v20-337
    "Rina stood before them, exuding confidence and allure in her striking red outfit. The atmosphere was charged with anticipation as Banu, Kamil, and Orxan took in the sight."
    ri "Welcome to my domain. Tonight, we will explore boundaries and desires like never before. Are you all ready?"
    b "Absolutely, Rina. We’ve been looking forward to this."
    k "We trust you, Rina. Let’s do this."
    o "This is going to be one for the books. I can’t wait to capture every moment."
    ri "Kamil, tonight you will learn what it means to truly surrender. Are you ready to submit to Banu and me?"
    k "Yes, Rina. I’m ready."
    b "Trust us, Kamil. This will bring us closer and unlock new levels of pleasure."
    ri "Orxan, I hope you’re prepared to witness something extraordinary. Feel free to capture every intimate detail."
    "Rina sent Kamil and Banu off to change into something more appropriate for the night's activities."
    scene v20-338 with fade
    "As she watched them leave, her eyes shifted to Orxan, who stood confidently with his camera."
    "Sensing an opportunity to challenge and perhaps break his confidence, Rina approached him, her movements graceful yet assertive."
    scene v20-339
    ri "So, Orxan, you think you’re confident enough to handle all of this?"
    "Orxan met her gaze, his stance firm. He nodded, though the slight tremor in his voice betrayed his nerves."
    o "I’m here to capture every moment, Rina. I can handle it."
    "Rina stepped closer, her presence overwhelming as she looked him up and down. Her red outfit gleamed under the lights, emphasizing her dominance."
    ri "Oh, I don’t think you understand what it means to truly handle me, Orxan. I break men like you for breakfast."
    "Orxan swallowed hard, his eyes flickering with a mix of fear and excitement. He could feel the power radiating off her and knew he was in for a challenge."
    ri "You see, confidence can be so easily shattered. Let’s see how long you can keep that up."
    o "I’m not so easily broken, Rina."
    ri "We’ll see about that. By the end of tonight, you’ll understand what it means to be truly dominated."
    ri "You know, Orxan, I have ways of breaking even the most confident men. Ever thought about what it would be like to have your dick cut in half?"
    scene v20-340
    "Orxan's eyes widened in shock, and he took an involuntary step back."
    o "Wh-what do you mean?"
    ri "I could have you begging for mercy in no time. A little slice here, a little cut there... you’d be crying like a baby."
    o "That’s... that’s crazy."
    "Rina laughed softly, the sound sending shivers down his spine. She reached out and gently tapped his cheek."
    ri "Oh, don’t worry, Orxan. I’m just playing with you. Or am I?"
    ri "I can see you’re starting to get the picture. Confidence is such a fragile thing, isn’t it?"
    o "I’m just here to take photos."
    ri "Relax, Orxan. Tonight is about pushing boundaries and exploring limits. But remember, I’m in control here. You’d do well to remember that."
    o "You know, Rina, I’ve always admired a woman who knows what she wants and isn't afraid to take it. You have a way of commanding a room that’s really... impressive."
    ri "Is that so? Flattery will get you everywhere, Orxan. But you’re not off the hook just yet."
    o "I wouldn’t expect to be. I know I’m in the presence of greatness. Maybe if I do a good job tonight, you might consider rewarding me?"
    ri "You’re bold, I’ll give you that. Perhaps I might find a way to reward you, if you manage to impress me tonight."
    o "I won’t let you down, Rina. I promise to give it my all."
    ri "You know, Orxan, I can’t help but notice you’ve got quite the bulge there. Are you excited or just happy to see me?"
    o "Maybe a bit of both. You have that effect on people, Rina."
    ri "Oh, I do love a man who can handle a little teasing. Let’s see if you can live up to what you’re packing."
    scene v20-341
    "As they spoke, the door opened, and Kamil and Banu re-entered the room, their new attire catching everyone's attention."
    "Banu was dressed in a sleek, black latex outfit that hugged her curves perfectly. Her high boots and long gloves added an extra layer of allure, and the revealing design left little to the imagination. "
    "Kamil, on the other hand, wore a black mesh harness that accentuated his chest and a matching thong that barely contained him."
    scene v20-342
    ri "Well, well, don’t you two look absolutely stunning. Banu, that outfit is incredible on you."
    b "Thanks, Rina. I feel amazing in it. And Kamil, you look pretty hot yourself."
    k "Thanks, Banu. This is definitely... different, but I’m excited."
    o "You both look incredible. This is going to make for some fantastic shots."
    scene v20-343
    ri "Look at you, Kamil. All dressed up and nowhere to go. That little bondage you have there makes you look like a proper slave."
    ri "How does it feel, knowing you’re completely at my mercy?"
    "Kamil swallowed hard, his face flushing with a mix of embarrassment and arousal. He felt exposed and vulnerable under Rina’s intense gaze."
    k "It’s... it’s different."
    ri "Different? Oh, Kamil, this is just the beginning. From now on, you’ll do exactly as you’re told. "
    scene v20-344
    ri "You are nothing but a slave, here for my amusement and pleasure."
    ri "Do you understand me, slave?"
    k "Yes, mistress."
    ri "Good boy. Remember, you belong to me tonight. Every move you make, every breath you take, is for my pleasure. Do you understand?"
    k "Yes, mistress."
    ri "Banu, take your slave and show him what it means to serve. Orxan, make sure to capture every humiliating moment. "
    ri "Tonight, Kamil will learn his place."
    scene v20-346
    "Rina took a seat, her commanding presence filling the room. She glanced at Kamil with a smirk, her eyes gleaming with authority."
    ri "Kamil, place your hands at your sides and put your feet together. Stand still and don't move a muscle."
    scene v20-345
    "Kamil immediately obeyed, positioning his hands by his sides and bringing his feet together. He stood as still as he could, feeling the weight of Rina's gaze on him."
    "Banu walked over to Kamil, her latex outfit gleaming under the lights. She stopped directly in front of him, their bodies almost touching."
    "She looked directly into his eyes, her gaze intense and unwavering."
    scene v20-347
    b "Look at me, Kamil. Don’t look away."
    ri "That's it, Banu. Show him who's in charge. Kamil, remember your place. You are here to serve and obey."
    b "You will do exactly as you're told, Kamil. No hesitation, no questions. Understood?"
    k "Yes, Banu."
    scene v20-348
    b "You worthless piece of trash, you will do exactly as I say tonight. Do you understand?"
    k "Yes, Banu."
    b "You're nothing but a pathetic slave. You exist only to serve me."
    "Before Kamil could respond, Banu spat on his face, a gesture that was both shocking and intense. Kamil flinched but held his position, fully immersed in the role."
    "Orxan, capturing every moment with his camera, zoomed in to document the raw intensity of the scene."
    o "Keep it going. This is powerful."
    b "Kneel, Kamil. Hands behind your back."
    scene v20-349
    "Kamil immediately obeyed, kneeling with his hands clasped behind him. He looked up at Banu, his eyes filled with a mix of anticipation and submission."
    b "You are nothing but my slave tonight. You will obey my every command without question."
    "Without warning, Banu spat on Kamil’s face, the act serving as a stark reminder of the power dynamics in play."
    b "Pathetic. Look at you, kneeling there with spit on your face. Remember your place."
    o "This is incredible. Keep it up."
    scene v20-350
    b "You think you’re a man, Kamil? Pathetic. Look at you, kneeling before me like a good little slave. You’re nothing without me. Do you understand?"
    "Kamil’s heart raced as he listened to Banu's degrading words, feeling a mix of humiliation and arousal."
    "He could feel his manhood straining against the bondage, responding to her taunts despite the constraints."
    b "Look at you, getting hard just from my words. You’re such a weak, pathetic little man. You don’t deserve to be called a man."
    o "Incredible. "
    ri "Well done, Banu. Kamil, you’re learning your place well. Keep going."
    scene v20-351
    b "You think you’re worth anything, Kamil? You’re going to get on your knees and wash my ass with your tongue."
    b "And after that, I’ll piss on your dad’s face, just to show you how pathetic you really are."
    k "B-Banu…"
    b "What’s wrong, Kamil? Didn’t think you’d hear such filthy things from me? Get used to it. You’re my slave, and you’ll do whatever I say."
    ri "Excellent, Banu. Kamil, your submission is admirable. Keep going."
    b "You will do everything I say, no matter how filthy or degrading. Understand, slave?"
    k "Yes, Banu. I understand."
    scene v20-352
    b "Look at you, groveling at my feet like the pathetic worm you are. Is this what you’ve been reduced to, Kamil?"
    k "Yes, Banu. I exist only to serve your desires."
    ri "Excellent, Banu. He’s learning his place. Keep breaking him down. Show him what it means to be truly owned."
    b " You're nothing but a plaything, an object for my amusement. How does it feel to be so powerless, so utterly at my mercy?"
    o "This is intense. The contrast between power and submission... it’s visually stunning."
    ri "Push him further, Banu. Make him beg for more, make him show just how deep his submission goes."
    b "Beg me to degrade you further, beg like the desperate, pathetic slave you are."
    k "Please, Banu, I beg you... I need your control, your humiliation. It’s all I want."
    scene v20-353
    "Banu pressed the sharp heel of her boot against Kamil’s bare ass, applying just enough pressure to pierce his skin slightly."
    "Rina watched from her seat, her eyes gleaming with approval and excitement. She loved seeing Banu take control and Kamil's utter submission."
    ri "Excellent, Banu. Keep pushing his limits. "
    "Kamil’s breath hitched, the sensation of Banu's heel combined with her degrading words overwhelming him."
    scene v20-354
    "She instructed Kamil to remain on all fours, and then she gracefully positioned herself to sit on his back."

    b "Stay still, Kamil. You are my throne now."
    "Kamil's heart raced as he felt Banu's weight on his back. He knew what was coming and braced himself, his mind swirling with a mix of fear and arousal."
    k "Yes, Banu. I am your throne."
    "Banu picked up the punishment stick, a wicked gleam in her eyes. She raised it high and brought it down hard on Kamil’s exposed ass."
    b "You will take this pain and thank me for it, do you understand?"
    scene v20-355
    "Banu, feeling the rush of control, decided to intensify the experience. She adjusted her position slightly, making sure she had a good angle to deliver a particularly hard strike."
    "Her eyes locked onto Kamil's vulnerable, exposed balls, and a wicked smile spread across her face."
    k "Ahhhhhhhhh...."
    b "Brace yourself, Kamil. This will hurt, and you will thank me for it."
    scene v20-356
    k "Yes, Banu. Thank you for the pain."
    "With a swift, powerful motion, Banu brought the long stick down hard on Kamil’s bare balls. "
    play sound "voices/stickslap.mp3"
    "The sharp crack of the impact echoed through the room, immediately followed by Kamil’s loud, involuntary shout of pain."
    scene v20-357 with vpunch

    play sound "voices/manscream.mp3"
    k "Aaah! Oh god, Banu!"
    "The pain was searing, intense, and Kamil’s body shook from the force of the strike."
    b "That’s right, scream for me. You will remember who owns you every time you feel this pain. Who do you belong to, Kamil?"
    k "I belong to you, Banu. I am yours completely. Thank you for the pain."
    play sound "voices/stickslap.mp3"
    b "You like that, don’t you, Kamil? Let’s see how much more you can take."
    play sound "voices/manscream.mp3"
    k "Aaah! Banu, please!"
    b "Scream for me, Kamil. Let everyone know who you belong to."
    k "I belong to you, Banu! Only you!"
    b "Remember this pain, Kamil. It’s a reminder of your place. You will always be mine to control."
    k "Yes, Banu! I am yours, always!"
    scene v20-358 with fade
    b "Now, Kamil, you’ve taken your punishment well. As your reward, you get to serve me. Eat my pussy."
    "Kamil, still on all fours, looked up at Banu, his eyes filled with a mix of anticipation and submission. "
    k "Yes, Banu. Thank you for this reward."
    b "That’s it, Kamil. Use that tongue. Make me feel good."
    scene v20-359
    "She shifted slightly and raised one leg, placing it on Kamil's back to open herself up even more for his eager tongue."
    "The new position gave her better access and control, emphasizing her dominance over him."
    scene v20-360
    b "That’s right, Kamil. Keep going. Make me cum with that tongue of yours."
    "Kamil adjusted his position to accommodate her leg, his face buried between her thighs."
    k "Yes, Banu. I will make you cum."
    b "That’s it, Kamil. Don’t stop. Show me how much you worship me."
    ri "Excellent, Banu. Kamil, you’re proving to be a very devoted slave. Keep serving your mistress."
    b "I’m so close, Kamil. Don’t stop. Make me cum."
    scene v20-361
    "As Rina approached, her eyes were drawn to the vivid red lines on Kamil's ass, evidence of Banu's recent punishment."
    ri "Banu, you’ve done quite a job on him. Those red lines are a testament to your control and his submission."
    b "He needed to be reminded of his place, and he’s taken his punishment well."
    ri "You’ve marked him beautifully, Banu. Kamil, you should be proud to bear these marks. They show your devotion and your place beneath Banu."
    k "Yes, Rina. I am proud to serve Banu."
    ri "Very good. Keep going, Kamil. Make sure Banu is completely satisfied."
    scene v20-362
    ri "Look at you, Kamil. So dedicated to serving Banu. Let’s see how much more you can take."
    "Kamil shivered at the touch of the stick against his sore skin but kept his focus on pleasuring Banu. "
    "His body tensed in anticipation, knowing that Rina's gentle teasing was only a prelude to something much more intense."
    scene v20-363
    "Rina’s smile widened as she continued to tease him, running the stick gently over the red lines on his ass."
    "Then, without warning, she brought the stick down with a forceful strike, the impact echoing through the room."
    play sound "voices/stickslap.mp3"
    scene v20-364 with hpunch
    play sound "voices/manscream.mp3"
    k "Ahhhhhhhhhhhhhh..."
    ri "Take this, Kamil!"
    k "Aaah! Oh god, Rina!"
    b "Yes, Kamil! Keep going!"
    scene v20-363
    ri "You will take this pain and serve Banu. Do you understand, Kamil?"
    "Rina, feeling the intensity of the scene, decided to push Kamil even further. "
    ri "Get ready, Kamil. This one is going to hurt even more."
    scene v20-365 with hpunch
    play sound "voices/stickslap.mp3"
    k "Aaaah! Oh god, Rina!"
    "Without warning, Rina brought the stick down with all her strength, the impact resounding through the room."
    "Kamil’s body jerked violently, and he let out an even louder, more agonized shout."
    "In that moment, Banu felt a surge of uncontrollable dominance and desire."
    "She looked down at him, her eyes filled with a mix of pleasure and command."
    b "Open your mouth and take this."
    scene v20-366
    k "B-Banu..."
    "Banu couldn’t hold back any longer. She allowed herself to let go, feeling a sense of release and control as she began to piss in Kamil’s mouth."
    b "Take it, Kamil. This is your place, serving me in every way."
    "Kamil, accepting everything Banu gave him, felt the warmth fill his mouth."
    o "This is incredibly intense. The dynamic, the raw power... it’s all here."
    b "Take it all, Kamil. This is where you belong."
    scene v20-367 with vpunch
    play sound "voices/stickslap.mp3"
    ri "Take this, Kamil!"
    play sound "voices/manscream.mp3"
    k "Aaaah! Oh god, Rina! Fuck!"
    "Kamil’s body jolted from the impact, a loud shout escaping his lips as the pain shot through him."
    scene v20-368
    "Banu, continuing to wash Kamil's face with her piss, felt the power of the moment surge through her. "
    "The combined sensations and the sounds of Kamil's pain and submission fueled her dominance."
    b "Take everything we give you. You are ours to control."
    scene v20-369
    "Kamil kept his mouth open, swallowing what he could, while the rest of Banu's piss washed over his face, a clear display of his submission and her control."
    ri "You’re doing well, Kamil. Show us your devotion and submission."
    "Kamil, his face and mouth still covered in Banu’s piss, nodded weakly, his voice filled with a mix of pain and submission."
    k "Ohhhhhh...."
    scene v20-370 with vpunch
    ri "Take this, Kamil!"
    play sound "voices/manscream.mp3"
    k "Ahhhhhhhh.....shit....fuck, fuck, fuck...."
    "The intensity of the strike combined with the raw emotion and submission triggered a powerful orgasm."
    "Kamil’s dick erupted, his body shaking as he released in a torrent of intense pleasure, the sensation overwhelming him completely."
    play sound "voices/man3.mp3"
    k "Oh, Banu! Rina! I’m cumming!"
    b "That’s right, Kamil. Cum for us. Show us your devotion."
    stop sound
    scene v20-371 with fade
    k "Oh god... Banu... Rina..."
    "Banu, standing over him, looked down with a mix of satisfaction and dominance."
    b "Look at you, Kamil. Completely spent and covered in your own cum. This is your place, serving and obeying us."
    o "This is incredible. The rawness, the emotion... it's all here."
    scene v20-372
    ri "Excellent, Kamil. You've proven yourself as a truly devoted slave. This is the result of your dedication and submission."
    ri "So, Orxan, how do you like my display of dominance? Does it meet your expectations?"
    o "Rina, your dominance is truly impressive. The way you command and control... it's powerful and captivating. I've never seen anything quite like it."
    scene v20-373
    ri "I'm glad you appreciate it, Orxan. Dominance is an art, and it takes skill to execute it properly. Do you think you could handle being on the receiving end of such control?"
    o "I'm not sure, Rina. It would certainly be a new experience for me. But after seeing what Kamil went through... I think it could be quite enlightening."
    ri "Orxan, come closer. It's time for you to be more than just an observer."
    ri "Kamil, stand up. Your submission isn’t over yet."
    scene v20-374
    ri "Take off your pants. Show us what you’ve got."
    "Orxan hesitated for a moment, his heart pounding with a mix of nerves and anticipation. "
    "He could feel the eyes of everyone on him as he slowly began to unbuckle his belt and slide down his pants."
    scene v20-375
    b "Ohhhhh shit..."
    k "What...."
    ri "Well, well, Orxan. It seems you’ve been hiding quite the secret."
    "Banu’s eyes widened as she took in the sight of Orxan’s impressive size. She exchanged a glance with Kamil, who also looked taken aback."
    scene v20-376
    b "Orxan, I had no idea. That’s... quite something."
    "Kamil, despite his exhaustion and recent submission, couldn’t help but feel a pang of insecurity at the sight of Orxan’s size."
    k "Yes, it’s... impressive."
    ri "It seems you’ve shocked everyone, Orxan. How does it feel to be exposed like this?"
    ri "Well, Orxan, it seems you’ve given us all quite a surprise. An uncircumcised member of that size isn’t something you see every day."
    b "It’s true, Orxan. Most men I’ve encountered have been circumcised. This is... different. How does it feel for you, having it uncircumcised?"
    o "It feels natural to me. I've never known anything different. The sensitivity is higher, which can make things more intense."
    scene v20-377
    "She turned her commanding gaze to Banu and Kamil, her eyes gleaming with anticipation."
    ri "Banu, you will kneel in front of Orxan and suck his dick while Kamil watches. "
    ri "This will be a true test of your control and Kamil’s devotion."
    "Banu and Kamil exchanged wide-eyed glances, the intensity of the moment washing over them."
    menu:
        "Kamil stops it":
            $ kamilstopsrina = True
            $ renpy.block_rollback()
            scene v20-378
            stop music
            k "No! I can’t just stand here and watch this."
            ri "This is part of the exploration."
            k "No, I won’t do it! This is too much!"
            ri "You knew what you were getting into, Kamil. If you can’t handle it, maybe you’re not cut out for this."
            k "Don’t you dare talk to me like that! I’m not some toy for you to play with!"
            scene v20-379
            ri "Enough! If you can’t handle this, then you have no place here. Get out of here."
            b "Rina, please. Let’s just talk this through. We can find a way to make this work."
            ri "No, Banu. He needs to understand that submission requires trust and control. Right now, he’s not demonstrating either."
            ri "He needs to leave and think about whether he’s truly ready for this."
            "Kamil, his anger boiling over, lashed out verbally, his voice filled with venom."
            k "You’re just a slut, Rina! You think you can control everyone around you!"
            ri "And you’re nothing but a cuck, Kamil. You can’t handle your own wife’s desires, so you lash out like a child."
            "Banu, caught in the middle, felt a wave of embarrassment and desperation. She stepped forward, trying to calm the situation."
        "Kamil obeys":







            $ kamilstopsrina = False
            $ renpy.block_rollback()
            stop music
            "Despite his jealousy and insecurities, Kamil knew this was a test of his submission and trust in Banu. He took a deep breath, steadying himself."
            play music "audio/heatedsex.mp3"
            scene v20-380 with fade
            "Banu, feeling the gravity of the moment, knelt between Kamil and Orxan. As she looked up, her eyes widened slightly, taking in the clear size difference between Kamil’s and Orxan’s members."
            "Orxan’s uncircumcised cock was significantly larger, a stark contrast to Kamil’s."
            b "Wow, there’s such a difference..."
            ri "Yes, Banu. There is a significant difference. This is about accepting and embracing those differences. Kamil, do you understand your place here?"
            k "Yes, Rina. I understand my place."
            scene v20-381
            "The size and weight of it were overwhelming compared to Kamil's, and she couldn't help but feel a rush of excitement and curiosity."
            "As she brought her face closer to the tip, she inhaled the musky scent. The smell was intoxicating, making her head spin with a mix of arousal and submission."
            b "It smells so... strong."
            "She closed her eyes for a moment, allowing the scent to wash over her, feeling her body respond to the primal allure of Orxan's cock."
            k "Banu..."
            ri "Embrace it, Banu. This is part of your journey. Kamil, watch and learn. This is about trust and submission."
            b "It’s so overwhelming..."
            scene v20-382
            b "Mmm..."
            "Orxan let out a soft groan, feeling the warmth and wetness of Banu's mouth enveloping him."
            o "That’s it, Banu. Take your time."
            "Kamil, standing beside them, watched with a mix of emotions. The sight of Banu taking Orxan’s cock into her mouth was both challenging and strangely arousing. "
            ri "Good, Banu. Embrace the sensation. Kamil, remember your place and support Banu."
            k "You’re doing great, Banu."
            ri "Kamil, kneel next to your wife and watch closely as she sucks Orxan's cock. "
            scene v20-383 with fade
            "He nodded slowly, understanding the importance of the command, and moved to kneel beside Banu."
            "Banu, feeling Kamil’s presence beside her, felt a renewed sense of determination and support."
            b "Mmm..."
            "Orxan, feeling the warmth and wetness of Banu's mouth, let out a soft groan, his hand gently caressing her hair in encouragement."
            ri "Good, Kamil. Watch closely. This is about trust and acceptance. Banu, you’re doing wonderfully. Keep going."
            scene v20-384
            k "Banu, are you okay? It's... it's so much."
            "Banu, her mouth full and eyes focused, glanced at Kamil briefly, seeing the mix of concern and jealousy in his eyes. She pulled back slightly, just enough to respond."
            scene v20-385
            b "I'm fine, Kamil. It’s just... a lot to handle. But I want to do this. For us."
            o "You're doing amazing, Banu. Take your time."
            k "Banu, you’re incredible. But seeing you like this... with him... it’s hard."
            o "You’re amazing, Banu. Just focus on the pleasure you’re giving and receiving."
            k "I love you, Banu. I’m here with you, no matter what."
            "Banu, her confidence bolstered by the support from both men, returned her focus to Orxan."
            show banusuckorxankamilwatch
            play music2 "voices/suckdick.mp3"
            o "Yes, Banu. Just like that. You’re amazing."
            k "Banu, seeing you like this... it’s so intense. You’re incredible."
            b "Mmm..."
            o "Keep going, Banu. You’re doing so well. I can feel your passion."
            k "Banu, you’re driving me crazy. The way you’re taking him... it’s intense."
            b "Mmm... Mmm..."
            o "Just like that, Banu. Don’t stop. You’re going to make me cum."
            k "You’ve got this, Banu. I trust you completely. You’re amazing."
            stop music2
            scene v20-386
            "She pulled back slightly, gasping for breath. Orxan's thick cock rested against her lips as she looked over at Kamil with a mixture of exhaustion and raw desire in her eyes."
            b "Kamil... I need you."
            k "Banu, you’re driving me wild. The way you look right now... it’s unbelievable."
            o "Take your time, Banu. You’re doing amazing. Feel the connection between you and Kamil."
            b "I want you to see this, Kamil. I want you to feel this with me."
            ri "Kamil, she needs you. Why don’t you help her suck Orxan’s cock?"
            "Kamil hesitated, his mind racing with a mix of emotions. He glanced at Banu, seeing the exhaustion and desire in her eyes, feeling a surge of conflicting feelings. "
            "Before he could fully process his thoughts, Orxan reached out and grabbed Kamil's head, guiding it towards his thick cock."
            scene v20-387
            o "Come on, Kamil. Help Banu."
            k "Mmmph!"
            "Kamil's eyes widened in shock as Orxan's cock was pushed into his mouth."
            b "Kamil..."
            scene v20-388
            k "Mmm..."
            o "That’s it, Kamil. Just like that."
            b "Kamil, you're... incredible."
            "Banu, watching Kamil's enthusiasm and the clear evidence of his arousal, felt a mix of shock, admiration, and deep arousal."
            b "Kamil... you're so hard."
            o "That’s it, Kamil. You’re doing amazing. Keep going."
            b "You’re incredible, Kamil. Keep going. I love seeing you like this."
            scene v20-389
            "Suddenly, Orxan took control, grabbing both Banu and Kamil's heads, guiding them closer together around his cock. "
            "The intensity of the moment surged as he positioned himself, pushing his dick into Banu's mouth while directing Kamil to lick the shaft."
            scene v20-390
            o "Both of you, work together. Show me how much you can please."
            b "Mmm..."
            k "Mmm..."
            o "Yes, just like that. You’re both doing amazing."
            ri "Banu, Kamil, you’re both doing wonderfully. Keep going. Show Orxan your dedication."
            o "Both of you... this is incredible. Don’t stop."
            scene v20-391
            "Banu reached out with one hand, grasping Kamil’s dick and beginning to stroke it rhythmically while she continued her efforts on Orxan."
            "Kamil, feeling Banu’s hand wrap around his cock and begin to stroke, groaned softly."
            k "Banu... oh god, yes..."
            o "Both of you... this is incredible. Don’t stop."
            o "Oh, Banu! I’m cumming!"
            scene v20-392
            stop music
            play sound "voices/man1.mp3"
            o "Ahhhhhh....shit..."

            "Banu's eyes popped out in shock as Orxan's release filled her mouth. "
            stop sound
            "At the same moment, Kamil, watching Banu’s shocked expression and feeling the intense connection between them, couldn’t hold back any longer. "
            scene v20-393
            k "Banu... oh god, I’m cumming!"
            "Banu, her mouth full, struggled to swallow Orxan's cum, her eyes still wide with surprise."
            b "Mmmm..."
            "Orxan, breathing heavily, looked down at Banu with satisfaction and admiration. He gently caressed her hair, appreciating her efforts and the intensity of the moment."
            scene v20-394
            "Banu and Kamil locked eyes, the intensity of the moment washing over them."
            "Cum was running down Banu's throat from her mouth, while Orxan's cock still dripped with his release."
            "Kamil, his own climax still tingling through his body, reached out and gently caressed Banu's hair. "
            b "Kamil, kiss me."
            "Kamil, feeling the deep connection between them, leaned in closer."
            scene v20-395
            k "Banu, I love you."
            b "I love you too, Kamil."
            "Their lips touched, and Kamil tasted the remnants of Orxan’s cum on Banu’s mouth. "
            "The kiss was slow and deep, filled with the love and trust they had for one another."
            "Rina, watching with satisfaction, nodded in approval. The scene had unfolded with a raw intensity that highlighted their trust and connection."
            scene v20-396 with fade
            "Rina, sensing the completion of one phase of their intense exploration, decided it was time for a shift."
            ri "Orxan, Banu, go get your clothes and clean up. You’ve both done well."
            scene v20-397
            "She winked at Orxan, signaling her approval and perhaps a hint of what was to come."
            "Orxan, catching the wink, nodded and followed Banu towards the shower, his eyes lingering on her as they moved away."
            "As Orxan and Banu disappeared towards the shower, Rina turned her attention back to Kamil."
            ri "Kamil, stay here. I’m not finished with you yet."
            scene v20-398 with fade
            play music "audio/suspense.mp3"
            o "Banu, you were incredible tonight. I can't get enough of you."
            b "Orxan, we should clean up..."
            o "Let me show you how much I appreciated your efforts tonight."
            b "Orxan, we need to be careful... Kamil..."
            "Before Banu could fully respond, Orxan's hands moved to her waist, pulling her against him."
            scene v20-399 with hpunch
            "His erection pressed against her thigh, and with a sudden, assertive movement, he positioned himself between her legs."
            "His thick cock found its way between her folds, pushing back and forth, rubbing against her sensitive areas."
            b "Orxan, we can't... Kamil..."
            "Orxan, not stopping, kissed her passionately, muffling her words. The sensation of his cock sliding between her legs, combined with the hot kisses, was overwhelming."
            scene v20-400
            "Banu felt her resistance weakening, but her mind was still on Kamil."
            o "Banu, just feel this. Let yourself go."
            b "Mmmm.."
            o "Mmmmmmmm..."
            b "Orxan, please..."
            scene v20-402
            "After a passionate, intense kiss, Orxan finally released Banu."
            "Her eyes locked onto Orxan’s, filled with a mixture of longing and defeat. She had resisted, but the desire to be fucked was overwhelming."
            o "Banu, I can see how much you want this."
            b "Orxan, I... I want you so bad, but... Kamil..."
            scene v20-401
            "Orxan's hard dick pressed against Banu's belly, the heat and urgency of his arousal evident."
            o "You know how much I want you."
            b "I want this so much, but we need to respect Kamil. We can’t do this behind his back."
            "His eyes locked onto Banu's with a smoldering intensity, and he moved closer, his hard dick pressing against her belly again."
            scene v20-402
            o "Banu, you drive me wild. I can't stop thinking about you."
            o "Just one more kiss, Banu. Let me show you how much I want you."
            menu:
                "Banu stops it":
                    $ banufucksorxanshower = False
                    $ renpy.block_rollback()
                    stop music
                    b "Orxan, get out of here! You crossed a line. I don't want anything to do with you right now."
                    o "Banu, I’m sorry. I..."
                    "But Banu cut him off, her voice rising with anger and determination."
                    b "Save your apologies. You disrespected me, Kamil, and everything we've been trying to build here. Get out of this bathroom. Now."
                    "Orxan nodded, realizing there was no point in arguing. He quickly turned and left the bathroom, his face showing a mix of regret and frustration."
                "Banu fucks Orxan":



                    $ banufucksorxanshower = True
                    $ renpy.block_rollback()
                    play music "audio/action.mp3"
                    b "Orxan, I can't hold back anymore. Take me. Fuck me."
                    o "Are you sure?"
                    b "Yes, I'm sure. I need you right now. Just fuck me."

                    scene v20-403 with fade
                    "Meanwhile, on the other side of the room, Rina decided to take the exploration to another level."
                    "She stood in front of Kamil, her eyes locked onto his as she slowly began to strip off her clothes."
                    "Piece by piece, her attire fell to the floor, revealing her impressive physique. Kamil's eyes widened in shock and awe as he took in the sight of Rina's naked body."
                    scene v20-404
                    "Rina’s body was a striking combination of strength and sensuality. Her large, firm breasts and curvy hips were complemented by her strong, muscled physique."
                    "Intricate tattoos decorated her skin, adding to her commanding presence. Her confidence and power were palpable, and Kamil couldn’t take his eyes off her."
                    k "Rina, I... I didn't realize..."
                    ri "Surprised, Kamil? This is the real me. All of me."
                    k "You're... incredible, Rina. I’ve never seen someone like you."
                    ri "Good. Now, let's see how far we can push your boundaries."
                    "Rina, her eyes gleaming with authority and desire, decided it was time to push Kamil's boundaries even further."
                    scene v20-405
                    "She guided him down to the floor, her movements deliberate and commanding. Kamil, feeling a mix of anticipation and submission, followed her lead and lay down on his back."
                    ri "I want you to eat my pussy. Hard and mercilessly. Show me how much you can handle."
                    "Kamil, his heart pounding with a mix of nervousness and excitement, nodded. He looked up at Rina, her powerful body towering over him, and felt a surge of determination."
                    scene v20-406
                    "He wanted to prove himself, to show her that he could meet her expectations."
                    k "Yes, Rina. I’ll do my best."
                    "Rina positioned herself over Kamil, lowering her hips until her wet, glistening pussy was right above his mouth."
                    "She grabbed his hair, pulling his face closer to her, her dominance evident in every movement."
                    ri "Good. Now, get to work. Eat me like you mean it."
                    show kamileatrinapussy
                    ri "You’re going to be my little toy tonight. Now, worship my pussy like the pathetic little cuck you are."
                    k "Mmmm..."
                    ri "That’s it, you worthless little cuck. Make me cum again. Your only purpose is to please me."
                    ri "Yes, that’s it, you pathetic little bitch. Keep licking. You’re nothing but a face for me to fuck."
                    ri "Yes, keep going, you worthless slut. Make me cum. That’s all you’re good for."
                    ri "Look at you, Kamil. Pathetic. You think licking my pussy makes you a man?"
                    ri "You think it makes you enough for Banu? It doesn't. You’ll never satisfy her the way a real man can."
                    scene black
                    b "Ahhhhhhhh.....shit....fuck..."
                    show orxandeformbanubellyshower
                    play music2 "voices/slappingmedium.mp3"
                    b "Ahhhhhh...Orxan, please be careful..."
                    o "Banu, you feel so tight... I can't hold back anymore."
                    b "Oh god, Orxan... you're so deep... I feel like you’re going to break me..."
                    o "Take it, Banu. Take all of me. I want to feel you completely."
                    b "Orxan... ahhhhhhhhhh ..it's so much... I feel like you're going to tear me apart..."
                    "Orxan's thrusts became even more forceful, his grip on her hips tightening. He could see the outline of his cock through her belly with each powerful movement, driving him to push even harder."
                    b "Oh god, Orxan! Yes!"
                    o "I’m going to cum inside you."
                    b "Yes, Orxan! Fill me..."
                    stop music2
                    scene v20-407
                    b "Oh... ah... Orxan... so deep... can’t... ah... too much... oh god... ah... yes... so... ohhh..."
                    "Her eyes crossed, her vision blurring as she struggled to comprehend the overwhelming sensations."
                    "She tried to speak, but her mind was too consumed by the overwhelming sensations."
                    b "Oh... ahhh... Orxan... ahhh... so... deep... oh god... ah... too... much... can’t... ahhh... yes... oh... ahhh..."
                    "Orxan's thrusts grew even more forceful, his grip on her hips tightening as he drove deeper into her."
                    b "Ahhh... Orxan... can’t... ahhh... so... deep... oh god... yes... more... ahhh... too... much... ahhh... breaking... oh... ahhh..."
                    scene v20-408
                    o "What's the matter, Banu? Can't handle it? Look at you, babbling like a helpless little slut."
                    b "Ahhh... oh... Orxan... ahhh..."
                    o "You can't even talk, can you? Just a blubbering mess. Is this what you wanted? To be fucked so hard you can't even think?"
                    b "Ahhh... oh god... yes... Orxan... ahhh... more... ohhh..."
                    o "Look at you, Banu. Completely undone. I knew you couldn't handle it."
                    b "Oh god... Orxan... yes... more... ahhh... ohhh..."
                    scene v20-409
                    "With a swift movement, he lifted Banu off the mirror table and lowered her to the floor."
                    "He positioned her above him, his eyes gleaming with a mix of desire and mischief."
                    scene v20-410
                    b "Oh... Orxan... ahhh... can't... oh god... too much... ahhh..."
                    o "Let’s see how much more you can take, Banu. You’re already babbling like a mess. What’s a little more?"
                    b "Ahhh... ohhh... Orxan... please... ahhh... can’t... too... much... ohhh..."
                    o "Look at you. Can’t even talk properly. Just a mindless, babbling mess. Is this what you wanted?"
                    o "You’re completely unraveled under me. Kamil could never do this, could he? He can't make you lose control like I can."
                    b "Oh god, Orxan! I can’t... I can’t hold it... ahh!"
                    scene v20-411 with vpunch
                    "The sensation was so overwhelming that as soon as Orxan pulled out, she squirted uncontrollably."
                    b "Oh God, I'm sorry...I'm sorry..."
                    o "See what I can make you do? Kamil will never match this. Never."
                    b "Orxan, stop... please... it’s too much."
                    scene black with dissolve
                    "..."
                    scene v20-412
                    "Meanwhile, on the other side of the room, Rina decided to take control in a way that would further push Kamil's boundaries."
                    "He carefully put the black mask on, the black cock protruding from the mouthpiece, making him feel both submissive and strangely empowered."
                    ri "You're going to use this to fuck me."
                    scene v20-413
                    ri "Now, Kamil, come here and fuck me with that cock in your mouth. Show me how much you want to please me."
                    "Kamil approached her, his heart pounding in his chest. He positioned himself between her legs, the black cock ready to enter her."
                    scene v20-414
                    "He looked up at Rina, his eyes filled with determination and a desire to please."
                    k "Yes, Rina."
                    "He leaned forward, guiding the black cock into her wet, waiting pussy."
                    scene v20-415
                    ri "That's it, Kamil. Fuck me with that cock. Show me how much you want to please me."
                    "Kamil moved his head rhythmically, thrusting the cock in and out of Rina's pussy."
                    scene v20-416
                    k "Mmm..."
                    ri "Yes, Kamil! Just like that. Fuck me harder. Make me cum."
                    ri "Oh god, Kamil! Yes!"
                    show kamilfuckrinamask
                    ri "Look at you, Kamil, thinking you can actually satisfy me like this. It’s almost adorable how hard you’re trying."
                    ri "You’re just a puppet on a string, Kamil. Even with that cock, you’re barely a man."
                    k "Mmmmm..."
                    ri "Look at you, flailing around with a fake cock. Do you think you’re enough for anyone like this?"
                    ri "Keep going, maybe you’ll learn something about how to really please a woman."
                    ri "That’s it, Kamil, fuck me with your toy because that’s all you’re good for—playing with toys. You’re just a boy in a man's world."
                    ri "Maybe there’s hope for you yet, Kamil... Keep going... just like that..."
                    scene v20-417
                    ri "Faster, Kamil! You pathetic little worm, go faster!"
                    k "I... I'm trying, Rina..."
                    ri "Trying isn't good enough, Kamil! Move faster! Do it right, or don't do it at all!"
                    "But the physical strain and the weight of Rina's insults became too much for him to handle."
                    scene v20-418
                    stop music
                    "With a final, exhausted push, his legs gave out, and he collapsed onto the floor, panting heavily."
                    k "I... I can't... I'm sorry..."
                    ri "You worthless, pathetic excuse for a man! You can’t even do this right! You disgust me, Kamil!"
                    scene v20-419 with fade
                    k "I’m sorry, Rina... I tried..."
                    ri "Trying isn’t enough, Kamil. You need to do better."
                    "Rina, her frustration still simmering, decided to leave Kamil collapsed on the floor."
                    "She turned and made her way toward the bathroom, where she knew Orxan and Banu were."
                    scene v20-420 with fade
                    "The sounds coming from the bathroom indicated a scene of intense passion."
                    "As Rina approached, she saw Orxan's powerful form dominating Banu."
                    scene v20-421 with fade
                    b "Oh... Orxan... so deep... ahhh..."
                    ri "Looks like you’re having fun, Banu. Orxan, don’t hold back."
                    o "You heard her, Banu. Let’s give her a show."
                    "Banu’s moans grew louder, her body shuddering with each powerful thrust. She could feel Orxan filling her completely, pushing her to the edge of pleasure."
                    scene v20-422
                    b "Oh god, Orxan... I can’t... it’s too much... ahhh..."
                    ri "Look at you, Banu. Completely at his mercy. You love it, don’t you?"
                    o "She’s close, Rina. Watch her fall apart."
                    b "Oh god... Orxan... yes..."
                    "Orxan continued to thrust, riding out Banu’s orgasm until she finally collapsed against him, her body trembling with the aftershocks of pleasure."
                    "He pulled out slowly, watching as Banu’s body continued to shudder, her mind still reeling from the intense experience."




    $ renpy.end_replay()
    $ persistent.rina_cuckolding_kamil_unlocked = True
    jump rina_cuckolding_kamil_continue







label banu_blackman_play:




    scene v20-425 with fade
    b "What’s on your mind, Kamil? Thinking about tomorrow?"
    k "Yeah, I was just thinking about the photo shoot... and everything that’s going to happen."
    b "It’s going to be intense, isn’t it?"
    k "Banu, can you explain the plot to me again? I want to make sure I understand everything that’s going to happen tomorrow."
    b "Of course, Kamil. So, the story revolves around me playing the role of a devout, hijab-wearing housewife."
    b "You’ll play my husband, who is oblivious to my secret affair. The twist is that I’m having an affair with a black exchange student."
    k "And Orxan will be there, right?"
    b "Yes, Orxan will be directing and photographing the entire scene. He has a keen eye for capturing the intensity and emotion of such moments."
    scene v20-426
    b "And there’s one more thing. Rina has arranged for one of her servants, a black man, to play the role of the exchange student."
    b "He’ll be the one I’m having the affair with."
    k "Rina’s servant? That’s... unexpected. But I trust you, Banu. I trust us."
    k "Banu, I agree to do this, but I have one condition. "
    k "The black man – he can be part of the story, but he won't touch you. I just... I don't think I can handle that."
    b "Of course, Kamil. He won't touch me. Just a few photos with him. That's all."
    k "Thank you, Banu. I trust you, and I’m willing to explore this with you. I just need to know that we’re both on the same page."
    b "We are, Kamil. We’ll talk to Orxan and make sure the shoot is something we’re both comfortable with. It’s important that we both enjoy this experience."
    scene black with dissolve
    play music "audio/kometaback.mp3"
    "..."
    "The next day, Kamil, Orxan, and the black man that Rina sent gathered in the setting apartment room. "
    scene v20-427 with blinds
    o "Alright, gentlemen, let's go over today's plan one more time."
    "Kamil nodded, trying to focus on Orxan’s words despite the silent figure next to him. He glanced at the black man, who remained expressionless and still."
    k "Sounds good, Orxan. I just want to make sure everything goes smoothly."
    o "Don’t worry, Kamil. We’ve got this. Just remember to stay in character and follow the script."
    scene v20-428
    k "So, um, what’s your name? It’s nice to meet you."
    "Kamil turned to the mysterious man."
    "The black man remained silent, his eyes steady but not hostile. Kamil looked at Orxan for help, who shrugged slightly."
    o "Rina trained him to be... let’s say, highly focused. He doesn’t speak during the shoots. Think of him as the strong, silent type."
    k "Oh, I see. Well, I hope we all work well together."
    o "Alright, let’s get started. Remember, we’re telling a story here. Let’s make it as authentic and powerful as possible."
    scene v20-429
    "As they were preparing to start, Banu entered the room, dressed in black, lacy lingerie that left little to the imagination. "
    b "Hey..."
    o "Banu, you always manage to steal the show. I'm starting to think I should just retire and let you handle all the directing."
    b "Oh, come on, Orxan. We all know you love being behind the camera too much to give it up."
    o "Maybe, but you make my job a lot easier. With you in front of the lens, I don't have to worry about a thing."
    b "Well, I aim to please. Let's make this shoot unforgettable."
    scene v20-430
    "Kamil, still feeling the sting of jealousy, couldn't help but comment on Banu's provocative attire."
    k "Banu, why did you rush to show your bare pussy like that?"
    b "Kamil, it’s part of the role I’m playing. We agreed to push our boundaries and explore new things together. It’s all for the story we’re telling."
    o "Kamil, Banu is just getting into character. The more authentic and intense the performance, the more impactful the photos will be."
    k "I understand. It’s just... seeing you like this..."
    b "I know it’s difficult, Kamil. But remember, this is something we’re doing together. I’m here with you, and I trust you completely."
    o "Come on, Banu. Let’s go over the scene in the bathroom. I'll explain a few things before we get started. "
    scene v20-431 with fade
    b "I’ll be right back, Kamil. Trust me."
    "Kamil watched them go, a mix of emotions swirling inside him—jealousy, concern, but also a sense of trust and excitement for what they were about to create."
    o "Alright, Banu. You’re the devoted housewife, caught in a moment of forbidden passion."
    o "I want you to convey that mix of guilt, excitement, and vulnerability."
    scene v20-432
    b "Got it, Orxan. I’ll give it everything."
    o "Good. Now, we’re going to start with you looking at yourself in the mirror, contemplating the situation you’re in."
    o "Banu, you look incredible. I can see why Kamil is so jealous and insecure. He must hate knowing how much you enjoy this."
    scene v20-433
    "Banu’s breath hitched slightly at Orxan's words, a mix of excitement and guilt washing over her. She looked at her reflection in the mirror, seeing the vulnerability and desire in her own eyes."
    b "Orxan..."
    o "You know he’s watching, don’t you? Seeing you like this, knowing what’s happening... it drives him crazy."
    o "And you love it, don’t you? Showing off that beautiful pussy, knowing he can’t handle it."
    b "Orxan, stop it. You're making me uncomfortable."
    o "That’s right. Embrace it, Banu. Let him see how much you enjoy this. Let him feel that jealousy and insecurity. It’s all part of the experience."
    scene v20-434
    o "Banu, let's practice your moaning. We need to make it sound authentic for the shoot."
    b "Okay...if you say so..."
    o "How about we give it a try and see how Kamil reacts?"
    b "What?"
    o "How about we make a bet? You'll scream as if sb fucks you and if Kamil stays calm and collected, I'll do anything you say."
    o "But if he loses his cool, then you have to do whatever I say."
    b "Alright, Orxan, you’re on. But Kamil trusts me. He'll stay calm. I believe in him."
    o "Oh, I have no doubt Kamil will try to act confident, but deep down, he'll be an insecure wimp. Let's see if we can push him over the edge."
    b "Alright, let's do this."
    o "That's it, Banu. Let’s hear those moans."
    stop music
    scene v20-435 with hpunch
    play music "voices/longmoan.mp3"
    b "Oh... ah... yes..."
    b "Oh, yes... Orxan... oh god... ah..."
    "As Banu's moans echoed through the bathroom, reaching a fevered pitch, Kamil could no longer contain his emotions."
    b "Oh, Orxan... yes... ah... more...fuck me."
    "His heart pounded, and his mind raced with jealousy and insecurity. Suddenly, he couldn't stand it any longer. He rushed to the bathroom, his thoughts in a whirlwind."
    scene v20-436 with hpunch
    stop music
    k "What the hell is going on in here?!"
    "Orxan, who had been enjoying the moment, looked up with a satisfied smirk. He had won the bet, and it showed in his expression."
    scene v20-437
    o "Calm down, Kamil. We were just practicing Banu's moaning for the shoot. Seems like you lost our little bet."
    "Banu, who had been fully immersed in her role, looked at Kamil with a mix of disappointment and frustration."
    b "Kamil, I trusted you. We agreed to this, and you promised to trust me. Why did you have to come rushing in like this?"
    k "Banu, I... I’m sorry. I just... hearing you like that, I couldn’t handle it. I should have trusted you, but I couldn’t control my jealousy."
    o "Well, Kamil, it looks like you couldn’t handle it after all. I guess that means Banu has to do whatever I say."
    k "Banu, I’m really sorry. I trust you, and I want to work through this with you."
    scene v20-438 with fade
    "Kamil, deeply embarrassed and feeling the weight of his mistake, quietly left the bathroom."
    k "Banu, I’m so sorry. I let my jealousy get the best of me. I should have trusted you."
    b "We need to trust each other completely if we’re going to continue exploring like this."
    k "You’re right, Banu. I promise I will always believe in you and trust you from now on. "
    k "I won’t let my insecurities get in the way again."
    b "What will you do if you hear the same moaning again?"
    k "Banu, I promise that if I hear you moaning again, I will trust that it’s part of the scene. "
    k "I won’t let my jealousy get the better of me. I’ll stay calm and support you, knowing that we’re doing this together."
    b "Well, apologies accepted."
    k "I love you, Banu. I’ll be right here, supporting you every step of the way."
    scene v20-439
    play music "audio/suspense.mp3"
    o "Let’s check your husband's reaction again, Banu. Let’s see if he can handle it this time."
    b "What?"
    o "Shhhhh..stay calm."
    b "What are you doing? He's just in the other room."
    o "You lost the bet, Banu. Now, you have to do whatever I say."
    scene v20-440
    o "And I say I’m going to fuck you right here in the toilet, while your husband is in the other room."
    b "You're out of your mind. Get off me!"
    o "And this time, I want you to moan for real."
    b "I can’t. Kamil is right in the other room. He trusts me."
    o "Let's check if he really trusts you."
    menu:
        "Push him away":
            $ banuletorxanfuckherkamilotherroom = False
            $ renpy.block_rollback()
            stop music
            b "Orxan, I can’t. Kamil is right in the other room. He trusts me."
            o "Come on, Banu. You know you want this. Just imagine how intense it will be."
            b "No, Orxan. I won’t cheat on Kamil. This isn’t what we agreed to. I can’t betray his trust like that."
            o "Alright, whatever...."
            "Banu felt a sense of relief wash over her. She turned to leave the bathroom, her heart still pounding, but her resolve intact."
        "Let him fuck you":




            $ banuletorxanfuckherkamilotherroom = True
            $ renpy.block_rollback()
            play music "audio/sexy.mp3"
            "After a moment of inner conflict, Banu took a deep breath and made her decision. She looked up at Orxan, her eyes filled with a mix of desire and determination."
            o "Good girl."
            scene v20-441 with hpunch
            b "Oh, Orxan..."
            "Without wasting any time, Orxan pulled down his pants, releasing his big, hard dick."
            "He lifted Banu's leg, raising it in the air as they stood."
            scene v20-442
            "Orxan’s smirk widened as he leaned in to kiss her deeply."
            "Banu’s initial resistance melted away as she surrendered to the moment, her body pressed against his."
            "She wrapped her arms around his neck, kissing him back with equal passion."
            o "That’s it, Banu. Let him hear you. Show him how much you love this."
            scene v20-443
            play music2 "voices/longhardmoan.mp3"
            b "Oh, yes... Orxan... ah..."
            b "Oh, yes... Orxan... fuck me...more... ah..."
            "Kamil, sitting on the bed in the other room, heard the sounds coming from the bathroom. His heart was pounding, but he took a deep breath and called out."
            scene v20-445
            k "Banu, are you testing me again?"
            b "Ahhhhh....Kamil...yessss....fuck....ahhhhhh..."
            scene v20-446
            k "Well, I trust you this time, Banu. You don't need to test me again."
            b "Oh, yes... Orxan... more... ah..."
            show orxanfuckbanukamilotherroom
            b "Oh, Orxan, you’re fucking me so hard... so bad... it feels incredible..."
            k "I trust you, Banu! You can’t deceive me this time, hehe!"
            b "Oh, yes... Orxan, you’re so bad... so good... ah..."
            b "Oh, yes... Orxan... more... ah..."
            k "Banu, keep going! This time, I won’t get suspicious no matter what. Hehe."
            b "Good... Kamil... just... trust... me..."
            o "Hear that, Kamil? She’s loving this. Let’s see how much more she can handle."
            b "Oh, yes... Orxan... more... ah..."
            k "Guys, please, stop that. I know what I did was wrong, but I apologized."
            scene v20-444
            b "If you want me to stop moaning.... ohhhhhhhh..., you need to apologize... ahhhhhhhhhhh... to me again. Apologize for doubting me."
            k "Banu, I’m sorry! I apologize for doubting you. I trust you completely!"
            b "That’s it, Kamil... keep trusting me... ah..."
            stop music
            stop music2
            "When it was over, Orxan stepped back, letting Banu catch her breath. She turned to him, her eyes filled with a mix of satisfaction and uncertainty."


    scene v20-447 with fade
    k "Banu, are you okay?"
    b "I’m okay, Kamil. I gave in to the moment, but it’s all part of our exploration. I hope you understand."
    k "Thank you, Banu. I trust you completely."
    scene v20-448 with fade
    "As Banu and Kamil were embracing, feeling the renewed strength of their bond, the black man entered the room."
    "He was completely naked, ready for the shoot. Banu's eyes widened in shock as she took in the sight of his enormous, erect member."
    scene v20-449
    play music "audio/weakbanu.mp3"
    b "Oh my god..."
    k "Wow, uh... that's... impressive."
    b "I wasn't expecting... that."
    o "Alright, everyone. Let’s get ready for the shoot. Banu, just focus on the scene."
    b "I'm ready. "
    scene v20-450
    "As the first scene began, Kamil stood to the side, watching with a mixture of anticipation and nervousness. Orxan directed them, ensuring everyone was in their positions."
    o "Banu, I want you to focus on the moment."
    "The black man, his presence commanding and confident, stepped forward and gently hugged Banu."
    scene v20-451
    b "Oh... oh my god..."
    "His strong arms wrapped around her, and he effortlessly lifted her leg, positioning himself so that his enormous dick was aligned with her pussy."
    k "No penetration, Orxan. Just posing. That was the agreement."
    o "Understood, Kamil. Just posing. Banu, let’s hear those moans. Show us how much you’re enjoying this."
    b "Oh... yes... ah..."
    "Banu knew he had chosen this position on purpose, pushing her and Kamil’s boundaries to the limit."
    "Orxan smirked, clearly pleased with the intensity of the scene he was orchestrating."
    b "Orxan, you did this on purpose, didn’t you?"
    scene v20-452
    o "It’s all part of the exploration, Banu. You’re doing great. Just keep going."
    b "Ahhhhh....ohhhh..."
    b "His dick....it's touching me..."
    o "Don't move. Hold that pose. That's amazing."
    k "Banu... are you okay?"
    b "Kamil... I’m... fine... just... trust... me..."
    o "Alright, lift her up and turn her towards the camera."
    o "I want her legs in the air so we can clearly see everything. Make sure her pussy is shown with that big black cock right there."
    scene v20-453 with fade
    play sound "voices/fastmoan2.mp3"
    "The black man complied, lifting Banu effortlessly and turning her towards the camera."
    "Her legs were in the air, and the sight of her exposed pussy pressed by the black man’s enormous member was undeniable."
    "Banu let out a frustrated moan, her body responding uncontrollably to the intense position."
    b "Oh... ah..."
    k "Banu... are you okay?"
    b "Kamil... I’m... fine... just... trust... me..."
    b "You really enjoy this, don’t you, Orxan? Putting me in such a degrading position... you think you’re in control?"
    o "Oh, I’m definitely in control, Banu. And look at you, moaning like you love every second of it. Maybe you’re the one who enjoys being degraded."
    b "Fuck you, Orxan. You think you can break me with this? I’m stronger than you think."
    o "Strong? Look at you, Banu. Moaning and trembling with a big cock pressed against you. You’re loving this, admit it."
    b "You’re nothing but a sadist, Orxan. Enjoying watching me struggle... but you’ll never truly have control over me."
    scene v20-454
    "As Banu continued to moan and struggle in the degrading position, her eyes suddenly caught Kamil's. "
    "She felt a wave of embarrassment wash over her, realizing how exposed and vulnerable she was in front of him."
    b "Kamil... I...please...look away."
    k "Banu, it’s okay. I’m here. Just remember why we’re doing this. I trust you."
    b "I know, Kamil... but this position... it's so..."
    o "Look at her, Kamil. She’s feeling embarrassed, but deep down, she’s loving every second of it. Isn’t that right, Banu?"
    b "You’re enjoying this too much, Orxan. "
    o "Alright, let's change positions. Banu, get on the bed. You too, big man. Sit on the bed and take Banu in your lap."
    scene v20-455 with fade
    "The black man complied, moving to sit on the bed. He lifted Banu effortlessly and positioned her on his lap, his fully erect dick just inches away from her wet pussy."
    "Banu's breathing quickened, her body responding instinctively to the proximity and the heightened tension."
    scene v20-456
    o "That’s it. Banu, I want you to feel everything but remember, no penetration. Just let him tease you."
    b "Oh... this is... so intense..."
    b "Oh my god..It's getting bigger and bigger..."
    "Banu's breathing quickened, her body responding to the sensation of his massive cock pressing against her wet pussy."
    b "I... I’ve never felt anything like this..."
    o "That’s right, Banu. Let him feel how much you’re enjoying this. Show Kamil how much you’re being stretched, even without penetration."
    o "Alright, let's change positions again. Black man, lay Banu on the bed on her back and raise her legs. I want her pussy to pop out for the camera."

    scene v20-457 with fade
    play sound "voices/fastmoan2.mp3"
    b "Ahhhhhh...Oh... my god..."
    "The black man complied, lifting Banu off his lap and gently laying her down on the bed. "
    "He positioned her on her back and then raised her legs, spreading them apart so that her pussy was fully exposed to the camera."
    o "Perfect. Banu, just stay like that. Let’s make sure Kamil can see everything."
    scene v20-458
    play music2 "voices/softmoan.mp3"
    "As the black man began to rub Banu's pussy, the intensity of the scene heightened. Banu moaned loudly, her body responding uncontrollably to the stimulation."
    b "Oh... yes... more... ah..."
    k "No penetration, Orxan. Remember the agreement."
    o "Relax, Kamil. It’s just rubbing. No penetration, I promise. Just look at how much she’s enjoying it."
    b "Oh... yes... please... ah..."
    o "You’re so wet, Banu."
    scene v20-459
    "Banu locked eyes with Kamil, her face flushed with a mix of embarrassment and pleasure. "
    b "Kamil... I’m... fine... just... trust... me..."
    "As the shoot continued, Banu's eyes were drawn to the black man's fully erect cock. She locked eyes with him, her moans becoming more sensual and uncontrollable."
    b "Oh... yes..."
    o "Look at you, Banu. You’re completely lost in it. You really want him to fuck you, don’t you?"
    b "Oh... ah..."
    scene v20-460
    stop music2

    o "Kamil, you saw it yourself. She’s craving it. You should just let the man fuck her. It’s what she really wants."
    "Banu’s face flushed with embarrassment, her eyes darting to Kamil, searching for his reaction."
    k "Orxan, that’s enough. We agreed on our boundaries, and we’re sticking to them."
    o "Oh come on, Kamil. You saw how much she enjoyed it."
    o "Maybe you’re just scared to let her experience real pleasure. You should let him fuck her properly. She’s practically begging for it."
    menu:
        "Kamil stops the scene":
            $ kamilletblackmanfuckbanu = False
            $ renpy.block_rollback()
            stop music
            k "Orxan, enough. We’ve done what we agreed to, and we’ve respected our boundaries."
            o "If you say so, Kamil. But I think deep down, you know she wants more."
            k "We’ve made our choices together, Orxan."
            b "Orxan, this is enough. Kamil and I know our limits."
            o "Alright, alright. You two are tougher than I thought."
        "Kamil lets him fuck Banu":





            $ kamilletblackmanfuckbanu = True
            $ renpy.block_rollback()
            play music "audio/sensualsex.mp3"
            k "You know, maybe... maybe we could try something more. "
            k "I think I want to see her... fully taken by him."
            b "Kamil...are you sure?"
            k "Yes, I'm sure. I want this. I think it will be... exhilarating to see you completely let go with him."
            "Orxan, always ready to push the boundaries, looks pleased with the turn of events and signals the black man to proceed."
            scene v20-461 with fade
            b "Ahhhh-ooohhh!"
            "As the black man began to slowly penetrate her, Banu's body responded immediately."
            k "Well, that’s a sound I haven’t heard before!"
            o "That’s it, Banu. Let’s keep going."
            scene v20-462
            b "Oh my god! Yes! Ah... ah..."
            "The black man didn't waste any time. He began to thrust powerfully into her, his movements strong and deliberate."
            "Banu's eyes widened as she felt the full length of him enter her, a mix of pleasure and shock flooding her senses."
            show blackmanfucksbanu
            play music2 "voices/hardfemaleorgasm.mp3"
            o "Look at her, Kamil. She's absolutely loving it. Maybe you should let her have this more often. She craves it, you can tell."
            k "Banu...."
            b "Oh... yes! More... ah... Kamil... oh god..."
            o "See how much she needs this, Kamil?"
            b "Oh my god! Yes! More... ah... Kamil... I love you... oh god..."
            "The black man thrust harder, sensing her nearing climax. With a final, powerful thrust, Banu was pushed over the edge. "
            "She screamed as her orgasm ripped through her, her body convulsing with the overwhelming pleasure."
            b "Oh my god! Yes! Ah... ah..."
            stop music2
            scene v20-463 with fade
            "Banu found herself straddling the black man, her back to him, her legs spread apart. "
            "The black man grabbed her hips firmly, guiding her onto his massive shaft once more. Banu gasped as she felt him fill her again, her body still sensitive from the previous climax."
            b "Oh... god... it’s so much..."
            o "That’s it, Banu. Just like that. Give us everything you’ve got."
            k "Kamil... I... oh god... it feels... amazing..."
            menu:
                "Banu talks to Kamil":
                    $ banutalkstoorxanwhilegettingfucked = False
                    $ renpy.block_rollback()
                    scene v20-464
                    b "Kamil... oh... I... I love you... ah... so much..."
                    k "I love you too, Banu. You're amazing..."
                    b "Kamil... oh god... this feels... incredible... thank you for... trusting me..."
                    b "Oh my god! Yes! More... ah... Kamil... oh... ah..."
                    k "Banu, you’re incredible. Let go and enjoy it. I’m here for you."
                    b "Oh my god! Yes! I’m going to... ah... oh god..."
                "Banu talks to Orxan":

                    $ banutalkstoorxanwhilegettingfucked = True
                    $ renpy.block_rollback()
                    scene v20-465
                    b "Orxan... you see this? He’s better than you... oh... much better... and you just hide behind the camera like a loser..."
                    o "Keep talking, Banu. Let's see if you can keep that up."
                    b "Oh my god! Yes!"
                    b "You think you're so powerful, Orxan? Watching from behind the lens? You wish you could make me feel like this... but you can’t."
                    o "Enjoy it while it lasts, Banu. We’ll see who’s really in control."
                    b "Oh my god! Yes! I’m going to... ah... oh god..."


            scene v20-466 with vpunch
            stop music
            play sound "voices/man1.mp3"
            "As the black man reached his climax, his moans filled the room, a deep, guttural sound that signaled his intense release. "
            stop sound
            "He gripped Banu tightly, his body tensing as he released all his seeds deep inside Banu’s pussy."
            b "Oh my god! Yes! I’m... I’m coming too!"
            scene v20-467
            play sound "voices/moanfinish.mp3"
            b "Ahhhhhh...."
            "As the black man finished, he slowly pulled out of Banu, his cock slipping out of her drenched pussy. "
            stop sound
            "A thick stream of cum began to ooze out, dripping down her thighs in a lewd display of their intense encounter."
            k "This is... incredible."
            o "This is pure gold. What a scene!"
            scene v20-468
            k "Banu, I love you. I’m so proud of us. We explored together, and we grew together. This was for us, and I wouldn’t have it any other way."
            b "Kamil... thank you. I love you so much. This... this was for us."
            o "That’s a wrap, everyone. Thank you for an incredible shoot."





    $ renpy.end_replay()
    $ persistent.banu_blackman_play_unlocked = True
    jump banu_blackman_play_continue





label orxan_threesome:


    play music "audio/sidesex.mp3"
    scene v20-471 with fade
    "After a few more minutes of chatting and drinking, the beer started to loosen their inhibitions."
    o "So, that shoot was pretty wild. I’ve got to ask, what’s the craziest thing you two have ever done before that?"
    k "Well, that definitely tops the list, but we've had our moments. Like that time at the beach, remember Banu?"
    b "Oh god, the beach. We thought we were being so sneaky, but we totally got caught by that old couple walking their dog."
    o "You two are something else. What happened after you got caught?"
    b "We were so embarrassed! We just grabbed our clothes and ran. But it was kind of thrilling, you know? The risk made it even more exciting."
    k "So, threesomes. Anyone here had any experience with those?"
    o "Well, I’ve been in a few. They can be a lot of fun if everyone’s comfortable and on the same page."
    scene v20-472
    b "Oh my God, Kamil, that's exciting. What’s it like, Orxan?"
    o "It’s all about communication and trust. And, of course, a bit of adventure never hurts."
    "Banu, feeling the effects of the alcohol, couldn't help but let her thoughts slip out. Her cheeks flushed as she spoke."
    b "I have to say, Orxan, you... um, you have a pretty impressive cock."
    o "Well, thank you, Banu. I appreciate the compliment."
    k "Banu, you really don’t hold back, do you?"
    b "Sorry, I just... well, it’s true. And I guess the beer is making me a bit more honest than usual."
    b "You know, maybe we could actually try a threesome sometime. What do you think, Kamil?"
    scene v20-473
    k "I don’t know, Banu. It’s a big step. I mean, I trust you, but..."
    o "It’s understandable, Kamil. Threesomes can be intense, but they can also be incredibly fulfilling if everyone is comfortable and on the same page."
    b "We don’t have to rush into anything, Kamil. I just thought it might be something fun to consider. But only if you’re okay with it."
    k "Okay, we can talk about it more. I just need some time to wrap my head around it."
    b "You know, Kamil, if we’re ever going to explore this, maybe now is the perfect time to bring Orxan to our bedroom. What do you think?"
    k "Banu, I don’t know... it’s a big step, and I’m not sure I’m ready for that right now."
    scene v20-474
    b "You know, Kamil, I really want to do this with Orxan. It could be so exciting for us."
    menu:
        "Kamil shows insecurity":
            $ kamilagreethreesomeorxan = False
            $ renpy.block_rollback()
            stop music
            "The jealousy and insecurity began to surface, despite his efforts to remain composed."
            k "Banu, I don’t know... It’s a big step, and I’m not sure I’m ready for that right now. What if... what if it changes things between us?"
            o "Hey, there’s no rush, Kamil. It’s all about what you’re comfortable with. "
            b "This is just something I thought we might explore together, but only if you’re okay with it. We can take it slow, step by step."
            k "I... I want to make you happy, Banu. But it’s hard for me to imagine. What if I can’t handle it?"
            b "Kamil...but.."
            k "No, Banu. I’m not comfortable with this. It’s too much for me right now."
            "The room fell silent for a moment, the weight of Kamil’s decision hanging in the air."
        "Kamil agrees to do a threesome":



            $ kamilagreethreesomeorxan = True
            $ renpy.block_rollback()
            k "You know what? Let’s do it. Let's try it tonight."
            b "Are you sure, Kamil?"
            k "Yes, I’m sure. If we’re going to explore this, we might as well see where it takes us. I trust you, Banu, and I want us to experience this together."
            b "Thank you, Kamil. I love you so much."
            o "Alright, why don’t we head to the bedroom and get comfortable? We’ll take things one step at a time."
            scene black with dissolve
            "After spending a few more minutes in the kitchen, the three of them moved to the bedroom."
            scene v20-475
            "Kamil and Banu exchanged a glance, and Banu felt a surge of boldness. "
            "She stepped away from Kamil and, with a deep breath, removed her clothes, standing completely naked in front of them."
            "The sight of Banu's naked body took both Kamil and Orxan's breath away."
            scene v20-476
            k "Banu, you look incredible."
            o "You’re stunning, Banu."
            b "This is... so intense. I can’t believe we’re actually doing this."
            b "I can see you’re both getting excited. I’m so wet right now just thinking about what’s going to happen."
            o "Your body is begging for it. And I can feel myself growing harder just looking at you."
            k "Banu, you look incredible. I can’t believe how much this is turning me on."
            b "I can feel how hard you are, Kamil. It drives me wild knowing you want this as much as I do."
            o "You’re so wet, Banu. I can’t wait to make you scream with pleasure."
            k "Yes, Banu. I can see how much you want it. Let’s do this together."
            scene v20-477 with fade
            "Banu took a deep breath and slowly got down on her knees in front of Kamil and Orxan."
            b "Oh my god, Orxan... your cock is enormous. It’s so much bigger than Kamil’s."
            o "You like what you see, Banu? It’s all for you. I want you to take it and show Kamil just how much you can handle."
            scene v20-478
            "Kamil watched, feeling a mix of jealousy and arousal. The sight of his wife on her knees, looking up at Orxan with such desire, was both intimidating and incredibly hot."
            k "Banu, I want to see you take him. Show me how much you want this."
            b "It’s so big, Orxan. I can’t wait to taste you."
            b "But I want to start with my dear husband."
            scene v20-479 with fade
            "Kamil watched, his breath hitching as Banu effortlessly took his cock into her mouth."
            k "Banu, that feels amazing..."
            b "Mmm... you taste so good, Kamil."
            "Kamil’s hands gently cradled Banu’s head, his fingers threading through her hair as she continued to suck him."
            k "You’re incredible, Banu. I love you so much."
            b "Just getting warmed up, Orxan. You’re next."
            o "Take your time, Banu. I’m enjoying the show."
            scene v20-480
            "As Banu leaned in to take Orxan's cock into her mouth, she immediately realized just how challenging it would be."
            "Her eyes rolled back as she struggled to accommodate him, the intensity of the sensation making her nipples harden and swell."
            o "That’s it, Banu. Just take it slow."
            b "You’re so big..."
            o "You really struggled there, didn't you, Banu?"
            k "That’s enough, Orxan. She did amazing..."
            o "Oh, how sweet. The little husband defending his wife’s honor. Face it, Kamil, she needs more than you can give her."
            "As Orxan continued to mock, Banu noticed Kamil’s reaction. Despite the harsh words, Kamil’s arousal seemed to intensify, his cock growing harder."
            "Banu, sensing the complex mix of emotions in the room, decided to take control of the situation."
            scene v20-481 with fade
            "Banu, feeling the heat of the moment, guided both men to the bed."
            "She lay between them, her hands stroking each of their cocks with a firm, confident touch."
            b "Kamil, you’re so hard for me. I love feeling you like this. You drive me wild."
            k "Banu, you’re amazing. I love you so much."
            "Orxan’s hand slid down her body, his fingers finding her wet pussy. He began to rub her clit in slow, deliberate circles, sending waves of pleasure through her."
            b "Oh, Orxan... that feels so good."
            o "You’re so wet, Banu. I can feel how much you want this."
            b "Kamil, do you see how much I want this? How much I need you both?"
            k "I see it, Banu. You’re so beautiful like this. I love seeing you so turned on."
            scene v20-482
            b "Oh, yes... just like that, Orxan. Keep going..."
            b "Kamil, I can see how hard you’re getting. You like watching another man pleasure your wife, don’t you?"
            k "Banu, I... it’s just... you’re so beautiful when you’re being pleasured. I can’t help it."
            o "Looks like your husband really enjoys seeing you like this, Banu. Maybe he likes knowing you’re being taken care of by someone else."
            b "Is that it, Kamil? Do you like seeing me with another man?"
            k "Yes, Banu. It turns me on so much... seeing you like this."
            b "Good. Because I love it too. I love seeing you so hard for me while another man pleasures me. It makes me so wet."
            o "That's it. My dick is going to explode."
            o "Let's fuck her, Kamil and give her what she wants."
            scene v20-483 with fade
            play music "audio/heatedsex.mp3"
            "Orxan grabs Banu forcefully in the cowgirl position and puts his cock deep inside of her pussy. He encourage Kamil to fuck her ass at the same time. "
            b "Oh my god... I can't take it... it's too much..."
            o "Come on, Kamil. Let's give her what she wants. Fuck her ass, man."
            o "That's it, Banu. Let yourself go. Feel everything."
            "Ahhhhhhh.....it's too much...."
            k "Ohhhhh...shit...his dick is pushing my cock....damn..."
            k "Man...she is getting destroyed..."
            show orxankamilfuckbanuatthesametime
            play music2 "voices/hardfemaleorgasm.mp3"
            b "Oh god, yes... I can't... it's so intense..."
            b "I’m so close... I can't hold back..."
            b "Oh my god... yes... yes..."
            k "Banu, just breathe. I’m right here...Ahhhhhh..."
            k "Ohhhh....damn...his cock..."
            b "Oh my god... yes... yes..."
            k "Ohhhh shit Banu, I can't hold back anymore..."
            stop music2
            scene v20-484 with vpunch
            k "Ahhhhhhhhh...shit..."
            play sound "voices/man1.mp3"
            k "Oh, Banu... I’m... I’m cumming..."
            b "Yes, Kamil... I can feel you...Ahhhhhh..."
            stop sound
            "With a final thrust, Kamil reaches his climax, his body shuddering as he releases inside of Banu's asshole."

            scene v20-485
            b "Oh my god, Kamil! I’m cumming too!"
            "Banu, already on the brink from the combined sensations, couldn't hold back any longer. The sound of her husband's pleasure, coupled with the physical sensations, sent her over the edge."
            b "Yes, yes, yes! Kamil, I’m cumming... I can’t... it’s too much..."
            k "Banu... oh, Banu, I love you..."
            b "Oh my god, I can feel both of you... it's incredible..."
            scene v20-486 with fade
            "As the wave of her climax subsides, Banu collapses gently against Orxan, exhausted and satisfied. "
            "Kamil's cum is running down from her slightly gaping asshole."
            k "That was beautiful, Banu. You were incredible."
            b "Kamil, you came so fast. You can’t even keep up with Orxan, can you?"
            k "Banu, I..."
            o "Looks like I’ve got more stamina, Kamil. Don’t worry, I’ll take care of her."
            b "Orxan, you feel so good... much better than Kamil. He can’t satisfy me like you can."
            k "Banu... I’m trying..."
            b "You know, Kamil...fuck it. I don't want it like this. I want more."
            b "I want real adventures, not just moments like this."
            k "What do you mean, Banu? What kind of adventures?"
            menu:
                "Kamil, I want him to fuck my ass and you watch":
                    $ orxanfuckskamil = False
                    $ renpy.block_rollback()
                    play music "audio/sexy.mp3"
                    k "What?"
                    scene v20-487 with fade
                    b "Fuck you, Kamil. I'm tired of your easy-cumming little dick."
                    b "Don't you want a real show? Watch Orxan fuck my ass."
                    "Kamil’s face flushed with a mix of emotions—embarrassment, arousal, and a hint of jealousy."
                    k "Okay, Banu... I understand. I’ll watch."
                    scene v20-488 with fade
                    b "That's it. Watch the real man's cock destroy my little asshole."
                    b "Sit there and watch closely. You know you can’t satisfy me like Orxan can."
                    "Kamil, feeling a mix of humiliation and arousal, nodded silently, his eyes locked on Banu as she positioned herself above Orxan."
                    scene v20-489
                    b "Look at you, Kamil. You’re just going to sit there and watch while a real man takes care of me."
                    o "Take your time, Banu. Let him see how it’s done."
                    "She takes a deep breath, determined to take him fully. As she lowers herself slowly onto Orxan's cock, she feels the immense pressure and stretch."
                    b "It's so big... but I can do this."
                    o "That's it, Banu. Take it slow. You’re doing great."
                    scene v20-490
                    b "Ohhhhhh...."
                    b "Almost there..."
                    "With a final push, Banu feels herself fully enveloping Orxan’s cock. She gasps, both from the sensation and the accomplishment."
                    show banusitsonorxancockanal
                    play music2 "voices/moaning.mp3"
                    b "Oh, Orxan, you're so big… I can feel every inch."
                    o "Damn, Banu, your ass is so fucking tight. "
                    b "Oh god... I did it. I can feel all of you, Orxan."
                    o "Shit, man, she squeezes my dick so bad."
                    b "Orxan ....ahhhhhhhh... you feel so good inside me. I love it..."
                    o "Shut up and keep going. Don’t stop."
                    b "Yes... yes... oh god, I’m going to cum..."
                    b "Ohhhhh...shit...I'm cumming from my ass...ahhhh.."
                    o "That's it, Banu. Let go. I’ve got you."
                    b "I can't hold it... Orxan, I’m..."
                    b "Ahhhhhhhh...."
                    scene v20-491 with fade
                    "As Banu recovered from her intense orgasm, Orxan gently but firmly repositioned her, bending her over in front of Kamil."
                    o "We’re not done yet, Banu. Hold on tight."
                    show banusitsonorxancockanaldoggy
                    b "Ahhhhhh....Kamil, watch me. I want you to see everything."
                    k "I’m watching, Banu. You’re incredible."
                    b "Oh god, Orxan... yes..."
                    o "Ohhh fuck...you're such a naughty couple..."
                    o "Shit...Look at you, Banu, taking it so well. And you, Kamil, just sitting there watching. Can’t even handle your own wife."
                    "Banu moaned loudly, her body responding eagerly to Orxan's thrusts and the added layer of teasing."
                    b "Oh god, yes..."
                    o "You see this, Kamil? This is what a real man does. You could never make her feel like this."
                    b "Oh god, Orxan... keep going..."
                    stop music2
                    scene v20-492 with fade
                    play sound "voices/fart2.mp3"
                    "Banu can't keep it and farts several times on Orxan's cock as he pushes it deep inside her asshole."
                    b "Ohhhhh...Oh my God...I'm sorry..."
                    o "Shit, Kamil, your wife is such a dirty woman. Look how many times she farted on my cock...damn..."
                    play sound "voices/man1.mp3"
                    o "Ohhhh....shit...I'm cumming...Banu..."
                    o "Ohhh yeah...that's it..."
                    b "Ahhhhh...yes...I can feel it....he's filling me up....ohhh..."
                    stop sound
                    scene v20-493 with fade
                    play sound "voices/fastmoan3.mp3"
                    b "Ahhhhhh....Kamil....it's....so...."
                    o "Oh god, Banu..."
                    "The hot streams of his cum landed on Banu's ass."
                    "Orxan groaned loudly, his orgasm overwhelming him."
                    scene v20-494 with fade
                    stop music
                    o "Damn...what a mess..."
                    "Orxan didn't waste any drop and let all his last seeds inside of her asshole."
                    "He collapsed next to Banu, his breathing heavy and ragged."
                    scene v20-495 with fade
                    "Banu, feeling deeply satisfied and connected, looked over at Kamil, who watched with a mix of awe and love."
                    b "That was incredible."
                    "Kamil, still processing what he was seeing, nodded slowly, his eyes wide with amazement."
                    k "There's so much..."
                    b "Kamil, it’s okay...ohhhh...I needed this."
                    k "I love you, Banu. You were amazing."
                "Kamil, I want him to fuck your ass":







                    $ orxanfuckskamil = True
                    $ renpy.block_rollback()
                    play music "audio/sensual.mp3"
                    k "What?"
                    b "How about Orxan takes you next, and I watch?"
                    k "Banu, what are you talking about."
                    b "Please, don't play stupid. I've seen you staring at his cock since he got naked. You want to feel that in your ass, don't you?"
                    k "Banu, I don’t know..."
                    b "Kamil, it’s just another way for us to explore together. Trust me, and trust Orxan. We can stop anytime you want."
                    k "Okay, Banu. I trust you. Let’s try this."
                    scene v20-496 with fade
                    k "Kamil moved to all fours, his heart pounding with a mix of fear and anticipation."
                    b "You’re doing great, Kamil. Just relax."
                    k "Okay... I’m ready."
                    k "This is... different, but I’m okay."
                    scene v20-497
                    "As Kamil prepared himself, Banu began to rub her pussy, her own arousal building. She looked at Orxan, her voice filled with urgency and excitement."
                    b "Ahhhhh...Orxan, please... fuck my husband’s ass."
                    o "You want me to destroy his ass, don't you?"
                    b "Ohhh yess...I want you to teach his stupid ass a lesson...."
                    b "I want him to feel the same feeling as I felt before..."
                    b "Fuck her asshole!"
                    scene v20-498
                    o "Remember, Kamil, if it's too much, just say the word."
                    "Kamil nodded, taking a deep breath. Banu, watching with a mix of excitement and concern, rubbed her pussy harder, her moans filling the room."
                    b "Orxan, do it."
                    scene v20-499
                    play sound "voices/manscream.mp3"
                    k "Oh god, wait!"
                    b "Ohhh Kamil, you are such a coward. He just put the tip inside."
                    k "Damn, it hurts so much, please, pull out!"
                    b "Keep fucking him, Orxan. Don't you dare to stop."
                    scene v20-500
                    play sound "voices/man2.mp3"
                    k "Ahhhhhhhhh....it's tearing me apart....ohhhh..."
                    k "Banu, please, tell him to pull out."
                    b "Orxan, keep going. He’s getting used to it."
                    k "Ohhhh...shit.."
                    b "That’s it, Kamil. Just let go and enjoy it."
                    b "Kamil, I want you to please me too."
                    stop sound
                    scene v20-501 with fade
                    "Banu moved in front of Kamil, positioning herself so that her pussy was level with his face."
                    b "Lick my pussy while Orxan fucks you."
                    k "Yes, Banu... anything for you.....ahhhhh..."
                    b "That’s it, Kamil... just like that."
                    scene v20-502
                    play sound "voices/man3.mp3"
                    b "Yes, Kamil! Don’t stop..."
                    k "Ummmmmm...ahhhhhh..."
                    k "Banu... you taste so good..."
                    stop sound
                    k "Ohhhhh... god... yesssss..."
                    "Banu, feeling the vibrations of Kamil's moans against sensitive pussy, gasped in shock and arousal."
                    b "Damn, Orxan...he's moaning like an animal. What are you doing to him?"
                    o "Wow, Kamil... you’re really feeling it, aren’t you?"
                    k "Ooooohhhhh... yesssss... more... please..."
                    o "You’re incredible, Kamil. Keep going..."
                    b "Yes, Kamil... keep going..."
                    scene v20-503 with fade
                    "Kamil finds himself in a remarkably intense position, caught between Orxan and Banu."
                    b "Look at us, Kamil. Isn't this what you've always wanted?"
                    k "Ohhhhhh...yes..."
                    "Kamil, sandwiched between the heat of Orxan's body behind him and the intoxicating closeness of Banu in front, feels an overwhelming mix of emotions."
                    scene v20-504
                    o "You feel that, mate?"
                    "Banu, observing the mixture of apprehension and thrill in Kamil’s eyes, kisses him deeply, her hands roaming over his chest, heightening the sensory overload."
                    "Kamil, caught in the web of sensations, lets out a moan muffled by Banu's kiss."
                    k "Ohhhhh...God..."
                    b "Just relax and let us take you somewhere you've never been before."
                    k "Ahhhh...I... I didn’t know it could feel like this..."
                    b "There's so much more to feel, Kamil. Let go for us."
                    scene v20-505
                    play sound "voices/man3.mp3"
                    k "Oh god... yes... I can't... ohhh..."
                    "Orxan increases the pressure and rhythm of his thrusts into Kamil's ass."
                    "Kamil feels the final thurst that sends his body a powerful climax."
                    o "That's it, Kamil. Let it all out. Show us how much you need this."
                    stop sound
                    b "Cum for us, Kamil. Let go completely."
                    k "Ohhhhh... god... I'm cumming...!"
                    b "You are amazing, Kamil. So beautiful."
                    scene v20-506 with fade
                    "Banu, sensing the perfect opportunity to tease him further, turns around and presents her perfectly shaped ass to him, giving it a playful wiggle."
                    b "Look at you, Kamil. Exhausted and covered in your own cum. Do you like what you see?"
                    "Kamil, still catching his breath, looks up at Banu, his eyes filled with a mix of admiration and lingering desire."
                    k "Banu... you're driving me crazy..."
                    scene v20-507
                    b "I know you love it, Kamil. Watching you fall apart like that... it’s so hot."
                    k "Banu..."
                    b "Do you want more, Kamil? Or have you had enough?"
                    k "I can never get enough of you, Banu..."
                    b "How about you watch Orxan fuck my ass while you recover? Would you like that, Kamil?"
                    k "No....no...that's enough..."
                    b "I don't care Kamil. I want cock in my ass right now. You better fuck my ass right now or I'll ask Orxan to do it."
                    k "Oh God...Banu..."
                    b "Come on, Kamil. Fuck my ass. Make me feel it."
                    k "Come here..."
                    scene v20-508 with fade
                    b "Ohhh... yes... Kamil..."
                    "Kamil begins to push into Banu’s ass slowly, feeling the tightness and warmth as he enters her. Banu lets out a moan, her body arching with pleasure."

                    scene v20-509
                    k "Banu... you’re amazing..."
                    b "Fuck me, Kamil. Fuck your wife's asshole."
                    k "Ohhhh...you're so tight..."
                    "Orxan watches the scene unfold, waiting for the perfect moment."
                    "As Kamil thrusts deeper into Banu’s ass, Banu locks eyes with Orxan and gives him a subtle wink, signaling him to proceed with the next part of the plan."
                    scene v20-510 with hpunch
                    play sound "voices/man1.mp3"
                    k "Oh... Orxan..."
                    o "Hold still, Kamil. Let’s take this to the next level."
                    stop sound
                    "Kamil’s eyes widen in shock as he feels Orxan’s cock teasing his entrance. He’s taken aback but too aroused to resist. "
                    "Orxan slowly pushes in, filling Kamil completely and causing him to moan with a mix of pleasure and surprise."
                    scene v20-511
                    b "Come on, Kamil. Fuck my ass. Make me feel it."
                    b "Ohhh... yes... Kamil..."
                    k "Oh... Orxan..."
                    o "You like that, Kamil? You like being fucked like this?"
                    k "Ohhhh...yes..."
                    show banuorxankamilfuckeachother
                    play sound "voices/man2.mp3"
                    "As Kamil thrusts into Banu's ass, he feels the incredible tightness and warmth enveloping his cock."
                    k "Oh, Banu... your ass... it’s so tight..."
                    "Banu’s moans mix with his, her body arching with every thrust. Her ass squeezes around Kamil’s cock, driving him to the brink of insanity."
                    b "Yes, Kamil... fuck me... harder..."
                    "The intensity of Orxan’s cock filling him from behind, combined with the sensation of Banu’s ass squeezing his cock, drives Kamil wild."
                    o "You like that, Kamil? You like being fucked by both of us?"
                    stop sound
                    play sound "voices/man3.mp3"
                    k "Oh... oh god... I’m going to... I can’t... this feels... so good..."
                    "Banu’s ass tightens even more around Kamil’s cock, and he feels his entire body tense up."
                    "Orxan’s powerful thrusts from behind push him over the edge, the pleasure becoming unbearable."
                    k "Ohhh... fuck... I’m cumming... I’m cumming...!"
                    b "Yes... cum inside me, Kamil... fill me..."
                    k "Oh... oh god... I can’t... this is... too much..."
                    stop sound
                    "Simultaneously, Orxan’s movements become even more determined, his breaths heavier as he reaches his peak. He grips Kamil tighter, signaling the imminent release."
                    o "Here it comes, Kamil... get ready for it..."
                    stop music
                    scene v20-512 with vpunch
                    o "Ohhhhhh...."
                    play sound "voices/manscream.mp3"
                    k "AAAAAHHHHHHHHH...."
                    stop sound
                    play sound "voices/man2.mp3"
                    o "That’s it, Kamil... take every inch..."
                    k "I can't hold back... I’m gonna..."
                    b "Yes, Kamil! Let it go... fill me up..."
                    stop sound
                    play sound "voices/man3.mp3"
                    k "Oh god... Orxan... Banu... I’m cumming!"
                    b "Oh, Kamil... Yes, yes, yes!"
                    o "Ahhh... Kamil.."
                    stop sound
                    "Kamil, utterly spent, collapses onto Banu’s back, his body slick with sweat and trembling from the intense release. "
                    "Orxan, panting heavily, slowly pulls out of Kamil's ass, leaving Kamil and Banu to bask in the afterglow of their shared experience."





    $ renpy.end_replay()
    $ persistent.orxan_threesome_unlocked = True
    jump orxan_threesome_continue








label developed:



    scene black with Dissolve(3)
    ""
    centered "{size=+120}1 year later...{/size}" with Fade(0.5, 0.5, 5)
    scene black with dissolve
    b_ "During this past year, a profound transformation enveloped my life."
    b_ "My relationship with Kamil evolved into a deep, passionate love."
    b_ "He embraced me for who I was, and our bond grew stronger with each passing day."
    b_ "Together, we embarked on exciting adventures, exploring uncharted territories in our marriage to keep the flame of our love alive."
    b_ "We ventured into the world of cam shows, experimenting with various fetishes that added an element of excitement to our intimate moments."
    scene v18-322 with pixellate
    b_ "Amidst our own adventures, the happiness of our family was amplified by Leyla's marriage. "
    b_ "Her visits with her husband became cherished moments, where we all gathered around the kitchen table, sharing laughter and engaging conversations. "
    scene v18-323
    b_ "It was in these moments that I found solace and contentment, realizing the importance of family and the unwavering support we offered one another."
    b_ "In the embrace of Kamil's love and the warmth of our family's happiness, I felt a newfound sense of fulfillment."
    scene v18-324
    b_ "In those joyous moments around the kitchen table, Kamil's laughter echoed through our home."
    b_ "His playful banter with our son-in-law created an atmosphere filled with light-hearted humor."
    b_ "Their jokes and laughter became the melody of our family gatherings, creating bonds of camaraderie and love that felt unbreakable. "
    b_ "Together, we shared smiles and hearty laughs, cherishing the simple yet profound beauty of family togetherness."
    scene black with dissolve
    play music "audio/up.mp3"
    b_ "Kamil and I continued to explore new adventures together, strengthening our bond and love for each other. "
    show banu_undressing_bedroom_animation
    ""
    scene undressing24
    b_ "We discovered our fetishes and we exchanged pleasure while others watching."
    b_ "We also made some money out of it."

    scene v18-325 with irisin
    b_ "We managed to increase our subscribers."
    b_ "We tried different stuff in front of the camera."
    b_ "At first Kamil was against my idea of doing a cam show."
    scene v18-326
    b_ "But later he got used to showing my body off the strangers."
    b_ "He knew that I was an adventurous woman and he was ready to do anything that brought smile to my lips."
    b_ "Our actions in front of the camera got bolder as time passed."
    scene v18-327
    b_ "I remember the intense gaze we shared, Kamil's eyes meeting mine in a moment of unspoken connection."
    b_ "I saw the excitement in his eyes. He enjoyed when other men watched my naked body."
    b_ "He was reading the comments of other men about my body...how my sexy body made their dicks hard."
    b_ "Kamil was a good husband. He understood me. He cared about me."
    scene v18-328
    b_ "It was as if the world around us faded away, leaving only the two of us."
    b_ "We had sex like it was just two of us."
    b_ "We didn't care that people were watching our fucking."
    scene v18-329
    b_ "I discovered Kamil's dirty sides and he discovered mine."
    b_ "Our relationship became more open."
    b_ "He had changed... "
    b_ "His unwavering respect for my boundaries was a testament to his love."
    b_ "In a world that often dictated how I should behave, Kamil stood by me, allowing me the freedom to explore, to be true to myself. "
    b_ "His love was a gentle rebellion against societal norms, and in his arms, I found the strength to embrace my happiness without fear or judgment. With him, I felt truly liberated."
    stop music
    scene black with dissolve
    b_ "We used to come together with our best friends, Polad and Nesrin so often. "
    b_ "It was one of these adventurous days..."
    scene v18-330 with pixellate
    b_ "Sitting around that circular table in the restaurant, we were just having a good time, like any group of friends would."
    b_ "Kamil had become pretty cool about our friendships, so we hung out often with our best pals, Polad and his wife Nesrin."
    scene v18-331
    b_ "We were all cracking jokes, teasing each other like we always did."
    b_ "Polad, the witty one, would say stuff like:"
    b_ "Maybe I'll steal Banu from you, Kamil!"

    b_ "We'd all laugh because we knew he was just messing around."
    b_ "I was never one holding back, so I added, Well, Polad, your charm is hard to resist!"
    scene v18-332
    b_ "Kamil, with a grin, joined in... And Polad, I hope you're keeping an eye on me, or I might run away with your woman!"
    scene v18-333
    b_ "Nesrin, always up for a laugh, fired back... Oh, Kamil, you're no match for me!"
    b_ "Our jokes about each other's personal lives were all in good fun, reflecting the trust and closeness of our friendship."
    scene v18-334
    b_ "Little did we know, beneath the laughter, there was a subtle tension, making us wonder if our playful banter might lead to something more serious."
    b_ "I couldn't ignore the subtle hints that Polad occasionally dropped, his playful winks and lingering glances suggesting a deeper connection."
    scene v18-335
    b_ "In those stolen moments of eye contact, I felt a magnetic pull, a silent conversation passing between us that hinted at something beyond friendship."
    b_ "I found myself captivated by Polad's charm and the way he seemed to see into the depths of my soul."
    b_ "While the jokes continued around the table, I couldn't shake the feeling that there was an unexplored territory between me and Polad, a territory that both intrigued and terrified me."
    scene black with dissolve
    b_ "That night, we all gathered at our place after the restaurant. "
    scene v18-336 with fade
    b_ "Polad, Kamil, Nesrin, and I were in high spirits, laughing and joking around."
    b_ "The atmosphere was light, filled with playful banter."
    b_ "Polad and Kamil lounged on the sofa, and Nesrin and I decided to have some fun."
    scene v18-337
    b_ "We changed into different outfits, showing off our figures, and then sashayed in front of the guys, asking them who looked sexier."
    b_ "The room echoed with laughter and teasing, and I felt a surge of confidence as I embraced my curves."
    b_ "It was all in good fun, but deep down, I sensed an unspoken tension in the air. "
    b_ "Despite the playful facade, there was something more beneath the surface, something that hinted at desires and connections waiting to be explored."
    scene v18-338 with fade
    b_ "My dress flowed around me, embracing my curves in all the right places."
    b_ "Nesrin, always playful, wore a cute mini pink dress that perfectly matched her youthful spirit."
    b_ "As we entered the room, I could see the gleam in the guys' eyes, appreciating our choice of outfits."
    scene v18-339
    b_ "Sitting on the sofa, Polad and Kamil watched us with amused expressions as we showcased our dresses."
    b_ "The atmosphere was charged with playful energy, and our banter only grew more spirited."
    b_ "Little did I know then, these seemingly innocent exchanges were the beginning of a series of events that would change our lives in ways we couldn't yet fathom."
    scene v18-340 with fade
    b_ "Nesrin and I returned again, donned in different yet equally alluring outfits."
    b_ "I opted for a charming mini grey-blue dress, its fabric hugging my figure gracefully. Nesrin, always bold, chose a striking long red dress that accentuated her elegance."
    b_ "We entered the room, our dresses creating an air of sophistication and allure."
    b_ "As we joined the conversation, the playful teasing continued. Kamil and Polad's eyes sparkled with amusement, appreciating our fashion choices."
    scene black with dissolve
    b_ "Ah, those playful nights in our bedroom, they were the moments where Kamil and I let go of all inhibitions and just enjoyed each other's company."
    scene v18-341
    b_ "One particular evening stands out vividly in my memory. "
    b_ "Kamil surprised me by donning a black superhero costume, his playful grin hidden behind a mask."
    scene v18-342
    b_ "I, in turn, slipped into a sleek black catsuit, complete with adorable cat ears."
    b_ "Together, we embraced the fantasy, weaving a tale of passion and excitement in the confines of our intimate space."
    scene v18-343
    b_ "In the dim light, our laughter echoed, mixing with whispers of sweet promises."
    b_ "Kamil and I reveled in the joy of exploring new adventures, both in our relationship and our imaginations. "
    b_ "It was a night of shared fantasies and tender connections, a testament to our love's ability to evolve and flourish, even in the midst of everyday life."
    scene v18-344
    b_ "Oh, that moment was pure magic."
    b_ "Kamil, dressed as my superhero, strong and confident, swept me off my feet—literally."
    b_ "His arms wrapped securely around me, lifting me effortlessly into the air."
    b_ "I felt weightless, suspended between reality and fantasy, my heart racing with exhilaration."
    b_ "In that instant, I wasn't just Banu; I was his damsel, and he was my hero."
    scene v18-345
    b_ "As our playful escapade in the bedroom continued, the superhero costumes were soon forgotten, replaced by the raw, genuine connection between us."
    b_ "Kamil and I embraced each other, our bodies entwined in a dance of passion and intimacy."
    b_ "There were no more masks or disguises, just us, stripped down to our truest selves."
    scene v18-346
    b_ "The room was filled with the soft glow of dim lights, casting a warm ambiance that matched the tenderness of our moments together."
    b_ "We explored each other's desires and dreams, finding solace in the quiet whispers and gentle touches that spoke volumes."
    scene v18-347
    b_ "It was a night of unspoken promises and shared secrets, a night where the world outside our bedroom seemed to vanish, leaving only the profound love we had for each other."
    b_ "In those intimate hours, we found not just pleasure but a deep emotional connection that bound us together, reminding us of the incredible love we shared."
    b_ "Our bodies moved in harmony, a testament to the years of understanding and adoration we had for one another. "
    scene v18-348
    b_ "As the night unfolded, our love story continued, a beautiful narrative written in the language of touch, affection, and trust."
    b_ "As the night deepened, Kamil, my loving and adventurous partner, agreed to fulfill one of my cherished desires. "
    scene v18-349
    b_ "He didn't hesitate at all to lick my shoes."
    b_ "I felt like a mistress and Kamil was my slave."
    b_ "In that moment, I felt an overwhelming gratitude for the man beside me."
    scene v18-350
    b_ "His willingness to indulge my wishes, his eagerness to create special moments together, filled my heart with warmth and love."
    b_ "The night continued with our shared dreams and plans, weaving a tapestry of love and togetherness that made our bond even stronger."
    b_ "Kamil was ready to do anything that I wished."
    scene v18-351
    b_ "It was our first time doing that."
    b_ "I made Kamil bend over on the bed and positioned myself right behind him with my new dick pointing to his asshole."
    b_ "In that time, he was my slave and was ready to accept what I desired."
    scene v18-352
    b_ "I told him to beg me and ask for forgiveness so I might go easy on him."
    b_ "He was begging me calling me mistress and I was insulting him telling him that he was a piece of shit."
    b_ "He was playing his role so good that it was making me hornier."
    b_ "I wanted him to feel my dick in his asshole. I wanted him to feel the pain."
    b_ "I put my fake dick with my right hand and put it into his asshole without warning."
    scene v18-353
    b_ "That was it. I was fucking Kamil's asshole and he was moaning."
    b_ "I noticed his dick getting harder as I fucked him."
    b_ "He was really enjoying it."
    scene v18-354
    b_ "His moaning fueled my energy and I started to fuck him faster."
    b_ "I felt the power of dominating and being in control."
    b_ "I slapped his ass telling him that I was going to destroy his asshole. "
    b_ "I really enjoyed that night with my submissive cute husband."
    b_ "Our adventures continued later with more daring stuff..."





    $ renpy.end_replay()
    $ persistent.developed_unlocked = True












    scene black with Dissolve(3)
    ""
    centered "{size=+120} Open relationship: Banu and Kamil {/size}" with Fade(0.5, 0.5, 5)


    $ kamilletorxantouchbanu = False
    $ banuletorxankissher = False
    $ kamilfightpoladfoursome = False
    $ kamilstopspoladfoursome = False
    $ kamilstopsrina = False
    $ banufucksorxanshower = False
    $ banuletorxanfuckherkamilotherroom = False
    $ kamilletblackmanfuckbanu = False
    $ banutalkstoorxanwhilegettingfucked = False
    $ kamilagreethreesomeorxan = False
    $ orxanfuckskamil = False



    scene black with dissolve
    "..."
    play music "audio/slowsoft.mp3"
    scene v20-210 with pixellate
    "In the photo studio, the atmosphere is a mix of excitement and nervous anticipation."
    "Banu fidgets slightly in her bold red lingerie, while Kamil tries to offer comfort and reassurance."
    "They are waiting for Orxan, the photographer, to set up for the shoot."
    b "I can't believe we're actually doing this. I feel so exposed."
    k "You look stunning, love. And remember, it's just Orxan here, and he's pretty much seen it all, right?"
    b "Yeah, I know. It's just a lot more revealing than I imagined. Do you think this will really help us feel closer?"
    k "Absolutely. It's something new, something adventurous. We're stepping out of our comfort zone together, which is what makes it special. Plus, it's fun, isn't it?"
    scene v20-211
    b "It is a bit thrilling, I guess. I just hope the photos turn out well."
    k "They will. Orxan is amazing at what he does. Just relax and let's enjoy the moment. This is about us being together in a new way."
    b "Okay, I'll try. How do I look?"
    k "Like a goddess. Really, Banu, you're breathtaking."
    scene v20-212
    o "Ready to make some magic happen? Let’s create something beautiful together!"
    o "Banu, you look absolutely fabulous in that outfit. The color is perfect for you. It really makes the shot pop!"
    scene v20-213
    b "Thank you, Orxan. I was a bit nervous about it, but hearing that helps."
    o "It’s normal to feel a bit nervous, but trust me, you’re doing great."
    o "This is all about capturing the chemistry between you two. Think of me as just a fly on the wall."
    b "That’s a funny way to put it, but I guess it does make it seem less intimidating."
    o "Exactly! Let’s not worry too much about the poses. I want to capture the real, spontaneous moments between you and Kamil."
    o "Just interact with each other as you normally would."
    k "Sounds like a plan."
    scene v20-214
    o "Banu, if we weren’t in a shoot, I’d say you could start a whole new career with this look. It's stunning."
    b "Oh, stop it, Orxan. You're just saying that to make me feel comfortable."
    k "Well, it’s working, isn’t it? She’s blushing!"
    o "It’s all in the spirit of making great art. But really, you both make a fantastic couple. "
    b "Well, thanks, Orxan. It’s actually kind of fun, now that I’m getting into it."
    o "That’s the spirit! Let’s keep that energy up. When you two are having fun, it shows, and it makes all the difference in the photos."
    scene black with dissolve
    "This light-hearted exchange helps to keep the mood buoyant and comfortable, ensuring that both Banu and Kamil feel at ease during the shoot."
    scene v20-215 with dissolve
    o "Perfect, just like that. Banu, your hand looks great there—shows just the right amount of connection and intimacy."
    k "Like this? Are we too stiff?"
    o "No, you're doing brilliantly. Just relax into each other a bit more."
    b "Okay, let’s pretend we’re at home, just us."
    k "That’s my favorite place to be."
    o "That’s the spirit! Now, both of you, look at the camera. Imagine it’s a window and you’re showing the world how proud you are to be with each other."
    o "Excellent! Hold that look... And... got it! That’s a beautiful shot."
    o "Alright, this next one, I want to capture a bit of a closer, more intimate vibe. Can you two get your faces closer together? Almost like you're about to kiss."
    scene v20-216
    b "Like this?"
    k "Is this close enough?"
    o "Perfect. Now, just bring your lips closer, just inches apart. Hold that tension, it's incredibly captivating."
    b "This feels like one of those dramatic movie moments."
    scene v20-217
    b "This feels like our first date again, staring into your eyes like there's no one else in the world."
    k "Every time I look at you, it’s like I’m discovering you all over again. You still give me butterflies."
    b "I love that we're doing this, creating new memories together."
    k "Me too. It’s just us here, in this moment. Everything else just disappears."
    o "That was beautiful, you two! Now, let’s try something a bit different. Stand back to back for me, but keep holding hands."
    scene v20-218 with fade
    b "Like this, Orxan?"
    k "Should we look straight at the camera or off to the side?"
    o "Look straight at the camera. I want to see the connection in your eyes, even though you're not facing each other. It’s a powerful stance."
    b "It feels like we're supporting each other."
    k "Because we are, in every shoot and in life."
    o "Exactly! Hold that thought, it translates well into the photo. Alright, ready? Hold that look... and... perfect!"
    scene v20-219 with fade
    o "Great work, both of you. Now, let’s get some solo shots of Banu for the brand. Kamil, you can take a quick break, grab some water, relax a bit."
    k "Alone? Just Banu?"
    o "Yes, just a few individual shots. It's standard for the campaign. Banu, are you ready?"
    b "Um, sure... I guess."
    scene v20-220
    k "Alright, I'll just be over there if you need me."
    b "It’ll be quick, right?"
    o "Absolutely, we’ll make it swift. Banu, just focus on the camera, think about the theme of empowerment and elegance. You’re representing the brand's image."
    b "Okay, I can do that."
    o "Banu, now that it's just you, let's make these shots really shine. You have an amazing presence—trust me, the camera loves you."
    b "Thank you, Orxan. I'll do my best."
    scene v20-221 with fade
    o "That's perfect, Banu! Hold that pose. The confidence in your posture really sells the image."
    b "Like this? Am I holding it right?"
    o "Absolutely, you look powerful, in control. It's exactly what we're going for."
    k "You're doing great, Banu!"
    b "Thanks, love!"
    scene v20-222
    b_ "Orxan’s so close, and I can't help but notice his... well, his pants."
    b_ "It's bulging a bit—am I imagining things? I wonder what he'd do if I just... "
    b_ "What if I did get completely naked? Would he stay professional?"
    b_ "Probably, but there's a hint of curiosity in his eyes. I can feel it. It's kind of thrilling and scary at the same time. Would he be able to keep his composure?"
    b_ "And Kamil—he's watching everything. This whole situation is getting more intense by the second. Why is my mind even going there? "
    o "Can you lift your hands above your head?"
    scene v20-223
    o "Yes, just like that."
    o "Perfect, just like that! Hold it there. You’re doing great. That smile lights up the room!"
    b_ "It's strangely liberating to stand here, to be admired not just by Kamil but also by Orxan, even if it's just in the context of his work."
    b_ "I feel powerful, in control, not just of my body but of the entire room."
    b_ "This isn't just about the physical—it's about expressing a deeper part of who I am. And right now, I feel unstoppable."
    o "Banu, can you turn around for me? We need to get some shots from the back to really show off the detailing and fit of the lingerie."
    scene v20-224
    b "Like this?"
    o "Yes, exactly like that. Hold that position, please."
    b_ "I’m proud of how I look, proud of my body."
    b_ "It's not just about Orxan seeing me; it’s about anyone who will eventually see these photos."
    b_ "And yes, there’s a thrill in knowing I’m admired, that my appearance can command attention."
    "...."
    scene v20-225 with fade
    o "Banu, I need to adjust your pose slightly to capture the right angle. Is it okay if I guide your posture?"
    b "Yes, that’s fine. Just tell me what to do."
    o "I’ll just lightly place my hands to adjust your shoulders and the angle of your hips. Let me know if anything feels uncomfortable."
    scene v20-226
    o "You look so irresistible in that lingerie, Banu. I can't stop thinking about how amazing you would feel under my hands, how your skin must feel like silk..."
    b_ "Oh my god, did he really just say that? I should stop this... but why does it feel so thrilling? This is so wrong, but there's a part of me that's... enjoying the attention."
    o "I bet you taste as good as you look. Imagine us alone, without any of these lights or cameras, just you and me..."
    b_ "This is crossing a line. I know I should stop this, but why am I feeling like this?"
    b_ "Focus, Banu, focus. This is not the time or place."
    k "Everything alright over there?"
    scene v20-227
    k "What exactly is going on here? You mentioned needing to touch her to adjust her pose?"
    o "Yes, sometimes it's necessary to make small adjustments to ensure the pose is perfect for the shot."
    menu:
        "Kamil stops the session":
            $ kamilletorxantouchbanu = False
            $ renpy.block_rollback()
            stop music
            k "I understand professional adjustments, but the way you’ve been speaking to Banu isn’t professional at all. This isn't just about adjusting a pose."
            o "I assure you, my intentions are strictly professional."
            k "No, I think we’ve had enough for today. We're stopping the session."
            b "Kamil, I..."
            k "We don’t have to continue if you’re uncomfortable. This isn’t how it should be."
            b "I agree. Let’s end this for now."
            o "I apologize if I crossed a line. That was not my intention."
            k "We’ll discuss this further, but for now, we're done here."
        "Kamil lets him touch Banu":






            $ kamilletorxantouchbanu = True
            $ renpy.block_rollback()
            stop music
            play music "audio/weakbanu.mp3"
            k "Alright, but keep it professional."
            o "Of course. Banu, could you place one of your knees on the stool and bend over slightly?"
            scene v20-228 with fade
            b "Like this?"
            o "Yes, exactly. Now, hold still."
            o "You have no idea how stunning you look like this, Banu. It’s hard to focus on the work when you're this tempting."
            scene v20-229
            o "Imagine if it was just the two of us, no cameras, no lights. Just you and me, exploring every inch of each other..."
            b "Orxan, I..."
            k "Is everything alright?"
            o "Just making sure she’s comfortable in the pose. Banu, are you okay to continue?"
            b "Yes, I’m fine."
            k "Let's just get this over with quickly."
            scene v20-230
            b_ "I can feel his breath on my neck, his hands on my hips..."
            b_ "I shouldn't be reacting like this, especially with Kamil right here."
            b_ "But my body is betraying me, responding to his touch."
            scene v20-231
            o "You're doing amazing, Banu. This position really highlights your beauty. Just a little more..."
            b_ "His touch is so close... I shouldn't be feeling like this, but it's hard to control. Kamil is right there, and yet, I can't deny the thrill."
            b_ "I can feel him so close, his bulge pressing against me. It's so wrong, but the sensation is electric. "
            b_ "The heat of his body, the firmness... I can't stop thinking about it."
            scene v20-232
            o "Alright, Banu, that’s perfect. Hold that position, and let’s capture some beautiful shots."
            b "Okay, I’m ready."
            o "Just like that. You’re doing great. The camera loves you."
            k "You're amazing, Banu. Just a few more and we'll be done."
            scene v20-233
            o "That’s it, Banu. You look incredible. Every angle, every curve… perfect."
            b "You like what you see, Orxan?"
            o "More than you know. If we were alone, I’d show you exactly how much."
            b "Is that a promise?"
            o "Absolutely. You’re driving me wild, Banu. Can you feel how much I want you?"
            k "What’s going on here? This isn’t what we agreed to. Banu, are you okay?"
            b "Kamil, I’m fine. We’re just getting the shots we need."
            scene v20-234
            o "Kamil, everything is under control. We’re capturing some incredible images. Trust me, this is all part of the process."
            o "Banu, you look so irresistible like this. Every pose, every curve... you’re driving me wild."
            b "You have no idea how much I’m enjoying this. You're making me feel things I shouldn’t."
            o "If it were just us, I’d show you exactly what I mean. I’d make you feel things you’ve never felt before."
            b "Tell me more, Orxan. What would you do to me?"
            o "I’d take my time, exploring every inch of your body. Making sure you feel pleasure you’ve only dreamed of."
            k "What the hell is going on here? This isn’t just a photo shoot anymore!"
            b "Kamil, please, it’s just part of the shoot. We’re capturing the intensity, the passion. It’s all for the photos."
            scene v20-235
            o "You know, Banu, I can’t help but wonder what you’re hiding between those gorgeous legs of yours."
            b "Orxan, we need to keep this professional..."
            k "That’s enough, Orxan. This isn’t part of the job."
            o "We’re almost done, Kamil. Just a few more shots."
            b "This is so inappropriate... but I can’t deny how it’s making me feel."
            o "Why don’t you show me, Banu? Let’s capture that raw, untamed beauty."
            scene v20-236
            b "Like this?"
            k "Banu, are you sure about this?"
            o "You’re stunning, Banu. This is going to be the shot of the session."
            b "Let’s do it. Let’s get the shot."
            k "Banu, if this is what you want, I’m here for you. But this needs to be the last one."
            o "Understood. This will be the last one. Banu, you’re incredible. Hold that pose."
            b_ "I can’t believe I’m doing this. The way Orxan is looking at me... it's driving me wild."
            b_ "This is so risky, so daring, but I can’t stop. The thrill of being so exposed, so vulnerable, and yet so powerful, it’s intoxicating. Orxan's words, his gaze, they’re setting me on fire."
            b_ "Kamil is right there, and he has no idea how much this is turning me on. I’ve never felt so alive, so bold. "
            b_ "I want Orxan to see everything, to know how much I’m enjoying this."
            b_ "But I also know this is dangerous territory. I need to keep control, even as my body screams for more."
            stop music
            scene v20-237
            k "Well, that was certainly an intense session. I hope the photos turn out well."
            o "Oh, they will. Banu was amazing. She really knows how to captivate the camera."
            b "It helps when you have a great photographer. You really know how to bring out the best in me, Orxan."
            o "I’m just doing my job. But with someone like you, it’s hard not to get inspired."
            k "Yeah, well, let’s remember to keep things professional."
            b "Of course, Kamil. Just having a bit of fun. Right, Orxan?"
            o "Absolutely. It’s all part of the creative process."







    scene black with dissolve

    b_ "I’ve never felt this level of excitement, this raw desire. "




    jump banu_naked_photo_orxan







label banu_naked_photo_orxan_continue:

    play music "audio/romantic.mp3"
    scene black with dissolve
    "As Banu and Kamil lie in bed together, the soft glow of the bedside lamp casting a warm light on their faces, they turn to each other, ready to discuss their plans for tomorrow."
    scene v20-269 with dissolve
    k "So, tomorrow is the big day. How are you feeling about it?"
    b "I'm a little nervous, to be honest."
    b "But also excited. It's something new for us, and it could really bring us closer together. What about you?"
    k "Same here. It's uncharted territory, but I trust Polad and Nesrin."
    k "They're good friends and we've talked about this for a while now. It feels right to take this step with them."
    b "Polad is such a strong, confident guy. "
    b "Running a pub must give him so many interesting stories."
    b "And Nesrin, she's so sweet and caring. I think their dynamic will complement ours well."
    scene v20-270
    k "Yeah, Polad is definitely a tough guy. I admire his confidence."
    k "And Nesrin, with her gentle nature, she's like the perfect balance. Do you think they'll feel the same way about us?"
    b "I hope so. I think we bring something unique to the table too."
    b "Plus, we all get along so well as friends. This could really add a new dimension to our relationships."
    k "It's important that we go into this with clear boundaries and communication. "
    k "We need to be honest with each other about our feelings every step of the way."
    b "Absolutely. Trust and communication are key. If at any point either of us feels uncomfortable, we need to speak up."
    b "This is about enhancing our relationship, not causing strain."
    k "Agreed. I think tomorrow will be an incredible experience for all of us."
    b "I love you, Kamil. Thank you for being so open and supportive about this."
    k "I love you too, Banu. We're in this together, always. Now, let's get some rest. Tomorrow is going to be a big day."
    stop music



    jump polad_nesrin_foursome




label polad_nesrin_foursome_continue:






    jump rina_cuckolding_kamil




label rina_cuckolding_kamil_continue:

    scene black with dissolve
    "..."
    "A few days later, Kamil found himself sitting alone in the kitchen late at night, sipping on a glass of water."
    scene v20-423 with dissolve
    "The house was quiet, the only sound the gentle hum of the refrigerator."
    "His mind wandered to the photo shoot planned for the next day, a complex blend of excitement, anxiety, and curiosity filling his thoughts."
    k_ "Tomorrow is going to be intense. Banu as a hijab-wearing housewife... the contrast of her character’s modesty with the bold, forbidden affair."
    k_ "Orxan will surely push our boundaries again."
    k_ "I wonder how it will feel to watch Banu play this role. The hijab, the modesty... and then the stark contrast with the affair."
    scene v20-424 with fade
    k "Banu..."
    "Banu smiled seductively, her eyes locked onto his. She walked slowly toward him, her hips swaying with each step."
    "When she reached him, she placed her hands on his topless back, her touch gentle and teasing."




    jump banu_blackman_play


label banu_blackman_play_continue:

    scene black with dissolve
    "..."
    "A few days after the intense shoot, Kamil, Banu, and Orxan found themselves relaxing in Kamil and Banu's apartment."
    "The atmosphere was relaxed, filled with the hum of casual conversation and the clinking of beer bottles. "
    scene v20-469 with dissolve
    "They sat around the kitchen table, enjoying each other's company and the familiarity that had grown between them."
    k "You know, Orxan, I never thought we'd end up doing something like that. It was intense."
    o "You both handled it like pros. I have to say, it was one of the most unforgettable shoots I've done."
    scene v20-470
    b "What are you two talking about?"
    k "Just talking about the shoot. Orxan was saying how unforgettable it was."
    b "It was definitely intense. But I'm glad we did it."


    jump orxan_threesome


label orxan_threesome_continue:




    dev "{color=#000000}Thank you for playing! This is the end of this route in this version. Play again to discover more. If you enjoyed it, please {a=https://www.patreon.com/lustfulfantasy}support{/a} the development. Buy the full game(Early Access) on {a=https://store.steampowered.com/app/2505580/Life_in_Middle_East/}STEAM{/a} {/color}"
    hide screen faith
    hide screen angeldevil
    jump endings
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
