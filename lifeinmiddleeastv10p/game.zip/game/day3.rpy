



label day3:
    show black
    centered "{size=+150}DAY 3{/size}" with dissolve
    scene black with dissolve
    with Pause(1)
    scene day3-1 with fade
    "..."
    scene day3-2 with dissolve
    "{i} {color=#526168}Banu woke up early today. {/color} "
    "{i} {color=#526168}As she rolled over in her bed, she considered skipping work. She wondered if she could manage it and actually ask for a day to herself for once in her life. {/color} "
    "{i} {color=#526168}She watched Kamil sleep for some time, rolling towards him as she did. He looked so peaceful, like he didn’t have a care in the world. {/color}"
    b "{i} {color=#526168}Another stressful day awaits me.{/color} "
    b "{i} {color=#526168}I’ve never wanted to stay in bed more than now, but I need to leave. I have some stuff I need to purchase before work.{/color} "
    scene day3-3
    "{i} {color=#526168}She got up immediately and headed towards the kitchen. {/color} "
    scene black
    with Pause(1)
    show black
    centered "{size=+150}At work{/size}" with dissolve
    scene day3-4 with irisout
    play music3 "sfx/office.mp3"
    b "{i} {color=#526168}I’m sure Turan will talk to me about those new interns.{/color} "



    b "{i} {color=#526168}They can be a pain in the neck sometimes.{/color} "

    b "{i} {color=#526168}I’m really not in the mood to deal with them, but I’ll probably have to, whether I like it or not. {/color} "

    scene day3-5
    a "Why is Banu always late? Do you really think this is how an employee should act? She should be fired for being so incompetent. I bet she thinks it makes her look important. "
    t "Aydan, just shut up."
    t "We both know you have something against Banu. Enough, I don’t want to have any more conflict between the two of you. "
    scene day3-6
    a "Look who finally decided to show up."
    b "{i} {color=#526168}I’m not replying to her snooty comment. I don’t like her at all.{/color} "
    b "{i} {color=#526168}I know she’s jealous of me. I have morals and self-respect, something she wishes she had.{/color} "


    t "Aydan, you can leave now."
    t "Please begin doing the tasks I’ve assigned to you. They’re urgent. You don’t want to get on the manager’s bad side."

    a "No worries. I’ll get it done."
    scene day3-7
    a "I'll contact you if I have any problems."
    b "{i} {color=#526168}Did she just wink at him?{/color} "


    scene day3-8
    t "Sure. Get to it."
    "{i} {color=#526168}Refusing to get Banu anymore acknowledgement, Aydan left without saying anything else.{/color}"
    if banu_turan == 1:
        b "{i} {color=#526168}Turan looks suspicious. Is there something going on there? I wonder if he invites Aydan to spend time with him after work like he does me?{/color} "




    scene day3-9
    t "So, tell me, Banu. How are you today?"
    scene day3-10
    b "Thank you, Turan. I’m fine."
    scene day3-12
    t "You know I have to pester you about the new interns. The manager wants you to work with them, to teach them what you know."
    scene day3-10
    b "Yeah, sure."
    scene day3-12
    t "Three senior students are going to get internships with our company: 1 boy and 2 girls. You’ll work with the boy. "

    t "Your task is to give him assignments like searching and finding materials, or you can just ask him to help you in preparing and translating documents. "
    if turandate == False:
        scene day3-11
        b "Okay, Turan. I got it. I've worked with interns before. "
        b "It's tiring to work with them, but I can do that. "
        b "{i} {color=#526168}It’s not much different than babysitting, actually. {/color} "



        scene day3-12
        t "Great. I believe that you won't let me down."
        scene day3-13
        b "You know me, Turan. Have I ever let you down?"
        t "{i} {color=#526168}She is a fantastic woman. {/color}"
        stop music3
    if turandate == True:

        scene day3-11
        b "I don't get it. There are a bunch of useless workers here, who don’t do anything except for chat up each other at the water dispenser. But of course, being the busiest person here, I’m expected to babysit them. "
        t "It’s just two months, Banu. Why get upset over it? "
        scene day3-12
        b "It's just unfair."
        b "Anyways, I'm leaving."
        scene day3-14
        t "I know why you're angry. Just listen to me. I didn't have any bad intentions that night. I just can’t hold myself back when I’m around you. I’m sorry, I really am."
        t "You know that I have feelings for you."
        menu:
            "She asks what’s going on between Aydan and him. ":

                $ renpy.block_rollback()
                $ banubad += 1
                $ banu_turan += 1
                scene day3-15
                b "Is that what you say to Aydan too?"

                t "I don't know what you’re talking about."

                b "Of course, you do."
                t "What?"
                scene day3-16
                b "What’s between you and Aydan?"

                t "That’s bothering you, isn’t it?"

                b "What? Of course not."
                b "{i} {color=#526168}Actually, it does bother me. I thought I’ve always been his favorite employee, but maybe I’m no different than her.{/color}"

                t "You can't hide it. Tell me. Are you jealous?"
                b "What? Are you nuts? I’m a married woman. How can you think like that?"

                t "You sure? I know your pussy was wet for me the other night."
                b "Now you’re really crazy."
                b "{i} {color=#526168}Ugh, the jerk had to bring that up, didn’t he? I’m so embarrassed.{/color}"
                t "Come on, Banu, I know you want it. Come to my apartment tonight to finish what we started."
                b "Never again. Look, I don't want to talk about this anymore."
                b "I’m willing to forget about what happened at your apartment, as long as you behave from here on. Otherwise, I’ll have to report you."
                b "{i} {color=#526168}I should’ve already reported him! He nearly raped me. But then Kamil would find out what happened, and he may not handle it well.{/color}"




                scene day3-17
                "{i} {color=#526168}She left without waiting for a reply from Turan...{/color}"
                t "{i} {color=#526168}You’ll give me that tight ass of yours, Banu. Just wait.{/color}"
                stop music3
            "She gets angry and leaves.":

                $ banu_turan += 1


                $ renpy.block_rollback()
                scene day3-16
                b "How can you tell me that? You know that I’m married!"
                t "Banu..."
                b "I don't want to hear anything more from you!"
                b "I’m willing to forget about what happened at your apartment, as long as you behave from here on. Otherwise, I’ll have to report you!"
                b "{i} {color=#526168}I should’ve already reported him! He nearly raped me. But then Kamil would find out what happened, and he may not handle it well.{/color}"

                scene day3-17
                "{i} {color=#526168}She left without waiting a reply from Turan...{/color}"
                stop music3






    scene black
    play music3 "sfx/school.mp3"
    "..."
    scene day3-18 with fade
    ays "Look, he's already waiting for us."
    l "I don't think I'm ready to meet your male friends."
    ays "Don't be afraid, Leyla. He doesn't bite."
    scene day3-19
    ays "He's kind and has a good sense of humor. You will get on well with him."
    l "Well, if you say so..."
    scene day3-20
    ays "How are you Mehti? Give me a hug."
    m "Life has no meaning without you, Princess."
    scene day3-21
    m "She is damn beautiful, Aysel. What’s your name, pretty?"
    l "I am Leyla.."
    m "And my name is Maga. It’s actually Mehti, but people simply call me Maga."
    l "Nice to meet you."
    ays "So, what are we doing today?"
    scene day3-22
    m "Maybe we can go to my place."
    ays "Hey, we're not going to go to your place, and take your hand off my ass."
    scene day3-23
    m "I thought you want to do it again after that 'hot' night."
    ays "Maybe.."
    ays "But, we're forgetting our friend, Leyla."
    scene day3-24
    m "I see she's a little bit introverted, but I don't think she'll say no to some good wine."
    l "Guys, I'm not into drinking so much, and I have to wake up early tomorrow to finish my essay."
    ays "Don't be so childish, Leyla. Your lesson tomorrow isn’t until the afternoon, you’ll have time until then."
    ays "I think you’re playing innocent, Leyla. I know you have some naughty experiences to share with us. Let’s chat. Spend some time with us."
    m "You know whisky helps a lot to let off some steam."

    menu:
        "Leyla is so tired and has zero desire to go anywhere":
            $ renpy.block_rollback()
            $ threesome = False
            scene day3-24
            l "Guys, I'm so sorry, but I have to go home early tonight."
            ays "As you wish, Leyla. See you tomorrow then."
            l "See you, guys."
            m "Take care, Leyla."
            l "You too, Maga. Bye. Nice meeting you."
            scene day3-25
            ays "So, you’ll buy me drinks to get me drunk and fuck me all night long at your place?"

            m "Oh, you are so quick-witted."
            m "Let's go to Mojo first, our usual place."
            ays "How could I say no to such an offer?"
            stop music3
        "Leyla is excited about the upcoming adventure":


            $ renpy.block_rollback()
            $ threesome = True
            scene day3-24
            l "You’ve convinced me. Let’s do it."
            ays "That's my girl.."
            ays "So.."
            m "Let's go to our usual place. What do you say?"
            ays "Nice idea. Let's go."
            stop music3




    scene black
    "..."
    scene day3-80 with wiperight
    play music3 "sfx/office.mp3"

    b "Follow me, clever boy."
    b "We have a lot to go over today."
    sam "Is it obligatory to come to the office every working day, Mrs. Banu?"
    b "Of course, it's obligatory. Remember, you're an official intern here."
    scene day3-81
    sam "I mean, if I finish the work you give me quickly and send it to your email, what's the point of coming to office?"
    b "You seem to be a lazy one. What you're proposing is impossible. We check interns' attendance every week, so we need to know which days you're here exactly. So, forget about that idea."

    sam "I have to work the same amount of hours as other workers, but I won't get a penny. Good."
    b "It's a part of your education. So, don't complain anymore."
    b "Now sit here and listen carefully.."
    scene day3-83
    b "You'll deliver the work I give you on time. Remember, I'm your only boss here. It means I'm responsible for you here. So, don't take the tasks I give you lightly."
    scene day3-84
    sam "{i} {color=#526168}I don't know if I'm lucky to be working with her or not, but she's so hot and I love looking down her top. {/color} "

    b "Are you listening carefully?"
    sam "Yes, Mrs. Banu."
    b "Good. For today you will do a search on the Universities which require a minimum of 6 IELTS band score for student admission."
    b "If you have any questions, you can ask me anytime."
    sam "Okay, Mrs. Banu."
    scene day3-85
    b "{i} {color=#526168}Hello? Yes, I am listening...{/color} "
    sam "{i} {color=#526168}Look at the shape of her body... {/color}"
    sam "{i} {color=#526168}Her husband must be a very happy man.. {/color}"
    scene black
    stop music3
    ".."
    if threesome == False:
        play music3 "sfx/bar.mp3"


        scene day3-26 with blinds
        m "Tell me the truth. Did you meet with him again?"
        ays "Who do you mean?"
        m "That stupid boyfriend of yours. "
        scene day3-27
        ays "Do you think he had a chance with me?"
        ays "Yes I gave him a chance for a short time, but he was stupid as fuck."
        ays " He also had a small dick, and you know I don’t have time for men like that."
        m "Did he fuck you from behind?"
        ays "Of course not.."
        ays "I didn't even let him touch me."
        scene day3-28
        m "How long are you planning to stay a virgin?"
        ays "I'm going to lose my virginity only after marriage. You know that we're living in the East. Girls can't do that before marriage. My parents would kill me."
        ays "Do you know what will happen if my future husband finds out that I'm not a virgin?"
        scene day3-29
        m "Well, it's not written on your ID, right?"
        ays "How many times have you fucked me in the ass? Why do you complain?"
        ays "After marriage, I'll not be able to hang out with you. So, you better fuck my ass as long as you can."



        m "Then what are we waiting for?"
        stop music3

        scene black
        play music "audio/chill.mp3"
        "..."
        scene day3-36 with hpunch
        ays "You're the hottest guy I've ever met. I can't describe this feeling, but you attract me so much."
        ays "Let's get rid of your clothes now."
        scene day3-37
        m "You look so sexy with only your top on."
        ays "My body is yours now."
        ays "I want to lick every inch of your body so badly."
        stop music
        show bj1
        play music2 "voices/bj.mp3"
        m "You're so good at this. You know that?"
        m "Suck my fat veiny cock, my slut.."
        ays "mmm..."
        stop music2
        hide bj1
        scene day3-38
        m "All I want now is to destroy your little cute ass."
        m "I know that your ass needs it."
        m "That little guy with a small dick can't give you this satisfaction."
        m "I want to fuck you doggy style on the bed."
        scene day3-39
        m "Yeah, like that. Good girl."
        ays "Just be gentle. Your cock is so big and it always hurts at first."
        scene day3-40
        m "Don't worry. I'm gonna treat your body how it needs to be treated.."
        ays "Ohh, I'm going to cum if you just keep teasing me like that."
        m "Do you want it inside you?"
        ays "Yes, I want it. Please, put it in slowly.."
        m "If you want it, take it.."
        show ayselfuckanimation
        play music2 "voices/slappingsex.mp3"
        ays "Ohh, it feels so good."
        ays "Yeah, keep going like that. My ass needs it. Ohh"
        ays "I'm going to cum from you fucking my ass. Ohh, shit..I'm cumminggg...ohhhh."
        play sound "voices/orgasm1.mp3"
        m "Yeah, enjoy it, little bitch. Enjoy my cock as long as you want.."
        stop music2
        hide ayselfuckanimation
        scene day3-41
        ays "Your balls slap my pussy so good..ohh"
        m "Put your hand like that bitch. I'm going to destroy your ass now."
        ays "Yeah, destroy my ass. Nobody has fucked my ass like you have..ahh"
        m "I'm going to cum..."
        menu:
            "Cum on her face":
                $ renpy.block_rollback()
                play sound "voices/maleorgasm.mp3"
                scene day3-43
                ays "Ohh, you came so much, baby."
                stop sound
                m "You look even prettier with my cum on your face hehe."
                ays "..."
                scene day3-44
                ays "What? Don’t want to kiss me with your cum on my face?"
                m "You know that I'm not so into kissing..."
                ays "Asshole."
            "Cum on her ass":

                $ renpy.block_rollback()
                play sound "voices/maleorgasm.mp3"
                scene day3-42
                ays "Ohh yeeesss, shower me with your cum.."
                stop sound
                m "Damn girl, look at how your ass is gaped..Can't you close it?"
                ays " It's because of your fat cock."
                "..."
                scene day3-45
                ays "Don't you feel sorry for my future husband that he's never going to fuck me as good as you just did?"

                m "You're such a dirty girl."
                "..."
        stop music
    if threesome == True:
        jump leyla_threesome





















































































































    label day3continue:
        scene day3-55 with Dissolve(3)
        play music3 "sfx/frying.wav"
        n "You know, it's very kind of you to come and help me with some of my chores."
        n "Sometimes I feel so alone and helpless. Polad works till midnight. So, I usually kill time by watching Netflix. "
        b "That is why friends exist."
        scene day3-56
        n "Tell me, how's it going between you and Kamil?"
        b "Nothing new to report yet."
        n "Maybe, you're hiding something.."
        b "What are you talking about?"
        n "Look, you can tell me everything. Does he have problems in bed? I mean...maybe, he can't get it up. Nowadays they cure everything. You don't need to be shy."
        scene day3-57
        b "Can you please stop that nonsense, Nesrin?"
        b "It's not about him. It's about me."
        n "I'm just saying."
        n "Then, tell me, how do you keep yourself happy? With your hands?"
        b "Nesrin, please, stop that. I'm embarrassed now."
        n "Don't be shy around me. You're 36 and alive. You need to have sex, and who better to do it than your own husband."
        n "Let me tell you a secret..."
        scene day3-58

        n "I had five hard orgasms last night. I was covered in sweat."
        b "God, Nesrin, stop telling me that... "
        n "Oh Banu, you’re no fun. "



        n "I’m going to go change my clothes, so come hang out for a bit. "
        b "Okay.."
        scene day3-59
        "{i} {color=#526168}Nesrin knew that Banu gets aroused talking about sex, but her intention for getting Banu worked up was unclear..{/color} "

        b "{i} {color=#526168}I’m so turned on. Nesrin caused it. {/color}"
        b "{i} {color=#526168}The way she talks about sex and orgasms impacts me. {/color}"
        b "{i} {color=#526168}I think she just invited me to come hang out with her, but if she’s changing that would be inappropriate. {/color}"



        b "{i} {color=#526168}But, something inside me is urging me to follow Nesrin.{/color} "
        scene day3-60 with squares
        stop music3
        b "{i} {color=#526168}I don’t think she notices me while she looks at the mirror. {/color}"


        scene day3-61
        b "{i} {color=#526168}I shouldn’t be watching her undress, but I can’t help admiring her beautiful curves.{/color}"

        scene day3-62
        b "{i} {color=#526168}Her naked body, curves and beautiful legs are turning me on so bad.. {/color}"
        b "{i} {color=#526168}At that moment, I want to touch myself, but I have to curb this desire inside me. {/color}"
        scene day3-63
        b "{i} {color=#526168}It's sexy how she's slowly touching her belly and breasts while watching herself in the mirror. {/color}"
        b "{i} {color=#526168}She's so hot.. {/color}"
        scene day3-64 with hpunch

        b "{i} {color=#526168}Why am I just standing here?{/color}"

        b "{i} {color=#526168}Luckily, she doesn’t notice me. {/color}"
        b "{i} {color=#526168}Or maybe she does and is putting on the show for me to enjoy. {/color}"
        b "{i} {color=#526168}I have to leave immediately...{/color} "
        scene black
        "..."
        scene day3-65 with Dissolve(2)
        "{i} {color=#526168}Banu was alone and bored at home after her exciting visit to Nesrin’s house. Ruslan and Leyla were out with friends. Kamil was still at work.{/color} "

        "{i} {color=#526168}It was raining outside, so Banu couldn't go out to explore the city as she had planned. {/color}"

        "{i} {color=#526168}She changed into a comfortable outfit and watched TV for some time when suddenly... {/color}"

        play sound "voices/doorbell.mp3"
        scene day3-66 with dissolve
        b "{i} {color=#526168}I'm not expecting anyone.. {/color}"
        b "..."
        scene day3-67 with squares
        play sound "voices/dooropen.wav"
        $ poladinvitehome = False
        b "Oh, it's you. Hi, how are you, Polad?"
        p "What's up, Banu?"
        b "Thanks. I'm doing fine."
        p "I was shopping nearby, and since it’s pouring, I decided to come visit you."
        p "Is your husband at home?"
        menu:
            "She decides to invite him inside for some tea":
                $ poladinvitehome = True


                $ renpy.block_rollback()
                $ lust += 1
                $ banubad += 1
                $ banu_polad += 1
                scene day3-67
                b "No. He's still at work. I'm alone actually."
                b "Don't worry. Come inside."
                scene day3-69
                p "I wouldn't want to cause any problems for you."
                b "No. Don't worry about that."


                scene day3-70
                b "You're wet. Take your t-shirt off. I'll dry it for you. "
                p "Yeah, I got really wet outside."
                b "You should take care of yourself better! Let me get you some tea."
                scene day3-71
                p "Thank you so much for all of this, Banu."
                b "Not at all, Polad."
                b "Do you prefer green tea or black tea?"
                p "Black if possible."
                b "Sure.."
                scene day3-72
                play sound "voices/pouring.mp3"
                "..."
                b "{i} {color=#526168}Polad is so fit. Nesrin and him are a gorgeous couple.{/color} "
                b "{i} {color=#526168}I probably shouldn’t have let him in, but I owe him so much and he’s my link to Alper.{/color} "



                "....."
                scene day3-73
                p "Do you need any help with that?"
                b "Oh, you startled me! No. Thank you. I’m good."

                scene day3-74
                p "How’s life going since we last spoke? Tell me about it."

                b "Well, you know, it’s going as usual. I visited Nesrin at your house earlier today."

                p "Is something going on with you?"

                b "What do you mean?"
                scene day3-75
                p "You don't seem to be happy at all. It’s as if something is bothering you. I can read you clearly, Banu, after knowing you all these years. "

                b "You are so confident."
                p "Do you like that in men?"
                b "I do."
                p "But your husband isn’t a confident man. I’m sure that he’s not treating you right. Anyone can see that you’re not happy with him."

                scene day3-76
                b "Why are you relating my unhappiness to him?"

                p " Anyone can see when a woman is satisfied in her own marriage."
                scene day3-77
                p "I can only see sadness in your eyes."
                b "Maybe one day this sadness will turn into happiness..."
                b "{i} {color=#526168}My heart is racing now that he’s so close to me.{/color} "
                b "{i} {color=#526168}He’s being too bold. What’s gotten into him?{/color} "
                b "{i} {color=#526168}I need to not look at his chest right now!{/color} "





                scene day3-78
                p "You don't need to be shy.."
                b "About?"
                p "About me being naked around you. "
                p "I see you are not ignoring my muscles. You can go ahead and touch them."

                b "I think it's time for you to go. Kamil can come in any minute and it won't end up well."
                b "I'll get your t-shirt now."
                stop music
                scene day3-79
                "...."
                "..."
            "She decides not to invite him inside since she’s home alone":









                $ poladinvitehome = False
                $ renpy.block_rollback()
                scene day3-67
                b "No. Actually, I’m alone at home."


                p "I see.."
                b "It's very nice of you to visit us, Polad."
                b "Maybe, you can come another time when Kamil is at home."
                p "Sure.."
                b " I hope it doesn’t come off as rude, you know how it is."
                p "Of course, I understand that. I just wanted to say hello."
                p "Then, see you, Banu. Take care."
                b "See you, Polad."
                scene day3-68
                b "{i} {color=#526168}I felt sorry for not inviting him inside.{/color} "
                b "{i} {color=#526168}But, there was also a feeling deep inside of me that I did the right thing... {/color}"







        scene day3-86 with Dissolve(2)
        "{i} {color=#526168}Banu's head was full of tiring and uncertain thoughts... {/color}"
        stop music
        "...."
        if streetguys == True:
            play music "audio/tension.mp3"


            scene day3-88 with Pixellate(3, 5)
            "..."
            scene day3-89
            b "No."
            b "Stop it..."
            scene day3-90
            b "Please, let me go..."
            b "NO"
            stop music
            scene day3-87 with hpunch
            b "..."
            "..."


        jump day4

label leyla_threesome:
    play music3 "sfx/bar.mp3"
    scene day3-30 with blinds
    ays "I don't know if it's the effect of whisky, but you look so sexy today."
    m "You always liked me. Especially, in bed. "
    ays "I have to agree with him, Leyla. He is really good in bed."
    l "What? You didn't tell me that you're not a virgin."
    ays "I'm a virgin. I only let him use my back door."
    scene day3-33
    ays "What about you, Leyla? Come on, tell us your dirty secrets..We are open-minded people."
    l "Well, my classmate fucked me in the ass."
    ays "OOO.."
    m "Come on, tell us the details."
    scene day3-32
    l "I don't like to get into details..."
    l "But he was a kind and nice guy, and I believed that I loved him. There was only kissing between us at first."

    l "One day, he seduced me at school. I was so horny, so I offered my ass to him. He fucked me in the men's toilets."
    scene day3-31
    l "But, later, it turned out that the feeling of love was fake."
    l "Well, I think that is all you need to know."
    ays "You see, Maga? She wasn't an innocent girl at school hehe."
    m "Maybe not, but I'm sure that you're also virgin like Aysel."

    l "Yes, I am."
    m "Like I said."
    scene black
    "{i} After a few shots... "
    scene day3-34
    l "Look at these hot guys. They've been staring at me for half an hour."
    ays "Leyla, please, shut up."
    m "Girls, calm down.."
    scene day3-35
    l "She told me that you have a big dick. Is that true, big man?"
    m "Do you want to find out yourself? I'm sure that your ass needs a good treatment since you last got fucked."
    ays "Guys, please, better not do this here."
    l "Yes, I want to see it."
    m "My place then..."
    play music "audio/chill.mp3"
    stop music3

    scene black
    "..."
    scene day3-46 with hpunch
    ays "Do you see that big cock? What do you want to do with it?"
    l "Wow, it's so fat and veiny. I've never seen a cock this size before."
    l "Give it to me. Put it in my mouth. I can't wait."
    scene day3-47
    m "Shit, she's choking on it."
    ays "I see that she's enjoying it. She'll cum soon by just sucking it."
    m "Come here.."
    scene day3-48
    m "Do you know what I'll do to your ass in seconds?"
    l "Yes, you'll destroy my little asshole."
    m "Good girl.."
    scene day3-49
    m "Now you'll do exactly what I say."
    l "Tell me, baby. And it’s done."
    m "I like an obedient slut. Now get on all fours in bed and show me that ass."
    scene day3-50
    stop music
    ays "Enjoy his dick until I come back and take him only for me."
    m "Do you like the tip of my cock rubbing your pussy like that?"
    l "Please, don't do this to me. Put it in my ass. I need it. Pleaseee."
    show leylafuckanimation
    play music2 "voices/slappingsex.mp3"
    m "Ohh fuck...your ass is so tight, Leyla."
    l "Yesss, keep fucking my asshole like that...ohh shit I'm cumming..."
    m "You're already cumming, dirty slut? Enjoying my cock like that?"
    m "Take it..."
    l "Ohh, it feels so good. Don't stop..ohh.."
    hide leylafuckanimation
    stop music2
    scene day3-51
    l "Ohh, I came so hard.."
    l "I've never been fucked like that..shit.."
    ays "Now I'll offer you something to compare to, Maga."
    m "Come here and raise your legs, bitch."
    scene day3-52
    play music2 "voices/threesome.mp3"
    ays "Ahh, yess, don't be too rough. It hurts ahhh.."
    m "You will get used to it, bitch."
    l "Yes, fuck her harder.. ohh I'll cum again..ahhhhh.."
    m "I am going to cum..."
    stop music2
    menu:
        "Cover their faces":
            $ renpy.block_rollback()
            play sound "voices/maleorgasm.mp3"
            scene day3-53
            m "Ohh yesss, take it, you little whores."
            stop sound
            m "Take a shower with my cum and go to your families, whores..."
            "..."
        "Cum on their asses":



            $ renpy.block_rollback()
            play sound "voices/maleorgasm.mp3"
            scene day3-54
            m "Fuck yeah, take my cum into your gaped assholes, you whores.. "
            stop sound
            ays "Oh yeah, it feels really good.."
            m "I bet you won't be able to sit for days."
            "..."




    stop music

    scene black

    "..."
    $ renpy.end_replay()
    $ persistent.leyla_threesome_unlocked_1 = True
    jump day3continue
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
