

















label v8:


    $ banukamilsex = 0
    $ banusticksupforkamilandstormoufofkitchen = False
    $ banuflirtsbacktoabdul = False
    $ banuslapsabdul = False
    $ banufeelsbadforkamil = False
    $ banuaskskamiltodobetter = False
    $ banuthreatenruslan = False
    $ banuasksruslanwhathewants = False













    if banukamilbedroomchoicesblabla == 2:
        $ banukamilsex += 1

    if humiliatingseyhun == True:
        $ banu_polad += 1

    if dinnerreddress == True:
        $ banu_polad += 1


    if banuturansexfirsttime == True:
        $ banu_turan += 1







    scene black with dissolve
    centered "{size=+120}The next day after work...{/size}" with blinds
    scene v8-28 with zoomin
    play music3 "sfx/store.mp3"
    "It wasn't a bad idea to do a bit window-shopping after work."
    scene v8-29
    b_ "Hicran has such beautiful clothes, and she recommended this store. She’s correct, they have lovely dresses here."
    b_ "Some of these are quite bold though. I’m not used to wearing shorter dresses, and I’m not sure Kamil would approve."
    scene v8-30
    b_ "My thoughts always go to Kamil and our complicated relationship. We have the house to ourselves tonight, so I want to focus on just the two of us when I get home. "
    b_ "I keep saying I’ll work harder on our relationship, but something always gets in the way. This time I will give him all my attention and we will have a romantic evening together."
    b_ "I just wish I didn’t have to walk home from here… this store is far. I want to get home early to spend more time with him, but that’s probably not realistic by walking."

    scene v8-31 with dissolve

    mur_ " Look who do we have here. It’s wrong to follow this woman, but I can’t get her out of my mind. "

    mur_ "Sometimes I think she just wears hijab to hide her true herself. There must be something lurking beneath her appearance... a wild woman."

    mur_ "I’m determined to find out, but I should play safe. "

    scene v8-32 with hpunch

    mur "Excuse me, are you looking for a sale? "

    b "Wha-… oh, Murat! You startled me. What are you doing here? This is a female store."

    mur "Part of my job requires me to keep up with the latest fashion trends for women."

    mur "I wanted to make you laugh because you have such a great smile."

    b "Oh, right. Well, that was the silliest pickup line I’ve ever heard."

    mur "I’m surprised you’d be shopping here, as a conservative woman who wears dresses and hijabs."

    b "I was just… looking. I’m not buying anything."

    mur "You left me wanting to spend more time with you."

    scene v8-33

    b "I think you know why I can’t do that. I’m a married woman."

    mur "I’m merely a journalist doing my job."

    b "Your job requires you to try to seduce married women? You didn’t sound interested in anything else."

    mur "I didn’t plan to seduce you, but I was enchanted by your beauty and couldn’t help it. But let’s not dwell on that."

    scene v8-34

    mur "How about we go have a cup of coffee together? "

    b "I should’ve expected you’d ask me this. I’m sorry, but I have to go home. I’m already late enough, and I have to walk home."

    mur "How about a ride home instead of coffee? No funny business, I’m just a nice guy giving his friend a ride home."

    b_ "I know he’s a wolf in sheep’s clothing, but for some reason I trust he won’t mistreat me. I could really use a ride."

    b "No funny business."

    mur "You have my word."

    b "Ok then… let’s go."

    stop music3

    scene v8-35 with blinds

    play music "audio/sensual.mp3"

    mur "I promise you I won’t bite. You don’t have to sit back there."

    scene v8-36

    b "After what happened last time, I’d be a fool to sit next to you."

    scene v8-37

    mur "It’s ok, I have an easier time seeing your beautiful face in the mirror now. So tell me, Banu, how are things going with your husband and you?"

    b "Things are fine. Why would you ask such a personal question?"

    mur "Because you willingly came over to my home. Married women don’t usually go visit a stranger’s home without their husband."

    mur "That is, unless they want something they aren’t getting from their husband."

    scene v8-38

    b "Let me guess, you can provide everything that my husband can’t, isn’t that right, Murat? You’d be my savior."

    b "You’d give me all the pleasure a man can offer. Yes, I’ve heard these things before."

    mur "You mistake my intentions. I’m just a concerned friend."

    b "Well you have nothing to be concerned about."

    b "Right after you drop me at my house, I’m going to cuddle with my husband all night and shower him with kisses to show how much I love him."


    scene v8-39

    mur "If you say so."

    scene v8-38

    b "You should find another woman to pursue. You’re attractive enough, I’m sure you could find plenty of single women interested in you."

    scene v8-37

    mur "It’s not about me… you’re in an unhappy marriage, and I want to show what you're missing. You know what I mean."


    if murattease == True:
        scene v8-38



        b "Like you tried to do when I came over… that went too far."

        mur "That was only the beginning. Next time will go farther."

        b "You are so confident, always."

        scene v8-39

        mur "This is why you didn’t sit up front with me, you were worried we would kiss again. All you need to do is nod your head, and I’ll turn my car around and take you to my home."

        mur "We can finish what we started last time."

        scene v8-40

        b_ "He thinks I’m that easy. He’s wrong. It was a big mistake letting him kiss me and I can’t let it happen again."

    scene v8-36

    b "Just take me to my home, Murat. My husband is waiting."

    stop music

    stop music3
    scene black with dissolve
    with Pause(3)
    scene v8-54 with pushright
    "Banu had been looking forward to a quiet evening with Kamil, hoping the time spent together could lead to some romance later in the night."
    "But upon arriving home she found her husband lounging with two of his friends, Farhad and Abdul."
    "So, instead of cuddling up with Kamil on the couch as she’d hoped, she had to be their servant."
    scene v8-55
    b_ "Why is it that something always comes in the way of making progress with Kamil? I shouldn’t have gotten my hopes up that we would have a romantic evening together. "
    b_ "Could it be that Kamil really does just look at me as his servant? I wonder how long these friends of his are staying. I hope they leave soon."
    scene v8-56
    b_ "The sooner I can feed them snacks, the sooner they’ll leave. "
    b_ "I’ll be sure to give Kamil a look that tells him I’m not happy he’s spending free time with friends instead of me."
    scene v8-57 with dissolve
    b_ "Better grab these tissues, so Abdul doesn’t make a mess like the last time he ate snacks over here. Maybe if he didn’t eat like a pig…"
    scene v8-58
    "In the other room, Kamil was having pleasant conversations with his two friends as they smoked from a hookah, ate snacks and drank beer."
    scene v8-59
    "Farhad was younger than Kamil, and they met through Kamil’s work. He worked as an architect, designing high-end apartment buildings. "
    "Abdul was older, and Kamil also met him through work. Abdul managed construction sites. "
    "Whenever the three friends were together, the conversations inevitably moved towards work, which Banu found extraordinarily boring. "
    "At the moment Abdul and Kamil were discussing the latest high-rise condominium construction in the North District, while Farhad smoked from the hookah."
    k "…but you know the funding will be outrageous."
    ab "They’re a bunch of jerkoffs who don’t know their head from their ass. Inventory is harder to come by lately, and they don’t take that into account."
    k "The district keeps growing. How will they manage shortages?"
    ab "You meant to say, how will they ‘mismanage’ shortages. It’s done on purpose because they’re controlled by mobsters."
    k "Mobsters? In the North District?"
    ab "The mobsters want legitimate businesses to fail, so they can buy property and run drugs, weapons, and prostitutes through there. "
    ab "Not that I’m complaining… if I help them build it, they’ll give me free pussy, haha! They have some fiiiine pussy up there, let me tell you."
    k "I shouldn’t be surprised that you’ve never married, my friend."
    ab "Marriage? No way. Too much fine pussy around."
    ab_ "Speaking of fine pussy…"
    scene v8-60
    ab_ "She might have the finest pussy in town…"
    k "Ah, my lovely wife has brought us more snacks."
    scene v8-61
    b "Gentlemen, here you are."
    far "Thank you, it looks delicious."
    k "It’s about time you stopped sucking on that pipe, Farhad."
    far "It’s been a long day; I’ve been looking forward to this hookah ever since I woke up. Banu, how is your job going?"
    ab_ "Look at her bending over… such a fine body."
    scene v8-62
    b "Thanks, it’s well. Some of my coworkers aren’t friendly, but the job keeps me busy."
    far "I’ve always appreciated the building your office is located in. It’s modern enough, but it still has a taste of tradition. I heard your bosses have been searching for loans lately. Have you heard?"
    b "Those matters stay with the bosses. I just do what I’m told. I try to stay out of the gossip."
    far "Ah, I wish my employees had the same mentality as you!"
    ab_ "Her legs are so sexy in those tight pants. What I wouldn’t give to have them wrapped around me."
    b "I speak up if I need to, but for now I’m satisfied with my job and keep quiet. "
    b "If they try to cut my wages, I’ll be quite unhappy though. I know that’s been happening all over the city."
    k "You shouldn’t talk like that, Banu. You do a wonderful job."
    ab "He’s right, Banu. You’re so talented and smart. Surely, they should pay you more money, not less. "
    ab "And might I say, Kamil, that you really struck gold with Banu. Every time I see her, she impresses me more and more. She’s a remarkable woman. You’re a lucky man."
    b "Thank you, Abdul. I hope my dear husband feels the same way."
    scene v8-63
    "Banu turned towards Kamil and stared daggers into him."
    b "I know for sure that he loves spending more time with his friends and the hookah than me."
    "You could hear a pin drop in the room. The three men were shocked Banu bluntly called her husband out like that."
    "Abdul suddenly realized she probably had planned to have Kamil all to herself this evening, which is why she’s been moody ever since she walked into the house."
    b "But enough idle chat, I need to go perform my wife duties, right Kamil?"
    scene v8-64
    "Banu gave Kamil another scowl and then quickly exited the room before he could respond."
    ab_ "That was an interesting exchange. There must be marriage issues Kamil isn’t telling me about."
    far "Woah, she’s pissed off! What did you do?"
    k "You know how women can be, but I’m not worried about it. I have a surprise for her tomorrow that will cheer her up."
    scene v8-59
    far "Do you want us to leave?"
    k "No, just take it easy."
    ab_ "Maybe I can take advantage of this... "
    ab "No more smoke for me, my stomach is churning from lunch. I need to head to the toilet. I could be a while."
    k "Take your time."
    scene v8-65 with blinds
    b_ "I couldn’t have made it more obvious. If Kamil doesn’t take the hint, he’s either clueless or he doesn’t love me. "
    b_ "There’s still time left for us to have a romantic evening if he tells them to leave soon."
    scene v8-66 with hpunch
    play music "audio/tension.mp3"
    "Banu’s thoughts were suddenly interrupted by the sound of heavy footsteps and the faint smell of sweat."
    b_ "This must be Abdul."
    ab "Banu..."
    b_ "I knew it."
    scene v8-67
    b "Hey Abdul. Can I help you?"
    ab "You sounded upset out there. Anything you’d like to talk about? Kamil didn’t sound interested in coming in here to comfort you."
    scene v8-68
    "Banu bristled at his words and turned around to resume preparing the snack. Abdul took this opportunity to look her body up and down."
    b "Thank you for your concern, but this is between Kamil and me."
    ab "I know you’re having trouble with Kamil. No wife talks to her husband like that in front of others. He must have done something really bad."
    "Banu now regretted confronting Kamil like that in front of his friends. She had let her emotions get the best of her."
    b "I shouldn’t have done that, but I’ve been dealing with stress lately and I’m moody today."
    ab "If you were my wife, I’d have told my friends to get lost the moment you stepped through the door, and we’d have a good time."
    scene v8-69
    "Banu was startled by his comment, but she remained silent."
    b_ "It’s too bad Kamil is not thinking like Abdul. That’s exactly what I wanted when I came home."
    b_ "Wait...what is he doing? I feel he is checking on my back?"
    scene v8-70
    "Instead of responding, Banu turned and walked away from him, wanting to forget about the issues with her husband."
    scene v8-71
    ab_ "I struck a nerve with her because I knew exactly what she wanted Kamil to do."
    scene v8-72
    stop music
    ab "If you want, I can grab Farhad and leave. We ruined your night."
    b "You can’t leave, I’m making you all some more snacks."
    ab "You’re such a good woman, Banu. Even though you wanted a romantic night with your husband, you still serve us."
    b "Of course, you’re a guest in my house. And I don’t know what romantic night you’re talking about, Kamil’s friends are always welcome here."
    ab "Don’t lie to me, I saw the look in your eyes when you came through the door. Kamil missed an opportunity."
    scene v8-73
    b "Well… honestly, you’re right, he did. It’s like he doesn’t even notice. Even after I snapped at him."
    b "It’s like he doesn’t care."
    ab "Kamil doesn’t understand women. He never has. Like I said, if it were me, I would’ve kicked my friends out immediately when you arrived."
    b "But he’s a nice man, it would be rude of him to kick friends out."
    play music "audio/tension.mp3"
    ab "Not with a wife like you, he should be taking you to bed instead. When you came in the room with those tight pants on, I knew you were teasing him."
    b "..."
    scene v8-74 with dissolve
    ab "I noticed though. Look how hard my cock is after watching your bum all night."
    menu:
        "Banu sticks up for Kamil and storms out of the kitchen.":
            $ renpy.block_rollback()
            $ banu_kamil += 1
            $ banusticksupforkamilandstormoufofkitchen = True
            scene v8-75
            b "How dare you say such a thing! You’re my husband’s friend!"
            scene v8-76
            ab "Hold on, Banu. No need to get upset. I’m just speaking my mind truthfully. Forget about what I said."
            b "You disgust me, talking to your friend’s wife like that. Kamil is a good man and I love him. You don’t deserve a friend like him."
            ab "You know that I’m good to him, I give him a lot of business. I’ll continue to be a good friend, just forget I said anything."
            b "You better treat him good, or he’ll hear about this!"
            scene v8-77
            stop music
            "Banu stormed out of the kitchen."
            ab_ "I misjudged her. She must really love that stupid Kamil."
        "Banu flirts back.":





            $ renpy.block_rollback()
            $ banuflirtsbacktoabdul = True

            stop music
            play music "audio/sensual.mp3"
            scene v8-82
            b "Oh, I did that? How rude of me to tease a guest like that."
            b_ "He’s not an attractive man, but I will tease him a bit. After all, my husband deserves it."
            scene v8-83
            "Banu turned back towards the task she was doing and purposely shifted her hips to push her ass towards him, knowing she’d be teasing him even more."
            ab "I never knew you had such a nice bum because you always hide it under dresses."
            b "You should be careful my husband doesn’t hear you say that."
            ab "Kamil won’t do anything to me. If he had balls, he would share his woman with his friends!"
            scene v8-84
            b "You know my husband wouldn’t do that."
            ab "True, but it’s not like you need his permission."
            b "That would be very cruel to betray my husband, don’t you think?"
            ab "What’s cruel is I’m so hard with no way to release it."
            b "I see. I have my hands full right now, so I can’t help you with that."
            ab "Yes, but soon I will visit again when Kamil isn’t around, and when you don’t have your hands full."
            scene v8-85
            "Banu smiled and began to walk away, ending the conversation, but added one last comment, seductively…"
            b "Don’t worry, hands aren’t the only thing I use."
            "Banu swayed her hips a bit more and kept a smile as she left the kitchen."
            b_ "Now he will need to leave sooner to go home and relieve himself. Hopefully he takes Farhad with him."
            stop music
        "Banu slaps him.":





            $ renpy.block_rollback()
            $ banuslapsabdul = True

            scene v8-78
            b "How dare you say such a thing, you fucking pig!"
            "Without hesitation, Banu raised her hand and took a swipe at Abdul’s face."
            scene v8-79 with hpunch
            "Because she was so enraged, her aim was shaky, and she slapped him on the side of the head instead of his face. "
            "Abdul was shocked. Banu was shocked too that she missed his face, but she wasn’t going to let him know of her mistake, so she continued to verbally insult him."
            scene v8-80
            b "You thought you could come into my house and disrespect me? Just because I’m a woman wearing a hijab and serving my husband’s guests?"
            ab "I’m sorry, Banu. I’m just speaking my mind truthfully. I’ll leave right now. "
            b "No, pig, you’re not leaving right now."
            ab "I’m not?"
            b "No because I need YOU to serve ME."
            scene v8-81
            stop music
            b "Get your ass out to the room and clean up the table. "
            ab "Okay, fine, but don’t tell Kamil what just happened."
            b "If you’re a good servant, I won’t. Now go clean up your mess! There better not be any crumbs either."
            ab "Okay, I will."
            "Abdul quickly exited the kitchen. "
            b_ "That felt good, I could get used to this kind of control!"



    stop music
    scene black with dissolve
    with Pause(2)
    scene v8-1 with slideleft
    b_ "It should be a relaxing day today. I’ll try not to be bothered that Kamil preferred to visit with his friends last night and we never got to spend time alone."
    scene v8-2 with dissolve
    play music "audio/sensualsex.mp3"
    b_ "Flowers? I’ve not seen these before. Where did they come from?"
    scene v8-3
    b_ "They’re so beautiful. Yellow is one of my favorite colors. And they smell wonderful."
    scene v8-4
    b_ "Kamil must have bought these. Leyla and Ruslan aren’t home, so it has to be Kamil. But where is-"
    scene v8-5 with hpunch
    k "My sweet wife."
    b "Oh, you startled me."
    k "Do you like them?"
    scene v8-6 with dissolve
    b "Of course! I love them! You know how much I adore yellow flowers."
    k "I do. That’s why I got them for you."
    scene v8-7
    b "Oh, that’s so sweet of you. What a nice surprise to start my day."
    k "I’m sorry for having my friends over last night when we had the house to ourselves. But I want to make it up to you tonight."
    k "I’m taking you to a romantic dinner, just the two of us. The restaurant is a surprise."
    scene v8-8
    b "A surprise, huh? I’m excited! And I accept your apology. I guess I’m going to have to decide on a dress."
    k "You look wonderful in anything you wear."
    b "Thank you, you’re so sweet."
    stop music
    b_ "I was unfair to Kamil last night. I shouldn’t have gotten so mad at him."
    if banuflirtsbacktoabdul == True:
        b_ "And teasing Abdul was shameful, but I was upset with Kamil at the time. Hopefully Abdul will keep it a secret."



    scene black with dissolve
    with Pause(2)
    scene v8-41 with irisin
    play music "audio/chill.mp3"
    "Banu met up with Hicran and headed for the gym. They decided yesterday that they wanted to visit the brand-new gym in the North District and possibly join it. "
    "It came highly recommended to Hicran. Banu wanted to start working out more consistently, so joining a new gym with Hicran would certainly provide her opportunities. On the walk, Banu told Hicran about Kamil’s present."
    scene v8-42
    hic "…That’s so sweet, I love yellow flowers too. And how romantic that he’s taking you out to dinner in the city. "
    hic "There are some great new restaurants here in the North District and I know some of the owners in case you’re looking for a recommendation."
    b_ "Hicran certainly knows a lot of people in this city. What happened to the shy girl from college?"
    b "Thanks, but my husband is surprising me with the restaurant choice."
    hic "That’s exciting, I can’t wait to hear all about it."
    b "I just feel so bad I got upset with him in front of his friends. I made a scene."
    hic "Maybe that’s why he got you the flowers? Therefore, it was good you made a scene. "
    hic "Sometimes us women need to stand up to men to get what we want. Men can be so clueless sometimes."
    b "That’s true. But I hope his friends don’t start rumors that our marriage is in trouble. One of his friends made a pass at me later on."
    if banuflirtsbacktoabdul == True:
        b_ "I won’t tell her that I flirted back. "
    hic "Stay true to yourself and it will work out. If you love your husband and he loves you, nothing will come in your way. "
    hic "But if you’re like me, I’m not in love with my husband, so it’s hard for me to care about him, and it’s very hard not to flirt with others."
    scene v8-43
    b "You look amazing, I’m sure it’s very easy for you to tease men."
    hic "And women."
    b "Yes… I suppose so…"
    if banuhicranshower == True:
        b_ "She got me aroused in the shower, there’s no doubt about that. She’s such a confident woman, and she always looks sexy no matter what day it is."
        b_ "Part of me wants to learn more from her, but that could be dangerous."


    scene v8-44
    stop music
    hic "Here we are! This place doesn’t look very special from the outside."
    b "Maybe it’s still under construction."
    hic "I’m sure the gym is nice, with brand new equipment."
    scene v8-45 with squares
    hic "This place is a maze."
    b "It has that new scent to it."
    hic "Yeah, fresh paint. Oh, it looks like the entrance is over here."
    scene v8-46
    play music3 "sfx/gym.mp3"
    "As they approach the gym entrance, a fit man exits through the door."
    scene v8-47
    hic "Hello, excuse me, is this where we enter the gym?"
    mal "Hello, and yes, it is. But you don’t look properly dressed to work out."
    scene v8-48
    hic "Oh, we’re not working out today, but maybe tomorrow if we like this gym. This is our first time here and we’re interested in joining. "
    hic "I know the owner of this building and he told me to come speak to Malik. Do you know where I can find him?"
    mal "I’m lucky to have met you out here. I’m Malik. I’m the lead instructor."
    hic "Good! Nice to meet you, Malik. I’m Hicran, and this is Banu."
    mal "Hello Hicran and Banu, you are two lovely ladies that would make this gym sparkle. We’re aggressively looking for new members, and I can tell you everything you need to know."
    mal "I can also offer you an exclusive discount."
    hic "We’re excited to learn more about this gym!"
    scene v8-49
    mal "We have brand new equipment and amenities. You should see our juice bar. It’s exceptional. We also have…"
    scene v8-50
    "As Malik and Hicran chatted about the gym, Banu couldn’t help but marvel at Malik’s chest."
    b_ "This man is so fit. He has a perfect body. I don’t know what to think about having a man like him instruct me. "
    b_ "How could I focus on working out? But maybe he wouldn’t be my instructor. Maybe the men are kept separate from the women."
    "After a few minutes of listening to them chat, Banu spoke up."
    scene v8-51
    b "Will men and women have separate training rooms?"
    mal "Absolutely. We respect privacy."
    b "And the locker rooms will be separate too?"
    mal "Yes. We have designs specific to your needs as a woman."
    scene v8-52
    hic "I like what I hear so far. How about you, Banu?"
    b "It’s suitable for me."
    b_ "Even though the thought of being around this hunk is disconcerting."
    scene v8-53
    mal "Great, so come with me and I can get your signed up! You will really love this gym. You’re making a great decision…"
    stop music3

    scene black with dissolve
    with Pause(2)
    scene v8-151 with pushdown
    play music3 "sfx/school.mp3"
    "Leyla was feeling better with each day that passed, but she was still haunted by the horrific incident with Seyhun. "
    "Everywhere she went around campus, she felt people were staring at her and judging her. She wondered if all the other students had heard she was raped by now."
    "Fortunately for Leyla, Seyhun all but disappeared from her life other than her memories and nightmares."
    "She wondered if he was hiding out somewhere nearby, or if he had left town for good. Either way, she hoped to never see him again. "
    "Currently she was headed to the University’s library and was ready to attack her homework."
    scene v8-152
    met "Leyla! Wait up! Why did you ignore me? "
    scene v8-153
    l "Why did you follow me? I don’t know who you are."
    met "I thought we could get to know each other better. My name is Metin, and I’ve seen you around here before, but we’ve never talked."
    l "Ok but how do you know my name?"
    scene v8-154
    met "Your mom who wears a hijab always shops for food at my family’s store and she tells me her daughter is my age and is named Leyla, and that we should meet sometime. I’ve seen you walking with her."
    l "So why are you approaching now?"
    met "You ask so many questions and I’m late to class. Give me your number and we can talk further tonight."
    scene v8-155
    l_ "I don’t trust him. He must’ve heard the rumors about Seyhun and me. "
    l_ "It’s so hard to talk to anyone because I never know if they’re judging me for losing my virginity and being raped."
    l "No, I don’t want to know you better. Please leave me alone."
    "Leyla turned around and stormed down the hallway away from him."
    scene v8-156
    met "You can keep ignoring me Leyla, but you’ll be mine soon!"
    scene v8-157
    "Metin pulled out his phone opened a video he took from a closet inside the gym locker room. The video showed Leyla changing out of her gym clothes and into the outfit she was currently wearing."
    met_ "Poor Leyla will have this video sent to everyone at University, unless she cooperates. Or maybe her mom will cooperate instead."
    stop music3


    scene black with dissolve
    with Pause(2)
    play music "audio/romantic.mp3"
    scene v8-9 with wipeleft
    "Banu and Kamil arrived at the restaurant, which was a fancy establishment that contained outdoor seating and primarily served seafood."
    "Kamil reserved the most romantic table available. Banu had never been to this restaurant before, so she was suitably impressed."
    scene v8-10
    k "I can’t tell you enough how stunning you look tonight. Black is a good look on you."
    b "Thank you. And you look very handsome and well-dressed. I think I’ve made other women here jealous as your date."
    k "I know I’ve made the men here jealous. All of them turned their heads when you walked by."
    b "You’re making me blush."
    scene v8-11
    b "I’m pretty hungry. I can’t wait to see what’s on the menu. I’m sure it’s going to be delicious."
    scene v8-12
    k "Best seafood in the district, is what they say."
    scene v8-11
    b "I love seafood, this is an excellent surprise. And so romantic on this patio. Oh, here comes the waiter."
    scene v8-13
    wait "The menu, sir."
    k "Thank you!"
    wait "What would you like to drink tonight?"
    k "I’ll have the house red wine, and my lovely wife will have your virgin red, being that she doesn’t drink alcohol."
    wait "Certainly, I’ll have those right out…"
    scene v8-14 with dissolve
    stop music
    "Kamil and Banu both ordered seafood, and the meals took a while to come out since everything at the restaurant is prepared fresh."
    "While they waited, Kamil drank his wine faster than he’d planned and the waiter refilled his glass twice."
    "Banu was amused by it, since Kamil seemed to loosen up a bit over the course of his drinking and was talking more animated than his usual stiff demeanor."
    "She was famished by the time the food finally arrived."
    b "This looks so delicious. I haven’t been this excited to eat a meal in ages."
    k "I hope it makes up for last night. I was wrong to invite my friends over when we could’ve spent time alone."
    b "Don’t apologize. I was moody yesterday and overreacted. You know I enjoy entertaining guests."
    k "Yes, but Farhad and Abdul can be a lot to handle!"
    b "Nonsense, they’re your friends, it’s not a problem. Farhad is so pleasant. Abdul… well, he’s a different story."
    k "What do you mean? Did something happen?"
    b_ "I shouldn’t ruin the night by bringing up the incident with Abdul."
    b "No, nothing happened, he just seems different than Farhad and you."
    k "Oh, yes indeed, he’s one-of-a-kind! He thinks he’s a ladies’ man and more accomplished than me, but look at him, he’s a slob and could never have a woman like you!"
    k "But he’s still a friend, and he’s good to me."
    if banuflirtsbacktoabdul == True:
        b_ "If only he knew of the conversation Abdul and I had, he wouldn’t be so sure. "
        b_ "Abdul may be a slob, but he’s a confident man and it was rather fun to tease him behind Kamil’s back despite feeling guilty afterwards."
    b "Enough about your friends. Let’s talk about this meal… the food is amazing!"
    scene v8-15
    play music "audio/intro.mp3"
    k_ "I should take her out to dinner more often. She looks so happy right now. Sometimes I never know whether she’s happy or not. "
    k_ "Maybe I’m just scared of trying to make her happy, that I might fail to make her happy despite trying. I’m afraid of failure."
    scene v8-16
    k "Banu, I should take you to fine restaurants more often. Being here with you, I realize I’ve neglected you. "
    k "With the kids now older, we should be spending more alone time together, doing things out in the city. "
    b "That does sound lovely."
    k "It’s just… I’m not sure if … if I…"
    "Kamil hesitated, trying to find the right words to speak his mind."
    b_ "Is he drunk?"
    b "What is it you’re trying to say? You can tell me anything."
    scene v8-17
    k "Deep down I’m scared. I don’t want to fail. I’m afraid you won’t be happy with me. It goes back to high school, the first time I ever fell in love. "
    k "She was my crush for two years, and I sat next to her in classes but never had the nerve to talk to her. "
    k "I couldn’t believe it when she passed me a note asking me to go out with her. Soon after, we were boyfriend and girlfriend, and I was head over heels in love."
    k "I couldn’t believe it to be true. I wanted her to meet my family. But… one night, when she said she was visiting her best friend, I saw her instead with Ahme… err… um… another boy… and they were making out, and she kissed him like she never had kissed me. "
    k "When I confronted her, she told me she wanted to break up with me and go out with him instead, that I failed to make her happy."
    if ahmedtease == True:
        b_ "Was he about to say Ahmed? I know he hasn’t ever talked to me about Ahmed, but Ahmed said he knows Kamil."
        b_ "It makes sense why Kamil doesn’t talk about him… Ahmed must have been the one who stole his girlfriend."

    k "This is why I’m distant towards you sometimes. I’m scared I’ll have my heart broken, like I did in high school. That if I love you more, you might leave me. That I can’t make you happy. "
    k "I know it’s silly to think this way. But you’re so beautiful, and I see other men lust after you, the way they look at you and talk to you."
    scene v8-18
    k "I hope you understand why I think this way."
    menu:
        "Banu feels bad for him and wants to comfort him about their relationship.":
            $ renpy.block_rollback()
            $ banufeelsbadforkamil = True
            $ banu_kamil += 1
            scene v8-19
            b "That’s awful. I had no idea your heart was broken like that."
            k "With you as a widow, I didn’t want to tell you, as it doesn’t compare to the heartache you experienced."
            b "That’s thoughtful, but you can tell me anything, you know this."
            scene v8-20
            b_ "This explains so much. It’s why he’s so distant and cold sometimes… it’s why he doesn’t shower me with affection nor try to make love with me."
            b_ "He’s scared. It must be awful to feel like that. But I too am scared. I also gave my heart to someone… and just like that he was gone from my life. I never thought I could ever love again."
            scene v8-21
            b "I too am scared. I don’t want my heart broken again either. This is why I’ve often been distant with you. "
            b "I see the efforts you make to love me, and I frequently reject them. I’m as much to blame as you."
            scene v8-22
            k "Then let’s stop blaming ourselves. Let’s move on and look towards our future. Starting tonight, we will have more dinners together. "
            k "We’ll have more alone time. We’ll do more activities together. Let’s fall madly in love, Banu."
            scene v8-23
            stop music
            b "You’re such a sweet man. It makes me happy to hear you say that. I don’t want to blame ourselves anymore either. I want to fall madly in love too. I’m ready."
        "Banu asks him to do better if he wants their relationship to work.":



            $ renpy.block_rollback()
            $ banuaskskamiltodobetter = True
            $ banu_kamil -= 1
            stop music
            scene v8-24
            b "But these are things of the past. What does your high school girlfriend have to do with our marriage?"
            b "I think this is the wine influencing your thoughts."
            scene v8-25
            b "We’ve been together for a long time now. If you can’t let go of this fear, how are we supposed to move further in our marriage?"
            scene v8-26
            k "I will give you all my heart, I just want to know you aren’t going to break it."
            scene v8-27
            b "I can’t give you any promises like that. You need to get over your fears and accept who I am. "
            b "You need to work on our relationship too. You can't expect me to do everything."
            b "You’re so worried about your feelings, but you need to get tougher and be confident that things will work out for us in the end. "
            b "I can’t understand why you’re scared to show love and desire for your own wife."
            scene v8-26
            k "I know, you’re right, and I’ll try harder. I’m never going to give up on my quest to make you the happiest woman in the world, Banu."
            k "I love you and would do anything for you."




    scene black with dissolve
    with Pause(3)
    scene v8-96 with blinds
    play music3 "sfx/office.mp3"
    "The next day brought a surprise visitor to the company Banu works for."
    "Her name was Rina Midori Powl, and she was the top investor in the company Banu worked for."
    "She carried herself like it too, as she walked briskly through the office as if she owned everything. She had a presence to her that everyone noticed immediately."
    scene v8-97 with dissolve
    "Banu was talking to a coworker when she noticed the woman out of the corner of her eye. Rina moved so quickly that Banu never got a suitable look. But Rina got a good look at Banu. "
    "Rina always knew her surroundings even when it looked like she wasn’t paying attention."
    "Dealing with powerful people on a daily basis forced Rina not to trust anyone, as she could be compromised at any moment, so observing every detail surrounding her at all times was ingrained in her. "
    "Some would say she was paranoid, but she deemed it necessary to survive."
    ri_ "A hijab-wearing woman in this office. Duly noted. I’ll deal with her later. I have an ass to kick first."
    stop music3
    scene v8-98 with irisout
    "Rina burst through the door belonging to the company director’s office without knocking."
    ri "Ali, apologies for being late to our meeting."
    scene v8-99
    ali "Late? You’re a minute early, Ms. Powl. A pleasure to see you again. I wasn’t expecting you back so soon, so I was shocked to receive your email this morning. I thought you were in London right now."
    ri "I always want you to think I’m somewhere else, so that I can surprise you at any moment."
    ali "You are too kind to consider my excitement. I do like a good surprise."
    ri "Spare me, this isn’t a pleasant surprise."
    ali "Please, sit down. You’ve traveled far. Can I get you-"
    ri "There’s no time for a refreshment. I’m on a tight schedule."
    scene v8-100 with dissolve
    ali "About last month’s financials, I think-"
    ri "I already know everything about the financials, your finance director briefed me before I made the trip here."
    ali "But I wanted to-"
    ri "I know you want to bullshit me about your numbers, that they aren’t what they appear, blah blah blah. "
    ri "Let me tell you, we still haven’t gotten the loan we desire. Without good numbers from your office, we can’t get the loan. Without the loan, we can’t start the Borash Project. You see where I’m going with this?"
    scene v8-101
    ali "If you let me explain, I could tell you our plan."
    scene v8-102
    ri "Fine, but this better be good. We have big plans in the North District, and time is of the essence. I need more buildings bought, torn down, and built again. "
    ri "And I need these vacant lots cleared so we can build on them. "
    ri "Money should NOT be an issue from your office, yet it is, so you’re going to need to have a damn good plan and explain it all to me in the next ten minutes…"
    scene v8-103 with squares
    play music3 "sfx/office.mp3"
    "Back in the main floor of the office, Banu was dreading her next task for the day, which required her to report to Turan’s office. "
    "She had been trying her best to avoid him recently, but it was inevitable she’d have to confront him eventually for her work assignments."
    scene v8-104 with dissolve
    "Just as she was about to enter his office, the woman she noticed earlier exited the elevator and swiftly headed straight towards her without blinking an eye. "
    "Before Banu could do as much as open her lips to say hello, the woman clutched Banu’s arm and prevented her from entering Turan’s office."
    scene v8-105
    b "Excuse me, but you can’t touch me like that."
    ri "Well said, I like that attitude in a woman. And here I thought you were a pushover with that ridiculous hijab on your head."
    ri "Before you say anything further, I’m the boss of your boss’s boss, so if I grab your arm, you should consider yourself lucky that I’ve acknowledged your existence. "
    scene v8-106
    ri "My name is Rina. And yours?"
    b "Banu."
    ri "Okay, Banu, I’m free in an hour, so meet me at that cute little café around the corner. My treat."
    b "What about-"
    scene v8-107
    "But before Banu could finish her sentence, Rina had already taken two steps towards the front corridor."
    ri "See you soon."
    "Banu could only stare at the interesting woman as she briskly walked away."
    b_ "What could this be about? I hope I’m not losing my job. Does Turan know what’s going on? Well, I guess I have no choice but to go meet her in an hour. "
    scene v8-108 with fade
    stop music3
    "After the awkward exchange with Rina, Banu shifted her mind back to her meeting with Turan. She entered his office and approached his desk."
    t "Banu, hello. How are you?"
    b "Thanks, I’m well. Here’s the rest of the briefs on the district codes you asked for."
    t "Very good. Like I always say, I can count on my top employee."
    if banuturansexfirsttime == True:
        scene v8-109
        "Turan can see that Banu looks timid. He gets up and walks around the desk."
        t "Come, let’s sit down on my couch and chat. I miss talking to you, and we have work matters we can discuss."
        scene v8-112
        t "Come sit here."
        "He motions towards the space next to him on the couch, but Banu wasn’t buying it."
        b "I prefer to sit in this chair."
        b_ "I won’t give him any satisfaction. I still can’t believe what happened between us. I swear it had to have been something he put into the tea. He took advantage of me."
        scene v8-117
        t "Fair enough. So tell me what’s on your mind?"
        b "What’s this woman named Rina doing here, the investor? She wants to meet with me in one hour. Do you know anything about this?"
        t "I don’t know what she’s doing here. Ali doesn’t explain these things to me. It’s curious that she wants to meet with you."
        b "I have no choice! She didn’t give me an option, she just said to be there. Are you sure you’ve not heard anything about my job status?"
        t "Of course not, I would tell you everything. You’re my best employee and you have nothing to worry about."
        b "Who is this woman? I know her name is Rina, but I know nothing else."
        "While Banu’s mind is occupied with Rina, Turan’s mind is in a different place. He was plotting a way to get closer to Banu. "
        "Sex with her was something he cherished, and he wants to fuck her again and again. But he is smart enough to know that he’ll have to play it slow and careful. "
        "He doesn’t want to spook her by being too forward with her again."
        scene v8-118
        play music "audio/tension.mp3"
        "Turan gets up from the couch and approaches Banu. She immediately puts her guard up and scowls at him. Turan discards her look and continues."
        t "She’s originally from Japan, but she lives in London these days. She has a lot of investments, and she knows a lot of people."
        t "Some of her associates are prominent people, and some of them are shady characters. She’s been visiting here a lot lately to meet with Ali. "
        "Turan moved behind Banu, which put her more at ease that he didn’t come straight at her."
        scene v8-119
        b "But now she wants to meet with me."
        t "Yes, that’s surprising. I don’t think she’s into women sexually, or else I’d say that’s why she’s wanting to meet with you."
        b "Be serious, Turan. What if she wants to fire me?"
        t "You report to me, so they have to tell me if they plan to fire you. I would tell you the truth if I knew."
        b "I work hard for this company, and I do good work."
        t "I agree. You’re my best employee."
        scene v8-120
        "Suddenly Turan puts his hands on the chair and leans over to be closer to Banu."
        t "Here’s what I’ll do. I can ask Ali about what Rina is doing here. I’ll push him to give me an answer. "
        t "I know things about Ali that he wouldn’t want anyone to find out about, so he will tell me truthfully."
        scene v8-121
        "Banu immediately stiffens up at Turan being so close."
        b_ "This man never stops. Coming into his office to chat was dangerous."
        b_ "I can’t help but remember… no… no Banu… you cannot think about that night!"
        t "I want to protect you, Banu. There’s a lot of bad stuff going on in the city, and you don’t need to get involved with those things. "
        t "Rina is a powerful woman, so you need to be careful in your dealings with her."
        b_ "Will he try to do something here? I can’t let that happen…"
        scene v8-122
        stop music
        "Banu immediately gets up and moves away from him."
        b "I can handle myself. I’m leaving now. I brought you what you needed, and I don’t need to stay here any longer."
        "Banu moves past him and exits his office, knowing that his eyes were on her ass as she walks away. It makes her shiver."
        "Turan isn’t quite sure what to make of this exchange, but he knows being too aggressive right now could be problematic if he plans to bed her again, so he lets her leave."






    if banuturansexfirsttime == False:
        scene v8-110
        b "Turan, what’s this woman named Rina doing here, the investor? She wants to meet with me in one hour. Do you know anything about this?"
        "Turan could see that Banu looks worried, so he gets up and walks around the front of the desk."
        t "I don’t know what she’s doing here. Ali doesn’t explain these things to me. It’s curious that she wants to meet with you."
        b "I have no choice! She didn’t give me an option, she just said to be there. Are you sure you’ve not heard anything about my job status?"
        t "Of course not, I would tell you everything. You’re my best employee and you have nothing to worry about."
        "While Banu’s mind is occupied with Rina, Turan’s mind is in a different place. He was plotting a way to get closer to Banu."
        "His attempts with her have failed so far, but he knew he’d have to play it slow and careful."
        t "Please, come sit. Let’s talk about it."
        scene v8-111
        "Turan sits on the couch that seats two and motions for Banu to sit down next to him. To his delight, she doesn’t hesitate to come over."
        b "Who is this woman? I know her name is Rina, but I know nothing else."
        scene v8-113
        t "She’s originally from Japan, but she lives in London these days. "
        t "She has a lot of investments, and she knows a lot of people."
        t "Some of her associates are prominent people, and some of them are shady characters. She’s been visiting here a lot lately to meet with Ali. "
        b "But now she wants to meet with me."
        t "Yes, that’s surprising. I don’t think she’s into women sexually, or else I’d say that’s why she’s wanting to meet with you."
        scene v8-114
        b "Be serious, Turan. What if she wants to fire me?"
        t "You report to me, so they have to tell me if they plan to fire you. I would tell you the truth if I knew."
        b "I work hard for this company, and I do good work."
        t "I agree. You’re my best employee."
        b "Thank you."
        t "Here’s what I’ll do. I can ask Ali about what Rina is doing here. I’ll push him to give me an answer. "
        t "I know things about Ali that he wouldn’t want anyone to find out about, so he will tell me truthfully."
        b "That sounds risky. I wouldn’t want you to get in trouble because of me."
        t "I want to protect you, Banu. There’s a lot of bad stuff going on in the city, and you don’t need to get involved with those things. "
        t "Rina is a powerful woman, so you need to be careful in your dealings with her."
        b "I appreciate your concern. You’re always so thoughtful."
        if banu_turan >= 1:
            scene v8-115
            t "You’d blush if you knew what I was thinking about right now."
            b "Don’t start with that, Turan."
            t "I can see your nipples getting hard being so close to me. It makes me want to pinch them."
            scene v8-116
            "Banu instinctively covered her breasts with her arms."
            b "Enough. You can’t talk to a married woman like this."
            t "But I can see how turned on you are being so close to me. You came and sat down because you wanted to be closer to me."
            b "I brought you what you needed, and I wanted to chat about Rina. I don’t need to stay here any longer. Goodbye, Turan."
            scene black with dissolve
            "Banu gets up and quickly exits his office."




    scene black with dissolve
    with Pause(2)
    scene v8-144 with blinds
    play music3 "sfx/coffee.mp3"
    "Banu arrived at the café right when Rina asked her to. Rina was already sitting at a table in the corner waiting for her. "
    "The conversation was actually more pleasant than Banu had ever expected, considering their first encounter. "
    "She learned all about Rina’s history. The woman was impressive, to say the least. Banu realized Rina took no shit from anyone. "
    "Rina had all sorts of businesses all over the world, but recently she began investing in properties and companies here in the city. "
    "Banu never got a clear answer as to what all these businesses actually did and why she invests in them, but it was clear that Rina was an exceptional person, so Banu trusted she had good reasons."
    scene v8-145 with dissolve
    ri "…And that’s why it was so difficult to make that decision without the proper funding."
    "Banu just nodded her head as Rina continued to talk. Part of her was in awe of the conversation, while part of her was still confused as to why this woman wanted to meet with her at a café."
    "It didn’t appear to Banu that her job was in jeopardy so far, so she gladly continued to smile and nod her head when Rina talked."
    scene v8-146
    ri "I’ve spent almost an hour talking about my hectic life. Tell me about you, Banu."
    scene v8-147
    b "Well… there’s not much to tell. My life is-"
    scene v8-146
    ri "Yes, yes, I know what you’re going to say, that your life is basic compared to mine. Whatever, it doesn’t matter."
    ri "Every minute has the same number of seconds in them no matter what you do with them, so you have as much of a story to tell as me."
    scene v8-145
    "Banu proceeded to talk about her business career, for the most part. Afterall, they were meeting on the context of Banu’s job, or at least, she assumed they were."
    "But Rina seemed to be more interested in Banu’s personal life."
    scene v8-148
    ri "You’re enthusiastic about your career, you love talking about your daughter, and you have fond memories of your dead husband."
    ri "But your body language and expressions change when you talk about your current husband."
    ri "I feel like you’re hiding something."
    scene v8-147
    b "Oh, I didn’t intend to mean anything by it. My husband is a good man."
    ri "And?"
    b "It’s… complicated to explain. I married him because my daughter needed a father, and-"
    scene v8-148
    ri "Yes, but now that your daughter is older and doesn’t need a father?"
    b "I see you understand. Well, we’re working on it… we’re working on how we can truly fall in love."
    ri "And how’s that going?"
    scene v8-149
    b "Tougher than I hoped. We get along, but we’re having intimacy issues."
    b_ "Why am I opening up to this woman? I just met her. But she really has a knack for understanding things and seems incredibly resourceful."
    scene v8-150
    ri "You’re under no obligation to slave yourself to this man. Forget what you’ve always thought you needed to be. You’re a woman who is more powerful than you’d ever imagine."
    ri "I see it in you. You’re unique, Banu. I can help you unlock your potential. You can obtain anything you want, just wait and see. "
    ri "If you want to love your husband forever, go ahead and love him. If you want to fuck other men, fuck other men. If you want to order your boss to shine your shoes, you can do it. "
    ri "If you want to be rich, go make money. Whatever you want to do, you can do it, Banu. "
    ri "You’ve lived your life thinking you don’t have choices and that you’re a slave to men, but enough with that, you have choices and can be anyone you want to be. "
    ri "Use being a woman to your advantage. Don’t use it as an excuse to be average."
    b_ "Wow, this woman is... inspiring! "
    stop music3

    scene black with dissolve
    with Pause(2)
    scene v8-158 with move
    "Later that day, Banu left work and spent some time in the city. It ended up getting late before she realized it, and the sun had already set. "
    "She needed to get home to Kamil, so she began her journey walking home."
    scene v8-159
    b_ "Meeting Rina at the café turned out to be nothing like I thought it was going to be. She’s so impressive. She’s strong, smart, cunning…"
    b_ "I can’t believe she’s taken an interest in me. It doesn’t seem like she has some kind of sexual interest in me. "
    b_ "I just think she sees potential in me and wants me to be a strong, successful and happy woman."
    b_ "It makes me proud she has that confidence in my abilities. She’s someone I don’t want to let down."
    scene v8-160
    "As Banu continued her walk towards her neighborhood, she reached a part of the city that worried her a bit."
    "It was an area that she wasn’t too familiar with."
    scene v8-161
    play music "audio/tension.mp3"
    "Just as Banu was about to reach another corner, she noticed a strange alleyway to her left, and she could hear some faint noises coming from it."
    b_ "I should keep walking and ignore it. There’s been a lot of stories of crime lately, and I don’t want to be a victim in tomorrow’s news feed."
    b_ "Maybe I should go the other way and cross the street over there? No, that would add more time to my already long walk. "
    scene v8-162
    "As Banu approached the alleyway, the sounds became louder. It was a rustling sound, and there were some voices too. It sounded like people gasping for breath."
    scene v8-163
    "As she turned to look down the alleyway, she was shocked at what she saw."
    stop music
    show banuseepublicsex
    play music2 "voices/slapmoanmedium.mp3"
    b_ "Oh my God!"
    "Banu was standing still and staring. She wanted to leave immediately but she didn't."
    "She was turned on the moment she saw them, but she didn't want to admit it to herself."
    "The mixture of the girl's lewd moaning and the man's powerful thrusts made Banu wet down there."
    show banuseepublicsexfast
    play music2 "voices/slapmoanfast.mp3"
    b_ "Now he's fucking her even faster."
    b_ "Aren't they afraid of getting caught?"
    b_ "Her moan is getting lauder."
    b_ "He's fucking her so bad now. He's merciless..."
    scene v8-164 with dissolve
    stop music2
    b_ "I never thought I’d ever see something like this in our city! I can’t believe these two young people are doing this out in public."
    b_ "I shouldn’t be watching, but it’s unbelievable! "
    b_ "But why do I continue to stand here and watch? "
    scene v8-165
    "Banu finally tore herself away from the scene and turned around to walk home, confused by her reaction."

    scene black with dissolve
    with Pause(2)
    scene v8-94 with slideawayleft
    "Banu made it home and went to bed shortly after. She was exhausted after such a busy day and just wanted to go to sleep. "
    "She continued to think about the public sex she had witnessed. She couldn’t get it out of her head, and she hoped a good night’s sleep would push it from the front of her mind."
    b_ "I’m still turned on, and I’m not wearing a bra or panties right now which makes it worse. I could easily masturbate, but I just want to get some sleep. "
    b_ "I should fall asleep soon. I wonder if that couple is still going at it in the alleyway. "
    b_ "They looked like they were just getting started, but the way she took his big dick into her lips and sucked it, I’m not sure he could’ve lasted much longer…"
    "With that final thought, Banu drifted off to sleep."


    if banubad >= 5:
        play music "audio/sensual.mp3"





        scene v8-86 with Pixellate(3, 5)
        b_ " The bed feels softer than usual and the room is so hot. My body is burning. "
        b_ " I'm covered in sweat. I should take a shower now. "
        scene v8-87
        b_ " But I feel so weak. I don't think I can take a shower now. "
        b_ " I want to lay down more. I wish Kamil were here with me, to cuddle me... "
        b_ " But he's gone. He left me alone. Although, this feels good to be naked on the bed all alone, to feel free. "
        scene v8-88
        b_ " What is that noise? Footsteps? "
        b_ " Who could it be? "
        scene v8-89
        b_ " Hmm...I know them. "
        b_ " I knew they would come for me. "
        b_ " They were just waiting for the right time when Kamil is not home. "
        scene v8-90
        b_ " What if Kamil comes back and sees us? "
        b_ " I'd be too ashamed. "
        b_ " But these men are here now. They came for me. "
        b_ " I'm at their command now. I can't escape. "
        scene v8-91
        b_ " I can't stop moaning anymore. "
        b_ " The way their strong bodies press into mine... the way their hands touch my sensitive zones... "
        b_ "I'm going to cum so hard, but first..."
        scene v8-92
        b_ "Their dicks are so smelly."
        b_ "I love stroking them back and forth, up and down, again and again."
        scene v8-93
        b_ "I want to smell them, taste them."
        b_ "He's holding my head so strong and looking into my eyes."
        b_ "I know what he wants me to do."
        stop music
        scene black
        b "NO!"
        scene v8-95 with hpunch
        "Suddenly Banu sprang up, gasping for air."
        b_ "Oh… Oh God… a dream… it was only a dream."
        "She was covered in sweat, and her pussy was so wet it had soaked the bed. She was panting."
        b_ "Oh my… wow… it was so real… their cocks… "
    else:


        play music "audio/sensual.mp3"


        scene v8-86 with Pixellate(3, 5)
        b_ " The bed feels softer than usual and the room is so hot. My body is burning. "
        b_ " I'm covered in sweat. I should take a shower now. "
        scene v8-87
        b_ " But I feel so weak. I don't think I can take a shower now. "
        b_ " I want to lay down more. I wish Kamil were here with me, to cuddle me... "
        b_ " But he's gone. He left me alone. Although, this feels good to be naked on the bed all alone, to feel free. "
        scene v8-88
        b_ " What is that noise? Footsteps? "
        b_ " Who could it be? "
        scene v8-89
        b_ " Hmm...I know them. "
        b_ " I knew they would come for me. "
        b_ " They were just waiting for the right time when Kamil is not home. "



        stop music
        scene black
        b "NO!"
        scene v8-95 with hpunch
        "Suddenly Banu sprang up, gasping for air."
        b_ "Oh… Oh God… a dream… it was only a dream."
        "She was covered in sweat, and her pussy was so wet it had soaked the bed. She was panting."
        b_ "Oh my… wow… it was so real… their cocks… "




    scene black with dissolve
    with Pause(2)
    scene v8-123 with dissolve
    b_ "That was hot..."
    b_ "But this is so wrong. I was dreaming about such dirty things next to my husband. "
    b_ "What if I talked loud during sleep and Kamil heard me? I can't even imagine that."
    scene v8-124 with hpunch
    r "Talking to yourself again like a schizophrenic?"
    b "Oh...you...what are you doing here in the middle of the night?"
    r "I can ask the same to you."
    scene v8-125
    b "..."
    r "Did I startle you?"
    scene v8-126
    b "No. I didn't expect you to be here."
    r_ "Her ass shape is perfect. She can never cover it fully with clothes. It always shows itself. "
    r_ "One day I'll put my dick between those ass cheeks. Just wait for it."
    scene v8-127
    b "So why are you awake at this time?"
    r "None of your business."
    b "I don't understand why you are always rude. What is your problem?"
    scene v8-128
    r "You know the reason. That is because of the affair between you and your co-worker...what was his name...Turan."
    b "How many times should I tell you that Turan is only my co-worker and nothing else."
    if banu_turan == 3:
        b_ "He doesn't know Turan fucked me. I can never let Ruslan know about it. "
        b_ "Of course Turan drugged me last time. I would never let him touch me."
        b_ "But I can't let Ruslan suspect about it."

    if banu_turan == 2:
        b_ "He's not completely wrong about it. Remember what Turan did to me in the office last time."
        b_ "He almost made me cum by rubbing my pussy."
        b_ "He found my weak spots and used me. "
        b_ "But Ruslan doesn't know it. I can't let him suspect about it."

    r "You don't seem like you're telling the truth."
    b "You can believe it or not. I don't have to explain myself to you."
    if dinnerreddress == True:
        play music "audio/tension.mp3"
        r "But you'll have to explain one more thing."
        b "What do you mean?"
        r "Do you think that I'm stupid? I saw you two last time."
        r "You were making out with Polad in the kitchen behind my dad's back."
        scene v8-129 with hpunch
        b "What are you talking about you idiot! Polad just came to the kitchen to drink some water."
        scene v8-130
        r "He was kissing you and you were not resisting."
        r "Don't play like an angel. I know you're a slut doing dirty things behind my dad's back."
        r "By the way, I recorded the whole scene when he kissed you."
        menu:
            "Threaten him":
                $ renpy.block_rollback()

                $ banuthreatenruslan = True
                scene v8-131
                b "Listen! You'll keep your fucking mouth shut. You understood?"
                r "And why should I do that? I have my recording on my phone. I can show it to my dad anytime. You better..."
                b "Shut your fucking mouth I said!"
                b "You can't prove anything with that fucking video. If you show it to Kamil, I'll say he was trying to force me and that I kept it a secret because I didn't want him to get into trouble. "
                b "But you'll be the one who suffers for blaming me and calling me bad names."
                b "Now get out of my sight!"
                scene v8-132
                stop music
                r "You handled everything well. I didn't record anything, actually. I was lying."
                r "But now I know how evil you are. Be careful then."
                jump v9
            "Ask him what he wants":


                $ renpy.block_rollback()
                $ banuasksruslanwhathewants = True
                jump ruslan_blackmails_banu
    else:



        jump v9






label ruslan_blackmails_banu:
    scene v8-133
    stop music
    b "What do you want from me?"
    r "Look at that cute face. First you'll learn to talk with me in a right tone."
    scene v8-134
    r "Then you'll do exactly what I say without asking further questions."
    b "What are you going to do with that video?"
    r "I don't know. Maybe I can show it to my dad if you don't do what I say."
    scene v8-135
    b "You're lying. You're not brave enough to show something like that to Kamil."
    r "You want to find out if I'm brave or not, or do you want to get away with it?"
    scene v8-136
    b "Fine. Do whatever you want. I'm not afraid of it."
    b_ "He won't do that...He can't..."
    r "Do you know what my dad will do when he knows that you're doing dirty things behind his back?"
    scene v8-137
    r "He'll divorce you and throw you out."
    r "Do you still want to risk it?"
    b "What do you want?"
    scene v8-138
    r "Pull your shirt down and let me see your tits."
    b "What?!"
    r "You heard me."
    b_ "He's going to cause me trouble. I should get that video deleted."
    b "I'll do that, but you'll delete the video in front of my eyes."
    r "Deal."
    r_ "Stupid cunt."
    scene v8-139 with dissolve
    r "Hey, look at that little titty. Your nipples are fucking hard."
    r "You are turned on now, aren't you? I wonder what made you horny like this."
    b "Are you satisfied now?"
    scene v8-140
    r "Your titties don't get enough care I see. "
    r "Do you want me to touch them?"
    scene v8-141 with hpunch
    b "Take your hand away."
    b "Now grab your phone and delete the video right now."
    scene v8-142
    r "I didn't record anything, stupid. I lied to you."
    b "What?"
    r "You didn't ask to show the video to you first. You were so eager to show me your breasts. "
    b "You liar."
    r "I bet you enjoyed showing me your body."
    scene v8-143
    b_ "What have I done?"
    b_ "This is so embarrassing."
    b_ "I was so naive to believe in his words..."




    stop music
    stop music3

    $ renpy.end_replay()
    $ persistent.ruslan_blackmails_banu_unlocked = True
    jump v9
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
