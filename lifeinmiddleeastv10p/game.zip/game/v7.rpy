







label v7:

    $ banuturansexfirsttime = False
    $ banuhicranshower = False
    $ lesbian = 0
    $ banuturantrynottomoan = False
    $ banu_samir = 0



    scene black with fade
    centered "{size=+130}THE NEXT DAY{/size}" with dissolve
    scene black with dissolve
    with Pause(2)
    scene v7-1 with fade
    play music3 "sfx/office.mp3"
    "{i} {color=#526168} Banu had to focus on working with the intern this morning. {/color} "
    b "{i} {color=#526168} I continue to be pleasantly surprised with his performance, after thinking he was as useless as a stump on his first day. {/color} "
    b "{i} {color=#526168} It's taken him a damn hour to explain the new encryption tool he used to protect the files he was working on for me. Boys talk a lot on the subjects they specialize on. {/color} "
    b "{i} {color=#526168} I was wrong about Samir. He may have some value to this company after all. {/color} "
    b "{i} {color=#526168} It’s cute he’s trying to impress me with all this technical talk. {/color} "
    scene v7-2
    b "Samir, I’m proud of you. You’re really catching on fast."
    sam "Does this mean I’ll be hired full-time?"
    b "Slow down, young man. Your internship has ways to go."
    b "But so far, I’m happy with your performance."
    b "You need to work on your people skills more though."
    sam "I think my people skills are excellent."
    b "You’re confident, aren’t you?"
    scene v7-3
    sam "I wouldn’t have gotten this internship if I didn’t have people skills."
    b "True, but you have a lot to improve on."
    sam "How so?"
    stop music3
    scene v7-4
    b "Like, when I tell you that you need to improve your people skills, you shouldn’t disagree with me, as your supervisor. You should agree with me and ask me how you can improve."
    sam "But I don’t agree with you."
    b "Oh, Samir. You sound like my stepson. Are all young men stubborn these days?"
    b "Another thing, you give away too much in your behaviors."
    sam "What’s that supposed to mean?"
    b "Well, I can see you’re angry that I’m criticizing you right now. When you’re in negotiations, you should never show your true feelings. It’s like playing cards."
    sam "I don't play cards."
    b "I bet you still play video games."
    scene v7-4 with hpunch
    b "Oh please no! Not again!"
    scene v7-5
    sam "Again? You mean this has happened before?"
    b "They refuse to upgrade this elevator. It gets stuck so often."
    scene v7-6
    b "We’ll just have to wait. Sometimes it’s a quick fix."

    if banubad >= 3:
        b "{i} {color=#526168} I'm sure he doesn't mind being stuck in an elevator with the woman he has spent the past week masturbating over countless times. {/color}"



    scene v7-7
    b "{i} {color=#526168}He’s not so confident now, is he? {/color} "

    label banuinternelevatorchoices:


        menu:
            set menuset
            "Ask him about his personal life to kill the time":


                $ renpy.block_rollback()
                scene v7-7
                b "So tell me Samir, do you have a girlfriend?"
                sam "Err… um… no, not at the moment."
                b "At the moment? You must be some kind of player then."
                sam "I don’t want a girlfriend right now. It’s too much work and it’s expensive. I need to save money."
                b "{i} {color=#526168}Clever boy....At least he's telling the truth. {/color} "
                b "{i} {color=#526168} I wonder if he is a virgin.{/color} "
                scene black with fade
                with Pause(0.5)
                scene v7-7 with vpunch
                "{i} {color=#526168}Suddenly, the elevator turned on, causing both of them to jolt.{/color} "
                b "Time to get to work."
                b "Don’t worry, what we discussed in here will stay between us."
                sam "Ok, I understand, thank you."
            "Try to fluster him and make him uncomfortable":


















                $ banu_samir += 1
                $ renpy.block_rollback()
                scene v7-7
                b "{i} {color=#526168}Let's see how he will react if I stand a bit close to him.{/color} "
                scene v7-8
                b "Are you attracted to any girl in this company?"
                sam "I..."
                sam "{i} {color=#526168}Her perfume is so intoxicating, and her eyes are so alluring, I can hardly contain myself. I want her so bad, but I have to control myself. {/color}"
                sam "Yes...but I'm not interested in a serious relationship yet..."
                scene v7-9
                b "Be careful...Women can be ruthless in the business world. They’ll use you to get what they want."
                sam "Um… err… how so?"
                b "They’ll use their words..."
                b "They’ll use their minds..."
                b "They’ll use their… bodies."
                b "{i} {color=#526168}I have to admit that it feels good making him uneasy.{/color} "
                b "{i} {color=#526168}He could have plenty of pretty young girls his age, but he has a crush on me. It’s flattering.{/color} "
                scene v7-10
                sam "{i} {color=#526168}I know I have to behave, but...fuck it...I'll say it.{/color} "
                sam "Your body… it’s just… so hot."
                scene v7-11
                b "That’s not the right answer, Samir!"
                b "I’m your boss, and I’m a married woman twice your age."
                b "You’re going to be around many beautiful women in your business career."
                b "Learn to control your urges."


                b "{i} {color=#526168}Poor Samir...{/color} "





                scene v7-7
                jump banuinternelevatorchoices
            "Tease him":




                $ banu_samir += 1
                $ renpy.block_rollback()
                $ banubad += 1
                scene v7-7
                b "{i} {color=#526168}It’s obvious Samir has a crush on me. {/color}"
                b "{i} {color=#526168}Nesrin was right. I will tease him for fun. {/color} "
                b "{i} {color=#526168}I know I shouldn’t, but I want to see just how much he really desires me. {/color} "
                scene v7-13
                "{i} {color=#526168}Banu moved towards the elevator buttons and bent over a bit, causing him to scoot back a step. {/color} "

                b " Hm, you know, maybe I can push the emergency button to get this thing working. "
                b "Now… where’s that button?"
                sam "{i} {color=#526168}Holy shit! Look at her tasty ass. {/color} "
                scene v7-14
                b "I don’t think that button worked. I’ll try pushing some other buttons."
                "{i} {color=#526168}Banu couldn’t help but smile, knowing this boy is getting an eyeful. {/color}"
                "{i} {color=#526168} She bent over a bit more and shifted her weight from one leg to the other, which caused her ass to sway.{/color} "

                b "{i} {color=#526168}Why am I suddenly getting such a thrill from this?{/color} "
                b "{i} {color=#526168}I should be teaching him a lesson.{/color} "
                b "{i} {color=#526168}He’s no doubt looking at my ass. I have to admit that I want him to. I want him to like it. {/color}"
                b "{i} {color=#526168}Why does this make me feel so wicked good? I’m a married woman, and this intern is merely some boy who could be friends with my daughter. {/color}"

                "{i} {color=#526168}She bent over even more as she played with the elevator buttons! She couldn’t help but continue to keep a sly grin on her face. {/color}"

                b "{i} {color=#526168}I hope he’s hard. Really, really hard. Could this kid be as big as Kamil? Or bigger?{/color} "
                b "{i} {color=#526168}Oh my, what’s wrong with me? I’m being so bad. {/color}"
                b "{i} {color=#526168}But I want to see if he’s hard.{/color} "
                scene v7-15
                "{i} {color=#526168}She straightened up and peaked over her shoulder.{/color}"
                b "{i} {color=#526168}Sure enough, he’s staring at my ass and has a tent in his pants.{/color} "
                sam "{i} {color=#526168}Shit! She caught me. {/color} "
                sam "{i} {color=#526168}Wait, where is she looking...She noticed it for sure.{/color} "
                scene v7-16
                b "Enjoying the view, Samir?"
                sam "I...What do you mean?"
                b "Yes, I can see you enjoy it."
                "{i} {color=#526168}She briefly looked down at his crotch and smirked. {/color}"
                scene v7-12
                b "Aren't you afraid that I may report you? "
                sam "Please don’t report me. I’ll work so much harder for you, Mrs. Banu. I’ll be your best employee."
                b "{i} {color=#526168}So, he accepts that he looked at me.{/color}"
                b "If you do good work for me, Samir, you may get away with it."
                sam "Ok… I understand."







                scene v7-7
                jump banuinternelevatorchoices





    scene black with dissolve
    with Pause(3)
    scene v7-33 with fade
    play music3 "sfx/office.mp3"

    b "{i} {color=#526168}Now that I’m finished with Samir for today, I have some time to myself.{/color} "
    b "{i} {color=#526168}I need a break. It’s been nonstop today, so I deserve it. {/color}"

    b "{i} {color=#526168}So, what to do now? {/color} "
    b "{i} {color=#526168}I'll probably read some articles. {/color} "
    scene v7-34
    b "{i} {color=#526168}What should I enter for my search? {/color} "
    menu:
        "How to be a happily married couple?":
            $ renpy.block_rollback()

            scene v7-35

            b "{i} {color=#526168}There’s many wonderful articles on happy marriages. {/color} "
            b "{i} {color=#526168}It looks like communication is the biggest key to a happy marriage. {/color} "
            b "{i} {color=#526168}I can definitely improve in this area. {/color} "
            b "{i} {color=#526168}And of course, having sex is the best way show love for each other. {/color} "
            b "{i} {color=#526168}Why does my mind always go to Alper? My future is with Kamil, and he deserves my undivided love and attention. {/color} "
            if banubad >= 8:
                b "{i} {color=#526168}It’s damaging to our relationship when I tease other men or desire their attention or approval. {/color}"
                b "{i} {color=#526168}Kamil is the only man I want attention from. {/color}"
        "Cheating wives":






            $ renpy.block_rollback()

            scene v7-36



            b "{i} {color=#526168}It appears lack of sex is definitely the major contributor to an unhappy marriage. {/color} "
            b "{i} {color=#526168} Even women who love their husbands and are happy can be frustrated without sex. {/color} "
            b "{i} {color=#526168} I can’t believe all these articles and blogs about women who find sex outside of their marriage in order to be happy. {/color} "
            b "{i} {color=#526168} I could never have an open relationship with Kamil. {/color} "
            b "{i} {color=#526168} And these women who find sex by cheating… they’re disgraceful. {/color} "
            b "{i} {color=#526168}But why does that suddenly excite me? {/color} "
            b "{i} {color=#526168} I’ve been a good wife for all these years. I’ve never betrayed Alper and Kamil. But where has that gotten me? I’m still unhappy. {/color} "
            b "{i} {color=#526168}Maybe being good IS my problem.{/color} "
            if banukamilbedroomchoicesblabla == 2:

                b "{i} {color=#526168}I know I want to have sex. Masturbating isn’t enough anymore. But why doesn’t sex with Kamil excite me like these articles and blogs about women who sleep with other men? {/color} "
        "How to control men":




            $ renpy.block_rollback()
            $ domme += 1
            scene v7-37



            b "{i} {color=#526168}There are some impressive women in these articles and blogs about taking control of men. {/color} "
            b "{i} {color=#526168} It’s engrained in so many of us women that we need to be meek and submissive, but it doesn’t have to be like that. {/color} "
            b "{i} {color=#526168} It’s expected by Kamil and Ruslan that I’m just around to be a maid, but I’m tired of it. {/color} "
            b "{i} {color=#526168} I’m a businesswoman who has a University degree. I deserve to be respected. {/color} "
            b "{i} {color=#526168} Being a wife doesn’t mean I have to live a life of servitude to my husband. I’m a strong woman and I have choices. {/color} "
            b "{i} {color=#526168} I no longer want to live by some moral code that hasn’t brought me happiness. I want to do whatever excites me and makes me happy.{/color} "






    stop music3       

    scene black with dissolve
    with Pause(3)
    scene v7-17 with fade
    play music3 "sfx/bar.mp3"
    p "Sasha, I thought we counted all of those cases last night?"
    sa "I had Natasha count them because I had to fix the broken table."
    p "You know that’s a mistake having her do that. You know that she’s not used to it."
    guy "You’ll owe me more if you can’t find those cases. I’m sorry, but I’ll have to collect the money now."
    sa "Hold on, I’m sure there’s an explanation, I’ll check with Natasha."
    p "Damnit Sasha, I made YOU responsible for counting, not Natasha."
    scene v7-18
    nat "{i} {color=#526168}Poor Sasha. I know he’s getting blamed. {/color}"
    nat "{i} {color=#526168}And Polad looks angry. He’s so sexy when he’s mad. {/color} "
    nat "{i} {color=#526168}I can’t stop thinking about Polad. He’s everything I want in a man. Nobody has ever resisted me… Polad will NOT be the first. I’ll make sure of it. {/color} "
    scene v7-17

    p "Go out to his truck and bring in the new shipments, and then recount everything we stocked last night."
    sa "Everything?"
    p "Yes, everything. Cases of booze don’t have legs. They can’t just get up and walk away."
    p "The only way cases disappear is by being stocked at the bar… or by theft. And I’ll be a very unhappy man if there was theft."
    sa "I’ll go ask Natasha if..."
    p "No, your ass needs to get to work. I’ll question Natasha myself."
    scene v7-19
    sa "I’m going to be busy for the next few hours. Our count is off, and Polad needs me to recount everything."
    sa "You counted all those cases I told you to count last night, right?"
    nat "Of course I did. Why would you ever question me?"
    sa "Baby I know you did it right, but Polad isn’t sure."
    sa "I told him how smart you are though."
    scene v7-20
    nat "Awe, thanks for sticking up for me, my love. You’re such a great boyfriend."
    sa "And you’re the best girlfriend."
    sa "With the best ass."
    scene v7-21
    nat "Mmm… I can’t wait to give you my ass later tonight."
    nat "I’m so horny. I need you bad."
    sa "You’ll have me later, Nat. I have work to do, and Polad is going to question you on those cases."
    scene v7-22
    nat "Ok baby, I’ll see you later, and I’m sure it will be fine with Polad. I’ll work it out with him."
    sa "I’m sure you will."
    p "{i} {color=#526168}This slut probably messed up the count. {/color}"
    p "{i} {color=#526168} And she goes on making out with Sasha as if it’s no big deal. Fucking tease. {/color}"
    scene v7-23
    p "Back room. Now!"
    nat "Okay."
    nat "{i} {color=#526168}I like when he orders me..{/color} "
    scene black with dissolve
    stop music3

    with Pause(1)
    scene v7-24
    p "Sasha must’ve told you that-"
    nat "Yeah, yeah… I know, I know."
    nat "But the count is correct, I assure you."
    p "If the count’s correct, how the fuck did four cases go missing?"
    nat "They aren’t missing. I put them in the janitorial closet."
    "{i} {color=#526168}Without saying a word, Polad took out a cigarette and lit it. He slouched back into his chair and looked Natasha in the eyes. {/color}"
    scene v7-25
    "{i} {color=#526168}Instead of looking nervous, Natasha gave him a sultry, confident look. {/color} "
    "{i} {color=#526168}She placed her fingers lightly on her tight abs, and they seductively circled her bellybutton. {/color} "
    "{i} {color=#526168}Polad finally spoke after taking another pull off his cigarette. {/color} "
    p "Tell me, why did you do put the cases there?"
    nat "I knew the supplier was coming today and that you’d find out they were missing."
    p "You pissed me off on purpose."
    nat "Yes."
    nat "I knew you would take me back here to question me. That I’d have you all to myself… locked in a room."
    p "This must stop! You have a boyfriend. I have a wife."
    p "I’ve been pissed off all morning over these missing cases. This isn’t a game."
    "{i} {color=#526168}Natasha still looked at him with a mischievous grin and opened her mouth slightly. Her tongue softly moved across her full lips. {/color} "

    "{i} {color=#526168}Both of her hands left her belly… one moved up towards her breast and grabbed it, while the other trailed down her belly until her fingertips reached the top of her pants. {/color} "

    "{i} {color=#526168}She unbuttoned them and slowly pulled the zipper down.{/color} "
    nat "I’m such a bad girl, Polad. How can I ever make it up to you?"
    stop music






    scene black with dissolve
    with Pause(3)
    scene v7-38 with fade

    "{i} {color=#526168}It was the end of the day, and Banu was heading home from work when all of the sudden Turan appeared at the exit. {/color}"
    t "Banu, wait!"
    b "{i} {color=#526168}What could Turan possibly want? My headache has returned, and I just want to go home. {/color}"
    scene v7-39
    b "What is it, Turan?"
    t "The boss just asked me to turn in the memo for the PR85 job by tomorrow morning."
    b "Tomorrow morning? That’s not a lot of time. But why are you telling me this?"
    b "{i} {color=#526168}I hope I’m not roped into this memo.{/color} "
    t "I need your help."
    b "Are you crazy? I just finished for the day. This memo is your responsibility, not mine."
    t "I know it is, but you’re the expert on this. You know I can’t finish this on my own tonight."
    b "You have all the documents here?"
    t "No, unfortunately they’re all at my apartment."
    b "You want me to come over to your apartment?"
    t "Just to pick up the documents, and then you can leave."
    if banu_turan == 0:



        scene v7-40
        b "..."
        t "I can count on you, right?"
        b "Hmmph. Okay fine. Yes, you can count on me."
        b "I’m sorry for being difficult, I just have a bad headache and I don’t feel like myself."
        t "Banu, you’re my best employee. I’m so grateful for you. I’ll give you a ride."
        b "Okay, but let’s go, I don’t want to be up late tonight."
        scene v7-41
        t "I could never give this assignment to anyone else. You’re the best."
        b "Thank you. It makes me feel good to hear that."
        b "{i} {color=#526168} I shouldn’t be getting in Turan’s car and going to his apartment alone, but it’s only to pick up the documents. {/color}"
        b "{i} {color=#526168} I don’t need to notify Kamil, since I won’t be long. It’s best he doesn’t know where I’m going. I don’t want him to get upset.{/color} "
        b "{i} {color=#526168} Even though it’s nothing he should be concerned with... {/color}"
        scene v7-42 with fade
        play sound "voices/dooropen.wav"
        "{i} {color=#526168}They arrived at Turan's apartment.{/color} "
        b "{i} {color=#526168}He’s been standing close to me since we arrived. It’s a bit unnerving. {/color} "
        t "Sooo, do you like my apartment?"
        b "Yes, I definitely do. It looks very comfortable, and it has a very good view of the city."
        t "What can I get you to drink?"
        t "I know the perfect drink to make your headache go away."
        scene v7-43
        b "No thank you, and besides, I don’t drink alcohol."
        t "Of course, but I’m offering you coffee, not alcohol."
        b "Turan, it’s getting late, and I have a lot of work to do. Please give me the documents, and I’ll be on my way."
        scene v7-42
        t "I wanted you also to see my apartment and we have a nice chat. You know that I love spending time with you, Banu."
        b "You know that I’m a married woman, Turan. My husband wouldn’t appreciate this."
        t "You’re correct, I apologize."
        t "I'm getting the documents now."
        scene v7-44
        b "{i} {color=#526168}But I must say I really enjoyed his company, and it was neat to finally see his apartment.{/color} "
        b "{i} {color=#526168}Turan’s a kind and caring gentleman with a high self-esteem, but I hope he wants nothing more from me.{/color} "
        b "{i} {color=#526168}No doubt he has many women falling over for him.{/color} "
        b "{i} {color=#526168}I shouldn’t be mistaken for one of these women. {/color}"
        stop music




    if turandate == True:

        play music "audio/tension.mp3"


        scene v7-40
        t "I can count on you, right?"
        b "{i} {color=#526168}No...I can't go there again. Remember what happened last time in his apartment and later at work. {/color} "
        b "{i} {color=#526168}He's so tricky. I should stay away from him. But what if he's not lying?...I may get in trouble at work. Just think quick, Banu. {/color} "
        menu:
            "Reject him":

                stop music


                $ renpy.block_rollback()
                $ banuturansexfirsttime = False
                scene v7-40
                b "I’m sorry, but I have a bad headache, and I learned my lesson last time not to go to your apartment alone."
                t "Banu, you’re my best employee, please don’t disappoint me."
                b "{i} {color=#526168} I don’t trust his intentions. I’m not sure he’s being truthful to me.{/color} "
                b "{i} {color=#526168}Hmmm… I have an idea to determine his REAL intentions. {/color}"
                scene v7-39
                b "What if I call Kamil to come pick up the documents from you instead?"
                t "Why trouble your husband? I need to discuss the documents with you anyways."
                b "What if Kamil meets us at your apartment? We could discuss the documents together while he’s there."
                t "...Banu… it’s not appropriate to ask your husband to do this."
                b "{i} {color=#526168}That’s what I thought. If he really needed this done, he wouldn’t care if Kamil came with me. I’m not falling for his trap. {/color} "
                b "I know what stunt you’re trying to pull on me. But I won’t do it. Goodbye Turan."
                t "..."
                stop music
                jump kamil_doctor_scene
            "Go with him for the last time":



                $ banubad += 3

                $ banuturansexfirsttime = True
                $ renpy.block_rollback()
                scene v7-39
                b "{i} {color=#526168}It’s definitely risky to go over there again, but I hope he learned his lesson last time and won’t try to pull anything on me.{/color} "
                b "{i} {color=#526168}I did threaten him last time.{/color} "
                b "Hmmph. Okay fine."
                scene v7-40
                t "Banu, you’re my best employee."
                t "I’ll give you a ride."
                b "Okay, but let’s go, I don’t want to be up late tonight."
                scene v7-41
                t "I could never give this assignment to anyone else. You’re the best."
                b "Thank you."
                b "{i} {color=#526168}I shouldn’t be getting in Turan’s car and going to his apartment alone AGAIN, but it’s only to pick up the documents. {/color}"
                b "{i} {color=#526168}I don’t need to notify Kamil, since I won’t be long. It’s best he doesn’t know where I’m going. I don’t want him to get upset. {/color}"
                b "{i} {color=#526168}Even though it’s nothing he should be concerned with. Turan knows not to try anything with me again or I’ll report him. {/color}"
                scene v7-42 with fade
                stop music
                "{i} {color=#526168}They arrived at Turan's apartment.{/color} "
                b "{i} {color=#526168}He’s been standing close to me since we arrived. It’s a bit unnerving.{/color} "
                t "Sooo, what can I get you to drink?"
                t "I know the perfect drink to make your headache go away."
                t "{i} {color=#526168}And to help me finally get inside your married pussy.{/color} "
                b "I don’t drink alcohol, remember?"
                t "Of course, but I’m offering you coffee, not alcohol."
                b "{i} {color=#526168}I’m actually craving a cup of coffee for my headache.{/color} "
                b "Thank you Turan, I’ll have a cup."
                scene v7-44
                "{i} {color=#526168}As Turan went into the kitchen to fix a cup of coffee, Banu tried to relax.{/color} "
                b "{i} {color=#526168}This all seems eerily familiar. I’m afraid he’s going to come back with his shirt off and try to pounce on me. {/color}"
                b "{i} {color=#526168}I need to be alert.{/color} "
                "{i} {color=#526168}While Banu was sorting out her thoughts, Turan was crushing up a pill to put in her cup.{/color} "
                scene v7-48two
                "{i} {color=#526168}Turan came back with a hot cup of coffee and gave it to Banu, before telling her he would have to gather the documents in his room. She sat down on his posh couch and waited. {/color} "
                b "{i} {color=#526168}At least he’s still wearing his shirt. And he didn’t try anything on me. Perhaps he learned his lesson. {/color}"
                "{i} {color=#526168}After she rejected him last time, he wasn’t going to take any chances this time, so he bought a pill off of his good friend. {/color}"
                "{i} {color=#526168}He’d never used these pills before, but his friend swore that it was an aphrodisiac to help loosen girls up. It wasn’t guaranteed to work, but his friend suggested mixing it with caffeine to give it maximum effect. {/color}"
                "{i} {color=#526168}Poor Banu had no idea of Turan’s evil plan, as she sipped on the coffee while waiting for him. {/color}"
                b "{i} {color=#526168}I can’t believe it, but my headache is already gone. This coffee has done wonders for me.{/color} "
                b "{i} {color=#526168}It’s very relaxing to sit here and not have a pounding head. I’ll need this focus when I prepare the memo tonight. {/color} "

                b "{i} {color=#526168}I wonder what’s taking Turan so long? Kamil is going to start worrying about me again. {/color} "
                b "{i} {color=#526168}Oh my, I just had a hot flash go through me. That felt wonderful. Was it because I’m here alone with Turan? {/color} "
                b "{i} {color=#526168}Ohhh… another warm chill. It must be because I’m here at Turan’s. Ohhh my… what’s wrong with me… I feel hot all over. {/color} "
                b "{i} {color=#526168} I’ll definitely have to masturbate tonight. Mmmmm… that sounds nice… sooo nice… in the hot shower… {/color} "
                b "{i} {color=#526168} But first I need to leave here. I almost forgot that I’m sitting here at Turan’s. I should’ve known better than to come here. After what happened last time. {/color} "
                b "{i} {color=#526168} Though, I can’t deny that being held in Turan’s arms was exciting. {/color} "
                b "{i} {color=#526168} And he saw my boobs. I wonder if Turan liked what he saw… if they compared to his other women. He almost put his mouth on them too. {/color} "
                b "{i} {color=#526168} Nooo… I shouldn’t think about that. I’m so confused… What’s going on with me? I need to get up and leave. {/color}"
                scene v7-48 with hpunch
                "{i} {color=#526168}Nearly in a panic, Banu abruptly got up and woozily walked towards the front door before Turan accosted her. {/color}"
                t "Where are you going?"
                b "I’m going to be late… I need to..."
                b "{i} {color=#526168}I’m feeling flush. {/color}"
                b "Er… do you have the documents, Turan? I need to leave."
                b "{i} {color=#526168}I can feel myself trembling with him so close. But why is he gripping my arm?{/color} "
                b "{i} {color=#526168}He smells amazing. His grip is so strong too. {/color}"
                if banukamilbedroomchoicesblabla <= 1:
                    t "I have the documents in the other room, let me take you there."
                    b "Ok, but once I get the documents I’m leaving."
                    "{i} {color=#526168}Banu turned to follow Turan and realized she was woozy, disoriented… and suddenly horny. {/color}"

                    jump kamil_doctor_scene




                stop music



label kamil_doctor_scene:
    scene black with dissolve
    with Pause(3)


    scene v7-75 with fade

    doc "...premature ejaculation is a very common problem, Kamil. You shouldn’t be ashamed of it. I can’t tell you how many healthy patients of mine who can’t get ‘it’ up"

    scene v7-76

    k "It’s so strange, I didn’t have this problem before my mid-twenties."

    k "It started to happen after that age."

    scene v7-77

    doc "I see this is acquired premature ejaculation."

    doc "There are different causes to this problem, both psychological and biological."

    doc "Stress is the main reason that causes this dysfunction, but of course after we analyze your body, we‘ll be able to give you the right diagnosis."

    scene v7-76

    k "You know doctor, I have to fix this problem as soon as possible because… you know I just started to build the relationship with my wife… you know what I mean."

    scene v7-77

    doc "Hmmm…I totally understand you. The relationship between partners may also contribute to the issue."

    doc "So be comfortable with each other and spend more time together. And one thing more, have sex a lot. This is the psychological approach to the issue."

    doc "Other factors may include infections and hormone levels, but we’ll check that."

    scene v7-76

    k "I hope this problem will be cured soon doctor."

    scene v7-77

    doc "Don’t worry. This is a curable problem, but you and your wife will both act together to solve this properly."

    k "She’s always by my side..."

    stop music

    if banuturansexfirsttime == True:
        jump turan_fucks_banu
    else:


        jump poland_fucks_natasha



label turan_fucks_banu:




    scene black with dissolve
    with Pause(3)
    scene v7-49 with fade
    play music "audio/tension.mp3"
    "{i} {color=#526168}Banu’s lips mashed with Turan’s lips as he skillfully removed her shirt. {/color} "
    "{i} {color=#526168}Turan had unbuttoned his own shirt and told her to touch his chest. {/color} "
    "{i} {color=#526168}She hesitated for a moment before placing her right hand on his pectoral muscle. As if someone else was controlling her, she rubbed her hand all over his chest while he nibbled on her neck. {/color}"
    "{i} {color=#526168}Soon after, her hand had moved its way to his abs and she instinctively caressed them. {/color} "
    "{i} {color=#526168}She suddenly came to her senses and removed her hand, but before she could protest, he attacked her mouth with his lips. {/color} "
    "{i} {color=#526168}She only put up a weak resistance as his tongue snaked its way into her mouth.{/color} "
    "{i} {color=#526168}After a minute of Turan assaulting her mouth with his tongue, she finally showed some real resistance and pulled her face away from his. {/color} "
    scene v7-50
    b "Turan, put me down. We’ve gone too far. I need to leave."
    t "We’re just getting started. I’m going to make you a happy woman and give you what you need."
    "{i} {color=#526168}Turan moved his lips down to her chest and began to lick, making his way towards her breasts. {/color}"
    b "No… stop… uughhh."
    b "{i} {color=#526168} Why does this feel good with his tongue on my skin? My body is failing me… I’m not able to resist this terrible man’s touch.{/color} "
    "{i} {color=#526168}Her left hand instinctively moved to hold his head while he assaulted her with his tongue. {/color} "
    b "I admit that feels good, Turan, but you must put me down."
    "{i} {color=#526168}Much to Banu’s surprise, he let go of her. {/color}"
    b "{i} {color=#526168}For once, he listened to my request. {/color}"
    "{i} {color=#526168}Banu wanted to run away, but she remained paralyzed, confused at her body’s reaction. {/color} "
    "{i} {color=#526168}Before she knew it, he began to remove her pants. Much to her dismay, she inexplicably let it happen. {/color} "

    scene v7-51
    b "Turan! You must stop now. We-"
    "{i} {color=#526168}He resumed assaulting her chest with his tongue, and his hands moved to her thighs and butt, caressing and squeezing them. {/color} "

    b "{i} {color=#526168}I’m speechless. I can’t believe my body’s reaction to his touches. I didn’t realize how much I’m craving a man’s strong hands on my body. {/color} "
    b "{i} {color=#526168} What am I doing? I can’t think such things.{/color} "
    b "{i} {color=#526168} I have a husband! I cannot do this.{/color} "
    b "No… no, we can’t."
    scene v7-52 with hpunch
    "{i} {color=#526168}Before she could finish her objection, Turan forcefully grabbed her and tackled her onto the bed.{/color} "

    "{i} {color=#526168}His hand grabbed her pussy, causing her to shriek. And before she knew it, he was kissing her… and she wasn’t resisting. {/color} "

    b "Mmmmphhhh.."
    t "Yes, Banu, give in to your urges."
    t "You know this is what you’ve always wanted."
    b "Mphh… mmmm… No.."
    b "I don’t want you. You’ll never have me."
    b "Let me go. You’ve had your fun."
    "{i} {color=#526168}She turned her head away from him and turned her hips to deflect his hand from touching her vagina. He paused in thought for a moment, and then he spoke.{/color} "
    t "So that’s how you want to play it? You’re a fighter, Banu, I’ll admit."
    t "But I want you more than anything. And I know deep down you want me. So, I’m going to give you a test."
    scene v7-53
    "{i} {color=#526168}He suddenly grabbed her wrists and got on top of her. She was confounded when she saw him pull handcuffs out of his pocket. {/color} "
    b "Wha… what’s going on? Turan?"
    b "What are you doing?!"
    b "Let me go! You’re crazy!"
    "{i} {color=#526168}He cuffed both of her wrists to the bed and got up to leave the room.{/color} "
    scene v7-54
    b "Turan! You’ll never get away with this! Let me go!"
    b "{i} {color=#526168} I want to scream, but my mind is numb.{/color} "
    "{i} {color=#526168} She couldn’t do anything but lay still, handcuffed to the bed, awaiting his return. {/color}"
    scene v7-55
    t "I’m going to make a deal with you."
    t "I think I can make you cum in five minutes, just by using my mouth on your body."
    b "I don’t want to play your games. Let me go!"
    t "I don’t think you have much of a choice, do you?"
    b "If you let me go, I won’t tell anyone what happened here."
    t "I’ll let you go… but only after you pass the test."
    t "Five minutes, with only my mouth. If you don’t cum, I’ll let you go. I swear it."
    b "You’re ridiculous. You can try anything you want, I’ll never cum for you."
    scene v7-56
    "{i} {color=#526168}Turan climbed onto the bed and placed the clock on the mattress. {/color}"
    t "At 19:30 I’m going use my mouth on your body. If by 19:35 you don’t cum, I’ll let you go home."
    t "But, here’s the catch. If you cum in those five minutes… I will fuck you as my reward."
    b "You’re an animal! You should be ashamed at the horrible things that go through your brain."
    t "Do we have a deal?"
    b "{i} {color=#526168}Do I really have a choice? It’s only five minutes… that’s nothing. I can play his stupid game for five minutes and then go home.{/color} "
    b "Fine, but you better let me go after five minutes."
    t "My dear Banu… I love that you’re a fighter. That’ll make this all the sweeter when you surrender."
    b "Don’t count on it."
    scene v7-57
    t "Ah, I see it’s time to start."
    b "{i} {color=#526168}There’s no chance I will cum for him, is there? I’ve never orgasmed under five minutes, not even in the comfort of my own shower! {/color}"

    scene v7-58
    b "{i} {color=#526168}I’m a bit worried about my body’s reaction… I can’t deny I enjoyed his tongue on my skin and his kisses on my neck. {/color}"
    b "{i} {color=#526168}Oh well, I’ll just need to be confident and try not to think about what’s happening. Think about how wrong this is. {/color} "
    scene v7-59
    b "Go on then, you pig."
    t "The way your eyes look at me… I see a wildcat hiding inside you."
    t "And your sweet lips… you’re amazing, Banu."
    b "{i} {color=#526168}I shouldn’t listen to him! I know what he’s trying to do. I need to be strong… just close my eyes and think about something else. {/color}"
    t "Your belly is so tight… I dream about your belly often."
    b "{i} {color=#526168}Don’t listen to him. {/color} "
    b " I will enjoy your failure after five minutes. "
    scene v7-60
    play music2 "voices/makeout.mp3"
    "{i} {color=#526168}Turan proceeded to stick his tongue in her bellybutton. {/color}"
    b "{i} {color=#526168} Mmmmm… oh that tickles… ohhh… I shouldn’t make a sound… I shouldn’t think about this…{/color} "
    b "{i} {color=#526168} It tickles… but I shouldn’t make a sound… I shouldn’t think about this…{/color} "
    b "{i} {color=#526168}My body… what’s happening to me???{/color} "
    scene v7-61
    "{i} {color=#526168}He kissed around her belly and then licked his way up to the gap between her breasts.{/color} "

    t "I couldn’t believe how spectacular your tits were when I saw them. They’re beautiful."
    b "{i} {color=#526168}Good… I had hoped he liked my breasts last time.{/color} "

    b "{i} {color=#526168}But I shouldn’t listen to him! I need to think about something else.{/color} "
    b "{i} {color=#526168}Damn, how much time is left?{/color} "
    scene v7-62
    b "{i} {color=#526168}Three more minutes… nooo… please hurry. {/color}"
    b "{i} {color=#526168}His kisses feel sooo good. Why is my body reacting like this?{/color} "
    b "{i} {color=#526168} I won't be able to keep my voice anymore.{/color} "
    b "Aggghhhh…"
    scene v7-63
    b "What are you doing!"
    t "I want to see them again."
    scene v7-64 with hpunch
    b "Ahhh… no.."
    t "They’re so lovely."
    b "{i} {color=#526168}Don’t get more aroused... please don’t.{/color} "
    b "{i} {color=#526168}But… the cool air on my nipples feels amazing… they’re aching to be touched...{/color} "
    b "{i} {color=#526168} ...which is why I can’t let him.{/color} "
    b "No… that wasn’t part of the-"
    scene v7-65
    b "Agghhh… Oohhhh..."
    "{i} {color=#526168}He attacked her tits with his mouth and sucked on them. While he sucked, his tongue went swiftly back and forth on the tips of her nipples. {/color}"
    b "{i} {color=#526168}If he continues like this... {/color} "
    "{i} {color=#526168}His next move was to nibble and chew on them.{/color} "
    b "Ooohhhh… uuhhhh… Turan… Ohhhh"
    b "{i} {color=#526168} I’m so wet right now… but I’m not going to cum. I won’t cum. {/color}"
    scene v7-66
    t "It’s time to give you what you’ve been wanting."
    b "{i} {color=#526168}What is he...{/color} "
    b "{i} {color=#526168}Oh no, he’s taking off my panties!? {/color}"
    b "Noooo! What are you doing? That wasn’t part of the deal!"
    t "I told you mouth only… and that’s exactly what I’m going to do."
    b "{i} {color=#526168}He never said he was allowed to do such a thing.{/color} "
    b "You can’t do-"
    scene v7-67 with hpunch
    "{i} {color=#526168}Once Turan removed her panties, he grabbed her ankles and forcefully pushed them back over her head. This enabled him to attack her pussy with his mouth at the best angle possible. {/color} "
    b "Ooooooohhhhh nooooo!"
    b "You… no… Turan…!"
    scene v7-68
    b "Aaghhhhh… ohhhhh…. Oooowww… Ahhhhh.."
    b "{i} {color=#526168}I can’t control it… I can’t help it.{/color} "
    b "{i} {color=#526168}I’ve never felt like this before. {/color}"
    b "Ohhhh… Aggghhhh… Nooo..."
    b "{i} {color=#526168} It’s coming… Oh no Banu… NOOOO!!! Don’t… let… it… happ-{/color} "
    scene v7-69
    b "Aagggghhhhhhh!!!!! Oooohhhhh!!!"
    b "{i} {color=#526168}Oh no, I’m cumming! Nooo!{/color} "
    b "Ughhhhhh… ohhhhhhh!"
    "{i} {color=#526168}Banu’s body uncontrollably shook and withered on the mattress as she orgasmed. {/color}"
    b "Ahhhh… Ahhhh… ahhhh.."
    b "{i} {color=#526168}I’m failing, but I can’t help it... my body can’t control it and it feels amazing.{/color} "
    b "Ahhhhhhhh… Uhhhhh… ooohhhh.."
    "{i} {color=#526168}The time wasn’t up until after she had climaxed. She lost the bet.{/color} "
    "{i} {color=#526168}Her orgasm passed through and he happily lapped up her juices. Once it finished, he smirked at her as he removed his pants and stood on the bed between Banu’s legs. {/color}"
    scene v7-70
    t "You’re all mine now."

    t " You put up a good fight, but you lost in the end."
    b "{i} {color=#526168}I failed. I can’t believe that just happened. My body failed me. My mind failed me.{/color} "
    "{i} {color=#526168}Banu continued to lay in a daze with her legs over her head as she watched Turan and his cock above her.{/color} "
    b "{i} {color=#526168} It’s as beautiful as I’d ever imagined it would be. {/color}"
    b "{i} {color=#526168} He’s about to fuck me with that thing and I can’t stop it. {/color} "
    scene v7-71
    "{i} {color=#526168}Before he properly stuck it in her, he laid his big penis on top of her cunt, and then he stroked it back and forth. {/color}"

    b "{i} {color=#526168}He’s trying to get me aroused again even though I just came. {/color}"
    b "{i} {color=#526168}I have to be strong… I can’t let him break my spirit by giving in to him completely. {/color}"
    scene v7-72
    b "{i} {color=#526168}But that’s nearly impossible. I can’t keep my eyes off his big dick and the way it caresses my pussy lips. It feels incredible. {/color} "
    b "{i} {color=#526168}Surely he would have no trouble sliding right in with how wet I am. {/color} "
    t "You want it bad, don’t you?"
    "{i} {color=#526168} She wasn’t able to look him in the eyes. She continued to lay on her back with her legs up and mouth gaping open, as she watched him rub his penis back and forth on her sex. {/color} "

    b "{i} {color=#526168} I can feel his balls repeatedly tapping my anus when he gives long strokes. My anus aches to be touched, just like the rest of my body. {/color} "
    t "Tell me Banu. Tell me what you want me to do."
    "{i} {color=#526168}She couldn’t respond in her current hypnotized-like state, so she remained motionless and quiet. {/color} "

    t "You want me to fuck you now… I know this… don’t be shy."
    "{i} {color=#526168}Suddenly Turan plunged his big cock into Banu’s quivering pussy.{/color} "

    show turanbanusexanimation
    play music2 "voices/slapmoanmedium.mp3"

    b "Uggghhh! Oh no, Turan it’s too big!"
    t "Relax, just let me get a bit deeper."
    b "Oooww… uhhhh…. Oooohhhhh!"
    t "You’re not used to having a man inside you Banu. You need to get used to my size."
    b "Ohhh… ugghhh… it’s… biiiig.."
    t "You’re lubing up already… your body loves it… see, it’s sliding in good now."
    b "Aahhhh… Ahhhh… uggghhhh"
    t "It feels so tight."
    t "I knew your pussy would be warm and tight. I imagined it would feel like this the first time I met you."
    b "Aaahhh… Ahhh… ohhh"
    t "I knew back then I’d be fucking you eventually, even though you were married."
    t "You were a tough one, but I knew you’d submit to me."
    t "Go on, submit to me, Banu."
    b "Ugggh… Ughhh"
    t "Move your hips… fuck me back."
    b "Aggghhhhh… Ahhhhhh… Ughhhh"
    t "Good, woman. Keep moving those hips."
    "{i} {color=#526168}Banu was in such a trance that she couldn’t think straight. Her body was in full control. {/color}"
    b "Ugghhhhhhh… oooooohhhh!!"
    b "{i} {color=#526168}I’m going to cum again soon. I need to hold back. I can’t submit to him again!{/color} "
    t "Tell me Banu, tell me you want it. You’re moaning, I know you want it."
    b "{i} {color=#526168}I can’t let this vile man take all my dignity. {/color} "
    b "{i} {color=#526168}But it feels so good… being bad feels good. {/color}"
    b "{i} {color=#526168} I don’t know if I should fight or give in... {/color} "
    menu:
        "Try not to moan":
            $ banuturantrynottomoan = True
            $ renpy.block_rollback()
            b "{i} {color=#526168} I need to shut my mouth and not moan. He can fuck me, but I won’t let him see me enjoying it.{/color} "
            b "{i} {color=#526168} I won’t give him that satisfaction.{/color} "
            t "I see you’re a fighter until the end. That’s disappointing. We’ll see if you can keep that up forever. This won’t be the last time I fuck you."
            show turanbanusexanimation2
            play music2 "voices/slapmoanfast.mp3"
            "{i} {color=#526168}Turan continued to fuck her mercilessly for what felt like an eternity for Banu. He thoroughly enjoyed watching her squirm and whimper while he pounded her relentlessly. {/color}"
            "{i} {color=#526168}He wanted her to cum, but she wasn’t cooperating. Turan’s stamina was otherworldly, but he had grown impatient and had to cum, so he finally pulled out. {/color} "
            stop music2
        "Tell him to fuck you harder":





            $ banuturantrynottomoan = False
            $ renpy.block_rollback()
            b "{i} {color=#526168} It feels so good having his big cock inside me. Now I know he was right when he said that I needed this. {/color} "
            b "{i} {color=#526168} I’ve never cum twice before, not even with Alper.{/color} "
            b "{i} {color=#526168} But Turan is proving me wrong. I want his big cock to make me cum over and over again. {/color} "
            b "Oh yes Turan, fuck me harder!"
            b "Make me cum again, you pig!"
            show turanbanusexanimation2
            play music2 "voices/slapmoanfast.mp3"

            t "Mmm, that’s good, Banu. You’re mine now."
            b "Ughhhh!! Ohhh!! Fuck me harder!! Harder."
            t "I knew you would submit to me."
            b "Yes! Yes! Ohhh yes!"
            b "{i} {color=#526168} I’m cumming again! It feels unbelievable.{/color}"
            b "OOOHHHH! YESSSS!!! UGGGHHH!"
            b "YESSSS!!! AGGGHHH!!"
            b "Give me more, Turan… mmm… don’t stop fucking me."
            "{i} {color=#526168}Turan continued to fuck her mercilessly for what felt like an eternity for Banu. He thoroughly enjoyed watching her moan and yell for him to fuck her harder while he pounded her relentlessly. {/color}"
            "{i} {color=#526168}He made her cum several more times, a feat she never could’ve imagined. Turan’s stamina was otherworldly, but he needed to cum and couldn’t take holding back any longer, so he finally pulled out. {/color}"
            stop music2


    scene v7-73 with hpunch
    play sound "voices/moanfinish.mp3"

    "{i} {color=#526168}His cock spewed ropes of cum onto Banu’s belly. {/color} "
    t "Oooohhh fuck… fuck… your pussy is soooo good Banu."
    "{i} {color=#526168}He continued to stroke his meat and spew globs of cum on her. She watched in awe at the eruption. {/color}"
    b "{i} {color=#526168} I can’t believe how much cum he has! And he lasted so long inside me… how’s that possible?! {/color}"
    b "{i} {color=#526168}He’s a machine! But thankfully he’s done.{/color} "
    scene v7-74
    "{i} {color=#526168}As Turan left the bed, Banu glanced at the clock. {/color}"
    b "{i} {color=#526168} He’s been fucking me for an hour. That can’t be possible. How did I… how could… I... {/color}"
    stop music
    $ persistent.turan_fucks_banu_unlocked = True
    $ renpy.end_replay()


    jump poland_fucks_natasha_dis





label poland_fucks_natasha_dis:
    scene black with dissolve
    p "This is temporary dialog"
    scene black with dissolve
    jump poland_fucks_natasha






label poland_fucks_natasha:


    scene black with dissolve
    with Pause(3)
    show backroomfuck with fade
    play music "audio/hardsex.mp3"
    play music2 "voices/moaning.mp3"
    nat "Oh yes Polad!"
    nat "Yes fuck me good!"
    nat "I’m such a bad girl!"
    nat "Fuck me!"
    p "You wanted it, you slut."
    nat "Ohh... да да да."
    p "You’re getting it."
    nat "I wanted it so bad. I want more."
    nat "Give it to me! Cum for me!"
    p "Not yet."
    p "I want you on your knees with your dirty mouth on my cock first."
    scene v7-26
    stop music2
    nat "You want me on my knees… like this?"
    nat "So I can suck on it?"
    nat "Mmm… your cock is amazing."
    nat "My pussy already misses it."
    p "Stop talking and suck on it already."
    show backroomblowanimation
    play music2 "voices/bj.mp3"
    p "Good girl."
    p "You suck it so good."
    nat "Mmphh… you’re the boss."
    nat "I’ll suck your cock anytime you want."
    p "You shouldn’t. Your mouth belongs to Sasha. Do you know that?"
    nat "Mmhmm, but, mmm, you can still have it."
    nat "...mmm… whenever you want."
    stop music2
    scene v7-27
    "{i} {color=#526168}Polad suddenly pulled her head off his penis and stood her up. {/color}"
    p "Listen to me."
    "{i} {color=#526168}He grabbed her throat, startling her. But she welcomed the forceful attention.{/color} "
    p "Now you will get your punishment for being a slut girlfriend."
    p "But don't forget that you belong to Sasha and I have a wife."
    p "After I finish fucking you, we’re done. This never happened."
    nat "Go on then, finish fucking me, stud."
    scene v7-28
    nat "You’re so strong. You fuck me so much better than Sasha."
    nat "I love being fucked by a real man."
    nat "Come on, fuck me harder!"
    nat "Fuck me like a real man!"
    "{i} {color=#526168}Polad picked her up and sat her on the table.{/color}"
    scene v7-29
    p "You horny slut, you asked for it. "
    p " I’m going to fuck you hard now. "
    p " This is what you get for playing games with me, misplacing those cases. "
    nat "Oh да! да! да!"
    nat "This is exactly what I wanted when I did that!"
    nat "Ugh! Oh! Yes! Ugh!"
    nat "I’m cumming so hard! Cum for me!"
    nat "Cum for me at the same time!"
    p "Arrghh… ughh..."
    p "...Take it then, you slut..."
    nat "Yes! Give it to me!"
    nat "Ohhh!!! Ugghh"
    "{i} {color=#526168} Polad unloaded inside Natasha while she withered and moaned uncontrollably.{/color} "
    "{i} {color=#526168}She came on his cock while he erupted.{/color} "
    scene v7-30
    "{i} {color=#526168}When Polad pulled out, there was cum everywhere, especially oozing out of her vagina. After all the moaning and dirty-talking, Natasha was suddenly quiet.{/color} "
    p "{i} {color=#526168}I just fucked this young beauty, but I feel empty. {/color} "
    p "{i} {color=#526168}Any man would be so lucky to have a girl like Natasha begging for him. {/color} "
    p "{i} {color=#526168}But I can't take Banu out of my mind. Why she attracts me so much?{/color} "
    scene v7-31
    stop music
    p "I mean it. This isn’t going to happen again."
    p "Bring the cases out front. You’ll explain to Sasha and the supplier that it was a mistake. That you misplaced them."
    nat "And I’ll leave out the part where you punished me for it."
    p "That’s right. Keep it quiet, or Sasha and you will be living on the street faster than you can blink."
    p "And no more fucking around on Sasha. He’s your boyfriend. I’m nothing to you but your boss."
    scene v7-32
    $ renpy.end_replay()
    $ persistent.poland_fucks_natasha_unlocked = True
    jump poland_fucks_natasha_continue

label poland_fucks_natasha_continue:

    nat "Okay, but you know you can’t find a pussy this young and hot anywhere else."
    nat "I belong to Sasha, but you can have me anytime you want."
    "{i} {color=#526168} She winked and left the room.{/color} "
    stop music

    scene black with dissolve
    with Pause(3)

    if banuturansexfirsttime == False:

        scene v7-78 with fade
        b "{i} {color=#526168}So many things continue to go through my head. It’s hard to sort out the men in my life. {/color} "
        b "{i} {color=#526168}What are their intentions? Who can I trust? {/color} "
        b "{i} {color=#526168} The one constant is Kamil. I can trust him. He should be the only true man in my life. {/color} "
        b "{i} {color=#526168} But I don’t know if that excites me? Why is it so hard to figure out? {/color} "
        scene v7-79
        b "{i} {color=#526168} Sometimes Kamil surprises me and makes me think I have a great future with him. {/color} "
        b "{i} {color=#526168} It’s finally time I move past Alper. I’m so tired of being eaten up by guilt and anxiety. {/color} "
        b "{i} {color=#526168} Can Kamil still be a wonderful husband for me and truly win over my soul? {/color}"
        b "{i} {color=#526168} So… Goodbye, Alper. You were my everything, but I’m FINALLY moving on with my life. {/color} "
        stop music



    if banuturansexfirsttime == True:

        scene v7-80 with fade
        b "{i} {color=#526168} What have I done? {/color} "
        b "{i} {color=#526168} I’m now an unfaithful wife. Deep down I knew I shouldn’t have gone to Turan’s apartment, so why did I? {/color} "
        b "{i} {color=#526168} I never thought I’d submit like that. Is Turan that skilled, or did he put something in my coffee? {/color} "
        b "{i} {color=#526168} I’d never felt like that… it was as if I had no control. {/color} "
        b "{i} {color=#526168} I have no doubt that animal put something in my coffee. If I was drugged, can I really be blamed? {/color} "
        scene v7-81

        b "{i} {color=#526168} Oh, Kamil. My sweet husband. I’m so sorry. {/color}"
        b "{i} {color=#526168} I’m a fool. How could I be such a fool? {/color} "
        b "{i} {color=#526168} Maybe this will go away fast. I can forget about it right now, and Kamil never has to know. {/color} "
        b "{i} {color=#526168} I’ll stay away from Turan. {/color} "
        b "{i} {color=#526168} But no matter what, I’m a terrible wife. I’m no longer the same pure woman I once was.{/color} "
        stop music

    scene black with dissolve
    with Pause(3)
    centered "{size=+150}MORNING{/size}" with dissolve
    scene v7-82 with fade
    play music "audio/chill.mp3"

    b "{i} {color=#526168} I really need a fresh start today after all the stress going through my head lately. {/color} "
    b "{i} {color=#526168} Exercise is probably the best way to reduce stress, so I was glad when Hicran messaged me to invite me on a jog. {/color} "

    b "{i} {color=#526168} Yes, jogging this morning would be the ideal way to begin shedding my anxieties. {/color} "
    b "{i} {color=#526168} Besides, I always like wearing my cute jogging outfits. {/color} "
    scene v7-83
    b "{i} {color=#526168} I must say my legs look fabulous in these pants. It’s too bad Kamil isn’t here to see me. {/color} "
    b "{i} {color=#526168} Jogging will tone my butt and make it even more lethal. {/color} "
    b "{i} {color=#526168} Hopefully Hicran notices I’m still as shapely as I was back at University. {/color} "
    b "{i} {color=#526168} And who knows, I might turn a few heads on the jog. {/color} "
    b "{i} {color=#526168} I know that’s not the way a married woman should think, but how long will I be able to do this before I’m too old? {/color} "
    scene v7-84

    "{i} {color=#526168} Banu had to wait for Hicran longer than anticipated, but she finally arrived, and they stretched. {/color} "

    "{i} {color=#526168} Banu was a bit jealous… Hicran’s outfit was sexier than hers. Here she thought she’d be the one turning heads.{/color} "
    hic "Girl, you look so cute in those pants."
    b "Truthfully, I’m feeling inadequate when looking at you. I’m wearing a jacket after all."
    hic "Oh stop it, you’d look amazing in my outfit. In fact, you should buy one like this and we can match when we jog together."
    b "I couldn’t wear that. I can’t imagine what my husband would say if I showed off my belly and breasts like that in public."
    b "Besides, my boobs aren’t in the same league as yours."
    scene v7-85
    hic "Well, that’s hardly your fault."
    hic "One of the few benefits of having an old, rich husband… he’ll pay for a lift anytime I need one."
    b "Well, I haven’t received any complaints about mine, so I’m happy with them."
    hic "I bet you haven’t..."
    "{i} {color=#526168} As Hicran said this she glanced down at Banu’s boobs and winked, causing Banu to blush. {/color}"
    b "{i} {color=#526168}She’s become a very bold woman over the years. {/color}"
    hic "But… mine kind of annoy me sometimes, like when I’m jogging! Speaking of… let’s get on with it."
    scene v7-86 with fade
    "{i} {color=#526168} They started jogging around the city. It was beautiful this morning, but there weren’t many people outside. {/color} "

    b "{i} {color=#526168} It feels great to sweat a bit, and my muscles are cooperating at this pace. I’m able to take my mind off everything.{/color} "

    b "{i} {color=#526168}Although, Hicran seems a lot more fit than me. Working in an office all the time has made me stiffer than I’d like. {/color} "
    scene v7-87
    "{i} {color=#526168} Eventually, Hicran kept increasing the pace to the point where Banu couldn’t keep up.{/color}"
    hic "Come on, Banu, push yourself."
    b "I’m trying, but remember, I’m not quite in shape like you."
    hic "Don’t worry, we’re almost to my husband’s villa."
    b "But I thought we were jogging a loop, so that I can go home afterwards?"
    hic "I want to show you it! Let’s go!"
    b "{i} {color=#526168}I have stuff to do today, but it doesn’t appear she’s taking no for an answer...{/color} "
    scene v7-88
    "{i} {color=#526168}Eventually they stopped outside of a café near Hicran’s husband’s villa. Banu was exhausted, but she felt great and healthy to have gotten exercise this morning. {/color}"

    hic "I’m proud of you, Banu. You worked hard, and if you keep it up, I’ll be the one having to catch up."
    b "Oh I don’t know about that, but I do feel great. I realize I need to get more exercise."
    hic "Especially as we age… these figures we have won’t last forever."
    hic "And we need to keep these bodies sexy… in order to make men bend to our will if we need them to… or, if we want to make them happy when they use us for their pleasure."

    scene v7-89
    b "{i} {color=#526168} I never remembered her being so bold! What happened to the shy girl I used to know? Is this how I’d be if I hadn’t ever met Alper so young.{/color} "
    b "Hicran, stop it. I’m a married woman and can’t think about other men."
    hic "I was referring to your husband in your case. But… hmm, does this mean you ARE thinking about other men?"

    b "No, stop it, that’s not what I meant."
    hic "Hmm… okay, I’m not sure I believe you, but never mind that, let’s go to the villa before it gets too late."
    if banubad >= 7:
        b "{i} {color=#526168}She’s perceptive… I immediately thought of the other men in my life when she said that. But I can’t tell her that. {/color} "


    scene v7-90
    hic "...it has its own movie room…"
    b "It sounds wonderful, I can’t wait to see inside. You’re very lucky."
    b "{i} {color=#526168}So why does she hate being with her husband and want to flee him when she has everything she needs? {/color} "
    b "{i} {color=#526168}And she cheats on him… would she lose everything if he finds out? I wonder how she’d feel then, without all of this luxury?{/color} "
    hic "...and the heated whirlpool is amazing. You have to try it! We should get in it after I give you a tour of the villa."
    b "That does sound nice, but I’m going to be behind schedule as it is, and I have things to do. I’m going to have to hurry back home, so that I can shower and change."
    hic "That’s nonsense, you can just shower here, and I can provide you clothes."
    b "Well, I..."
    hic "I have many clothes that will fit you, don’t worry! Just relax and have a nice, hot shower."
    b "But...is your husband home?"
    hic "No. Don't worry. He will come home late. You are so shy like in University years."
    b "Um… okay."
    stop music
    scene v7-91 with fade
    play music3 "sfx/shower.mp3"
    "{i} {color=#526168}After Hicran gave Banu a tour of the villa, she escorted her to the bathroom where Banu could shower. {/color} "
    "{i} {color=#526168}The whirlpool was in there too, so Hicran filled the tub up so that she could use it later. She then retreated to find a change of clothes for Banu. {/color} "
    "{i} {color=#526168}But Hicran was aching to get in the whirlpool, so she figured she could sneak back into the bathroom while Banu showered. She removed her clothes and quietly entered. {/color}"
    hic "{i} {color=#526168}Banu is such a proper lady, I’m not sure she’d appreciate me sneaking in here to take a bath. But she’d get over it. This is my bathroom, and besides, she needs to loosen up a bit. {/color} "
    hic "{i} {color=#526168} I wonder how shocked she’ll be seeing me naked. I don’t think she ever saw me naked. {/color} "
    hic "{i} {color=#526168} But, I saw her… I used to spy on her in the gym shower back at University. {/color} "
    hic "{i} {color=#526168} She had such a sexy body. Everything about her posture oozed sexiness, in an innocent kind of way. {/color} "
    hic "{i} {color=#526168} I wonder if her body looks the same? {/color} "
    scene v7-92
    $ banuhicranshower = False

    "{i} {color=#526168} She decided to peep on her before getting into the whirlpool. {/color} "
    hic "{i} {color=#526168} This reminds me of those days when I’d spy on her, before I’d run off to masturbate thinking about it. {/color} "
    hic "{i} {color=#526168} It was my first real experience having feelings for another woman. She was just so happy, beautiful, and sexy. I couldn’t help it. {/color} "
    hic "{i} {color=#526168} Seeing her lather up in the gym shower and hum tunes to herself, when she thought nobody was looking. It was soooo hot. {/color} "
    scene v7-93
    hic "{i} {color=#526168} And here I’m finally doing it again after all these years. {/color} "
    hic "{i} {color=#526168} And she’s just as lovely as she was back then. {/color} "
    hic "{i} {color=#526168} Oh God, I’m becoming wet. I want to touch myself. {/color} "
    hic "{i} {color=#526168} But that would be too much for Banu to comprehend. {/color} "
    scene v7-94

    hic "{i} {color=#526168} I’ll touch myself in the whirlpool once she leaves. For now, I’ll just enjoy the show. {/color} "
    hic "{i} {color=#526168} If I can contain myself. {/color} "
    scene v7-95 with hpunch
    b "Hicran! What are you doing in here?"
    hic "It’s my bathroom, I’m free to come in here. I couldn’t wait to take a bath."
    b "But…"
    hic "{i} {color=#526168}She’s so shy, trying to cover herself, but she has no reason to be shy around me. I’m a trusted friend… and I can be more than a friend for her if she wants. {/color}"
    b "..."
    hic "I know you’re in a hurry, so let me come wash your back for you."
    menu:
        "Decline her offer":

            $ renpy.block_rollback()
            $ banuhicranshower = False
            b "I’m sorry, Hicran. I know you’re a dear friend, but I can’t do anything like that."
            hic "I understand, Banu, don’t worry… just relax."

            scene v7-96
            hic "I’ll go get your change of clothes before I get in the tub."
            hic "{i} {color=#526168} Damn, she’s shyer than I thought. What a shame… we could have a lot of fun together.{/color} "
            b "{i}{color=#526168} She’s definitely not the same Hicran I once knew.{/color} "
            stop music3
        "Don't say anything":



            $ lesbian += 1
            $ banubad += 1
            $ banuhicranshower = True
            jump hicran_soaps_banu


    jump hicran_soaps_banu_continue

label hicran_soaps_banu_continue:

    stop music3
    stop music


    jump v8

label hicran_soaps_banu:
    play music "audio/sensual.mp3"
    $ renpy.block_rollback()

    b "{i} {color=#526168} I can’t believe I’m suddenly in this position. Here I thought I was just going on a jog with Hicran. But now she wants to get in the shower with me. {/color}"
    b "{i} {color=#526168}The right thing to do would be to tell her ‘no’, but I’m tired of doing the right things. {/color}"
    scene v7-97
    hic " I’ll take that as a ‘yes,’ hah. "
    scene v7-98
    hic "You’ve always had such magnificent skin. It’s so silky."
    hic "I can’t believe how much you’ve retained your figure all these years later."
    b "Coming from you, that’s very flattering. You’ve really blossomed over the years and look great."
    scene v7-99
    b "{i} {color=#526168} She’s very skilled at lathering up my back with soap… it’s so sensual. My tension is melting to her touch. I never realized a female’s touch could feel this way.{/color} "
    b "{i}{color=#526168} I don’t know what to think… I’m conflicted because I’m aroused now. I had these same feelings with Nesrin recently. {/color}"
    scene v7-100
    hic "Next time we can get into the whirlpool, and I’ll give you a more… thorough… cleaning."
    "{i} {color=#526168} After she said this, she moved closer to Banu and pressed into her bottom. Banu could feel her pubic hairs tickling her bare skin.{/color} "

    "{i}{color=#526168} Hicran breathed onto her neck, causing goosebumps all over.{/color} "
    b "{i} {color=#526168} I'm so wet all of the sudden, and not from the shower. All because of a woman’s touch…{/color} "
    b "{i}{color=#526168} ...this is too much to process right now, and besides, I have to get going.{/color} "
    b "Hicran, I must go, now."
    scene v7-101
    hic "Yes, of course."
    hic "I’ll go get your change of clothes before I get in the tub."
    if banubad >=7:
        b "{i} {color=#526168} I feel like I’ve turned into a different person. I’ve been battling my urges with men lately, and now all of the sudden I have urges with women! {/color}"
        stop music3
    $ renpy.end_replay()
    $ persistent.hicran_soaps_banu_unlocked = True
    jump hicran_soaps_banu_continue
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
