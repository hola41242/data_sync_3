

label ask1:
    show black


    menu:
        "Play introduction":





            jump introduction
        "Skip introduction":


            jump day1
        "Meet characters":


            jump characters




label introduction:
    play music "audio/intro.mp3"


    scene intro1 with Fade(0.5, 0.5, 5)

    $ banu_ruslan = 0
    $ banu_kamil = 10
    $ banu_turan = 0
    $ banu_nesrin = 0
    $ banu_polad = 0
    $ leyla_ruslan = 0
    $ leyla_kamil = 0
    $ banubad = 0
    $ domme = 0
    $ kamilbeta = 0
    $ lust = 0
    $ turandate = False
    $ spykamil = False
    $ ruslanargument = False
    $ turandate = False
    $ streetguys = False
    $ threesome = False
    $ murat = False
    $ humiliatingseyhun = False
    $ ahmedtease = False
    $ murattease = False
    $ dinnerreddress = False
    $ banukamilbedroomchoicesblabla = 0
    $ samirtease = False
    $ banukamilsexfirsttime = False




    b "{i} {color=#526168}I've had a lot of obstacles and hardships in my life. Especially after my parents' death.{/color}"
    b "{i} {color=#526168} I've never seen my real parents. I grew up in the orphanage till those kind hearted couple adopted me. {/color}"
    b "{i} {color=#526168}After they passed away, I was alone and helpless, I had to somehow survive in this cruel world.{/color} "
    b "{i} {color=#526168}I had options, options that plagued me at the time. {/color}"
    b "{i} {color=#526168}But I feel I've always made the right choices.{/color}"
    scene intro2
    b "{i} {color=#526168}I've always been intelligent, and I was accepted into a University with a goal in mind: I would become a business lady.{/color}"
    b_ "I also speak english and russian."

    b "{i} {color=#526168}But my goals were altered when I met the love of my life during my last year as a student. His name was Alper. {/color}"
    b "{i} {color=#526168}I was so lucky that I found the right person who understood and took care of me.{/color}"
    scene intro3
    b "{i} {color=#526168}We had a lot of pleasant memories together...{/color}"
    b "{i} {color=#526168}... {/color}"
    scene intro4 with Pixellate(3, 5)
    b "{i} {color=#526168}I didn't understand how time could pass so quickly when we were together.{/color} "
    scene intro5
    b "{i} {color=#526168}I was very happy with him.{/color} "
    scene intro6
    b "{i} {color=#526168}After only three months, he asked me to marry him. You couldn't believe how happy I was. I'd never felt those emotions before. {/color} "
    b "{i} {color=#526168}We got married and had our cute baby, Leyla, shortly after. We were very young, but we wanted to have a big family and not wait. {/color}"
    scene intro7
    b "{i} {color=#526168}My happiness didn't last long. Alper died in a car accident. My life collapsed around me. Everything I felt, everything I thought... it was all meaningless.{/color} "
    scene intro8
    b "{i} {color=#526168}After two years of grieving, I met a man named Kamil. He was a kind man. Besides, he was also widowed, and knew exactly how I felt. He had to raise his son, Ruslan, and I knew he was a good dad. {/color}"
    b "{i} {color=#526168} We decided to get married shortly after. {/color} "
    b "{i} {color=#526168}Yeah, everything happened so quickly only because of Leyla. She was just 2 years old when her father died. I didn't want to raise her without the care of a father. {/color}"
    b "{i} {color=#526168}Moreover, Kamil is a nice gentleman who knows how to treat a woman. {/color}"
    b "{i} {color=#526168} But sadly, despite how wonderful a man he was, I wasn’t in love and I feared I’d never be able to fall in love again. How could I betray Alper? He was everything to me.{/color} "
    scene intro9

    b "{i} {color=#526168}We’re currently living together in his apartment with Leyla and Ruslan.{/color} "
    b "{i} {color=#526168}This year Leyla started at a University. Time really passed so quickly. I hope I raised her well enough all these years for her to take care of herself now, to be a woman. {/color}"

    b "{i} {color=#526168}Now’s the first time in my life where I have time for myself, no longer raising the kids. It’s been a very strange adjustment, and it makes me feel old, even though I look young.{/color} "

    b "{i} {color=#526168}I know Kamil is still attracted to me, which makes me happy. Even though I fear I’ll never love him back, I selfishly don't want to imagine him with another women. It would hurt me too much. I still want to be with him forever.{/color}"

    b "{i} {color=#526168}I've been completely and utterly unfair with him. He deserved affection from me, even just a little. I died the moment Alper died... but I realized that I need to keep going, for this sake, and for mine.{/color} "
    b "{i} {color=#526168}... {/color}"
    scene intro10
    b "{i} {color=#526168}I need to give Kamil a chance. What other man could be this patient and love me without being loved in return?{/color} "
    b "{i} {color=#526168}From now on I will have to make serious decisions that could significantly alter my life, for better or for worse.{/color} "
    scene intro11
    b "{i} {color=#526168}I hope I will make the right decisions that will lead me to a happy life. {/color}"
    b "{i} {color=#526168}... {/color}"
    scene black with Fade(0.5, 0.5, 5)
    stop music
    jump day1
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
