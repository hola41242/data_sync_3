


label day4:
    show black

    centered "{size=+150}DAY 4{/size}" with dissolve
    scene black with dissolve
    with Pause(1)
    scene day4-1 with dissolve
    "{i} {color=#526168}Banu had such a terrible headache that morning. {/color}"
    "{i} {color=#526168}She wasn’t sure if she could attend work today. {/color}"


    scene day4-2
    b "{i} {color=#526168}It seems this headache is never going to leave me alone.{/color} "
    b "{i} {color=#526168}A cup of good coffee always helps...{/color} "
    scene day4-3
    b "{i} {color=#526168}I have so many things to do at work, including having to deal with that new intern. {/color} "

    b "{i} {color=#526168}I'm not working in a company where one can have a day off whenever. They pay attention to attendance. {/color}"

    b "{i} {color=#526168}But I'm not sure if I can work in this condition. I can't decide... {/color}"

    b "{i} {color=#526168}Dammit, there’s no way I can miss. It's my only job. I can't risk it.{/color} "
    "{i} {color=#526168}There was a chance of losing her job so, she decided not to risk it... {/color}"
    scene day4-4 with fade
    play music3 "sfx/office.mp3"
    "{i} {color=#526168}She busied herself with the paperwork she had left from yesterday. {/color} "
    "{i} {color=#526168}When she entered the room for the interns, she saw Samir was waiting for her. {/color}"

    b "You look energetic today. So, tell me, how are you?"

    scene day4-5

    sam "Thank you, Mrs. Banu. I'm doing well here."

    b "You did a really good job delivering the files on time. To be honest, I wasn't expecting that."

    sam "Actually, I've started getting used to the friendly environment here, and the work is not so hard. I'd be very lucky to get a full-time job here."

    scene day4-6

    b "Who knows what will happen. If you continue like this, your dream may come true."

    "{i} {color=#526168}While Banu was talking, Samir's eyes unconsciously drifted to Banu's chest as he imagined what her naked tits looked like. He forced himself to concentrate again so he wouldn’t get a hard-on at work... {/color}"


    b "Now, let's talk about work."

    sam "Sure."

    scene day4-7 with dissolve

    b "You did everything correctly, exactly as I told you. This time you will need to submit that information in the form of a table like the table here."

    scene day4-8

    b "This should be easy for you."

    sam "This looks easy, but it will probably take a lot of time to find all the information."

    b "Don't worry. I'll send you a list of sites which will save you time."

    scene day4-9



    "{i} {color=#526168}It was the first time that Samir was so close to Banu. {/color}"

    "{i} {color=#526168}He was trying to look down her top and admire the shape of her breasts, while smelling her perfume and wondering if her panties smelled good too. {/color}"


    "{i} {color=#526168}He was dreaming of having her in his arms, and he wanted this to continue forever. {/color}"

    "{i} {color=#526168}He let himself enjoy the situation until he realized that he had gotten an erection... {/color}"

    scene day4-10

    sam "I'm sorry for interrupting, Mrs Banu. Can I leave for five minutes?"

    scene day4-11

    "{i} {color=#526168}His erection was obvious. {/color}"

    scene day4-12 with vpunch

    "{i} {color=#526168}She saw the shape of the bulge in his pants right after she turned her head. {/color}"

    "{i} {color=#526168}She couldn't answer him immediately as that condition confused her a little bit.{/color}"

    "{i} {color=#526168}It took her a bit long to answer back... {/color}"

    menu:
        "Sure you can":






            $ renpy.block_rollback()

            scene day4-12

            b "But don't be late. We have things to do here."

            sam "Of course, Mrs. Banu."

            scene day4-13
            b "{i} {color=#526168}It’s obvious he’s going to the WC to fix his bulge. {/color}"
            b "{i} {color=#526168}I can’t help but think him being close to me caused his erection. {/color}"





            stop music3
        "I have not finished yet":








            $ lust += 1



            $ renpy.block_rollback()

            $ banubad += 1

            scene day4-12

            b "{i} {color=#526168}It’s obvious him being so close to me was the reason for his erection. {/color}"

            b "{i} {color=#526168}I want to embarrass him a bit and enjoy his awkward condition.{/color}"

            b "Don't be in such a hurry. Let me finish telling you a few things before I forget. Sit down please."



            sam "Okay..."

            scene day4-14

            b "You know, I have a very bad memory. Most of the time, I forget to remind you of the important things."

            b "Starting tomorrow try to come before 8 AM. If you can finish your work by the afternoon, you may deliver additional tasks by email."


            sam "Sounds good to me. Thank you....Mrs. Banu."

            scene day4-15

            b "Why don't you just call me Banu?"

            sam "I think..."

            scene day4-16

            b "And try to wear something more comfortable. We don't have any dress code here."

            b "The weather is getting hotter day by day."

            "{i} {color=#526168}Banu was talking in a seductive way while looking at Samir's shirt and jeans... {/color}"

            scene day4-17

            sam "You're right..."

            "{i} {color=#526168}Samir was so embarrassed and was trying to cover his crotch with his right hand while talking.. {/color}"

            "{i} {color=#526168}His erection was getting even harder while talking to Banu. He couldn’t help but look down at her tits, as if she were inviting him to do so with where her hand was placed. {/color}"


            b "Well, you can go now. But don't take long. We still have to do some work here."


            sam "Okay..."

            "{i} {color=#526168}He slowly stood up and walked towards the door while covering his crotch. {/color}"

            scene day4-18

            sam "{i} {color=#526168}She must have done this on purpose. She wanted to embarrass me. {/color}"

            sam "{i} {color=#526168}We will see... {/color}"

            "{i} {color=#526168}Banu watched as he left the room with a smile on her face. {/color}"
            b "{i} {color=#526168}Is he going to masturbate in the WC, and if he does, will he be thinking of me? {/color}"


            stop music3







    scene black with dissolve
    with Pause(2)
    scene day4-19 with fade
    play music "audio/romantic.mp3"

    "{i} {color=#526168} Kamil came home after a few hours of work. {/color}"

    "{i} {color=#526168}He has a part-time job as a real estate agent, so he was often at home in the afternoons.{/color}"


    scene day4-20 with dissolve



    k "So, you're not working today?"
    k "You came home early."



    b "I asked for permission today. My head is absolutely killing me so..."



    k "Wow. That’s so unlike you to ask permission from work. It must be really bad. Are you feeling better now?"

    b "Yeah, it’s much better since I got home, but I’m exhausted and don't know why."

    scene day4-21

    k "I think you’re working too much. That must be the reason behind it. You need some time to relax."

    b "Yeah, that's true."

    k "Well, since you have time today, and feel better, let's go out. We'll walk and visit some coffee shops maybe. It'll be good for you."

    scene day4-22

    b "It sounds good, but what about the meal I’ve started to prepare?"

    scene day4-23

    k "Don't worry, we should go out for a change."

    b "Well, it's actually a good idea. Let me change my clothes then."

    scene day4-24

    k "Whatever you wear, you always look beautiful."

    b "Thank you..."



    scene black

    "{i} {color=#526168}They walked for some time in the city and finally ended up in Kamil's favorite coffee shop... {/color}"

    scene day4-25 with irisin
    stop music
    play music3 "sfx/coffee.mp3"

    k "Let's sit there next to the window, what do you say?"

    b "I'll let you choose."

    scene day4-26

    "{i} {color=#526168}They slowly walked towards the table in the corner, next to the window. {/color}"

    scene day4-27

    "{i} {color=#526168}Kamil and the server, Humay, kept looking at each other for some time... {/color}"
    "{i} {color=#526168}They met before he married Banu. Humay was looking for an apartment for a temporary stay, and Kamil did a lot of work as a real estate agent to find a comfortable option for her. {/color} "




    "{i} {color=#526168}However, the relationship between them was not only about business. {/color}"

    "{i} {color=#526168}They started meeting and fucking in Humay's newly rented apartment. But when Humay moved to a new apartment due to her new job, they promised not to meet again and forget about what happened between them... {/color}"

    scene day4-28 with dissolve

    b "This is a really nice place."

    k "Yeah, this is my favorite. They also have a room for playing chess at the back."

    b "Interesting..."

    scene day4-29 with dissolve

    "{i} {color=#526168}It didn't take too long for Humay to approach them with a suspicious look on her face... {/color}"

    scene day4-30

    h "Welcome, can I take your orders?"

    k "Hello. We'll have two skinny lattes and please with no foam. "

    "{i} {color=#526168}While taking orders, Humay couldn't stop herself from staring at Kamil, thinking about their past. {/color}"

    h "Okay."

    scene day4-31

    "{i} {color=#526168}She smiled and slightly winked at Kamil..{/color} "

    scene day4-32

    "{i} {color=#526168}Banu saw how Humay looked at Kamil. From her reaction it was obvious that she didn’t like what she saw. {/color}"

    b "I don't like her at all. That smile on her face makes me angry."

    scene day4-33

    k "Take it easy, Banu. It's their job to be nice to their customers."

    k "It's the part of their marketing to hire beautiful ladies to smile at customers' faces."

    scene day4-34

    b "But she knows that we're a couple, and it's not an acceptable behavior to smile on a man's face like that in front of his wife. "

    k "My dear, it's just..."

    scene day4-35



    "{i} {color=#526168}While Kamil was explaining something, Banu's eyes drifted towards the stranger who was sitting opposite to her.. {/color}"

    scene day4-36

    "{i} {color=#526168}That stranger was looking directly at Banu with a flirtatious smile. {/color}"

    menu:
        "Banu keeps looking at him":






            $ banu_kamil -= 1

            $ murat = True

            $ kamilbeta += 1

            $ renpy.block_rollback()



            scene day4-37

            "{i} {color=#526168}Banu kept looking at him for several minutes unconsciously. {/color}"

            "{i} {color=#526168}He was a handsome young man. {/color}"

            "{i} {color=#526168}She had no idea who the young man was and what he was hiding behind the smile he was giving her. {/color}"

            scene day4-38

            b "{i} {color=#526168}He’s so mysterious. Have I met this man somewhere before? No, he’s a complete stranger. {/color}"


            " {i} {color=#526168}During these minutes, Banu was totally ignoring what Kamil said to her.{/color}"

            "{i} {color=#526168}She came to her senses finally after Kamil raised his tone a little... {/color}"



            scene day4-39

            k "Banu, are you okay?"

            b "Yeah, I just got carried away a little bit."

            k "Sorry, I need to go to the WC, just two minutes.."

            b "Sure.."



            scene day4-40 with dissolve



            "{i} {color=#526168}On the way to the bathroom, Kamil passed the counter and saw Humay tending to their order. He decided to say hello, to be courteous, especially since Banu wasn’t with him at the moment. {/color}"
            "{i} {color=#526168}He pushed aside his thoughts that she was very attractive, even standing with her back to him. {/color}"





            scene day4-41

            k "Long time no see. I don’t see you working here often, and when I do, you’re always busy. It’s good to say hello after all this time."


            scene day4-42

            h "Yes. It’s a small world and a small city. It’s very nice to see you again."
            k "How’s your apartment going?"
            h "Now that I’ve had this job for a while, I have enough money to upgrade to something larger."
            k "Oh, congratulations! You have my contact info if you need some help finding an upgrade."
            h "Thank you. I may do that soon."
            k "Well I better get going. Maybe we’ll talk soon."









            scene day4-46 with dissolve

            "{i} {color=#526168}Without waiting much, the young man stood up and approached Banu with quick steps.. {/color}"

            scene day4-47

            mur "Hello."

            b "Hi..."

            mur "You fully drew my attention the minute you sat here."

            mur "My name is Murat, and I’m a journalist. My company is organizing interviews with religious women and collecting their ideas about religion, clothing and so on."



            mur " When I saw you, I thought you might be interested in this. "

            scene day4-48

            b "I'm sorry, but I really don't have time for things like this."

            mur "If this time is the only problem, we can arrange a more suitable time for you."

            scene day4-49

            b "I don't think my husband will allow me doing stuff like that."

            mur "I'm afraid you've got it wrong. We don't show your face or reveal your identity. We only collect ideas."

            b "It sounds interesting... I would love to help you, but..."

            scene day4-50

            mur "I’m sure that you can find the time and get your husband's agreement on this.."

            b "I'm not sure.."

            scene day4-51

            mur "So, please, take this. You can call me any time to get information about the interview."

            mur "There's also the company's name and website address on it. You can check and find any information you would need to make your decision."

            b "Okay. We will see."

            mur "See you soon."


            b "Bye.."

            scene day4-52

            b "{i} {color=#526168}I’m confused. {/color}"

            b "{i} {color=#526168}Collecting ideas? Was that his only reason for approaching me? {/color}"

            b "{i} {color=#526168}I'm not so sure... something about his smile tells me otherwise. But either way, he’s an interesting man.{/color}"


            scene day4-53

            k "Our lattes will be ready soon..."
            stop music3
        "Banu concentrates on the conversation":











            $ murat = False

            $ renpy.block_rollback()

            $ banu_kamil += 1



            scene day4-34

            "{i} {color=#526168}She simply ignored the guy as if there was nobody there... {/color}"

            scene day4-39 with dissolve

            k "Sorry, I need to go to the WC, just two minutes.."

            b "Sure.."

            scene day4-40 with dissolve
            "{i} {color=#526168}On the way to the bathroom, Kamil passed the counter and saw Humay tending to their order. He decided to say hello, to be courteous, especially since Banu wasn’t with him at the moment. {/color}"
            "{i} {color=#526168}He pushed aside his thoughts that she was very attractive, even standing with her back to him. {/color}"


            scene day4-41
            k "Long time no see. I don’t see you working here often, and when I do, you’re always busy. It’s good to say hello after all this time."








            scene day4-42
            h "Yes. It’s a small world and a small city. It’s very nice to see you again."
            k "How’s your apartment going?"
            h "Now that I’ve had this job for a while, I have enough money to upgrade to something larger."
            k "Oh, congratulations! You have my contact info if you need some help finding an upgrade."
            h "Thank you. I may do that soon."
            k "Well I better get going. Maybe we’ll talk soon."

            scene day4-46 with dissolve

            "{i} {color=#526168}Without waiting much, the young man stood up and approached Banu with quick steps.. {/color}"

            scene day4-47

            mur "Hello."

            b "Hi..."

            mur "You fully drew my attention the minute you sat here."

            mur "My name is Murat, and I’m a journalist. My company is organizing interviews with religious women and collecting their ideas about religion, clothing and so on."



            mur " When I saw you, I thought you might be interested in this. "

            scene day4-48

            b "I'm sorry, but I really don't have time for things like this."

            mur "If this time is the only problem, we can arrange a more suitable time for you."

            scene day4-49

            b "I don't think my husband will allow me doing stuff like that."

            mur "I'm afraid you've got it wrong. We don't show your face or reveal your identity. We only collect ideas."

            b "It sounds interesting... I would love to help you, but..."

            scene day4-50

            mur "I’m sure that you can find the time and get your husband's agreement on this.."

            b "I'm not sure.."

            scene day4-51

            mur "So, please, take this. You can call me any time to get information about the interview."

            mur "There's also the company's name and website address on it. You can check and find any information you would need to make your decision."

            b "Okay. We will see."

            mur "See you soon."


            b "Bye.."

            scene day4-52

            b "{i} {color=#526168}I’m confused. {/color}"

            b "{i} {color=#526168}Collecting ideas? Was that his only reason for approaching me? {/color}"

            b "{i} {color=#526168}I'm not so sure... something about his smile tells me otherwise. But either way, he’s an interesting man.{/color}"




            scene day4-53 with dissolve

            k "Our lattes will be ready soon..."
            stop music3









    stop music



    scene black with dissolve



label leyla_rape_scene:

    scene day4-54 with fade

    sey "Do you see that? It's so complicated. It overwhelms me. "

    l "Come on, it's not complicated. You should just read it carefully."

    scene day4-55

    l "You should also practice reading with a timer. That will have a great effect on your speed. "

    sey "I've never used a timer before."

    l "I see..."

    scene day4-56

    sey "Do you know that you're the best one among our group mates?"

    sey "You're so kind to everybody, and you've helped me a lot doing these boring home tasks."

    scene day4-57

    l "You're exaggerating."

    sey "No I'm not. You've been so kind to me."

    sey "Believe me, Leyla, you're the nicest girl at the university. I can't help but stare at you all the time. You're so attractive."

    l "Hehe, all men say that, but thank you."

    sey "I don't say nice words about any girl. Only for you."

    l "Thank you so much, Seyhun, I'll take it as a compliment."



    sey "But I didn't mean to just compliment you."

    scene day4-58

    l "Anyway, it’s late already. I better go now."


    sey "You're so shy. I don't want you to go..."

    scene day4-59

    sey "It’s just the two of us. Let's enjoy this moment."

    l "I told you, Seyhun, I only like you as a friend and you know that. There’s nothing between us. Now, please, let me go."


    sey "I'm addicted to you. You know that?"

    l "Stop it. This is never going to happen."

    sey "Just come here..."

    scene day4-60

    l "Ahhh, heyy take your dirty hands off me, you pig."

    sey "Don't you dare move. You’re mine now."

    l "Fuck off!"
    if agressive == True:
        play sound "voices/slap.mp3"


        scene day4-61 with hpunch


        l "AAAhh"

        sey "I said you’ll be mine."

        scene day4-62

        l "Ohh God, please, help me."

        sey "Stop shouting. Nobody’s going to hear you."

        l "Don't do that, please."

        sey "Shut up. You’ll enjoy this after a few minutes."

        scene day4-63

        l "God, pleasee, nooo."

        sey "Let's see what’s inside."

        l "Help meee, please..."

        scene day4-64

        sey "I said shut up and accept that your body is mine now."

        l "I’m choking, ohh…"

        scene day4-65

        sey "Come on. Don't you enjoy it?"

        sey "Stop resisting. You know that you’ll succumb to me in minutes."

        scene day4-66

        "{i} {color=#526168}Seyhun didn't waste any time and quickly stripped off Leyla's jeans. {/color}"

        scene day4-67

        sey "I've been wanting to do this for 5 months now. "

        l "Seyhun, please, let me go. What you are doing is so wrong."

        sey "No way I’m going to let you go before I fuck your virgin pussy and make you mine."

        scene day4-68

        l "You’ll answer for this."

        l "Now let me go before it’s too late."

        sey "It’s too late, sweetie, you know that. "

        scene day4-69 with hpunch

        play music2 "voices/moaning.mp3"

        l "AHHHHH.."

        "{i} {color=#526168}Seyhun grabbed her hands and pressed his body on top of her's, so that she couldn't move. {/color}"

        "{i} {color=#526168}She resisted with all her power left, but her body was so light and weak against Seyhun's heavy body.{/color}"

        "{i} {color=#526168}Seyhun showed her no mercy and immediately entered her with a powerful thrust. {/color}"

        show leylarapeanimation

        sey "You see? You’re not resisting anymore."

        l "Ooohhh!"

        "{i} {color=#526168}At first Leyla was in a lot of pain, but soon she was feeling the mixture of pain and pleasure. {/color}"

        "{i} {color=#526168}She had already succumbed her body to pleasure. {/color}"

        sey "Fuck… it’s so tight."

        sey "I'll cum in your tight pussy now."

        l "NO!"

        sey "AAA..."

        stop music2

        scene black

        hide leylarapeanimation

        "{i} {color=#526168}He came inside her pussy without understanding what he was doing. {/color}"

        scene day4-70



        "{i} {color=#526168}Her vagina was filled with a mixture of blood and semen. {/color}"

        l "What have you done?"

        sey "Don't think about it so much."

        sey "Let's take a shower."

        scene day4-71

        "{i} {color=#526168}Seyhun went to take a shower, leaving her shocked and devastated on the bed. {/color}"

        l "..."

    stop music
    $ renpy.end_replay()
    $ persistent.leyla_rape_scene_unlocked = True
    jump turan_fucks_aydan






label turan_fucks_aydan:


    scene black with dissolve
    with Pause(2)
    "{i} {color=#526168}In Turan's apartment...{/color}"
    scene day4-72 with dissolve
    play music "audio/sidesex.mp3"

    a "I thought you would like this lingerie.."
    scene day4-73
    t "Did your husband suspect anything?"
    a "He's a fool. He thinks that I'm working overtime."
    scene day4-74
    t "Can't he satisfy you anymore?"
    a "He can't do it anymore. You spoiled me. He can't do the things that you're doing to me."
    t "I guess he's too small for your liking."
    a "Well, he cannot be compared with you."
    a "Let's stop talking about him."
    scene day4-75
    a "I want to enjoy your big cock now."
    t "Enjoy it as long as you want."
    scene day4-77
    "{i} {color=#526168}She quickly took his pants off and started sucking his balls furiously.{/color}"
    t "Enjoy it, my slut."
    scene day4-77
    t "You want to take it all, don't you?"
    "{i} {color=#526168}She sucked his cock for about ten minutes like the hungry girl that she was, needing his cock deep inside her mouth. {/color}"
    scene day4-78
    a "Yes, keep doing that. I'm cumming!"
    scene day4-79
    t "You're already cumming. Look at you. Look at how dirty of a slut you are."
    a "I am your slut. Do whatever you want to me. Treat me like a whore."
    scene day4-80
    a "I came just from you rubbing my pussy with your dick."
    t "You fucking slut. Are you ready to cum again?"
    a "Yes, my master. Make me cum again please."
    t "Your husband is probably sleeping now while his wife is getting fucked by another man."
    a "Ohh yes, he's a loser."
    t "Now I'll stretch your pussy a little bit."
    a "Ahh yes, do it already. Stop teasing me, please. I can't take it anymore."
    stop music
    show aydanturanfuck
    play music2 "voices/softmoan.mp3"
    t "Your husband doesn't deserve you. He doesn't deserve this cute ass."
    a "Ohhh..I'm cumming again baby...ohhh..."
    t "Yes, slut, cum again on my dick. You need this."
    a "I'm hungry for your fat cock, baby. Feed me with your cock. Ahhh yesss.."
    stop music2
    scene day4-81
    play sound "voices/maleorgasm.mp3"
    t "Take it, little slut. Take all of it."
    stop sound
    a "I'm still cumming, baby."
    t "Now you can go and sleep next to your husband."
    scene day4-82

    a "He can wait a bit longer."
    "{i} {color=#526168}She fell on the sofa as her legs were powerless to move. {/color}"
    scene black
    $ renpy.end_replay()
    $ persistent.turan_fucks_aydan_unlocked = True
    jump turan_fucks_aydan_continuation




label turan_fucks_aydan_continuation:
    "...."
    "..."
    scene day4-83 with squares
    play music "audio/action.mp3"
    b "Do you understand what that means?"
    b "Aren’t you even a little bit worried about her future?"
    k "Banu, you need to calm down a bit."
    b "I can't calm down now. Do you understand that what happened today will have a big impact on Leyla's future?"
    b "How will we prove that she was raped by her groupmate?"
    scene day4-84
    k "My dear, I understand you well, but you should calm down first. Getting angry will not solve anything."
    k "Now tell me. Are you sure that she's not a virgin anymore?"
    scene day4-85
    b "She told me everything. That wicked scoundrel took advantage of her and raped her in his room."
    b "You’re not understanding! Do you know how they treat raped girls in our society?"
    scene day4-86
    k "I know, Banu. I will go and talk to his parents tomorrow."
    b "That will not change anything. We should go to the police and report this."
    k "We can't do that. If we go to the police, everybody will know about this. Is that what you want?"

    k "We shouldn't worsen the situation."
    b "I can't believe that you're so calm like that. Do you know that her future is destroyed now? Her husband won't accept her after knowing that she's not a virgin."
    b "They will think of her as a slut."
    k "Banu, stop it for God's sake."
    k "You're exaggerating things."


    menu:
        "She gets even angrier":


            $ kamilbeta += 1
            $ domme += 1
            $ renpy.block_rollback()

            $ humiliatingseyhun = True
            scene day4-87
            b "I know why you’re so calm now. She’s only your stepdaughter, that’s why. You don't feel sorry for her."
            k "Are you mad? How can you blame me like that? Of course, I feel sorry for her."
            scene day4-88
            b "Just leave me alone..."
            k "Banu..."
            scene black with dissolve
            with Pause(2)
            scene day4-91
            "..."
            ".."
            scene day4-92
            b "Hi..It's Banu. How are you, Polad?"
            scene day4-94
            p "Hey..thanks. How are you doing?"
            scene day4-92
            b "There's a problem. I need your help."
            "{i} {color=#526168}Banu told Polad everything she knew about Leyla being raped. {/color}"
            b "I can't decide what to do. I'm so desperate right now."
            scene day4-95
            p "Calm down, Banu.... I think I know that guy."
            scene day4-93
            b "I can't do anything or go to the police."
            b "But I don't want that asshole to run away like that."
            p "Just leave it to me. We will teach him a lesson."
            b "..."
            stop music
        "She calmed down":





            $ renpy.block_rollback()

            $ humiliatingseyhun = False
            stop music

            scene day4-89
            b "You're right. Maybe, I'm exaggerating."
            b "This has affected me so badly."
            k "I know, my dear. We will get over this together. Now come here. "
            scene day4-90
            b "You are so good to me. Just forgive me if you can."
            k "I love you, my dear."
            b "..."
            stop music2



    scene black

    "{i} The next day... "
    scene black
    with Pause(1)
    scene day4-102 with fade
    "...."
    scene day4-103
    "{i} {color=#526168}It was not an ordinary day.{/color}"
    "{i} {color=#526168}Banu's head was full of stressful thoughts left from yesterday.{/color} "
    "{i} {color=#526168}All these thoughts and the pain in her heart were torturing her.. {/color} "
    "{i} {color=#526168}She didn't want to get up, as her soul was so weak. {/color}"
    scene day4-104
    "{i} {color=#526168}She wanted to forget everything that happened recently.. {/color}"
    "{i} {color=#526168}She wanted to forget about the thoughts and events that were torturing her soul. {/color}"
    "{i} {color=#526168}Her body and soul were so fragile.. {/color}"
    "{i} {color=#526168}She needed to free her mind. {/color}"
    scene day4-105
    b "{i} {color=#526168}Mmmmm {/color}"
    b "{i} {color=#526168}Ohhh... {/color}"
    scene day4-106
    b "{i} {color=#526168}Ahhhh... {/color}"
    b "{i} {color=#526168}Mmmmm.. {/color}"
    scene day4-107
    r "...."
    stop music
    scene black
    "..."


    if humiliatingseyhun == True:
        play music "audio/action.mp3"
        scene black

        ram "Hey, shut your mouth, you son of a bitch."
        p "You thought you could run away like that?"
        scene day4-96 with wipeleft
        ram "Bring that asshole here."
        sey "Please, don't do that. I won't do it again. I promise."
        scene day4-97
        p "What does it mean to rape a virgin girl, huh?"
        sey "Pleasee, let me go."
        scene day4-98 with hpunch
        ram "You deserve this, you piece of shit."
        sey "Noo..."
        scene day4-99 with hpunch
        ram "You'll take a good lesson from this.."
        sey "AAg"
        if agressive == True:
            scene day4-100
            ram "You will not approach teen girls anymore, will you?"





            sey "No, never again.."
            scene day4-101
            p "I think he'll be a good boy from now on."
            p "I'll try not to share this video..."
        else:


            p "I think he'll be a good boy from now on."





        scene black
        "..."
        stop music









    jump day5
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
