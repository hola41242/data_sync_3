



label characters:
    play music "audio/kometaback.mp3"
    show black
    dev "Meet Banu..."

    scene Banu with dissolve
    with Pause(50)
    show black
    dev "Meet Kamil..."

    scene Kamil with dissolve
    with Pause(50)
    show black
    dev "Meet Leyla..."

    scene Leyla with dissolve
    with Pause(50)
    show black
    dev "Meet Ruslan..."

    scene Ruslan with dissolve
    with Pause(50)
    show black
    dev "Meet Polad..."
    scene Polad with dissolve
    with Pause(50)



    show black
    dev "Meet Hicran..."
    scene Hicran with dissolve
    with Pause(50)


    show black
    dev "Meet Boss..."
    scene Boss with dissolve
    with Pause(50)




    show black
    dev "Meet Nesrin..."
    scene Nesrin with dissolve
    with Pause(50)
    show black
    dev "Meet Turan..."
    scene Turan with dissolve
    with Pause(50)
    show black
    dev "Meet Murat..."
    scene Murat with dissolve
    with Pause(50)
    show black
    dev "Meet Natasha..."
    scene Natasha with dissolve
    with Pause(50)

    show black
    dev "Meet Ahmed..."
    scene Ahmed with dissolve
    with Pause(50)




    show black
    dev "Meet Rina..."
    scene Aysel with dissolve
    with Pause(50)


    stop music











    jump start
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
