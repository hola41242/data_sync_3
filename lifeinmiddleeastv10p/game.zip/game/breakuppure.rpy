

label breakuppure:

    scene black with Dissolve(3)
    centered "{size=+120}Break up{/size}" with Fade(0.5, 0.5, 5)
    scene v13-89 with irisin
    play music "audio/intro.mp3"
    b_ "I can't bear this anymore. How could that asshole dare to slap me? "
    b_ "I don't deserve this. I deserve a much better life that Kamil can't possibly offer. "
    b_ "I'm tired of him. Slapping a woman and calling himself a man? You lost me Kamil."
    if followpolad == True:
        b_ "Now I don't feel sorry for letting Polad fuck me behind your back. He's a much better man than you'll ever be."

    if banuturansexfirsttime == True:
        b_ "Even Turan treated me a way better than you do in bed. If you were a real man you could protect your wife and no other man could touch your wife."

    if banutakethebetfuckmurat == True:
        b_ "If Murat didn't tell me I'd never know."
        b_ "At least he's sincere with me. And the sex with him is much more enjoyable than with you. Loser!"


    scene v13-90
    k "Banu, w-what are you doing?"
    k "Banu, answer me. Where are you going?"
    b "That's is not your fucking business at all."
    b "I knew from the very beginning that we can't do together. You can't handle a woman like me. You don't deserve me, so simple."
    k "You'll be ashamed for your words when you come back tomorrow."
    b "You still think that I'll come back? Poor Kamil."
    k "Tell me at least where are you going."
    b "You don't deserve to know that."
    scene v13-91
    k "Banu..."
    b "Get out of my way."
    "Banu knew exactly what she was doing."
    "She couldn't get the attention and care she needed from Kamil."
    "And the last mistake Kamil made today was the excuse to flee away from him. "
    "Their relationship never worked. Banu knew Kamil was not the right man to be with her for a life. But she still gave him a chance to keep the promises he made which he couldn't keep. "
    "Banu has been a good wife but Kamil failed to keep her with him. She tried her best to be a good wife until she realized that this is not working anymore. "
    "She needed a new life and better people around her. "
    "She realized that she is ready for more of what life has to offer and Kamil is not the man to provide everything she wants. He just lost her."
    "Banu is not an angel. She has mistakes. She has enormous amount of lust, desire, needs, expectations which Kamil failed to fulfill."
    "She love Kamil as her husband and respected him."
    "But she didn't love him as a man."
    scene v13-92
    "Kamil watched her leave in silent. He couldn't open his mouth and say a single word to prevent her from leaving."
    "He was powerless, hopeless and heartbroken. "
    "He did not cheat on Banu. The picture Murat showed to Banu was taken when Kamil rejected Humay saying that he is not interested in her and that he has Banu."
    "But Banu never trusted him."
    "And she didn't take serious steps to fix her relationship with Kamil. "
    stop music

    scene black with Dissolve(3)
    centered "{size=+120}Polad's apartment{/size}" with Fade(0.5, 0.5, 5)
    scene v13-187 with squares
    "Banu had nowhere to go other than her best friends' apartment. "
    "She can't go back to Kamil as she put an end to that relationship."
    "Things with Kamil were not working out anymore. Both feelings and their sex life have already faded away. "
    "So it was the high time to end this relationship."
    "Polad and Nesrin always welcomed Banu. They were living in a big apartment just two of them so they were happy to have Banu as a guest for some time."
    scene v13-188
    n "So that asshole hit you? "
    b "Please, I don't want to talk about him anymore."
    n "If I were you I'd break one of these vases you got on his head."
    scene v13-189
    b "I wanted to do that. I wanted to spit on his face, but I was afraid and now I regret not doing that."
    n "Hmm, seeing you like this I believe that you're not planning to go back to him again. "
    scene v13-190
    p "Back to him? What are you talking about? Kamil's a dishonorable piece of shit."
    p "If I were there I'd beat the shit out of him in front of Banu."
    n "Okay calm down boy. What's it with you? Why are you getting angry all of a sudden?"
    p "Oh please, Nesrin. I can't tolerate when I hear a piece of shit treating his lady like this."
    p "A lady like Banu, pure and with good morals."
    b "..."
    n "..."
    scene v13-191
    n "He's right Banu. You're precious to us. I don't want you to feel as a guest here. Just feel yourself at home."
    b "Thank you guys. I knew that I can count on you."
    n "Look, Polad and some friends went fishing today and they were lucky this time. He came back with a big bucket full of salmon. "
    n "Let's cook together."
    b "Okay..."
    scene v13-192
    p "I don't want to be rude Banu but if you fled from him and came here, I won't let you go back to him again. "
    scene v13-193
    b "I don't have any intention like that."
    scene v13-192
    p "Just keep that in mind. If you go back to him, I won't forgive you."
    p "I just want the best for you. I don't want him to hurt you again."
    p "I want you to stay here under my protection."
    p "I'll protect you and keep those people away from you who can hurt you. You just need to listen to me and do what I say."
    scene v13-193
    b_ "He's always been so masculine like that."

    p "You know that what I do is for your safety and wellbeing. "
    p "So I'll know where you are going and whom you are talking to. "
    p "Most importantly I don't want you to contact that husband of yours."
    p "So these are the simple rules."
    b_ "Isn't he going too far?"
    b_ "Anyway, I don't have a choice. He's the man of this house after all. I think I can do what he says."
    b_ "He just care about me."
    scene black with dissolve
    centered "{size=+120}Later{/size}" with Fade(0.5, 0.5, 5)
    scene v13-194 with fade
    "Banu was making some tea to help Nesrin out in the kitchen."
    p "I hope you didn't get offended by what I said earlier."
    b "..."
    scene v13-195 with fade
    b "Not of course."
    b "It's perfectly fine. This's your house and you should be aware of what's happening in your house."
    p "Then why don't you look at me while you are talking to me?"
    scene v13-197
    b "I was just busy making...."
    if followpolad == True:
        play music "audio/tension.mp3"
        p "You can't forget about it, right?"
        b "What do you mean?"
        p "What we did in my bedroom."
        b "Polad, please, that was a big mistake that we did."
        scene v13-199
        p "Listen..."
        b "No you listen to me. This can't go on."
        scene v13-200
        b "And if you open this subject again, I'll leave and you'll never see my face again."
        b "Is that understood?"
        p "If you say so..."
        stop music


    p "I got it."
    p "Let's change the subject."
    scene v13-198
    b "Okay Polad, let's talk another time."
    b "I'm a bit busy here."
    p "Okay..."

    stop music


    scene black with Dissolve(3)
    centered "{size=+120}The backstreet{/size}" with Fade(0.5, 0.5, 5)
    scene v14-1 with move


    $ banudefendherself = False
    play music "audio/action.mp3"

    "The sun was just setting when Banu was coming home from work."
    "Again she had to do some overtime work the manager asked her to do."
    "She was heading towards the backstreet to go through to reach the neighborhood where Polad lived."
    scene v14-2
    "The street used to be full of gang members and the street guys who used and sold illegal drugs. "
    "The police cleaned most of them after the residents raised the issue and reported them, but it was still a dangerous place to walk alone for a woman at night. "
    scene v14-3
    b_ "The surrounding is so quiet...This place is not familiar and it looks scary."
    b_ "This is not the only way to home for sure but it's late to go back. I'll just pass through quickly. "
    b_ "Damn Banu, you always get into trouble because of your wrong choices. "
    b_ "Let's hope nothing bad will happen."
    scene v14-4
    "Banu was entering the narrow path to go through."
    "Swaying her pretty shaped hips as usual, but this time with careful steps."
    "She was afraid but she had no idea what kind of adventure was waiting for her..."
    scene v14-5 with hpunch
    "Banu was shocked when one of the crooks stood in front of her, blocking the way she was passing."
    scene v14-6
    b "Please, let me pass..."
    cr "Shh...be quiet. Aren't you afraid of walking alone here late at night."
    cr "You're a very brave woman, aren't you?"
    "Banu's body tingled when she noticed the long sharp knife in the man's hand."
    "The man looked dangerous and Banu instinctively knew that she had to be careful otherwise she'll have a really bad ending here."
    scene v14-7
    "As the man came closer to Banu she stepped back until her back touched the wall."
    b "Please, what do you want?"
    cr "What can I want from a beautiful chick like you?"
    cr "I'd gladly rip your clothes off right here and have my way with you."
    cr "I'd fuck you in every hole you have and destroy your insides making you scream till morning comes."
    cr "But unfortunately I should hurry."
    scene v14-8
    cr "For now, hand me your purse and keep your mouth shut."
    cr "If you try to scream I'll make more holes in your body and make you look like a colander."
    b_ "If I scream nobody is around to help me. He'd kill me till anybody comes to help. "
    b_ "But I hate the fact that I'm forced to give him my purse."
    b_ "I could try to run but he'd catch me before I reach the main road."
    b_ "What if I stand for myself and defend myself. He's just an ordinary dude. I can defend myself."
    menu:
        "Give him the purse":
            $ renpy.block_rollback()
            $ banudefendherself = False
            scene v14-9
            play music "audio/tension.mp3"
            "For some reason Banu didn't want to risk it and handed the purse to the crook with a desperate look on her face. "
            b_ "I just can't do it. At least he's a man and he's dangerous. If I do something wrong he can just kill me right here. I have no chance other than obeying what he orders."
            b "Here, take it....please...let me go."
            "As Banu gave him what he wanted she expected the man to be satisfied and leave her alone but... "
            scene v14-10
            "Instead of leaving her, the crook got even closer to Banu with the knife touching between her breasts. "
            "He sensed that the woman is so scared and decided to have more fun with her."
            cr "I see you're a good obeying girl and I believe that you have more to give me. "
            b "I gave you what you wanted. Just leave me alone."
            scene v14-11
            cr "Shut your fucking mouth otherwise I know how to shut it myself."
            "The sharp knife touching her skin scared the shit out of Banu. She was terrified but tried to not make a noise to further make him angry."
            cr "That's a good girl. Now you know who I am and you know why I've not cut your body into pieces yet."
            scene v14-12
            cr "You see? Nobody is around. We can just finish it right here."
            cr "Now you'll turn around like a good obeying girl, bend over, put your hands on the wall and wait till I finish with your lower body. "
            scene v14-13 with vpunch
            b "Ahh...."
            cr "Shh..."
            "Banu was tingled when the man suddenly pushed the knife between her legs."
            "She thought the knife entered her for a moment but the hard metal rubbed her clothes and stimulated her already wet pussy."
            scene v14-14
            b "Please, please...you don't have to do this."
            cr "Really? Why is that?"
            b "I can give you more money, please don't do this."
            cr "Why don't you give it to me now?"
            b "I have a lot of money but it's all in my bank account. If you let me go now I'll go and withdraw it and give it to you. "
            cr "Really? Do you think that I'm that stupid?"
            scene v14-15
            cr "Instead I want this one between your legs."
            cr "You tried to fool me huh? Now you'll get your punishment."
            cr "I'll cut your clothes one by one and give you the best fuck of your life."
            "Hearing the man's words, Banu instinctively closed her legs squeezing the knife between her legs."
            cr "Hey, what happened? That excited you?"
            cr "Now open your legs..."
            cr "Do I need to repeat myself?"
            scene v14-16
            "Banu didn't want to make the man angrier and the sharp knife between her legs made her even weaker so she obeyed what he said without thinking about it."
            cr "Look at these beautiful curves. Your husband must be happy. Am I right?"
            cr "I know what you want right now. You want to get fucked so bad but you don't want to admit it."
            cr "I can see it in your eyes that you have a desperate desire to get fucked."
            cr "You're burning right now and your pussy is dripping for sure."
            cr "Now we'll see if I'm right or not."
            scene v14-17
            cr "Take all your clothes off right now. "
            b "No...please...I can't do that."
            cr "You'll do that right now or I'll push this knife all the way to your cunt and splatter your internal organs over here."
            cr "You choose. Do what I say or die."
            scene v14-18
            un "Hey, what are you doing over there?"
            "Suddenly a man's voice from a distance was heard and it broke the dark silence inside Banu and gave her a relief."
            cr "Shit, you're so lucky, bitch. I have to go now. I hope we'll meet again soon."
            scene v14-19
            stop music
            "The theft left Banu and ran along the narrow path as he saw the unknown man approaching."
            "Banu was left in a disgraceful situation that she felt so bad after what happened."
            "Her purse was stolen and she herself almost got raped."
            "This gave Banu an unforgettable experience and lowered her self-esteem."
        "Defend yourself ":







            $ renpy.block_rollback()
            $ banudefendherself = True
            scene v14-20
            b "So you want my purse? Come and take it yourself."
            cr "Are you mad, bitch?"
            cr "You want me to cut you into pieces? I can do that."
            "Banu knew what she was going to do next. She was trying to distract the man and implement her tricky plan."
            b_ "Now he'll come one step forward and one step to the right. Then I'll smash his balls so hard that he wouldn't forget this moment for a long time."
            scene v14-21 with vpunch
            cr "Arrrggg..."
            b "That's it you son of a bitch."
            "Banu didn't miss the target and landed a heavy kick right in the man's balls. The kick was so hard that the man almost lost consciousness and collapsed on the ground."
            scene v14-23
            "Banu was so satisfied that she gave the man so much pain and put him on the ground."
            "But she had no intention to leave that early and wanted to enjoy the situation more."
            scene v14-22
            b "So you're the bad boy. How do you feel now? Do you like the pain?"

            scene v14-24
            cr "..."
            "The man didn't reply rather wiggling in agony."
            "The pain was so hard that he needed time to recover."
            scene v14-22
            "The more the man felt pain the more Banu enjoyed his suffering face. "
            "She was a tigress staying there and bitterly watching her enemy trying to recover. "
            "The moment the man's pain started to vanish Banu didn't wait any longer."
            scene v14-25
            "She gathered all her strength one more time."
            "Bitterly looking at his eyes she was about to smash his face."
            scene v14-26 with hpunch
            b_ "That's it. Another accurate hit right on his fucking face."
            "After another hard kick the man's head hit the wall making a crackling sound and he again collapsed on the ground."
            scene v14-27
            "Banu put her right foot on the man's chest and released her weight on the man as her pointed high heel almost pierced through the man's chest. "
            scene v14-28
            b "Do you feel it, asswipe?"
            b "You're such a pathetic creature. You're so weak that you can't even fight with a man and all you can do is to steal from women."
            b "You're not even a man. You're a boy. A man doesn't steal from a woman."
            b "You're so ridiculous that you couldn't even manage to get my purse. I feel sorry for you."
            scene v14-29
            b "Look at you. You're genetically stronger than me but you're kissing my shoes now."
            b "You're such a loser. If I were you I'd cut off that little penis you got right there. You don't need that."
            b "If I had more time now I'd make you kiss my ass and beg me to forgive you."
            b "But for now...."
            scene v14-30
            b "Take this! You deserve this!"
            cr "Wait....no!"
            scene v14-31 with vpunch
            "Before leaving the man Banu gave him another hard kick right on his balls."
            b "Take this asshole. Your eggs must be broken now. Good luck with that."
            scene v14-32 with fade
            b_ "Maybe I was too much. But I enjoyed every second of it."
            "Banu left the man and walked to the main road with a satisfied smile on her face."
            "She enjoyed what she did. All her fears were replaced by strong feelings full of pride."
            "Today's accident was an important memory for Banu. Maybe this will make her even stronger and encourage her to stand for herself more."



    stop music      
    scene black with dissolve
    ""


    if banuturansexfirsttime == True:
        scene black
        centered "{size=+120}Turan's apartment{/size}" with Fade(0.5, 0.5, 5)
        scene v14-33 with squares
        "Banu was again here in a place she hates the most."
        "She came here because she had a specific reason for this."
        "She didn't like Turan at all. He was not her type of a man, cocky and tricky."
        "But every time Turan found a way to slide into her self-defensive system and sometimes into her pussy."
        scene v14-34
        "But this time she came prepared."
        "She came to get her revenge on Turan for all the bad things he did to Banu."
        scene v14-35
        "But after all, another surprise from Turan was waiting for Banu."
        b "What the fuck!"
        scene v14-36 with hpunch
        t "Hey Banu. You get prettier day by day. Don't stand just there. Come take a seat."
        scene v14-37
        b "What the hell are you doing? Are you out of your mind?"
        t "Why is that?"
        b "Just put some clothes on. We can't talk like this."
        t "This is my house after all and I decide what to wear. It's just hot here so I decided to stay naked. Is something bothering you?"
        b "Stop this Turan. It's ridiculous. Put some clothes on or I'm leaving."
        t "We both know that you're not going anywhere. You came here to be fucked and you can only leave after I finished with you, remember?"
        scene v14-38
        b "Fine, let's talk then. What you need to leave me alone already? You already got what you wanted from me."
        t "Nice point Banu. I've a good news for you. I believe that this will make you happy."
        scene v14-39
        b "I had enough of your tricks but again tell me what's this all about?"

        scene v14-40
        t "After a month I'm going to leave the city. Just one month and I'll be gone forever so you'll never see my face again."
        scene v14-39
        b_ "He doesn't know that I broke up with Kamil. His stupid ass thinks that he can blackmail me using Kamil."
        b_ "But I won't make it obvious and play along."

        b "Wait..you're telling me that you'll leave the city forever?"
        scene v14-40
        t "That's right. But there's a bad news. You'll have to serve me until I leave and once I leave the city I'll forget about you. I promise."
        scene v14-39
        b "You're such an asshole! I can't believe you're telling me this."
        scene v14-43
        t "You're right. I'm asshole. Now let's get to the business. You'll just have to do this for one month and then you'll be free. "
        t "Of course if you want to stay with me after one month you can just come with me."
        scene v14-41
        b "I hate it when you talk like that you know that?"
        b "You're the last person on earth that I'd want to be with."
        b "I hate you Turan. How many times should I tell you that?"
        scene v14-42
        "Occasionally Banu's eyes drifted unconsciously towards Turan's bare manhood and she couldn't stop thinking about it."
        b_ "Look at that..."
        b_ "It looks so tough but at the same time it's beautiful."
        "It was the first time Banu paid close attention to the attractiveness of a man's penis."
        scene v14-45
        t "You're saying that but you can't take your eyes off my dick. Now don't tell me that you didn't look at it."
        scene v14-44
        b "You have a good fantasy world. It's just your fantasy that I look at you."
        b "I never enjoyed your presence, I never enjoyed being with you and I'll never give you that satisfaction. "
        scene v14-45
        t "Okay as you wish. Let's take the conversation to my bedroom..."
        b "..."
        scene black with dissolve
        ""
        scene v14-46 with dissolve
        t "Don't hurry. Take your clothes off slowly. I enjoy your undressing."
        b "One day you'll die and I'll come and spit on your grave."
        t "Are you always pessimist like that? You don't know how to enjoy the moment."
        b "You'll die one day."
        scene v14-47
        play music "audio/tension.mp3"
        b_ "Maybe that's exactly today..."
        "Turan had no idea what Banu had planned for him all this time."
        "She wanted to end this affair. She knew that Turan would never leave her alone. "
        scene v14-48
        "She couldn't live with this. She couldn't do this, she was not that type of person."
        "She came to Turan's apartment for the last time to kill him to get her revenge on him."

        scene v14-49

        "Banu was determined to finish what she came for."

        "She slowly took the knife out of the bag and squeezed it in her hand."

        b "Hey I'm having trouble unzipping my pants. Why don't you come and help me with that?"

        t "That's my girl. I knew one day you'll ask me to undress you."

        scene v14-50

        t "I'll gladly help you with that. "

        t "Just turn around..."

        scene v14-51 with hpunch

        b "This is what you deserve. Do you hear me?"

        "Banu made a quick turn around and the knife in her hand penetrated Turan's chest."

        b "Bastard, this will be the only thing you'll get from me."

        "Banu was talking bitterly and aggressively. She did what she came for and now nothing was holding her to break Turan properly."

        scene v14-52

        "Turan couldn't believe what had happened for a moment."

        "Once he realized that the sharp kitchen knife had penetrated down his right pectoral muscle, he instinctively put his hands around the knife to pull it off."

        scene v14-53

        t "What...what've you done?"

        "His face impression changed completely. The arrogant look on his face was replaced by a weak pathetic look."

        t "Are you crazy, bitch?"

        t "You'll go to the jail."

        scene v14-54

        "On the other hand, Banu was now so confident and proud of what she was doing."

        b "And you'll go to the hell! You'll be burning there and like I said I'll come and spit on your grave, asshole."

        "Banu's bitter words hit Turan and he tried to grab her by her throat."

        t "If I go to hell, I'll take you with me, bitch."

        "He tried to grab her and choke her but the pain and running blood from his body made him weak so he fell on his knees."

        scene v14-55

        b "Now it's time to pay for all the things you've done to me."

        b "I won't even call an ambulance you know?"

        b "One more motherfucker will disappear from my life today."

        scene v14-56

        t "Don't be stupid. Call an ambulance..."

        t "I'm passing out..."

        t "Please..."

        scene v14-57

        b "You're so weak, pathetic and coward."

        b "If you want me to help you, you need to beg properly. I can't hear you."

        scene v14-58

        "But Turan was already passed out."

        "Banu looked at him bitterly again. She couldn't believe that the man who did all the evil stuff was lying unconscious just before her."

        scene v14-59

        b "Hey do you hear me?"

        b "Don't try to fool me again. "

        b "After all the things you've done to me I'm still up but you're lying down here. You need me to save your ass."

        b "But you don't deserve this. You don't deserve to live. "

        scene v14-60

        "But Turan didn't move or say a single word."

        "Soon Banu realized that she was in a deep shit."

        "Her anger was replaced by fear and worry."

        scene v14-61
        stop music

        b_ "Shit! What should I do now."

        b_ "If I leave him here he'll die for sure."

        b_ "I don't want to go to the jail. But what's done is done. I believe I did the right thing."


        scene black with dissolve
        ""

    stop music    
    centered "{size=+120}Praying{/size}" with Fade(0.5, 0.5, 5)
    scene v14-128 with blinds
    play music "audio/intro.mp3"
    "Several months had passed since the last time Banu visited Mosque, the holy place."
    "She had made a lot of sins for sure and now needed at least to tell them to God and beg for forgiveness."
    scene v14-129
    b_ "I should come here more often. This place always brings me peace and heals the pain in my heart."
    b_ "Lately I've become more violent and cruel to people around me."
    b_ "This's because of the trauma the bad people around me gave me. "
    b_ "The more they hurt me the more I crave to get my revenge on everybody who hurt me."
    b_ "I know that I can be so dangerous in the end if I don't stop the darkness inside me."
    scene v14-130
    "But there was another secret about this place that got Banu really interested."
    "The man who was always watching Banu, following her everywhere was again here looking at Banu."
    scene v14-131
    b_ "He's here..."
    b_ "He doesn't seem like a dangerous man. He's actually a religious man. "
    b_ "He looks humble and simple. He's thin and short but he looks so peaceful."
    b_ "I've seen him praying many times but why is he following me? Is this my imagination or he knows me?"
    b_ "There's something weird about him."
    scene v14-132
    stop music
    ass "Hey, Madam, can I have a minute with you?"
    b "Huh..."
    scene v14-133
    b "Sure, how can I help you?"
    ass "Well how to say...I..."
    ass "I don't know how to say but...."
    ass "I've seen you here several times and..."
    scene v14-135
    b "I know you. I've seen you praying here too."
    "Banu noticed that the man was having a hard time expressing himself and decided to kinda help him. "
    scene v14-134
    ass "Yes I come here often but recently I noticed that you don't come anymore and wondered if something happened. "
    ass "So I decided to ask you that and I kinda felt embarrassed asking you that. "
    scene v14-135
    b "No. Don't worry. Everything is alright. I was just a bit busy."
    ass "That is nice. I'm sure you have serious reasons to skip visiting the God's place and I'm sure you'll come here more often."
    ass "By the way I wish God accept all your prays and forgive your sins."
    b "Thank you so much. I wish the same to you."
    scene v14-134
    ass "By the way, could you please tell me your name? I'd really appreciate it."
    b "Banu...and what's your name?"
    ass "My name is Aslan. I'm really pleased to meet you Banu."
    scene v14-136
    "Aslan shook Banu's hand softly and kept it in his hand for some time."
    "Banu was in an awkward situation. She tried to pull her hand and say goodbye but..."
    scene v14-137
    ass "Actually I've a few questions to you Banu. If you have some time can we walk a little bit and talk?"
    b "Umm...okay but I have to hurry, but we can talk for five minutes."
    scene v14-138
    "They walked a little bit in the yard and Aslan continued to talk sweet to Banu."
    "During the conversation Banu learned some facts about him like he lost his both parents and live alone."
    "Most importantly he's still a single man."
    scene v14-139
    b "You're in your mid-thirties, but still single why is that?"
    ass "I just haven't met my soulmate yet. "
    ass "Actually, I'm looking for a girl who is religious and polite...like you."
    b "Ummm..."
    scene v14-140
    ass "I know that it's not polite to ask but I want to know if you're married or single."
    b "I'm about to get divorced..."
    ass "Ohh that's sad....what happened?"
    b "Now I don't really want to talk about it. I think you understand that..."
    ass "Of course..."
    scene v14-142
    ass "Look Banu I know that there're so many criminals recently in the city so... "
    ass "If you let me I'd walk you to your neighborhood."
    scene v14-141
    b "Thank you. That's very nice of you to ask but I don't need protection. I can take care of myself."
    "The conversation got more interesting. The man made it more obvious that he likes Banu."
    scene v14-142
    "Banu was having fun, laughing and making jokes."
    "The man was so cute and gentle that Banu was not feeling shy anymore and now was talking more open with him."
    scene v14-143
    b "Once I made sure that short men know exactly how to make ladies laugh."
    scene v14-144
    ass "Banu, I want to tell you one thing. I know that beauty is subjective but I know that if a girl becomes more beautiful when she laughs, she's the real beauty."
    ass "You're so beautiful, Banu. I wish I met you before. I wouldn't waste my ten years and I'd ask you to marry me immediately."
    scene v14-145
    b "Now it all become clear. Now I understand what's this all about."
    ass "Banu, I don't want you to understand something wrong..."
    scene v14-146
    ass "I really like you...It makes me happy when I see you here every time."
    ass "I don't want to miss this chance. "
    ass "If that's not a problem for you I'd like to invite you for a coffee sometime."
    b "Do you think that I'll accept that?"
    ass "I'm sorry if I..."
    scene v14-147
    b "Try your luck next time."
    b "But you should try a little bit harder to get me interested."
    b "Only then we can think about it..."

    scene black with Dissolve(3)
    ""
    centered "{size=+120}Polad's apartment{/size}" with Fade(0.5, 0.5, 5)


    scene v14-148 with squares
    "It was at midnight that Banu couldn't sleep and went to the kitchen to drink something."
    "She was distracted by the sounds coming from the bedroom."
    "A female moaning was travelling all the rooms to the kitchen. "
    scene v14-149
    b_ "They're doing it again. Almost every day and it lasts hours."
    b_ "Polad has so much sexual energy."
    b_ "This's distracting..."
    b_ "Wait...They left the door open. "
    b_ "Why don't they care that there's another female living here."
    scene v14-150
    b_ "This's shameful..."
    b_ "You shouldn't be doing this, Banu."
    "She couldn't stop the unbeatable urge inside her and approached the door of the bedroom. "
    scene v14-151
    b_ "Oh my God..."
    b_ "I can't believe I'm doing this."
    scene v14-152
    b_ "They're so hot and passionate..."
    b_ "No, I should leave now...he can see me... "

    scene v14-155

    b_ "Anyway, it's none of my business. This's their house after all. They can do what they want."

    "Banu left immediately but deep inside her she felt jealous and maybe wanted to be in Nesrin's place."

    "She didn't know why this happened to her. She just couldn't stand seeing Polad engaging with a female."




    scene black with dissolve
    centered "{size=+120}The graveyard{/size}" with Fade(0.5, 0.5, 5)
    scene v15-1 with dissolve
    play music "audio/intro.mp3"
    "It was quite a while that Banu hadn't visited her beloved deceased husband."
    "Banu used to visit Alper's grave very often but recently she got her head so busy that she could even forget Alper who was still the most precious person for her."
    scene v15-2 with dissolve
    "Kamil didn't know about Banu's visits to the graveyard. She didn't let him know about it because she was not sure Kamil would be happy about it or even let her visit her dead husband."
    "At least Kamil was her husband and he wouldn't be happy if he knew Banu still didn't forget about Alper."
    "So Banu used to come to the graveyard to be with her beloved one and talk to him some time without Kamil knowing about it."
    "After she broke up with Kamil and left his house, she needed an urge to come here and talk to a person that she truly loved."

    scene v15-3
    "She was not afraid of coming here alone in the evenings because she didn't want anybody to see her and wanted to have alone time with Alper."
    "She was now here standing in front of Alper's grave. The grave stone was a regular stone and got dirty from the humidity because of no attention."
    scene v15-4
    b "I'm really sorry that I can't visit you often recently."
    b "A lot of things happened to me recently but I managed to survive."
    b "Life is so hard without you..."
    scene v15-5
    b "I know that I made mistakes and I've been so weak and now my life's fucked up. I don't really know what to do."
    b "I'm planning to get divorced. Kamil's just a selfish pig. I'm sorry to say this but he's not a man that I appreciate to be with. "
    b "He's just not enough of a man that controls me, handles me or even satisfies me."
    scene v15-6
    b "You know that he can never replace you. "
    b "I'll always belong to you in this life and in the next one. My body and sould will always belong to you."
    scene v15-7
    b "I'd never let him touch my body but...I tried to give him a chance and I let him touch me...but regret that."
    b "Please, don't call this cheating. It's not like that."
    b "He can never touch my body like you did and the connection between Kamil and me was only physical. He was just my husband and now he lost that privilege too."
    scene v15-8
    b "I know that I have so many mistakes.."
    b "I'm not a complete pure woman. I've been dirty. My spirit has been touched by dirty stuff. Please, forgive me!"
    scene v15-9
    b "Once you left me, my weak body started to seek attention. "
    b "Once you stopped feeding me with your precence, I couldn't help but searched attention elsewhere."
    b "I touched my body and I enjoyed it."
    if banuturansexfirsttime == True:
        b "I let another man have my body. "
        b "He was not my husband, Kamil."
        b "I know how degrading this is but I enjoyed his touches..."

    if followpolad == True:
        b "I'm sorry to confess this but I betrayed you with your best friend..."
        b "Yes I did it with your best friend, Polad."
        b "We both betrayed you. Now you know that how awful I've been."


    if banutakethebetfuckmurat == True:
        b "Once I got drunk. I betrayed my religion. I couldn't control myself and let a boy younger than me enjoy my body."
        b "I was so desperate. I couldn't control my urges and I engaged in sex with a man."


    b "My body got so horny after you left me and I sometimes couldn't control it. "
    b "I touched my bare body. I dreamt about dirty things. I dreamt about other men..."
    b "Please, forgive me because I've been so dirty and bad. "
    b "And... stop looking at me like that. You're also guilty because you left me."
    b "I know that you can't stand it. You know that I'm surrounded by dirty men everywhere..."
    b "They enjoy looking at my body. The body that beloged to you."
    b "They're looking for a single chance to get pleasure from me."
    b "I don't know why but I'm angry at you..."
    b "Please, forgive me."
    b "I have to leave now but I'll come back and one day we'll be together forever..."
    scene v15-10 with fade
    "Banu was so relieved after confessing to Alper but at the same time so embarrassed to look into his eyes."
    "She hated herself for a moment that she had been with another man other than Alper and she had to come visit him secretly."

    scene v15-11 with fade
    "But it was too late. Banu had a new life now and new opportunities."
    "Alper didn't exist anymore. No matter how hard Banu tried to stay with him, life pulled Banu away from Alper every single day."
    "Banu was changed. She was not the same Banu that Alper dated, not the same Banu that blushed and ran away when Alper tried to kiss her."
    "It was fortunate for Alper that he didn't see the changed Banu..."
    "...or maybe he did..."
    stop music

    scene black with Dissolve(3)
    ""
    centered "{size=+120}Aslan{/size}" with Fade(0.5, 0.5, 5)
    scene v15-231 with squares
    "Aslan was sitting nervously on his couch, waiting for Banu's arrival."
    "He had spent the last hour cleaning his apartment and preparing the books he wanted to lend her."
    "He had been looking forward to this moment for days, ever since Banu had called him asking for guidance."
    "He couldn't help but felt a sense of excitement and nervousness. He had always admired Banu from afar, admiring her devotion to her faith and her kind heart."
    "He had been hoping for a chance to get to know her better, but had never found the courage to make a move."
    scene v15-232
    "Now, with her coming over to his apartment, he felt like he had been given a chance. He wanted to make a good impression and show her how much he respected and cared for her."

    "As he heard a knock on the door, his heart skipped a beat. He quickly got up from the couch and made his way to the door, taking a deep breath to calm his nerves."
    scene v15-233
    "Opening the door, he was greeted with a warm smile from Banu."
    ass "Hi Banu, please come in."
    b "Thank you, Aslan. I really appreciate you lending me these books."
    ass "Of course, it's my pleasure. I'm glad I could help."
    scene v15-234
    b "Your apartment is lovely. You have a great taste in decor."
    ass "Thank you. I try to keep it neat and tidy."
    b "I can see that. You're very organized."
    ass "Well, I try to be. So, how have you been doing?"
    b "I've been alright, thank you. Just been busy with work and trying to stay focused on my faith."
    scene v15-235
    ass "Yes, I know how important your faith is to you. That's one of the things I really admire about you."
    b "Thank you, Aslan. That means a lot."
    ass "Banu, would you like to sit down and have some tea with me?"
    b "Sure, Aslan. That would be nice."
    ass "Great. Let me just boil the water and I'll bring out the tea."
    b "Thank you, Aslan. You're such a gracious host."
    ass "It's no problem at all. I enjoy having guests over."
    scene v15-236 with fade
    "After a while Banu and Aslan sat down at the table with their tea."
    ass "So, Banu, I know we've been friends for a while, but I feel like we don't always get to talk about the deeper things in life. How are you really doing?"
    b "I appreciate you asking, Aslan. It's been a bit of a rough patch lately. Breaking up with my husband was really hard on me and it's been a struggle to adjust to being single again."
    ass "I'm so sorry to hear that, Banu. Is there anything I can do to help?"
    b "Honestly, just having a friend to talk to is really helpful. Thank you for being here for me."
    scene v15-237
    ass "Banu, there's something I need to tell you. I've been thinking about it for a while now and I don't want to keep it to myself anymore."
    b "Okay, what is it, Aslan?"
    ass "I know we've been friends for a while, but I've been feeling something more for you. I care about you a lot and I think we have a real connection."
    b "Aslan, I appreciate your honesty, but I'm not sure how I feel about you in that way."
    ass "I understand, and I don't want to make things awkward between us. I just needed to be honest with you about my feelings."
    menu:
        "Talk sarcastic and agressive":
            $ banutalksarcastictoaslan = True
            $ renpy.block_rollback()
            play music "audio/tension.mp3"
            scene v15-241
            b "Really? Are you sure you're not just saying that because you're bored or lonely?"
            ass "No, Banu, I'm serious. I've been feeling this way for a while now. I care about you a lot and I think we have a real connection."
            b "A real connection? What the fuck?"
            b "Don't be redicilous."
            b "I know that you're just another pervert who wants to fuck me."
            scene v15-240
            ass "No...of course not."
            b "Come on Aslan. All men are the same, don't you think?"
            ass "I didn't know you swear Banu. That's not a good thing for a religious woman like you."
            b "You're just so naive, Aslan. Everybody swears."
            ass "Right but..."
            scene v15-239
            b "So you want me to marry you right?"
            ass "I want to get to know each other better...I mean why not? I love you, Banu."
            b "You want to marry me knowing that I'm not virgin and I've been with other men."
            ass "That's not...really important...I guess."
            b "I don't believe you."
            scene v15-241
            stop music
            ass "But I do love you, Banu."
            b "I don't know, Aslan. I'm sorry if I've been harsh. I've been hurt before, and I don't want to get my hopes up just to be disappointed again."
            ass "I understand, Banu, and I don't want to pressure you into anything. I just wanted to be honest with you about how I feel."
            b "I appreciate your honesty, Aslan, but I need some time to think about this. Can we talk about this again later?"
            ass "Of course, Banu. I don't want to rush you or make you feel uncomfortable. Whenever you're ready, we can talk more about this."
            b "Okay, thanks, Aslan. I appreciate your understanding."
        "Talk calm and kind":




            $ banutalksarcastictoaslan = False
            $ renpy.block_rollback()
            scene v15-238
            b "I appreciate your honesty, Aslan. But, I need some time to think about this."
            ass "Of course, Banu. I understand. Take all the time you need."
            b "It's not that I don't believe you, Aslan. It's just that I need to be sure. I've had some bad experiences in the past with men and I don't want to rush into anything."
            ass "I completely understand, Banu. I just want you to know that I'm here for you, no matter what. Just take your time and let me know when you're ready."
            b "Thank you, Aslan. I appreciate your understanding. I promise to give this some serious thought."


    scene v15-242 with fade
    b "Well, I should probably get going. It's getting late."
    ass "Banu, I just want to say that I really appreciate you listening to me and giving me a chance to express my feelings."
    b "Of course, Aslan. I'm glad you felt comfortable enough to share with me."
    scene v15-244
    ass "And I also want you to know that I value our friendship, no matter what happens."
    b "Thank you, Aslan. I value our friendship too. And I'll definitely think about what you said."
    ass "That's all I can ask for, Banu. I just want you to be happy, no matter what you decide."
    scene v15-243
    b "That's very kind of you, Aslan. And I want you to know that I'm here for you too, whenever you need a friend."
    ass "I appreciate that, Banu. You're a really special person."
    scene v15-245
    b "You're not so bad yourself, Aslan.."
    ass "Take care, Banu. And let me walk you to the door."
    b "But I thinkg you're forgetting something..."
    ass "..."
    b "Don't you want to lend me your books?"
    ass "Oh yeah, my bad...wait a minute. I'm bringing them..."


    scene black with Dissolve(3)
    ""
    centered "{size=+120}On the way{/size}" with Fade(0.5, 0.5, 5)
    scene v15-246 with irisin
    play music "audio/tension.mp3"
    "Banu steps out of Aslan's apartment and onto the narrow, dimly lit street."
    "The night air is cool and quiet, and she shivers a little. She glances around nervously, feeling a bit uneasy as she realizes she's alone in the dark."
    scene v15-247
    "As she begins to make her way down the street, her footsteps echoing against the pavement, she can't help but think about her conversation with Aslan."
    "She's still processing his confession, and although she's flattered, she's also a bit nervous about what it could mean for their friendship."
    scene v15-248
    "Banu walked along the narrow street, the darkness enveloping her."
    "She shivered, feeling a sudden coldness in the air. As she walked, she saw an old beggar with torn clothes, sitting against a wall."
    scene v15-249
    "Banu stopped in her tracks and looked at the beggar. He was thin and looked like he hadn't been washed in months."
    scene v15-250
    beg "Excuse me, ma'am. Do you have any spare change you could give me? I'm down on my luck and could use some help."
    menu:
        "Give him money":
            $ renpy.block_rollback()
            $ banuignorethebeggar = False
            scene v15-252
            stop music
            b "Okay let me see what I have."

            b "Here, take this. It's not much, but I hope it helps."
            scene v15-253
            beg "Thank you, kind lady. You have a good heart."
            b "Is there anything else I can do for you?"
            scene v15-251
            beg "Actually, I can do something for you. If you ever need any work done around your home, I can help you with that. I'm a good handyman."
            b "Oh, I see. Well, thank you for the offer. I'll keep it in mind."
            beg "Thank you, miss. May God bless you."
            b "You too, sir. Take care."
            "Banu continues on her way, feeling a little lighter knowing that she helped someone in need."
        "Ignore him":



            $ renpy.block_rollback()
            $ banuignorethebeggar = True


            b "I'm sorry, I don't have anything to give you."
            beg "Please, just a little something. I'm hungry and need to eat."
            b "I'm sorry, but I really don't have anything on me."
            beg "You're lying. Just give me some money, please."
            b "No, I'm not lying. And please don't bother me and get out of my way."
            scene v15-254
            beg "You're a selfish woman. All you care about is yourself."
            b "I'm sorry you feel that way, but I have to go now. Take care."
            beg "I know you have money. It's visible from your pocket right here."
            "Saying that the beggar pointed his right hand to Banu's pocket and..."
            scene v15-255 with hpunch
            b "Fuck off! You old bastart!"
            scene v15-256 with vpunch
            b "You old pig!"
            b "How do you dare to touch me with your dirty hands?"
            b "Go to hell!"
            scene v15-257
            stop music
            "Banu walks away quickly, feeling uneasy and a bit frightened."
            "She keeps a tight grip on her pocket, looking around to make sure she's not being followed."






    scene black with Dissolve(3)
    ""
    centered "{size=+120}Coffee break{/size}" with Fade(0.5, 0.5, 5)


    $ banuwantstoteaseintern = False
    $ banustaysalittlelongerintern = False
    $ banuskeptikalaslan = False
    $ banumockaslan = False
    $ banuchoosefirstone = False
    $ banuordersservant = False
    $ orderservantlickfoot = False
    $ slapservant = False
    $ askservantshowdick = False


    scene v16-1 with blinds
    "Banu was busy organizing files neatly on the shelf. "
    "Just as Banu was immersed in her work, the door creaked open, and Samir walked in with an eager smile."
    "He carried two steaming cups of coffee with a touch of nervousness mixed with excitement in his eyes."
    "Banu had asked him to bring the coffees, and secretly, he was thrilled for this chance to spend some time with her."
    scene v16-2
    b "Oh, Samir! You brought the coffees. Thank you so much."
    sam "You're welcome, Banu. I wanted to make sure they were just the way you like them."
    b "I appreciate your thoughtfulness, Samir. You're doing great as an intern here."
    b "Please, put the coffees on the table and come join me on the sofa. Let's take a break and chat for a while."
    sam "Sure, Banu. I'll do that."
    scene v16-3
    "Samir carefully placed the cups on the table and walked over to the sofa, sitting down beside Banu."
    "She couldn't help but notice the subtle signs of nervousness etched on his face."
    "Banu recognized the signs and wanted to alleviate Samir's unease. She finished organizing her files and set them aside, giving him her undivided attention."
    b "Samir, I can't help but sense a bit of nervousness. Is everything okay?"
    sam "Oh, um, yeah, Banu. I'm fine. It's just... I don't want to make any mistakes in front of you. I want to do a good job."
    b "Samir, I understand how you feel. We all have moments of nervousness, especially when we're starting something new."
    b "But please remember, mistakes are a natural part of the learning process. What's important is that we learn from them and grow."
    sam "Thank you, Banu. I appreciate your understanding. I really want to make a good impression here."
    scene v16-13
    b "Ah, that's good. It's nice to have a moment to relax, isn't it?"
    sam "Absolutely. It's a great opportunity to learn from someone experienced like you."
    b "Thank you, Samir. I'm happy to share my knowledge and help you grow in your career. So, how are you finding your time here so far?"
    sam "It's been amazing, Banu. I've learned so much already, and everyone has been really supportive. Working alongside professionals like you is truly inspiring."
    scene v16-4
    b "So, Samir, let's talk about something a bit more personal. Love and relationships. What are your thoughts on that?"
    sam "Oh, love and relationships, right. Well, I think it's a complicated subject, you know?"
    sam "People have different expectations and experiences, and it can be challenging to navigate."
    b "I sense some hesitation, Samir. Is there something on your mind? Perhaps a personal experience you'd like to share?"
    sam "Well, honestly, it's not something I usually discuss, but I've had some mixed experiences. It can be confusing at times, and I'm still trying to figure it all out."
    b "I understand, Samir. Relationships can be complex, and it takes time to find what works for each individual. It's alright to take your time and explore what feels right for you."
    b "Samir, I'd like to discuss something with you. What are your thoughts on a situation where a young boy develops feelings for an older woman?"
    b "How do you think such a scenario should be approached?"
    scene v16-5
    sam "Oh, well, I don't see any problem with that, Banu. Age shouldn't matter when it comes to love, right? "
    sam "If two people genuinely care for each other, I think they should be allowed to explore their feelings, regardless of age."
    b "Samir, love is indeed a beautiful thing, but it's important to consider the complexities that can arise in relationships with significant age differences."
    sam "I guess I haven't really thought about it that way before. I just believe that love knows no boundaries, and if two people connect, age shouldn't be a barrier."
    b_ "Oh, Samir, you're so young and idealistic. It's clear that you still have much to learn and experience when it comes to matters of the heart."
    b_ "Your belief that love knows no boundaries is charming, but it overlooks the potential power imbalances, societal judgments, and practical challenges that often come into play."
    menu:
        "Banu wants to help him":
            $ banuwantstoteaseintern = False
            $ renpy.block_rollback()
            scene v16-6
            b "Samir, I've noticed that you tend to be quite shy, and I want to discuss this with you. "
            b "Frankly, I'm a bit frustrated with your shyness because it can hinder your personal growth and interactions, particularly when it comes to relationships."
            sam "Oh, I'm sorry, Banu. I didn't mean to frustrate you. Shyness has always been a part of who I am, and it's not something I can easily change."
            b "I understand that shyness is a part of your personality, Samir, but that doesn't mean you can't work on overcoming it or finding ways to manage it."
            b "It's essential to realize that shyness can hold you back from fully experiencing life and forming meaningful connections."


            scene v16-7
            sam "I don't think being shy is such a bad thing. I've always been reserved, and I've managed to get by just fine."
            b "Samir, I understand that you may feel comfortable with your shyness, but it's important to recognize that it can limit your opportunities."
            b "If you want to grow personally and establish strong relationships, you need to challenge yourself and step out of your comfort zone."
            sam "Why are you so against my shyness? It's a part of who I am, and I don't see why I need to change just to please others."
            b "Samir, I'm not asking you to change who you are at your core. I'm merely encouraging you to develop social skills and confidence so that you can fully express yourself and connect with others."
            b "It's not about pleasing others; it's about unlocking your own potential and fostering meaningful relationships."
        "Banu wants to tease him":




            $ banuwantstoteaseintern = True
            $ renpy.block_rollback()
            play music "audio/sidesex.mp3"
            scene v16-8
            b "Samir, I wanted to ask about your relationship with your girlfriend. Last time we spoke, you mentioned her. How are things going between you two?"
            sam "Actually, Banu, she's no longer my girlfriend. We broke up recently."
            b "Oh, Samir, I'm sorry to hear that. Are you okay? Do you want to talk about what happened?"
            sam "It's just that she felt I was too reserved and shy, that I didn't open up enough. She said she needed someone who could be more emotionally available and outgoing."
            b_ "Poor Samir..."
            b "I understand that this must be difficult for you. It's unfortunate that your shyness played a role in the relationship ending."
            sam "I guess you're right, Banu. Maybe I do need to work on being more open and expressive in my future relationships."
            scene v16-9
            b "Well, Samir, now that you're single, are you ready to dive back into the dating world and find yourself another girl?"
            sam "Oh, Banu, I think I need a little time to heal and focus on myself before jumping into another relationship. But who knows, maybe in the future, I'll be ready to give it another shot."
            b_ "He's so funny..."
            b "That's fair, Samir. Take your time, enjoy being single, and when you're ready, don't forget to put those newfound social skills and confidence to good use. Just remember, there's plenty of fish in the sea."
            scene v16-11
            "Banu, feeling a mischievous spark, decides to playfully tease Samir. She moves closer, intentionally invading his personal space. Samir, taken aback, starts to feel uncomfortable, shifting uneasily in his seat."
            b "Now, Samir, let's get a little closer for some girl talk, shall we?"
            sam "Uh, Banu, I think this is close enough. I can hear you just fine from here."
            b "Oh, come on, Samir, don't be shy. It's just a little chat between friends."
            scene v16-10
            b "So, Samir, let's have a little chat about girls. I know it can be a bit overwhelming, but I'm here to offer you some advice from my years of experience."
            sam "Uh, okay..."
            b "First things first, confidence is key. Believe in yourself and let your authentic personality shine. Girls are attracted to someone who is comfortable in their own skin."
            sam "Uh, I'll try my best to be more confident, Banu. It's just not something that comes naturally to me."
            scene v16-12
            b "So, Samir, I've noticed you've been quite attentive today. Is there something on your mind?"
            sam "Uh, well, I guess I... um... enjoy our conversations. You're really easy to talk to, Banu."
            b "Oh, Samir, you're such a charmer. I appreciate your kind words. You're a great listener, too."
            b "Well, Samir, it seems like someone has a little crush on their HR assistant. Should I be worried about the company's intern policy?"
            sam "No, no, Banu! It's not like that. I mean, I do like you, but it's just... um... a friendly liking, you know?"
            b "I see you're a grown up man already and you started to look at my ass. Do you like that?"
            sam "No! Banu...that was just..."
            b "I saw it, Samir. You can't deny that. Your bulging pants tell me that you're so excited about me."
            b "I'm sure that you dreamt about me and masturbated countless times thinking about me. "
            sam "Banu..."
            b "Well, you know that you can't have me but there's something that you can do. You're a man now and you need to release the sperm from your body."
            b "Do you know that I don't shave my pussy? Hehe now you know that. Jerk off your cock thinking about my pussy. You need it and I'm not against it."
            sam "No, no, Banu! It's not like that...."
            scene v16-13 with fade
            stop music
            b "Of course, Samir. I was just teasing you. Don't worry, your secret crush is safe with me."

    scene v16-5 with fade
    b "Samir, I really need those files for a project I'm working on. Did you bring them as I asked?"
    sam "Oh, Banu, I'm so sorry, but I completely forgot to bring them. They're still at home. I feel terrible about this."
    b "Samir, I needed those files today. It's crucial for the progress of the project. Is there any way you can retrieve them quickly?"
    sam "Actually, Banu, I live close by. If you'd like, I could go to my place and grab the files but I was thinking..."
    sam "How about coming over this afternoon to collect the files?"
    sam "Plus, it'll give you a chance to see where I live. "
    b "Well, since I do need the files and you're offering, I suppose it would be convenient."
    sam "Absolutely, Banu! Thank you for accepting my invitation."
    "Banu and Samir agree on the plan, with Banu feeling a mix of relief and curiosity about Samir's home."
    "They quickly discuss the logistics and set a time for the visit, ensuring that the work will continue smoothly. The invitation to Samir's home adds a touch of anticipation to their day."

    scene black with Dissolve(3)
    ""
    centered "{size=+120}Samir's home{/size}" with Fade(0.5, 0.5, 5)
    scene v16-14 with fade
    play music "audio/kometaback.mp3"
    "Banu arrives at Samir's home in the sunny afternoon, curious to see where he lives."
    "As she approaches the house, she notices that it is a small, old building with a charming, albeit weathered, exterior."
    scene v16-15
    sam "Hey, Banu! I'm glad you made it. Welcome to my home."
    b "Thank you, Samir. It's nice to be here."
    sam "So, this is our little garden. It's not much, but it's a nice spot to relax and enjoy some fresh air."
    b "It's lovely, Samir. I can see the care you put into maintaining it. It's a peaceful retreat."
    "Banu couldn't help but notice the age and wear of Samir's home, but she tactfully avoids bringing it up to spare Samir any further embarrassment."
    "She understands that their financial situation may have contributed to the condition of the house and doesn't want to make Samir feel uncomfortable about it."
    scene v16-16
    stop music
    meta "Samir, who is this young lady?"
    sam "This is my mother...Come and meet her, Banu."
    scene v16-17
    sam "Mom, this is Banu, my colleague from work. She's here to visit and spend some time with us."
    sam "Banu, this is my mom, Metanet."
    b "Nice to meet you, aunt."
    "Instead of offering a warm greeting, Metanet's face displays a disapproving expression. She immediately redirects her attention towards Samir."
    meta "Samir, why are you bringing your colleague into the house? You know very well that we have our own responsibilities and chores to attend to."
    sam "Mom, Banu is just visiting. I invited her over to spend some time together. It's important to show hospitality and make her feel welcome."
    meta "Hospitality? Is that what you call it? Instead of helping me with the household tasks, you're gallivanting around with your colleague. It's high time you focus on your responsibilities here."
    "Banu feels a sense of discomfort witnessing the tension between Samir and his mother. She tries to remain composed, knowing that it is not her place to interfere in their family dynamics."
    scene v16-18
    b "Aunt, I apologize if my presence has disrupted your routine. I didn't mean to cause any inconvenience."
    meta "Your presence is not the issue. It's Samir neglecting his duties and prioritizing other things over his family responsibilities. We have our way of doing things here."
    meta "Well, Banu, it's quite usual I see for women to wear these tight jeans trousers nowadays. Don't you think it's a little inappropriate. We have different standards here."
    b "I understand, Aunt. Fashion choices can vary, and I respect that. I assure you, it's nothing disrespectful or inappropriate."
    scene v16-19
    meta "It's not about fashion, dear. It's about respecting our traditions and values. We have certain expectations when it comes to proper attire."
    b "I apologize if my attire doesn't align with your expectations, Aunt. I didn't mean to offend anyone. I assure you, my intention is to be polite and respectful."
    scene v16-20
    sam "Mom, let's not focus on Banu's attire. She's a wonderful person and a valued colleague. I invited her here because I enjoy her company."
    "Samir, sensing the tension between his mother and Banu, takes a step forward to defuse the situation and invites Banu inside the house."
    sam "Banu, why don't we go inside? Please, come in and make yourself comfortable."
    b "Thank you, Samir. I appreciate your hospitality."
    scene v16-21
    "Metanet, still harboring her concerns, watches as Samir and Banu walk into the house together. She remains hesitant and decides not to follow them."
    "Banu follows Samir into the house, but she notices that Metanet doesn't join them."
    "As she steps inside, she takes a closer look at the room and notices its dilapidated state. The furniture is worn, the walls are peeling, and dust collects in neglected corners."
    "Banu maintains her composure, not wanting to make Samir feel embarrassed or uncomfortable about the condition of the room. "
    b "Samir, your home has a certain charm. It feels lived-in and carries a sense of history."
    sam "Thank you, Banu. I know it's not the most glamorous place, but it's where I grew up. It may not look like much, but it's filled with memories and love."
    scene v16-22
    sam "Banu, I'm sorry about my mother's behavior earlier. She's going through a tough time, and I think she was just upset about something unrelated. It's not a reflection of how she feels about you."
    b "Samir, there's no need to apologize. I understand that people have their own struggles and emotions. I hope everything gets better for your mother soon."

    scene v16-23
    sam "Banu, would you consider staying a bit longer? I enjoy spending time with you, and I don't want our conversation to end just yet."
    menu:
        "Banu is in a hurry":
            $ banustaysalittlelongerintern = False
            $ renpy.block_rollback()
            b "Samir, I would love to stay longer, but I'm afraid I'm in a bit of a hurry. I really need those files we discussed earlier, so I can't stay for too much longer."
            sam "I understand, Banu. I'm sorry for keeping you waiting. Let me go and get the files for you right away."
            b "That would be great, Samir. I appreciate your help. Just grab the files quickly so I can take them with me and continue my work."
            scene v16-24
            "Banu observes Samir as he searches for the files, and a sense of pity washes over her. "
            "She can't help but feel a pang of sympathy for him and his family, realizing the financial hardships they must be facing."
            b_ "It's heartbreaking to see how they're struggling financially. The condition of their home and the challenges they face must weigh heavily on Samir's shoulders."
            b_ "He's just a young man trying to navigate his way through life, and yet he's burdened with so much. I can't imagine the difficulties they've endured."


        "Banu enjoys to stay a little longer" if banubad >= 300:
            $ banustaysalittlelongerintern = False
            $ renpy.block_rollback()
            scene v16-25
            b "Well, don't you think it's late?"
            sam "Banu, please stay a little longer. I enjoy our conversations and your company. It would mean a lot to me."
            b "Well, Samir, since you asked so nicely, I suppose I can stay a little longer. But remember, I have other things to attend to, so don't get too used to it."
            scene v16-26
            "Banu, feeling a sense of comfort and playfulness in Samir's home, notices his bed and decides to playfully walk over and sit on it."
            "With a mischievous smile, she takes a few steps towards the bed, her movements light and carefree."
            "Banu approaches the bed, her fingers lightly grazing the edge as she lowers herself onto it, settling in with a playful bounce. The bed feels soft and inviting, adding a touch of spontaneity to their interaction."
            scene v16-27
            "Samir watches Banu's playful actions, a mix of surprise and delight on his face. He finds her spontaneity endearing, and it brings a sense of warmth to the atmosphere."
            sam "Banu, you certainly know how to make yourself at home!"
            b "Well, Samir, it's all about being comfortable, right? And your bed looked too inviting to resist."
            sam "I'm glad you feel comfortable here. It's nice to have someone who can bring a sense of lightness to this place."
            "Banu's playful gesture breaks the tension that may have lingered, allowing both of them to relax and enjoy the moment. The simple act of sitting on Samir's bed creates an intimacy that brings them closer together."
            b "So, Samir, since I'm staying a bit longer, how about we play a little game?"
            sam "A game?"
            b "Yeash, come and sit with me."
            scene v16-28
            "Banu, feeling a sense of adventure, suggests playing a game of truth or dare, wanting to delve deeper into their connection. She looks at Samir with a playful glint in her eyes and extends an invitation."
            b "Let's play a game of truth or dare. It's a great way to get to know each other better. What do you say?"
            sam "Um, truth or dare? That sounds... fun, I guess. Okay, let's do it!"
            "They face each other, their knees slightly touching, as the game begins. Banu starts by taking the first turn."
            scene v16-29
            "Banu notices Samir's nervousness and she starts to really enjoy it while slightly caressing his knee with her fingers."
            b "Alright, Samir, truth or dare?"
            sam "Um, let's start with... truth."
            b "Alright, Samir. Here's my question for you. What's the most adventurous thing you've ever done?"
            "Samir takes a moment to think, his face lighting up with a mix of excitement and nostalgia."
            sam "Well, a few years ago, I went skydiving with my friends. It was an adrenaline rush like no other, and I still remember the feeling of jumping out of the plane. It was both terrifying and exhilarating at the same time."
            scene v16-31
            sam "Alright, Banu, truth or dare?"
            b "I'm feeling brave today. Give me the truth, Samir."
            sam "Alright then, here's my question. What's the most embarrassing thing you've done with your husband?"
            scene v16-29
            "Banu's eyes widen, caught off guard by the question. She blushes, realizing she'll have to share a personal and potentially embarrassing moment from her own experiences."
            b "Well, if you wanna hear it, here it comes."
            b "A few years ago when we were having sex, he tried to do me from behind, you know what I mean? "
            b "He tried to enter me from the back door. I could never let that happen of course."
            b "Do you know what happened next? He slept that night on the sofa. I tought him a good lesson that night."
            b "Are you satisfied now?"
            scene v16-30
            "As the game of truth or dare continues, it's Banu's turn to ask Samir an embarrassing truth. She takes a moment to think, her playful eyes scanning Samir, searching for a question that will challenge him."
            b "Alright, Samir, truth or dare?"
            sam "Well, I've survived a few truths so far. Let's stick with truth again."
            b "Alright, Samir. Here's my question for you. Who do you think about when you masturbate?"
            sam "Well, I don't actually masturabte so much...just one or two times in a month..."
            b "Come on, I know that you maturbate every day. I sense it when I look at you but that is not important. Answer my question?"
            sam "Well since we're so open like this...here's the truth. I think about you, Banu!"
            b "Wow...I knew that."
            sam "Are you satisfied now?"
            b "I guess so."
            scene v16-31
            sam "Alright, Banu, truth or dare?"
            b "I'm up for a dare this time, Samir. Bring it on!"
            "Samir's eyes widen, realizing the daring nature of his dare. He takes a moment to gather his thoughts, wanting to push the boundaries just enough to create a playful and exciting moment."
            sam "Alright, Banu, for your dare... I dare you to take off one piece of clothing."
            scene v16-29
            "Banu's eyebrows raise in surprise, caught off guard by the audacity of Samir's dare. She giggles, a mischievous glint in her eyes."
            b "Oh, Samir, you're getting bolder, aren't you? Alright, challenge accepted!"
            scene v16-32 with hpunch
            "It took Samir by surprise that Banu actually started unbuttoning her shirt slowly from the bottom to the top."
            b "Do you think that I'll accept the defeat? Never!"
            sam "Banu...what are you doing?"
            b "What? Don't you want to see what is inside? "
            scene v16-33 with hpunch
            sam "Banu, you really did that..."
            b "Well, do you like what you see?"
            sam "I..I don't know...yeah of course I like it but...I just can't believe you did that..."
            b "This is only for you Samir. I know you wanted to see them so bad, didn't you?"
            sam "..."
            b "Do you want to touch it?"
            sam "Yeah, but..."
            b "Come on touch it already, I don't have much time."
            scene v16-34
            sam "It's so soft and warm, Banu."
            b "Do you like it?"
            sam "Of course I do."
            b "Feel free to play with it but don't squeeze it so hard."
            sam "No, I won't..."
            b "I see you're excited down there...Do you let me touch you?"
            sam "..."
            scene v16-35
            sam_ "Oh shit..."
            b "Wow, you're rock hard."
            b "I didn't know I make you excited like this."
            b "I should definitely be careful around you, big boy."
            scene v16-36 with hpunch
            met "Samir, what are you doing so long here?"
            "As Banu and Samir immerse themselves in the game, their playful banter is suddenly interrupted by the entrance of Samir's mother."
            scene v16-37
            "Banu quickly turned around to button her shirt while Samir confronted his mother."
            sam "Mom, why are you shouting again?"
            met "What do you mean why I'm shouting? Why hasn't she left already? What is she doing there."
            sam "Mom, she's just picking the documents related to work."
            scene v16-38
            b "I'm sorry, I took a lot of your time. I'm just about to leave."
            "Metanet's disapproval towards Banu is palpable as she enters the room."

            scene v16-39
            "Her cold gaze and distant demeanor make it clear that she does not hold a favorable opinion of Banu."
            "Metanet's brows furrow, and her lips form a thin line, indicating her disapproval."
            met " Samir, can I speak with you for a moment?"
            scene v16-40
            "As Samir follows his mother, Banu observes the interaction, noting the tension and the strained expressions on their faces. "
            "Banu's suspicions about Metanet's feelings are confirmed as she witnesses the whispered conversation between Samir and his mother."
            "Although unable to hear their words, Banu can sense the gravity of the situation by the disappointment etched on Samir's face."
            "Despite feeling the weight of Metanet's disliking, Banu remains composed, understanding that it's crucial not to escalate the tension."



    scene black with Dissolve(3)
    ""

    $ banugotomuratsapartmentafterfun = False
    $ banuagreebowlingmurat = False




    centered "{size=+120}Murat{/size}" with Fade(0.5, 0.5, 5)
    scene v16-120 with blinds
    play music "audio/kometaback.mp3"
    "Banu, clad in her pink sportswear, took a solitary stroll through the sunlit city streets. The warm rays of sunlight cascaded down, casting a golden hue on her surroundings."
    "Despite the pleasant weather, her mind was clouded with thoughts, burdened by stress and a sense of loneliness."
    "As she walked along the bustling sidewalks, the sounds of city life enveloped her."
    "Conversations melded into an indistinguishable buzz, while the distant honking of cars echoed in the distance. The vibrant cityscape seemed to carry on with its rhythm, oblivious to Banu's inner turmoil."
    scene v16-121 with wipeleft
    "At the same time, about half a mile away from Banu, Murat was strolling through the city streets with his palpable vibrant energy."
    "A smile adorned his face, radiating positivity to those around him."
    "The sun's warm rays seemed to reflect his cheerful disposition, illuminating the path he traversed."
    scene v16-122 with wiperight
    "While Banu's face seemed to bear the weight of her worries..."
    scene v16-123 with wipeleft
    "Murat's face reflected an inner lightness, an unwavering positivity that he carried with him."
    scene v16-122 with wiperight
    "Banu's sad face, subdued and introspective, seemed to blend into the background of the bustling city, almost unnoticed amidst the vibrant colors and lively energy."
    scene v16-123 with wipeleft
    "Meanwhile, Murat's vibrant face drew attention, attracting the gazes of passersby, who couldn't help but be captivated by his infectious enthusiasm."
    scene v16-124 with fade
    "As Banu continued her lonely walk through the city, lost in her thoughts and weighed down by her emotions, her eyes suddenly met with a familiar face in the distance."
    "It was Murat, walking towards her with his characteristic smile and a twinkle in his eyes."
    "Banu's sad face, momentarily interrupted by the sight of Murat, softened with a flicker of recognition."
    "The corners of her mouth lifted slightly, reflecting a glimmer of hope amidst her troubled state. Her eyes, once clouded with sadness, now held a trace of warmth as they locked onto Murat's."
    scene v16-125
    "Murat, his energetic stride never faltering, approached Banu with an enthusiastic greeting."
    mur "Hey, Banu! Fancy running into you here. How's it going?"
    "Banu, surprised by the unexpected encounter, couldn't help but feel a sense of comfort in Murat's presence."
    b "Oh, Murat. It's been a tough day, but seeing you brings a little light to it. How about you? How's life treating you?"
    mur "I'm sorry to hear that, Banu. Life's been treating me well, but knowing you're having a rough time makes me want to offer support."
    mur "If you ever need someone to talk to or simply want a listening ear, count on me."
    scene v16-126
    b "You know, Murat, I have to admit something. You're really good with women."
    mur "Oh, really? Well, thank you, Banu. "
    b "You have this way of making people feel comfortable and appreciated. I've seen how effortlessly you connect with others, especially women. It's a gift."
    mur "I appreciate your kind words, Banu. "
    mur "But let's not forget, you have your own special qualities that draw people towards you as well."
    b "So, Murat, am I special to you? Or am I just another face in the crowd?"
    scene v16-127
    mur "Banu, you know you're more than just another face in the crowd. "
    b "Oh, really? And what makes me so special, Mr. Smooth Talker?"
    mur "Well, for starters, you have this unique ability to light up a room with your presence. "
    mur "Your warmth and genuine nature make people feel comfortable and valued. And your sense of humor always brings a smile to my face."
    mur "Hey, Banu, I was thinking it would be fun to grab a coffee and go bowling together. What do you say?"
    stop music
    menu:
        "Banu rejects":
            $ renpy.block_rollback()
            $ banuagreebowlingmurat = False
            scene v16-126
            b "Hmm, that does sound like fun, Murat. But I have to be honest with you. I can't help but feel a bit skeptical about your intentions."
            mur "Why that? I simply thought it would be enjoyable to spend some time together."
            b "Come on, I know your intention is not just to play bowling. I have noticed the way you look at me, and it makes me feel uncomfortable. Plus, I'm married, and I want to honor my commitment to my husband."
            scene v16-127
            mur "You're the way smarter than I expected. Just keep in mind that if you need support or bored, you have my number and I'm always here for you."
            b "Thank you again, Murat. I'll keep it in mind."
        "Banu agrees":

            $ renpy.block_rollback()
            $ banuagreebowlingmurat = True
            scene v16-126
            play music "audio/chill.mp3"
            b "I just want to let you know that I don't trust you because you're a man."
            b "But honestly, I'm quite bored, so I guess I'll give it a shot."
            scene v16-127
            mur "I understand if you're hesitant, but I promise to respect your choices."
            scene v16-126
            b "Alright, Murat. I'll take your word for it, but I want to be clear that this is strictly as friends. If at any point I feel uncomfortable or sense any inappropriate behavior, I'll have to end our outing."
            mur "Let's just have a good time and enjoy each other's company."
            b "..."
            scene v16-133 with pixellate
            "Banu and Murat found themselves seated at a cozy coffee table in the vibrant atmosphere of the bowling club. "
            "The sound of rolling balls and jubilant cheers filled the air, adding to the excitement that surrounded them."
            "As they settled in, the conversation flowed effortlessly, and Banu couldn't help but find herself genuinely enjoying Murat's company."
            mur "Hey, Banu, did you know that I have a black belt in bowling? They call me the Strike Ninja!"
            b "Strike Ninja? That's a new one! So, should I be worried about any karate moves with that bowling ball of yours?"
            mur "Watch out! I might just unleash my secret bowling technique - the unstoppable Flying Strike Kick!"
            b "Oh, please! I can't even imagine what that would look like. But I must admit, you have a way of turning bowling into a martial art!"
            mur "Well, you know what they say, Banu - the key to a perfect strike is a strong mind, a steady hand, and a killer sense of humor!"
            scene v16-134
            b "Well, you definitely have the humor part covered, Murat. You always manage to bring a smile to my face, even in the midst of a tense situation!"
            mur "That's the goal, Banu. Laughter is the secret ingredient that makes everything better. Besides, what's a game of bowling without a few good jokes and shared laughter?"
            b "You're absolutely right, Murat. Life should be filled with moments of joy and lightness, even in the simplest things like bowling. Thanks for reminding me to embrace the fun and laughter."
            scene v16-133
            mur "Come on, Banu! Let's start bowling already. It's going to be so much fun!"
            scene v16-134
            b "I have to be honest, Murat. I'm not really good at bowling. I don't want to embarrass myself."
            mur "Nonsense, Banu! Bowling is all about having a good time. Trust me, you'll get the hang of it in no time. Plus, I'll be right there to guide you through it."
            b "I appreciate your confidence in me, Murat. But I'm not sure if I can do it."
            mur "Come on, Banu..."
            scene v16-135 with fade
            b "Heyyy, okay I'm coming."
            mur "We'll figure it out together. Don't worry about being perfect. Let's just have fun and enjoy the experience."
            b "Okay, okay! I'm going, but you better be ready to witness my terrible bowling skills."
            scene v16-136
            mur "I can't wait to see what you've got, Banu! I have a feeling you'll surprise yourself."
            b "Alright, Murat, here I go. Any last-minute tips?"
            mur "You've got this, Banu! Just take a deep breath, aim for the middle pin, and give it a nice, smooth roll. Remember, it's all about finding your rhythm."
            b "Okay, I'll give it my best shot!"
            scene v16-137
            "Banu stepped forward to the edge of the lane, her focus intensifying. With a determined expression, she swung her arm back and gracefully released the ball. It glided down the lane, steadily rolling towards the pins."
            mur "Looking good, Banu! Keep going!"
            "The ball approached the pins, and with a satisfying thud, it knocked down several of them, leaving a scattered arrangement. Banu's eyes widened, and a mixture of surprise and delight spread across her face."
            scene v16-138 with fade
            b "I did it! I actually hit some pins!"
            mur "That was fantastic, Banu! You're a natural. See? I told you that you could do it!"
            b "Alright, Murat, it's your turn now. Show me what you've got! I bet you can't knock down all the pins in one shot."
            mur "Oh, Banu, you're underestimating my bowling skills. I'm so sure I'll get a strike that I'm willing to bet on it!"
            b "Really? You're that confident, huh? Alright, let's see what you've got. But don't be surprised when you don't get all the pins."
            scene v16-139
            "Murat positioned himself at the edge of the lane, holding the bowling ball in his hands. He took a deep breath, focusing his gaze on the pins ahead."
            mur "Watch closely, Banu. This one's for the skeptics!"
            "With a swift motion, Murat released the ball, sending it gliding down the lane with precision."
            "As if guided by an invisible force, the ball curved just at the right moment, striking the pins with a satisfying crash."
            scene v16-140
            b "No way! You actually got them all! I can't believe it!"
            mur "Told you, Banu! Never underestimate the power of a little confidence. Looks like I owe you a victory dance!"
            b "Fine, fine. You win this time, Mr. Bowling Champion. But let's see if you can keep up that perfect score throughout the game!"
            "Their playful banter continued as they completed their game, exchanging laughter and friendly competition. Murat's strike had left Banu in awe, but it only fueled her determination to improve her own skills."
            scene v16-141 with fade
            "As Banu and Murat continued playing their game of bowling, the atmosphere filled with excitement and laughter."
            "The joy they found in each other's company became evident as their friendship deepened through shared moments of triumph and lighthearted banter."
            "With each successful shot and strike, their connection grew stronger. Banu couldn't help but feel a sense of comfort and ease whenever she was around Murat, and the same sentiment seemed to hold true for him."
            "In a moment of exhilaration, Murat couldn't contain his excitement any longer."
            "As Banu celebrated another well-earned strike, he playfully and instinctively wrapped his arms around her from behind, pulling her into a warm, spontaneous embrace."
            b "Well, someone's feeling quite victorious, aren't they? I didn't know hugging was part of the bowling game!"
            mur "I couldn't help it, Banu! You're just too amazing at this. The thrill got the best of me!"
            b "Well, Mr. Hugger, be prepared for some tough competition. I won't let you win so easily!"
            mur "Oh, it's on, Banu! You better bring your A-game because I won't go easy on you!"
            "..."
            scene v16-128 with fade
            "After an exhilarating game of bowling, Murat couldn't contain his infectious energy and mischievous spirit. Holding Banu's hand tightly, he led her on a playful and joyous run through the city streets."
            "Banu, her face glowing with laughter and excitement, gladly followed along, fully immersed in the moment."
            "As they dashed through the bustling city, their laughter echoed in the air, catching the attention of passersby who couldn't help but smile at their infectious enthusiasm."
            "Banu's tired legs were evidence of their adventure, but her spirit remained uplifted and energized."
            scene v16-129
            mur "Come on, Banu! Just a little bit farther. I have a surprise for you!"
            b "You really know how to keep the fun going, don't you? I don't even know where we're headed, but I'm loving every moment!"
            "Their laughter intertwined with the rhythm of their footsteps as they navigated the winding streets, their destination looming ahead. Banu's heart raced with anticipation, wondering what surprise awaited her at the end of their spirited journey."
            scene v16-130 with hpunch
            "In a spontaneous burst of joy, Murat playfully grabbed hold of both of Banu's hands. With a mischievous smile, he began to twirl her around, gently spinning her in a circle."
            "Banu's laughter filled the air as her head spun with a delightful mixture of dizziness and excitement."
            b "Murat, what are you doing? You're going to make me dizzy!"
            mur "Just a little fun, Banu! Let's keep the laughter going and see if we can make the world spin!"
            "As Murat continued to twirl Banu, the world around them blurred, their laughter intermingling with the sounds of the bustling city. In that moment, time seemed to stand still as they embraced the pure joy of the present."
            b "Okay, Murat, you win! My head is spinning, but it's the best kind of dizzy. You really know how to make me smile!"
            scene v16-131
            "Banu, I have an idea. Why don't you come up to my apartment? I want you to be my guest, just for a little while. We can continue our fun and laughter in a more comfortable setting."
            "Oh... um, Murat, I appreciate the invitation, but I'm not sure. We've had a great time so far, but I'm not sure if going to your apartment is the right thing to do."
            mur "Banu, please reconsider. I genuinely enjoy your company."
            stop music
            menu:
                "Reject him":
                    $ renpy.block_rollback()
                    $ banugotomuratsapartmentafterfun = False
                    scene v16-132
                    b "Murat, I appreciate your persistence, but I know what accepting this invitation would imply. As a married woman, it wouldn't be appropriate for me to go to your apartment alone."
                    mur "Banu, let's forget about everything else for a moment. Come to my apartment and let's just have fun together. No worries, no obligations, just a chance to enjoy each other's company."
                    b "Murat, I can't do that. I appreciate your invitation, but I am a married woman, and it wouldn't be right for me to disregard my commitment to my husband."
                    b "I value our friendship, but I must prioritize my marriage and the trust that exists within it."



                "Go with him" if banubad >= 300:
                    $ renpy.block_rollback()
                    $ banugotomuratsapartmentafterfun = True

                    jump muratfucksbanuafterfunsexscenestaywithkamil

                    scene v16-132
                    b "Murat, I can't believe I'm agreeing to this, but okay. Just 5 minutes, and then I need to leave. No longer than that, okay?"
                    mur "Deal! I promise you won't regret it. Let's go!"
                    scene black with dissolve
                    "..."
                    scene v16-142 with dissolve
                    b "Wait...you're such a liar, Murat."
                    b "....mmmmp.."
                    mur "Your lips taste so good. I can kiss you all day."
                    b "You're going to choke me, maniac."
                    b "Is it your fisrt time kissing?"
                    mur "You're driving me crazy, Banu. I can't control myself with you."
                    scene v16-143 with fade
                    b "Mmmp...oh god...stop touching me there...ohh."
                    mur "You like this, don't you?"
                    b "We didn't agree on taking the clothes off, did we?"
                    scene v16-144 with fade
                    mur "Shhhh...just enjoy the moment. "
                    b "Your dick....it's touching me..."
                    mur "Damn Banu, you're kissing me so passionately. You must be craving this all the time you've been with me."
                    scene v16-145
                    b "Ahhh...you know what I need..."
                    b "Right there...ahhhh.."
                    b "Ummmmm...You got me so wet you tricky boy."
                    scene v16-146
                    "Murat was bending Banu backwards slightly and she was grabbing his neck not to fall off."
                    "Using the opportunity, Murat started rubbing Banu's pussy furiously and talking dirty to her making her crazy."
                    b "Ahhhhh...stop it...please, ahhh."
                    mur "I'll make you feel so good that your husband never done that to you."
                    mur "I'm going to make you feel like a real woman today. You'll scream and beg but I won't stop..."
                    scene v16-147 with fade
                    "After minutes Murat grabbed Banu taking her pants and bra off and sat on the sofa holding her on top of him. "
                    "While invading her mouth, Murat run his hands all over Banu's body, caressing her thighs, belly and breasts. "
                    "At this point, Banu could't help but reached her pussy with her hand stimulating her left out clit."
                    scene v16-148
                    b "Shit, I can't bear it anymore...Murat, please..."
                    mur "Tell me. What you want me to do?"
                    b "Please, make me feel good."
                    mur "You want my cock, don't you?"
                    b "My pussy is so wet now. I'm going to cum from your touches."
                    b "Please, take my pussy. Make me yours!"
                    scene v16-149 with hpunch
                    b "Ahhh...yeah like that.."
                    mur "You're such a lewd slutty wife, aren't you?"
                    b "Yesss, I'm a despicable, bad wife who needs a good punishment."
                    b "Call me whatever you want. I deserve that."
                    mur "You're a bad bitch enjoying my fingers deep inside of your married cunt. "
                    b "Ohhh...I can't take it anymore...I'm going to cummm....."
                    scene v16-150
                    mur "Look how slutty you are. You're cumming from a young man at your children's age fingering your pussy."
                    b "Please, stop it..."
                    b "Damn, you're so good at this. Fuck..."
                    b "I've never let my husband touch me like that."
                    mur "Go on, cum for me. I'm going to tease all of your slutty holes."
                    mur "I'm going to tease the shit out of you. You'll beg me to fuck all of your holes."
                    mur "Have you ever got your asshole fucked?"
                    scene v16-151 with vpunch
                    b "No! Don't touch me there. I warn you!"
                    mur "What? You're rejecting me?"
                    b "Shit, I'm serious, Murat. I've never let a man touch me there."
                    "Banu squeezed her legs so hard to prevent Murat teasing her asshole with his middle finger. "
                    scene v16-152 with fade
                    b "Ahhh..."
                    b "You're crazy...what are you doing?"
                    mur "You see? I'm full of surprises."
                    scene v16-153
                    mur "Mmmm...it's so delicious. Do you like it?"
                    b "Ohhh shit...stop it...it's so dirty..."
                    b "Oh god...you're hitting my spot."
                    b "You're eating it like your favorite breakfast...ufff.."
                    mur "Mmmm..this is my favorite meal of the day."
                    b "Oh my God...if you keep doing that....I won't be able to stop cumming."
                    mur "Don't hold it. Cum all over my mouth. "
                    b "Shit, you're so good with your tongue."
                    mur "Are you ready for the main course?"
                    scene v16-154 with fade
                    "Murat suddenly raised Banu's legs and put his dick on top of her pussy grinding it back and forth."
                    mur "You want this, don't you?"
                    b "Stop teasing me, please..."
                    mur "Shut up!"
                    mur "Tell me how you want it."
                    scene v16-155
                    b "I want it inside of me..."
                    "Murat continued teasing Banu's wet pussy with his fully erect curvy dick making her crazy."
                    mur "I want you to ask it properly."
                    b "Oh god...you're making me crazy..."
                    b "Put that fucking dick inside of me!"
                    mur "Tell me how bad you want it."
                    b "I want it so bad...please, my pussy aches for your big curvy dick."
                    b "Put it inside of my married unsatisfied pussy."
                    b "Fuck the shit out of me..."
                    scene v16-156 with hpunch
                    b "Ahhh..."
                    mur "That's it. I'm not gonna make you suffer any longer."
                    show sex
                    b "Fuck!...This feels so good..."
                    mur "I know what you want, baby."
                    mur "My dick fits so good inside of your wet pussy."
                    mur "Your pussy is just made for my cock."

                    show sexangle
                    b "Ohh fuck me...keep fucking me like that."
                    mur "Your husband is weak man probably. Leaving a pussy unsatisfied like this huh?"
                    b "Please, ahhh, stop talking about him..."
                    b "Keep fucking me like that, ahhh.."

                    show sexfast
                    b "Ohhhh shit..."
                    b "It's hitting me so bad..."
                    mur "Fuck...your pussy squeezes my cock so hard."

                    show sexangle fast
                    b "Oh my god, keep fucking me like that...ahhh..."
                    b "Your cock reaches my stomach...ohhh shit.."
                    mur "I'm going to destroy belly..."
                    mur "I can't believe you gave a birth from this pussy. It's so tight."
                    b "Fuck....I'm cumming....shit...."
                    scene v16-157 with hpunch
                    b "Shit...that was so intense."
                    mur "Your face tells it all."
                    b "You're the devil."
                    mur "I'm glad you liked that...but it's not over yet."
                    scene v16-158
                    mur "I have an idea. How about we try something new together?"
                    b "Wait..what?"
                    mur "It's something you've never done before, and I think it could be a fun and memorable experience."
                    b "No!...no way..."
                    scene v16-159
                    mur "But why not trying?"
                    b "I'm sorry, but I can't do that. It's just not something I'm comfortable with or ready for."
                    mur "Let's give it a try, just this once. I'm sure you'll love it."
                    scene v16-160
                    b "No I can't do that. I'm not comfortable with this you know."
                    mur "How do you know if you haven't tried it?"
                    b "Please, don't push me. I'm afraid of that."
                    scene v16-161
                    b "Heyyyy...stop it!"
                    mur "I promise you, it won't be painful."
                    mur "I'll make sure you're comfortable and at ease throughout the experience."
                    scene v16-162
                    b "I just said stop it! What are you doing?"
                    b "I can't do this!"
                    mur "Shhhh...your ass will love it."
                    scene v16-163
                    b "Ahhhhhhhh...Ay mama....it hurts...stop it!"
                    mur "Shhhh, I'll lubricate it good that you'll only feel the pleasure."
                    scene v16-164
                    b "Ahhhhhh..."
                    mur "That's it..."
                    b "It hurts so bad, please pull it out! Ahhhhh.."
                    mur "Don't worry. Your ass will get used to it."
                    show sex
                    b "Shit...Ahhhh..."
                    b "It destroyes my ass."
                    mur "You seem to like it."
                    show sexangle
                    b "Ohh yeah, don't stop...keep fucking my dirty asshole..."
                    mur "Your asshole is so tight. It squeezes my dick like hell."
                    mur "But I'll stretch it a bit more."
                    show sexfast
                    b "Ahhhhhh....yesss...pound my ass like that..."
                    b "Shit, I can't hold it. I'm going to pee."

                    show sexanglefast
                    mur "Your asshole belonges to me now. "
                    mur "I'll stretch it whenever I want."

                    scene v16-165 with fade
                    "Murat fucked Banu for hours in the ass hitting deep inside her with his long curvy dick."
                    "Banu's initial pain was replaced by a mixture of pleasure and pain afterwards giving her the best pleasure in her life. "
                    scene v16-166
                    "At this point, she couldn't stop her eyes rolling back and moaning like a whore while accepting full length of Murat's swollen cock from her back door. "
                    b "Ahhhh, it's hitting me right there..."
                    scene v16-167
                    b "Keep fucking me like that. Don't dare to pull it out now."
                    b "Oh my god...I can't hold it any longer...."
                    b "Shit, if you keep fucking..."
                    scene v16-168 with vpunch
                    b "Oohhhhhh...."
                    b "Damn...I'm..."
                    mur "Fuck, look at that."
                    scene v16-169
                    b "Fuck...I'm so sorry...It was just..."
                    mur "It's okay, Banu. You just enjoyed it a bit too much."
                    b "I'm really sorry...it was just an accident."
                    scene v16-170 with hpunch
                    "Murat looked deeply into Banu's eyes, a glimmer of excitement and anticipation in his gaze."
                    b "Murat, I have to go. It's late."
                    mur "For the next few hours, I want us to have an incredible time together."
                    b "But I really can't stay."
                    mur "We're having such a great time together, and I don't want it to end so soon."
                    mur "You belong to me for the next hours."
                    "Banu couldn't say a word as she felt Murat's dick in the enterance of her asshole again."
                    "It was too late to reject Murat again..."




    scene black with Dissolve(3)
    ""
    centered "{size=+120}Walking in the park{/size}" with Fade(0.5, 0.5, 5)
    scene v16-266 with irisin
    "Banu and Aslan, both devoted to their religious beliefs, stroll through the serene park together."
    "Despite their physical differences, with Banu being taller than Aslan, they embrace their unique qualities and find beauty in their contrasting appearances."
    "As they walk side by side, Banu's hijab gracefully frames her face, radiating elegance and modesty. She exudes confidence in her height, embracing her stature as a symbol of her strength and individuality."
    "Aslan, a thin and short gentleman, carries himself with a quiet self-assurance, appreciating his own qualities that extend beyond physical attributes."
    scene v16-267
    "Despite Banu still being married to her previous husband, she has made the decision to pursue a divorce, acknowledging that her current relationship no longer aligns with her values."
    "As she spends time with Aslan, she carefully observes his character and intentions, allowing him the opportunity to demonstrate his sincerity and compatibility."
    "Throughout their walk in the park, Banu encourages meaningful conversations that delve into their shared religious beliefs, values, and aspirations."
    "Aslan, in his own unique way, offers insights and perspectives that resonate with Banu's spiritual journey."
    "Their shared moments in the park serve as a backdrop for the blossoming connection between them."
    "Banu, while still cautious, gives Aslan a chance to demonstrate his understanding and alignment with her values."
    scene v16-268
    menu:
        "Banu is skeptical about Aslan":
            $ banuskeptikalaslan = True
            $ renpy.block_rollback()
            b "Aslan, I have to admit, I'm still skeptical about this. "
            b "I've encountered my fair share of disappointments in the past, and it's made me hesitant to fully trust anyone. I hope you understand."
            ass "Banu, I appreciate your honesty. I understand that trust is earned, especially given your previous experiences."
            ass "I want to assure you that I'm here with genuine intentions and a deep respect for your boundaries. I'm not like the other guys you've encountered."
            b "That's what they all say. They promise to be different, but then their true colors come out. I've been through heartache before, and I don't want to go through it again."
            ass "Banu, I can't erase the pain you've experienced, but I can show you through my actions that I'm different. I understand that trust takes time to build."
            b "It's hard for me to let my guard down, Aslan. But there's something about you that makes me want to give you a chance. I'm cautiously optimistic, hoping that you truly are different."
        "Banu trusts Aslan":

            $ banuskeptikalaslan = False
            $ renpy.block_rollback()
            b "Aslan, I want to share something with you. Despite my past experiences, I've come to a point where I can fully trust you. I believe in the sincerity and authenticity of your intentions."
            ass "Banu, your trust means the world to me. It's a testament to the connection we've developed and the understanding we share."
            b "I appreciate your unwavering support and the way you've shown up for me. You've consistently demonstrated your loyalty and understanding."
            b "It's given me the courage to open my heart to you completely."
            ass "Banu, your trust is a precious gift, and I will treasure it always. I promise to cherish you, honor our shared values, and be there for you through thick and thin."


    scene v16-269 with fade
    play music "audio/action.mp3"
    "As Banu and Aslan continue their walk in the park, their steps suddenly falter as they come face to face with Polad, a close acquaintance of Banu and someone she has had deep feelings for."
    "Banu's heart skips a beat, and a rush of mixed emotions floods over her, leaving her feeling embarrassed and vulnerable."
    "Banu's eyes meet Polad's, and for a fleeting moment, their shared history flashes before her."
    "The memories of their dark moments resurface, reminding her of the pain and complexity that once entangled their relationship."
    scene v16-270
    "Aslan, sensing Banu's sudden change in demeanor, silently observes Polad and Banu."
    "He remains composed, sensing the gravity of the encounter, but determined to stand by Banu's side."
    "Polad approaches, his gaze fixed on Banu, but with a hint of surprise at seeing her accompanied by Aslan."
    "Banu musters her strength, knowing that she has moved forward and found a new connection with Aslan, yet the presence of her past still lingers."
    b "Polad, it's...unexpected to see you here. This is Aslan, someone special in my life now."
    scene v16-272
    p "Banu, I...didn't realize... It's good to meet you, Aslan."
    ass "Likewise, Polad. It's a pleasure to meet you too."
    "Banu's heart beats with a mix of conflicting emotions as Polad's presence brings forth a flood of memories. She finds herself feeling both embarrassed and weak, vulnerable to the power their shared history still holds over her."
    ass "Banu, I couldn't help but notice the connection between you and this man. Would you mind introducing him to me?"
    scene v16-271
    "Banu hesitates for a moment, recognizing that disclosing her past relationship with Polad may complicate the situation. She decides to prioritize the present and maintain a level of privacy for the time being."
    b "He's a close friend of mine and I currently live in his apartment."
    "As Banu, Aslan, and Polad find themselves in the same space, a conversation ensues, with Aslan addressing the topic of Banu's silence about Polad."
    ass "Banu, I couldn't help but notice that you've never mentioned Polad before. I'm just curious why."
    "Banu's gaze shifts between Aslan and Polad, momentarily taken aback by the directness of the question."
    "She takes a deep breath, considering how to respond honestly and with respect for both Aslan and Polad."
    scene v16-273
    stop music
    "As Polad interrupts Aslan's attempt to address Banu, his tone carries a mix of surprise and sarcasm. A slight smirk plays across Polad's face as he directs his attention towards Aslan."
    scene v16-274
    p "Well, well, Aslan. I must say I'm quite surprised. Banu here has always had a passion for taller men. It's amusing to see her with someone like you."
    "Aslan, momentarily caught off guard by Polad's interruption and sarcastic remark, maintains his composure and responds with confidence."
    ass "I understand you may have your own perspective, but Banu and I share a connection that goes beyond physical attributes."
    p "So, Aslan, how does it feel to be the lucky one?"
    scene v16-273
    p "I must admit, I never thought someone as tall and confident as Banu would be interested in a guy like you. It's quite a surprise!"
    p "I mean I'm not sure if you can handle her."
    ass "Relationships are not solely based on physical attributes. Banu and I share a deep emotional connection."
    menu:
        "Protect Aslan":
            $ banumockaslan = False
            $ renpy.block_rollback()
            scene v16-278
            "As Banu notices the malevolent glimmer in Polad's eyes and senses the need to protect Aslan, her instincts kick in."
            "She steps closer to Aslan, intertwining her arm with his, offering him a reassuring show of support."
            b "Aslan, you don't need to pay any attention to Polad's words. They hold no significance in our relationship."
            scene v16-279
            "Aslan, grateful for Banu's unwavering support, finds comfort in her presence and the strength she exudes."
            "Banu's protective gesture conveys her determination to shield Aslan from any harm or doubt. She refuses to let Polad's words cast a shadow on their bond."
            "Polad, sensing the unity and resilience between Banu and Aslan, decides not to pursue the matter further."
            scene v16-280
            "Banu and Aslan continue their walk in the park, with a silent understanding to move past the uncomfortable encounter and focus on the positive aspects of their time together."
            "Banu's protective stance and her unwavering support for Aslan create a sense of harmony and safety, reinforcing their commitment to each other."
            "Together, they choose to rise above negativity, cherishing the love they share and cherishing the moments they have in each other's company."
        "Mock Aslan":




            $ banumockaslan = True
            $ renpy.block_rollback()
            scene v16-276
            "Aslan's heartfelt statement about the importance of emotional connection and the depth of their relationship hangs in the air. However, to the surprise of Aslan and Polad, Banu's reaction takes a lighthearted turn."
            "She can't help but find amusement in the situation and playfully mocks Aslan, glancing mischievously at Polad."
            b "Oh, Aslan, you really know how to make us laugh! Deep emotional connections and all that, huh? You're quite the comedian today!"
            "Polad, catching Banu's playful vibe, chuckles along, appreciating her sense of humor."
            scene v16-275
            p " I have to agree with Banu, Aslan. You've got quite the way with words. Who knew you were the philosopher of love?"
            "As Polad and Banu exchange glances, a mischievous spark flickers between them."
            "They begin chatting, sharing inside jokes and reminiscing about humorous moments from their past. Their laughter fills the air, echoing through the park."
            scene v16-277
            "As Polad and Banu engage in their lively conversation, their laughter ringing through the air, Aslan begins to feel a pang of jealousy."
            ass "Hey, guys, what's so funny? Mind including me in the joke?"
            scene v16-276
            b "Oh, Aslan, I'm sorry, but didn't you get the memo? Only tall guys are allowed to crack jokes around here. Short guys need to step up their game!"
            scene v16-277
            p "(laughing) Banu's got a point, Aslan. We'll have to see if you're tall enough to match our humor levels!"
            b "(giggling) Don't worry, Aslan. We're just messing with you. The only requirement for joining our humor club is a good sense of fun!"
            "Aslan, initially taken aback by Banu's playful remark, quickly realizes that she's joking and joins in the laughter."

    scene black with Dissolve(3)
    ""
    centered "{size=+120}Rina{/size}" with Fade(0.5, 0.5, 5)
    scene v16-281 with dissolve
    "As Banu enters Rina's luxurious home, she feels a mixture of awe and discomfort. The opulent furnishings and decadent decor contrast sharply with her own more modest lifestyle."
    "Rina, the enigmatic hostess, is an athletic Japanese woman, adorned in revealing attire that exudes confidence and power."
    "Her striking appearance immediately catches Banu's attention, yet it also makes her feel somewhat inadequate in her simple, long blue dress and hijab."
    scene v16-282
    b "Thank you for inviting me, Rina. Your home is beautiful."
    ri "Oh, it's nothing. I enjoy surrounding myself with the finest things. Now, tell me what brings you here, Banu. You seem troubled."
    scene v16-283
    b "Yes, I am. I recently broke up with my husband, and it's been hard for me to move on. I'm considering dating someone new, but I'm uncertain about trusting men again."
    ri "Ah, men can be nothing but trouble, can't they? I've always believed they should be slaves to women."
    b "Well, I don't think it's fair to generalize. There are good and bad people in every gender."
    ri "Fair enough. But you must admit, many men have done terrible things to women throughout history."
    b "That's true, and I've experienced some of that pain myself. But I don't want to let those experiences define my future."
    scene v16-284
    ri "So, you're considering dating again? Even after what you've been through?"
    b "Yes, there's a religious man in my neighborhood, and he seems kind and genuine. But I'm scared to submit myself to another man and end up hurt again."
    ri "Submit? Why should you submit to anyone? You're strong and independent. You don't need a man to define your worth."
    b "I suppose you're right. But I still believe in love and partnership."
    ri "Love can be complicated, Banu. I've seen the darkest sides of relationships in my line of work."
    ri "Let's just say I have my ways of dealing with men who cross me."
    scene v16-283
    ri "So, Banu, what do you think is better – to fall in love and risk getting hurt again, or to take control and enjoy life on your own terms?"
    menu:
        "The First one":
            $ banuchoosefirstone = True
            $ renpy.block_rollback()
            b "It's a difficult question, Rina. Falling in love and risking getting hurt is scary, no doubt about it."
            b "But it's also what makes us human, what makes life worth living. Love can bring immense joy and fulfillment, even if there's a chance of pain."
            ri "And you're willing to risk going through heartbreak all over again?"
            b "Yes, I am. Because I've learned that the risk of pain is a part of the human experience. It's how we grow and learn."
        "The second one":


            $ banuchoosefirstone = False
            $ renpy.block_rollback()
            b "It's a tough question, Rina. While falling in love can be beautiful, it also leaves you vulnerable to heartbreak and pain."
            b "After my recent breakup, I've realized that taking control of my life and focusing on my own happiness might be the better option for now."
            ri "Good for you, Banu. Taking control of your life will empower you in ways you can't even imagine."
            b "I believe so too. I want to focus on my own growth, my spirituality, and building a strong foundation for myself."

    scene v16-285
    "As Banu and Rina sit on the sofa, the atmosphere takes a slightly tense turn as Rina speaks with a serious tone."
    ri "Banu, I want to teach you how to take control and punish those men who have done wrong to you."
    ri "You don't have to suffer in silence or let them get away with their actions. But you must follow my instructions carefully."
    scene v16-286
    b "Punish them? I'm not sure I understand what you mean, Rina. I don't want to cause harm to anyone."
    ri "It doesn't have to be physical harm, Banu. I mean teaching them a lesson, making them realize the consequences of their actions, and empowering yourself in the process."
    b "I don't know, Rina. It doesn't sound right to me. Revenge won't heal the pain I've experienced."
    scene v16-287
    ri "You're right; revenge won't heal your pain. But it can give you a sense of justice and closure. It's about showing them that they can't mistreat others without consequences."
    b "I understand the desire for justice, but I don't want to become someone who hurts others, even if they've hurt me."
    ri "It takes strength to rise above the desire for vengeance. But sometimes, standing up for yourself and ensuring they understand the impact of their actions can be empowering."
    ri "Have you ordered a man before?"
    b "Mmmm...No."
    ri "I want to practice it with you. I believe you have a great potential to be a dominant female. "
    ri "I want to teach you how to order a man."
    scene v16-288
    "Rina calls one of her servants to the room and immediately a tall man wearing brown knee-length shorts and a bow tie enters the room."
    scene v16-289 with fade
    serv "Yes Mistress, how can I help you?"
    ri "Talk to Banu. She's going to give you orders. Take requests from Banu and assist her to the best of your abilities. "
    scene v16-290
    ri "Now it's your turn, Banu. I'm going to watch how you order. He's at your command right now."
    b "But I...."
    scene v16-291
    serv "How can I help you, Mistress?"
    menu:
        "I can't do that":
            $ banuordersservant = False
            $ renpy.block_rollback()
            scene v16-292
            b "I'm sorry, Rina, but I can't do that."
            b "I must admit, Rina, I'm not very good at ordering others around."
            ri "It's not about being good at ordering; it's about finding your voice and expressing your needs confidently."
            b "I suppose you're right. It's just that I've always been more comfortable with a softer approach."
        "Order him!":

            $ banuordersservant = True
            $ renpy.block_rollback()
            scene v16-293
            play music "audio/sexy.mp3"
            b "I guess I should try this."
            b "First, come closer you fucking idiot."
            serv "Yes, Mistress."
            scene v16-294
            b "Now, you're gonna do exactly what I tell you. Do you understand me, you stupid bitch?"
            serv "Yes, Mistress."
            ri "Wow, you're a quick learner, Banu."
            jump banuorderstheservant


            label banuorderstheservant:

                scene v16-294
                play music "audio/sexy.mp3"

                menu:
                    set menuset
                    "Order him to lick your foot":

                        $ orderservantlickfoot = True
                        $ renpy.block_rollback()
                        b "Lick every inch of my feet, bitch and get a taste of my shoes."
                        scene v16-295
                        b "That's good. You're so good at licking. I may have more jobs for you."
                        ri "You're doing it, Banu. You're born to do this."
                        b "That's it. Suck it like that."
                        scene v16-296
                        b "Hold my leg and lick it all clean. "
                        b "Suck it good, you worthless piece of shit."
                        ri "Wow, I like that."

                        scene v16-294
                        jump banuorderstheservant
                    "Order him to show you his cock":


                        $ askservantshowdick = False
                        $ renpy.block_rollback()
                        b "Show me what you're packing there."
                        b "What are you looking at? Shorts down!"
                        serv "Yes, Mistress."
                        ri "You're so curious, Banu."
                        scene v16-300
                        b "..."
                        b "He's really big, isn't he?"
                        scene v16-301
                        b "Dude, you have a really monster cock. How do you even carry it with you."
                        b "That's a big fucking cock right there."
                        ri "Don't be distracted, Banu."
                        scene v16-302
                        b "You're a piece of shit but... "
                        b "I must say you have a really beautiful cock. Keep it safe."

                        scene v16-294
                        jump banuorderstheservant
                    "Slap him":


                        $ slapservant = False
                        $ renpy.block_rollback()
                        scene v16-297
                        b "I see that you're not paying close attention to me. Are you deaf or what?"
                        serv "No, Mistress.."
                        scene v16-298
                        b "Shut the fuck up!"
                        b "You only talk if I allow you."
                        scene v16-299
                        ri "That was really good, Banu. You showed him his place."
                        b "He has so much to learn yet."



                        scene v16-294
                        jump banuorderstheservant
                    "That's enough":



                        scene v16-293
                        b "I think that's enough for now."
                        b "He'll be a good boy I believe."







            $ renpy.end_replay()
            $ persistent.banuorderstheservant_unlocked = True



    stop music    














    scene black with Dissolve(3)
    ""

    $ banubeattheguy = False










    centered "{size=+120}Drunk...{/size}" with Fade(0.5, 0.5, 5)
    scene v17-16 with squares
    nur "You know, Emil, sometimes I still can't believe it's been a year since I joined the army. It feels like a lifetime of experiences packed into those twelve months."
    nur "The challenges we faced were unlike anything I had experienced before."
    emil "I can only imagine. It must be really tough, am I right? "
    nur "It wasn't easy, that's for sure. But looking back, I wouldn't trade those experiences for anything. The army taught me so much about myself and the world."
    emil "What were some of the most challenging moments you faced during your time in the military?"
    nur "Oh, there were quite a few. The rigorous training, the long deployments away from family and friends, and the moments when we had to make tough decisions that carried real consequences."
    emil "I have to say, it's been a year, and you're still rocking that army uniform. Are you planning on making it a lifelong fashion statement?"
    nur "Well, you know what they say, 'Once a soldier, always a soldier.' But, no, it's just a habit, I guess. Plus, it's comfortable, and I've grown oddly attached to it."
    scene v17-17 with dissolve
    nur "Look over there. Seems like that guy could use some help."
    emil "You're right. He doesn't seem to be in the best state. Let's see if we can offer him some assistance."
    scene v17-18
    nur "Hey there, buddy. Are you okay?"
    k "Huh? Wh-who're you?"
    nur "We're just a couple of guys passing by. It looks like you've had a bit too much to drink. Is there anything we can do to help you?"
    k "I'm fine... just leave me alone."
    emil "We don't want to intrude, but we're concerned about your well-being. Maybe we can call someone for you or help you get home safely?"
    k "I said I'm fine! Mind your own business!"
    nur "We understand, but sometimes we all need a little help. We're not judging you, just want to make sure you're okay."
    emil "That's right. It's okay to ask for help, and we won't think any less of you for it."
    k "..."
    scene v17-19
    nur "Emil, we can't just leave him like this. He needs help, and we should call the police or someone who can assist him."
    emil "You're right, Nurlan. I don't feel comfortable leaving him here alone either. Let's find a safe spot nearby to make the call."
    k "Why... why did she leave me? Wasn't I good enough? (Pauses, taking a deep, shaky breath) I loved her so much... gave her everything I could..."
    "Nurlan and Emil overhear his words, exchanging a glance that shows understanding and sympathy for the man's pain."
    k "I thought we'd be together forever... but she's gone now, and I don't know what to do..."
    k "Maybe... maybe I messed it all up. Too many mistakes, too much pride... "
    k "I wish I could turn back time, do things differently... make her stay."
    scene v17-20
    "Kamil reaches for the beer bottle with a trembling hand, his fingers gripping it tightly as if seeking comfort in its familiarity."
    "With a heavy sigh, he raises the bottle to his lips, the familiar scent of hops and barley filling the air as he takes a long swig."
    "..."


    scene black with Dissolve(3)
    ""
    centered "{size=+120}The trauma for Banu...{/size}" with Fade(0.5, 0.5, 5)
    scene black with dissolve
    "Banu's footsteps echoed down the sterile, fluorescent-lit corridor as she approached the door marked 'Patient Room 305.'"
    "Her heart raced, anxiety pooling in the pit of her stomach, as she wrestled with the knowledge of what might await her on the other side."
    scene v17-171 with hpunch
    "With a trembling hand, Banu pushed the door open, revealing a scene that struck her like a physical blow. "
    "A clinical smell mixed with an underlying scent of antiseptic, assaulting her senses."
    "Leyla lay on the hospital bed, her usually vibrant face now marked with bruises and swelling."
    scene v17-172
    "Banu's hands trembled at her sides as she took hesitant steps closer to the bed."
    "She looked down at Leyla, the girl who was once her little beacon of light, now wounded and fragile."
    "A thousand emotions rushed through her: anger, guilt, sorrow, and a deep-seated fear that threatened to consume her."
    "The knowledge that she hadn't been there for her daughter when she needed her the most was like a sharp knife twisting in Banu's heart."
    scene v17-173
    b "Leyla... sweetheart, it's me. It's your mother. What happened to you?"
    l "I didn't know if you'd come."
    b "I'm so sorry. I should've been here for you. I should've protected you."
    l "Mom, it's not your fault. It's... it's complicated."
    b "No matter what happened, Leyla, I want you to know that I'm here for you now. I want to help you through this, if you'll let me."
    scene v17-174
    l "Mom, please don't look at me like that."
    b "I... I can't help but feel responsible for what happened to you."
    l "Mom, you're not responsible. What happened was not your fault."
    b "I can't stand to see you in pain."
    b "Leyla, sweetheart, I need to know. Who did this to you? Who hurt you like this?"
    scene v17-175
    l "Mom, it's... complicated."
    b "Leyla, I'm your mother. You can trust me. Please, tell me who did this to you."
    l "Mom, it's really not important. Just take it easy."
    b "Leyla, no one has the right to hurt you, no matter what the circumstances were. Please, let me help you. Tell me who he is."
    l "It's complicated, Mom. I promise, I'll figure this out, but right now, I need your support more than anything."
    scene v17-176
    b "Leyla, I want you to know that I will do whatever it takes to find the person who did this to you. No one should get away with hurting you like this."
    l "Mom, I appreciate your concern, but I don't want you to get hurt or involved because of me."
    b "I can't stand the thought of someone hurting you like this. I promise you, I will get revenge for what he's done to you."
    scene v17-177 with fade
    ah "I have one more question. Do you happen to know any of Leyla's friends or acquaintances? Maybe someone she might have been spending time with recently?"
    ass "I'm sorry, Officer, but I don't personally know any of Leyla's friends or acquaintances."
    ah "I just thought if you had any information about her social circles, it could potentially lead us to more clues about the incident."
    ass "I wish I could be more helpful in that regard. But I truly don't have that kind of information."
    scene v17-178 with fade
    b "What are you people doing? How could this happen to my daughter? And what progress have you made?"
    ah "Banu, I understand your frustration. We're doing everything we can to investigate and find answers."
    b "Everything you can? My daughter is lying in there, hurt and traumatized, and all you can say is 'everything you can'?"
    ah "I assure you, we're working tirelessly to solve this case. We take this matter seriously."
    scene v17-179
    b "Serious? If you were serious, you would have caught whoever did this by now! Leyla deserves justice, and all I see is incompetence!"
    ass "Banu, I know you're angry and scared, but let's try to channel that energy into finding solutions."
    scene v17-180
    b "Solutions? What solutions? My daughter is in that room, hurt and traumatized, and you're telling me about solutions?"
    ass "I understand your pain, Banu, but we should work together to find justice."
    b "Work together? With them? They couldn't even prevent this from happening!"
    scene v17-181
    b "Oh, Officer Ahmed, you're such a fine example of law enforcement, aren't you? You couldn't protect a young girl from getting hurt right under your nose."
    ah "I understand your frustration, Banu. Our goal is to resolve this."
    b " If only your dedication matched your words, Ahmed."
    b "Your version of justice seems more like a comedy of errors, Officer Ahmed."
    scene v17-182
    b "Listen here, Ahmed. If you don't start delivering results and bringing justice for my daughter, you'll be dealing with a force of anger you've never encountered before."
    ah "I understand your frustration, but threats won't help the situation."
    b "You have no idea what frustration is until you've walked in my shoes, dealing with your incompetence."
    b "You two can keep talking in circles all you want. But mark my words, if justice isn't served, I'll be the one to take matters into my own hands. Leyla deserves better than this mockery of an investigation."
    scene v17-183 with fade
    ass "Banu, please remember we're here to support you and Leyla."
    "As Banu walks away, Ahmed and Aslan exchange a glance, the weight of the situation hanging heavily between them."



    scene black with Dissolve(3)
    ""
    centered "{size=+120}Night walk{/size}" with Fade(0.5, 0.5, 5)
    scene v17-184 with dissolve
    "In the dark of the night, Banu and Aslan walked together through an old, empty factory."
    "The factory was spooky, with broken machines and dim moonlight filtering through the windows."
    "Banu walked with purpose, her long strides making soft sounds on the ground."
    "Aslan walked beside her, looking at her with admiration, though he didn't say much. He was dressed simply, reflecting his humble nature and religious values."
    ass "Is she doing better?"
    b "Physically, she's healing, but the emotional scars... they run deep."
    ass "I can only imagine how difficult this must be for both of you."
    b "It's been a roller coaster of emotions. Seeing my daughter go through this pain is heart-wrenching."
    ass "I wish there was more I could do to help."
    b "Your presence alone is comforting, Aslan. Knowing that you care means a lot to us."
    scene v17-185
    ass "How is Leyla holding up?"
    b "It's been tough on her. The trauma of what happened... it's hard to shake off."
    "As Banu and Aslan cautiously continued their walk through the abandoned factory, they couldn't help but feel the weight of the encounter with the hooded man. "
    scene v17-186
    "As they passed in front of the man, his presence seemed to linger like a shadow."
    hood "Well, hello there, beautiful."
    b "Excuse me?"
    hood "Don't be shy, gorgeous. I know how to make a lady feel special."
    hood "Come on, let's have some fun together."
    ass "Leave us alone."
    hood "Don't be so uptight. I can show you a good time."
    ass "Banu, let's just ignore him and keep walking."
    menu:
        "Listen to Aslan":
            $ banubeattheguy = False
            $ renpy.block_rollback()
            scene v17-187
            "Aslan's words provided a small sense of comfort amidst the lingering tension. They walked a bit faster, putting distance between themselves and the hooded man."
            hood "Hey, where are you two off to?"
            "Banu clenched her jaw, fighting the urge to respond. Aslan's hand gently touched her arm, offering reassurance."
            ass "Just keep moving, Banu. He's not worth our attention."
            "Banu forced herself to focus on the path ahead, her steps determined. The factory's silence seemed to amplify the sound of their footsteps, drowning out the man's taunts."
            hood "You'll regret walking away from me, sweetheart!"
            ass "Don't listen to him. We're almost out of here."
            "Banu nodded, her gaze fixed ahead. As they continued their journey, the tension gradually began to ease, replaced by a sense of unity as they faced the challenge together."
        "Give the guy a lesson":




            $ banubeattheguy = True
            $ renpy.block_rollback()
            b "No, Aslan. I won't let him get away with his behavior."
            scene v17-188 with fade
            "Aslan looked at her, surprised by her resolve. Banu's expression was a mix of frustration and determination as she turned back towards the hooded man."
            b "Excuse me."
            hood "Came back for a chat, did you?"
            b "I didn't come here for a chat. I came here to demand respect."
            b "You will apologize to me right now for your disrespectful comments."
            hood "Or what? You'll cry to your boyfriend over there?"
            scene v17-189
            "Banu's patience wore thin, and she took a step closer, her confidence unwavering."
            b "I won't tolerate your behavior any longer. Apologize."
            hood "What if I don't want to apologize? What are you going to do about it?"
            b "You will apologize, and you will learn to treat people with respect, whether they're women or men."
            b "I won't be silent in the face of disrespect. Apologize now."
            hood "Apologize? For what? Trying to talk to a whore like you?"
            b "You think this is a joke? You think you can just disrespect people and get away with it?"
            hood "Oh, I'm sorry, miss high-and-mighty. Did I hurt your delicate feelings?"
            scene v17-190
            "Banu's hands trembled, her anger turning into a boiling rage. Without a second thought, she turned around abruptly, scanning the surroundings for something to grab."
            "Her eyes settled on a wooden plank lying nearby."
            scene v17-191
            ass "Banu, no!"
            hood "Oh, what's this? Little miss angry found herself a toy to play with?"
            b "You're not going to get away with this. It's time you learn some respect."
            hood "You can try to be tough, sweetheart, but I can fuck your brains out, what do you say?"
            play music "audio/action.mp3"
            scene v17-192 with vpunch
            "Before he could react, Banu swung the plank with a forceful motion, the wood connecting solidly with the side of the hooded man's face."
            hood "What the..."
            "Aslan watched in astonishment as Banu's anger turned into action. "
            scene v17-193
            b "That's what you get for disrespecting me!"
            "The plank connected solidly with the side of the hooded man's face, the impact resonating with a sharp crack that echoed in the air."
            "The force of the blow sent shockwaves through both Banu and the hooded man. His confident stance crumbled as his head jerked to the side, his body momentarily losing its balance."
            "A gasp escaped from his lips as he staggered, a hand instinctively flying to his injured face."
            scene v17-194
            "Banu's fury burned hot, her anger and frustration fueling an intensity that she had never experienced before."
            "As the hooded man staggered back from the impact of the blow, he lost his footing and fell to the ground."
            "Aslan watched in a mix of concern and disbelief, his voice urgent as he tried to intervene."
            ass "Banu, that's enough! Stop!"
            "With a swift, forceful motion, Banu brought the plank down again, the wood connecting with the man's face."
            b "(Shouting, voice trembling with rage) You will learn to respect people!"
            scene v17-195
            ass "Banu, please!"
            "Banu slowly lowered the plank, her hands trembling as she absorbed the gravity of the scene before her."
            ass "We need to leave now, Banu. This has gone far enough."
            scene v17-196
            "His nose appeared broken, bent at an unnatural angle that distorted his face. Blood flowed freely from his nose, mixing with the red stains that marked his cheeks and mouth."
            "The man's body lay near Banu's high heels, an unsettling image that highlighted the severity of the situation."
            "His unconscious form appeared vulnerable against the backdrop of her shoes, serving as a visual symbol of the imbalance of power that had escalated into this violent encounter."
            "Aslan's urgency snapped Banu back to the present, reminding her that they needed to leave before the situation worsened."
            scene v17-197
            stop music
            ass "Banu, we need to go. This has gone too far."
            b "He needed to learn a lesson."
            ass "But look at him now. He's hurt, and this could have serious consequences."
            b "He disrespected me. He deserved to face the consequences of his actions."
            ass "I know it's frustrating, but responding with violence isn't the answer. We should have found another way to handle this."
            b "Sometimes people only learn when they're faced with the same treatment they dish out to others."




    scene black with Dissolve(3)
    ""
    centered "{size=+120}Aslan's home{/size}" with Fade(0.5, 0.5, 5)
    scene v17-198 with dissolve
    "As they reached Aslan's apartment, the weight of the recent events still hung heavily in the air. Banu and Aslan entered, their footsteps echoing in the quiet space."
    "Aslan's apartment offered a temporary refuge from the outside world, a place where they could finally discuss the situation that had escalated earlier."
    ass "Banu, what happened back there... It's not like you. I can't believe you went that far."
    b "Aslan, he needed to understand that his behavior was unacceptable. I won't apologize for standing up for myself."
    ass "I get it, Banu, but violence wasn't the solution. You could have gotten hurt, or things could have turned even worse."
    scene v17-199
    b "And what about the hurt he caused with his words and actions?"
    b "Shouldn't he face the consequences?"
    ass "I'm not saying he shouldn't, but what you did... it's not who you are. You're a strong and compassionate person. This isn't the way to handle things."
    b "I know you're worried, Aslan. But sometimes, being strong means taking a stand, even if it's uncomfortable."
    ass "I just wish you hadn't gone to that extent."



    $ aslan = 0

    if banudefendherself == True:
        $ aslan -= 1

    if banutalksarcastictoaslan == True:
        $ aslan -= 1

    if banutalksarcastictoaslan == False:
        $ aslan += 1

    if banuignorethebeggar == True:
        $ aslan -= 1

    if banuignorethebeggar == False:
        $ aslan += 1

    if banuskeptikalaslan == True:
        $ aslan -= 1

    if banuskeptikalaslan == False:
        $ aslan += 1

    if banumockaslan == False:
        $ aslan += 1

    if banumockaslan == True:
        $ aslan -= 1

    if banuchoosefirstone == True:
        $ aslan += 1


    if banuchoosefirstone == False:
        $ aslan -= 1


    if banuordersservant == False:
        $ aslan += 1

    if banuordersservant == True:
        $ aslan -= 1

    if banubeattheguy == True:
        $ aslan -= 1

    if banubeattheguy == False:
        $ aslan += 1





    menu:
        "{color=#FF0000}Blame Aslan for not protecting you back there{/color}" if aslan <= 0:
            $ renpy.block_rollback()
            scene v17-200 with fade
            b "I had to protect myself since you were not doing that."
            ass "Alright, I get it. But you have to admit, I was there to back you up."
            b "Back me up? When he was hitting on me, you just stood there like a statue. You didn't say a word."
            ass "Banu, I didn't want to escalate the situation. I thought you had it under control."
            b "Under control? He was disrespecting me right in front of you! I expected you to stand up for me."
            scene v17-201 with fade
            b "You know, Aslan, sometimes I wonder if you even know what it means to be a man."
            ass "Whoa, Banu, where is this coming from?"
            b "It's coming from the fact that when that guy was hitting on me, you just stood there, spineless! A real man would have stepped in and put a stop to it."
            ass "I didn't want to escalate the situation. I thought you had it handled."
            scene v17-202
            b "Handled? You call that handling it? You were practically invisible, like you couldn't be bothered to defend me."
            ass "Banu, I support you, but that doesn't mean I need to fight every man out there."
            b "Right, because that's not what real men do, isn't it? They just stand by and let women deal with things on their own."
            ass "That's not what I'm saying, Banu. It's about respecting your strength and independence."
            b "Oh, how noble of you! So, respecting my strength means watching silently while someone disrespects me? That's not support, Aslan, that's cowardice."
            scene v17-203
            ass "I'm not a coward, Banu! I didn't want to make the situation worse."
            b "Of course not, can't risk your fragile ego by actually doing something manly."
            ass "That's not fair, Banu."
            b "Maybe it's time you rethink what it means to be a man, Aslan. Because right now, you're falling short."
            ass "I never thought you'd question my manhood over something like this."
            b "Look, I'm just frustrated. But this whole ordeal has shown me that I need someone who'll stand up for me when it matters."
            ass "I'm sorry if I let you down."
            scene black with dissolve
            "Banu didn't pause, her steps purposeful as she made her way out of the apartment. The door closed behind her with a muted thud, leaving the space in silence."
            jump power



        "{color=#008000}Thank Aslan for supporting you all the time{/color}" if aslan >= 1:
            $ renpy.block_rollback()
            scene v17-204 with fade
            "Without a word, Banu closed the distance between them, her steps soft as she came up behind him."
            "Gently, she placed her head on his shoulder from behind, her silent gesture conveying a mixture of apology, remorse, and a shared moment of vulnerability."
            ass "Banu..."
            ass "I know why you did that but we shouldn't treat people like that."
            b "I know, Aslan. I let my anger get the best of me. I shouldn't have gone that far."
            scene v17-205
            ass "Banu, I..."
            "Banu's gaze held a combination of emotions – understanding, affection, and a hint of playfulness."
            "Her touch seemed to convey a silent apology and a desire to bridge the gap that had momentarily strained their connection."
            b "Aslan...I value what we have."
            b "You know, Aslan, sometimes I think I need a man like you in my life."
            ass "Banu, I appreciate that sentiment, but we need to be careful about how we handle this situation."
            scene v17-206 with fade
            "Slowly, she began to remove her purple cardigan, the fabric sliding off her shoulders and revealing the attire beneath."
            "Aslan found himself captivated by Banu's presence. Her actions and demeanor had a magnetic quality that drew his attention, and he found himself unable to look away."
            scene v17-207
            b "How do I look?"
            "Aslan's gaze swept over Banu, his eyes taking in the details of her presence – the way the light played on her features, the way her outfit complemented her, and the genuine curiosity in her expression."
            ass "Banu, you... you look absolutely stunning."
            scene v17-208
            "Banu suddenly grabbed Aslan and started to kiss him."
            "Aslan was shocked to react and say a word and went with the flow."
            "He enjoyed Banu's hot kisses but couldn't dare to put his hands on her."
            scene v17-209
            "She continued to kiss him passionately while grinding herself against his crotch."
            "Aslan got excited and embarrassed at the same time but couldn't reject Banu's sweet kisses."
            ass "Banu..."
            b "Kiss me...Don't stop."
            ass "We can't..."
            scene v17-210 with hpunch
            b "What do you mean? Don't you like me? "
            "Banu put her hand on Aslan's crotch and squeezed it."
            b "I want to be with you tonight. Do you know what it means?"
            ass "Banu, I care about you deeply, but we have to remember our boundaries. We can't cross certain lines before marriage."
            scene v17-211
            b "Well, Aslan, if we can't do certain things before marriage, what can we do to pass the time?"
            ass "We can still spend time together, enjoy each other's company, and have meaningful conversations."
            b "Meaningful conversations, huh? I suppose that's a good way to keep our minds occupied."
            ass "It's an important part of building a strong foundation for our relationship."
            b "True, but you can't deny there's a certain level of anticipation in the air."
            ass "You're not making it any easier, Banu."
            scene v17-212
            "Seated on the cozy sofa, Banu's arms encircled Aslan from behind."
            "Their laughter filled the room as they shared stories and jokes, their connection growing stronger with each passing moment."
            "Time seemed to slow as they enjoyed each other's company, finding solace and joy in the simple act of being together."
            jump marry












    dev "{color=#000000}Thank you for playing! This is the end of this route in this version. Play again to discover more. If you enjoyed it please {a=https://www.patreon.com/lustfulfantasy}support{/a} the development. Please, add the game to your {a=https://store.steampowered.com/app/2505580/Life_in_Middle_East/}wishlist{/a} on Steam to make it grow. {/color}"
    hide screen faith
    hide screen angeldevil
    jump endings
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
