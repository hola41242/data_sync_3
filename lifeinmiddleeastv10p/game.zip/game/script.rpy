



image disclaimer = "disclaimer.png"
image disclaimer2 = "disclaimer2.png"
define menumusic = "menumusic.mp3"
image Banu = "Banu.jpg"
image Kamil = "Kamil.jpg"
image Leyla = "Leyla.jpg"
image Ruslan = "Ruslan.jpg"
image Polad = "Polad.jpg"
image Nesrin = "Nesrin.jpg"
image Turan = "Turan.jpg"
image Murat = "Murat.jpg"
image Boss = "Boss.jpg"
image Hicran = "Hicran.jpg"
image Ahmed = "Ahmed.jpg"
image Natasha = "Natasha.jpg"
image Aysel = "Aysel.jpg"
define story1 = "story1.mp3"
image ending1 = "ending1.png"






image banudancingabdulanimation = Movie(play="videos/banudancingabdulanimation.webm")
image poladbanureverseanimation = Movie(play="videos/poladbanureverseanimation.webm")
image banujerkoffkamilfriends = Movie(play="videos/banujerkoffkamilfriends.webm")
image abdulfucksbanuferhadstanding = Movie(play="videos/abdulfucksbanuferhadstanding.webm")
image ferhadfucksbanuabdulstanding = Movie(play="videos/ferhadfucksbanuabdulstanding.webm")
image banujerkoffkamilfriends = Movie(play="videos/banujerkoffkamilfriends.webm")
image banuruslanmasturbatecuckroute = Movie(play="videos/banuruslanmasturbatecuckroute.webm")
image banujerkkamilruslanoffanimation = Movie(play="videos/banujerkkamilruslanoffanimation.webm")
image banujerkoffkamilcuckroute = Movie(play="videos/banujerkoffkamilcuckroute.webm")
image kamilforcebanubedroomcuckroute = Movie(play="videos/kamilforcebanubedroomcuckroute.webm")
image poladrubbingbanupussykitchen = Movie(play="videos/poladrubbingbanupussykitchen.webm")
image ahmedfuckbanuonsofa = Movie(play="videos/ahmedfuckbanuonsofa.webm")
image banustrokehassancock = Movie(play="videos/banustrokehassancock.webm")
image banusuckhassancock = Movie(play="videos/banusuckhassancock.webm")
image ruslanfuckbanuleylahold = Movie(play="videos/ruslanfuckbanuleylahold.webm")
image ruslanfuckbanuleyladoggy = Movie(play="videos/ruslanfuckbanuleyladoggy.webm")
image samirfuckbanupussybedroom = Movie(play="videos/samirfuckbanupussybedroom.webm")
image samirfuckbanuassbedroom = Movie(play="videos/samirfuckbanuassbedroom.webm")
image poladfuckbanubathroomkamildrunk = Movie(play="videos/poladfuckbanubathroomkamildrunk.webm")


image kamilfucksbanuasspurerouteanimation = Movie(play="videos/kamilfucksbanuasspurerouteanimation.webm")
image banusuckkamildadstandingkitchen = Movie(play="videos/banusuckkamildadstandingkitchen.webm")
image kamilfuckbanumissionary_dadoutside = Movie(play="videos/kamilfuckbanumissionary_dadoutside.webm")
image kamilfuckbanustanding_dadoutside = Movie(play="videos/kamilfuckbanustanding_dadoutside.webm")
image kamilfuckbanustandingbiking = Movie(play="videos/kamilfuckbanustandingbiking.webm")
image kamilfuckbanureversebiking = Movie(play="videos/kamilfuckbanureversebiking.webm")
image banuandnesrinsuckkamilpolad = Movie(play="videos/banuandnesrinsuckkamilpolad.webm")
image kamileatnesrinpoladfuckbanu = Movie(play="videos/kamileatnesrinpoladfuckbanu.webm")
image kamilpoladfuckbanunesrindoggy = Movie(play="videos/kamilpoladfuckbanunesrindoggy.webm")
image poladfuckbanuassholefoursome = Movie(play="videos/poladfuckbanuassholefoursome.webm")
image banusuckorxankamilwatch = Movie(play="videos/banusuckorxankamilwatch.webm")
image kamileatrinapussy = Movie(play="videos/kamileatrinapussy.webm")
image orxandeformbanubellyshower = Movie(play="videos/orxandeformbanubellyshower.webm")
image kamilfuckrinamask = Movie(play="videos/kamilfuckrinamask.webm")
image orxanfuckbanukamilotherroom = Movie(play="videos/orxanfuckbanukamilotherroom.webm")
image blackmanfucksbanu = Movie(play="videos/blackmanfucksbanu.webm")
image orxankamilfuckbanuatthesametime = Movie(play="videos/orxankamilfuckbanuatthesametime.webm")
image banusitsonorxancockanal = Movie(play="videos/banusitsonorxancockanal.webm")
image banusitsonorxancockanaldoggy = Movie(play="videos/banusitsonorxancockanaldoggy.webm")
image banuorxankamilfuckeachother = Movie(play="videos/banuorxankamilfuckeachother.webm")





image alifucksbanumissionary = Movie(play="videos/alifucksbanumissionary.webm")
image alifucksbanumissionary_2 = Movie(play="videos/alifucksbanumissionary_2.webm")
image banuteaseturandickwithherass = Movie(play="videos/banuteaseturandickwithherass.webm")
image banuteaseturandickwithherpussy = Movie(play="videos/banuteaseturandickwithherpussy.webm")
image turanbangbanuhandslocked = Movie(play="videos/turanbangbanuhandslocked.webm")
image turanbangbanuhandslocked_2 = Movie(play="videos/turanbangbanuhandslocked_2.webm")
image banumagashowupdown = Movie(play="videos/banumagashowupdown.webm")
image banuswingmagarope = Movie(play="videos/banuswingmagarope.webm")
image magafuckbanu = Movie(play="videos/magafuckbanu.webm")
image magafuckbanu_2 = Movie(play="videos/magafuckbanu_2.webm")
image vusalravagebanu = Movie(play="videos/vusalravagebanu.webm")










image aldojhbjh = Movie(play="videos/aldojhbjh.webm")
image aroofbjhbjh = Movie(play="videos/aroofbjhbjh.webm")
image banufuckedkamilwatchvgcfg = Movie(play="videos/banufuckedkamilwatchvgcfg.webm")
image banusuckdxfd = Movie(play="videos/banusuckdxfd.webm")
image changingroomnkjbh = Movie(play="videos/changingroomnkjbh.webm")
image dominationfgdgf = Movie(play="videos/dominationfgdgf.webm")
image guysfuckbanudoggyhggfcgh = Movie(play="videos/guysfuckbanudoggyhggfcgh.webm")
image guysfuckbanustandingjhvhgvhg = Movie(play="videos/guysfuckbanustandingjhvhgvhg.webm")
image handgcgfvjh = Movie(play="videos/handgcgfvjh.webm")
image natasha_ridejhvhj = Movie(play="videos/natasha_ridejhvhj.webm")
image natbanunmbh = Movie(play="videos/natbanunmbh.webm")
image nelsonbnvnb = Movie(play="videos/nelsonbnvnb.webm")
image poladbanustandingbjh = Movie(play="videos/poladbanustandingbjh.webm")
image poladbanuvgfh = Movie(play="videos/poladbanuvgfh.webm")
image poladnatbanuhjhjv = Movie(play="videos/poladnatbanuhjhjv.webm")
image rooffuckvjh = Movie(play="videos/rooffuckvjh.webm")
image suckingghvg = Movie(play="videos/suckingghvg.webm")
















image animasiya_banu_ridingbackview = Movie(play="videos/animasiya_banu_ridingbackview.webm")
image animation_banu_ride_polad = Movie(play="videos/animation_banu_ride_polad.webm")
image animasiya_banusuckpoladkitchen = Movie(play="videos/animasiya_banusuckpoladkitchen.webm")
image animasiya_poladmissionarynextkamil = Movie(play="videos/animasiya_poladmissionarynextkamil.webm")
image animasiya_aruslansikiplank = Movie(play="videos/animasiya_aruslansikiplank.webm")
image animasiya_aruslanspnak = Movie(play="videos/animasiya_aruslanspnak.webm")
image animasiya_ruslanmissionary = Movie(play="videos/animasiya_ruslanmissionary.webm")
image animation_ruslanfuckbanushowerpussy = Movie(play="videos/animation_ruslanfuckbanushowerpussy.webm")
image animation_ruslanbanushowerdownview = Movie(play="videos/animation_ruslanbanushowerdownview.webm")




























image chat1 = "chat1.jpg"
image chat2 = "chat2.jpg"
image chat3 = "chat3.jpg"
image chat4 = "chat4.jpg"
image chat5 = "chat5.jpg"
image chat6 = "chat6.jpg"

image color10 = "color10.png"
image color13 = "color13.png"
image color15 = "color15.png"
image color20 = "color20.png"
image angel = "angeldemon1.png"
image xscenes = "xscenesindicators.png"


image ending2 = "ending2.png"
image ending3 = "ending3.png"
image ending4 = "ending4.png"
image ending5 = "ending5.png"
image logo = "LF_logo.png"
image faith = ConditionSwitch(
    
    
    "banu_kamil == 26 ", "kamilpoints12.png",
    "banu_kamil == 25 ", "kamilpoints12.png",
    "banu_kamil == 24 ", "kamilpoints11.png",
    "banu_kamil == 23 ", "kamilpoints11.png",
    "banu_kamil == 22 ", "kamilpoints10.png",
    "banu_kamil == 21 ", "kamilpoints10.png",
    "banu_kamil == 20 ", "kamilpoints9.png",
    
    "banu_kamil == 19 ", "kamilpoints9.png",
    "banu_kamil == 18 ", "kamilpoints8.png",
    
    "banu_kamil == 17 ", "kamilpoints8.png",                         
    "banu_kamil == 16 ", "kamilpoints7.png",
    
    "banu_kamil == 15 ", "kamilpoints7.png",
    "banu_kamil == 14 ", "kamilpoints6.png",
    
    "banu_kamil == 13 ", "kamilpoints6.png",
    "banu_kamil == 12 ", "kamilpoints5.png",
    "banu_kamil == 11 ", "kamilpoints5.png",
    
    "banu_kamil == 10 ", "kamilpoints4.png",
    "banu_kamil == 9 ", "kamilpoints4.png",
    "banu_kamil == 8 ", "kamilpoints3.png",
    
    "banu_kamil == 7 ", "kamilpoints3.png",
    "banu_kamil == 6 ", "kamilpoints2.png",
    "banu_kamil == 5 ", "kamilpoints2.png",
    "banu_kamil == 4 ", "kamilpoints1.png",

    "banu_kamil > 26 ", "kamilpoints12.png",
    "banu_kamil < 4 ", "kamilpoints1.png",
    )






image angeldevilcondition = ConditionSwitch(
    
    "banubad == 0 ", "angeldemon1.png",
    "banubad == 1 ", "angeldemon1.png",
    "banubad == 2 ", "angeldemon1.png",
    "banubad == 3 ", "angeldemon2.png",
    "banubad == 4 ", "angeldemon2.png",
    "banubad == 5 ", "angeldemon2.png",
    "banubad == 6 ", "angeldemon3.png",
    "banubad == 7 ", "angeldemon3.png",
    "banubad == 8 ", "angeldemon3.png",
    "banubad == 9 ", "angeldemon3.png",
    "banubad == 10 ", "angeldemon4.png",
    "banubad == 11 ", "angeldemon4.png",
    "banubad == 12 ", "angeldemon4.png",
    "banubad == 13 ", "angeldemon5.png",
    "banubad == 14 ", "angeldemon5.png",
    "banubad == 15 ", "angeldemon6.png",
    "banubad == 16 ", "angeldemon6.png",
    "banubad == 17 ", "angeldemon7.png",
    "banubad == 18 ", "angeldemon7.png",
    "banubad == 19 ", "angeldemon8.png",
    "banubad == 20 ", "angeldemon8.png",
    "banubad == 21 ", "angeldemon8.png",
    "banubad == 22 ", "angeldemon9.png",
    "banubad == 23 ", "angeldemon9.png",
    "banubad == 24 ", "angeldemon10.png",
    "banubad == 25 ", "angeldemon10.png",
    "banubad == 26 ", "angeldemon11.png",
    "banubad == 27 ", "angeldemon11.png",
    "banubad == 28 ", "angeldemon12.png",
    "banubad == 29 ", "angeldemon12.png",
    "banubad == 30 ", "angeldemon13.png",
    "banubad == 31 ", "angeldemon13.png",
    "banubad == 32 ", "angeldemon14.png",
    "banubad == 33 ", "angeldemon14.png",
    "banubad > 33 ", "angeldemon14.png",


    )




image loyalty = ConditionSwitch(
    
    "loyalty == 0 ", "loyalty0.png",
    "loyalty == 1 ", "loyalty1.png",
    "loyalty == 2 ", "loyalty2.png",
    "loyalty == 3 ", "loyalty3.png",
    "loyalty == 4 ", "loyalty4.png",
    "loyalty == 5 ", "loyalty5.png",

    )

image lust = ConditionSwitch(
    
    "lust == 0 ", "lust0.png",
    "lust == 1 ", "lust1.png",
    "lust == 2 ", "lust2.png",
    "lust == 3 ", "lust3.png",
    "lust == 4 ", "lust4.png",
    "lust == 5 ", "lust5.png",

    )

image orgasm = ConditionSwitch(
    
    "orgasm == 0 ", "orgasm0.png",
    "orgasm == 1 ", "orgasm1.png",
    "orgasm == 2 ", "orgasm2.png",
    "orgasm == 3 ", "orgasm3.png",
    "orgasm == 4 ", "orgasm4.png",
    "orgasm == 5 ", "orgasm5.png",

    )





define b = Character("Banu", color= "#8A090E" )
define b_ = Character("Banu", color= "#8A090E",   what_color="#FFFF00", what_italic=True   )

define l = Character("Leyla" , color= "#8F00FF")
define l_ = Character("Leyla" , color= "#8F00FF",    what_color="#FFFF00", what_italic=True   )

define n = Character("Nesrin", color = "#F239B0")
define n_ = Character("Nesrin", color = "#F239B0",   what_color="#FFFF00", what_italic=True   )
define r = Character("Ruslan", color = "#153558")
define r_ = Character("Ruslan", color = "#153558",  what_color="#FFFF00", what_italic=True  )
define k = Character("Kamil", color = "#4C2915")
define k_ = Character("Kamil", color = "#4C2915",  what_color="#FFFF00", what_italic=True   )
define t = Character("Turan", color = "#000000")
define t_ = Character("Turan", color = "#000000",  what_color="#FFFF00", what_italic=True )

define ja = Character("Javid", color = "#000000")
define vu = Character("Vusal", color = "#153558")

define cam = Character("Camal", color = "#000000")
define cam_ = Character("Camal", color = "#000000",  what_color="#FFFF00", what_italic=True )


define p = Character("Polad", color = "#DD7D00")
define p_ = Character("Polad", color = "#DD7D00", what_color="#FFFF00", what_italic=True  )
define pol = Character("Police Officer 1", color = "#DD7D00")
define pol2 = Character("Police Officer 2", color = "#DD7D00")

define s = Character("Sevda", color = "#FF00B9")
define s_ = Character("Sevda", color = "#FF00B9",  what_color="#FFFF00", what_italic=True )
define guy1 = Character("Guy 1", color = "#232323")
define guy1_ = Character("Guy 1", color = "#232323",  what_color="#FFFF00", what_italic=True  )
define guy2 = Character("Guy 2", color = "#232323")
define guy2_ = Character("Guy 2", color = "#232323",   what_color="#FFFF00", what_italic=True  )

define cus = Character("Customer", color = "#232323")

define dev = Character("Developer", color = "#232323")
define dev_ = Character("Developer", color = "#232323",  what_color="#FFFF00", what_italic=True   )
define a = Character("Aydan" , color= "#E100E0")
define a_ = Character("Aydan" , color= "#E100E0",    what_color="#FFFF00", what_italic=True    )
define ays = Character("Aysel", color = "#FF00B9")
define ays_ = Character("Aysel", color = "#FF00B9",        what_color="#FFFF00", what_italic=True    )
define m = Character("Maga", color = "#000000")
define m_ = Character("Maga", color = "#000000",  what_color="#FFFF00", what_italic=True )
define sam = Character("Samir", color = "#0189B6")
define sam_ = Character("Samir", color = "#0189B6",   what_color="#FFFF00", what_italic=True  )
define h = Character("Humay", color = "#FF00B9")
define h_ = Character("Humay", color = "#FF00B9",    what_color="#FFFF00", what_italic=True   )
define mur = Character("Murat", color = "#003616")
define mur_ = Character("Murat", color = "#003616",    what_color="#FFFF00", what_italic=True   )
define sey = Character("Seyhun", color = "#B97A57")
define sey_ = Character("Seyhun", color = "#B97A57",     what_color="#FFFF00", what_italic=True   )
define ram = Character("Ramin", color = "#2303BC")
define ram_ = Character("Ramin", color = "#2303BC",   what_color="#FFFF00", what_italic=True    )
define sa = Character("Sasha", color = "#2303BC")
define nat = Character("Natasha" , color= "#E100E0")
define guy = Character("Guy", color = "#232323")
define sel = Character("Seller", color = "#232323")
define un = Character("Unknown man", color = "#232323")
define un_ = Character("Unknown man", color = "#232323" ,    what_color="#FFFF00", what_italic=True  )
define hs = Character("Hassan", color = "#232323")
define hs_ = Character("Hassan", color = "#232323" ,    what_color="#FFFF00", what_italic=True  )
define ah = Character("Ahmed", color = "#B97A57")
define ar = Character("Arab", color = "#000000")
define pol = Character("Police Officer", color = "#232323")
define hic = Character("Hicran" , color= "#E100E0")
define ra = Character("Rauf", color = "#2303BC")
define boss = Character("Muxtar", color = "#000000")
define v = Character("Vladimir", color = "#000000")
define am = Character("Amir", color = "#2303BC")
define doc = Character("Doctor", color = "#2303BC")
define narrator = Character(None, what_color="#FFFF00", what_italic=True)
define sa_ = Character("Sasha", color = "#2303BC",         what_color="#FFFF00", what_italic=True      )
define nat_ = Character("Natasha" , color= "#E100E0",         what_color="#FFFF00", what_italic=True   )
define guy_ = Character("Guy", color = "#232323",              what_color="#FFFF00", what_italic=True    )
define sel_ = Character("Seller", color = "#232323",                  what_color="#FFFF00", what_italic=True   )
define un_ = Character("Unknown man", color = "#232323",             what_color="#FFFF00", what_italic=True   )
define ah_ = Character("Ahmed", color = "#B97A57",             what_color="#FFFF00", what_italic=True    )
define ar_ = Character("Arab", color = "#000000",                 what_color="#FFFF00", what_italic=True    )
define pol_ = Character("Police Officer", color = "#232323",              what_color="#FFFF00", what_italic=True    )
define hic_ = Character("Hicran" , color= "#E100E0",         what_color="#FFFF00", what_italic=True     )
define ra_ = Character("Rauf", color = "#2303BC",            what_color="#FFFF00", what_italic=True    )
define boss_ = Character("Muxtar", color = "#000000",           what_color="#FFFF00", what_italic=True    )
define v_ = Character("Vladimir", color = "#000000",              what_color="#FFFF00", what_italic=True     )
define am_ = Character("Amir", color = "#2303BC",                  what_color="#FFFF00", what_italic=True     )
define doc_ = Character("Doctor", color = "#2303BC",               what_color="#FFFF00", what_italic=True    )
define ab = Character("Abdul", color = "#DD7D00")
define ab_ = Character("Abdul", color = "#DD7D00",              what_color="#FFFF00", what_italic=True              )
define far = Character("Farhad", color = "#000000")
define far_ = Character("Farhad", color = "#000000",             what_color="#FFFF00", what_italic=True             )
define mal = Character("Malik", color = "#000000")
define mal_ = Character("Malik", color = "#000000",         what_color="#FFFF00", what_italic=True             )
define met = Character("Metin", color = "#153558")
define met_ = Character("Metin", color = "#153558",     what_color="#FFFF00", what_italic=True        )
define wait = Character("Waiter", color = "#232323")
define wait_ = Character("Waiter", color = "#232323",     what_color="#FFFF00", what_italic=True      )
define ri = Character("Rina" , color= "#8F00FF")
define ri_ = Character("Rina" , color= "#8F00FF",    what_color="#FFFF00", what_italic=True   )
define ali = Character("Ali", color = "#4C2915")
define ali_ = Character("Ali", color = "#4C2915",     what_color="#FFFF00", what_italic=True     )
define serv = Character("Servant", color = "#000000")
define blonde = Character("Blonde", color = "#CEAC81")
define brunette = Character("Brunette", color = "#000000")
define redgirl = Character("Girl in red", color = "#E33C2F")
define ame = Character("Amelie", color = "#E33C2F")
define reese = Character("Reese", color = "#E33C2F")
define carla = Character("Carla", color = "#000000")
define pilot = Character("Pilot", color = "#DD7D00")
define attendant = Character("Girl", color = "#CEAC81")
define girl1 = Character("Girl in black", color = "#222A30")
define girl2 = Character("Girl in red", color = "#E62424")
define ins = Character("Instructor", color = "#000000")
define woman = Character("Woman", color = "#CEAC81")
define man = Character("Man", color = "#232323")
define ta = Character("Tarik", color = "#232323")
define mux = Character("Muxtar", color = "#232323")
define little = Character("Little girl", color = "#153558")
define dad = Character("Boss", color = "#000000")
define dad_ = Character("Boss", color = "#000000",       what_color="#FFFF00", what_italic=True             )
define mah = Character("Mahmud", color = "#232323")
define mah_ = Character("Mahmud", color = "#000000",       what_color="#FFFF00", what_italic=True             )
define cr = Character("Crook" , color= "#8F00FF")
define cr_ = Character("Crook" , color= "#8F00FF",    what_color="#FFFF00", what_italic=True   )
define ass = Character("Aslan", color = "#4C2915")
define ass_ = Character("Aslan" , color= "#4C2915",    what_color="#FFFF00", what_italic=True   )
define z = Character("Zaur", color = "#000000")
define z_ = Character("Zaur", color = "#000000",       what_color="#FFFF00", what_italic=True             )
define o = Character("Orxan", color = "#232323")
define o_ = Character("Orxan", color = "#232323",        what_color="#FFFF00", what_italic=True           )
define beg = Character("Beggar", color = "#232323")
define beg_ = Character("Beggar", color = "#232323",        what_color="#FFFF00", what_italic=True           )
define ken = Character("Kenan", color = "#222A30")
define f = Character("Faiq", color = "#232323")
define meta = Character("Metanet", color = "#682510")
define meta_ = Character("Metanet", color = "#682510",      what_color="#FFFF00", what_italic=True     )
define nur = Character("Nurlan", color = "#000000")
define emil = Character("Emil", color = "#232323")
define hood = Character("Hooded Man", color = "#232323")
define va = Character("Vasif", color = "#4C2915")
define va_ = Character("Vasif", color = "#4C2915",  what_color="#FFFF00", what_italic=True   )
define ha = Character("Hasan", color = "#153558")
define ha_ = Character("Hasan", color = "#153558",     what_color="#FFFF00", what_italic=True        )


init python:
    renpy.music.register_channel("music2", "sfx", True)
    renpy.music.register_channel("music3", "sfx", True)







label splashscreen:


    $ renpy.movie_cutscene("videos/Comp 1_1_1.webm", delay=None)


    $ banu_ruslan = 0
    $ banu_kamil = 10
    $ banu_turan = 0
    $ banu_nesrin = 0
    $ banu_polad = 0
    $ leyla_ruslan = 0
    $ leyla_kamil = 0
    $ banubad = 0
    $ domme = 0
    $ kamilbeta = 0
    $ lust = 0
    $ turandate = False
    $ spykamil = False
    $ ruslanargument = False
    $ turandate = False
    $ streetguys = False
    $ threesome = False
    $ murat = False
    $ humiliatingseyhun = False
    $ ahmedtease = False
    $ murattease = False
    $ dinnerreddress = False
    $ banukamilbedroomchoicesblabla = 0
    default gallery_unlock_all = False
    default ruslan_ending_unlocked = False


    python:

        if not persistent.set_volumes:
            
            persistent.set_volumes = True
            _preferences.volumes['music'] *= .25
            _preferences.volumes['sfx'] *= .35 
            _preferences.volumes['voice'] *= .30 







    scene black
    with Pause(1)

    show war1
    show disclaimer2 behind war1 with dissolve
    $ renpy.pause(4.5)
    hide war1

    scene black
    with Pause(1)

    show disclaimer with dissolve
    $ renpy.pause(10)

    return









label start:

    init:
        $ agressive = False

    $ banu_ruslan = 0
    $ banu_kamil = 10
    $ banu_turan = 0
    $ banu_nesrin = 0
    $ banu_polad = 0
    $ leyla_ruslan = 0
    $ leyla_kamil = 0
    $ banubad = 0
    $ domme = 0
    $ kamilbeta = 0
    $ lust = 0
    default turandate = True
    default spykamil = True
    default ruslanargument = True
    default streetguys = True
    default threesome = True
    default murat = True
    default humiliatingseyhun = True
    default ahmedtease = True
    default murattease = True
    default dinnerreddress = True
    $ banukamilbedroomchoicesblabla = 0
    $ poladconversationinthekitchenchoicesblabla = 0
    $ banudominateruslan = 1
    default killturan = False
    default agreetoruslanoffer = True
    default banumeetruslaninprivateplace = False
    default banudefendherself = False
    default stayandwatchpoladandnesrin = True
    default banukissorxan = True
    default banuagreetostayatclub = True
    default banudanceclosetoorxan = True
    default banukisskamilinfrontofpolad = True
    default banuscoldpolad = False
    default banuagreetoobeyturanonemonth = True
    default banusendabdulselfie = True
    default banutalksarcastictoaslan = True
    default banuignorethebeggar = True
    default kamilagreetoplaythegame = True
    default followpolad = True
    default banuturansexfirsttime = True
    default banutakethebetfuckmurat = True
    default callahmed = True
    default getridoftoyshome = False
    default banubad = 100
    default banugotomuratsapartmentafterfun = True
    default banuagreebowlingmurat = True
    default borrowmoneyfrompolad = True
    default banuflirtwithpoladinthelivingroom = True
    default banuundressedinfrontofboss = True
    default banusitnexttopolad = True
    default banuwantstoteaseintern = True
    default banustaysalittlelongerintern = True
    default banuskeptikalaslan = True
    default banumockaslan = True
    default banuchoosefirstone = True
    default banuordersservant = True
    default orderservantlickfoot = True
    default slapservant = True
    default askservantshowdick = True
    default banurevealthetruth = True
    default banupushabdulaway = True
    default banuconfessapastsecrettokamil = True
    default banusharedetailswithkamil = True
    default banuorderthefood = True
    default banupaysatseafoodrestaurant = True
    default kamilholdbanufrombehindrestroom = True
    default kamilwarnkamilbathroom = True
    $ banupoladshowering = False
    $ banustaysmuratandfriend = False
    default banupoladshowering = True
    default banustaysmuratandfriend = True
    $ banuconfesscheating = False
    default banuconfesscheating = True
    $ kamilencouragebanu = False
    default kamilencouragebanu = True
    $ banupoladshowering = False
    $ banustaysmuratandfriend = False
    $ banuacceptmafia = False
    default banuacceptmafia = True
    $ banubeattheguy = False
    default banubeattheguy = True
    default banublockturan = True




    stop music









    jump ask1


label endings:


    jump credits



















label credits:
    play music "audio/mainmenumusic2.mp3"
    image splash = Text("{size=90}Lustful Fantasy", text_align=0.5, ypos=0.5)

    image cred = Text(credits_s, font="skate.otf", text_align=0.5)
    image cred = Text(credits_s, text_align=0.5)
    image theend = Text("{size=80}The End of this version", text_align=0.5)
    image thanks = Text("{size=80}Thanks for Playing!", text_align=0.5)
    $ credits_speed = 15
    scene black
    show cred at Move((0.5, 5.0), (0.5, 0.0), credits_speed, repeat=False, bounce=False, xanchor="center", yanchor="bottom")
    show theend:
        yanchor 0.5 ypos 0.5
        xanchor 0.5 xpos 0.5
    with dissolve
    with Pause(5)
    hide theend
    with dissolve
    with Pause(credits_speed - 5)
    show splash
    with dissolve
    with Pause(3)
    hide splash
    with dissolve
    with Pause(1)
    show thanks:
        yanchor 0.5 ypos 0.5
        xanchor 0.5 xpos 0.5
    with dissolve
    with Pause(4)
    hide thanks
    with dissolve
    return

init python:
    credits = ('Writing', 'Lustful Fantasy'), ('Programming', 'Lustful Fantasy'), ('Music',  'Lustful Fantasy'), ('SPECIAL THANKS TO', 'All my Patrons')
    credits_s = "{size=80}Life in Middle East\n\n"
    c1 = ''
    for c in credits:
        if not c1==c[0]:
            credits_s += "\n{size=60}" + c[0] + "\n"
        credits_s += "{size=40}" + c[1] + "\n"
        c1=c[0]
    credits_s += "\n{size=60}Engine\n{size=40}" + renpy.version()













init:
    define flash = Fade(.25, 0.0, .50, color="#fff")
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
