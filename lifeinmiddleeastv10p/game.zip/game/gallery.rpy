


init python:

    import math 

    def add_gallery_scene(scene_label, gallery_scene_name, gallery_image_path ):
        """
        All arguments must be string.
        """
        if [scene_label, gallery_scene_name, im.Scale(gallery_image_path,500,300)] not in persistent.gallery_b_list:
            persistent.gallery_b_list.append([scene_label, gallery_scene_name, im.Scale(gallery_image_path,500,300)])




screen gallery_navigation():


    add "images/gallerybackground.jpg"






    textbutton _("UNLOCK ALL"):
        xpos 1500
        ypos 80

        action [
            SetVariable("gallery_unlock_all", True),
            SetVariable("persistent.banu_teases_ruslan_unlocked", True),
            SetVariable("persistent.banu_masturbates_unlocked", True),
            SetVariable("persistent.banuorderstheservant_unlocked", True),
            SetVariable("persistent.banu_reject_kamil_anal_corruptedroute_unlocked", True),
            SetVariable("persistent.gym_shower_fuck_unlocked", True),

            SetVariable("persistent.banusendturan_selfie_unlocked", True),
            SetVariable("persistent.banu_makehassan_cum_unlocked", True),
            SetVariable("persistent.kamil_fuck_banu_dadoutside_unlocked", True),
            SetVariable("persistent.banu_suck_kamil_dadwatch_unlocked", True),
            SetVariable("persistent.kamil_fuck_banu_necklace_unlocked", True),
            SetVariable("persistent.banu_kamil_outside_sex_unlocked", True),
            SetVariable("persistent.banu_wash_dad_back_unlocked", True),
            SetVariable("persistent.banu_masturbate_dad_unlocked", True),
            SetVariable("persistent.banu_naked_photo_orxan_unlocked", True),
            SetVariable("persistent.rina_cuckolding_kamil_unlocked", True),
            SetVariable("persistent.banu_blackman_play_unlocked", True),
            SetVariable("persistent.orxan_threesome_unlocked", True),
            SetVariable("persistent.ali_fuck_banu_unlocked", True),
            SetVariable("persistent.turan_banu_power_unlocked", True),
            SetVariable("persistent.banu_revenge_unlocked", True),
            SetVariable("persistent.banu_natasha_unlocked", True),
            SetVariable("persistent.guys_banu_unlocked", True),
            SetVariable("persistent.changing_room_unlocked", True),
            SetVariable("persistent.threesome_666_unlocked", True),
            SetVariable("persistent.leyla_threesome_unlocked_1", True),
            SetVariable("persistent.ruslan_fucks_leyla_unlocked", True),
            SetVariable("persistent.leyla_rape_scene_unlocked", True),
            SetVariable("persistent.turan_fucks_aydan_unlocked", True),
            SetVariable("persistent.turan_harrasses_unlocked", True),
            SetVariable("persistent.turan_fucks_banu_unlocked", True),
            SetVariable("persistent.turan_eats_banu_unlocked", True),
            SetVariable("persistent.turan_fucks_banu_1_unlocked", True),
            SetVariable("persistent.turan_destroy_banu_unlocked", True),
            SetVariable("persistent.polad_teases_banu_unlocked", True),
            SetVariable("persistent.poland_fucks_natasha_unlocked", True),
            SetVariable("persistent.polad_fucks_banu2_unlocked", True),
            SetVariable("persistent.natasha_threesome_unlocked", True),
            SetVariable("persistent.banu_makesout_polad_unlocked", True),
            SetVariable("persistent.polad_fucks_banu3_unlocked", True),
            SetVariable("persistent.polad_banu_shower_unlocked", True),
            SetVariable("persistent.polad_banu_forest_unlocked", True),
            SetVariable("persistent.polad_fuck_banu_kamil_bedroom_cuckroute_unlocked", True),
            SetVariable("persistent.poladfuckbanubathcheatroute_unlocked", True),
            SetVariable("persistent.polad_nesrin_foursome_unlocked", True),
            SetVariable("persistent.polad_banu_power_shower_unlocked", True),
            SetVariable("persistent.banu_mountain_polad_unlocked", True),
            SetVariable("persistent.roof_sex_unlocked", True),
            SetVariable("persistent.dominating_polad_unlocked", True),
            SetVariable("persistent.threesome_555_unlocked", True),
            SetVariable("persistent.ruslan_whore_scene_unlocked_1", True),
            SetVariable("persistent.ruslan_blackmails_banu_unlocked", True),
            SetVariable("persistent.ruslan_rapes_banu_unlocked", True),
            SetVariable("persistent.banu_humiliates_ruslan_unlocked", True),
            SetVariable("persistent.banu_dominates_kamil_ruslan_unlocked", True),
            SetVariable("persistent.ruslan_fuck_leyla_banu_unlocked", True),
            SetVariable("persistent.abdul_sexting_banu_unlocked", True),
            SetVariable("persistent.abdul_fucksbanu_nexttokamil_unlocked", True),
            SetVariable("persistent.abdulfarhadfuckbanu_bathroom_unlocked", True),
            SetVariable("persistent.ahmedsfucksbanu_sofa_unlocked", True),
            SetVariable("persistent.kamil_banu_sex_unlocked", True),
            SetVariable("persistent.banu_rides_kamil_unlocked", True),
            SetVariable("persistent.kamil_banu_sex2_unlocked", True),
            SetVariable("persistent.kamil_banu_sex3_unlocked", True),
            SetVariable("persistent.banu_challanges_kammil_unlocked", True),
            SetVariable("persistent.banuflashkamilrestroom_unlocked", True),
            SetVariable("persistent.kamil_show_banu_who_is_man_unlocked", True), 
            SetVariable("persistent.kamil_dominate_banu_bedroom_unlocked", True),
            SetVariable("persistent.banu_tease_samir_unlocked", True),
            SetVariable("persistent.samirfucksbanu_bedroom_unlocked", True),
            SetVariable("persistent.murat_fucks_banu_unlocked", True),
            SetVariable("persistent.muratfucksbanuafterfunsexscenestaywithkamil_unlocked", True),
            SetVariable("persistent.murat_threesome_unlocked", True), 
            SetVariable("persistent.hicran_soaps_banu_unlocked", True),
            SetVariable("persistent.hicran_sucks_dick_unlocked", True),
            SetVariable("persistent.banu_hiran_kiss_unlocked", True),
            SetVariable("persistent.banu_wet_dream_unlocked", True), 
            SetVariable("persistent.hicran_vladimir_sex_unlocked", True),
              
            
            
            
            [Return(), Hide("gallery_navigation")],    
            [ShowMenu("gallery_navigation"), Show("gallery_a")]
       

    ]















    viewport id ("gallery_scroll"):
        mousewheel True
        ypos 140
        xpos 30
        ymaximum 800
        has vbox
        style_prefix "gallery_nav"


        textbutton _("Banu") action Show("gallery_a")
        textbutton _("Leyla") action Show("gallery_b")
        textbutton _("Turan") action Show("gallery_c")
        textbutton _("Polad") action Show("gallery_e")
        textbutton _("Ruslan") action Show("gallery_f")
        textbutton _("Abdul") action Show("gallery_g")
        textbutton _("Ahmed") action Show("gallery_h")
        textbutton _("Kamil") action Show("gallery_i")
        textbutton _("Samir") action Show("gallery_j")
        textbutton _("Murat") action Show("gallery_k")
        textbutton _("Hicran") action Show("gallery_l")

    vbar value YScrollValue("gallery_scroll") xpos 210 ypos 140 ymaximum 800




    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]


style gallery_nav_vbox:
    xalign 0.03
    yalign 0.5
    spacing 40


python:
    """


        """




screen gallery_a():
    default gallery_a_list = [
            
            
            ["banu_teases_ruslan","{color=#ababab}Banu teases Ruslan{/color}", im.Scale("images/banuteasesruslangallerygrey.jpg", 500, 300), im.Scale("images/banuteasesruslangallery.jpg", 500, 300), persistent.banu_teases_ruslan_unlocked],
            ["banu_masturbates","{color=#ababab}Banu masturbates next to Kamil{/color}", im.Scale("images/banumasturbatesnexttokamilgallerygrey.jpg", 500, 300), im.Scale("images/banumasturbatesnexttokamilgallery.jpg", 500, 300), persistent.banu_masturbates_unlocked],
            ["banuorderstheservant","{color=#ababab}Banu orders the servant{/color}", im.Scale("images/banuorderservantgallerygrey.jpg", 500, 300), im.Scale("images/banuorderservantgallery.jpg", 500, 300), persistent.banuorderstheservant_unlocked],
            ["banu_reject_kamil_anal_corruptedroute","{color=#ababab}Kamil eats Banu{/color}", im.Scale("images/kamileatsbanugallery_grey.jpg", 500, 300), im.Scale("images/kamileatsbanugallery.jpg", 500, 300), persistent.banu_reject_kamil_anal_corruptedroute_unlocked],
            ["gym_shower_fuck","{color=#ababab}Banu fucks the instructor{/color}", im.Scale("images/banugymguygallery_grey.jpg", 500, 300), im.Scale("images/banugymguygallery.jpg", 500, 300), persistent.gym_shower_fuck_unlocked],
            ["banusendturan_selfie","{color=#ababab}Banu chat with Turan{/color}", im.Scale("images/banusendturanselfiegallery_grey.jpg", 500, 300), im.Scale("images/banusendturanselfiegallery.jpg", 500, 300), persistent.banusendturan_selfie_unlocked],
            ["banu_makehassan_cum","{color=#ababab}Banu jerk off Hassan{/color}", im.Scale("images/banujerkoffhassangallery_grey.jpg", 500, 300), im.Scale("images/banujerkoffhassangallery.jpg", 500, 300), persistent.banu_makehassan_cum_unlocked],
            ["kamil_fuck_banu_dadoutside","{color=#ababab}Banu and Kamil{/color}", im.Scale("images/kamilbanufuckdadoutsidegallery_grey.jpg", 500, 300), im.Scale("images/kamilbanufuckdadoutsidegallery.jpg", 500, 300), persistent.kamil_fuck_banu_dadoutside_unlocked],
            ["banu_suck_kamil_dadwatch","{color=#ababab}Banu sucks Kamil{/color}", im.Scale("images/banusuckkamildadwatchgallery_grey.jpg", 500, 300), im.Scale("images/banusuckkamildadwatchgallery.jpg", 500, 300), persistent.banu_suck_kamil_dadwatch_unlocked],
            ["kamil_fuck_banu_necklace","{color=#ababab}Banu and Kamil{/color}", im.Scale("images/banu_kamil_necklacegallery_grey.jpg", 500, 300), im.Scale("images/banu_kamil_necklacegallery.jpg", 500, 300), persistent.kamil_fuck_banu_necklace_unlocked],
            ["banu_kamil_outside_sex","{color=#ababab}Banu outside sex{/color}", im.Scale("images/banuoutsidesexgallery_grey.jpg", 500, 300), im.Scale("images/banuoutsidesexgallery.jpg", 500, 300), persistent.banu_kamil_outside_sex_unlocked],
            ["banu_wash_dad_back","{color=#ababab}Banu wash Camal{/color}", im.Scale("images/banuwashcamalgallery_grey.jpg", 500, 300), im.Scale("images/banuwashcamalgallery.jpg", 500, 300), persistent.banu_wash_dad_back_unlocked],
            ["banu_masturbate_dad","{color=#ababab}Banu masturbate{/color}", im.Scale("images/banumasturbatedadgallery_grey.jpg", 500, 300), im.Scale("images/banumasturbatedadgallery.jpg", 500, 300), persistent.banu_masturbate_dad_unlocked],
            ["banu_naked_photo_orxan","{color=#ababab}Orxan and Banu{/color}", im.Scale("images/banunakedorxanphotogallery_grey.jpg", 500, 300), im.Scale("images/banunakedorxanphotogallery.jpg", 500, 300), persistent.banu_naked_photo_orxan_unlocked],
            ["rina_cuckolding_kamil","{color=#ababab}Cuckolding roleplay{/color}", im.Scale("images/rinacuckkamil_grey.jpg", 500, 300), im.Scale("images/rinacuckkamil.jpg", 500, 300), persistent.rina_cuckolding_kamil_unlocked],
            ["banu_blackman_play","{color=#ababab}Cheating scene{/color}", im.Scale("images/banucheatingscenegallery_grey.jpg", 500, 300), im.Scale("images/banucheatingscenegallery.jpg", 500, 300), persistent.banu_blackman_play_unlocked],
            ["orxan_threesome","{color=#ababab}Threesome{/color}", im.Scale("images/orxanthreesomegallery_grey.jpg", 500, 300), im.Scale("images/orxanthreesomegallery.jpg", 500, 300), persistent.orxan_threesome_unlocked],
            ["ali_fuck_banu","{color=#ababab}Ali{/color}", im.Scale("images/ali_banu_gallery_grey.jpg", 500, 300), im.Scale("images/ali_banu_gallery.jpg", 500, 300), persistent.ali_fuck_banu_unlocked],
            ["turan_banu_power","{color=#ababab}Turan{/color}", im.Scale("images/turan_banu_powregallery_grey.jpg", 500, 300), im.Scale("images/turan_banu_powregallery.jpg", 500, 300), persistent.turan_banu_power_unlocked],
            ["banu_revenge","{color=#ababab}Revenge{/color}", im.Scale("images/banurevengegallery_grey.jpg", 500, 300), im.Scale("images/banurevengegallery.jpg", 500, 300), persistent.banu_revenge_unlocked],
            ["banu_natasha","{color=#ababab}Natasha{/color}", im.Scale("images/banunatashagallery_grey.jpg", 500, 300), im.Scale("images/banunatashagallery.jpg", 500, 300), persistent.banu_natasha_unlocked],
            ["guys_banu","{color=#ababab}The guys{/color}", im.Scale("images/banuguysgallery_grey.jpg", 500, 300), im.Scale("images/banuguysgallery.jpg", 500, 300), persistent.guys_banu_unlocked],
            ["changing_room","{color=#ababab}Changing room{/color}", im.Scale("images/changingroomgallery_grey.jpg", 500, 300), im.Scale("images/changingroomgallery.jpg", 500, 300), persistent.changing_room_unlocked],
            ["threesome_666","{color=#ababab}Threesome{/color}", im.Scale("images/threesome666gallery_grey.jpg", 500, 300), im.Scale("images/threesome666gallery.jpg", 500, 300), persistent.threesome_666_unlocked]
            

        ]

    style_prefix "navigation" tag menu



    default total_scenes = len(gallery_a_list)
    default cg_page_a = 1
    default cg_page_a_max = max(int(total_scenes / 4) + (total_scenes % 4 > 0), 1)

    zorder 100







    hbox:

        xalign 0.5
        yalign 0.5

        grid 2 2:

            xalign 0.5
            yalign 0.5
            xspacing 20
            yspacing 20

            for i in range(((cg_page_a-1)*4),(cg_page_a*4)):
                if i < len(gallery_a_list):
                    vbox:
                        imagebutton:
                            action Replay(gallery_a_list[i][0], scope={ }, locked=not  gallery_a_list[i][4])
                            idle Transform(gallery_a_list[i][2], zoom=1)
                            hover gallery_a_list[i][3]



                        text str(gallery_a_list[i][1]):
                            color "#262626"
                            bold True
                            xalign 0.5
                else:
                    null

    hbox:
        xalign 0.5
        yalign 0.99


        textbutton _("Prev") action [SetLocalVariable("cg_page_a", If(cg_page_a>1, cg_page_a-1, cg_page_a_max))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]



        for page in range(1, cg_page_a_max+1):
            if page == cg_page_a:
                textbutton "{color=#ffa237}{b}[page]{/b}{/color}" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]
            else:
                textbutton "[page]" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]

        textbutton _("Next") action [SetLocalVariable("cg_page_a", If(cg_page_a<cg_page_a_max, cg_page_a+1, 1))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]


    textbutton _("Return") action [Return(), Hide("gallery_navigation")] xalign 0.97 yalign 0.95


    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]


screen gallery_b():
    default gallery_b_list = [
            
            
            ["leyla_threesome","{color=#ababab}Leyla Threesome{/color}", im.Scale("images/leylathreesomegallerygrey.jpg", 500, 300), im.Scale("images/leylathreesomegallery.jpg", 500, 300), persistent.leyla_threesome_unlocked_1],
            ["ruslan_fucks_leyla","{color=#ababab}Ruslan fucks Leyla{/color}", im.Scale("images/ruslanfucksleylagallerygrey.jpg", 500, 300), im.Scale("images/ruslanfucksleylagallery.jpg", 500, 300), persistent.ruslan_fucks_leyla_unlocked],
            ["leyla_rape_scene","{color=#ababab}Leyla gets raped{/color}", im.Scale("images/leylarapedgallerygrey.jpg", 500, 300), im.Scale("images/leylarapedgallery.jpg", 500, 300), persistent.leyla_rape_scene_unlocked]

        ]

    style_prefix "navigation" tag menu



    default total_scenes = len(gallery_b_list)
    default cg_page_a = 1
    default cg_page_a_max = max(int(total_scenes / 4) + (total_scenes % 4 > 0), 1)

    zorder 100







    hbox:

        xalign 0.5
        yalign 0.5

        grid 2 2:

            xalign 0.5
            yalign 0.5
            xspacing 20
            yspacing 20

            for i in range(((cg_page_a-1)*4),(cg_page_a*4)):
                if i < len(gallery_b_list):
                    vbox:
                        imagebutton:
                            action Replay(gallery_b_list[i][0], scope={ }, locked=not  gallery_b_list[i][4])
                            idle Transform(gallery_b_list[i][2], zoom=1)
                            hover gallery_b_list[i][3]



                        text str(gallery_b_list[i][1]):
                            color "#262626"
                            bold True
                            xalign 0.5
                else:
                    null

    hbox:
        xalign 0.5
        yalign 0.99


        textbutton _("Prev") action [SetLocalVariable("cg_page_a", If(cg_page_a>1, cg_page_a-1, cg_page_a_max))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]



        for page in range(1, cg_page_a_max+1):
            if page == cg_page_a:
                textbutton "{color=#ffa237}{b}[page]{/b}{/color}" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]
            else:
                textbutton "[page]" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]

        textbutton _("Next") action [SetLocalVariable("cg_page_a", If(cg_page_a<cg_page_a_max, cg_page_a+1, 1))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]


    textbutton _("Return") action [Return(), Hide("gallery_navigation")] xalign 0.97 yalign 0.95


    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]


screen gallery_c():
    default gallery_c_list = [
            
            
            ["turan_fucks_aydan","{color=#ababab}Turan Fucks Aydan{/color}", im.Scale("images/turanfuckesaydangallerygrey.jpg", 500, 300), im.Scale("images/turanfuckesaydangallery.jpg", 500, 300), persistent.turan_fucks_aydan_unlocked],
            ["turan_harrasses","{color=#ababab}Turan harasses Banu at work{/color}", im.Scale("images/turanharrasesbanuworkgallerygrey.jpg", 500, 300), im.Scale("images/turanharrasesbanuworkgallery.jpg", 500, 300), persistent.turan_harrasses_unlocked],
            ["turan_fucks_banu","{color=#ababab}Turan fucks Banu for the first time{/color}", im.Scale("images/turanfucksbanufirsttimegallerygrey.jpg", 500, 300), im.Scale("images/turanfucksbanufirsttimegallery.jpg", 500, 300), persistent.turan_fucks_banu_unlocked],
            ["turan_eats_banu","{color=#ababab}Turan eats Banu's pussy{/color}", im.Scale("images/turaneatsbanupussygallerygrey.jpg", 500, 300), im.Scale("images/turaneatsbanupussygallery.jpg", 500, 300), persistent.turan_eats_banu_unlocked],
            ["turan_fucks_banu_1","{color=#ababab}Turan fucks the shit out of Banu{/color}", im.Scale("images/turanfucksshitoutofbanugallerygrey.jpg", 500, 300), im.Scale("images/turanfucksshitoutofbanugallery.jpg", 500, 300), persistent.turan_fucks_banu_1_unlocked],
            ["turan_destroy_banu","{color=#ababab}Turan fucks her ass{/color}", im.Scale("images/turanfuckbanuassgallery_grey.jpg", 500, 300), im.Scale("images/turanfuckbanuassgallery.jpg", 500, 300), persistent.turan_destroy_banu_unlocked]
            

        ]

    style_prefix "navigation" tag menu



    default total_scenes = len(gallery_c_list)
    default cg_page_a = 1
    default cg_page_a_max = max(int(total_scenes / 4) + (total_scenes % 4 > 0), 1)

    zorder 100







    hbox:

        xalign 0.5
        yalign 0.5

        grid 2 2:

            xalign 0.5
            yalign 0.5
            xspacing 20
            yspacing 20

            for i in range(((cg_page_a-1)*4),(cg_page_a*4)):
                if i < len(gallery_c_list):
                    vbox:
                        imagebutton:
                            action Replay(gallery_c_list[i][0], scope={ }, locked=not  gallery_c_list[i][4])
                            idle Transform(gallery_c_list[i][2], zoom=1)
                            hover gallery_c_list[i][3]



                        text str(gallery_c_list[i][1]):
                            color "#262626"
                            bold True
                            xalign 0.5
                else:
                    null

    hbox:
        xalign 0.5
        yalign 0.99


        textbutton _("Prev") action [SetLocalVariable("cg_page_a", If(cg_page_a>1, cg_page_a-1, cg_page_a_max))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]



        for page in range(1, cg_page_a_max+1):
            if page == cg_page_a:
                textbutton "{color=#ffa237}{b}[page]{/b}{/color}" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]
            else:
                textbutton "[page]" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]

        textbutton _("Next") action [SetLocalVariable("cg_page_a", If(cg_page_a<cg_page_a_max, cg_page_a+1, 1))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]


    textbutton _("Return") action [Return(), Hide("gallery_navigation")] xalign 0.97 yalign 0.95


    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]


screen gallery_e():
    default gallery_e_list = [
            
            
            ["polad_teases_banu","{color=#ababab}Polad teases Banu{/color}", im.Scale("images/poladteasesbanugallerygrey.jpg", 500, 300), im.Scale("images/poladteasesbanugallery.jpg", 500, 300), persistent.polad_teases_banu_unlocked],
            ["poland_fucks_natasha","{color=#ababab}Polad fucks Natasha{/color}", im.Scale("images/poladfucksnatashagallerygrey.jpg", 500, 300), im.Scale("images/poladfucksnatashagallery.jpg", 500, 300), persistent.poland_fucks_natasha_unlocked],
            ["polad_fucks_banu2","{color=#ababab}Polad fucks Banu in his bedroom{/color}", im.Scale("images/poladfucksbanuinhisbedroomgallerygrey.jpg", 500, 300), im.Scale("images/poladfucksbanuinhisbedroomgallery.jpg", 500, 300), persistent.polad_fucks_banu2_unlocked],
            ["natasha_threesome","{color=#ababab}Natasha Polad and Sasha{/color}", im.Scale("images/natashathreesomepoladgallerygrey.jpg", 500, 300), im.Scale("images/natashathreesomepoladgallery.jpg", 500, 300), persistent.natasha_threesome_unlocked],
            ["banu_makesout_polad","{color=#ababab}Banu makes out with Polad{/color}", im.Scale("images/banumakesoutwithpoladgallerygrey.jpg", 500, 300), im.Scale("images/banumakesoutwithpoladgallery.jpg", 500, 300), persistent.banu_makesout_polad_unlocked],
            ["polad_fucks_banu3","{color=#ababab}Polad fucks Banu in the back room{/color}", im.Scale("images/poladfuckbanuinthebackroomgallerygrey.jpg", 500, 300), im.Scale("images/poladfuckbanuinthebackroomgallery.jpg", 500, 300), persistent.polad_fucks_banu3_unlocked],
            ["polad_banu_shower","{color=#ababab}Banu sees Polad showering{/color}", im.Scale("images/banupoladshowergallery_grey.jpg", 500, 300), im.Scale("images/banupoladshowergallery.jpg", 500, 300), persistent.polad_banu_shower_unlocked],
            ["polad_banu_forest","{color=#ababab}Polad fucks Banu in the forest{/color}", im.Scale("images/banupoladforestgallery_grey.jpg", 500, 300), im.Scale("images/banupoladforestgallery.jpg", 500, 300), persistent.polad_banu_forest_unlocked],
            ["polad_fuck_banu_kamil_bedroom_cuckroute","{color=#ababab}Polad cucks Kamil{/color}", im.Scale("poladcuckskamil_gallery_grey.jpg", 500, 300), im.Scale("images/poladcuckskamil_gallery.jpg", 500, 300), persistent.polad_fuck_banu_kamil_bedroom_cuckroute_unlocked],
            ["poladfuckbanubathcheatroute","{color=#ababab}Polad breaks Banu{/color}", im.Scale("poladbreaksbanugallery_grey.jpg", 500, 300), im.Scale("images/poladbreaksbanugallery.jpg", 500, 300), persistent.poladfuckbanubathcheatroute_unlocked],
            ["polad_nesrin_foursome","{color=#ababab}Foursome{/color}", im.Scale("foursomepoladgallery_grey.jpg", 500, 300), im.Scale("images/foursomepoladgallery.jpg", 500, 300), persistent.polad_nesrin_foursome_unlocked],
            ["polad_banu_power_shower","{color=#ababab}Banu shower{/color}", im.Scale("banupoladshowerssgallery_grey.jpg", 500, 300), im.Scale("images/banupoladshowerssgallery.jpg", 500, 300), persistent.polad_banu_power_shower_unlocked],
            ["banu_mountain_polad","{color=#ababab}Mountain sex{/color}", im.Scale("banumountainpoladgallery_grey.jpg", 500, 300), im.Scale("images/banumountainpoladgallery.jpg", 500, 300), persistent.banu_mountain_polad_unlocked],
            ["roof_sex","{color=#ababab}Roof sex{/color}", im.Scale("roofsexgallery_grey.jpg", 500, 300), im.Scale("images/roofsexgallery.jpg", 500, 300), persistent.roof_sex_unlocked],
            ["dominating_polad","{color=#ababab}Dominating Polad{/color}", im.Scale("dominatingpoladgallery_grey.jpg", 500, 300), im.Scale("images/dominatingpoladgallery.jpg", 500, 300), persistent.dominating_polad_unlocked],
            ["threesome_555","{color=#ababab}Threesome{/color}", im.Scale("threesome555gallery_grey.jpg", 500, 300), im.Scale("images/threesome555gallery.jpg", 500, 300), persistent.threesome_555_unlocked]
            

        ]

    style_prefix "navigation" tag menu



    default total_scenes = len(gallery_e_list)
    default cg_page_a = 1
    default cg_page_a_max = max(int(total_scenes / 4) + (total_scenes % 4 > 0), 1)

    zorder 100







    hbox:

        xalign 0.5
        yalign 0.5

        grid 2 2:

            xalign 0.5
            yalign 0.5
            xspacing 20
            yspacing 20

            for i in range(((cg_page_a-1)*4),(cg_page_a*4)):
                if i < len(gallery_e_list):
                    vbox:
                        imagebutton:
                            action Replay(gallery_e_list[i][0], scope={ }, locked=not  gallery_e_list[i][4])
                            idle Transform(gallery_e_list[i][2], zoom=1)
                            hover gallery_e_list[i][3]



                        text str(gallery_e_list[i][1]):
                            color "#262626"
                            bold True
                            xalign 0.5
                else:
                    null

    hbox:
        xalign 0.5
        yalign 0.99


        textbutton _("Prev") action [SetLocalVariable("cg_page_a", If(cg_page_a>1, cg_page_a-1, cg_page_a_max))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]



        for page in range(1, cg_page_a_max+1):
            if page == cg_page_a:
                textbutton "{color=#ffa237}{b}[page]{/b}{/color}" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]
            else:
                textbutton "[page]" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]

        textbutton _("Next") action [SetLocalVariable("cg_page_a", If(cg_page_a<cg_page_a_max, cg_page_a+1, 1))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]


    textbutton _("Return") action [Return(), Hide("gallery_navigation")] xalign 0.97 yalign 0.95


    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]


screen gallery_f():
    default gallery_f_list = [
            
            
            ["ruslan_whore_scene","{color=#ababab}Ruslan has fun{/color}", im.Scale("images/ruslanhasfunwithhiswhoregrey.png", 500, 300),im.Scale("images/ruslanhasfunwithhiswhore.png", 500, 300), persistent.ruslan_whore_scene_unlocked_1],
            ["ruslan_blackmails_banu","{color=#ababab}Ruslan blackmails Banu{/color}", im.Scale("images/ruslanblackmailsbanukitchengallerygrey.jpg", 500, 300),im.Scale("images/ruslanblackmailsbanukitchengallery.jpg", 500, 300), persistent.ruslan_blackmails_banu_unlocked],
            ["ruslan_rapes_banu","{color=#ababab}Ruslan rapes Banu{/color}", im.Scale("images/ruslanrapesbanugallerygrey.jpg", 500, 300),im.Scale("images/ruslanrapesbanugallery.jpg", 500, 300), persistent.ruslan_rapes_banu_unlocked],
            ["banu_humiliates_ruslan","{color=#ababab}Banu humiliates Ruslan{/color}", im.Scale("images/banuhumiliatesruslangallerygrey.jpg", 500, 300),im.Scale("images/banuhumiliatesruslangallery.jpg", 500, 300), persistent.banu_humiliates_ruslan_unlocked],
            ["banu_dominates_kamil_ruslan","{color=#ababab}Banu dominates Ruslan and Kamil{/color}", im.Scale("images/banudominateskamilruslangallery_grey.jpg", 500, 300),im.Scale("images/banudominateskamilruslangallery.jpg", 500, 300), persistent.banu_dominates_kamil_ruslan_unlocked],
            ["ruslan_fuck_leyla_banu","{color=#ababab}Ruslan fucks Banu and Leyla{/color}", im.Scale("images/ruslanfuckleylabanugallery_grey.jpg", 500, 300),im.Scale("images/ruslanfuckleylabanugallery.jpg", 500, 300), persistent.ruslan_fuck_leyla_banu_unlocked]
            

        ]

    style_prefix "navigation" tag menu



    default total_scenes = len(gallery_f_list)
    default cg_page_a = 1
    default cg_page_a_max = max(int(total_scenes / 4) + (total_scenes % 4 > 0), 1)

    zorder 100







    hbox:

        xalign 0.5
        yalign 0.5

        grid 2 2:

            xalign 0.5
            yalign 0.5
            xspacing 20
            yspacing 20

            for i in range(((cg_page_a-1)*4),(cg_page_a*4)):
                if i < len(gallery_f_list):
                    vbox:
                        imagebutton:
                            action Replay(gallery_f_list[i][0], scope={ }, locked=not  gallery_f_list[i][4])
                            idle Transform(gallery_f_list[i][2], zoom=1)
                            hover gallery_f_list[i][3]



                        text str(gallery_f_list[i][1]):
                            color "#262626"
                            bold True
                            xalign 0.5
                else:
                    null

    hbox:
        xalign 0.5
        yalign 0.99


        textbutton _("Prev") action [SetLocalVariable("cg_page_a", If(cg_page_a>1, cg_page_a-1, cg_page_a_max))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]



        for page in range(1, cg_page_a_max+1):
            if page == cg_page_a:
                textbutton "{color=#ffa237}{b}[page]{/b}{/color}" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]
            else:
                textbutton "[page]" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]

        textbutton _("Next") action [SetLocalVariable("cg_page_a", If(cg_page_a<cg_page_a_max, cg_page_a+1, 1))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]


    textbutton _("Return") action [Return(), Hide("gallery_navigation")] xalign 0.97 yalign 0.95


    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]


screen gallery_g():
    default gallery_g_list = [
            
            
            ["abdul_sexting_banu","{color=#ababab}Banu sends Abdul nude{/color}", im.Scale("images/banusextingabdulgallerygrey.jpg", 500, 300), im.Scale("images/banusextingabdulgallery.jpg", 500, 300), persistent.abdul_sexting_banu_unlocked],
            ["abdul_fucksbanu_nexttokamil","{color=#ababab}Abdul fucks Banu next to Kamil{/color}", im.Scale("images/abdulfucksbanunexttokamilgallerygrey.jpg", 500, 300), im.Scale("images/abdulfucksbanunexttokamilgallery.jpg", 500, 300), persistent.abdul_fucksbanu_nexttokamil_unlocked],
            ["abdulfarhadfuckbanu_bathroom","{color=#ababab}Abdul and Farhad bang Banu{/color}", im.Scale("images/abdulfarhadbangbanugallery_grey.jpg", 500, 300), im.Scale("images/abdulfarhadbangbanugallery.jpg", 500, 300), persistent.abdulfarhadfuckbanu_bathroom_unlocked]

        ]

    style_prefix "navigation" tag menu



    default total_scenes = len(gallery_g_list)
    default cg_page_a = 1
    default cg_page_a_max = max(int(total_scenes / 4) + (total_scenes % 4 > 0), 1)

    zorder 100







    hbox:

        xalign 0.5
        yalign 0.5

        grid 2 2:

            xalign 0.5
            yalign 0.5
            xspacing 20
            yspacing 20

            for i in range(((cg_page_a-1)*4),(cg_page_a*4)):
                if i < len(gallery_g_list):
                    vbox:
                        imagebutton:
                            action Replay(gallery_g_list[i][0], scope={ }, locked=not  gallery_g_list[i][4])
                            idle Transform(gallery_g_list[i][2], zoom=1)
                            hover gallery_g_list[i][3]



                        text str(gallery_g_list[i][1]):
                            color "#262626"
                            bold True
                            xalign 0.5
                else:
                    null

    hbox:
        xalign 0.5
        yalign 0.99


        textbutton _("Prev") action [SetLocalVariable("cg_page_a", If(cg_page_a>1, cg_page_a-1, cg_page_a_max))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]



        for page in range(1, cg_page_a_max+1):
            if page == cg_page_a:
                textbutton "{color=#ffa237}{b}[page]{/b}{/color}" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]
            else:
                textbutton "[page]" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]

        textbutton _("Next") action [SetLocalVariable("cg_page_a", If(cg_page_a<cg_page_a_max, cg_page_a+1, 1))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]


    textbutton _("Return") action [Return(), Hide("gallery_navigation")] xalign 0.97 yalign 0.95


    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]


screen gallery_h():
    tag menu
    default gallery_h_list = [
            
            
            ["ahmedsfucksbanu_sofa","{color=#ababab}Ahmed fucks Banu{/color}", im.Scale("images/ahmedfucksbanusofagallery_grey.jpg", 500, 300), im.Scale("images/ahmedfucksbanusofagallery.jpg", 500, 300), persistent.ahmedsfucksbanu_sofa_unlocked]

        ]

    style_prefix "navigation"



    default total_scenes = len(gallery_h_list)
    default cg_page_a = 1
    default cg_page_a_max = max(int(total_scenes / 4) + (total_scenes % 4 > 0), 1)

    zorder 100







    hbox:

        xalign 0.5
        yalign 0.5

        grid 2 2:

            xalign 0.5
            yalign 0.5
            xspacing 20
            yspacing 20

            for i in range(((cg_page_a-1)*4),(cg_page_a*4)):
                if i < len(gallery_h_list):
                    vbox:
                        imagebutton:
                            action Replay(gallery_h_list[i][0], scope={ }, locked=not  gallery_h_list[i][4])
                            idle Transform(gallery_h_list[i][2], zoom=1)
                            hover gallery_h_list[i][3]



                        text str(gallery_h_list[i][1]):
                            color "#262626"
                            bold True
                            xalign 0.5
                else:
                    null

    hbox:
        xalign 0.5
        yalign 0.99


        textbutton _("Prev") action [SetLocalVariable("cg_page_a", If(cg_page_a>1, cg_page_a-1, cg_page_a_max))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]



        for page in range(1, cg_page_a_max+1):
            if page == cg_page_a:
                textbutton "{color=#ffa237}{b}[page]{/b}{/color}" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]
            else:
                textbutton "[page]" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]

        textbutton _("Next") action [SetLocalVariable("cg_page_a", If(cg_page_a<cg_page_a_max, cg_page_a+1, 1))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]


    textbutton _("Return") action [Return(), Hide("gallery_navigation")] xalign 0.97 yalign 0.95


    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]


screen gallery_i():
    default gallery_i_list = [
            
            
            ["kamil_banu_sex","{color=#ababab}Kamil has sex with Banu{/color}", im.Scale("images/kamilhavesexwithbanugallerygrey.jpg", 500, 300), im.Scale("images/kamilhavesexwithbanugallery.jpg", 500, 300), persistent.kamil_banu_sex_unlocked], 
            ["banu_rides_kamil","{color=#ababab}Banu rides Kamil{/color}", im.Scale("images/banurideskamilgallerygrey.jpg", 500, 300), im.Scale("images/banurideskamilgallery.jpg", 500, 300), persistent.banu_rides_kamil_unlocked],
            ["kamil_banu_sex2","{color=#ababab}Kamil has sex with Banu in Malibu{/color}", im.Scale("images/kamilhassexwithbanumalibugallerygrey.jpg", 500, 300), im.Scale("images/kamilhassexwithbanumalibugallery.jpg", 500, 300), persistent.kamil_banu_sex2_unlocked],
            ["kamil_banu_sex3","{color=#ababab}Kamil fucks Banu on the chair{/color}", im.Scale("images/kamilfucksbanuchairgallerygrey.jpg", 500, 300), im.Scale("images/kamilfucksbanuchairgallery.jpg", 500, 300), persistent.kamil_banu_sex3_unlocked],
            ["banu_challanges_kammil","{color=#ababab}Banu challenge Kamil{/color}", im.Scale("images/banuchallangekamilgallerygrey.jpg", 500, 300), im.Scale("images/banuchallangekamilgallery.jpg", 500, 300), persistent.banu_challanges_kammil_unlocked],
            ["banuflashkamilrestroom","{color=#ababab}Kamil eats Banu in public{/color}", im.Scale("images/kamileatsbanuassgallerygrey.jpg", 500, 300), im.Scale("images/kamileatsbanuassgallery.jpg", 500, 300), persistent.banuflashkamilrestroom_unlocked],
            ["kamil_show_banu_who_is_man","{color=#ababab}Kamil dominates Banu{/color}", im.Scale("images/kamilshowbanuwhoismangallery_grey.jpg", 500, 300), im.Scale("images/kamilshowbanuwhoismangallery.jpg", 500, 300), persistent.kamil_show_banu_who_is_man_unlocked],
            ["kamil_dominate_banu_bedroom","{color=#ababab}Kamil dominates Banu in bed{/color}", im.Scale("images/kamildominatesbanubedgallery_grey.jpg", 500, 300), im.Scale("images/kamildominatesbanubedgallery.jpg", 500, 300), persistent.kamil_dominate_banu_bedroom_unlocked]
            

        ]

    style_prefix "navigation" tag menu



    default total_scenes = len(gallery_i_list)
    default cg_page_a = 1
    default cg_page_a_max = max(int(total_scenes / 4) + (total_scenes % 4 > 0), 1)

    zorder 100







    hbox:

        xalign 0.5
        yalign 0.5

        grid 2 2:

            xalign 0.5
            yalign 0.5
            xspacing 20
            yspacing 20

            for i in range(((cg_page_a-1)*4),(cg_page_a*4)):
                if i < len(gallery_i_list):
                    vbox:
                        imagebutton:
                            action Replay(gallery_i_list[i][0], scope={ }, locked=not  gallery_i_list[i][4])
                            idle Transform(gallery_i_list[i][2], zoom=1)
                            hover gallery_i_list[i][3]



                        text str(gallery_i_list[i][1]):
                            color "#262626"
                            bold True
                            xalign 0.5
                else:
                    null

    hbox:
        xalign 0.5
        yalign 0.99


        textbutton _("Prev") action [SetLocalVariable("cg_page_a", If(cg_page_a>1, cg_page_a-1, cg_page_a_max))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]



        for page in range(1, cg_page_a_max+1):
            if page == cg_page_a:
                textbutton "{color=#ffa237}{b}[page]{/b}{/color}" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]
            else:
                textbutton "[page]" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]

        textbutton _("Next") action [SetLocalVariable("cg_page_a", If(cg_page_a<cg_page_a_max, cg_page_a+1, 1))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]


    textbutton _("Return") action [Return(), Hide("gallery_navigation")] xalign 0.97 yalign 0.95


    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]


screen gallery_j():
    default gallery_j_list = [
            
            
            ["banuteaseinterninhishome","{color=#ababab}Banu teases Samir{/color}", im.Scale("images/samirgrabbanustitsgallerygrey.jpg", 500, 300), im.Scale("images/samirgrabbanustitsgallery.jpg", 500, 300), persistent.banu_tease_samir_unlocked],
            ["samirfucksbanu_bedroom","{color=#ababab}Samir fucks Banu{/color}", im.Scale("images/samirfucksbanugallery_grey.jpg", 500, 300), im.Scale("images/samirfucksbanugallery.jpg", 500, 300), persistent.samirfucksbanu_bedroom_unlocked]

        ]

    style_prefix "navigation" tag menu



    default total_scenes = len(gallery_j_list)
    default cg_page_a = 1
    default cg_page_a_max = max(int(total_scenes / 4) + (total_scenes % 4 > 0), 1)

    zorder 100







    hbox:

        xalign 0.5
        yalign 0.5

        grid 2 2:

            xalign 0.5
            yalign 0.5
            xspacing 20
            yspacing 20

            for i in range(((cg_page_a-1)*4),(cg_page_a*4)):
                if i < len(gallery_j_list):
                    vbox:
                        imagebutton:
                            action Replay(gallery_j_list[i][0], scope={ }, locked=not  gallery_j_list[i][4])
                            idle Transform(gallery_j_list[i][2], zoom=1)
                            hover gallery_j_list[i][3]



                        text str(gallery_j_list[i][1]):
                            color "#262626"
                            bold True
                            xalign 0.5
                else:
                    null

    hbox:
        xalign 0.5
        yalign 0.99


        textbutton _("Prev") action [SetLocalVariable("cg_page_a", If(cg_page_a>1, cg_page_a-1, cg_page_a_max))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]



        for page in range(1, cg_page_a_max+1):
            if page == cg_page_a:
                textbutton "{color=#ffa237}{b}[page]{/b}{/color}" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]
            else:
                textbutton "[page]" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]

        textbutton _("Next") action [SetLocalVariable("cg_page_a", If(cg_page_a<cg_page_a_max, cg_page_a+1, 1))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]


    textbutton _("Return") action [Return(), Hide("gallery_navigation")] xalign 0.97 yalign 0.95


    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]


screen gallery_k():
    default gallery_k_list = [
            
            
            ["murat_fucks_banu","{color=#ababab}Murat fucks drunk Banu{/color}", im.Scale("images/muratfucksbanudrunkgallerygrey.jpg", 500, 300), im.Scale("images/muratfucksbanudrunkgallery.jpg", 500, 300), persistent.murat_fucks_banu_unlocked],
            ["muratfucksbanuafterfunsexscenestaywithkamil","{color=#ababab}Murat fucks Banu's ass{/color}", im.Scale("images/muratfucksbanuintheassgallerygrey.jpg", 500, 300), im.Scale("images/muratfucksbanuintheassgallery.jpg", 500, 300), persistent.muratfucksbanuafterfunsexscenestaywithkamil_unlocked],
            ["murat_threesome","{color=#ababab}Banu has threesome{/color}", im.Scale("images/banuthreesomemuratgallery_grey.jpg", 500, 300), im.Scale("images/banuthreesomemuratgallery.jpg", 500, 300), persistent.murat_threesome_unlocked]

        ]

    style_prefix "navigation" tag menu



    default total_scenes = len(gallery_k_list)
    default cg_page_a = 1
    default cg_page_a_max = max(int(total_scenes / 4) + (total_scenes % 4 > 0), 1)

    zorder 100







    hbox:

        xalign 0.5
        yalign 0.5

        grid 2 2:

            xalign 0.5
            yalign 0.5
            xspacing 20
            yspacing 20

            for i in range(((cg_page_a-1)*4),(cg_page_a*4)):
                if i < len(gallery_k_list):
                    vbox:
                        imagebutton:
                            action Replay(gallery_k_list[i][0], scope={ }, locked=not  gallery_k_list[i][4])
                            idle Transform(gallery_k_list[i][2], zoom=1)
                            hover gallery_k_list[i][3]



                        text str(gallery_k_list[i][1]):
                            color "#262626"
                            bold True
                            xalign 0.5
                else:
                    null

    hbox:
        xalign 0.5
        yalign 0.99


        textbutton _("Prev") action [SetLocalVariable("cg_page_a", If(cg_page_a>1, cg_page_a-1, cg_page_a_max))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]



        for page in range(1, cg_page_a_max+1):
            if page == cg_page_a:
                textbutton "{color=#ffa237}{b}[page]{/b}{/color}" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]
            else:
                textbutton "[page]" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]

        textbutton _("Next") action [SetLocalVariable("cg_page_a", If(cg_page_a<cg_page_a_max, cg_page_a+1, 1))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]


    textbutton _("Return") action [Return(), Hide("gallery_navigation")] xalign 0.97 yalign 0.95


    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]


screen gallery_l():
    default gallery_l_list = [
            
            
            ["hicran_soaps_banu","{color=#ababab}Hicran soaps Banu's back{/color}", im.Scale("images/hicransoapsbanugallerygrey.jpg", 500, 300), im.Scale("images/hicransoapsbanugallery.jpg", 500, 300), persistent.hicran_soaps_banu_unlocked],
            ["hicran_sucks_dick","{color=#ababab}Hicran sucks Boss's dick{/color}", im.Scale("images/hicransucksbossgallerygrey.jpg", 500, 300), im.Scale("images/hicransucksbossgallery.jpg", 500, 300), persistent.hicran_sucks_dick_unlocked],
            ["banu_hiran_kiss","{color=#ababab}Banu and Hicran kiss{/color}", im.Scale("images/banukisshicrangallerygrey.jpg", 500, 300), im.Scale("images/banukisshicrangallery.jpg", 500, 300), persistent.banu_hiran_kiss_unlocked],
            ["banu_wet_dream","{color=#ababab}Banu dreams about Hicran{/color}", im.Scale("images/banudreamshicrangallerygrey.jpg", 500, 300), im.Scale("images/banudreamshicrangallery.jpg", 500, 300), persistent.banu_wet_dream_unlocked],
            ["hicran_vladimir_sex","{color=#ababab}Hicran threesome{/color} ", im.Scale("images/hicranthreesomegallerygrey.jpg", 500, 300), im.Scale("images/hicranthreesomegallery.jpg", 500, 300), persistent.hicran_vladimir_sex_unlocked]

        ]

    style_prefix "navigation" tag menu



    default total_scenes = len(gallery_l_list)
    default cg_page_a = 1
    default cg_page_a_max = max(int(total_scenes / 4) + (total_scenes % 4 > 0), 1)

    zorder 100







    hbox:

        xalign 0.5
        yalign 0.5

        grid 2 2:

            xalign 0.5
            yalign 0.5
            xspacing 20
            yspacing 20

            for i in range(((cg_page_a-1)*4),(cg_page_a*4)):
                if i < len(gallery_l_list):
                    vbox:
                        imagebutton:
                            action Replay(gallery_l_list[i][0], scope={ }, locked=not  gallery_l_list[i][4])
                            idle Transform(gallery_l_list[i][2], zoom=1)
                            hover gallery_l_list[i][3]



                        text str(gallery_l_list[i][1]):
                            color "#262626"
                            bold True
                            xalign 0.5
                else:
                    null

    hbox:
        xalign 0.5
        yalign 0.99


        textbutton _("Prev") action [SetLocalVariable("cg_page_a", If(cg_page_a>1, cg_page_a-1, cg_page_a_max))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]



        for page in range(1, cg_page_a_max+1):
            if page == cg_page_a:
                textbutton "{color=#ffa237}{b}[page]{/b}{/color}" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]
            else:
                textbutton "[page]" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]

        textbutton _("Next") action [SetLocalVariable("cg_page_a", If(cg_page_a<cg_page_a_max, cg_page_a+1, 1))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]


    textbutton _("Return") action [Return(), Hide("gallery_navigation")] xalign 0.97 yalign 0.95


    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
