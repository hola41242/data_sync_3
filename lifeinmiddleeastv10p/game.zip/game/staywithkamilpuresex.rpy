





label banuflashkamilrestroom:

    scene v16-188 with blinds
    play music "audio/sensualsex.mp3"
    "Inside the restroom, Banu and Kamil find themselves in a more private setting."
    b "So, Kamil, did you enjoy our little detour? It's not every day we get to have a clandestine rendezvous in the restroom."
    k "Banu, you certainly have a way of keeping things interesting. But let's remember to be mindful of our surroundings. We wouldn't want anyone to misunderstand our intentions."
    scene v16-189
    b "Oh, Kamil, where's your sense of adventure? We're just having a bit of harmless fun. Besides, it's exhilarating to have these secret moments, even if they're in the restroom."
    k " I understand your playful spirit, Banu, but I believe it's important to prioritize respect and decorum."
    b "You're so stupid, Kamil."
    scene v16-190 with fade
    b "Who would miss a chance like this?"
    b "If it was another man here, he would come and take me right here. And you're still waiting..."
    menu:
        "Kamil gets angry":
            $ renpy.block_rollback()
            $ kamilholdbanufrombehindrestroom = False
            stop music
            k "BANU! What the fuck are you doing...Come here!"
            scene v16-191
            k "That's it. I see that you're out of your mind today."
            b "I'm sorry. I just wanted to..."
            k "Just shut up now. We'll talk about this when we get home."
            b "...."
        "Kamil holds Banu from behind":



            $ renpy.block_rollback()
            $ kamilholdbanufrombehindrestroom = True
            k "Wow, look at that beauty you're hiding there."
            k "Well, I don't want to miss a chance like this."
            scene v16-192
            b "Ohhh...you know where to touch me, Kamil."
            b "Being here with you, even in a small space like this, feels incredibly intimate."
            b "You know, Kamil, there's something about being in a restroom that brings out the mischievous side of me."
            b "Please, come with me."
            scene v16-193
            k "Banu...no...this is too much."
            b "Shut up and come here. There's nobody here."
            scene v16-194 with fade
            "The restroom door discreetly opens, revealing the waiter standing there."
            "His eyes widen slightly as he realizes he has unintentionally become a silent observer to their dialogue."
            scene v16-195
            "Curiosity and surprise flash across the waiter's face as he finds himself unable to resist the temptation to listen to their banter."
            "He stands at a distance, maintaining a professional demeanor while discreetly eavesdropping on their conversation."
            scene v16-196
            b "Fuck...that's it. Eat it, Kamil. I know how long you've been waiting for this moment..."
            b "Uhhhhh...and you're very good at eating my pussy...don't stop."
            scene v16-197
            b "Ohhhh shit, I didn't know how dirty you are, Kamil."
            b "Now I know how much you love me....don't stop. Make me cum on your face right here...Ohhh..."
            k "Ummmm....Banu..."
            b "Shut the fuck up and eat it like an obedient husband."
            scene v16-198
            b "That's it....I'm right there..."
            b "Lick and swallow all my juices."
            b "I never knew your dark, dirty side of you."
            b "That's it. Fuck!"
            scene v16-199 with fade
            "Kamil was furious and horny. Banu's words were the motivation for him to pull his pants down quickly and take Banu right there."
            b "Yeah, that's it. I want you to fuck me right here right now!"
            "But while they were engaging with their little adventure..."
            scene v16-200 with hpunch
            stop music
            k "Ohhhhhhh! Banu...fuck..."
            menu:
                "Warn Kamil":
                    $ kamilwarnkamilbathroom = True
                    $ renpy.block_rollback()
                    b "Kamil!"
                    scene v16-204 with fade
                    b "Oh my god, that was so embarrassing."
                    k "I told you that was a stupid idea."
                    k "You never listened to me."
                    k "Your little adventue ends here."
                    b "Sure...you're going to blame me for everything."
                "Encourage him to continue":




                    $ kamilwarnkamilbathroom = False
                    $ renpy.block_rollback()
                    scene v16-201
                    b "Fuck me, Kamil. Don't dare to stop."
                    b "You're fucking me so good."
                    b "Keep fucking me like that....Ahhhhhh...yeah...I like it when you're so agressive like this."
                    scene v16-202
                    play sound "voices/moanfinish.mp3"
                    b "Ahhhhhhhhh....I'm cumming all over your big dick!"
                    b "Ohhh shit....don't stop..."
                    stop sound
                    "Banu offers a moaning face of her to the waiter, acknowledging the waiter's presence without revealing her awareness to Kamil."
                    "She continues to talk dirty to Kamil, deflecting any suspicion that something has caught her attention."
                    scene v16-203
                    "Banu, finding a certain amusement in the situation, decides to play along, secretly relishing the attention she is receiving from the waiter."
                    "With subtle yet deliberate movements, she adjusts her posture, ensuring that her gestures and expressions subtly draw the waiter's gaze without alerting Kamil."
                    "With the pleasure and enjoyment she received from the both men, she couldn't hold it anymore and a powerful orgasm comes over her."





    $ renpy.end_replay()
    $ persistent.banuflashkamilrestroom_unlocked = True


    jump banuflashkamilrestroom_continue







label banu_reject_kamil_anal_pureroute:

    scene v17-1 with dissolve
    b "FFFuck...Kamil you're doing a fantastic job here."
    b "I've always wanted to do it with you."
    k "Mmmm...do you like it here?"
    scene v17-2 with dissolve
    b "I love it! You're the best pussy licker in the world, Kamil. I hope you don't get offended."
    k "No...I don't."
    scene v17-3
    b "Yessss! Bury your head between my asscheeks."
    b "Wow...You're getting intense. I bet you enjoy it the same I enjoy. "
    k "Yess, my love...I love licking every inch of your body."
    scene v17-4
    b "Yess...do it faster. Ahhhhhh! I'm gonna cum on your face, Kamil."
    b "Do you want your wife to cum on your face? "
    k "Yess, I'd like your juices on my face..."
    b "Fuck!"
    scene v17-4 with hpunch
    play sound "voices/moanfinish.mp3"
    b "I'm cumming, Kamil! AAAAAHHHHHHHH!"
    b "You're an asshole, Kamil, you know that?"
    stop sound
    b "Lay down on the floor! I'll make you eat my whole pussy."
    scene v17-5 with fade
    b "I never knew you're so eager to eat pussy."
    k "Mmmm, I'd do anything to make my wife happy."
    b "Fuck yeah!"
    b "Eat your wife's dirty pussy then.."
    scene v17-6
    k "But what about returning the favor?"
    b "Shut the fuck up and keep cleaning."
    b "You're not allowed to speak until you lick it clean. "
    b "That's it. My legs hurt. Let's move it to the bed."
    scene v17-7 with fade
    b "Holy shit!"
    b "You're so good at stimulating my clitoris. Keep doing that."
    b "If you do a good job down there, maybe I can let you use it as it's designed to be used."
    k "Do you think I'd ask a permission?"
    b "You have to, you little slave! Because I'm the queen of this house, remember?"
    scene v17-8
    k "But seriously, why don't you suck my dick? It's only fair, right?"
    b "We talked about it, Kamil. I can't do that."
    k "But why? I don't understand that."
    b "I love you Kamil, but I'm a religious woman and I visit mosque and you know that."
    b "I can't get into a dirty stuff like that make myself dirty. I hope you understand that and I believe you'd like your wife to be pure forever, wouldn't you?"
    k "That's true. But I hope it doesn't stop me taking you hard from behind!"
    scene v17-9 with vpunch
    b "AHHH!"
    b "Wow! You're so energetic today."
    k "Seems like I got you so wet down there."
    scene v17-10
    k "Now it's time to fuck!"
    b "Uuuuhhh, I like it when you're rough like this."
    b "Come on keep fucking me like that. Show me what you got."
    scene v17-11 with hpunch
    "As Banu was in the middle of a building orgasm, Kamil suddenly pulled his cock out and brought it closer to Banu's asshole."
    k "There's something I want to try tonight."
    b "What!"
    k "I want to try something new, something we've never done before. I want to explore a different side of our intimacy, something more adventurous."
    b "What the fuck, Kamil!"
    scene v17-12
    k "I understand it might be a bit out of our comfort zone, but I think it could be exciting, and it might bring us closer together."
    b "GET OFF ME, ASSHOLE!"
    scene v17-13 with hpunch
    b "How could you do that to me?!"
    k "Banu, I'm really sorry for making you uncomfortable. I shouldn't have brought it up like that."
    b "Brought it up like that? You just tried to put it in my ass, Kamil."
    k "Banu, I'm really sorry to make you upset. Let's just forget about it?"
    b "How could I forget about it, Kamil. You just tried to fuck your wife's ass."
    scene v17-14 with fade
    k "Look, Banu. I'm really sorry."
    b "How could you even consider something like that? Do you think I'm that kind of woman?"
    k "No, Banu, that's not what I meant! I didn't mean to offend you. It's just... I thought we could try something new and exciting together, something that could deepen our connection."
    scene v17-15
    b "But why would you think that I would be okay with it? Have I ever given you the impression that I'm interested in that sort of thing?"
    k "No, you haven't, and I shouldn't have assumed. I'm sorry for misjudging what you might be comfortable with."
    b "It's not just about misjudging, Kamil. It's about respecting me and our relationship. I never expected you to try something like that without even discussing it with me first."
    k "Banu!"
    b "That's it. Just leave me alone for some time."
    k "..."






    $ renpy.end_replay()
    $ persistent.banu_reject_kamil_anal_corruptedroute_unlocked = True

    jump banu_reject_kamil_anal_pureroute_continue
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
