
label day2:


    show black
    centered "{size=+150}DAY 2{/size}" with dissolve
    scene black with dissolve
    with Pause(1)
    scene day2-15 with fade
    "{i} {color=#526168}It was an ordinary day.{/color} "
    if spykamil == True:
        " {i} {color=#526168}Banu woke up and stayed in bed for a while thinking about yesterday.{/color}"
        b "{i} {color=#526168}Kamil saw me when I was spying on him yesterday. {/color}"
        b "{i} {color=#526168}I feel very bad just thinking about it.{/color} "
        b "{i} {color=#526168}I shouldn't have done that. It is so embarrassing. {/color}"
        b "{i} {color=#526168}I need to dress quickly and leave as soon as possible.{/color} "
    else:

        " {i} {color=#526168}Banu woke up and stayed in bed for a while thinking about yesterday.{/color}"
        b "{i} {color=#526168}What I've done is not an acceptable behavior for a woman like me. I won't be able to forgive myself for that.{/color} "
        b "{i} {color=#526168}I didn't know Turan could've done something like that. {/color} "

        b "{i} {color=#526168}I need to dress quickly and leave as soon as possible.{/color} "



    scene day2-16 with blinds
    play music3 "sfx/office.mp3"
    b "{i} {color=#526168}Today at work was very boring. {/color}"
    b "{i} {color=#526168}I'm definitely not feeling well. I should go and wash my face.{/color} "
    scene day2-17 with wiperight
    stop music3


    b "{i} {color=#526168}I’m so bored today, but it will be great to visit Nesrin later for a little chit-chat.{/color}"
    b "{i} {color=#526168}With her, I think I found the right person for sharing my unhappiness and problems. She’s always there for me, both in my bad and good days.{/color} "
    b "{i} {color=#526168}Her husband, Polad, has also helped me a lot since Alper's death. {/color}"


    b "{i} {color=#526168}They’re so close to me and I feel very comfortable around them...{/color} "



    scene black
    "{i} {color=#526168}Banu had some time to visit Nesrin after the tiring and boring work day. {/color}"
    scene day2-18 with wiperight
    n "Yeah, long time no see, Banu."


    b "Stop it Nesrin, it’s been just two days. Besides, you know I’m a busy woman. I have problems at work, and my relationship with my stepson is tense, as you know."
    n "I know Banu. No need to explain, I'm just teasing you."
    scene day2-19
    b "You're my bestie, you know that?"
    n "That face tells me that you have some interesting news for me. Let's talk about that."
    scene day2-20
    b "Okay I'll tell you everything."
    scene day2-21
    if spykamil == True:
        n "Haha, you naughty girl, I can't believe you spied on Kamil in the shower."
        b "Nesrin, please, keep it quiet. Polad can hear us."
        n "Don't worry. He’s in the shower."
        n "Be careful not to spy on HIM... haha."
        b "Oh hush, Nesrin. I’m so embarrassed."


        b "I don't really know why I did that. I think it should be the natural thing between husband and wife, but we are..."
        n "Banu, stop being silly. Just forget about Alper. Life goes on. You have everything that any girl could ask for, and Kamil is an ideal husband who loves you so much."


        b "I know..."
        n "Look, we are women and we do have needs, so don't go against the rules of nature."
        scene day2-22
        b "So what do you think? Should I talk to him about this? Maybe this would be the start of giving him a real chance at winning my total love and affection?"


        scene day2-23
        n "Of course. Talk to him as soon as you can."
        scene day2-22
        b "Okay, I'll do as you say... you always give me the best advice."
        scene day2-24
        n "Now tell me. How big is his dick?"
        scene day2-21
        b "Nesrin! Can you just shut your mouth? You can be disgusting sometimes. And Polad could have walked in at that moment."


        n "What can I say? I have dirty thoughts when it comes to men."
    else:

        n "So..."
        b "Do you remember I told you about Turan, my co-worker?"
        n "Well.."
        b "He’s also my close friend, but he wants to be more than a friend, and it makes me really uncomfortable."
        n "Do you want him?"
        scene day2-22
        b "No! Of course not. We’re just friends, and he's really nice to me."
        scene day2-23
        n "Banu, look at my eyes and tell me the truth. I know you can't lie to me."
        scene day2-22
        b "I am telling the truth."
        scene day2-23
        n "Can you explain to me why you went to a man's apartment at night knowing that he lives alone?"
        scene day2-21
        b "Are you implying that I wanted to sleep with him?"
        n "Exactly!"



        b "No way. I wouldn't do that. Yeah, I can agree that he’s a handsome and successful man, but you know me. I’m not that type of woman. Besides, I’m married. How could you think that way?"


        n "But you didn't answer my question. Why did you go there?"
        b "..."

        n "Fine, if you're not going to reply, tell me what happened, did you fuck?"


        b "Of course not! He asked me to stay longer, and I knew his intentions were not good, so I left immediately."


        b "{i} {color=#526168}Of course, I left out some of the details...{/color} "

        b "{i} {color=#526168}I can’t tell ANYONE that Turan kissed me and saw my breasts... not even my best friend. It’s too shameful. {/color}"

        n "And that's it?"
        b "Yes..."
        n "Maybe he's serious about you. Have you thought about that?"



        b "Nesrin, I have a husband and I’m very satisfied with my life."
        n "Hm. Okay, but I think there's something more here, Banu."



    if ruslanargument == True:
        scene day2-23
        n "So, what about your stepson? What’s his problem with you?"
        scene day2-22

        b "First off, he’s incredibly disrespectful when he speaks to me. Secondly, he bullies my daughter, his own dear stepsister."
        b "And he… how do I say this…"

        b "He eats me with his eyes, as if he wants me."


        b "It happened about a week ago. He saw me naked in the shower."
        b "I didn’t think anyone was home, and the door was unlocked. He snuck into the bathroom, the little devil. I tried to cover up, but he saw enough."
        b "Instead of apologizing and covering his eyes, he tried to get a better look!"


        b "I think this behavior is normal for his age, but obviously it's not okay."
        scene day2-23
        n "Well Banu, I can’t say I blame him. Look at your body! He’s a horny young man, after all."
        n "But he shouldn’t be disrespecting Leyla and you."
        n "You should talk with Kamil about it. I’m sure that will solve your problems."

        scene day2-22
        b "I don't want to hurt Ruslan by getting his dad involved. This is something I need to work out on my own. Everything will settle as time passes..."
        n "I really don't think so, but I guess we'll see."


    scene day2-25
    p "I hope I’m not interrupting you both."



    scene day2-27
    b "Wow, the man of the house finally arrived. How are you, Polad?"
    scene day2-26
    p "Thanks, Banu, I’m doing fine. You though, I can't believe you're still getting prettier every day."



    n "He’s always full of compliments."
    p "Yes, I am."
    p "What about you, Banu, how are you doing?"
    scene day2-27
    b "As usual Polad. Home-work routine. I want to know how you're doing working at the pub. It must be an adventurous job."
    scene day2-28
    p "You know, each job has pros and cons, but I do believe it's pretty adventurous. You can see a lot of different people there, and they love telling me their secrets."
    p "But every time I invite you for free drinks, you don't accept my offer."
    b "You know me Polad. First, I don't drink alcohol. Second, I don't go to such places."
    n "Come on, Banu. It's just a small pub. There’s nothing dangerous about it."


    b "Well, maybe I’ll go with you some time, but I'm not making any promises."

    scene day2-26
    p "You are welcome anytime."
    p "By the way, Nesrin told me that you’re having issues getting along with your stepson, especially now that he's grown up. Why is that?"


    scene day2-29
    b "He’s a real pain in the neck..."
    jump ruslan_whore_scene



label ruslan_whore_scene:
    scene day2-1 with irisin
    play music "audio/chill.mp3"
    r "Yes, I’m a real pain in the neck."
    s "It seems that your tongue is agile when it comes to talking, but I’d prefer it on another place."


    scene day2-2
    s "Do you like what you see?"
    r "I love every piece of you."
    s "Now tell me what you want me to do?"
    r "Better take that outfit off for starters... then we'll talk."


    s "You’re so eager. I can't say no to you."

    r "Do you have a choice?"
    s "There’s always a choice, and I'll tell you that you don't know how to properly talk to a lady."

    scene day2-3
    r "Damn girl, you’re fucking hot. I’m dying to stick my hard cock deep inside you."


    s "Be patient, we’re not in a hurry."
    scene day2-4
    s "What’s the name of your stepmom, I forgot?"
    r "Banu..."
    s "So you want to fuck her?"
    r "I WILL fuck her eventually, the same way I'm going to destroy your pussy right now."

    scene day2-5

    s "What are you waiting for?"
    s "Come and get it."
    r "My dick is aching for your lips. Your face is fucking gorgeous."
    r "I wonder how much better you'll look with my cum on your face."
    s "Do you really want to cum on my face?"
    r "Stop asking questions and stand up."
    scene day2-6
    s "Look at how fucking hard you are, Ruslan."
    r "Stop talking and get on your knees whore."
    scene day2-7
    stop music
    play music2 "voices/bj.mp3"
    r "You look like a good slut when you put your hands back and suck my cock like that."
    r "Yeah, suck it you cheap whore."
    scene day2-8


    r "You see… you can't hold your hands back."
    r "You can't stop touching yourself while sucking my cock."
    s "Yeah, I want to feel like a cheap whore. Fuck me please, I can't stand it anymore. Fuck me!"


    r "Stand up and bend over, slut."
    r "You ready to feel my cock destroy you from the inside?"
    scene day2-9
    stop music2
    play music2 "voices/moaning.mp3"
    s "Fuck, you're so big.. ahhh..it is stretching my pussy so good..ohh"
    r "Yeah, take it slut. Take it..."
    scene day2-10
    s "Slow down a little bit. You are destroying me..."
    s "OHH shit, I am cumming already...ohh fuck it felt soo good..ohh"
    s "My legs are shaking so much, I have to lay down, Ruslan."
    scene day2-11
    r "You see, you couldn't stop cumming on my cock."
    s "You are soo good, Ruslan. Please, do it again. I want it again..Fuck me."
    scene day2-12
    r "I'm going to stretch you out more than anyone's ever done."
    s "Please, give it to me. Pleasee"
    show run_animation
    r "You want it like this?"
    s "Yeah, like that. The tip of your cock just touches my spots right."
    r "You want an orgasm again?"
    s "Yeah, do it faster, please..."
    show run_animationfast
    s "Yeah, ohh...like that. Keep going..keep fucking me like that.."
    r "You want it harder? Tell me how bad you want it."
    s "Yes, I want it so bad. I want your cock so bad. Now fuck me harder like a real man fucks..ohh..do it..ahhh.."
    r "Like that, bitch?"
    s "Yeah, ohhh yes destroy my pussy..ahhh"
    r "Oh yes I'm cumming ..."
    stop music2
    menu:
        "Cum on her face":
            $ renpy.block_rollback()
            scene day2-14
            r "Ohh shit, yeah like that. Take it all on your pretty face you little bitch.."
            s "Your fresh cum tastes so good."
            r "It is all for you..."
            r "{i} {color=#526168}Next, it will be your turn, Banu..Be ready...{/color}"
        "Cum on her ass":

            $ renpy.block_rollback()
            scene day2-13
            s "Fuck Ruslan, your sperm is so hot on my ass.."
            r "You look like a destroyed doll right now"
            r "I will take your photo and add it to my collection."
            s "Do what you want with me, baby."
            r "{i} {color=#526168}Next, it will be your turn, Banu..Be ready...{/color}"



    stop music
    $ renpy.end_replay()
    $ persistent.ruslan_whore_scene_unlocked_1 = True
    jump ruslan_whore_continue


label ruslan_whore_continue:

    scene day2-30 with fade

    p "I wanna tell you something before you leave."
    b "Yeah, what is it?"
    scene day2-31
    p "I want you to know that you’re very important to us, especially to me, Banu."
    p "You know that Alper was like a brother to me, and I vowed to take care of you after his death."


    p "I have to make sure that everything’s okay with you. "

    p "If your husband and his son are treating you badly, just tell me and leave it to me."


    p "They have no right to judge you for not loving Kamil like you did Alper. Do you understand me, Banu? You can tell me anything! I’m very serious about this."

    scene day2-32
    b "Thank you so much for everything, Polad."
    b "But I’ll deal with all that myself. It’ll be fine, I just needed some advice from Nesrin."


    b "You’ve done so much for me already, and I owe you a lifetime of gratitude. I don't know how I can ever thank you properly."

    p "No need to thank me..."
    scene day2-33
    "{i} {color=#526168}Without a single word, she hugged him for some time... {/color} "
    "{color=#526168}...{/color}"
    scene day2-34
    p "Do you want me to take you home in my car? It’s already dark outside."

    b "Don't worry, Polad. It's not so far from here. I'll just walk home."
    p "Well, see you next time."

    b "See you."


    scene day2-40 with dissolve
    guy1 "Hey, look at that chick."
    guy2 "Damn, you're right, man."
    scene day2-41
    guy1 "What a tight ass. I would give anything to fuck this bitch right now..."
    scene day2-42
    b "{i} {color=#526168}Listen to these bastards. {/color}"

    b "{i} {color=#526168}What gives them the right to talk about me that way?{/color} "
    b "{i} {color=#526168}Someone needs to teach them a lesson! {/color}"
    play music "audio/tension.mp3"

    menu:
        "Banu decides to confront them":
            $ lust += 1
            $ domme += 1
            $ streetguys = True

            $ renpy.block_rollback()
            $ banubad += 1
            scene day2-42
            b "{i} {color=#526168}It probably isn't a good idea to confront them, but I don't want to let this chance slip.{/color} "
            scene day2-44
            "..."
            scene day2-45
            b "So you want to fuck me?"
            guy1 "I..."
            b "Do it!"
            guy1 "What??"
            b "I said, do it."
            b "Yeah, fuck me bad boy. What are you waiting for? Show me your dick. I wanna see it."
            play sound "voices/slap.mp3"
            scene day2-46
            "..."
            scene day2-47
            b "So tell me. What's your next move?"
            b "The police station is not far from here. We can go down there."
            b "Not so tough now, are you?"
            scene day2-48



            b "And you, boy. It’s time for you to go home. I bet your parents are worried about you."
            b "You wouldn’t want me to go talk to them, would you?"
            b "You need to find new friends."

            b "And both of you better learn to be respectful towards women!"
            stop music
            scene day2-49
            b "{i} {color=#526168}It serves them right. They’ll be careful next time...{/color} "



            scene day2-50
            guy1 "{i} {color=#526168}You fucking bitch. You won’t be able to run away next time...{/color}"
            guy1 "{i} {color=#526168}You’ll have to answer for this...{/color}"
        "Banu is in a hurry and it isn't a good idea to confront them":



            stop music

            $ streetguys = False
            $ renpy.block_rollback()
            scene day2-42
            b "{i} {color=#526168}I would like to teach them a lesson now, but I must hurry, otherwise I will be in big trouble.{/color} "
            scene day2-43
            b "{i} {color=#526168}I think it’s better to ignore them and not risk it.{/color} "
            "..."




    scene day2-60 with Fade(0.5, 0.5, 3 )

    k "Banu, you're finally home! We were so worried. Don't come home so late without telling me where you're going first. I don't want to question you... but I was worried."
    scene day2-61


    b "You’re absolutely right, Kamil. I'm sorry, but you know my friend Nesrin, she’s a chatterbox."


    b "Don't worry, it won't happen again. I'll let you know next time."
    scene day2-62
    k "You're an ideal wife, you know that right? Thank you for everything, Banu!"
    b "And you’re the nicest man in the world. You’ve always been so nice and understanding."

    b "I hope..."
    b "I hope the relationship between us will turn into a feeling that will connect us forever."
    k "Do you think it will happen one day? Do you think you’ll be able to love me? I mean, I know that you’ve not forgotten your deceased husband yet. But I thought by now…"

    menu:
        "She avoids talking about it":
            $ renpy.block_rollback()
            scene day2-62
            b "I know, Kamil. Things are a little bit complicated..."
            b "Let's talk about it another time. I’m going to take a shower now."
            scene day2-64
            b "Good night."
            k "Good night, Banu..."
            stop music
        "She shows him how much he means to her":



            $ banu_kamil += 1
            $ renpy.block_rollback()
            scene day2-63
            b "You're the only man in my life now."
            b "I think we should forget the past and start a new life."
            k "I agree, and I love you so much, Banu."


            "{i} {color=#526168}Banu didn't say anything but kissed Kamil on his cheek instead.{/color} "
            b "I’m going to take a shower now."
            scene day2-64
            b "Good night."
            k "Good night, Banu..."




    scene day2-70 with wipeup
    play music3 "sfx/shower.mp3"

    b "{i} {color=#526168}The water is scalding hot, but it feels good. {/color}"
    b "{i} {color=#526168}I’m so tense from these recent unwanted events.{/color} "


    b "{i} {color=#526168}The hot water on my skin is relaxing my muscles.{/color}"
    scene day2-71
    b "{i} {color=#526168}The shower is the only place where I can relax and be alone with my thoughts. {/color}"


    b "{i} {color=#526168}But, what if my thoughts are dangerous? {/color}"
    scene day2-72
    b "{i} {color=#526168}My body is so alive, but what if it were being touched by a man… his hands on my body, warm breath on my neck, a kiss on my lips... {/color} "


    b "{i} {color=#526168}The deep love and respect towards my deceased husband has always prevented me from having my needs met by a man, even by Kamil.{/color} "

    b "{i} {color=#526168}I’ve been able to manage my life without having those needs met...{/color}"

    b "{i} {color=#526168}…by using my fingers during my secret times in the shower. {/color}"


    scene day2-73
    b "{i} {color=#526168}I love being alone sometimes, especially after a long day, so I can quench my needs.{/color}"

    if ruslanargument == True:
        scene day2-74
        b "{i} {color=#526168}Ruslan is very aggressive with me. What is the reason behind that?{/color} "
        b "{i} {color=#526168}Does he like me as a woman? {/color}"
        b "{i} {color=#526168}Does he really want to fuck me, his stepmom?{/color} "
        scene day1-14black with pixellate
        b "{i} {color=#526168}He's an adult man now. I forget about that sometimes. {/color}"


        b "{i} {color=#526168}He’s tall and has rock-hard muscles...{/color} "

        b "{i} {color=#526168}If he attacks me when we’re home alone, I can't do anything to stop him.{/color} "

        b "{i} {color=#526168}I’m so powerless against his strength. Would he try to fuck me? {/color}"

        scene day2-75
        b "{i} {color=#526168}Ohh, I want to touch myself now. It feels so good...{/color} "
        b "{i} {color=#526168}I need more... {/color}"
    if turandate == True:
        scene day2-75
        b "{i} {color=#526168}I can't forget that night with Turan...{/color} "
        b "{i} {color=#526168}Maybe, he was right. I needed a man's care and that is why I agreed to go his home.{/color} "
        scene day1-40black with pixellate
        b "{i} {color=#526168}I was so powerless that time... {/color}"
        scene day1-41black
        b "{i} {color=#526168}His powerful hands unbuttoned my shirt revealing my breasts while he was kissing me on the lips. {/color}"
        b "{i} {color=#526168}What if I didn't manage to run away? What if he fucked me right there, holding my hands so I couldn't move? {/color}"
        scene day2-76
        b "{i} {color=#526168}Oh, I’m so horny right now, I can’t stop myself.{/color} "
        b "{i} ... "
        scene day2-77
        b "{i} {color=#526168}It feels so good... I’m going to cum any moment...{/color} "

    if spykamil == True:
        scene day2-77
        b "{i} {color=#526168}I am unfair with Kamil. {/color}"
        scene day1-62black with pixellate
        b "{i} {color=#526168}His body is perfect and his cock is so fat.{/color} "
        b "{i} {color=#526168}I can imagine it thrusting inside my pussy... {/color}"
        b "{i} {color=#526168}I could've just gone and succumbbed to him and told him to fuck me right there in the shower... {/color} "
        scene day2-78
        b "{i} {color=#526168}Ohh shit, I am going to cum soon... {/color}"
    scene day2-33black with pixellate
    b "{i} {color=#526168}I can't forget Polad's warm breath around my neck. {/color}"
    b "{i} {color=#526168}His strong body and firm muscles... {/color}"
    scene day2-78
    b "{i} {color=#526168}Ahhh, shit... {/color}"
    scene day2-79
    b "{i} {color=#526168}Ohhhhh, I'm cummingggg...ahhhh yess...{/color} "
    b "{i} ohhh.... "
    scene day2-80 with dissolve
    stop music3
    b "{i} {color=#526168}I'm crazy. That was insane...{/color} "
    b "{i} {color=#526168}But it felt soo good, I clearly needed it..{/color} "

    scene day2-81
    b "{i} {color=#526168}Anyway, it's late. I should go to bed now... {/color} "
    b "{i} ... "



    jump day3
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
