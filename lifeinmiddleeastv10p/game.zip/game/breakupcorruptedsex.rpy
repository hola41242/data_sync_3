



label hicran_vladimir_sex:
    scene v15-319 with pushleft
    play music "audio/hardsex.mp3"
    hic "Are you sure you want to do this here?"
    v "Don't worry. Nobody will hear your screaming."
    scene v15-320
    f "You're such a slut. "
    f "You've just betrayed a friend you've known for a long time."
    v "Now get down on your knees."
    scene v15-321
    v "Now tell me that you're a cocksucking whore."
    hic "I'm a cocksucking whore..."

    scene v15-322
    f "Beg us to fuck your holes, bitch."
    hic "Please, fuck my holes, please, punish my holes..."
    f "That's good enough. Now open your mouth and suck my dick."
    scene v15-323
    f "Good...you're a good obedient slut."
    v "Now it's time to punish your mouth properly."
    scene v15-324
    hic "Ummmmm...."
    v "Choke on my dick...that's it.."
    f "Let's not make her pussy wait longer."

    scene v15-325
    hic "Please, fuck me quick. My pussy is aching for your dicks..."
    f "You're such a slut."

    scene v15-326
    v "You want this huh? "
    v "Take it then..."
    hic "Ahhhhhh...."
    show hicrangettingfuckedanimation
    hic "Ahhhhhh...."
    hic "Yeah...Vlad push it deeper like that..."
    hic "Ohhh shit, shit shit..."
    hic "You're destroying me..."
    hic "If you keep this I'm going to cummm so bad..."
    hic "Ohhh yesss...fuck me harder..."
    scene v15-329
    v "Now I'm going to fuck your mouth, slut."
    v "Open your mouth..."
    hic "Ohh yesss..."

    scene v15-330
    f "Damn, she squeezes my dick so good with her ass."
    hic "Ummmm..."

    scene v15-331
    "Vladimir and Faiq fucked Hicran for hours gaping her pussy and ass."

    scene v15-332
    hic "Oh my god....You're so big, Vlad..."
    hic "Please, be gentle with my asshole."

    scene v15-333
    v "Take it slut, I'm gonna destroy your asshole."
    f "Keep sucking that dick, whore, don't stop."


    scene v15-334
    hic "Oh my god, he's destroying me..."
    hic "Ahhhhhhh..."
    scene v15-335
    hic "Ohh shit, I can't concentrate..."
    hic "I'm gonna cum on your big fat dick.."

    scene v15-336 with hpunch
    v "Damn...she's good..."
    v "Her ass is amazing..."
    v "You should try this, Faiq."
    scene v15-337
    v "Look at that gaping ass.."
    v "It's taken the shape of my dick."
    f "I told you to keep sucking, bitch, don't you hear me?"
    f "Stand up now!"
    scene v15-338
    hic "What are you doing?"
    f "Come here, slut."
    v "Go easy on her, man."
    hic "Hey, you're hurting me."

    scene v15-339
    f "Come here...I'll show you what you've done."
    hic "What are you doing? Just let me go."

    scene v15-340 with vpunch
    hic "Heyyy...stop this bullshit..."
    f "Just enjoy the moment..."


    scene v15-341
    f "Don't you want to look at his face?"
    hic "Come on, already, Faiq. I'm scared of this."
    f "Now you'll enjoy it even more."
    scene v15-342 with vpunch
    hic "Ahhhh...."
    f "I knew you'd like it."

    scene v15-343
    f "Look at his face while I fuck your ass."
    f "Do you enjoy getting fucked while moaning to Kenan's ear?"

    scene v15-344
    hic "Ahhh...you're a terrible man."
    f "You know me."
    f "Ohh shit, I'll cum in your ass."
    stop music
    scene v15-345
    f "Shit...that was interesting."
    f "Did you enjoy that."
    hic "Fuck you!"
    $ renpy.end_replay()
    $ persistent.hicran_vladimir_sex_unlocked = True
    jump hicran_vladimir_sex_continue
















label muratfucksbanuafterfunsexscenestaywithkamil_breakup:



    scene v16-132

    b "Murat, I can't believe I'm agreeing to this, but okay. Just 5 minutes, and then I need to leave. No longer than that, okay?"

    mur "Deal! I promise you won't regret it. Let's go!"

    scene black with dissolve

    "..."

    scene v16-142 with dissolve
    play music "audio/sensualsex.mp3"

    b "Wait...you're such a liar, Murat."

    b "....mmmmp.."

    mur "Your lips taste so good. I can kiss you all day."

    b "You're going to choke me, maniac."

    b "Is it your fisrt time kissing?"

    mur "You're driving me crazy, Banu. I can't control myself with you."

    scene v16-143 with fade

    b "Mmmp...oh god...stop touching me there...ohh."

    mur "You like this, don't you?"

    b "We didn't agree on taking the clothes off, did we?"

    scene v16-144 with fade

    mur "Shhhh...just enjoy the moment. "

    b "Your dick....it's touching me..."

    mur "Damn Banu, you're kissing me so passionately. You must be craving this all the time you've been with me."

    scene v16-145

    b "Ahhh...you know what I need..."

    b "Right there...ahhhh.."

    b "Ummmmm...You got me so wet you tricky boy."

    scene v16-146

    "Murat was bending Banu backwards slightly and she was grabbing his neck not to fall off."

    "Using the opportunity, Murat started rubbing Banu's pussy furiously and talking dirty to her making her crazy."

    b "Ahhhhh...stop it...please, ahhh."

    mur "I'll make you feel so good that your husband never done that to you."

    mur "I'm going to make you feel like a real woman today. You'll scream and beg but I won't stop..."

    scene v16-147 with fade

    "After minutes Murat grabbed Banu taking her pants and bra off and sat on the sofa holding her on top of him. "

    "While invading her mouth, Murat run his hands all over Banu's body, caressing her thighs, belly and breasts. "

    "At this point, Banu could't help but reached her pussy with her hand stimulating her left out clit."

    scene v16-148

    b "Shit, I can't bear it anymore...Murat, please..."

    mur "Tell me. What you want me to do?"

    b "Please, make me feel good."

    mur "You want my cock, don't you?"

    b "My pussy is so wet now. I'm going to cum from your touches."

    b "Please, take my pussy. Make me yours!"

    scene v16-149 with hpunch

    b "Ahhh...yeah like that.."

    mur "You're such a lewd slutty wife, aren't you?"

    b "Yesss, I'm a despicable, bad wife who needs a good punishment."

    b "Call me whatever you want. I deserve that."

    mur "You're a bad bitch enjoying my fingers deep inside of your married cunt. "

    b "Ohhh...I can't take it anymore...I'm going to cummm....."

    scene v16-150

    mur "Look how slutty you are. You're cumming from a young man at your children's age fingering your pussy."

    b "Please, stop it..."

    b "Damn, you're so good at this. Fuck..."

    b "I've never let my husband touch me like that."

    mur "Go on, cum for me. I'm going to tease all of your slutty holes."

    mur "I'm going to tease the shit out of you. You'll beg me to fuck all of your holes."

    mur "Have you ever got your asshole fucked?"

    scene v16-151 with vpunch

    b "No! Don't touch me there. I warn you!"

    mur "What? You're rejecting me?"

    b "Shit, I'm serious, Murat. I've never let a man touch me there."

    "Banu squeezed her legs so hard to prevent Murat teasing her asshole with his middle finger. "

    scene v16-152 with fade

    b "Ahhh..."

    b "You're crazy...what are you doing?"

    mur "You see? I'm full of surprises."

    scene v16-153

    mur "Mmmm...it's so delicious. Do you like it?"

    b "Ohhh shit...stop it...it's so dirty..."

    b "Oh god...you're hitting my spot."

    b "You're eating it like your favorite breakfast...ufff.."

    mur "Mmmm..this is my favorite meal of the day."

    b "Oh my God...if you keep doing that....I won't be able to stop cumming."

    mur "Don't hold it. Cum all over my mouth. "

    b "Shit, you're so good with your tongue."

    mur "Are you ready for the main course?"

    scene v16-154 with fade

    "Murat suddenly raised Banu's legs and put his dick on top of her pussy grinding it back and forth."

    mur "You want this, don't you?"

    b "Stop teasing me, please..."

    mur "Shut up!"

    mur "Tell me how you want it."

    scene v16-155

    b "I want it inside of me..."

    "Murat continued teasing Banu's wet pussy with his fully erect curvy dick making her crazy."

    mur "I want you to ask it properly."

    b "Oh god...you're making me crazy..."

    b "Put that fucking dick inside of me!"

    mur "Tell me how bad you want it."

    b "I want it so bad...please, my pussy aches for your big curvy dick."

    b "Put it inside of my married unsatisfied pussy."

    b "Fuck the shit out of me..."

    scene v16-156 with hpunch
    stop music

    b "Ahhh..."

    mur "That's it. I'm not gonna make you suffer any longer."

    show muratfuckbanuafterfunanimation
    play music "voices/moaning.mp3"

    b "Fuck!...This feels so good..."

    mur "I know what you want, baby."

    mur "My dick fits so good inside of your wet pussy."

    mur "Your pussy is just made for my cock."



    show muratfuckbanuafterfunanimationangle

    b "Ohh fuck me...keep fucking me like that."

    mur "Your husband is weak man probably. Leaving a pussy unsatisfied like this huh?"

    b "Please, ahhh, stop talking about him..."

    b "Keep fucking me like that, ahhh.."


    show muratfuckbanuafterfunanimationfast

    b "Ohhhh shit..."

    b "It's hitting me so bad..."

    mur "Fuck...your pussy squeezes my cock so hard."



    show muratfuckbanuafterfunanimationanglefast

    b "Oh my god, keep fucking me like that...ahhh..."

    b "Your cock reaches my stomach...ohhh shit.."

    mur "I'm going to destroy belly..."

    mur "I can't believe you gave a birth from this pussy. It's so tight."
    stop music
    play sound "voices/moanfinish.mp3"
    b "Fuck....I'm cumming....shit...."

    scene v16-157 with hpunch
    stop sound
    b "Shit...that was so intense."

    mur "Your face tells it all."

    b "You're the devil."

    mur "I'm glad you liked that...but it's not over yet."

    scene v16-158

    mur "I have an idea. How about we try something new together?"

    b "Wait..what?"

    mur "It's something you've never done before, and I think it could be a fun and memorable experience."

    b "No!...no way..."

    scene v16-159

    mur "But why not trying?"

    b "I'm sorry, but I can't do that. It's just not something I'm comfortable with or ready for."

    mur "Let's give it a try, just this once. I'm sure you'll love it."

    scene v16-160

    b "No I can't do that. I'm not comfortable with this you know."

    mur "How do you know if you haven't tried it?"

    b "Please, don't push me. I'm afraid of that."

    scene v16-161

    b "Heyyyy...stop it!"

    mur "I promise you, it won't be painful."

    mur "I'll make sure you're comfortable and at ease throughout the experience."

    scene v16-162

    b "I just said stop it! What are you doing?"

    b "I can't do this!"

    mur "Shhhh...your ass will love it."

    scene v16-163

    b "Ahhhhhhhh...Ay mama....it hurts...stop it!"

    mur "Shhhh, I'll lubricate it good that you'll only feel the pleasure."

    scene v16-164

    b "Ahhhhhh..."

    mur "That's it..."

    b "It hurts so bad, please pull it out! Ahhhhh.."

    mur "Don't worry. Your ass will get used to it."

    show muratfucksbanuanalsideanimation
    play music "voices/moaning.mp3"

    b "Shit...Ahhhh..."

    b "It destroyes my ass."

    mur "You seem to like it."



    b "Ohh yeah, don't stop...keep fucking my dirty asshole..."

    mur "Your asshole is so tight. It squeezes my dick like hell."

    mur "But I'll stretch it a bit more."

    show muratfucksbanuanalsideanimationfast

    b "Ahhhhhh....yesss...pound my ass like that..."

    b "Shit, I can't hold it. I'm going to pee."





    mur "Your asshole belonges to me now. "

    mur "I'll stretch it whenever I want."

    stop music

    scene v16-165 with fade

    "Murat fucked Banu for hours in the ass hitting deep inside her with his long curvy dick."

    "Banu's initial pain was replaced by a mixture of pleasure and pain afterwards giving her the best pleasure in her life. "

    scene v16-166

    "At this point, she couldn't stop her eyes rolling back and moaning like a whore while accepting full length of Murat's swollen cock from her back door. "

    b "Ahhhh, it's hitting me right there..."

    scene v16-167

    b "Keep fucking me like that. Don't dare to pull it out now."

    b "Oh my god...I can't hold it any longer...."

    b "Shit, if you keep fucking..."

    scene v16-168 with vpunch
    play sound "voices/moanfinish.mp3"

    b "Oohhhhhh...."

    b "Damn...I'm..."
    stop sound
    mur "Fuck, look at that."

    scene v16-169

    b "Fuck...I'm so sorry...It was just..."

    mur "It's okay, Banu. You just enjoyed it a bit too much."

    b "I'm really sorry...it was just an accident."

    scene v16-170 with hpunch

    "Murat looked deeply into Banu's eyes, a glimmer of excitement and anticipation in his gaze."

    b "Murat, I have to go. It's late."

    mur "For the next few hours, I want us to have an incredible time together."

    b "But I really can't stay."

    mur "We're having such a great time together, and I don't want it to end so soon."

    mur "You belong to me for the next hours."

    "Banu couldn't say a word as she felt Murat's dick in the enterance of her asshole again."

    "It was too late to reject Murat again..."
    $ persistent.muratfucksbanuafterfunsexscenestaywithkamil_unlocked = True


    jump muratfucksbanuafterfunsexscenestaywithkamil_continue_breakup









label polad_banu_shower:

    scene v17-117 with hpunch
    p "Banu? What are you doing here?"
    b "What's wrong with me seeing you showering, Polad? We live in the same apartment, and it's just a natural occurrence."
    p "Well, it's just that... it's a private moment, you know?"
    b "Exactly! And I'm sorry for intruding on your privacy. I should have respected your space, and I apologize for that. But it made me realize something important—I can't keep running away from my feelings."
    p "What do you mean, Banu?"
    b "I mean... I've been struggling with my emotions for a while now. I can't control how I feel, and it's not fair to anyone involved. I have feelings for you, Polad, and I can't keep denying it."
    p "I have to admit, I didn't expect our conversation to take place in the bathroom. Please, turn oround and leave."
    b "You know what, Polad? I think it's time to take our relationship to the next level."
    b "Next level? What do you mean?"
    scene black
    "Banu quickly strips down all her clothing revealing her naked body in front of Polad."
    scene v17-118 with dissolve
    b "I mean, why not spice things up a bit? How about we take a shower together?"
    "Polad's eyes widen in surprise, and a hint of nervousness crosses his face."
    p "Wait, Banu, are you serious?"
    b "You can't imagine how serious I am right now..."
    scene v17-119 with fade
    b "I can't hold it anymore. I see you every day but I can't touch you. It's like a torture for me."
    b "I know that I betray Nesrin, my best friend, but I just can't live with this."
    b "I know how you look at me all the time. So don't act like a fool and don't waste time."
    b "Take me!"
    scene v17-120
    "Without Banu saying a word, Polad takes Banu with force and pushes her against the bathroom wall."
    b "I knew you wanted this too. "
    p "Shut up and don't dare to lower your hands."
    p "I've been waiting for this moment, Banu. You can't imagine how bad I want you right now."
    p "You're driving me crazy with those dresses and these curves."
    b "Do you like them?"
    p "Damn, I will fuck the shit out of you."
    scene v17-121
    "While pushing her against the wall, Polad started to kiss Banu passionately."
    "Banu's breasts felt Polad's hard chest muscles pushing them aside and her lower body started to feel his big semi-erected cock."
    "Her pussy started to get wet, feeling the need of Polad's cock inside her."
    "At some point Polad sensed that Banu's pussy stayed out of his attention."
    scene v17-122
    b "Ahhhh. Shit! Are you serious?"
    p "Your dirty pussy down there needs attention. You're so sensitive there."
    b "You want to make me cum, don't you?"
    p "That will be easy as I already see it in your eyes. Your dirty married pussy will cum soon just from fingering it."
    b "Shit! Your hand is so hard and...."
    scene v17-123
    b "AAAAhhhhh.."
    b "Harder! Do it harder!"
    p "Yess do it! "
    b "Damn!"
    scene v17-123 with hpunch
    b "AAAhhhhhh!"
    p "Good job, Banu. Now you're ready for the main course."
    p "Turn around and put your hands on the wall!"
    scene v17-124
    p "Good girl. Spread your legs like this."
    p "Have you ever fucked in the shower?"
    b "No..."
    scene v17-125
    b "Holy fuck!"
    p "I see you are enjoying this. "
    p "Do you feel how hard you made me down there?"
    p "I'll fuck you senseless, Banu."
    b "Please, be gentle. Your cock is huge. That would destroy me."
    scene v17-126
    b "AY MAMA!"
    p "Shhhh, I haven't put it in yet. "
    b "That feels so big...I don't know if I can take it."
    p "Your pussy will get into the shape of my cock in no time."
    p "Here it comes..."
    n "Hey, Polad, could you grab my charger from the bedroom? Where are you?"
    scene v17-127 with hpunch
    b "Shit! Shit! Shit!"
    "Polad's expression shifts from surprise to urgency as he realizes the situation."
    p "She might come in here. You need to step out of the shower, quickly."
    scene v17-128
    "Understanding the gravity of the situation, Banu nods quickly and starts to run towards her clothes."
    b "Okay, I'm going!"
    "Polad gestures for her to go and watches as she exits the shower."
    "He quickly turns off the water and grabs a towel to dry himself."


    $ renpy.end_replay()
    $ persistent.polad_banu_shower_unlocked = True
    jump polad_banu_shower_continue





label murat_threesome:


    scene v17-224 with fade

    b "A game?"

    mur "Yep, a classic spin-the-bottle game. We'll spin the bottle, and whoever it points to has to take off one piece of clothing."

    b "Murat, I think that might be taking things a bit too far."

    va "Yeah, I'm sure that's the best idea right now."

    mur "Oh, come on, Banu. It's just a bit of fun. We could use some laughs to break the tension, right?"

    b "Alright, fine. But just one round, and let's keep it lighthearted."

    scene v17-225

    mur "Alright, let's keep this game rolling."

    "With a flick of his wrist, Murat spun the bottle. The room seemed to hold its breath as the bottle twirled, its momentum gradually slowing down."

    scene v17-226

    "The suspense was palpable, and then, as if guided by fate, the bottle's neck came to a stop, pointing directly at Banu."

    b "Well, what are the odds?"

    mur "Fate has spoken, Banu. Your turn."

    "A lighthearted yet nervous laughter filled the room as Banu took a deep breath, her fingers moving to the delicate fabric of her hijab."

    scene v17-227

    "With a practiced grace, she carefully removed the hijab, revealing her hair that had been hidden beneath it."

    "The atmosphere seemed to shift, a mix of emotions lingering in the air – surprise, curiosity, and a touch of vulnerability."

    "Banu's expression remained composed, her gaze meeting the inquisitive looks of her friends."

    b "I hope this doesn't change your perception of me."

    va "Exactly. We appreciate your openness, Banu."

    scene v17-228 with fade

    mur "Well, it seems I'm next in line for a wardrobe adjustment."

    scene v17-229

    b "Well, Murat, I have to say, I never expected you to be the one leading our impromptu fashion show."

    mur "You know, Banu, I'm full of surprises. Besides, I couldn't let Vasif have all the fun, could I?"

    b "Oh, absolutely not. We can't have Vasif hogging the spotlight, can we?"

    scene v17-230

    b "Well, I have to say, you're certainly proving your expertise."

    mur "You haven't seen anything yet."

    "As Murat unbuttoned his shirt and began to remove it, Banu's gaze shifted subtly, her curiosity piqued by the unexpected turn of events."

    "Her eyes trailed over the exposed expanse of his chest with a sense of longing but quickly she took her eyes off."

    scene v17-231 with fade

    mur "It seems luck is on Vasif's side tonight."

    "The room was now filled with a mixture of anticipation and laughter, the game having taken on a life of its own."

    "The bottle twirled, the suspense building as it gradually slowed down, finally coming to a stop, its neck pointing directly at Vasif."

    va "Well, well, it looks like I'm the chosen one."

    b "Looks like the fashion show continues, Vasif."

    scene v17-232 with hpunch

    va "Here you have it."

    "As Vasif unbuttoned his shirt and removed it, Banu's gaze shifted, her eyes involuntarily tracing the contours of his body."

    "A mixture of surprise and admiration played across her features as she took in the sight of Vasif's burly frame, the muscles of his arms and chest clearly defined."

    scene v17-233

    b "Vasif, I have to say, I'm impressed. You've been hiding those muscles under that shirt all this time?"

    va "Well, I guess I don't usually have an excuse to show them off."

    b "You're definitely making a statement now. All that dancing and you're hiding this impressive physique?"

    va "I guess I've been keeping it my little secret."

    mur "Who knew you were the undercover bodybuilder, Vasif?"

    va "Okay, okay, enough with the teasing."

    scene v17-234

    b "Well, well, now that we've all taken turns shedding some layers, I have to say, you two are quite the unexpected duo. Vasif with his undercover muscles and Murat with his spontaneous strip show."

    va "Who would've thought our night would take this turn?"

    mur "Hey, I'm all about keeping things interesting."

    b "Oh, I can see that. First the dancing, then the fashion show – what's next on the agenda, gentlemen?"

    scene v17-235 with fade

    mur "Looks like the bottle is having a field day with Banu tonight."

    "With another spin of the bottle, the room was filled with a mix of anticipation and laughter. "

    "As the bottle slowed down and finally came to a stop, its neck pointed directly at Banu."

    b "Well, well, it seems I'm up next."

    va "The fashion show continues, Banu."

    "Banu's gaze moved to the bottle and then back to her friends, her expression a mix of amusement and a hint of excitement."

    scene v17-236 with fade

    "With a final flourish, Banu removed her shirt, exposing more of her skin and leaving her cute bra underneath."

    "Her expression remained composed, her eyes meeting the amused gazes of her friends."

    b "Well, someone has to keep the game interesting, right?"

    va "You're definitely succeeding in that."

    scene v17-237 with fade

    "As the bottle gradually slowed down and came to a stop, its neck pointed at Vasif once again, a chorus of laughter filled the room."

    mur "Vasif, it looks like you're the star of the show tonight."

    va "I'm starting to think this bottle has a thing for me."

    b "It certainly seems that way. Are you ready for your encore performance?"

    scene v17-238

    va "I guess it's my turn to keep the fashion show going."

    b "Seriously? You're going to do that?"

    va "Are you ready?"

    scene v17-239 with vpunch

    "As Vasif removed his pants, Banu's gaze naturally drifted to his exposed member."

    "A sense of shock and admiration played across her features as she took in the sight of his giant cock, particularly the shape and the girth of his cock which appeared notably big and heavy."

    scene v17-240

    va "Oh, Banu, I see I've managed to surprise you. Should I be worried that you're speechless?"

    b "Oh please, Vasif. It's not every day I see someone's cock take up half the room. It must be difficult to carry this weight everywhere you go."

    va "Well, you know, I have to make sure I'm always prepared for a beautiful woman like you."

    b "I can't help but think you'd have an unfair advantage..."

    scene v17-241

    "The next time as the bottle gradually slowed down and came to a stop, its neck pointed at Banu once more."

    va "Looks like the bottle is favoring Banu tonight."

    b "Round and round it goes, where it stops, only the bottle knows."

    va "It seems like it has a thing for you."

    scene v17-242

    b "Okay I guess I have to go with the rules but promise guys not to stare."

    b "I see those curious glances!"

    b "No staring, gentlemen. Haven't you heard that it's impolite to ogle a lady?"

    mur "My apologies, Banu. It's just hard not to be a little surprised."

    scene v17-243

    va "You know what Banu? That's enough teasing for us."

    b "Wait, what do you mean?"

    va "You've been torturing us since we met today. I think it's time for us to get a little closer."

    b "Vasif, please, don't make things complicated. Please, don't come closer."

    scene v17-244 with vpunch

    va "Throughout all these moments, all the laughter and conversations, I've realized that I want you even stronger. I can't help it anymore."

    va "You're desperate, Banu. I want to give it to you, the best sex in your life."

    b "You know....I didn't know things would go this far...I need to go. It's getting late already."

    scene v17-245

    va "Do you feel how hard you made me? Do you think it's fair if you leave now?"

    b "Oh Vasif...I'm sorry but I can't stay any longer...I'm not ready for this."

    va "You're not going anywhere until you get your reward. Now the fun part begins. We'll make sure that every hole of yours is filled and satisfied."

    b "Listen...Vasif, I understand that you are young and horny and energetic but...I have a life and you need to understand that."

    va "Fuck that! Right now the only thing you need is my big, fat dick."

    scene v17-246 with fade

    "While Vasif groped and talked dirty to Banu, Murat quickly got rid of his clothes and joined Vasif and Banu."

    b "Hey wait! wait! guys..."

    b "Listen...this is definitely not a good idea."

    mur "Come on Banu, just relax a bit. You're so tense right now."

    scene v17-247

    va "Come on take off these cute bra and pants so we can see what we're dealing with."

    b "Fuck, guys...you're not letting it go..."

    va "Come on, Banu. I'm sure you're wet right now. You can't keep your eyes off my cock since I removed my pants."

    b "You're an asshole, Vasif. You know that?"

    scene v17-248

    va "Wow look at here. Man, she's dripping wet down there."

    mur "I told you man. She won't stop until our balls are drained."

    b "Shut up, Murat!"

    scene v17-249 with fade

    "After a few minutes, the sense of connection and desire among them deepened."

    "They moved to the sofe with Vasif sucking on Banu's nipples and Murat grabbing her from behind kissing her neck."

    scene v17-250

    b "Ohh guys, you're so passionate about this...you definitely know how to please a lady."

    "With each passing moment, each kiss exchanged, Banu's body got more excited and her pussy felt more vulnerable. "

    scene v17-251

    "As they continued to engage in the various poses, Banu's moaning became lauder that motivated the two young men."

    "The room was full of moaning and slapping sounds which Banu won't forget for a long time."

    "Vasif and Murat exchanged a quick glance, winking at each other while Murat pounding her harder. "

    "Without a word, they both raised their hands and gave each other a high five."

    scene v17-252

    "Banu cought her breath and found herself stroking Vasif's giant cock while Murat fucking her pussy. "

    "As she got her logical thinking back for a moment, she was again shocked by the size of Vasif's horse cock."

    scene v17-253 with fade

    "After some time, their time around the billiards table was a continuation of the night's theme – full of hard sex."

    "Banu put her hands on the billiards table and raised her hips for Vasif."

    "He bent Banu over as his liking and came closer to put his giant cock into action. "

    scene v17-254 with hpunch

    b "AHHHHHHH..."

    va "Fuck! I've been waiting for this..."

    b "Hey careful, you're going to tear me apart."
    scene v17-255 with hpunch
    b "AHHHHHHHHH..."
    va "Fuck! This pussy is so tight for my dick."
    b "Please, slower...It's tearing me apart...Ohhhhh"
    va "I'm going to ruin your pussy."
    show blondefucksbanustandinganimation
    play music "voices/moan4.mp3"
    b "Ahhhhh...that's fucking deep..."
    b "Your cock is invading my womb...It's so different...Ummmm"
    va "Let's see how much your milf pusssy can take."
    va "This married pussy is not stretched enough."
    va "I'm going to ruin you for other dicks, Banu."
    show blondefucksbanustandinganimation_fast
    b "Fuck, Ay mama! you're so deep..."
    va "Fuck, Murat, her pussy is sucking my dick so bad."
    mur "Give it to her, man. She's a bad wife and needs to be punished bad."
    va "Fuck yes..."
    stop music
    scene v17-256 with fade
    b_ "Those guys were savages."
    b_ "They were not just fucking me...they were taking my breath, killing me."
    b_ "They fucked me in every corner of the room in various degrading positions."
    scene v17-257
    b_ "That night was not just about friends having fun."
    b_ "They were degrading me, punishing me and I can't deny the fact that I loved it."
    b_ "I loved being used by those young men and fuck in every hole. "
    b_ "Murat's young and curvy dick was giving my asshole the best pleasure I've ever experienced."
    b_ "I got addicted getting fucked in the ass. I like how the pain turned into a mind-blowing pleasure."
    scene v17-258
    b_ "Vasif was so hard on me. He violated my mouth with his horse cock while Murat fucking my ass."
    b_ "Vasif was turned into an animal. He enjoyed fucking me hard and degrading me. "
    scene v17-259
    b_ "Those two young men were so different from Kamil."
    b_ "As Kamil never made me feel at my limit, with those guys...it was so intense."
    scene v17-260
    b_ "They fucked me in all three holes making me crazy."
    b_ "My brain melted, my body was continuously shaking from hard orgasms."
    b_ "It was the first time I got two cocks inside me at the same time."
    scene v17-261
    b_ "They banged my holes for hours and hours senslessly."
    b_ "Murat was continuously hitting my g-spot while Vasif's dong was inside of my."
    b_ "I couldn't believe how a dick that size even fit inside of me. "
    scene v17-262
    b_ "At that time, I had only little power left from those powerful orgasms."
    b_ "My body was weak and sweating from the hard fucking session that continued for hours."
    b_ "Their stamina shocked me and I thought they would last forever."
    scene v17-263 with fade
    b_ "But it finally came to an end with those beautiful creampies."
    b_ "Those two men gave me some good memorable moments in my sex life."
    b_ "After I came to my senses the gentlemen helped me to move to sit on a sofa as I couldn't move by myself after that hard fuck."
    scene v17-264 with fade
    play music "audio/up.mp3"
    va "Fuck! That was the best. Did you enjoy it, Banu."
    b "I truly did. This evening turned out to be quite the unexpected adventure."
    scene v17-265
    mur "So, I guess we're officially your partners in spontaneous escapades now?"
    b "That seems to be the case. Who would've thought a night that started at a club would lead us here?"
    b "Vasif, I have to say, even after all these activities, your dick still deserves a round of applause."
    mur "Man, looks like your dick got her attention."
    va "Hey, I'll take all the attentions I can get."
    stop music
    scene v17-266
    "As the laughter and playful banter continued around her, Banu's expression shifted from amusement to something more introspective."
    "In that moment, the events of the night and the complexities of her emotions collided, leaving her feeling out of place."
    "Why am I even here? she thought to herself. I shouldn't have joined them. What was I thinking?"

    $ renpy.end_replay()
    $ persistent.murat_threesome_unlocked = True
    jump murat_threesome_continue
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
