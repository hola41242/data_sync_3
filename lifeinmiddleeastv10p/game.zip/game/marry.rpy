


label marry:



    play music "audio/intro.mp3"
    scene black with Dissolve(3)
    ""
    centered "{size=+120}1 year later...{/size}" with Fade(0.5, 0.5, 5)
    scene black with dissolve
    b_ "So, it's been a year, and my life has gone through some pretty big changes."
    b_ "I went through a divorce with my ex-husband, Kamil. It was a tough decision, but I knew I had to make some serious changes."
    b_ "One of the biggest things I did was cut ties with negative and creepy people in my life. They were just dragging me down, and I needed better people around me."
    b_ "During this time, I spent more time with Aslan, who's a really religious guy. We got closer and realized we shared a lot of the same beliefs and values. He was a huge source of support for me during a tough period."

    scene v18-1 with Fade(0.5, 0.5, 5)
    b_ "Our friendship turned into something more, and we both knew we were meant to be together."
    b_ "We had a lot of love and respect for each other, so we decided to get married to make it official."
    b_ "This marriage marked the end of my journey to find myself."
    b_ "I went from feeling torn between my religious and modern sides to finding happiness and balance with Aslan by my side. "
    b_ "It shows how positive changes and love can transform your life."
    scene v18-2 with fade
    b_ "Oh, I can't even begin to describe how fresh and happy I felt when Aslan and I got married. It was an incredibly beautiful moment, one that I'll cherish forever."
    b_ "As I stood there, in my wedding dress, with Aslan holding me close, I felt like the weight of the world had been lifted off my shoulders."
    b_ "Aslan's embrace was warm and reassuring, and I could feel his love and support radiating through every touch."
    b_ "It was like a promise of a bright and beautiful future together, filled with love, respect, and shared values."
    scene v18-3 with fade
    b_ "The happiness in our hearts was palpable, and as we exchanged vows and made our commitment to each other, I knew that I was exactly where I was meant to be."
    b_ "It was a fresh start, a new chapter in my life, and I couldn't have asked for a better partner to share it with."
    scene v18-4 with fade
    b_ "In that moment, I felt like the luckiest person in the world, and I couldn't stop smiling."
    b_ "Aslan and I were not just starting a marriage, but embarking on a journey of love, growth, and happiness together."
    b_ "Kamil and Aslan are like night and day, and the difference between them is striking in so many ways."
    b_ "Kamil was never really supportive of my spiritual journey, and it created a sense of unease in our relationship."
    b_ "On the other hand, there's Aslan. He's a deeply religious man, and our shared faith forms a strong foundation for our relationship."
    scene v18-8 with fade
    b_ "I have to admit, our wedding night with Aslan didn't turn out quite as I had hoped."

    b_ "I was very horny and eager to show him my naked body for the first time"
    b_ "I thought he'd just grab me hard and put me on the bed forcefully and have his way with me."
    scene v18-9 with dissolve
    b_ "I was enthusiastic about beginning this new chapter of our lives, but when it came to the bedroom, things were a bit different."
    b_ "Aslan was incredibly shy that night, and it caught me off guard."
    b_ "He was just staring at my naked body instead of doing something."
    b_ "I was so awkward so I decided to take the initiative."
    scene v18-10 with fade
    b_ "I had expected a sense of confidence and closeness, but instead, we both felt somewhat hesitant and uncertain."
    b_ "It was clear that Aslan's shyness was affecting our ability to connect in the way we had imagined."
    scene v18-11 with fade
    b_ "I decided to tease him more but no luck."
    b_ "I felt a bit disappointed, not because of Aslan's shyness but because I had built up certain expectations for our first night together."
    scene v18-12 with fade
    b_ "I have to be honest; our wedding night in the bedroom left me feeling quite frustrated with Aslan sitting next to me covering his dick with his hands."
    b_ "I had been looking forward to this special night with excitement and anticipation, expecting it to be filled with sex, kissing and intimacy."
    scene v18-13 with fade
    b_ "However, things didn't quite go as I had imagined. Aslan seemed to be holding back, and there was a lack of the emotional and physical connection I had hoped for."
    b_ "It felt like our expectations and desires were not aligned, and this created a sense of frustration within me."
    b_ "I wanted our first night together to be a memorable and beautiful experience, but instead, it left me feeling disappointed and somewhat unfulfilled."
    scene v18-14
    b_ "It's important to remember that not every moment in a marriage is perfect, and our wedding night was a stark reminder of that reality."
    b_ "On our wedding night, I have to admit that I went to sleep feeling frustrated and even a bit angry at Aslan."
    b_ "Aslan's shyness and the awkwardness we experienced in the bedroom had created a disconnect between us."
    b_ "I had expected a deeper emotional and physical connection, and when that didn't happen, I couldn't help but feel let down."
    scene v18-5 with fade
    b_ "Sitting in front of my computer at work, my mind often drifted towards thoughts of Aslan and our marriage. "
    b_ "I couldn't help but reflect on the journey we had embarked on together, from our wedding night to the present."
    b_ "Thoughts of Aslan brought a sense of warmth and comfort. I remembered his kind smile, his unwavering support, and the deep connection we had built over time."
    b_ "Those memories made me feel grateful and fortunate to have him by my side."
    scene v18-6
    b_ "However, I also found myself contemplating the other men who had been part of my life before Aslan. "
    b_ "There were moments of nostalgia and reflection about the choices I had made in the past."
    b_ "It was a reminder of the different paths I had taken and the lessons I had learned along the way."
    scene v18-7
    b_ "But, ultimately, my thoughts always returned to Aslan and the love and happiness we shared in our marriage."
    b_ "It was a grounding force amidst the distractions of daily life, a reminder of the profound bond we had created and the bright future we were building together."
    scene v18-15 with Fade(0.5, 0.5, 5)
    b_ "Going shopping with Aslan used to be a lot of fun."
    b_ "We had this special way of making jokes and sharing laughter while we browsed through the stores."
    scene v18-16 with fade
    b_ "Sometimes, we would have playful arguments about which brand to choose or who had better taste in fashion."
    b_ "These little disagreements would always end in laughter, and we both knew we were just having fun."
    scene v18-17 with fade
    b_ "What I loved about those moments was how they reminded me of the joy that comes from sharing simple, everyday experiences with the person you love."
    b_ "Even during routine shopping trips, we managed to connect, have fun, and create lasting memories."
    scene v18-18 with fade
    b_ "It was a beautiful reminder of the happiness that came from being with someone who could make you laugh on even the most ordinary days but..."
    scene v18-19 with Fade(0.5, 0.5, 5)
    b_ "There were days when I felt really lonely and unsatisfied, especially when I was in the shower."
    b_ "Those moments of solitude could sometimes bring on a sense of yearning and desire that I couldn't ignore."
    scene v18-20 with fade
    b_ "As the water cascaded down and I stood there alone, I couldn't help but feel a longing for connection."
    b_ "I couldn't help but reached my sensitive spot with my hands and furiously rubbed my pussy."
    b_ "Loneliness would wash over me, making me acutely aware of my desires and my need for intimacy."
    scene v18-21 with fade
    b_ "I didn't care if Aslan could walk in and see me like this."
    b_ "I just thought about dirty and nasty stuff fulfilling my desires."
    scene v18-22 with fade
    b_ "Feeling lonely and horny in the shower could be both frustrating and isolating."
    b_ "It was a reminder of the moments when I craved the closeness and passion that only a loving relationship could provide."
    b_ "In those moments, I wished for someone to share those desires with, to feel connected, and to be satisfied on a deeper level."
    b_ "It's essential to acknowledge these feelings because they are a part of being human."
    b_ "Loneliness and desire are natural emotions, and they can serve as a catalyst for seeking the kind of intimacy and connection that can make life more fulfilling."
    scene v18-23 with Fade(0.5, 0.5, 5)
    b_ "My work life has been pretty normal, but there's this one thing that sometimes makes me a little uncomfortable. "
    scene v18-24 with fade
    b_ "There's this young guy at the office, and he often gives me this flirty look."
    b_ "You know, that kind of look that suggests he might be interested in more than just work-related stuff."
    b_ "Honestly, I try my best to ignore it. I mean, I'm there to focus on my job, not to get into any kind of personal entanglements."
    b_ "It's not that I'm not flattered by the attention, but I prefer to keep things professional and avoid any workplace drama."
    scene v18-25 with fade
    b_ "So, I just carry on with my work, do my best to concentrate on my tasks, and hope that things stay as they should – strictly business."
    b_ "It's important to maintain a professional environment and keep any personal distractions at bay in the workplace."
    scene v18-26 with Fade(0.5, 0.5, 5)
    b_ "In our bedroom, there was a turning point in our relationship with Aslan."
    b_ "He managed to put aside his shyness and connect with me on a deeper level, and I could see the effort he was making to bridge that gap."
    b_ "Our intimacy became more passionate, and we were finally starting to understand each other's desires and needs."
    b_ "Aslan's willingness to be more open and expressive in the bedroom was a significant step forward."
    scene v18-27 with fade
    b_ "However, despite this progress, there was still something missing for me."
    b_ "I couldn't help but feel that we needed more than just physical connection; we needed emotional intimacy as well."
    b_ "It was as if there was a deeper level of communication and understanding that we hadn't quite reached."
    b_ "Aslan was so naive in bed. He was treating me like an expensive car, trying not to hurt me. "
    b_ "But I needed more. I didn't like how he handled me in bed and his small dick failed to fully satisfy me."
    scene v18-28 with fade
    b_ "It was so small that it couldn't just go any deeper."
    b_ "But that's not the only thing I worried about, of course. That's not why we got married, right?"
    scene v18-29 with fade
    b_ "It's not that I wasn't satisfied with the progress we had made; I just knew that there was room for growth and that our relationship had the potential to be even more fulfilling."
    b_ "So, I was determined to work on nurturing that emotional intimacy with Aslan, because I believed it would bring us closer together in a way that went beyond the physical."
    scene v18-30 with fade
    b_ "It was a difficult and frustrating experience when Aslan showed signs of being weak both mentally and physically in the bedroom."
    b_ "There were times when he seemed exhausted or overwhelmed, which affected our intimacy."
    scene v18-31 with fade
    b_ "In some instances, he would struggle to maintain his physical stamina, leaving me feeling unsatisfied and disappointed."
    b_ "It was evident that there were challenges he was dealing with that were impacting our intimate moments."
    b_ "One particularly trying moment was when Aslan fell asleep, leaving me awake and feeling neglected. It was a tough situation because it left me feeling emotionally disconnected and lonely."
    b_ "It's important to remember that sexual issues can happen to anyone, and they are not a reflection of a person's worth or desirability."
    scene v18-32 with fade
    b_ "In our relationship, we knew that addressing these challenges required open and honest communication, empathy, and a commitment to finding solutions together."
    b_ "We sought professional help to understand and address the issues that were affecting our physical and emotional connection."
    b_ "While it was a challenging journey, it also allowed us to grow as a couple and work on strengthening our bond, both inside and outside the bedroom."
    scene v18-33 with Fade(0.5, 0.5, 5)
    b_ "There were times when I held that test in my hands, hoping for a positive result, and when it turned out negative, it was difficult to bear."
    b_ "The repeated disappointment was emotionally draining, and it felt like my dreams of starting a family were slipping away."
    scene v18-34 with fade
    b_ "Each time I saw that negative result, I couldn't help but feel a sense of sadness and frustration."
    b_ "It was a reminder of the challenges and uncertainties that can come with the journey to parenthood."
    scene v18-35 with Fade(0.5, 0.5, 5)
    b_ "When we realized we were having trouble getting pregnant, Aslan and I decided it was time to see a doctor."
    b_ "It was a tough decision, but we knew it was necessary to figure out what was going on."
    b_ "We went through a bunch of tests and exams to find out why we were having trouble conceiving."
    scene v18-36 with fade
    b_ "Turns out, the issue was related to Aslan's health, and that news was really tough to digest."
    b_ "But the doctor was really supportive and told us not to lose hope."
    b_ "He said there were treatments and options available to help us become parents. That was a relief to hear, and it gave us some optimism for the future."
    scene black with dissolve
    b_ "As we left the doctor's office, we knew the journey ahead wouldn't be easy, but we were determined to do whatever it took to start our family."
    b_ "We felt reassured that the doctor was on our side and that, with medical help and our unwavering support for each other, we could overcome this challenge and eventually welcome a child into our lives."
    scene v18-37 with Fade(0.5, 0.5, 5)
    b_ "To help distract ourselves from the longing for a child and the emotional toll it was taking on us, Aslan and I started filling our time with fun things to do at home."
    b_ "One of our favorite activities was playing chess."
    scene v18-38 with fade
    b_ "We'd set up the chessboard, sit down, and engage in friendly games."
    b_ "Chess required us to think and plan our moves carefully, and it provided a welcome escape from the constant thoughts about our fertility struggles."
    b_ "Our games were a chance to relax and enjoy each other's company. We'd share laughs and have playful conversations while we played."
    scene v18-39 with fade
    b_ "It was a way for us to create happy moments together, free from the worries of trying to have a baby."
    b_ "Chess became a sort of refuge for us, where we could focus on something different and find some peace amidst the challenges we were facing."
    b_ "It helped us stay connected and reminded us of the strength of our relationship, even during tough times."
    b_ "You know, I never thought I'd be any good at chess, but thanks to Aslan, I've become a bit of a chess whiz! It's all his fault, really."
    b_ "He's such a patient teacher, and he'd sit down with me for hours, explaining strategies and tactics."
    b_ "At first, I was like, 'Are you sure I'm not just moving the pieces randomly?' But he encouraged me and never let me give up."

    show banu_walking_office_animation
    "..."
    scene walking38
    b_ "At work, there were moments when I felt an unexpected boost of confidence and freshness, especially when I noticed other men looking at me."
    b_ "It's like a shot of energy that comes from feeling noticed and appreciated."
    b_ "Feeling good about myself in the workplace was empowering. It made me walk a little taller, smile a bit brighter, and approach my tasks with renewed enthusiasm."



    scene v18-40 with Fade(0.5, 0.5, 5)
    b_ "You won't believe it, but the guy at work who always seems to be around wherever I am."
    b_ "It's like he's following me or something, trying to find a way for us to be alone together."
    scene v18-41 with fade
    b_ "I have to admit, I can't help but sneak a glance at him from time to time."
    b_ "I mean, he's undeniably good-looking, and it's hard not to notice."
    b_ "But I want to be clear that I'm not encouraging his attention or anything like that. I'm just a human being, and I can appreciate good looks when I see them."
    b_ "At the same time, though, I know how important it is to keep things professional at work."
    b_ "I don't want to get involved in any workplace drama or distractions."
    b_ "So, while I might notice him, I make sure to keep our interactions strictly business."
    scene v18-42 with Fade(0.5, 0.5, 5)
    b_ "Aslan and I were determined to have frequent sexual interactions in the bedroom in our quest to start a family."
    b_ "We knew that this was a crucial part of our journey toward parenthood, and we were both committed to doing whatever it took."
    b_ "Our bedroom became a place of hope and longing, where we put aside our worries and focused on the possibility of bringing a child into our lives."
    scene v18-43 with fade
    b_ "There were nights when I found myself staying awake long after Aslan had fallen asleep."
    b_ "It wasn't because of restlessness or insomnia; rather, it was a time when my thoughts seemed to come alive."
    b_ "In the quiet stillness of the night, I would reflect on our life together, our dreams, and the challenges we faced."
    b_ "Sometimes, these late-night reflections were filled with optimism and gratitude, as I thought about the love and support Aslan and I shared."
    b_ "Other times, it was a chance to confront my worries and uncertainties, especially in our journey to start a family."
    stop music









    "..."
    scene ending_10 with dissolve
    "..."
    "..."

    dev "{color=#ffffff}Thank you for playing! YOU'VE REACHED ONE OF THE ENDINGS!. Play again to discover more. If you enjoyed it, please {a=https://www.patreon.com/lustfulfantasy}support{/a} the development. Wishlist our new game here {a=https://store.steampowered.com/app/4056530/Banu_in_the_West/}Banu in the West{/a} {/color}"
    hide screen faith
    hide screen angeldevil
    $ renpy.end_replay()
    $ persistent.marry_unlocked = True
    jump endings
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
