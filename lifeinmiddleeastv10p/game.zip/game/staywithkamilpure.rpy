label banu_challanges_kammil:
    $ renpy.block_rollback()
    $ kamilagreetoplaythegame = True
    scene v15-86
    play music "audio/sexy.mp3"
    k "I just... I'm not really into these things. But if it makes you happy, I'll give it a try."
    b "I appreciate you being open-minded and willing to step out of your comfort zone for a little while. Let's see if we can have some fun with it."
    k " I'll do my best, Banu. Just remember, I'm not really the game-playing type."
    b "Well, if you accept the bet, let's not waste any time."
    b "For the starter I'll take your underwear off."
    scene v15-87 with fade
    "As they begin playing the game, there is a hint of hesitation and reluctance in Kamil's actions."
    "However, Banu remains patient and understanding, ensuring that their time together is filled with support and encouragement."
    scene v15-88
    "While Kamil might not fully embrace the game, their willingness to compromise and engage in an activity that brings Banu joy becomes a testament to their commitment in finding common ground within their relationship."
    b "Well, how do you think? Will you be able to win?"
    k "I'll try my best to give you pleasure."
    b "A pleasure? huh. I'll squeeze the last drop of your cum out of your dick."
    b "I bet you'll cum in not time and this'll be an easy win for me."
    scene v15-89
    k "You sound confident."
    b "Because I know you're weak down there."
    b "I know that's a big amount for you."
    b "Are you ready to give me your one thousand?"
    k "Do you think I'll give it to you so easily?"
    k "I'll give you the most powerful orgasm in your life in a few minutes and take your one thousand. I'm sorry but I'll show you no mercy."
    scene v15-90
    b "I think you're ready to play."
    b "Let's warm you up a bit."
    scene v15-91
    "Banu ran her hands all over Kamil's body making him excited and wrapped them around his fully erect cock."
    b "It's so warm."
    b "Let's see if you can pass the first round."
    stop music
    show banumakekamilcumanimation
    k "Ahhhhh...You're so agressive."
    b "This game is so much fun!"
    k "Slow down a bit....Ahhhhh.... That's not fair."
    b "Oh, come on, Kamil! It's all part of the game. You know I'm a competitive person."

    show banumakekamilcumanimationangle
    k "Ohhh shit....If you keep that..."
    b "What? "
    b "You're cumming already?"
    b "Shit, this was so easy."
    b "Sometimes I think your weak dick doesn't deserve my pussy."
    b "Come on shoot it. I know you want to do it."
    scene v15-92 with vpunch
    play sound "voices/man2.mp3"
    k "Ahhhhhh...."
    b "Uh!"
    stop sound
    scene v15-93
    k "Ohhhhhh shit..."
    b "Wow , you cum so much..."
    b "Come on, release all of it. Empty your balls."
    scene v15-94 with fade
    b "Well, I'm sorry to tell you this but you've only two chances left. "
    k "That wasn't fair I mean....I didn't expect that to be so agressive."
    scene v15-95
    b "Well, maybe you can prove yourself in the third round."
    k "You'll definitely lose this time."
    k "I'll make your pussy cum in no time like you always cum on my dick."
    b_ "Poor Kamil. He hasn't realized that every time I make fake orgasms just to make him happy."
    b "Hmmmm, let's see..."
    scene v15-96
    b "I love it when you're always excited to see me undress."
    b "Let's take these off."
    b "We don't need these panties, do we?"
    scene v15-97
    k "Banu, I love your body."
    b "I know that. You're addicted to my body."
    scene v15-98
    "Banu was moving her hip back and forward teasing Kamil's dick with her pussy."
    b "Are you ready to release all your semen inside of me?"
    k "I'd love that but this time you'll be the one cumming on my dick."
    scene v15-99
    b "Oh really?"
    k "I'll show you no mercy, Banu."
    b "Oh let's do it bad boy, I want to see it."
    scene v15-100
    "Banu pinned Kamil's hands to the bed. With a slow movemend Kamil's dick slid into Banu's pussy."
    b "I see you're ready to go."
    show banumakekamilcumtwoanimation
    k "Ohhhhh shit..."
    k "You're so energetic today..."
    b "Do you like it?"
    k "Damn..."
    k "You squeeze my dick so hard..."
    k "Ohhhh....that feels so good...shit..."
    k "I know you do it on purpose..."
    show banumakekamilcumtwoanimationangle
    b "Just shut your mouth and fuck me harder."
    b "You worthless piece of cow dung..."
    b "Look at my face."
    b "I want you to look into my eyes."
    b "You're a pathetic human being and your dick can never make me cum."
    k "Really..."
    scene v15-101
    "Kamil started thrusting faster fueled by Banu's talking."
    "But It was too late."
    "Kamil was in the edge of a powerful orgasm..."
    scene v15-102 with vpunch
    play sound "voices/man3.mp3"
    "And with the last thurst he emptied his balls again inside Banu's pussy."
    k "Ahhhhhhhhhhh....Damn..."
    stop sound
    k "This is soo good."
    scene v15-103
    b "Poor Kamil. I told you. You lost again."
    b "You have only one chance left."
    k "Come on, Banu, let's just end this stupid game."
    scene v15-104
    b "Really? So you decided to resign?"
    k "I'm serious Banu, you know I have to wake up early tomorrow."
    b "Oh, Kamil, you're getting tired already?"
    b "There's so much more fun to be had."
    k "I need a break. My mind and body are exhausted. Can't we continue later?"
    scene v15-105
    b "But Kamil, the game is getting more interesting, and I can't resist seeing that competitive fire in your eyes."
    b "Come on, just one more round. I promise it'll be worth it."
    k "Worth it, huh? What do you have in mind?"
    scene v15-106
    b "Well, let's say that if you win the next round, I'll give you a special reward. Something that will make you forget all about being tired."
    b "I don't remember doing this in a standing position."
    b "We always do that in missionary position."
    scene v15-107
    b "Do you want to try something new?"
    b "But be careful and don't mistake the holes."
    k "Damn, Banu, you're so dirty."
    scene v15-108
    k "You know how to tempt me, Banu."
    b "But be careful. This is your last chance to make me cum."
    scene v15-109
    k "You got me really frustrated."
    k "I'll show you just how powerful and skilled I can be. I won't settle for anything less than victory."
    b "Wow, Kamil! You're really into the game. You're determined to win, aren't you?"
    b "I love seeing this competitive side of you, Kamil. It's thrilling to watch you give it your all."
    scene v15-110 with hpunch
    b "Ahhhh..."
    "Kamil entered Banu with a powerful thurst while holding her arms firmly."
    show banumakekamilcumstandinganimation
    b "Wow...you really want to make me cum, don't you?"
    k "Come on, cum on my dick."
    b "Ahhh...yeah, just a little more..."
    b "Oh yeah...fuck me harder Kamil. "
    b "Show me what you've got."
    k "You're so tempting..."
    show banumakekamilcumstandinganimationangle
    b "Show me how much of a man you are."
    b "My pussy is hungry for your manly seeds."
    b "Come on harder....ahhhh."
    b "Give my pussy what she needs..."
    k "Damn cum already....ohh shit..."
    b "More....a little more..."
    b "Harder..."
    scene v15-111 with vpunch
    play sound "voices/man1.mp3"
    k "Ohhhhh...."
    b "Oh, Kamil, you gave it your all."
    stop sound
    k "..."
    scene v15-112
    b "But luck doesn't seem to be on your side tonight."
    b "You lost again!"
    scene v15-113 with fade
    k "I'm exhausted, both mentally and physically."
    b "It's okay, Kamil. Remember, winning isn't everything. The most important thing is that we had fun."
    b "Winning or losing doesn't change how much I appreciate you."
    scene v15-114
    k "I'm so tired, Banu. Playing all those rounds really drained me. I think I need to rest now."
    b "Of course, my dear. You did your best tonight. Get some rest and recharge. We can always continue the game another time if you're up for it."
    b_ "As I watch Kamil, once again defeated and tired, a part of me can't help but feel a sense of disappointment. "
    b_ "These thoughts linger, and I find myself questioning his strength, both physically and mentally. Am I wrong to think this way?"
    b_ "I've always admired those who exude confidence and conquer challenges effortlessly."
    b_ "It's what I envisioned in a partner, someone who could match my drive and assert themselves with unwavering determination. But is that fair? Is that what truly defines strength?"
    b_ "He's caring, supportive, and deeply committed to our relationship. "
    b_ "Those are strengths in their own right, aren't they? But why do I find myself yearning for something more, something different?"
    $ renpy.end_replay()
    $ persistent.banu_challanges_kammil_unlocked = True
    jump banu_challanges_kammil_continue



label banu_rides_kamil:

    "In order to make it stronger, Kamil and Banu decided to water their relationship regularly."
    k "Do you like it..."
    b "Yesss...faster... I want it faster."
    k "Your pussy feels so good Banu..."
    b "Fuck me harder Kamil, please....do it..."
    show banukamilmissionaryanimationpureroute
    "While having sex with her husband, Banu's mind drifted away again..."
    if followpolad == True:
        b_ "I'm such a bad wife."
        b_ "How could I cheat on my husband with Polad."
        b_ "But....Polad's the beast in bed..."
        b_ "Kamil can't be compared to him of course..."
        b_ "Shit, why do I compare them....?"
        b_ "Kamil's my husband but Polad is just nobody..."


    if banuturansexfirsttime == True:
        b_ "How could that evil man managed to put me in his bed..."
        b_ "Turan's the worst man I've ever known. How could I cheated with him..."
        b_ "Although the fuck was so intense and full of orgasms... "
        b_ "No...I shouldn't be thinking about him..."


    if banutakethebetfuckmurat == True:
        b_ "I can't forget about my last mistake..."
        b_ "Murat...he fucked me using his tricky games..."
        b_ "How could I fall for that?"
        b_ "I shouldn't be doing those mistakes again..."

    b_ "Kamil's nice and gentle in bed..."
    b_ "But there's something missing..."
    b_ "I want him to be more passionate and more cruel to me in bed."
    b_ "I want him to fuck me so hard in different positions..."
    b_ "But I'm afraid to tell him that. I don't want to hurt him and I don't want him to think bad of me..."
    scene v13-167
    b_ "Maybe I can encourage him with my loud moaning. "
    b "Yessss, Kamil. AAAAAhhhhh....harder, harder please...."
    show banukamilmissionaryanimationpureroute2
    play music "voices/moan2.mp3"
    "Banu started to look into Kamil's eyes, encourage him using her woman power... "
    b "Yess Kamil, you are so good..."
    k "Really?.."
    b "Yess. You fuck me so good. I'm about to cum....just a little harder..."
    k "Oh yess? Then take it.... "
    "Kamil started to pound faster, but...."
    scene v13-168 with hpunch
    stop music
    play sound "voices/man3.mp3"
    k "OOOOhhhhh shit, I'm cumming....Oooooohhhhhh..."
    b_ "Not again! This's not surprising. He couldn't hold it again..."
    stop sound
    b_ "If this continues I'll never be satisfied. "
    b_ "I need to do something, but I don't want to hurt his male pride..."
    menu:
        "Fake an orgasm":
            $ fakeanorgasm = True
            $ renpy.block_rollback()
            scene v13-169
            play sound "voices/moan1.mp3"
            b_ "Ohhhh yess, I'm cumming too..."
            b_ "This feels good..."
            k "Ohh yesss..."
            stop sound
            scene v13-170
            k "I'm so happy that we had an orgasm at the same time."
            b "Yes, I'm happy too. I'm happy to have you. I love you so much."
            k "I love you too."
        "Tell him that you want to ride him":




            $ fakeanorgasm = False
            $ renpy.block_rollback()
            scene v13-170
            b "Wait, we're not done yet..."
            k "What do you mean?"
            scene v13-171
            "Banu is released from his arms and stood on her knees looking into Kamil's eyes.."
            "Kamil was not understanding what she had in mind..."
            scene v13-172
            b "Now you're going to lay back straight and shut up."
            k "Banu you know that I don't like that. I don't want to play any games."
            b "You told me you would do anything to save our marriage."
            b "And now you're not keeping your promise."
            k "Banu!"
            b "I SAID LAY BACK!"
            k "Oh..okay..."
            scene v13-173
            "Kamil did what Banu ordered, laid back and waited for Banu to take lead. "
            b "Now keep your hands attached to bed like this."
            k "Banu..."
            b "I want you to shut your mouth and not to talk until I finish with you."
            "Banu kept looking into Kamil's eyes and started to grind his semi erected dick with her ass cheeks."
            scene v13-174
            b "I know that what I'm doing hurts you. "
            b "This hurts your male pride that your wife's on the top."
            b "Because you're a typical eastern male thinking that males are superior to females."
            k "Stop this...this's.."
            scene v13-175
            b "I know that you enjoy to be dominated deep inside you though you don't want to accept that. "
            b "Your manhood's excited I see. He doesn't agree with you."
            k "Banu this's too much..."
            b "I see it in your eyes that you want to fuck me so bad now, don't you?"
            scene v13-176
            b "But you don't want to admit it."
            b "Tell me now. Do you want to stick that dick inside of me?"
            k "Fuck yes, I want it..."
            b "Then you have to ask for it. Come on ask gently. "
            k "Banu, please, let me fuck you.."
            b "Hehe, you're so funny."
            b "Tell me that you want to fuck me so bad."
            k "I want to fuck you so bad Banu, please let me do it."
            b "Well, since you asked like that..."
            scene v13-177
            "Banu slowly lowered her ass on Kamil's penis."
            "Kamil wanted it so bad but didn't dare to move as Banu ordered it. "
            b "Stay still and I'm going to fuck you!"
            show banuridingkamilanimation1
            "Banu started to ride Kamil up and down..."
            "The sensation of being on top of Kamil felt so excited and made Banu go wild."
            "She started to insult Kamil which she could never do in other circumstances."
            b "I'm going to fuck your male pride."
            b "Of course if you have one."
            k "Banu.."
            b "Shut your fucking mouth."
            b "I'm going to make your pathetic penis explode again."
            b "You're so poor and weak. I'm gonna teach you how to fuck your wife."
            b "I feel your balls are boiling now."
            b "You can never hold it more than five minutes..."
            b "Because you're weak..."
            scene v13-178
            play sound "voices/man3.mp3"
            k "Shit, I'm cumminggg...Ahhhh yess..."
            b "Yes release it..."
            stop sound
            k "Banu...."
            scene v13-179
            b "What? Don't tell me you didn't like it."
            k "I don't know. I feel awkward."
            k "But that was definitely too much."
            scene v13-180
            b "But you like it don't you. I can see it in your eyes."
            b "Just admit it. Be sincere with me."
            k "Yes it felt good."
            b "I'm happy that you liked it."
            k "But..."
            b "Let's talk about it another time."
            b "Now I want you to hug me. I want to fall asleep in your arms..."
    $ renpy.end_replay()
    $ persistent.banu_rides_kamil_unlocked = True
    jump banu_rides_kamil_continue

label staywithkamilpure:

    scene black with Dissolve(3)


    $ tellkamilaboutmurat = False
    $ fakeanorgasm = False





    centered "{size=+120}Broken{/size}" with Fade(0.5, 0.5, 5)
    scene v13-93 with irisin
    play music "audio/intro.mp3"
    "Banu was not expecting that Kamil could do such a thing."
    "He has always been a gentleman with her."
    "But today..."
    b_ "I guess I crossed the lines but..."
    b_ "I did everything to save our marriage, to give him the satisfaction as a husband and as a man and this is what I get?"
    b_ "I don't deserve this."
    scene v13-94
    k "Banu..."
    "Kamil was so sorry for hitting Banu."
    "He loved her more than anything in her life."
    "But today he couldn't keep himself and hit his little pure wife."
    "Now it's up to him if he can heal her broken heart or not."
    scene v13-95
    stop music
    "Banu instantly stood up and turned her face to other side so Kamil couldn't see her broken face."
    k "Look, I understand you well. But what you saw..."
    b "Who is Humay?"
    k "..."
    k "Humay was a woman a was seeing."

    k "Look, I broke up with her before we were married... but who told you about Humay.."
    scene v13-96
    k "Come on Banu. Don't you see how it's ridiculous. Somebody tries to separate us."
    k "Just tell me who told you about Humay?"

    menu:
        "Tell him about Murat":
            $ renpy.block_rollback()
            $ tellkamilaboutmurat = True
            b "Well, I've a friend. He's a journalist and..."
            k "What! He? You have a male friend?"
            b "Kamil, listen, he's a nice guy and... "
            k "You know that I don't want any male be around you and you are talking about a friendship?"
            if banutakethebetfuckmurat == True:
                b_ "Poor Kami. You don't know what he's done to me and I can never tell you that."
                b_ "This'll be a lifelong secret between us...I'm sorry."

            k "What's your business with him?"
            b "I just help him write some news about religious women."
            k "But where the hell he knows about Humay and me?"
            b "I don't know and I don't care."
        "Keep it secret":




            $ renpy.block_rollback()
            $ tellkamilaboutmurat = False
            b "It's not so important. Let's just forget about what happened."


    scene v13-97
    play music "audio/romantic.mp3"
    k "I love you so much and I don't want to lose you."
    k "I'm sorry Banu, really sorry!"
    b "It's okay Kamil, I love you too."
    k "You are my precious one, my love!"
    scene v13-98
    "Kamil finished his words and gave Banu a sweet kiss on her forehead showing that she is the most important female in his life."
    "Banu enjoyed the kiss on her head. She felt so good being loved and cared in her husband's arms."
    "Both Kamil and Banu were taking steps to fix their relationship, to make their marriage stronger."
    "Today they achieved compromising and forgiving. Now they are ready for the next step."
    stop music
    scene black with Dissolve(3)
    centered "{size=+120}Midnight{/size}" with Fade(0.5, 0.5, 5)
    scene v13-166 with squares
    jump banu_rides_kamil

label banu_rides_kamil_continue:



    scene black with Dissolve(3)
    centered "{size=+120}2:33 AM{/size}" with Fade(0.5, 0.5, 5)
    scene v13-181 with dissolve
    play music "audio/intro.mp3"
    "Banu again couldn't sleep."
    "With different thoughts on her head she started wandering around the kitchen."
    scene v13-182
    b_ "My relationship with Kamil is developing little by little."
    b_ "I do feel that we moved forward."
    b_ "He always appreciated my beauty. I know that he loves me so much."
    b_ "He did everything he can not to lose me."
    b_ "Kamil has a lot of flows like everybody else."
    scene v13-183
    b_ "But what about me?"
    b_ "I've not been such a good wife to Kamil."
    scene v13-184
    b_ "I made so many mistakes. I made sins that Kamil doesn't deserve. I did wrong to him sometimes."
    b_ "And most importantly, he doesn't know my newly developed feelings for Polad."
    scene v13-185
    b_ "I feel the worst as I fell for Polad who was the best friend to my deceased husband."
    b_ "Both Polad and me betrayed him."
    b_ "But it's what it is. I like him. I can't control myself when I'm around him."
    b_ "I should kill those feelings for him inside me because I feel like I'm doing wrong to Kamil. I feel like a bad person but I'm not that type of woman."
    b_ "I'm sure those feelings will fade away soon."
    scene v13-186
    b_ "I'm committed to the marriage with Kamil."
    b_ "And from now on it's my duty to give all my loyalty to this commitment."
    if followpolad == True:
        b_ "Kamil doesn't know what I did with Polad and I have to keep secrets from Kamil for lifelong."
        b_ "But this is just to save our marriage."
        b_ "If I tell him the truth he would never accept me as his wife and this's completely normal."

    if banuturansexfirsttime == True:
        b_ "I shouldn't make the same mistakes again. The mistake I made with Turan."
        b_ "I just forced me into sex, because he can't get me in another way."
        b_ "But I should be careful anyways."


    if banutakethebetfuckmurat == True:
        b_ "The first time I tried alcohol gave me bad memories."
        b_ "How could I betray my religion and drink something that is haram."
        b_ "What happened with Murat must be a lesson for me."



    stop music
    scene black with dissolve
    ""




    if banuturansexfirsttime == True:
        scene black
        centered "{size=+120}Turan's apartment{/size}" with Fade(0.5, 0.5, 5)
        scene v14-33 with squares
        "Banu was again here in a place she hates the most."
        "She had to come here because she didn't want to destroy her marriage because of another man."
        "She didn't like Turan at all. He was not her type of a man, cocky and tricky."
        "But every time Turan found a way to slide into her self-defensive system and sometimes into her pussy."
        scene v14-34
        "But this time she came prepared."
        "She didn't want this disgraceful affair to last so she decided to put an end to this."
        scene v14-35
        "But after all, another surprise from Turan was waiting for Banu."
        b "What the fuck!"
        scene v14-36 with hpunch
        t "Hey Banu. You get prettier day by day. Don't stand just there. Come take a seat."
        scene v14-37
        b "What the hell are you doing? Are you out of your mind?"
        t "Why is that?"
        b "Just put some clothes on. We can't talk like this."
        t "This is my house after all and I decide what to wear. It's just hot here so I decided to stay naked. Is something bothering you?"
        b "Stop this Turan. It's ridiculous. Put some clothes on or I'm leaving."
        t "We both know that you're not going anywhere. You came here to be fucked and you can only leave after I finished with you, remember?"
        scene v14-38
        b "Fine, let's talk then. What you need to leave me alone already? You already got what you wanted from me."
        t "Nice point Banu. I've a good news for you. I believe that this will make you happy."
        scene v14-39
        b "I had enough of your tricks but again tell me what's this all about?"

        scene v14-40
        t "After a month I'm going to leave the city. Just one month and I'll be gone forever so you'll never see my face again."
        scene v14-39
        b "Wait..you're telling me that you'll leave the city forever?"
        scene v14-40
        t "That's right. But there's a bad news. You'll have to serve me until I leave and once I leave the city I'll forget about you. I promise."
        scene v14-39
        b "You're such an asshole! I can't believe you're telling me this."
        scene v14-43
        t "You're right. I'm asshole. Now let's get to the business. You'll just have to do this for one month and then you'll be free. "
        t "Of course if you want to stay with me after one month you can just come with me."
        scene v14-41
        b "I hate it when you talk like that you know that?"
        b "You're the last person on earth that I'd want to be with."
        b "I hate you Turan. How many times should I tell you that?"
        scene v14-42
        "Occasionally Banu's eyes drifted unconsciously towards Turan's bare manhood and she couldn't stop thinking about it."
        b_ "Look at that..."
        b_ "It looks so tough but at the same time it's beautiful."
        "It was the first time Banu paid close attention to the attractiveness of a man's penis."
        scene v14-45
        t "You're saying that but you can't take your eyes off my dick. Now don't tell me that you didn't look at it."
        scene v14-44
        b "You have a good fantasy world. It's just your fantasy that I look at you."
        b "I never enjoyed your presence, I never enjoyed being with you and I'll never give you that satisfaction. "
        scene v14-45
        t "Okay as you wish. Let's take the conversation to my bedroom..."
        b "..."
        scene black with dissolve
        ""
        scene v14-46 with dissolve
        t "Don't hurry. Take your clothes off slowly. I enjoy your undressing."
        b "One day you'll die and I'll come and spit on your grave."
        t "Are you always pessimist like that? You don't know how to enjoy the moment."
        b "You'll die one day."
        scene v14-47
        b_ "Maybe that's exactly today..."
        "Turan had no idea what Banu had planned for him all this time."
        "She wanted to end this affair. She knew that Turan would never leave her alone. "
        "She couldn't live with this. She couldn't do this to her husband because she was not that type of person."
        "She came to Turan's apartment for the last time to kill him."
        scene v14-48
        "But what Turan said earlier really confused Banu."
        "This would be just a one month affair... "
        b_ "I have to make a decision now. I came here to kill him and end this madness. "
        b_ "If I kill him the police will find out in the end but what if I bear this one more month?"
        b_ "I don't know if I can do this."
        menu:
            "Kill Turan":
                $ renpy.block_rollback()
                $ killturan = True
                scene v14-49
                play music "audio/tension.mp3"
                "Banu was determined to finish what she came for."
                "She slowly took the knife out of the bag and squeezed it in her hand."
                b "Hey I'm having trouble unzipping my pants. Why don't you come and help me with that?"
                t "That's my girl. I knew one day you'll ask me to undress you."
                scene v14-50
                t "I'll gladly help you with that. "
                t "Just turn around..."
                scene v14-51 with hpunch
                b "This is what you deserve. Do you hear me?"
                "Banu made a quick turn around and the knife in her hand penetrated Turan's chest."
                b "Bastard, this will be the only thing you'll get from me."
                "Banu was talking bitterly and aggressively. She did what she came for and now nothing was holding her to break Turan properly."
                scene v14-52
                "Turan couldn't believe what had happened for a moment."
                "Once he realized that the sharp kitchen knife had penetrated down his right pectoral muscle, he instinctively put his hands around the knife to pull it off."
                scene v14-53
                t "What...what've you done?"
                "His face impression changed completely. The arrogant look on his face was replaced by a weak pathetic look."
                t "Are you crazy, bitch?"
                t "You'll go to the jail."
                scene v14-54
                "On the other hand, Banu was now so confident and proud of what she was doing."
                b "And you'll go to the hell! You'll be burning there and like I said I'll come and spit on your grave, asshole."
                "Banu's bitter words hit Turan and he tried to grab her by her throat."
                t "If I go to hell, I'll take you with me, bitch."
                "He tried to grab her and choke her but the pain and running blood from his body made him weak so he fell on his knees."
                scene v14-55
                b "Now it's time to pay for all the things you've done to me."
                b "I won't even call an ambulance you know?"
                b "One more motherfucker will disappear from my life today."
                scene v14-56
                t "Don't be stupid. Call an ambulance..."
                t "I'm passing out..."
                t "Please..."
                scene v14-57
                b "You're so weak, pathetic and coward."
                b "If you want me to help you, you need to beg properly. I can't hear you."
                scene v14-58
                "But Turan was already passed out."
                "Banu looked at him bitterly again. She couldn't believe that the man who did all the evil stuff was lying unconscious just before her."
                scene v14-59
                b "Hey do you hear me?"
                b "Don't try to fool me again. "
                b "After all the things you've done to me I'm still up but you're lying down here. You need me to save your ass."
                b "But you don't deserve this. You don't deserve to live. "
                scene v14-60
                "But Turan didn't move or say a single word."
                "Soon Banu realized that she was in a deep shit."
                "Her anger was replaced by fear and worry."
                scene v14-61
                stop music
                b_ "Shit! What should I do now."
                b_ "If I leave him here he'll die for sure."
                b_ "I don't want to go to the jail. But what's done is done. I believe I did the right thing."
                scene black with dissolve
                ""

            "Agree to obey him one last month" if lust >= 200:
                $ renpy.block_rollback()
                $ killturan = False

                scene v14-62
                b "Okay, I agree to go with your rules one month but I need to make sure that you'll fucking leave after that."
                t_ "Like you've a choice."
                t "I spoke to the boss about this and he already found a worker to replace me. Now I should guide him and teach him stuff about the job."
                t "If you suspect you can always ask the boss about that."
                scene v14-63
                b "I'll give you what you want, but I have rules and you'll have to obey these rules. Only then we can do business."
                scene v14-64
                t "Wow, you have rules?"
                b "Exactly."
                t "Then what are they?"
                scene v14-65
                b "My first rule is that we won't kiss, never. You won't touch my lips."
                t "You don't like that?"
                b "I hate you and I don't want to kiss you. That's simple."
                t "Okay deal."
                scene v14-63
                b "My second rule..."
                t "Wait...I want to hear the rest after you undress completely."
                t "Take your jeans off."
                b "..."
                scene v14-66
                "Banu didn't say anything and obeyed what he ordered."
                t "That's it. Now it's good."
                t "So what were you saying?"
                scene v14-67
                b "My second rule is that you won't touch any of my private parts other than my vagina. I hate that."
                b "Is that agreed?"
                scene v14-66
                t "Well, if you mean your little butthole, I won't touch it until you asked me to."
                b "That will never happen."
                scene v14-67
                b "And lastly while we're doing it you can't talk about my family. I'd prefer you to shut your mouth completely. "
                t "If you say so. I agree to all of your rules."
                t "Now it's time to get to the business."
                t "My dick's aching for that pussy."
                t "Come here..."
                scene v14-68 with hpunch
                b "Ahh.."
                b "Hey, be gentle with me."
                "Turan grabbed Banu hard and pulled her to the bed with force."
                scene v14-69
                "Now Turan's dick was fully erect touching Banu's abdomen."
                "Banu was trying to concentrate not to moan and give him the satisfaction."
                b_ "I can't enjoy this. No matter what he does I should keep my voice down."
                b_ "I can't stand to see pleasure in his face. I feel weak when he grins looking at my eyes."
                b_ "I hope that he'll orgasm soon and I leave this disgusting room."
                scene v14-70
                "Turan again grabbed Banu by her legs hard and pulled her to himself."
                t "It's time baby, are you ready for this?"
                b "Hey, I told you to be gentle with me."
                t "I'll try baby."
                scene v14-71
                "Turan slowly pushed the tip of his cock in to Banu's already wet pussy."
                b_ "Why it feels this good. It's just the tip of his penis. It feels fatter than it was last time. Did it get bigger?"

                t "Girl, your pussy gets tighter every day I see."
                t "Why are you looking other way. You don't wanna see this?"
                scene v14-72
                b_ "Oh my God..."
                t "I see that you don't want to show me the lewd expression in your face. "
                t "Just don't tell me you don't enjoy this. Your cunt is burning. It's flooding inside."
                scene v14-73
                b "Hey don't push it so deep. It's hurting me."
                t "Cool down girl, It's okay."
                b "I said don't push it's reaching my womb. It's hurting me. Just finish it."
                show turanfucksbanuv141
                b "Ahh.."
                b "Hey slower I said..."
                "Turan was not listening to her anymore. His dick was stimulating the deepest parts of her vagina."
                "Banu was trying hard not to moan and give Turan the sign of her defeat."
                t "Look at me bitch. I want to see that expression. You have no idea how lewd you look right now."
                t "You don't admit it but your cunt is begging to be fucked."
                show turanfucksbanuv141angle
                t "Come on, look at me. I wanna see your face."
                t "Your pussy squeeze my dick so hard. "
                t "Do you do that on purpose? Do you want me to finish that soon?"
                t "I'll fuck you until you can't walk, bitch."
                scene v14-74
                "Banu was at her limit. She had no power to hold it anymore."
                b_ "I can't do this. He's breaking me...I'm melting. This is just too much for me..."
                scene v14-75 with vpunch
                b "AAAAAAHHHHHHHhhhhh...."
                b "Oh my God...."
                b "I'm cummingg....."
                b "Ohhhh...."
                scene v14-76
                b "Please, slower. Fuck me slower. It's too much. "
                t "That's what I wanted to hear. Your soft voice. It's music to my ear."
                b "Please, stop. Let me take a break."

                scene v14-77

                t "Well, if you want break, I'll give you that."
                t "Do you like to do it on the sofa?"
                b "What? What are you talking about?"
                t "Come here."
                scene v14-78 with hpunch
                b "Hey stop it, put me down."
                t "You're so light Banu. You're really in a good shape."
                b "Don't you hear me?"
                scene v14-79
                b "Damn you..."
                "Turan carried Banu to one of the armchairs and just threw her roughly on the armchair."
                scene v14-80 with hpunch
                b "Are you mad? "
                b "How you dare to treat me like that?"
                t "Shut your fucking mouth. I've enough of your talking."
                t "Now spread your legs.."
                b "What...?"
                scene v14-82
                "Turan quickly got into the position and stuck his fat cock into her pussy."
                b "Oh my God..."
                show turanfucksbanuv142
                t "I know how to shut your mouth, bitch."
                t "Do you like this?"
                b "Please, be gentle...ahhh...it's so deep..."
                b_ "I can't think straight while he's inside me. It's melting my brain."
                b_ "I can't reject him. I can't go against him."
                scene v14-81
                b "Please, finish already..."
                t "Damn bitch, you needed this."
                t "You have to see your face now, stupid cunt."
                scene v14-83
                b "Please, finish it already....ahhh...I have to go home.....AAAHHH...please slower..."
                t "Don't worry. I'll give you my cum soon, but first I want you to look at yourself in the mirror."
                scene black with dissolve
                t "Come here..."
                t "Now bend over..."
                b "Please, Turan. I've no power left."
                scene v14-84 with dissolve
                t "That's it. Now look at yourself."
                b "Please, don't touch me there...ahh..."
                t "Put your hands on the mirror like that..."
                scene v14-85
                t "That's right."
                "Turan started to rub Banu's clit furiously."
                b "AAAAHHhhhhhhh....."
                b "Please, Turan. I can't stand this anymore, please finish it already..."
                t "So you are asking me to fuck you?"
                b "Yes, do it already."
                t "Ask properly Banu."
                b "Fuck me, Turan. Stop teasing me. Fuck me, please."
                t "That's better."
                scene v14-86
                b "OOOHhhhhh.."
                "Turan positioned himself behind Banu and entered her with a powerful thrust."
                t "If you want it that bad, then take it..."
                show turanfucksbanuv143
                t "Take it, slut. Take it..."
                b "UUUUhhhhh.."
                t "You're howling like an animal..."
                t "You must really like it."
                t "Stop howling like that or the neighbors will come and interrupt us."
                b "Please..."
                show turanfucksbanuv143angle
                b "Please, Turan. I can't stand like this. "
                b "Ohh....I'm going to collapse...."
                t "Your legs are shaking."
                t "You really enjoyed my cock. "
                t "Let's see if you can stand it if I increase the pace a bit."
                scene v14-87
                b "Oh my God....AAAAAAHhhhhh..."
                t "Take it bitch."
                t "Arrrrgg...."
                t "Take my cum."
                scene black with fade
                t "Oohhhh....shit.."
                b "Ahhhh...."
                scene v14-88 with dissolve
                t "Ohh shit, that was good. I knew you wouldn't be able to hold it."
                t "Damn look at you. I messed your ass a little bit."
                scene v14-89
                t "Damn girl, you look so sexy with my cum on your ass."
                b "You're a brute."
                b "Hand me some paper at least. "
                t "You can take a shower once I'm finished with you."
                b "What?"
                scene v14-90 with hpunch
                b_ "Ohh shit...he just came but it's still as hard as rock."
                b_ "How this is possible?"
                b "Turan, please stop it. I have to go. I'm being late."
                "Banu knew that Turan was not going to listen to her. "
                "She knew that telling him to let her go was a waste of time. "
                t "Now get ready for the next round..."
                scene v14-91 with vpunch
                "After a few seconds Banu found herself pinned to the bed by Turan's large heavy body and getting pounded by his fat cock."
                scene v14-92
                "A strong eye contact and powerful thrusts made Banu melt that she took her eyes off his eyes."
                "She felt so weak and feminine that she wanted to be made love to and her lips wanted to be kissed."
                scene v14-93
                "Turan again increased the speed pushing his massive penis all the way back and forth inside Banu."
                scene v14-94
                b "AAAhhhh..."
                b "No please not there...ahh...don't hold me there..."
                b "AAhhhh...I am sensitive there, Turan, please..."
                scene v14-95
                "Turan had found Banu's sensitive spot, her belly button."
                "As he pushed down her belly button Banu reached the climax and had a very powerful orgasm that was building while she was being fucked."
                scene v14-96
                "One more time Turan came o her pussy while she was still having an orgasm."

                t "I bet you'll never forget this evening."

                scene v14-97
                t "See you next time, baby. Go and clean yourself. Your husband is now waiting for you. "
                "Turan left her on the bed with her pussy gaping and covered in cum."
                "She stayed in bed for a while coming to her senses before she realized that she had to hurry."

                scene black with dissolve
                ""

    stop music

    scene v14-98 with Dissolve(3)
    play music "audio/action.mp3"
    "Banu was suspected about Leyla's behavior lately."
    "Her unusual visits at night bothered Banu so she decided to follow her to see where she goes. "
    scene v14-99
    b_ "Again with an outfit like that God knows where she goes."
    b_ "This girl knows how to make me crazy."
    b_ "She doesn't have any friends living in this building."
    b_ "Today I'll find out..."
    scene v14-100
    "Banu was following her daughter with careful steps and keeping the distance so she doesn't see her."
    "Leyla didn't suspect anything and think that her mother is actually smarter than her."
    scene v14-101
    "She watched her daughter enter the building and then quickly followed her."
    scene v14-102
    "Leyla entered the aisle and walked till the end."
    "Banu waited for her to knock the door in the other side of the aisle."
    scene v14-103
    b_ "If it turns out to be a boy I'll kill him."
    b_ "I hope you don't meet any male friends here. "
    b_ "You've always been a good girl but why did you change?"
    b_ "Keeping secrets from your mother, secret visits, revealing outfits..."
    b_ "I'll put an end to this..."
    scene v14-104
    "Somebody opened the door for Leyla but Banu didn't see the person inside."
    b_ "Who could that be?"
    scene v14-105
    "Banu approached and knocked on the door."
    "She waited a bit and knocked on the door again."
    "..."
    scene v14-106 with hpunch
    "She was shocked to see the similar figure in front of her."
    "Ruslan, her stepson was standing there with a bold face. He didn't seem happy to see Banu at all."
    scene v14-107
    stop music
    b "What the hell is happening here? Where is Leyla?"
    r "You always ruin the fun. You're a party pooper."
    b "What are you talking about?"
    scene v14-108
    b "Hey, Leyla....come here quick."
    scene v14-109
    b "Now explain to me. What's happening here?"
    "Leyla didn't respond rather blushed."
    r "I told you. We've organized a party with close friends. Now we're waiting for them. "
    b "You shut up. It's not a party time. You can fool your dad like that."
    scene v14-110
    b "Will you answer me Leyla? I'm talking to you."
    b "When did you start lying to your mother?"
    b "Now you go straight home. We'll talk about this once I reach home. "
    scene v14-111
    "Without saying a single word Leyla quickly left the room."
    b "It's time to put an end to this. You better not come home today."
    r "What? What's your problem with me? "
    b "Now you'll see."
    scene v14-112 with hpunch
    play music "audio/tension.mp3"
    b "YOU LITTLE BASTART!"
    r "Heyyy!"
    "Banu pushed Ruslan with all her strength that he touched the wall behind him. "
    scene v14-113
    b "How many times I told you that stay away from Leyla?"
    b "Now tell me. Did you touch her?"
    b "Answer me!"
    scene v14-114
    b "I swear to God if you touched her I'll break your hand and then I'll send you to jail."
    b "You know what will happen to you there? "
    b "Once they learn that you raped your sister they'll make you faggot."
    b "They'll use you as their sister. They'll fuck your ass."
    b "Now I'm telling you one last time. Stay away from her!"
    scene v14-115
    r "Enough of this shit. You know what, I fuck her!"
    r "I've been fucking her for the last month. She's a slut you know that? She's like you and she craves for my big dick."
    scene v14-116
    b "Stop that...She's not such a girl..."
    r "She's a slut and you have to accept it already."
    r "She's a fucking slut just like her mother."
    scene v14-117
    r "You can't deny it. It's in your DNA. "
    r "You can't reject when you see a big cock. "
    r "She's screaming when I push all the way inside her. She can't get enough of me."
    r "No matter how hard you try she'll still come to me. You can't stop her."
    scene v14-118
    r "But I may leave her alone only if you agree what I say."
    b "What?"
    r "If you deal with me, I'll stay away from her I promise."
    b "What kind of deal?"
    r "If you make me cum just once that will solve all your problems. I'll stay away from her forever."
    b "What do you mean? Make you cum?"
    r "We'll meet at the hotel tomorrow and you'll wear the most sexy lingerie you can get."
    r "That's all I want from you. You'll make me cum with your hands and the task will be completed."
    scene v14-116
    b "I can't believe this. Do you even understand what you ask your mother?"
    scene v14-118
    r "Stop that shit already. You're not my mother."
    r "Now what do you say?"
    r "If you agree, I'll stay away from Leyla forever."

    scene v14-119

    b "That's it. Kamil's the only reason that I don't send you the fucking jail."

    b "But you won't live in that house. I'm telling you this. I'll get you banished no matter what."

    b "Little bastard! You'll be living in the streets soon."

    scene v14-120
    stop music

    r "Hey wait..."

    b "You may not come home today."

    b "I told you..."

    scene black with Dissolve(3)
    centered "{size=+120}A visit{/size}" with Fade(0.5, 0.5, 5)
    scene v14-226
    play music "audio/action.mp3"
    "The doorbell rang and Kamil went to open the door while Banu was busy cleaning the house."
    k_ "Who could it be this time?"
    scene black with dissolve
    k "Oh, hey man what's up?"
    p "Hey..."
    scene v14-227 with dissolve
    p "I was just passing by. I needed to get my bike repaired. The oil is leaking obviously. "
    p "How do you do guys?"
    k "Like you see. Everything is fine thanks God."
    k "Don't stand here. Come in."
    scene v14-228
    p "So how do you do in selling apartments? "
    k "Nothing's changed. Still fighting with problems."
    "Polad asked some common questions and talked about Kamil's work a bit."
    "His main reason to visit was actually Banu."
    "He wanted to visit and see her but he couldn't ask directly Kamil about Banu."
    scene v14-229 with fade
    b "You're welcome, Polad. How are you?"
    p "Thank you Banu. I'm fine and how do you do?"
    scene v14-230
    "Banu ignored his question and she didn't even shake his hand like usual and rather asked."
    b "So what's the reason of your surprise visit?"
    "Banu's cold behavior touched Polad and he felt that Banu was not happy about his visit. There was something wrong."
    scene v14-231
    p "I came to say 'hi'. I hope I'm not bothering you. "

    k "Nah man, don't say that. You're always welcome."
    scene v14-230
    k "Banu, come on make tea for us."
    b "Okay..."
    scene v14-231
    k "Come Polad, tell me about your business."
    p "I'm coming, I'll wash my hands..."
    scene v14-232
    "Polad noticed that this was a different Banu and she was being so rude to him."
    "He followed and stopped Banu on the way to kitchen."
    scene v14-233
    stop music
    p "Okay, I'm listening. Tell me what's the problem?"
    b "Problem is you. Why do you come here?"
    p "What do you mean why? I always come here."
    scene v14-234
    b "This can't continue Polad. I saw how you look at me every time. "
    b "You shouldn't be interested in me like this. This's not normal. I don't want to risk my marriage so please stop this."
    p "If my visit bothers you like that it means that you're feeling something. I know it Banu."

    scene v14-235
    b "Just stop it. You're putting my family under risk. "
    b "As a favor I'm telling you not to go for this."
    b "This will be harmful for both of us."
    p "If you tell me that you hate me right now, I'll never come here again. But you can't say that because you love me."
    b "Come on Polad. You're getting everything complicated."

    if followpolad == True:

        scene v14-236
        p "You say you don't want me to come here but you let me fuck you."
        b "Please, stop that."
        p "I know that you love me. You don't love him. You'll never do."
        p "And when he fucks you, you'll think about me."
        scene v14-237
        b "Okay, I'll tell you the truth, I didn't like it when we had sex. I hated it and that was the biggest mistake I made."
        b "Are you satisfied now?"
    b "Let's put an end to this. Now go back to Kamil. He's waiting for you."

    scene v14-238 with fade
    k "Banu was tired. She worked all the day so that's why she acted cold. I hope you don't get offended."
    p "I see. It's not a problem."
    scene v14-239
    "Banu entered the room with a bold look on her face. She glanced at Polad then moved and sat next to Kamil."
    b "Now I realized that we don't have any tea left."
    scene v14-240
    k "Ohh, what a shame!"
    k "Sorry Polad for that. Do you want anything else to drink."
    p "No, don't worry. I'm fine."
    "Banu was thinking about what Polad said earlier and was still angry at him."
    "She was looking for ways to make him suffer and suddenly a strange idea came to her mind..."
    menu:
        "Leave them alone":
            $ banukisskamilinfrontofpolad = False
            $ renpy.block_rollback()
            scene v14-241
            b "Alright, I'll be in the kitchen..."
            b "I hope your conversation won't last forever because we have something to discuss, Kamil."
            b "After you say goodbye to our guest, we'll talk about it."
        "Kiss Kamil while Polad watching":





            $ banukisskamilinfrontofpolad = True
            $ renpy.block_rollback()
            play music "audio/sexy.mp3"
            scene v14-242
            b "Can I join your conversation? I'm really interested what you're are discussing."
            b "Kamil and I share almost everything. "
            b "I wish every woman a man like Kamil. He's understandable, kind and he's got a great hairstyle. I love that even more."
            scene v14-243 with hpunch
            "Banu suddenly leaned towards Kamil and started kissing his lips."
            "Banu's behavior caught Kamil by surprise and he was totally unaware of the situation."
            b "Ummm...He kisses so good."
            k "Banu..."
            scene v14-244
            k "What're you doing?"
            b "Kamil's always passionate like this. You won't believe if I tell you how wild he is in the bedroom."
            k "It's enough Banu. Get out of the room."
            stop music
            b "But why?"
            scene v14-245
            p "Don't worry Kamil. Banu's always been like this. Sometimes she becomes so naughty."
            k "..."






    stop music


    scene black with dissolve
    centered "{size=+120}The graveyard{/size}" with Fade(0.5, 0.5, 5)
    scene v15-1 with dissolve
    play music "audio/intro.mp3"
    "It was quite a while that Banu hadn't visited her beloved deceased husband."
    "Banu used to visit Alper's grave very often but recently she got her head so busy that she could even forget Alper who was still the most precious person for her."
    scene v15-2 with dissolve
    "Kamil didn't know about Banu's visits to the graveyard. She didn't let him know about it because she was not sure Kamil would be happy about it or even let her visit her dead husband."
    "At least Kamil was her husband and he wouldn't be happy if he knew Banu still didn't forget about Alper."
    "So Banu used to come to the graveyard to be with her beloved one and talk to him some time without Kamil knowing about it."
    scene v15-3
    "She was not afraid of coming here alone in the evenings because she didn't want anybody to see her and wanted to have alone time with Alper."
    "She was now here standing in front of Alper's grave. The grave stone was a regular stone and got dirty from the humidity because of no attention."
    scene v15-4
    b "I'm really sorry that I can't visit you often recently."
    b "A lot of things happened to me recently but I managed to survive."
    b "Life is so hard without you..."
    scene v15-5
    b "I know that I made mistakes and I've been so weak but I believe that I'm in the right way now."
    b "Kamil's a nice man. I feel his protection all the time and he loves me. "
    scene v15-6
    b "You know that he can never replace you. "
    b "I'll always belong to you in this life and in the next one. My body and sould will always belong to you."
    scene v15-7
    b "I'd never let him touch my body but...he's my husband now and he deserves attention from me."
    b "Please, don't call this cheating. It's not like that."
    b "He can never touch my body like you did and the connection between Kamil and me is only physical. He's just my husband."
    scene v15-8
    b "I know that I have so many mistakes.."
    b "I'm not a complete pure woman. I've been dirty. My spirit has been touched by dirty stuff. Please, forgive me!"
    scene v15-9
    b "Once you left me, my weak body started to seek attention. "
    b "Once you stopped feeding me with your precence, I couldn't help but searched attention elsewhere."
    b "I touched my body and I enjoyed it."
    if banuturansexfirsttime == True:
        b "I let another man have my body. "
        b "He was not my husband, Kamil."
        b "I know how degrading this is but I enjoyed his touches..."

    if followpolad == True:
        b "I'm sorry to confess this but I betrayed you with your best friend..."
        b "Yes I did it with your best friend, Polad."
        b "We both betrayed you. Now you know that how awful I've been."


    if banutakethebetfuckmurat == True:
        b "Once I got drunk. I betrayed my religion. I couldn't control myself and let a boy younger than me enjoy my body."
        b "I was so desperate. I couldn't control my urges and I engaged in sex with a man."


    b "My body got so horny after you left me and I sometimes couldn't control it. "
    b "I touched my bare body. I dreamt about dirty things. I dreamt about other men..."
    b "Please, forgive me because I've been so dirty and bad. "
    b "Please, don't look at me like that. You're that man that my body and soul belong to and you know that."
    b "I have to leave now but I'll come back and one day we'll be together forever..."
    scene v15-10 with fade
    "Banu was so relieved after confessing to Alper but at the same time so embarrassed to look into his eyes."
    "She hated herself for a moment that she's been with another man other than Alper and she had to come visit him secretly."

    scene v15-11 with fade
    "But it was too late. Banu had a new life now."
    "Alper didn't exist anymore. No matter how hard Banu tried to stay with him, life pulled Banu away from Alper every single day."
    "Banu was changed. She was not the same Banu that Alper dated, not the same Banu that blushed and ran away when Alper tried to kiss her."
    "It was fortunate for Alper that he didn't see the changed Banu..."
    "...or maybe he did..."
    stop music
    scene black with Dissolve(3)
    ""
    centered "{size=+120}At home{/size}" with Fade(0.5, 0.5, 5)
    scene v15-223 with blinds
    play music "audio/tension.mp3"
    "Banu sat on the sofa with a troubled look on her face, her hands folded in her lap."
    "Kamil stood in front of their already adult son scolding him for what he had done."
    scene v15-224
    k "What have you turned into? I closed my eyes everything else you've done but this is just insane."
    k "How could you do something like that to your sister?"
    b "His actions lately affecting our home and my daughter. I think it's time already to send him away home."
    b "This would be better for both him and us."
    scene v15-225
    r "What's going on here? Are you trying to get rid of me?"
    b "Ruslan, it's not like that. We just can't tolerate your behavior anymore."
    r "I knew it! You always wanted to get rid of me. You never cared about me."
    k "That's enough, Ruslan. You need to respect your mother and our rules."
    r "I can't believe this! You're just like her, dad. You're always on her side!"
    scene v15-226
    r "You just want to get rid of me, don't you? You can't stand having me around anymore!"
    k "Enough! Both of you! Ruslan, you have been behaving terribly lately and you need to take responsibility for your actions."
    r "I can't believe you're taking her side over mine! You always do this, you never listen to me!"
    k "That's it. I've had enough of your behaviour."
    scene v15-227 with hpunch
    "Kamil couldn't take it any longer and slapped Ruslan so hard that he lost stability and fell to the ground."
    scene v15-228
    b "You deserved it, Ruslan."
    "Ruslan was shocked by his father's action and surprised how his father support and comply everything that Banu said."
    "He looked bitterly at Banu."
    scene v15-229
    b "This is for your own good, Ruslan."
    b "The streets will teach you a lot of rules that we can't teach you."
    r "Are you happy now? Bitch!"
    scene v15-230
    stop music
    k "That's it, I've had enough. You're leaving this house right now."
    r "Fine, I'll leave! I don't need any of you anyway!"

    show black with Dissolve(3)
    ""
    centered "{size=+120}Banu and Kamil{/size}" with Fade(0.5, 0.5, 5)
    scene v15-82 with squares
    play music "audio/romantic.mp3"
    "In a softly lit bedroom, Banu and Kamil find themselves in a moment of intimacy."
    "The room is filled with a serene ambiance, with a hint of moonlight filtering through the partially closed curtains."
    "Banu is standing near the bed, wearing one of Kamil's shirts, which hangs loosely on her petite frame, emphasizing her delicate features."
    "Kamil, lying comfortably on the bed, gazes at Banu with affectionate eyes, captivated by her beauty. "
    scene v15-83
    "His admiration is evident as he appreciates how the shirt perfectly complements her, its fabric draping over her figure in a way that highlights her graceful curves."
    "Kamil's voice breaks the tranquility of the moment as he softly speaks, his words laced with tenderness..."
    stop music
    k "You look absolutely stunning in my shirt, Banu."
    "Banu's eyes meet Kamil's, sparkling with affection and gratitude. She walks towards the bed, her steps gentle and purposeful, until she reaches the edge."
    scene v15-84
    b "Your shirt feels so good in my body."
    b "But I think it's time to take it off."
    "Banu climbs onto the bed, settling herself beside Kamil."
    scene v15-85
    "They find comfort in each other's embrace, their bodies intertwined, as they engage in a heartfelt dialogue, their voices hushed and filled with warmth."
    b "You know, moments like these make me believe in the magic of love. It's as if the world fades away, and all that matters is you and me, together."
    k " I feel the same way, Banu. When we're together like this, everything else loses its significance. It's like we create our own little universe, where nothing can touch us."
    b "You bring out the best in me, Kamil. Your presence makes me feel stronger, more confident. With you by my side, I feel like I can conquer the world."
    k "And you, my love, inspire me every day. Your kindness, compassion, and unwavering support remind me of the beauty that exists in this world. You make me believe in myself."
    b "I'm grateful every day for the love we share, Kamil. It's a rare and precious gift, and I promise to cherish it with all my heart."
    k "And I promise to love and cherish you, Banu, for the rest of my days. You're my everything, and I'm grateful for every moment we spend together."

    scene v15-86
    b "And I want to break the boundaries. I want to spice things up a little bit."
    b "I believe that this will make our relationship stronger."
    k "Okay....I think you have something to tell me. So what is it?"
    b "I stumbled upon this fascinating game online! It's a challenge that I think we should try. If you win, I'll give you one thousand, but if I win, you'll give me one thousand. What do you think?"
    k "One thousand? Why do you need it? It's so much money."
    b "Come on, don't be this greedy."
    k "Alright but what are the rules?"
    b "Rules are simple. You'll have to make me have an orgasm before you cum."
    b "If you cum, you lose. You have three chances. If you cum more than two times, you lose."
    b "But if you make me cum before that, I'll give you one thousand. What do you say?"
    k "What?"
    b "It's just a fun game, and we can both enjoy the thrill of competition. Besides, think about the possibilities if you win!"
    menu:
        "Kamil gets angry":
            $ renpy.block_rollback()
            $ kamilagreetoplaythegame = False
            scene v15-116
            play music "audio/tension.mp3"
            k "Banu, I don't understand why you waste your time searching for these stupid games on the internet."
            k "I thought you knew me well enough to know that I'm a serious man."
            b "Kamil, it's not about wasting time. It's about finding ways to unwind and have fun. Everyone needs a break from seriousness now and then."
            k "Fun? We have responsibilities, Banu. We have real-life matters to attend to, and you're indulging in trivial games."
            k " It's frustrating to see you prioritize these pointless distractions."
            scene v15-115
            b "It's not about trivializing our responsibilities, Kamil. It's about finding balance and enjoying the little pleasures in life. "
            b "We can't be serious all the time. That's not healthy for our well-being or our relationship."
            scene v15-117
            k "I don't want to waste my time on these mindless games. I have goals to achieve, dreams to fulfill. I can't believe you don't see the importance of that."
            b "I thought you valued our happiness and shared experiences, Kamil. I thought you'd appreciate the effort I put into finding something that could bring us closer."
            scene v15-118 with fade
            b "Maybe I was wrong."
            k "Maybe you were. Maybe I made a mistake in thinking that we were on the same page. I'm a serious man, Banu, and I can't change that for the sake of a game."
            scene v15-119
            stop music
            b " I'm not asking you to change who you are, Kamil. I'm asking for understanding, for a willingness to explore new things together."
            b "But if that's too much to ask, maybe I need to reevaluate our relationship."
            "The tension hangs heavy in the air as they both grapple with their differing perspectives and the potential consequences of their disagreement."
            "Feeling the weight of the argument, Banu silently gathers her emotions and walks out of the bedroom, leaving Kamil to contemplate the impact of his words. "
        "Kamil agree to play":



            $ kamilagreetoplaythegame = True
            jump banu_challanges_kammil







    jump banu_challanges_kammil_continue
label banu_challanges_kammil_continue:



    scene black with Dissolve(3)
    ""
    centered "{size=+120}Coffee break{/size}" with Fade(0.5, 0.5, 5)


    $ banuwantstoteaseintern = False
    $ banustaysalittlelongerintern = False
    $ banuconfessapastsecrettokamil = False
    $ banusharedetailswithkamil = False
    $ banuorderthefood = False
    $ banupaysatseafoodrestaurant = False
    $ kamilholdbanufrombehindrestroom = False
    $ kamilwarnkamilbathroom = False

    scene v16-1 with blinds
    "Banu was busy organizing files neatly on the shelf. "
    "Just as Banu was immersed in her work, the door creaked open, and Samir walked in with an eager smile."
    "He carried two steaming cups of coffee with a touch of nervousness mixed with excitement in his eyes."
    "Banu had asked him to bring the coffees, and secretly, he was thrilled for this chance to spend some time with her."
    scene v16-2
    b "Oh, Samir! You brought the coffees. Thank you so much."
    sam "You're welcome, Banu. I wanted to make sure they were just the way you like them."
    b "I appreciate your thoughtfulness, Samir. You're doing great as an intern here."
    b "Please, put the coffees on the table and come join me on the sofa. Let's take a break and chat for a while."
    sam "Sure, Banu. I'll do that."
    scene v16-3
    "Samir carefully placed the cups on the table and walked over to the sofa, sitting down beside Banu."
    "She couldn't help but notice the subtle signs of nervousness etched on his face."
    "Banu recognized the signs and wanted to alleviate Samir's unease. She finished organizing her files and set them aside, giving him her undivided attention."
    b "Samir, I can't help but sense a bit of nervousness. Is everything okay?"
    sam "Oh, um, yeah, Banu. I'm fine. It's just... I don't want to make any mistakes in front of you. I want to do a good job."
    b "Samir, I understand how you feel. We all have moments of nervousness, especially when we're starting something new."
    b "But please remember, mistakes are a natural part of the learning process. What's important is that we learn from them and grow."
    sam "Thank you, Banu. I appreciate your understanding. I really want to make a good impression here."
    scene v16-13
    b "Ah, that's good. It's nice to have a moment to relax, isn't it?"
    sam "Absolutely. It's a great opportunity to learn from someone experienced like you."
    b "Thank you, Samir. I'm happy to share my knowledge and help you grow in your career. So, how are you finding your time here so far?"
    sam "It's been amazing, Banu. I've learned so much already, and everyone has been really supportive. Working alongside professionals like you is truly inspiring."
    scene v16-4
    b "So, Samir, let's talk about something a bit more personal. Love and relationships. What are your thoughts on that?"
    sam "Oh, love and relationships, right. Well, I think it's a complicated subject, you know?"
    sam "People have different expectations and experiences, and it can be challenging to navigate."
    b "I sense some hesitation, Samir. Is there something on your mind? Perhaps a personal experience you'd like to share?"
    sam "Well, honestly, it's not something I usually discuss, but I've had some mixed experiences. It can be confusing at times, and I'm still trying to figure it all out."
    b "I understand, Samir. Relationships can be complex, and it takes time to find what works for each individual. It's alright to take your time and explore what feels right for you."
    b "Samir, I'd like to discuss something with you. What are your thoughts on a situation where a young boy develops feelings for an older woman?"
    b "How do you think such a scenario should be approached?"
    scene v16-5
    sam "Oh, well, I don't see any problem with that, Banu. Age shouldn't matter when it comes to love, right? "
    sam "If two people genuinely care for each other, I think they should be allowed to explore their feelings, regardless of age."
    b "Samir, love is indeed a beautiful thing, but it's important to consider the complexities that can arise in relationships with significant age differences."
    sam "I guess I haven't really thought about it that way before. I just believe that love knows no boundaries, and if two people connect, age shouldn't be a barrier."
    b_ "Oh, Samir, you're so young and idealistic. It's clear that you still have much to learn and experience when it comes to matters of the heart."
    b_ "Your belief that love knows no boundaries is charming, but it overlooks the potential power imbalances, societal judgments, and practical challenges that often come into play."
    menu:
        "Banu wants to help him":
            $ banuwantstoteaseintern = False
            $ renpy.block_rollback()
            scene v16-6
            b "Samir, I've noticed that you tend to be quite shy, and I want to discuss this with you. "
            b "Frankly, I'm a bit frustrated with your shyness because it can hinder your personal growth and interactions, particularly when it comes to relationships."
            sam "Oh, I'm sorry, Banu. I didn't mean to frustrate you. Shyness has always been a part of who I am, and it's not something I can easily change."
            b "I understand that shyness is a part of your personality, Samir, but that doesn't mean you can't work on overcoming it or finding ways to manage it."
            b "It's essential to realize that shyness can hold you back from fully experiencing life and forming meaningful connections."


            scene v16-7
            sam "I don't think being shy is such a bad thing. I've always been reserved, and I've managed to get by just fine."
            b "Samir, I understand that you may feel comfortable with your shyness, but it's important to recognize that it can limit your opportunities."
            b "If you want to grow personally and establish strong relationships, you need to challenge yourself and step out of your comfort zone."
            sam "Why are you so against my shyness? It's a part of who I am, and I don't see why I need to change just to please others."
            b "Samir, I'm not asking you to change who you are at your core. I'm merely encouraging you to develop social skills and confidence so that you can fully express yourself and connect with others."
            b "It's not about pleasing others; it's about unlocking your own potential and fostering meaningful relationships."
        "Banu wants to tease him":




            $ banuwantstoteaseintern = True
            $ renpy.block_rollback()
            scene v16-8
            play music "audio/sidesex.mp3"
            b "Samir, I wanted to ask about your relationship with your girlfriend. Last time we spoke, you mentioned her. How are things going between you two?"
            sam "Actually, Banu, she's no longer my girlfriend. We broke up recently."
            b "Oh, Samir, I'm sorry to hear that. Are you okay? Do you want to talk about what happened?"
            sam "It's just that she felt I was too reserved and shy, that I didn't open up enough. She said she needed someone who could be more emotionally available and outgoing."
            b_ "Poor Samir..."
            b "I understand that this must be difficult for you. It's unfortunate that your shyness played a role in the relationship ending."
            sam "I guess you're right, Banu. Maybe I do need to work on being more open and expressive in my future relationships."
            scene v16-9
            b "Well, Samir, now that you're single, are you ready to dive back into the dating world and find yourself another girl?"
            sam "Oh, Banu, I think I need a little time to heal and focus on myself before jumping into another relationship. But who knows, maybe in the future, I'll be ready to give it another shot."
            b_ "He's so funny..."
            b "That's fair, Samir. Take your time, enjoy being single, and when you're ready, don't forget to put those newfound social skills and confidence to good use. Just remember, there's plenty of fish in the sea."
            scene v16-11
            "Banu, feeling a mischievous spark, decides to playfully tease Samir. She moves closer, intentionally invading his personal space. Samir, taken aback, starts to feel uncomfortable, shifting uneasily in his seat."
            b "Now, Samir, let's get a little closer for some girl talk, shall we?"
            sam "Uh, Banu, I think this is close enough. I can hear you just fine from here."
            b "Oh, come on, Samir, don't be shy. It's just a little chat between friends."
            scene v16-10
            b "So, Samir, let's have a little chat about girls. I know it can be a bit overwhelming, but I'm here to offer you some advice from my years of experience."
            sam "Uh, okay..."
            b "First things first, confidence is key. Believe in yourself and let your authentic personality shine. Girls are attracted to someone who is comfortable in their own skin."
            sam "Uh, I'll try my best to be more confident, Banu. It's just not something that comes naturally to me."
            scene v16-12
            b "So, Samir, I've noticed you've been quite attentive today. Is there something on your mind?"
            sam "Uh, well, I guess I... um... enjoy our conversations. You're really easy to talk to, Banu."
            b "Oh, Samir, you're such a charmer. I appreciate your kind words. You're a great listener, too."
            b "Well, Samir, it seems like someone has a little crush on their HR assistant. Should I be worried about the company's intern policy?"
            sam "No, no, Banu! It's not like that. I mean, I do like you, but it's just... um... a friendly liking, you know?"
            b "I see you're a grown up man already and you started to look at my ass. Do you like that?"
            sam "No! Banu...that was just..."
            b "I saw it, Samir. You can't deny that. Your bulging pants tell me that you're so excited about me."
            b "I'm sure that you dreamt about me and masturbated countless times thinking about me. "
            sam "Banu..."
            b "Well, you know that you can't have me but there's something that you can do. You're a man now and you need to release the sperm from your body."
            b "Do you know that I don't shave my pussy? Hehe now you know that. Jerk off your cock thinking about my pussy. You need it and I'm not against it."
            sam "No, no, Banu! It's not like that...."
            scene v16-13 with fade
            stop music
            b "Of course, Samir. I was just teasing you. Don't worry, your secret crush is safe with me."

    scene v16-5 with fade
    b "Samir, I really need those files for a project I'm working on. Did you bring them as I asked?"
    sam "Oh, Banu, I'm so sorry, but I completely forgot to bring them. They're still at home. I feel terrible about this."
    b "Samir, I needed those files today. It's crucial for the progress of the project. Is there any way you can retrieve them quickly?"
    sam "Actually, Banu, I live close by. If you'd like, I could go to my place and grab the files but I was thinking..."
    sam "How about coming over this afternoon to collect the files?"
    sam "Plus, it'll give you a chance to see where I live. "
    b "Well, since I do need the files and you're offering, I suppose it would be convenient."
    sam "Absolutely, Banu! Thank you for accepting my invitation."
    "Banu and Samir agree on the plan, with Banu feeling a mix of relief and curiosity about Samir's home."
    "They quickly discuss the logistics and set a time for the visit, ensuring that the work will continue smoothly. The invitation to Samir's home adds a touch of anticipation to their day."

    scene black with Dissolve(3)
    ""
    centered "{size=+120}Samir's home{/size}" with Fade(0.5, 0.5, 5)
    scene v16-14 with fade
    play music "audio/kometaback.mp3"
    "Banu arrives at Samir's home in the sunny afternoon, curious to see where he lives."
    "As she approaches the house, she notices that it is a small, old building with a charming, albeit weathered, exterior."
    scene v16-15
    sam "Hey, Banu! I'm glad you made it. Welcome to my home."
    b "Thank you, Samir. It's nice to be here."
    sam "So, this is our little garden. It's not much, but it's a nice spot to relax and enjoy some fresh air."
    b "It's lovely, Samir. I can see the care you put into maintaining it. It's a peaceful retreat."
    "Banu couldn't help but notice the age and wear of Samir's home, but she tactfully avoids bringing it up to spare Samir any further embarrassment."
    "She understands that their financial situation may have contributed to the condition of the house and doesn't want to make Samir feel uncomfortable about it."
    scene v16-16
    stop music
    meta "Samir, who is this young lady?"
    sam "This is my mother...Come and meet her, Banu."
    scene v16-17
    sam "Mom, this is Banu, my colleague from work. She's here to visit and spend some time with us."
    sam "Banu, this is my mom, Metanet."
    b "Nice to meet you, aunt."
    "Instead of offering a warm greeting, Metanet's face displays a disapproving expression. She immediately redirects her attention towards Samir."
    met "Samir, why are you bringing your colleague into the house? You know very well that we have our own responsibilities and chores to attend to."
    sam "Mom, Banu is just visiting. I invited her over to spend some time together. It's important to show hospitality and make her feel welcome."
    meta "Hospitality? Is that what you call it? Instead of helping me with the household tasks, you're gallivanting around with your colleague. It's high time you focus on your responsibilities here."
    "Banu feels a sense of discomfort witnessing the tension between Samir and his mother. She tries to remain composed, knowing that it is not her place to interfere in their family dynamics."
    scene v16-18
    b "Aunt, I apologize if my presence has disrupted your routine. I didn't mean to cause any inconvenience."
    meta "Your presence is not the issue. It's Samir neglecting his duties and prioritizing other things over his family responsibilities. We have our way of doing things here."
    meta "Well, Banu, it's quite usual I see for women to wear these tight jeans trousers nowadays. Don't you think it's a little inappropriate. We have different standards here."
    b "I understand, Aunt. Fashion choices can vary, and I respect that. I assure you, it's nothing disrespectful or inappropriate."
    scene v16-19
    meta "It's not about fashion, dear. It's about respecting our traditions and values. We have certain expectations when it comes to proper attire."
    b "I apologize if my attire doesn't align with your expectations, Aunt. I didn't mean to offend anyone. I assure you, my intention is to be polite and respectful."
    scene v16-20
    sam "Mom, let's not focus on Banu's attire. She's a wonderful person and a valued colleague. I invited her here because I enjoy her company."
    "Samir, sensing the tension between his mother and Banu, takes a step forward to defuse the situation and invites Banu inside the house."
    sam "Banu, why don't we go inside? Please, come in and make yourself comfortable."
    b "Thank you, Samir. I appreciate your hospitality."
    scene v16-21
    "Metanet, still harboring her concerns, watches as Samir and Banu walk into the house together. She remains hesitant and decides not to follow them."
    "Banu follows Samir into the house, but she notices that Metanet doesn't join them."
    "As she steps inside, she takes a closer look at the room and notices its dilapidated state. The furniture is worn, the walls are peeling, and dust collects in neglected corners."
    "Banu maintains her composure, not wanting to make Samir feel embarrassed or uncomfortable about the condition of the room. "
    b "Samir, your home has a certain charm. It feels lived-in and carries a sense of history."
    sam "Thank you, Banu. I know it's not the most glamorous place, but it's where I grew up. It may not look like much, but it's filled with memories and love."
    scene v16-22
    sam "Banu, I'm sorry about my mother's behavior earlier. She's going through a tough time, and I think she was just upset about something unrelated. It's not a reflection of how she feels about you."
    b "Samir, there's no need to apologize. I understand that people have their own struggles and emotions. I hope everything gets better for your mother soon."

    scene v16-23
    sam "Banu, would you consider staying a bit longer? I enjoy spending time with you, and I don't want our conversation to end just yet."
    menu:
        "Banu is in a hurry":
            $ banustaysalittlelongerintern = False
            $ renpy.block_rollback()
            b "Samir, I would love to stay longer, but I'm afraid I'm in a bit of a hurry. I really need those files we discussed earlier, so I can't stay for too much longer."
            sam "I understand, Banu. I'm sorry for keeping you waiting. Let me go and get the files for you right away."
            b "That would be great, Samir. I appreciate your help. Just grab the files quickly so I can take them with me and continue my work."
            scene v16-24
            "Banu observes Samir as he searches for the files, and a sense of pity washes over her. "
            "She can't help but feel a pang of sympathy for him and his family, realizing the financial hardships they must be facing."
            b_ "It's heartbreaking to see how they're struggling financially. The condition of their home and the challenges they face must weigh heavily on Samir's shoulders."
            b_ "He's just a young man trying to navigate his way through life, and yet he's burdened with so much. I can't imagine the difficulties they've endured."


        "Banu enjoys to stay a little longer" if banubad >= 300:
            $ banustaysalittlelongerintern = False
            $ renpy.block_rollback()
            scene v16-25
            b "Well, don't you think it's late?"
            sam "Banu, please stay a little longer. I enjoy our conversations and your company. It would mean a lot to me."
            b "Well, Samir, since you asked so nicely, I suppose I can stay a little longer. But remember, I have other things to attend to, so don't get too used to it."
            scene v16-26
            "Banu, feeling a sense of comfort and playfulness in Samir's home, notices his bed and decides to playfully walk over and sit on it."
            "With a mischievous smile, she takes a few steps towards the bed, her movements light and carefree."
            "Banu approaches the bed, her fingers lightly grazing the edge as she lowers herself onto it, settling in with a playful bounce. The bed feels soft and inviting, adding a touch of spontaneity to their interaction."
            scene v16-27
            "Samir watches Banu's playful actions, a mix of surprise and delight on his face. He finds her spontaneity endearing, and it brings a sense of warmth to the atmosphere."
            sam "Banu, you certainly know how to make yourself at home!"
            b "Well, Samir, it's all about being comfortable, right? And your bed looked too inviting to resist."
            sam "I'm glad you feel comfortable here. It's nice to have someone who can bring a sense of lightness to this place."
            "Banu's playful gesture breaks the tension that may have lingered, allowing both of them to relax and enjoy the moment. The simple act of sitting on Samir's bed creates an intimacy that brings them closer together."
            b "So, Samir, since I'm staying a bit longer, how about we play a little game?"
            sam "A game?"
            b "Yeash, come and sit with me."
            scene v16-28
            "Banu, feeling a sense of adventure, suggests playing a game of truth or dare, wanting to delve deeper into their connection. She looks at Samir with a playful glint in her eyes and extends an invitation."
            b "Let's play a game of truth or dare. It's a great way to get to know each other better. What do you say?"
            sam "Um, truth or dare? That sounds... fun, I guess. Okay, let's do it!"
            "They face each other, their knees slightly touching, as the game begins. Banu starts by taking the first turn."
            scene v16-29
            "Banu notices Samir's nervousness and she starts to really enjoy it while slightly caressing his knee with her fingers."
            b "Alright, Samir, truth or dare?"
            sam "Um, let's start with... truth."
            b "Alright, Samir. Here's my question for you. What's the most adventurous thing you've ever done?"
            "Samir takes a moment to think, his face lighting up with a mix of excitement and nostalgia."
            sam "Well, a few years ago, I went skydiving with my friends. It was an adrenaline rush like no other, and I still remember the feeling of jumping out of the plane. It was both terrifying and exhilarating at the same time."
            scene v16-31
            sam "Alright, Banu, truth or dare?"
            b "I'm feeling brave today. Give me the truth, Samir."
            sam "Alright then, here's my question. What's the most embarrassing thing you've done with your husband?"
            scene v16-29
            "Banu's eyes widen, caught off guard by the question. She blushes, realizing she'll have to share a personal and potentially embarrassing moment from her own experiences."
            b "Well, if you wanna hear it, here it comes."
            b "A few years ago when we were having sex, he tried to do me from behind, you know what I mean? "
            b "He tried to enter me from the back door. I could never let that happen of course."
            b "Do you know what happened next? He slept that night on the sofa. I tought him a good lesson that night."
            b "Are you satisfied now?"
            scene v16-30
            "As the game of truth or dare continues, it's Banu's turn to ask Samir an embarrassing truth. She takes a moment to think, her playful eyes scanning Samir, searching for a question that will challenge him."
            b "Alright, Samir, truth or dare?"
            sam "Well, I've survived a few truths so far. Let's stick with truth again."
            b "Alright, Samir. Here's my question for you. Who do you think about when you masturbate?"
            sam "Well, I don't actually masturabte so much...just one or two times in a month..."
            b "Come on, I know that you maturbate every day. I sense it when I look at you but that is not important. Answer my question?"
            sam "Well since we're so open like this...here's the truth. I think about you, Banu!"
            b "Wow...I knew that."
            sam "Are you satisfied now?"
            b "I guess so."
            scene v16-31
            sam "Alright, Banu, truth or dare?"
            b "I'm up for a dare this time, Samir. Bring it on!"
            "Samir's eyes widen, realizing the daring nature of his dare. He takes a moment to gather his thoughts, wanting to push the boundaries just enough to create a playful and exciting moment."
            sam "Alright, Banu, for your dare... I dare you to take off one piece of clothing."
            scene v16-29
            "Banu's eyebrows raise in surprise, caught off guard by the audacity of Samir's dare. She giggles, a mischievous glint in her eyes."
            b "Oh, Samir, you're getting bolder, aren't you? Alright, challenge accepted!"
            scene v16-32 with hpunch
            "It took Samir by surprise that Banu actually started unbuttoning her shirt slowly from the bottom to the top."
            b "Do you think that I'll accept the defeat? Never!"
            sam "Banu...what are you doing?"
            b "What? Don't you want to see what is inside? "
            scene v16-33 with hpunch
            sam "Banu, you really did that..."
            b "Well, do you like what you see?"
            sam "I..I don't know...yeah of course I like it but...I just can't believe you did that..."
            b "This is only for you Samir. I know you wanted to see them so bad, didn't you?"
            sam "..."
            b "Do you want to touch it?"
            sam "Yeah, but..."
            b "Come on touch it already, I don't have much time."
            scene v16-34
            sam "It's so soft and warm, Banu."
            b "Do you like it?"
            sam "Of course I do."
            b "Feel free to play with it but don't squeeze it so hard."
            sam "No, I won't..."
            b "I see you're excited down there...Do you let me touch you?"
            sam "..."
            scene v16-35
            sam_ "Oh shit..."
            b "Wow, you're rock hard."
            b "I didn't know I make you excited like this."
            b "I should definitely be careful around you, big boy."
            scene v16-36 with hpunch
            met "Samir, what are you doing so long here?"
            "As Banu and Samir immerse themselves in the game, their playful banter is suddenly interrupted by the entrance of Samir's mother."
            scene v16-37
            "Banu quickly turned around to button her shirt while Samir confronted his mother."
            sam "Mom, why are you shouting again?"
            met "What do you mean why I'm shouting? Why hasn't she left already? What is she doing there."
            sam "Mom, she's just picking the documents related to work."
            scene v16-38
            b "I'm sorry, I took a lot of your time. I'm just about to leave."
            "Metanet's disapproval towards Banu is palpable as she enters the room."

            scene v16-39
            "Her cold gaze and distant demeanor make it clear that she does not hold a favorable opinion of Banu."
            "Metanet's brows furrow, and her lips form a thin line, indicating her disapproval."
            met " Samir, can I speak with you for a moment?"
            scene v16-40
            "As Samir follows his mother, Banu observes the interaction, noting the tension and the strained expressions on their faces. "
            "Banu's suspicions about Metanet's feelings are confirmed as she witnesses the whispered conversation between Samir and his mother."
            "Although unable to hear their words, Banu can sense the gravity of the situation by the disappointment etched on Samir's face."
            "Despite feeling the weight of Metanet's disliking, Banu remains composed, understanding that it's crucial not to escalate the tension."


    scene black with Dissolve(3)
    ""
    centered "{size=+120}Bedroom conversation{/size}" with Fade(0.5, 0.5, 5)
    scene v16-101 with pixellate
    play music "audio/chill.mp3"
    "Banu walked into the bedroom wearing her new sportswear, which accentuated her full figure."
    "She had just returned from shopping and felt energetic, hoping to bring some cheer to her husband Kamil, who seemed lost in thought while sitting on the sofa."
    "Banu leaned against the bedroom wall, observing Kamil sitting on the sofa from a slight distance."
    "With a mischievous grin on her face, she decided to initiate a playful exchange."

    b "Hey there, Mr. Sofa King. Enjoying the throne?"
    k "..."
    k "Well, someone's feeling extra punny today. But I must say, it's a pretty comfortable throne."
    b "Comfortable, huh? I thought I'd spice things up a bit. Maybe I should get you a crown and scepter to complete the look."
    k "Look, Banu, we have to discuss something."
    b "..."
    scene v16-102 with fade
    stop music
    "Banu noticed a shift in Kamil's demeanor, sensing that his playful mood had turned into something more serious."
    "She walked closer to him, standing near the sofa..."
    b "Hey, what's wrong, Kamil? You seem a bit off. Is everything okay?"
    k "It's just... I've been feeling uneasy lately. When you go to the gym, I can't help but notice that some men stare at you. It makes me uncomfortable, Banu."
    b "Kamil, I understand how you feel. But please know that my intention for going to the gym is solely to take care of my health and well-being. "
    b "I don't have any control over how others may behave or look at me."
    k "I know, Banu. It's just difficult for me to see others admiring you when you're mine. It triggers my insecurities, and I don't want to feel this way."
    scene v16-103
    b "Well, Kamil, maybe I should start wearing a disguise to the gym. A fake mustache and wig, so no one will recognize me! What do you think?"
    k "Banu, this is not a joking matter! It's not about disguises or making light of my feelings. I'm trying to express my genuine discomfort here."
    scene v16-104
    b "Kamil, I'm so sorry. I didn't mean to invalidate your feelings or make light of the situation. "
    b "I understand this is something that genuinely bothers you, and I should have approached it with more sensitivity."
    scene v16-105
    k "You don't understand it yet. I want you to stop going to that god damn place. If you want to stay in shape you can train at home. "
    k "Look at your clothes...Don't you see that you draw so much attention? It's not appropriate for you to dress like that. It just reveals your body."
    b "Kamil, I understand that you're feeling uncomfortable, but it's unfair to place the blame on my clothing. I dress in a way that makes me comfortable and confident, and it doesn't give anyone the right to disrespect me."
    b "It's better to address the behavior of others rather than dictate what I wear."
    scene v16-106
    k "I'm not blaming you, Banu, but can't you see that the way you dress draws attention? It makes me feel embarrassed, like I can't protect you or keep others from looking."
    b "Kamil, I understand your concerns, but I can't change who I am or compromise my personal freedom because of others' actions."
    scene v16-107
    b "We need to focus on building trust and addressing the behavior of those who disrespect boundaries, rather than restricting my choices."
    scene v16-106
    k "I just can't handle the constant scrutiny and attention you receive. It eats away at me, and I don't know how to cope with it."
    k "I don't trust the men out there. They see your shape and body and they want to sleep with you. Doesn't it bother you?"
    scene v16-107
    "Banu felt a mix of anger, frustration, and sadness welling up inside her as Kamil made the decision to prohibit her from going to the gym."
    "She understood his concerns, but she also valued her independence and the importance of maintaining her physical and mental well-being."
    b "As you say I don't have a choice here, do I?"
    k "..."
    b "Now I have to sacrifice my well being for your insecurities...fine."
    scene v16-108
    b "If this is what you want....I'll take these off now."
    k "I totally understand you being angry at me, Banu. "
    scene v16-109
    b "It's okay. If you want me to stop going to the gym. I'll do that."
    b "But you'll have to explain me the logic here."
    b "I'm tired of you blaming me for all your insecurities lately."
    scene v16-110
    "Banu's fury turned into a mix of frustration and empathy as she stood in front of Kamil, trying to understand the root of his concerns."
    b "So what? Are you satisfied now?"
    "She looked into his eyes and spoke with a determined yet compassionate tone."
    b "Kamil, I need you to be honest with me. What exactly about my behavior makes you feel so insecure? Is it the attention I receive from other men? Or is it the fear of losing me?"
    "Kamil shifted uncomfortably, feeling the weight of Banu's gaze upon him. He took a deep breath and mustered the courage to express his innermost fears."
    k "It's a combination of both, Banu. Seeing other men look at you, appreciating your beauty, it triggers my insecurities. I'm afraid that one day, I won't be enough for you."
    scene v16-111
    b "Kamil, I chose you because you are the one I love and want to build a life with. The attention I receive from others is superficial and fleeting."
    b "It's your love, understanding, and the connection we share that truly matters to me."
    k "But how can I overcome these insecurities, Banu? How can I trust that you won't be swayed by the attention of other men?"
    scene v16-112 with fade
    "As Banu sensed Kamil's vulnerability, she moved closer to him on the bed, gently placing her hand on his shoulder."
    "Her touch conveyed both comfort and encouragement, as she wanted to be a source of support during this challenging moment."
    b "Kamil, I understand that it takes courage to open up and share your insecurities with me. I want you to know that I'm here for you, and we'll navigate this together."
    "Kamil looked at Banu, appreciating her presence and the warmth of her touch."
    "But there was one thing that was still bothering him that it was hard to tell Banu."
    "Kamil gathered his courage, knowing that there was a question he needed to ask Banu—a question that had been weighing on his mind."
    scene v16-113
    "He took a deep breath, trying to find the right words to express his curiosity while respecting her emotions."
    k "Banu, there's something I've been wanting to ask, but please know that I ask with the utmost respect and understanding."
    k "Have you been with other men before me, besides your late husband?"
    menu:
        "Banu pretended to be offended":
            $ banuconfessapastsecrettokamil = False
            $ renpy.block_rollback()
            scene v16-114
            b "Kamil! Are you seriously asking me that?"
            b "How dare you question my fidelity and loyalty to you!"
            k "Banu, I just..."
            b "I thought you trusted me! How could you think that I could do something like that."
            b "You're my man and you should be confident but not ask such a disgusting question."
            scene v16-115
            "Kamil's face immediately reflected regret and concern, realizing that his question had unintentionally hurt Banu. He hurriedly tried to rectify the situation, his voice filled with genuine remorse."
            k "Banu, I'm so sorry. I didn't mean to doubt you. Please forgive me. I trust you completely, and I know I shouldn't have let my insecurity get the best of me."
            b "You should be mindful of how your question may impact me and I want you to close this topic forever."
            k "Banu, I'm truly sorry for my thoughtless question. I didn't realize how it could hurt you or undermine our trust."
            k "I promise to be more mindful of my words and actions. Please forgive me."
            b "..."
        "Banu confessed a past secret ":



            $ banuconfessapastsecrettokamil = True
            $ renpy.block_rollback()
            scene v16-116 with fade
            play music "audio/intro.mp3"
            "Banu felt a mix of surprise and curiosity as Kamil asked her about her past experiences."
            "She looked into Kamil's eyes, recognizing his genuine curiosity and desire to know more about her past."
            "While hesitant at first, she understood the importance of honesty in their relationship. Taking a deep breath, she decided to open up about her relationship with a boy from her high school days."
            scene v16-117
            b "I can guess why this is important to you."
            b "Well, if you want to know..."
            b "Kamil, I want to be open with you about my past. In high school, I had a relationship with a boy named Ali."
            b "We were young and experiencing the complexities of first love."
            b "We shared laughter, dreams, and supported each other during those formative years."
            b "However, as we grew older, we realized that our paths were diverging, and we eventually went our separate ways."
            k "Tell me everything, Banu."
            k "I want to know everything about it."
            b "Kamil, I must be honest with you about Ali. While we had a close relationship in high school, he had a reputation as a playboy. "
            b "He was charismatic and had a way with words that captured the attention of many girls. It was something I found intriguing and admired at the time."
            scene v16-118
            k "I appreciate your honesty, Banu. It's interesting to hear about Ali's reputation, but I'm curious why you were drawn to him despite knowing about this behavior."
            scene v16-119
            "Banu sighed, understanding the need for further clarification."
            b "At that time, Kamil, I was young and naive. I was captivated by Ali's charm and his ability to make others feel special."
            b "I admired his confidence and wanted to be a part of his world. Looking back, I realize it was more about the idea of him rather than a true understanding of who he was."
            k "So you've been with him?"
            b "If you're asking if I had sex with him....yes."
            b "I had sex with him several times."
            k "Oh.."
            b "He just made me believe that we could have a future together."
            b "At the end, I discovered his true self but it was late and he had fucked me many times already if this is what you want to know. "
            menu:
                "Banu share the details":
                    $ banusharedetailswithkamil = True
                    $ renpy.block_rollback()
                    scene v16-117
                    b "Kamil, I have to be honest with you. Ali had an amazing physique. He was athletic and took great care of his body. "
                    b "His dedication to fitness was evident, and I couldn't help but admire his physical strength and appearance during our time together in high school."
                    b "I'm sorry to admit this but he was amazing in bed. We had a great body compatibility."
                    b "I couldn't stop cumming as soon as he put his thing inside of me. His thing was one of the biggest I've ever seen."
                    k "I think that's enough, Banu."
                    stop music
                    b "I'm sorry, I just wanted to be honest."
                    k "I appreciate your honesty, Banu, but hearing about your admiration for his physicality does make me feel a bit insecure. I want to be able to provide you with the same level of attraction and fulfillment."
                    b "Kamil, I understand how my words might have affected you, and I'm truly sorry for any insecurity they may have caused."
                    b "It's important to remember that physical attraction is just one aspect of a relationship. While Ali had a striking physique, it's the deep emotional connection, understanding, and love we share that truly matter to me."
                "Banu skip the details":


                    $ banusharedetailswithkamil = False
                    $ renpy.block_rollback()
                    stop music
                    b "Kamil, I understand that you may have questions, but the specific details of my past relationship may not be necessary for us to dwell on."







            scene v16-118
            k "But what about your husband? How he reacted when he knew that you were not a virgin?"
            scene v16-119
            b "He didn't know that. I had a hymen repair surgery. I knew this was a stupid thing but I wasn't going to risk my relationship with Alper. I loved him so much."
            k "So you cheated on Alper?"
            b "Only for the sake of our relationship. I didn't want this stupid virginity to cause problems between us."

            b "Kamil, I feel that this conversation has become quite awkward, and I don't want it to affect our connection."
            b "Let's take a moment to acknowledge that it's uncomfortable and agree to move past it. Our love and the present moment are what truly matter."
            k "You're right, Banu. I appreciate your honesty in acknowledging the discomfort. Let's leave this topic behind and focus on the love and connection we share."


    scene black with Dissolve(3)
    ""

    $ banugotomuratsapartmentafterfun = False
    $ banuagreebowlingmurat = False




    centered "{size=+120}Murat{/size}" with Fade(0.5, 0.5, 5)
    scene v16-120 with blinds
    play music "audio/kometaback.mp3"
    "Banu, clad in her pink sportswear, took a solitary stroll through the sunlit city streets. The warm rays of sunlight cascaded down, casting a golden hue on her surroundings."
    "Despite the pleasant weather, her mind was clouded with thoughts, burdened by stress and a sense of loneliness."
    "As she walked along the bustling sidewalks, the sounds of city life enveloped her."
    "Conversations melded into an indistinguishable buzz, while the distant honking of cars echoed in the distance. The vibrant cityscape seemed to carry on with its rhythm, oblivious to Banu's inner turmoil."
    scene v16-121 with wipeleft
    "At the same time, about half a mile away from Banu, Murat was strolling through the city streets with his palpable vibrant energy."
    "A smile adorned his face, radiating positivity to those around him."
    "The sun's warm rays seemed to reflect his cheerful disposition, illuminating the path he traversed."
    scene v16-122 with wiperight
    "While Banu's face seemed to bear the weight of her worries..."
    scene v16-123 with wipeleft
    "Murat's face reflected an inner lightness, an unwavering positivity that he carried with him."
    scene v16-122 with wiperight
    "Banu's sad face, subdued and introspective, seemed to blend into the background of the bustling city, almost unnoticed amidst the vibrant colors and lively energy."
    scene v16-123 with wipeleft
    "Meanwhile, Murat's vibrant face drew attention, attracting the gazes of passersby, who couldn't help but be captivated by his infectious enthusiasm."
    scene v16-124 with fade
    "As Banu continued her lonely walk through the city, lost in her thoughts and weighed down by her emotions, her eyes suddenly met with a familiar face in the distance."
    "It was Murat, walking towards her with his characteristic smile and a twinkle in his eyes."
    "Banu's sad face, momentarily interrupted by the sight of Murat, softened with a flicker of recognition."
    "The corners of her mouth lifted slightly, reflecting a glimmer of hope amidst her troubled state. Her eyes, once clouded with sadness, now held a trace of warmth as they locked onto Murat's."
    scene v16-125
    "Murat, his energetic stride never faltering, approached Banu with an enthusiastic greeting."
    mur "Hey, Banu! Fancy running into you here. How's it going?"
    "Banu, surprised by the unexpected encounter, couldn't help but feel a sense of comfort in Murat's presence."
    b "Oh, Murat. It's been a tough day, but seeing you brings a little light to it. How about you? How's life treating you?"
    mur "I'm sorry to hear that, Banu. Life's been treating me well, but knowing you're having a rough time makes me want to offer support."
    mur "If you ever need someone to talk to or simply want a listening ear, count on me."
    scene v16-126
    b "You know, Murat, I have to admit something. You're really good with women."
    mur "Oh, really? Well, thank you, Banu. "
    b "You have this way of making people feel comfortable and appreciated. I've seen how effortlessly you connect with others, especially women. It's a gift."
    mur "I appreciate your kind words, Banu. "
    mur "But let's not forget, you have your own special qualities that draw people towards you as well."
    b "So, Murat, am I special to you? Or am I just another face in the crowd?"
    scene v16-127
    mur "Banu, you know you're more than just another face in the crowd. "
    b "Oh, really? And what makes me so special, Mr. Smooth Talker?"
    mur "Well, for starters, you have this unique ability to light up a room with your presence. "
    mur "Your warmth and genuine nature make people feel comfortable and valued. And your sense of humor always brings a smile to my face."
    mur "Hey, Banu, I was thinking it would be fun to grab a coffee and go bowling together. What do you say?"
    stop music
    menu:
        "Banu rejects":
            $ renpy.block_rollback()
            $ banuagreebowlingmurat = False
            scene v16-126
            b "Hmm, that does sound like fun, Murat. But I have to be honest with you. I can't help but feel a bit skeptical about your intentions."
            mur "Why that? I simply thought it would be enjoyable to spend some time together."
            b "Come on, I know your intention is not just to play bowling. I have noticed the way you look at me, and it makes me feel uncomfortable. Plus, I'm married, and I want to honor my commitment to my husband."
            scene v16-127
            mur "You're the way smarter than I expected. Just keep in mind that if you need support or bored, you have my number and I'm always here for you."
            b "Thank you again, Murat. I'll keep it in mind."
        "Banu agrees":

            $ renpy.block_rollback()
            $ banuagreebowlingmurat = True
            scene v16-126
            play music "audio/chill.mp3"
            b "I just want to let you know that I don't trust you because you're a man."
            b "But honestly, I'm quite bored, so I guess I'll give it a shot."
            scene v16-127
            mur "I understand if you're hesitant, but I promise to respect your choices."
            scene v16-126
            b "Alright, Murat. I'll take your word for it, but I want to be clear that this is strictly as friends. If at any point I feel uncomfortable or sense any inappropriate behavior, I'll have to end our outing."
            mur "Let's just have a good time and enjoy each other's company."
            b "..."
            scene v16-133 with pixellate
            "Banu and Murat found themselves seated at a cozy coffee table in the vibrant atmosphere of the bowling club. "
            "The sound of rolling balls and jubilant cheers filled the air, adding to the excitement that surrounded them."
            "As they settled in, the conversation flowed effortlessly, and Banu couldn't help but find herself genuinely enjoying Murat's company."
            mur "Hey, Banu, did you know that I have a black belt in bowling? They call me the Strike Ninja!"
            b "Strike Ninja? That's a new one! So, should I be worried about any karate moves with that bowling ball of yours?"
            mur "Watch out! I might just unleash my secret bowling technique - the unstoppable Flying Strike Kick!"
            b "Oh, please! I can't even imagine what that would look like. But I must admit, you have a way of turning bowling into a martial art!"
            mur "Well, you know what they say, Banu - the key to a perfect strike is a strong mind, a steady hand, and a killer sense of humor!"
            scene v16-134
            b "Well, you definitely have the humor part covered, Murat. You always manage to bring a smile to my face, even in the midst of a tense situation!"
            mur "That's the goal, Banu. Laughter is the secret ingredient that makes everything better. Besides, what's a game of bowling without a few good jokes and shared laughter?"
            b "You're absolutely right, Murat. Life should be filled with moments of joy and lightness, even in the simplest things like bowling. Thanks for reminding me to embrace the fun and laughter."
            scene v16-133
            mur "Come on, Banu! Let's start bowling already. It's going to be so much fun!"
            scene v16-134
            b "I have to be honest, Murat. I'm not really good at bowling. I don't want to embarrass myself."
            mur "Nonsense, Banu! Bowling is all about having a good time. Trust me, you'll get the hang of it in no time. Plus, I'll be right there to guide you through it."
            b "I appreciate your confidence in me, Murat. But I'm not sure if I can do it."
            mur "Come on, Banu..."
            scene v16-135 with fade
            b "Heyyy, okay I'm coming."
            mur "We'll figure it out together. Don't worry about being perfect. Let's just have fun and enjoy the experience."
            b "Okay, okay! I'm going, but you better be ready to witness my terrible bowling skills."
            scene v16-136
            mur "I can't wait to see what you've got, Banu! I have a feeling you'll surprise yourself."
            b "Alright, Murat, here I go. Any last-minute tips?"
            mur "You've got this, Banu! Just take a deep breath, aim for the middle pin, and give it a nice, smooth roll. Remember, it's all about finding your rhythm."
            b "Okay, I'll give it my best shot!"
            scene v16-137
            "Banu stepped forward to the edge of the lane, her focus intensifying. With a determined expression, she swung her arm back and gracefully released the ball. It glided down the lane, steadily rolling towards the pins."
            mur "Looking good, Banu! Keep going!"
            "The ball approached the pins, and with a satisfying thud, it knocked down several of them, leaving a scattered arrangement. Banu's eyes widened, and a mixture of surprise and delight spread across her face."
            scene v16-138 with fade
            b "I did it! I actually hit some pins!"
            mur "That was fantastic, Banu! You're a natural. See? I told you that you could do it!"
            b "Alright, Murat, it's your turn now. Show me what you've got! I bet you can't knock down all the pins in one shot."
            mur "Oh, Banu, you're underestimating my bowling skills. I'm so sure I'll get a strike that I'm willing to bet on it!"
            b "Really? You're that confident, huh? Alright, let's see what you've got. But don't be surprised when you don't get all the pins."
            scene v16-139
            "Murat positioned himself at the edge of the lane, holding the bowling ball in his hands. He took a deep breath, focusing his gaze on the pins ahead."
            mur "Watch closely, Banu. This one's for the skeptics!"
            "With a swift motion, Murat released the ball, sending it gliding down the lane with precision."
            "As if guided by an invisible force, the ball curved just at the right moment, striking the pins with a satisfying crash."
            scene v16-140
            b "No way! You actually got them all! I can't believe it!"
            mur "Told you, Banu! Never underestimate the power of a little confidence. Looks like I owe you a victory dance!"
            b "Fine, fine. You win this time, Mr. Bowling Champion. But let's see if you can keep up that perfect score throughout the game!"
            "Their playful banter continued as they completed their game, exchanging laughter and friendly competition. Murat's strike had left Banu in awe, but it only fueled her determination to improve her own skills."
            scene v16-141 with fade
            "As Banu and Murat continued playing their game of bowling, the atmosphere filled with excitement and laughter."
            "The joy they found in each other's company became evident as their friendship deepened through shared moments of triumph and lighthearted banter."
            "With each successful shot and strike, their connection grew stronger. Banu couldn't help but feel a sense of comfort and ease whenever she was around Murat, and the same sentiment seemed to hold true for him."
            "In a moment of exhilaration, Murat couldn't contain his excitement any longer."
            "As Banu celebrated another well-earned strike, he playfully and instinctively wrapped his arms around her from behind, pulling her into a warm, spontaneous embrace."
            b "Well, someone's feeling quite victorious, aren't they? I didn't know hugging was part of the bowling game!"
            mur "I couldn't help it, Banu! You're just too amazing at this. The thrill got the best of me!"
            b "Well, Mr. Hugger, be prepared for some tough competition. I won't let you win so easily!"
            mur "Oh, it's on, Banu! You better bring your A-game because I won't go easy on you!"
            "..."
            scene v16-128 with fade
            "After an exhilarating game of bowling, Murat couldn't contain his infectious energy and mischievous spirit. Holding Banu's hand tightly, he led her on a playful and joyous run through the city streets."
            "Banu, her face glowing with laughter and excitement, gladly followed along, fully immersed in the moment."
            "As they dashed through the bustling city, their laughter echoed in the air, catching the attention of passersby who couldn't help but smile at their infectious enthusiasm."
            "Banu's tired legs were evidence of their adventure, but her spirit remained uplifted and energized."
            scene v16-129
            mur "Come on, Banu! Just a little bit farther. I have a surprise for you!"
            b "You really know how to keep the fun going, don't you? I don't even know where we're headed, but I'm loving every moment!"
            "Their laughter intertwined with the rhythm of their footsteps as they navigated the winding streets, their destination looming ahead. Banu's heart raced with anticipation, wondering what surprise awaited her at the end of their spirited journey."
            scene v16-130 with hpunch
            "In a spontaneous burst of joy, Murat playfully grabbed hold of both of Banu's hands. With a mischievous smile, he began to twirl her around, gently spinning her in a circle."
            "Banu's laughter filled the air as her head spun with a delightful mixture of dizziness and excitement."
            b "Murat, what are you doing? You're going to make me dizzy!"
            mur "Just a little fun, Banu! Let's keep the laughter going and see if we can make the world spin!"
            "As Murat continued to twirl Banu, the world around them blurred, their laughter intermingling with the sounds of the bustling city. In that moment, time seemed to stand still as they embraced the pure joy of the present."
            b "Okay, Murat, you win! My head is spinning, but it's the best kind of dizzy. You really know how to make me smile!"
            scene v16-131
            "Banu, I have an idea. Why don't you come up to my apartment? I want you to be my guest, just for a little while. We can continue our fun and laughter in a more comfortable setting."
            "Oh... um, Murat, I appreciate the invitation, but I'm not sure. We've had a great time so far, but I'm not sure if going to your apartment is the right thing to do."
            mur "Banu, please reconsider. I genuinely enjoy your company."
            stop music
            menu:
                "Reject him":
                    $ renpy.block_rollback()
                    $ banugotomuratsapartmentafterfun = False
                    scene v16-132
                    b "Murat, I appreciate your persistence, but I know what accepting this invitation would imply. As a married woman, it wouldn't be appropriate for me to go to your apartment alone."
                    mur "Banu, let's forget about everything else for a moment. Come to my apartment and let's just have fun together. No worries, no obligations, just a chance to enjoy each other's company."
                    b "Murat, I can't do that. I appreciate your invitation, but I am a married woman, and it wouldn't be right for me to disregard my commitment to my husband."
                    b "I value our friendship, but I must prioritize my marriage and the trust that exists within it."



                "Go with him" if banubad >= 300:
                    $ renpy.block_rollback()
                    $ banugotomuratsapartmentafterfun = True

                    jump muratfucksbanuafterfunsexscenestaywithkamil

                    scene v16-132
                    b "Murat, I can't believe I'm agreeing to this, but okay. Just 5 minutes, and then I need to leave. No longer than that, okay?"
                    mur "Deal! I promise you won't regret it. Let's go!"
                    scene black with dissolve
                    "..."
                    scene v16-142 with dissolve
                    b "Wait...you're such a liar, Murat."
                    b "....mmmmp.."
                    mur "Your lips taste so good. I can kiss you all day."
                    b "You're going to choke me, maniac."
                    b "Is it your fisrt time kissing?"
                    mur "You're driving me crazy, Banu. I can't control myself with you."
                    scene v16-143 with fade
                    b "Mmmp...oh god...stop touching me there...ohh."
                    mur "You like this, don't you?"
                    b "We didn't agree on taking the clothes off, did we?"
                    scene v16-144 with fade
                    mur "Shhhh...just enjoy the moment. "
                    b "Your dick....it's touching me..."
                    mur "Damn Banu, you're kissing me so passionately. You must be craving this all the time you've been with me."
                    scene v16-145
                    b "Ahhh...you know what I need..."
                    b "Right there...ahhhh.."
                    b "Ummmmm...You got me so wet you tricky boy."
                    scene v16-146
                    "Murat was bending Banu backwards slightly and she was grabbing his neck not to fall off."
                    "Using the opportunity, Murat started rubbing Banu's pussy furiously and talking dirty to her making her crazy."
                    b "Ahhhhh...stop it...please, ahhh."
                    mur "I'll make you feel so good that your husband never done that to you."
                    mur "I'm going to make you feel like a real woman today. You'll scream and beg but I won't stop..."
                    scene v16-147 with fade
                    "After minutes Murat grabbed Banu taking her pants and bra off and sat on the sofa holding her on top of him. "
                    "While invading her mouth, Murat run his hands all over Banu's body, caressing her thighs, belly and breasts. "
                    "At this point, Banu could't help but reached her pussy with her hand stimulating her left out clit."
                    scene v16-148
                    b "Shit, I can't bear it anymore...Murat, please..."
                    mur "Tell me. What you want me to do?"
                    b "Please, make me feel good."
                    mur "You want my cock, don't you?"
                    b "My pussy is so wet now. I'm going to cum from your touches."
                    b "Please, take my pussy. Make me yours!"
                    scene v16-149 with hpunch
                    b "Ahhh...yeah like that.."
                    mur "You're such a lewd slutty wife, aren't you?"
                    b "Yesss, I'm a despicable, bad wife who needs a good punishment."
                    b "Call me whatever you want. I deserve that."
                    mur "You're a bad bitch enjoying my fingers deep inside of your married cunt. "
                    b "Ohhh...I can't take it anymore...I'm going to cummm....."
                    scene v16-150
                    mur "Look how slutty you are. You're cumming from a young man at your children's age fingering your pussy."
                    b "Please, stop it..."
                    b "Damn, you're so good at this. Fuck..."
                    b "I've never let my husband touch me like that."
                    mur "Go on, cum for me. I'm going to tease all of your slutty holes."
                    mur "I'm going to tease the shit out of you. You'll beg me to fuck all of your holes."
                    mur "Have you ever got your asshole fucked?"
                    scene v16-151 with vpunch
                    b "No! Don't touch me there. I warn you!"
                    mur "What? You're rejecting me?"
                    b "Shit, I'm serious, Murat. I've never let a man touch me there."
                    "Banu squeezed her legs so hard to prevent Murat teasing her asshole with his middle finger. "
                    scene v16-152 with fade
                    b "Ahhh..."
                    b "You're crazy...what are you doing?"
                    mur "You see? I'm full of surprises."
                    scene v16-153
                    mur "Mmmm...it's so delicious. Do you like it?"
                    b "Ohhh shit...stop it...it's so dirty..."
                    b "Oh god...you're hitting my spot."
                    b "You're eating it like your favorite breakfast...ufff.."
                    mur "Mmmm..this is my favorite meal of the day."
                    b "Oh my God...if you keep doing that....I won't be able to stop cumming."
                    mur "Don't hold it. Cum all over my mouth. "
                    b "Shit, you're so good with your tongue."
                    mur "Are you ready for the main course?"
                    scene v16-154 with fade
                    "Murat suddenly raised Banu's legs and put his dick on top of her pussy grinding it back and forth."
                    mur "You want this, don't you?"
                    b "Stop teasing me, please..."
                    mur "Shut up!"
                    mur "Tell me how you want it."
                    scene v16-155
                    b "I want it inside of me..."
                    "Murat continued teasing Banu's wet pussy with his fully erect curvy dick making her crazy."
                    mur "I want you to ask it properly."
                    b "Oh god...you're making me crazy..."
                    b "Put that fucking dick inside of me!"
                    mur "Tell me how bad you want it."
                    b "I want it so bad...please, my pussy aches for your big curvy dick."
                    b "Put it inside of my married unsatisfied pussy."
                    b "Fuck the shit out of me..."
                    scene v16-156 with hpunch
                    b "Ahhh..."
                    mur "That's it. I'm not gonna make you suffer any longer."
                    show sex
                    b "Fuck!...This feels so good..."
                    mur "I know what you want, baby."
                    mur "My dick fits so good inside of your wet pussy."
                    mur "Your pussy is just made for my cock."

                    show sexangle
                    b "Ohh fuck me...keep fucking me like that."
                    mur "Your husband is weak man probably. Leaving a pussy unsatisfied like this huh?"
                    b "Please, ahhh, stop talking about him..."
                    b "Keep fucking me like that, ahhh.."

                    show sexfast
                    b "Ohhhh shit..."
                    b "It's hitting me so bad..."
                    mur "Fuck...your pussy squeezes my cock so hard."

                    show sexangle fast
                    b "Oh my god, keep fucking me like that...ahhh..."
                    b "Your cock reaches my stomach...ohhh shit.."
                    mur "I'm going to destroy belly..."
                    mur "I can't believe you gave a birth from this pussy. It's so tight."
                    b "Fuck....I'm cumming....shit...."
                    scene v16-157 with hpunch
                    b "Shit...that was so intense."
                    mur "Your face tells it all."
                    b "You're the devil."
                    mur "I'm glad you liked that...but it's not over yet."
                    scene v16-158
                    mur "I have an idea. How about we try something new together?"
                    b "Wait..what?"
                    mur "It's something you've never done before, and I think it could be a fun and memorable experience."
                    b "No!...no way..."
                    scene v16-159
                    mur "But why not trying?"
                    b "I'm sorry, but I can't do that. It's just not something I'm comfortable with or ready for."
                    mur "Let's give it a try, just this once. I'm sure you'll love it."
                    scene v16-160
                    b "No I can't do that. I'm not comfortable with this you know."
                    mur "How do you know if you haven't tried it?"
                    b "Please, don't push me. I'm afraid of that."
                    scene v16-161
                    b "Heyyyy...stop it!"
                    mur "I promise you, it won't be painful."
                    mur "I'll make sure you're comfortable and at ease throughout the experience."
                    scene v16-162
                    b "I just said stop it! What are you doing?"
                    b "I can't do this!"
                    mur "Shhhh...your ass will love it."
                    scene v16-163
                    b "Ahhhhhhhh...Ay mama....it hurts...stop it!"
                    mur "Shhhh, I'll lubricate it good that you'll only feel the pleasure."
                    scene v16-164
                    b "Ahhhhhh..."
                    mur "That's it..."
                    b "It hurts so bad, please pull it out! Ahhhhh.."
                    mur "Don't worry. Your ass will get used to it."
                    show sex
                    b "Shit...Ahhhh..."
                    b "It destroyes my ass."
                    mur "You seem to like it."
                    show sexangle
                    b "Ohh yeah, don't stop...keep fucking my dirty asshole..."
                    mur "Your asshole is so tight. It squeezes my dick like hell."
                    mur "But I'll stretch it a bit more."
                    show sexfast
                    b "Ahhhhhh....yesss...pound my ass like that..."
                    b "Shit, I can't hold it. I'm going to pee."

                    show sexanglefast
                    mur "Your asshole belonges to me now. "
                    mur "I'll stretch it whenever I want."

                    scene v16-165 with fade
                    "Murat fucked Banu for hours in the ass hitting deep inside her with his long curvy dick."
                    "Banu's initial pain was replaced by a mixture of pleasure and pain afterwards giving her the best pleasure in her life. "
                    scene v16-166
                    "At this point, she couldn't stop her eyes rolling back and moaning like a whore while accepting full length of Murat's swollen cock from her back door. "
                    b "Ahhhh, it's hitting me right there..."
                    scene v16-167
                    b "Keep fucking me like that. Don't dare to pull it out now."
                    b "Oh my god...I can't hold it any longer...."
                    b "Shit, if you keep fucking..."
                    scene v16-168 with vpunch
                    b "Oohhhhhh...."
                    b "Damn...I'm..."
                    mur "Fuck, look at that."
                    scene v16-169
                    b "Fuck...I'm so sorry...It was just..."
                    mur "It's okay, Banu. You just enjoyed it a bit too much."
                    b "I'm really sorry...it was just an accident."
                    scene v16-170 with hpunch
                    "Murat looked deeply into Banu's eyes, a glimmer of excitement and anticipation in his gaze."
                    b "Murat, I have to go. It's late."
                    mur "For the next few hours, I want us to have an incredible time together."
                    b "But I really can't stay."
                    mur "We're having such a great time together, and I don't want it to end so soon."
                    mur "You belong to me for the next hours."
                    "Banu couldn't say a word as she felt Murat's dick in the enterance of her asshole again."
                    "It was too late to reject Murat again..."






    scene black with Dissolve(3)
    centered "{size=+120}The Dinner{/size}" with Fade(0.5, 0.5, 5)
    scene v16-171 with blinds
    play music "audio/chill.mp3"
    "Banu and Kamil entered the seafood restaurant hand in hand, their faces adorned with gentle smiles."
    "Banu, dressed in a modest yet elegant brown dress, gracefully glided through the establishment, her hijab adding a touch of spiritual reverence to her appearance."
    "Kamil, wearing white shirt as usual, complemented her with his strong and supportive presence."
    scene v16-172
    "They exchanged compliments, whispering words of admiration and endearment that only they could hear, cherishing the beauty they saw in one another."
    b "Kamil, you know I always have a soft spot for seafood. I can't wait to try out this restaurant!"
    k "I knew this place would make you happy, my dear. Your excitement is contagious. I'm glad we're here."
    scene v16-173
    b "You're just saying that because you know how much I love seafood, don't you?"
    k "Well, of course, I do! But honestly, seeing you enjoy yourself and having a good time is what truly makes me happy. Plus, I'm quite excited to try some delicious dishes myself."
    b "Oh, really? So, you're not just here to make me smile, but to indulge your own taste buds too?"
    k "Guilty as charged! But let's not forget the real reason we're here – to spend quality time together, strengthen our bond, and create beautiful memories."
    b "You always know how to say the right things, don't you? I'm grateful to have you by my side, Kamil."
    scene v16-174 with fade
    stop music
    "As Banu and Kamil engaged in their playful conversation, a well-groomed waiter, dressed in a crisp white shirt and grey trousers, approached their table with a friendly smile."
    scene v16-175
    "He stood near Kamil, making sure to maintain eye contact and convey his attentive demeanor."
    wait "Good evening, sir. Welcome to our seafood restaurant. I'll be taking care of you tonight. How may I assist you?"
    menu:
        "Banu order the food":
            $ renpy.block_rollback()
            $ banuorderthefood = True
            scene v16-176
            "As the waiter engaged in conversation with Kamil, Banu, noticing the dynamic, interjected politely, ensuring her voice was heard."
            b "Excuse me. I appreciate your recommendations, but it would be wonderful if you could include me in the conversation as well. We are here together, and I would love to be part of the decision-making process."
            wait "My sincerest apologies, madam. You're absolutely right, and I apologize for the oversight. I will make sure to address both of you equally from now on. Please forgive me."
            scene v16-177
            b "Thank you. I appreciate your understanding. Now, Kamil and I have decided. We would like to start with the grilled lobster with garlic butter sauce and also enjoy the seafood paella, please."
            wait "Excellent choices, madam. Is there anything else I can assist you with? Any specific beverage preferences or dietary restrictions?"
            b "We would love a bottle of your finest sparkling water, please. And as for dietary restrictions, we do not have any."
            wait "Certainly, madam. A bottle of sparkling water will be brought to your table shortly. Thank you for clarifying. If you need any further assistance or have any questions, please don't hesitate to let me know."
            b "Thank you."
            scene v16-178
            k "Banu, I was just about to ask you if you had any preferences or if you wanted to order anything specific. You know you can always let me know."
            b "I appreciate that, Kamil."
        "Banu stay silent":




            $ renpy.block_rollback()
            $ banuorderthefood = False
            scene v16-175
            "As the waiter engaged in conversation with Kamil, Banu stayed silent, observing their interaction."
            k "I'll have the grilled lobster with garlic butter sauce. And for my wife, she would like the seafood linguine with creamy white wine sauce, please."
            wait "Excellent choices, sir. We'll prepare the dishes accordingly. Is there anything else I can assist you with?"
            k "We'll have a bottle of your finest sparkling water, please."
            wait "Certainly, sir."

    scene v16-179
    "As the waiter finished taking their order, a brief moment of disagreement arose between Banu and Kamil regarding the payment."
    menu:
        "Banu lets Kamil pay":
            $ renpy.block_rollback()
            $ banupaysatseafoodrestaurant = False
            scene v16-179
            b "Oh, Kamil, let me take care of the bill this time. It's only fair."
            k "Banu, you know we've discussed this before. Let me handle it. I insist."
            b "But Kamil, you work so hard, and I want to treat you. Besides, it's my way of showing appreciation for everything you do."
            scene v16-181
            k "I appreciate your gesture, Banu, but as your husband, it's my responsibility to provide for our needs. Please, let me take care of this. It brings me joy to do so."
            b "You're right, Kamil. I understand. Thank you for always looking out for us. I'm grateful to have such a caring and supportive partner."
            k "And I'm grateful to have you, Banu. You bring so much love and happiness into my life. Let me take care of you."
        "Banu insists to pay herself":


            $ renpy.block_rollback()
            $ banupaysatseafoodrestaurant = True
            scene v16-180
            b "No, Kamil. It's important for me to contribute and show my independence. I am more than capable of taking care of us financially as well."
            scene v16-182
            k "I understand, Banu, but as your husband, it's my responsibility to provide for our needs. You know I don't like this."
            scene v16-180
            b "Kamil, being a responsible husband doesn't mean you have to take care of everything. We are partners, and I want to share in the responsibilities. Let me pay this time, and we can take turns in the future."
            k "Alright, Banu. If it's important to you, then I won't argue anymore."
            scene v16-179
            "Banu, pleased with her victory in asserting her dominance, smiled at Kamil."


    scene v16-183
    play music "audio/sensual.mp3"
    b "You know, Kamil, I can't help but be captivated by your charm. How did I get so lucky to have such a handsome and charming man as my husband?"
    k "Oh, Banu, you have a way with words that makes my heart skip a beat. But I must admit, I'm equally fortunate to have such a beautiful and alluring wife by my side."
    b "Flattery will get you everywhere, my dear. But it's not just your good looks that have me swooning."
    scene v16-184
    b "You know, Kamil, I can't help but notice how adorable you look when you get all shy and tense. It's like a secret side of you that only I get to see."
    "Kamil, feeling shy and slightly overwhelmed by Banu's teasing, mustered up the courage to express his discomfort."
    scene v16-185
    k "I think it's best if we keep our affectionate teasing for more private moments. It feels a bit uncomfortable for me to engage in such intimate behavior in a public place like this."
    scene v16-183
    b "You're right, Kamil. I didn't consider how our playful moments might affect others around us."
    scene v16-186
    "Banu, recognizing Kamil's concerns, decides to playfully lighten the mood by suggesting a different kind of adventure."
    b "You know what, Kamil? I was just about to head to the restroom, but I don't think I should go alone. How about you guide me there? It could be our little adventure within this restaurant."
    k "Banu, please, stop this for god's sake."
    b "Oh, come on, Kamil! It'll be harmless fun. Let's just enjoy this little adventure together. Trust me, it'll make our time here even more memorable."
    k "Banu..."
    stop music
    scene v16-187 with fade
    "Banu, with an air of confidence and grace, makes her way towards the restroom. Her steps are purposeful and elegant, as she moves with a natural sway in her hips. "
    "Her head held high, Banu exudes a quiet confidence that catches the attention of those around her."
    jump banuflashkamilrestroom

label banuflashkamilrestroom_continue:












    scene black with Dissolve(3)
    ""
    centered "{size=+120}Rejection...{/size}" with Fade(0.5, 0.5, 5)



    $ kamilencouragebanu = False













    jump banu_reject_kamil_anal_pureroute



label banu_reject_kamil_anal_pureroute_continue:


    scene black with Dissolve(3)
    ""
    centered "{size=+120}Married friends{/size}" with Fade(0.5, 0.5, 5)
    scene v17-21 with irisin
    "Banu and Kamil hosted a dinner for their close friends, Polad and Nesrin. "
    "The room was lightly lit, and laughter filled the air as they all enjoyed a delightful meal together."
    "Throughout the evening, they engaged in playful and jokeful conversations, sharing fond memories and creating a warm and friendly atmosphere."
    scene v17-22
    "The dinner strengthened their bond, leaving them with hearts full of joy and gratitude for the cherished moments they had shared."
    "But that was the most memorable dinner they've ever had."
    k "You know, guys, I've been thinking lately. I think I'm a pretty brave and good husband to Banu."
    b "Oh, here we go!"
    p "Brave and good, huh? Alright, I'm intrigued. Do tell us more, oh great Kamil!"
    k "Come on, don't laugh! I mean it. I'm always there for Banu, supporting her in everything she does."
    n "Yes, yes, you're her knight in shining armor!"
    p "Wow, I can see it now. 'Kamil the Brave' coming to the rescue!"
    scene v17-23
    k "Hey, I'm serious! Remember that time she had to deal with that scary spider? I bravely took care of it, didn't I, Banu?"
    b "Oh, yes, you were very brave... from a safe distance!"
    "Everyone bursts into laughter."
    k "Okay, fine. Maybe my bravery has its limits, but I'm always there to listen and support her when she needs me."
    n "That's sweet, Kamil. You two are such a cute couple!"
    p "Yes, the brave and the adorable, a perfect match!"
    b "You better be careful, Kamil. Your bravery might go to your head!"
    p "You know, Kamil, I've always admired your bravery—especially when it comes to facing Banu's cooking experiments!"
    scene v17-24
    k "Oh, come on! Banu's cooking is delicious, and you know it. But speaking of bravery, I must say, I've never seen anyone pull off a bald head quite like you, Polad."
    p "Hey now, watch it! My bald head is my superpower. It reflects all the wisdom I've accumulated over the years!"
    n "Oh, you two are at it again!"
    k "Just having some fun! But seriously, Polad, you rock the bald look with style."
    p "Well, I suppose I have to, with a friend like you making bald jokes all the time."
    k "Oh, don't worry, Polad. We all love you and your shiny head."
    b "Oh, Kamil, don't be too hard on him."
    scene v17-29
    p "You know, Kamil, I've heard a little secret about Banu."
    k "A secret about Banu? What is it?"
    p "Well, I heard she has a thing for bald men. You know, like me."
    k "Wait, what? That can't be true!"
    p "Oh, trust me, my friend. She might have a soft spot for baldies."
    k "Banu, is this true?"
    scene v17-26
    "As the playful banter continued, Banu decided to join in on the fun and playfully test Kamil's patience, taking a cue from Polad's earlier joke."
    b "You know, Polad might be onto something, Kamil. I must admit, I've always had a soft spot for bald men."
    k "Wait, seriously?"
    b "You know, Kamil, there's something quite attractive about bald men. They exude confidence!"
    scene v17-25
    b "You know, Polad, I have to say something..."
    b "You're such a sexy and muscular guy! Like, seriously, you're so...erotic."
    menu:
        "Kamil gets angry":
            $ renpy.block_rollback()
            $ kamilencouragebanu = False
            scene v17-26
            k "Alright, that's enough. Let's finish this conversation."
            b "Kamil, I didn't mean anything by it. It was just a joke!"
            k "I get it, but it's not something I want to hear, especially in jest."
            n "Come on, guys, it was all in good fun. No need to take it so seriously."
            scene v17-27
            b "I understand, but Kamil is the man of the house, and what he says matters to me."
            n "Of course, I get that. Every couple has their boundaries, and it's important to respect them."
            k "Banu, I trust you, and I know it was meant as a joke. But sometimes, certain things can hurt, even in jest."
            "The group takes a moment to let the tension subside, and soon the mood lightens again as they continue with the dinner. Banu respects Kamil's wishes, and the conversation steers away from anything that might cause discomfort."
        "Kamil encourages Banu":


            $ renpy.block_rollback()
            $ kamilencouragebanu = True
            scene v17-26
            "As the conversation takes an unexpected turn, Banu's playful remark about Polad catches Kamil off guard."
            "Instead of getting angry, he finds himself feeling oddly excited by her boldness. He smirks, encouraging her to continue, intrigued by her candid expression."
            k "Oh, really? You find Polad sexy, huh? Tell us more, Banu."
            scene v17-25
            b "Well, I must admit, there's something about Polad that's just... irresistible. His confidence, his muscles... I can't help but feel drawn to him."
            b "You know, I must say, Polad's confidence is just so alluring. And those muscles of his...They're like a work of art, so well-defined and strong."
            p "Well, I have been hitting the gym lately."
            k "I have to admit, Polad, you do have a way of turning heads."
            b "Exactly! I mean, who wouldn't be drawn to such a handsome and charming man?"
            n "Oh, Polad, you should really thank Banu for the ego boost!"
            scene v17-28
            b "Oh, it's all in good fun. But seriously, you're quite the catch, Polad."
            b "Polad, I know you have an eye for me. I can see it in your sly glances."
            scene v17-29
            p "What? Me? I have no idea what you're talking about."
            b "Oh, come on! You can't fool me."
            p "Alright, alright. Maybe I do find you a little captivating."
            n "Oh, these two are like a comedy duo!"
            b "And you know what else? Polad thinks I have a great shape."
            p "Well, who can blame me? But let's not forget, Nesrin's shape is equally wonderful."
            n "Oh, stop it, you two!"
            scene v17-30
            "Banu, feeling a bit more daring due to the wine, decides to show off her confidence. She stands up and smooths down her knee-length tight dress, playfully flaunting her figure."
            b "Well, here's a little something to prove Polad right."
            "Kamil and Polad exchange amused glances, enjoying Banu's playful spirit."
            p "Well, I don't want to be rude but I've seen better."
            scene v17-31
            "As Banu decided to play along with Polad's teasing, she grinned mischievously, taking it as an opportunity to prove him wrong."
            "With a playful twirl, she turned around to show off her full shape, feeling a burst of confidence in her slightly tipsy state."
            scene v17-32
            b "Oh, really, Polad? You think you've seen greater shapes? Well, feast your eyes on this!"
            "She spun around gracefully, showcasing her figure in the knee-length tight dress, exuding an air of playful charm and allure."
            "The room fell momentarily silent as all eyes turned to Banu, including Polad's, who found himself momentarily speechless."
            scene v17-33
            p "Uh... well... I mean..."
            "Banu's bold move left Polad slightly flustered, and everyone else burst into laughter at his reaction. She turned back to face him with a smirk, feeling triumphant in her playfulness."
            b "That's what I thought!"
            k "I think you've rendered Polad speechless, Banu."
            n "Bravo, Banu! You've got him!"
            "As Polad playfully calls Nesrin to join the fun, she grins and accepts the challenge."
            scene v17-34
            n "Alright, Banu, let's settle this once and for all. May the best shape win!"
            b "You're on, Nesrin! Let's see what you've got."
            scene v17-35
            "The two friends stand side by side, exchanging amused glances, ready to have some friendly fun."
            n "So, Kamil, who do you think has the better shape?"
            n "Make sure to choose wisely!"
            k "Oh, you're both amazing in your own ways. It's hard to pick a winner when you both look fantastic."
            "Banu and Nesrin exchange playful glances, pretending to pout at Kamil's diplomatic response."
            scene v17-36
            "As Banu playfully turns to Polad, she raises an eyebrow, waiting for his response to the question she posed."
            b "So, Polad, what's your verdict? Who has the best shape?"
            p "Hmmm... this is a tough one."
            p "Well, after careful consideration, I have to say, Banu, you win this round. Your shape is undeniably amazing!"
            b "Oh, you're too kind, Polad!"
            k "Are you sure you're not just trying to get on her good side?"
            p "Hey, I'm just speaking the truth! Banu is looking stunning tonight."
            b "Thank you, Polad. You're not so bad yourself."
            scene v17-37
            b "Polad, I just wanted to say a special thank you. You always bring so much fun and laughter into our lives."
            b "And we're lucky to have you and Nesrin in our lives. You know, in some areas, you really are better than Kamil."
            k "Oh, is that so?"
            b "You know, Kamil, I have to say, Polad's muscles are quite impressive. He must have spent a lot of time at the gym."
            p "Oh, well, I do try to stay in shape."
            b "You definitely succeed! It's hard not to notice those well-defined muscles of yours."
            n "Oh, Banu, you're making him blush!"
            b "Can you blame me? I can't help but admire a guy who takes care of himself."
            p "Well, I appreciate the compliment. But you're no slouch either, Banu. You've got your own charm."
            b "..."

    scene black with Dissolve(3)
    ""
    centered "{size=+120}An offer{/size}" with Fade(0.5, 0.5, 5)
    scene v17-51 with irisout
    "The soft glow of the television illuminated the cozy little room, casting flickering shadows on the walls. Kamil lounged on the couch, engrossed in whatever program was playing on the screen."
    "The door creaked open, and a sultry presence entered the room. Banu stepped in, her figure silhouetted against the doorway for a moment before she closed it behind her."
    "Clad in a red silk nightwear that clung to her every curve, she exuded an air of confidence and allure that was hard to ignore."
    "Kamil tore his gaze away from the screen, his eyes widening as they met Banu's alluring form. A mix of surprise and appreciation flickered in his eyes, his lips parting slightly as he took in the sight before him."
    scene v17-52
    b "Well, well, what do you think?"
    k "Banu! You... you look amazing."
    b "Just amazing? I was hoping for a bit more enthusiasm."
    k "Okay, let me try that again. You look absolutely stunning, Banu. I mean, seriously, my jaw might've dropped a little when you walked in."
    scene v17-53 with fade
    b "That's more like it. But tell me, what's your favorite part? The silk? The color?"
    k "It's hard to pick just one favorite part when the whole package is... well, mind-blowing. The silk, the color, the way it fits you perfectly – they all come together to create something... incredible."
    scene v17-54
    b "How about this angle, Kamil?"
    k "Oh, now you're just being unfair, Banu. That's... that's a whole new level of captivating."
    b "Unfair, you say? I thought I'd give you a different perspective. You know, keep things interesting."
    k "Interesting is an understatement. You're positively mesmerizing from every angle."
    scene v17-55 with fade
    b "You know, Kamil, I didn't just put on this outfit for the fun of it."
    k "Oh? So there's more to this than meets the eye?"
    b "Absolutely. I've been thinking, we've been married for quite a while now, and life has settled into a routine. I thought maybe it's time we inject a bit more excitement into our marriage."
    k "Excitement? Do tell, Banu."
    b "Well, I've been reading up on ways to keep the spark alive, and one suggestion caught my attention. It's about exploring new experiences together, doing things that are out of the ordinary, and stepping out of our comfort zones."
    k "That does sound interesting. But what kind of new experiences are we talking about?"
    scene v17-56
    b "It's a bit... daring, but I think it could add a whole new level of excitement to our marriage."
    k "Daring, you say? I'm listening."
    b "What if... what if we considered doing something like a cam show, but exclusively for our OnlyFans subscribers?"
    k "A cam show? Like, a live video?"
    b "Yes, exactly. It's a way to share our connection and intimacy with those who appreciate us, while also keeping things exciting between us."


    $ adventure = 0

    if fakeanorgasm == True:
        $ adventure -= 1

    if fakeanorgasm == False:
        $ adventure += 1

    if tellkamilaboutmurat == True:
        $ adventure += 1

    if tellkamilaboutmurat == False:
        $ adventure -= 1

    if banukisskamilinfrontofpolad == True:
        $ adventure += 1

    if banukisskamilinfrontofpolad == False:
        $ adventure -= 1

    if kamilagreetoplaythegame == False:
        $ adventure -= 1

    if kamilagreetoplaythegame == True:
        $ adventure += 1

    if banuwantstoteaseintern == True:
        $ adventure += 1

    if banuwantstoteaseintern == False:
        $ adventure -= 1

    if banuconfessapastsecrettokamil == False:
        $ adventure -= 1

    if banuconfessapastsecrettokamil == True:
        $ adventure += 1

    if banusharedetailswithkamil == True:
        $ adventure += 1

    if banusharedetailswithkamil == False:
        $ adventure -= 1

    if banuagreebowlingmurat == True:
        $ adventure += 1

    if banuagreebowlingmurat == False:
        $ adventure -= 1

    if banuorderthefood == True:
        $ adventure += 1

    if banuorderthefood == False:
        $ adventure -= 1

    if banupaysatseafoodrestaurant == True:
        $ adventure += 1

    if banupaysatseafoodrestaurant == False:
        $ adventure -= 1

    if kamilencouragebanu == True:
        $ adventure += 1

    if kamilencouragebanu == False:
        $ adventure -= 1

    if kamilholdbanufrombehindrestroom == False:
        $ adventure -= 1

    if kamilholdbanufrombehindrestroom == True:
        $ adventure += 1

    if kamilwarnkamilbathroom == False:
        $ adventure += 1

    if kamilwarnkamilbathroom == True:
        $ adventure -= 1








    menu:
        "{color=#008000}Kamil gets angry{/color}" if adventure <= -1:
            $ renpy.block_rollback()
            scene v17-59
            play music "audio/tension.mp3"
            k "Are you out of your minds, Banu? A cam show? Have you completely lost touch with reality?"
            b "Kamil, I... I didn't expect you to react like this. I thought it could be a way to..."
            k "A way to what? Humiliate ourselves for the world to see? I can't believe you'd even suggest something like this!"
            b "Kamil, I didn't mean to hurt you. I thought it could be something... different, a way to maybe spice things up between us."
            scene v17-60
            k "Is that what you call it? Sharing our private moments, our intimacy, with strangers online? Do you have any respect for our relationship, for our privacy?"
            k "Banu, I can't believe you're even suggesting something like this. It's out of the question."
            k "I don't want to discuss this any further. It's not happening, and that's final."
            stop music

            jump pure


        "{color=#FF0000}Kamil agrees{/color}" if adventure >= 0:
            $ renpy.block_rollback()
            scene v17-57
            k "Banu, I must admit, your suggestion took me completely by surprise. It's not something I ever thought I'd consider, but I can see that you're genuinely interested in exploring new avenues to keep our marriage exciting."
            b "Kamil, I appreciate your willingness to even think about it."
            b "I'm glad you're open to discussing this, Kamil. I believe that we can approach this in a way that's comfortable for both of us."
            scene v17-58
            b "I want to assure you that our privacy is a top priority for me."
            b "I did some research, and I found out that on the platform we're considering, we can block specific countries from accessing our content. "
            b "That way, people from our own country won't be able to recognize us."
            k "Blocking our own country? That could provide an extra layer of anonymity. I appreciate your efforts to ensure our privacy, Banu."
            b "I'm glad you think so. It's important to me that we're both comfortable with this decision. If we proceed, we can set up our profile in a way that only our selected subscribers have access."



            scene black with Dissolve(3)
            ""
            centered "{size=+120}Cam show{/size}" with Fade(0.5, 0.5, 5)
            scene v17-61 with irisin
            play music "audio/up.mp3"
            "The soft glow of a lamp cast a warm light over the bedroom as Banu and Kamil meticulously arranged the room."
            "The atmosphere was a blend of nervous excitement and shared determination as they prepared for the cam show they had decided to undertake together."
            b "It's a new experience for both of us. Just remember, we're doing this together."
            k "Absolutely. And I appreciate you taking the time to research the platform and the privacy settings."
            scene v17-62
            b "I wanted to make sure we're taking every precaution to protect our privacy."
            k "You look beautiful, Banu. I'm glad we found a way to incorporate your style and values into this."
            b "Thank you, Kamil. Your support means a lot to me."
            k "Let's take a moment before we start to remind ourselves why we're doing this. It's about exploring something new as a couple and strengthening our connection."
            b "You're right. As long as we keep our focus on each other and our relationship, I believe we can make this work."
            k "And if at any point either of us feels uncomfortable, we'll communicate and adjust. We're in control of this experience."
            b "We're in control. Together."
            scene v17-63
            "Banu carefully adjusted the laptop on the small table at the foot of the bed. "
            b "How does this angle look, Kamil?"
            k "I think that's perfect, Banu. "
            stop music
            scene v17-64
            "The screen displayed the live feed of the camera, and she was keen on getting the angle just right to capture the entirety of the bed and the space around it."
            scene v17-65 at left
            show chat1 at right
            k "Are you ready?"
            b "I am. Let's do this."
            scene v17-66 at left
            show chat2 at right
            b "See, Kamil? Alex thinks we're adorable."
            k "Well, who am I to argue with our fans?"
            b "Thank you, Emily! I thought I'd go for something comfortable and stylish tonight."
            k "And I must say, you're turning heads."
            b "Oh, I've got one! Remember that time Kamil tried to cook dinner for me and ended up burning the entire pot?"
            k "Hey, I thought I could master the art of cooking in one go. But I've definitely improved since then."
            b "How about we give our subscribers a little surprise?"
            k "What did you have in mind?"
            scene v17-67 at left
            show chat2 at right
            b "Let's show them something exciting. Are you up for it?"
            k "Ohhhh!"
            "With a swift motion, Banu leaned down, capturing Kamil's lips in a tender kiss. "
            "As the camera continued to roll, they held onto the kiss for a brief but charged moment."
            "Banu pulled back slightly, her face mere inches from Kamil's, a shared smile playing on their lips."
            scene v17-68 at left
            show chat3 at right
            b "Our subscribers wanted something exciting. I think we just gave them a glimpse."
            b "I think they'll appreciate our little surprise."
            "As Banu and Kamil talked, the comments from their subscribers started rolling in. Some were positive and supportive, while others were not really nice."
            k "Are you okay?"
            b "Yeah, just processing all these comments. It's interesting how people perceive us differently."
            scene v17-69 at left
            show chat4 at right
            b "You know what? I think I have an idea to give our subscribers a little extra excitement."
            k "Banu, I don't think this is a good idea for the first time."
            b "Come on, Kamil."
            b "Just watch and see."
            scene v17-70 at left
            show chat5 at right
            "Banu's playful spirit continued to shine as she decided to take things up a notch, embracing the moment and engaging with their subscribers in a light-hearted manner."
            "She glanced at Kamil with a mischievous smile before turning her attention back to the camera."
            b "Alright, subscribers, it seems like you're in for a treat!"
            k "Banu, what are you up to now?"
            scene v17-71 at left
            show chat5 at right
            k "You're certainly keeping them entertained, Banu."
            "Banu's playful nature continued to shine through as she found herself fully immersed in the moment, enjoying the dynamic energy of the cam show."
            "With a mischievous glint in her eyes, she looked at Kamil and then back at the camera, a playful smile tugging at her lips as she continued to rub her pussy through her pants."
            b "You know what? Let's keep things interesting! ahhhhhh... "
            k "Banu, don't you think it's enough?"
            scene v17-72 at left
            show chat6 at right
            b "What do you mean, Kamil? It's getting interesting."
            k "I've been trying to be open-minded about this, but I'm starting to feel uncomfortable with some of the comments and the direction the show is taking."
            b "I understand, Kamil. This was meant to be fun and lighthearted, but I never want you to feel uncomfortable."
            k "It's not that I don't trust you or our relationship. It's just... seeing those comments and knowing that people are looking at you like this makes me uneasy."
            scene v17-73 at left
            show chat6 at right
            b "Kamil, please, let's talk about this."
            k "I can't believe you're still going along with this, Banu. Reading those comments, seeing you do those things for them—it's too much."
            b "I'm so sorry, Kamil. I didn't realize how much it was affecting you."
            k "I know you didn't mean for it to turn out like this. But it's hard for me to see you getting that kind of attention from strangers."

            jump developed





    dev "{color=#000000}Thank you for playing! This is the end of this route in this version. Play again to discover more. If you enjoyed it please {a=https://www.patreon.com/lustfulfantasy}support{/a} the development. Please, add the game to your {a=https://store.steampowered.com/app/2505580/Life_in_Middle_East/}wishlist{/a} on Steam to make it grow. {/color}"
    hide screen faith
    hide screen angeldevil
    jump endings
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
