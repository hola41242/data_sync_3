





screen faith:
    add "faith"

screen angeldevil:
    add "angeldevilcondition"

screen lust:
    add "lust"

screen orgasm:
    add "orgasm"

screen loyalty:
    add "loyalty"









screen color10:
    add "color10"

screen color13:
    add "color13"

screen color15:
    add "color15"

screen color20:
    add "color20"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
