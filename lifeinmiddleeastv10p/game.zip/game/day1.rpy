

label day1:
    $ banu_ruslan = 0
    $ banu_kamil = 10
    $ banu_turan = 0
    $ banu_nesrin = 0
    $ banu_polad = 0
    $ leyla_ruslan = 0
    $ leyla_kamil = 0
    $ banubad = 0
    $ domme = 0
    $ kamilbeta = 0
    $ lust = 0
    $ turandate = False
    $ spykamil = False
    $ ruslanargument = False
    $ turandate = False
    $ streetguys = False
    $ threesome = False
    $ murat = False
    $ humiliatingseyhun = False
    $ ahmedtease = False
    $ murattease = False
    $ dinnerreddress = False
    $ banukamilbedroomchoicesblabla = 0




    show black
    centered "{size=+150}DAY 1{/size}" with dissolve
    scene black with dissolve
    $ banu_kamil = 10
    with Pause(1)
    scene day1-1 with Fade(0.5, 0.5, 5)
    show screen faith with blinds
    show screen angeldevil with blinds


    "{i} {color=#526168}It started off as a normal Monday. Banu had to get up, prepare something to eat and go to work.{/color} "
    "{i} {color=#526168}She was currently working in the ASAN service branch in the city centre. The work was not too difficult, not for her, but did take up a lot of her time.{/color}"
    "{i} {color=#526168}She got the job with the help of Polad. He was a friend of Alper's, Banu's deceased husband.{/color}"
    "{i} {color=#526168} After Alper's sudden death, Polad tried to help Banu as much as possible, because of how much he loved his passed friend. {/color} "
    "{i} {color=#526168} He also knew Banu didn't have any close friends, and wanted to be a support mechanism for her. {/color}"

    "{i} {color=#526168}He visited Banu often, and was a crutch for her everytime she needed help.{/color} "
    "{i} {color=#526168}He knew that he was there to respect this friend, though the affection he had for Banu was building over time, and he was conflicted about his own feelings.{/color} "
    "{i} {color=#526168}Banu had no idea herself, but it made her happy to be cared for, especially by someone who also knew Alper and experienced the same loss.{/color} "
    scene day1-2
    b "{i} {color=#526168}Ah, I overslept again. Why do I always feel so tired on Mondays?{/color} "
    b "{i} {color=#526168}...{/color}"
    b "{i} {color=#526168}I must get up now!{/color} "
    scene day1-3
    b "{i} {color=#526168}Maybe it's because I know today will be stressful at work...{/color} "
    b "{i} {color=#526168}Anyways, I need to hurry. No point in thinking about this now.{/color}"
    scene day1-4 with squares
    l "Mom, is that you?"
    b "I'm coming! One second!"
    l "You're late for work again!"
    b "I know, no need to remind me."
    scene day1-5
    b "I don't have time for breakfast, baby. You eat on your own. I have to go or they'll be mad at me again."
    b "Where's your dad?"
    l "I don't know. He got up really early and went out to meet ... One of his friends I guess."
    scene day1-6
    b "{i} {color=#526168}I love my daughter so much. I always marvel at how mature Leyla has become.{/color} "
    b "{i} {color=#526168}Despite being only 19, Leyla carries herself like someone in their 20’s.{/color} "
    b "{i} {color=#526168}I only wish my daughter could get along with my stepson, Ruslan. They had been fighting recently.{/color} "


    b "What about Ruslan?"

    l "He's in his room."

    b "{i} {color=#526168}She has a sour look now that I mentioned Ruslan. Something must’ve happened again.{/color} "
    b "Is he treating you badly again?"
    l "Yes, but I’m over it. You know him. He’s tough and arrogant, and he’s never going to change."
    scene day1-7
    play music "audio/tension.mp3"
    b "No, he MUST change! He’s stubborn, but I can deal with him."
    b "{i} {color=#526168}Ruslan... I've had enough of you bullying my daughter. I'll deal with you sooner or later."
    $ turandate = False
    $ spykamil = False
    $ ruslanargument = False
    menu:
        "Dealing with Ruslan can wait, since Banu was late for work and wanted to have a good day.":
            stop music



            $ ruslanargument = False
            $ renpy.block_rollback()
            b "I have no idea why he's behaving like that lately... maybe it's because he's an adult now."
            b "I must hurry to work. But I will talk to him later."
            scene day1-8 with fade
            "{i} {color=#526168}She put her hijab on and headed to work immediately...{/color} "


            jump restoftheday
        "Ruslan’s behavior was unacceptable and Banu must deal with him immediately despite being late for work.":
            $ domme += 1

            $ banu_ruslan -= 1
            $ ruslanargument = True
            $ renpy.block_rollback()

            scene day1-7
            b "That’s it. This situation can't go on like this."
            b "I have to see what his problem is."
            scene day1-9 with wipeleft
            b "Ruslan, it's Banu, I’m coming in!"
            b "Young man, can you please tell me why you're not respecting your own sister?"
            scene day1-10
            r "Is it so hard to knock at the door before entering?"
            b "Look, I don't know why you’re behaving like this recently, but you ought to be respectful to your sister and your mother."
            r "She’s not my sister and you’re not my mother. Can't you understand that? Now please go away, this really is none of your business."

            scene day1-11
            b "Don't you dare talk to me in that tone."
            b "I brought you up, I took care of you, I'm your mother more than anything else."
            r "Thank you...and can you please leave me alone? Then I would be even more thankful!"
            b "That’s not the right way to talk to your mother. I’ll complain to your father about your disgusting behavior."

            scene day1-12
            r "Do you think he can hurt me just because of you? Do you honestly think you're that important to him?"
            r "You’re only married to my father because he needed a maid to take care of the house."

            r "You’re just a cleaner here, and nothing else."
            play sound "voices/slap.mp3"
            scene day1-13
            b "How dare you say that!"
            b "On second thought, I won't get your dad involved. I’ll find ways to make you a good boy myself… I know how to handle dudes like you!"

            scene day1-14
            r "You'll regret slapping me. I’ll get my revenge, Banu!"
            b "What? You will punch me?"
            r "No. But I know how to treat you, little bitch."
            r "I've seen you and your co-worker, Turan. You look at him like you want him."
            r " You probably sleep with him, don't you?"
            b "Of course not! You don't know what you’re talking about."

            r "You’ve never had sex with my father. I know this."
            b "What? How...never mind! Our sex life is none of your business!"
            r "Ha! I knew it. You won’t fuck him, so you found another way to fulfill your sexual desire."



            scene day1-15
            b "So that’s your problem? You're trying to defend your father against me? You don't know what you’re talking about. And Turan is just my co-worker and nothing more."
            b "Besides, it’s none of your business what I do. Mind your own business and behave appropriately!"
            b "I’m in a hurry, so I'm finished here, but we WILL talk about this again."
            r "There’s nothing to talk about. Now get out of my sight or I won't be able to control myself."
            scene day1-16
            stop music
            b "{i} {color=#526168}You will apologize to me for your behavior...{/color}"
            r "{i} {color=#526168}Fucking slut.{/color}"

            scene day1-8
            b "{i} {color=#526168}I can’t believe Ruslan is treating me like this and accusing me of cheating. Maybe he saw Turan and me on Friday.{/color} "
            b "{i} {color=#526168}But it was just a friendly walk. Turan was visiting his friend in the neighborhood and I accompanied him after work.{/color} "
            b "{i} {color=#526168}Turan is such a gentleman. He checks on me often and cares about me.{/color} "
            b "{i} {color=#526168}I think I’m his favorite employee. But we’re just friends and nothing more.{/color} "

            b "{i} {color=#526168}... {/color}"
            b "{i} {color=#526168}Oh forget it, I’m going to be late...{/color} "

            jump restoftheday

label restoftheday:
    play music3 "sfx/office.mp3"

    scene day1-17 with fade



    b "{i} {color=#526168}A lot of questions were haunting me today, and I spent a lot of time deep in my thoughts.{/color}"


    b "{i} {color=#526168}Why are so many things making me unhappy all of the sudden? I need to get some advice from my best friend, Nesrin. {/color}"

    if ruslanargument == True:

        b "{i} {color=#526168}I can understand Ruslan’s anger. He lost his mother at a young age. But he has no right to call me a bitch.{/color} "

        b "{i} {color=#526168}He's acting so weird recently, and I notice how he looks at me. {/color}"
        b "{i} {color=#526168}When I walk around the apartment in nightwear, he cannot take his eyes off me.{/color} "
        b "{i} {color=#526168}I’m used to men staring at my body and I’ve dealt with it my entire life, but with Ruslan, it’s so weird. I’ll have to talk with him about this too... {/color}"








    t "Hey, Banu, how are you doing?"
    scene day1-18
    b "Hey Turan, thanks... just thinking about something."
    t "I was passing and saw you looking a little upset. What happened? Is everything okay?"
    b "{i} {color=#526168}How is Turan always so good at reading my mind like this?{/color}"
    b "Yeah don't worry about that. I just have a few problems at home."
    scene day1-19
    t "Don't worry, it happens."
    t "You know what, this isn’t a suitable place to talk. Let's go to my apartment after work. We can have a drink and talk about your problems. What do you say?"
    b "You know, Turan, that’s a really kind offer, but I cannot go home late, I’m sorry. "

    t "Come on, I know you need somebody to chat with about your life, and it won't take too long, I promise."

    menu:
        "Banu really needed somebody to chat with and she believed that Turan had no bad intentions.":

            $ lust += 1
            $ banubad += 1
            $ turandate = True
            $ spykamil = False
            $ banu_turan += 1
            $ renpy.block_rollback()
            scene day1-20
            b "Turan, you’re a gentleman and a funny guy, but you know this isn't appropriate."
            t "Believe me, Banu, it will only take half an hour to talk through your problems, and then you can leave."

            b "Okay, you win. But I'm leaving as soon as the half hour is up."
            t "Great. I'll pick you up."
            scene day1-21
            b "{i} {color=#526168}Deep inside I know this isn’t the right thing to do, but I want someone to talk to, and I’d feel bad rejecting Turan's proposal. He’s always so helpful to me.{/color}"
            b "{i} {color=#526168}He's a nice guy, I know he doesn't have bad intentions… well, I hope he doesn’t. {/color}"
            stop music3
            jump badday1
        "She knew what it means for a married woman to go into the house of a single man. She had to reject.":



            $ turandate = False
            $ spykamil = True
            $ renpy.block_rollback()
            scene day1-19
            b "I’m so sorry, Turan, but I have to visit some stores to buy some stuff before they’re closed, so we can talk another time."
            t "Okay, Banu, I just wanted to make sure everything was okay with you."
            b "Thanks a bunch Turan. That's very kind of you."
            t "Then see you later, bye."
            b "Bye, see you."
            "{i} {color=#526168}It was very hard for her, but a lie helped her to reject Turan.{/color} "
            stop music3
            jump goodday1





label badday1:
    scene black with dissolve
    with Pause(1)
    scene day1-31 with fade

    play sound "voices/dooropen.wav"
    "{i} {color=#526168}They arrived at Turan's apartment. {/color}"
    b "{i} {color=#526168}I’m feeling very shy, and I haven’t been talking unless I’m asked a question. Am I now regretting my decision? I wonder what Kamil would say if he knew I was here.{/color}"
    t "Soo, do you like my apartment? "
    b "Yes, I definitely do. It looks very comfortable, and it has a very good view of the city."
    t "What can I get you to drink?"
    b "Thanks Turan, but I’ll pass this time. Besides, I don't drink alcohol."

    t "Water?"
    b "Maybe. Thanks."
    t "Okay, let me get some."
    scene day1-32
    t "Okay, now will you tell me why you were so upset at work today?"
    b "It’s about my stepson. I don’t believe he wants to accept me as his mother, even after all these years. He’s mean to his sister and me."
    t "I see. "
    scene day1-33
    b "I don't know what to do. I don't want to tell his dad about his behavior in case that makes it worse. I want to handle it on my own."
    t "I think there might be another cause of this problem."

    b "What do you mean?"
    t "I mean maybe he likes you as a woman, but not as a mother, if you know what I mean."



    b "Turan, please, stop. That’s crossed my mind, but it's a little difficult to imagine."



    t "Why not? You know it must be very hard for any man to control himself around you."
    scene day1-34
    b "Stop it Turan. You’re making me blush."



    t "But it’s true."



    b "You’re always so full of compliments."




    scene day1-35
    t "Yeah, but not all the time. Only when I’m around you."




    b "It feels so good talking to you... You’re such a good person."



    b "{i} {color=#526168}Though, I’m a little worried that Turan is flirting with me, and I don't know what to say. I hope he didn’t take my words as flirting back with him.{/color} "




    scene day1-36
    play music "audio/tension.mp3"
    "{i} {color=#526168}She could smell his cologne lingering in the air, and didn't know what to do. What was he thinking?{/color} "
    "{i} {color=#526168}In her mind, Turan was a kind and caring gentleman with high self-esteem but nothing more. {/color}"
    "{i} {color=#526168}As time went on, Banu's heart started beating faster because of the silence in the room. {/color}"
    "{i} {color=#526168}Maybe because she knew Turan's next step. {/color}"
    scene day1-37
    b "Turan, what are you doing?! Please, stop this!"


    t "Tell me, why are you here?"
    b "Turan, I am a married woman."
    t "A married woman who has not had sex with her husband yet."
    b "Turan, I am serious. You misunderstood me, ohhh.."
    t "I know everything Banu. We don't have secrets from each other, do we?"
    t "I know that there is only a formal relationship between you and your husband and nothing more. Am I wrong?"
    b "Turan, what you're doing is not ....ahhh"
    scene day1-38 with hpunch
    "{i} {color=#526168}Without saying any word, he pressed Banu to the wall and started unbuttoning her shirt while kissing her.{/color} "
    "{i} {color=#526168}It could be the mistake of her life and she knew that.{/color}"
    b "Turan, please let me go."
    scene day1-39
    t "You don't need to feel ashamed of this. You are a woman and you need this, so, relax and let it happen."
    "{i} {color=#526168}Banu unintentionally closed her eyes and put her hands on Turan's arms for a second. {/color}"
    scene day1-40
    b "{i} {color=#526168}Oh God, my breasts are bare! I need to cover them up but I’m not able to escape his hands. {/color}"


    b "{i} {color=#526168}It’s becoming too hard for me to resist. I shouldn’t do this, but my passion is overwhelming me right now.{/color} "


    t "You'll be mine and only mine.."
    scene day1-41
    t "Let's find out if you are wet after those kisses."
    b "{i} {color=#526168}He’s touching me where no man since Alper has touched… not even my husband! I can’t let this continue. Be strong Banu! {/color}"
    b "I ...I have to go..."
    t "Just let it happen."

    t "Your tits are beautiful, I’m going to taste them, and you’ll love it."

    b "NO..."
    scene day1-42
    b "{i} {color=#526168}As soon as he moved his head towards my breasts, I knew I had him distracted, and I could use this as an opportunity. I pushed Turan with all my power! {/color}"


    b "{i} {color=#526168}I almost made a lifelong mistake, but now I’m free to escape!{/color} "
    b "{i} {color=#526168}I quickly took my handbag and rushed to the elevator.{/color} "
    stop music


    scene day1-50 with fade
    b "{i} {color=#526168}Kamil was already asleep.{/color}"
    scene day1-51
    b "{i} {color=#526168}What I've done was a big mistake and it won't happen again.{/color} "
    scene day1-52
    b "{i} {color=#526168}I don't understand why I agreed to Turan's proposal. {/color} "

    if ruslanargument == True:

        b "{i} {color=#526168}Maybe because I was mad after the argument with Ruslan and needed to share my problems with someone.{/color} "









    b "{i} {color=#526168}Turan was a friend, and I trusted him. But he tried to push my buttons, and I almost gave in.{/color} "
    b "{i} {color=#526168}Would he have raped me if I didn’t escape? Surely, he’s not so vile a creature to do that, is he?{/color} "


    b "{i} {color=#526168}Anyway, it should never happen again...I should go to sleep now... {/color}"
    jump day2






label goodday1:
    scene black with dissolve
    with Pause(1)
    scene day1-60 with fade
    play music3 "sfx/shower.mp3"
    b "{i} {color=#526168}Fortunately, the day went on without any problem.{/color} "
    b "{i} {color=#526168}I reached home and relaxed a little bit. {/color}"
    b "{i} {color=#526168}I knew I had to go to bed soon, so that I could wake up earlier and not be late again. {/color} "


    b "{i} {color=#526168}Kamil wasn’t in the bedroom, but when I heard someone in the shower, I knew it must be him.{/color} "


    b "{i} {color=#526168}For some reason I can’t explain, I suddenly had the urge to peep on him in the shower. I’d never done anything like this before. {/color}"

    b "{i} {color=#526168}I couldn't stop my curiosity...{/color} "
    scene day1-61


    b "{i} {color=#526168}I wanted to glance at him for a second, just a second. I could've asked him if he needed anything, anything I could help with, but I couldn't do it. The prospect of telling him I was watching him showering was too scary for me, even though we were husband and wife. {/color}"
    scene day1-62 with hpunch
    b "{i} {color=#526168}When I did look, I couldn't take my eyes off him. I couldn't help but stare.{/color} "


    scene day1-63
    b "{i} {color=#526168}I knew I had to leave before he saw me, but I also didn't want to miss this opportunity. {/color}"
    b "{i} {color=#526168}I began to think I needed to give him a second chance, to start a new life for the sake of my daughter and for myself.{/color} "
    b "{i} {color=#526168}He had almost all the qualities I was looking in a man. {/color}"
    scene day1-64
    b "{i} {color=#526168}He was tall and in shape. He had a hairy chest and belly. There was slight hair on his legs and arms.{/color} "
    b "{i} {color=#526168}And his cock... {/color}"
    b "{i} {color=#526168}It was looking so fat even in its semi-erect form...{/color} "
    b "{i} {color=#526168}I was barely stopping myself from touching my body. {/color}"
    b "{i} {color=#526168}My heart suddenly skipped a beat...{/color} "
    scene day1-65 with hpunch
    k "Banu, is that you?"
    b "{i} {color=#526168}I froze for a moment. {/color}"
    scene day1-66
    b "{i} {color=#526168}And then I ran into the bedroom, covered myself fully with the blanket and pretended to be sleeping.{/color}"




    b "{i} {color=#526168}I could barely sleep, imagining what would happen when we saw each other the next day.{/color}"
    stop music3 
    jump day2
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
