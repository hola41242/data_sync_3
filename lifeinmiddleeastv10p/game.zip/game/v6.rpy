




default menuset = set()




label v6:

    scene black with fade
    centered "{size=+150}THE NEXT DAY{/size}" with dissolve
    scene black with dissolve
    with Pause(2)
    scene day7-1 with squares
    play music3 "sfx/office.mp3"
    b "{i} {color=#526168}I’m already feeling so bored today at work. I wish there were something more interesting for me to do other than stare at the computer all day. {/color}"
    b "{i} {color=#526168}You know what always helps? A cup of coffee. Maybe tea. Actually, I think today is more of a tea day. {/color}"
    scene day7-2
    b "{i} {color=#526168}Rauf's always been a sweetheart, but I’ve never spoken to him much. {/color} "
    b "{i} {color=#526168}I should probably get closer to some of the people I work with. {/color}"
    scene day7-3
    b "Oh, Hi Rauf. I didn’t know you were on break. "
    ra "Just talking to my wife about our plans tonight, then I’ll be heading back to work."
    b "I’m just grabbing a cup of tea, since I already took my break today. "
    ra "Don’t worry, I won’t tell anyone if you take a longer break."
    b "You’re always so sweet Rauf, tell your wife I say hello!"
    scene day7-4
    b "{i} {color=#526168}I wonder where Turan is right now, I haven’t seen him all day. {/color}"
    b "{i} {color=#526168}He usually comes in for tea at this time. {/color}"

    scene day7-5
    b "{i} {color=#526168}I can feel someone behind me...I know it's him...his body heat is so warm, and I can smell his cologne. {/color}"
    t "Hello, Banu."
    b "Ah, I thought I heard you approaching."
    b "Would you like some tea as well, Turan? "
    t "I would love some Banu, you’re always so sweet."
    if banu_turan >= 2:
        jump turan_harrasses
    else:
        jump turan_harrasses_continue

label turan_harrasses:

    scene day7-7
    b "So, tell me about your plans for tonight."
    t "Oh, I’m going out with a friend later, no one you know."
    t "He wants to play some pool tonight, but I don’t really like how crowded it is. "
    t "I would much rather you went with me, Banu."

    scene day7-8
    play music "audio/sensual.mp3"
    b "Turan! What are you doing!"
    t "You should be quiet… or Rauf will hear you."
    t "You wouldn’t want rumors spreading around work, would you?"
    b "But what are you doing with your hands on my body?"
    scene day7-9
    t "I can smell the lust on you from a mile away."
    t "Banu, you make me so hard just being around you."
    show banuturanoffice
    t "I can just imagine how easy it would be to slide into you right now…"
    t "I can feel the heat of you against my hand, wanting me to do more...."
    b "{i} {color=#526168}He’s whispering such dirty words to me… and I can’t help but react to it. {/color}"
    scene day7-10
    b "{i} {color=#526168}I can feel his hot breath against my ear. {/color}"
    b "{i} {color=#526168}He knows exactly what he’s doing to me. {/color}"
    b "{i} {color=#526168}Rauf is sitting right there! He only needs to turn around to see Turan touching me like this… {/color}"
    scene day7-11
    t "Look at your lust filled eyes. You’re desperate for me, aren’t you?"
    t "I bet you’re imagining me bending you over this countertop and fucking you right now in the middle of the lunchroom. "
    t "Rauf will divorce his wife if he sees something so hot. "
    b "Enough, Turan. I’m leaving now. "
    t "{i} {color=#526168}I’ll get you one day, Banu. Whether you like it or not. {/color} "
    stop music
    stop music3

    $ renpy.end_replay()
    $ persistent.turan_harrasses_unlocked = True
    jump turan_harrasses_continue

label turan_harrasses_continue:



    scene day7-6
    b "So, tell me about your plans for tonight."
    t "Oh, I’m going out with a friend later, no one you know."
    t "He wants to play some pool tonight, but I don’t really like how crowded it is. "
    scene day7-12
    b "Well, I’m sure you’ll still have a lot of fun."
    t "I’ll have more fun if I have a pretty lady like you around."
    b "You’re such a charmer. You know I’m too busy doing housework at home to go out!"
    t "Okay, Banu. But one day I’ll get you to come out and have fun with me."
    b "Sure, we’ll see."
    stop music3


    scene black with dissolve
    with Pause(2)
    scene day7-13 with fade

    h "{i} {color=#526168}I can’t believe I’m doing this. {/color} "
    h "{i} {color=#526168}I already have the camera set up, so everything’s ready for the plan. {/color} "
    h "{i} {color=#526168}What I’m wearing will surely entice him. {/color}"
    scene black with fade
    with Pause(1)
    scene day7-14 with fade

    h "Thanks for taking my call about finding a new apartment and agreeing to come here."
    k "Humay, I… um… what you’re wearing is not… appropriate for business."
    h "{i} {color=#526168}His eyes are wide as saucers as expected. Men are so predictable, even good ones like him. {/color}"


    h "Oh, don’t mind this outfit, I didn’t have time to get myself ready."
    h "I’m so comfortable around you anyways... "



    scene day7-15
    h "I could be naked around you and it wouldn’t bother me."
    k "Err… um… "
    k "… this isn’t what I… "
    h "Come on, Kamil, I can see it in your eyes. You want to fuck me again… you always have."
    h "I know your wife must be a prude, wearing the hijab and acting all snooty… I bet she can’t suck your dick like I can… I bet she can’t ride your cock as wild as I can… she won’t make your dreams come true like I will."
    h "I’ve always regretted that we never stayed together… all this time has gone by, and every day I regretted it. Let’s not make that mistake again."

    h "Let's make up for all that lost time."
    k "{i} {color=#526168}Banu… I could never betray Banu. This young woman is a man’s dream, but I’m a married man and I’m committed to my vows. {/color} "



    scene day7-16




    k "Sorry, Humay. I’m realizing it was stupid for me to come here."


    k "I think I was a little bit too forward at the coffeeshop and gave you the wrong impression."


    k "I love my wife, and I wouldn’t ever betray her."

    k "Thank you for the offer… any other man would be so lucky."


    k "But I need to go now."


    h "You bastard! Go home to your prude wife!"


    stop music




    scene black with dissolve
    with Pause(2)
    scene day7-87 with fade
    play music "audio/action.mp3"

    boss "We need to talk, Amir."
    am "Sure, but why'd you call us both here?"
    boss "How's business?"
    am "It’s all been going great. Hicran has been learning our operation like an expert. She’s delivered the most goods in the past few weeks compared to the other women."
    boss "That’s good to hear, Hicran. I’m glad you’re doing well here."
    hic "Thank you. It’s all thanks to Amir. He takes care of me well."
    scene day7-88
    boss "Has anyone been giving you any trouble?"
    boss "If they have, you can always come and talk to me."
    hic "Don’t worry about me."
    hic "I’m only a small part of this operation."
    hic "I barely know anything yet."
    boss "You’re a good girl. I can tell."
    scene day7-89
    boss "Now tell me, do you think Amir is doing anything suspicious behind our backs?"
    am "What are you talking about?"
    boss "I’ve heard many things from the women, and they’ve been informing me that you’ve been trying to embezzle money from me. Is that true?"
    am "I would never do something like that, Boss!"
    boss "I trust my sources more than I trust you, unfortunately. "
    scene day7-90
    boss "What do you think, Vladimir? "
    boss "Should we do something about this?"
    v "Anything you say, boss. It’s your call."
    boss "If you were the boss, what would you do about it?"
    v "Well, you’ve always killed those that go behind your back."
    v "Not only that… he’s also had a relationship with Hicran."
    boss "You’re right. We don’t condone relationships in this business."
    boss "Do what you must, Vlad."
    play sound "voices/gun.mp3"
    scene day7-91 with vpunch
    hic "NO!"
    hic "..."
    scene day7-92
    hic "Amir! No, what have you done?!"
    hic "You monsters!"
    scene day7-92
    boss "Calm down, Hicran."
    boss "We don’t condone relationships in our organization."
    boss " I hope you understand. "
    boss " I still trust you... for now. "
    boss " But don’t go against me again, do you hear me? "
    hic "Yes, boss..."
    stop music

    scene black with dissolve
    with Pause(2)
    scene day7-44 with fade

    b "Here’s your tea, Kamil."

    k "Thank you Banu, you’re always so good at taking care of me."
    k "How was your day today?"
    scene day7-45
    b "The usual work stuff, I’m honestly getting so tired of all the work I have to do."
    k "I’ve said many times you can be a stay-at-home mom if you wish."
    b "Oh Kamil, you’re sweet for offering, but I’d be so bored if that was my only role in life."
    b "And with our daughter at University, I don’t need to baby her anymore."
    k "That’s true. You’ve always been such a great mother."
    scene day7-46
    b "We’ve been married for years now and I’m still not used to your flattery."
    k "I hope you’re never used to it."
    b "Are you ready for Polad and Nesrin's visit?"
    k "I’d say so."
    k "I feel like I haven’t seen them in quite some time."
    b "Hah. I always miss my best friend when I’m not with her."
    b "I guess I should go change now since they’ll be here soon."
    k "But you’re already wearing your favorite casual outfit."
    b "It’s comfortable, but I don’t wear this for guests. You want me to look good, right?"



    k "But you already look so good, Banu."
    b "Always the flatterer. I need to impress our guests!"
    k "....."
    stop music


    scene black with dissolve

    with Pause(2)

    scene day7-36 with pushleft

    play sound "voices/glass.wav"


    h "I met with Kamil, her husband, what was her name?...Banu."

    h "Like you asked, Murat, are you satisfied now?"

    mur "What did I tell you to call me when we’re alone?"

    h "Sorry, master. I forget sometimes."

    scene day7-37

    mur "It’s okay. I’ll forgive you this time."

    h "I must say… I’m a little distracted from your lack of clothing."

    mur "Maybe that was part of the plan for tonight."

    h "Oh?"

    mur "Never mind that for now. How did it go with Kamil?"

    h "What’s your goal in this?"

    mur "I want to fuck his beautiful wife, of course."

    h "It seems men are all pigs, and my master is the greatest one."

    scene day7-38

    mur "Why don’t you come here and see how much of a pig I am?"

    h "I think I might be safer standing this far away."

    mur "How did it go with Kamil? Did everything go according to plan?"

    h "No, he’s declined me."

    h "He’s decided he wants to be faithful to his wife."

    mur "What a pity. I thought he’d be wilder than that based on the few minutes I saw him at the cafe."

    mur "Anyways, I want to focus on us now."

    mur "Come closer, sweetheart. I want to touch you."

    scene day7-39

    h "Do you really think I’ll be so easy, Master?"

    mur "You’re already crawling towards me, and you can’t stop staring at my cock."

    h "It’s because I’m not used to seeing something so delicious… and you know I can’t say no to my master...."

    mur "That’s because you’re a good girl, and good girls listen to what they’re told."

    scene day7-40

    h "I love how you’re stroking yourself."

    mur "Maybe you should come closer and finish the job. "

    h "Is that a question or an order?"

    mur "Don’t tease me, baby girl. You don’t want to see me when I’m out of control."

    scene day7-41

    mur "I love your tits, baby. I’d love to shove my dick between them and cum on your face."

    h "Such dirty words coming from a dirty man."

    mur "I thought you would’ve known how dirty I really am by now."

    scene day7-42

    h "Let me help you with the stroking."

    h "Master… you’re so fucking hard for me."

    mur "I can get even harder. "

    h "Why don’t I help you more then?"

    scene day7-43

    mur "Fuck baby… put my dick in your mouth."

    h "I fully plan to have you cum over and over again tonight, Master."

    mur "Of course you do, my pretty little slut."

    mur "I’m glad I chose you as my accomplice."

    mur "You’re going to help me do some pretty dirty things to Banu... "

    h "..."

    stop music








    scene black with dissolve
    with Pause(2)
    scene day7-47 with fade

    b " {i} {color=#526168}Kamil already said I look good in my dress… but I still want to wear something to impress them.{/color}"
    b "{i} {color=#526168}What should I wear? {/color}"
    menu:
        "I need to wear something more conservative for our guests.":
            $ renpy.block_rollback()
            $ dinnerreddress = False

            scene day7-48 with fade
            b "{i} {color=#526168}This looks good, I like the way that the dress covers my body.{/color} "
            scene day7-49
            b "{i} {color=#526168}I hope they’ll like it. {/color}"
            b "{i} {color=#526168}I think I look like a good and proper mother, which is something I definitely am. {/color}"
        "I need to wear something sexy that wows them.":


            $ banubad += 1

            $ renpy.block_rollback()
            $ dinnerreddress = True

            scene day7-50 with fade
            b "{i} {color=#526168}Wow, I usually don’t think so highly of myself, but I feel completely gorgeous. {/color}"
            b "{i} {color=#526168}I bet Kamil won’t be able to stop looking at me now… {/color}"
            b "{i} {color=#526168}And maybe Polad too… {/color}"
            scene day7-51
            b "{i} {color=#526168}Banu! You shouldn’t be thinking this way about someone else’s husband. {/color}"
            b "{i} {color=#526168}Think of how gorgeous your body is instead. {/color}"
            b "{i} {color=#526168}Look at that slit down the side, you can practically see my panties! {/color}"
            scene day7-52
            b "{i} {color=#526168}Actually… it might be better if I don’t wear panties at all. {/color}"
            b "{i} {color=#526168}Ah! I need to finish setting up for the gathering! {/color}"
            b "{i} {color=#526168}I got too focused on my looks... {/color}"


    scene black with dissolve
    with Pause(2)
    scene day7-53 with fade
    if dinnerreddress == False:
        k "So nice to see you again, Polad. How’s everything going with you two?"
        p "Great, the usual. "
        p "We’re both excited to see the two of you tonight."
        n "I’m just here to see my best friend!"
        k "Well, I’m sure you’ll enjoy my company as well, Nesrin."
        n "I hope so. "
        scene day7-54skirt
        n "Banu! You look like a proper woman with that outfit on."
        b "You’re so sweet. Wanted to show you I can be a proper housewife as well, Nesrin."
        n "Well, you definitely look like one. I look so out of place with my dress!"
        b "Don’t be silly, you look gorgeous… as usual."
        p "So Kamil, tell me about your business. "
        p "I feel like I haven’t had a proper chat with a man for a while."
        k "Let’s get comfortable and I’ll tell you all about it."
        scene day7-58skirt
        b "So the intern has been way better than I thought he would be."
        n "I told you it would be okay, Banu. You always worry too much."
        b "He’s actually really nice as well. I think he’ll do well in the company."
        n "Maybe he’s doing well because he thinks you’re gorgeous."
        b "Hah! I can tell he hates me like a mom."
        scene day7-59skirt
        b "Are you sure you’re not drinking too much, Kamil?"
        k "We’re having fun tonight, don’t worry about it."
        n "You’ve got to let your husband have some fun!"
        b "You’re right Nesrin. "
        scene day7-60
        play sound "voices/glass.wav"
        k "Cheers everyone, to an amazing gathering of friends."
        p "Cheers!"
        n "Cheers!"
        scene day7-61skirt

        p "{i} {color=#526168}Fuck, I can’t stop staring at her. {/color}"
        p "{i} {color=#526168}I need to get myself together, I feel like I’m being too obvious. {/color}"
        p "{i} {color=#526168}I just want to bend her over this table and make her scream my name. {/color}"
        p "{i} {color=#526168}I’m going to make you mine Banu, but I feel like you’re too into your husband to even pay attention to me right now. {/color}"
        p "{i} {color=#526168}I won’t give up, though. {/color}"
        scene day7-62skirt
        b "{i} {color=#526168}I feel like Polad is staring at me a lot. {/color} "
        b "{i} {color=#526168}I can feel the dirty thoughts coming out of his brain. {/color} "
        b "{i} {color=#526168}Guys are so obvious when they want you… {/color} "
        b "{i} {color=#526168}Can’t he see that I’m only here for my husband? {/color} "
        b "{i} {color=#526168}I love Kamil so much, and I’d never cheat on him, no matter how much you stare at me, Polad. {/color} "
        b "{i} {color=#526168}I’ve had naughty thoughts and feelings lately, but I can’t consider actually cheating. {/color} "
        scene day7-63skirt
        b "{i} {color=#526168}I feel like he’s still staring at me. {/color}"
        b "{i} {color=#526168}It doesn’t matter, I’ll just ignore him, and he’ll give up one day. {/color}"
        b "{i} {color=#526168}Let me go get the desert for them and try to change the topic. {/color} "
        b "{i} {color=#526168}He should really be focusing on his own wife! {/color} "
        scene day7-64skirt
        b "{i} {color=#526168}He’s coming, I can tell. {/color}"
        b "{i} {color=#526168}Act calm, Banu. Nothing can happen here. {/color} "
        b "{i} {color=#526168}Kamil will come and save me if Polad does anything, I know he will. {/color} "
        b "{i} {color=#526168}God, Banu...what are you thinking? {/color}"
        scene day7-65skirt
        b "Hi Polad, do you need my help with anything?"
        p "No, Nesrin was just going on about something I already knew about, so I figured I would come and ask if you needed my help bringing the deserts."
        b "You’re sweet Polad, thank you, but I don’t need any help."
        p "To be honest, I have an ulterior motive for coming in here…"
        scene day7-66skirt
        b "What’s your ulterior motive?"
        p "I want to tell you how I feel about you, once and for all."
        b "Polad, enough of this. "
        b "Kamil and Nesrin are just in the other room."
        b "I’ve told you before, I’m not into you, I’m a married woman."
        b "I appreciate everything you’ve done for me these years, but you know I’m in love with Kamil, and I always will be."
        p "But Banu, we-"
        b "I’m going back to them now. I hope you understand."
        stop music
        jump polad_teases_banu_continue_2

    if dinnerreddress == True:
        k "So nice to see you again, Polad. How’s everything going with you two?"
        p "Great, the usual. "
        p "We’re both excited to see the two of you tonight."
        n "I’m just here to see my best friend!"
        k "Well, I’m sure you’ll enjoy my company as well, Nesrin."
        n "I hope so. "
        scene day7-54
        n "Banu! I love that dress, you show it off so well."
        b "You’re so sweet. Wanted to show you I can be as pretty as you, Nesrin."
        n "Well, you definitely won this time."
        b "Don’t be silly, you look gorgeous… as usual."
        p "So Kamil, tell me about your business. "
        p "I feel like I haven’t had a proper chat with a man for a while."
        k "Let’s get comfortable and I’ll tell you all about it."
        scene day7-55
        p "{i} {color=#526168}Fuck, I can’t believe what Banu’s wearing. I’ve never seen her dress like this, not even for Alper. Is she trying to tease me on purpose? {/color}"

        p "Hello Banu, nice to see you again."
        p "Has everything been going well at work?"
        b "It has, thank you for asking."
        p "I love the dress you have on, it looks great on your body."
        b "You’re such a flatterer."
        scene day7-56
        b "{i} {color=#526168}He’s devouring my body with his eyes… it’s so inappropriate, but I can’t deny it’s arousing. I feared this would happen when I put on this dress. {/color}"

        p "I don’t think I’ve ever seen so much of your skin before."
        b "Hah. I just wanted to show off to Nesrin that I can be as sexy as her."
        p "I’ve always thought you were as sexy as her."
        b "Stop it! Your wife is right there!"
        p "She won’t mind, she thinks you look sexy as well."
        scene day7-57
        b "So the intern has been way better than I thought he would be."
        n "I told you it would be okay, Banu. You always worry too much."
        b "He’s actually really nice as well. I think he’ll do well in the company."
        n "Maybe he’s doing well because he thinks you’re gorgeous."
        b "Hah!"
        k "{i} {color=#526168}I have to admit Banu looks gorgeous tonight, but I don’t know if I’m comfortable with her acting this way in front of Polad. {/color} "
        k "{i} {color=#526168}He can’t keep his eyes off of her, and that’s not okay with me. {/color} "
        k "{i} {color=#526168}I should join the conversation, but I can’t help but think about how wrong this is. {/color} "
        k "{i} {color=#526168}Why would Banu wear this dress tonight? Is she into Polad? No!... {/color} "
        scene day7-58
        p "Are you okay, Kamil? You’ve been so quiet tonight."
        k "I’m fine, just deep in thought."
        p "Or you can’t help thinking about the beautiful lady next to you."
        k "{i} {color=#526168}How dare he talk about her like that to me? {/color}"
        k "{i} {color=#526168}Maybe, there is something between them? {/color}"
        scene day7-59
        b "Are you sure you’re not drinking too much, Kamil?"
        k "We’re having fun tonight, don’t worry about it."
        n "You’ve got to let your husband have some fun!"
        b "I don’t know..."
        scene day7-60
        play sound "voices/glass.wav"
        k "Cheers everyone, to an amazing gathering of friends."
        p "Cheers!"
        n "Cheers!"
        scene day7-61

        p "{i} {color=#526168}Fuck, I can’t stop staring at her. {/color} "
        p "{i} {color=#526168}I need to get myself together, I feel like I’m being too obvious. {/color} "
        p "{i} {color=#526168}I just want to bend her over this table and make her scream my name. {/color} "
        p "{i} {color=#526168}I’m going to make you mine Banu, and I know by the way you’re seducing me with that dress that you want this. {/color} "
        scene day7-62
        b "{i} {color=#526168}I feel like Polad is staring at me a lot. {/color} "
        b "{i} {color=#526168}I can feel the dirty thoughts coming out of his brain. {/color} "
        b "{i} {color=#526168}Guys are so obvious when they want you… {/color}"
        b "{i} {color=#526168}Did I subconsciously put on this dress to tease him, not Kamil? {/color}"
        b "{i} {color=#526168}Maybe I did… I feel like he can tell I wore it for him. {/color} "

label polad_teases_banu:
    scene day7-63
    b "{i} {color=#526168}There’s so much heat between us. {/color} "
    b "{i} {color=#526168}Look at the way he stares at me. {/color} "
    b "{i} {color=#526168}I want him right now. {/color} "
    b "{i} {color=#526168}Ah, Banu, what are you thinking? {/color} "
    scene day7-64
    play music "audio/sensual.mp3"
    b "{i} {color=#526168}He’s coming, I can tell. {/color}"
    b "{i} {color=#526168}Act calm, Banu. Nothing can happen here. {/color}"
    b "{i} {color=#526168}Maybe I want something to happen, though? {/color}"
    scene day7-65
    b "Hi Polad, do you need my help with anything?"
    p "No, Nesrin was just going on about something I already knew about, so I figured I would come and ask if you needed my help bringing the deserts."
    b "You’re sweet Polad, thank you, but I don’t need any help."
    p "To be honest, I have an ulterior motive for coming in here…"
    scene day7-66
    b "And what’s your ulterior motive, hmm?"
    p "I want to tell you how I feel about you, once and for all. "
    b "Polad! You shouldn’t be saying these things here."
    p "Does that mean you want me to say it elsewhere?"
    b "You know I’m married…and you have a wife as well…"
    b "And don’t forget that Alper was your best friend."
    scene day7-67
    p "I don’t care about them right now."
    p "All I can think about is how much I want your lips on mine, and how much I want to worship that body of yours."
    b "Polad..."
    p "Even the way you say my name is so fucking hot, Banu."
    p "Come closer… let me do what I’ve wanted to do all night."
    scene day7-68
    b "Polad!"
    b "Mmphh… your lips…"
    b "{i} {color=#526168}Oh this is so bad… Nesrin and Kamil are in the other room!{/color} "
    b "{i} {color=#526168}Why am I letting him kiss me? I’m so aroused. My pussy is throbbing.{/color} "
    b "{i} {color=#526168}This is too risky. I HAVE to pull back now!{/color} "
    scene day7-69
    p "Fuck, I just want to rip this dress off of you and have you right here."
    p "I know you’re desperate for someone to show you what you’ve been missing out on."
    b "Polad… we really shouldn’t…"
    p "Don’t pretend you didn’t love that kiss."
    p "I know you’re already wet for me."

    $ renpy.end_replay()
    $ persistent.polad_teases_banu_unlocked = True
    jump polad_teases_banu_continue



label polad_teases_banu_continue:

    p "I’ll leave now... this time. "
    p "I’m sure you’ll be dreaming about me tonight."
    scene day7-70
    b "{i} {color=#526168}That was so hot. {/color}"
    b "{i} {color=#526168}I feel like I can’t breathe. {/color}"
    b "{i} {color=#526168}Polad is one of the hottest men I’ve ever seen. {/color}"
    b "{i} {color=#526168}I'll need to control my urges around him. {/color}"
    stop music
label polad_teases_banu_continue_2:
    scene black with dissolve
    with Pause(2)
    if dinnerreddress == True:
        scene day7-71 with fade


        k "Banu, I need to talk to you."
        b "Yes, dear?"
        k "Do you think it was entirely appropriate for you to be wearing that dress tonight?"
        b "What do you mean?"
        k "I know you could tell Polad couldn’t stop staring at you."
        k "It’s okay when you’re not taken, but you’re my wife..."
        scene day7-72
        b "I’m sorry, Kamil. You know I meant no harm."
        b "Nesrin is always trying to show off, so I just wanted to show off too."
        b "{i} {color=#526168}That sounded stupid..{/color}"
        b "You know I’m not interested in Polad. I love you very much, and I would never even think about another man."
        k "Okay, Banu. I understand. Just don’t do it again."
        b "Okay…"
        b " {i} {color=#526168}I can tell he’s really angry...{/color}"
        b " {i} {color=#526168}Good thing he didn’t see us in the kitchen...{/color}"
        stop music


    label kamiltalkstobanuafterdinner:

        scene day7-74 with fade

        k "Did you have a nice night tonight?"
        b "Yes I did, sweetheart. I’m glad you were okay with having dinner with my friends."
        k "I’m always interested in having a meal with them, Banu. Your friends are my friends as well."
        k "I think you looked really beautiful tonight…"
        scene day7-74
        b "Do you really think so?"
        k "Yes."
        b "Thank you, Kamil, I love you very much."
        k "I can tell."
        k "I love you too, Banu."
        label kamiltalkstobanuafterdinnerafter:



            label banukamilbedroomchoices:


                menu:
                    set menuset
                    "Compliment him":

                        $ renpy.block_rollback()
                        $ banukamilbedroomchoicesblabla += 1
                        $ banu_kamil += 1
                        scene day7-74
                        b "Have you been working out lately, Kamil?"
                        k "Why do you say that?"
                        b "Because your arms… they seem even larger than normal."
                        k "Hah! I didn’t even think you noticed something like that."
                        b "Of course I notice, you’re my husband!"

                        scene day7-74
                        jump banukamilbedroomchoices
                    "Talk about Polad":


                        $ banu_kamil -= 1

                        $ renpy.block_rollback()
                        $ banukamilbedroomchoicesblabla -= 1
                        scene day7-74
                        b "Do you think Polad seemed a little quiet tonight?"
                        k "I don’t think so… he seems the same as usual."
                        k "I’m not very close with him."
                        b "Oh, maybe you should try to get to know him better."
                        k "Banu, I don’t really want to talk about Polad right now."

                        scene day7-74
                        jump banukamilbedroomchoices
                    "Ask why he was so kind with Nesrin":


                        $ banu_kamil -= 1
                        $ renpy.block_rollback()
                        $ banukamilbedroomchoicesblabla -= 1
                        scene day7-74
                        b "I think you were too sweet to Nesrin tonight…"
                        k "Are you feeling jealous?"
                        b "Of course I am, I don’t want my husband flirting with any other woman but me!"
                        k "You know I only have eyes for you, Banu."
                        k "Besides, Nesrin isn’t my type."
                        b "Oh? and what is your type?"
                        k "I don't like it when you don't trust me."



                        scene day7-74
                        jump banukamilbedroomchoices
                    "Ask him to massage you":


                        $ banu_kamil += 1

                        $ renpy.block_rollback()
                        $ banukamilbedroomchoicesblabla += 1
                        scene day7-74
                        b "Do you think you can massage my shoulders? I’m feeling a little sore."
                        k "Of course, I’m here for you sweetheart."
                        scene day7-76
                        b "Ah, that already feels so good."
                        b "You’re great with your hands."
                        k "Ask me anytime, I’m always here to relax your muscles."
                        b "Thank you, Kamil."


                        scene day7-74
                        jump banukamilbedroomchoices
                    "Say you have to wake up early tomorrow":


                        $ renpy.block_rollback()
                        scene day7-74
                        b "I’m tired from all the fun we’ve had tonight."
                        b "But I have to wake up early tomorrow, so I’ll go to sleep now."
                        scene day7-75

                        k "Goodnight Banu. Sweet dreams."
                        b "Sweet dreams..."
                        stop music
                        jump kamil_banu_sex_continue_2
                    "Tease Kamil with your body":


                        play music "audio/sexy.mp3"

                        $ banu_kamil += 1
                        $ renpy.block_rollback()
                        jump kamil_banu_sex




label kamil_banu_sex:

    scene day7-77

    b "Do you like the outfit I have on tonight?"
    k "Of course, I love that you’re only showing this off for me."
    b "That’s what a wife is supposed to do."
    k "Your skin is so soft…"
    b "I think you should touch more of it."
    k "Why don’t you lie down then? It’ll be more comfortable for you."
    scene day7-78
    k "You look so gorgeous lying there like that."
    k "I want to have my way with you right now."
    b "Kamil.."
    b "Do you think I am ready for it?"
    k "Yes, I want us to finally be together."
    b "You’ve waited long enough."
    scene day7-79
    k "Banu… I’ve waited for this moment for a very, very long time."
    b "You’ve been so patient with me. I don’t think any other man would be able to do that."
    b "I think you finally deserve your reward."
    k "I think it’ll be an amazing reward. "
    scene day7-80
    k "Your lips are so soft, Banu."
    k "I’ve imagined them on mine for many years now."
    k "And your breasts are so soft…"
    scene day7-81
    k "{i} {color=#526168}I haven’t put one of these condoms on in a long time. I forgot how awkward it feels.{/color}"
    b "I’m ready for you, Kamil."
    k "I’m going to make your body mine. "

    b "Please… fuck me, Kamil!"
    k "As you wish…"
    scene day7-82
    play music2 "voices/softmoan.mp3"
    b "Anh… Oh… it’s been so long Kamil."
    k "You’re so tight, Banu. I’ve never felt like this before."
    b "Faster.... harder, Kamil! Ah!"
    scene day7-83
    b "More, you’re driving me crazy."
    b "More Kamil. More, so much more."
    k "Banu… I’m cumming."
    k "Your pussy is milking me like crazy… I can’t take it anymore."
    scene day7-84
    k "I’m cumming! Fuck, fuck Banu. Your pussy feels so good!"
    stop music2
    scene day7-85
    b "{i} {color=#526168}I can feel the heat deep inside of me. {/color}"
    $ renpy.end_replay()
    $ persistent.kamil_banu_sex_unlocked = True
    jump kamil_banu_sex_continue

label kamil_banu_sex_continue:

    b "Oh… Kamil."
    b "{i} {color=#526168}I wasn’t expecting it to end so quickly… I was hoping for an orgasm too. {/color}"
    b " {i} {color=#526168}But it’s okay, he still did a great job.{/color}"
    scene day7-86
    stop music
    b "I can’t believe that finally happened…"
    k "I’d say we’ve waited long enough."
    b "We definitely have."
    b "It was as good as I imagined…"
    b "{i} {color=#526168}It wasn’t, but I can’t hurt his feelings. {/color} "
    b "{i} {color=#526168}I will always love him no matter what. {/color}"
    k "You’ve imagined it? You’re such a dirty girl…"
    b "Kamil!"
    k "I’m just teasing you. Come, wrap your body around mine and let’s sleep."
    b "Good night, Kamil. Sweet dreams."





label kamil_banu_sex_continue_2:



    scene black with dissolve
    with Pause(2)
    scene day7-23 with fade

    r "{i} {color=#526168}What’s that sound? {/color}"
    r "{i} {color=#526168}Sounds like a girl getting hot and heavy…. {/color} "
    r "{i} {color=#526168}Could my step-sister be having some fun without me? {/color} "
    scene day7-24
    r "{i} {color=#526168}Hah! I was right. {/color}"
    r "{i} {color=#526168}I wish I was there right now, being the one to pound her. {/color} "
    r "{i} {color=#526168}She clearly needs a real man in her life. {/color}"
    r "{i} {color=#526168}She was an idiot for not locking her door. {/color} "
    r "{i} {color=#526168}Or maybe she wanted me to discover her little secret… {/color} "
    scene day7-25
    r "{i} {color=#526168}I’ll approach her and see what happens. {/color}"
    r "{i} {color=#526168}Maybe she’ll beg me to finish the job for her. {/color}"
    r "{i} {color=#526168}Fuck, my dick is already so hard just thinking about it. {/color}"
    r "{i} {color=#526168}Look at the way her fingers are moving! Like a cat in heat. {/color}"
    scene day7-26
    l "What are you doing here, Ruslan?!"
    l "You complete freak of a step-brother!"
    l "How dare you come into my room without my permission!"
    l "Get out. Right now."
    scene day7-27
    r "Come on, baby. I’m just here to give you some company."
    l "Are you crazy? You’re my brother. What the hell is wrong with you?"
    l "I told you to get out!"
    scene day7-28
    r "You must be so needy now that a guy’s taken your virginity."
    r "Come on, you have a real man at home to take care of you, why finger yourself when you can have me deep inside of your pussy?"
    scene day7-29
    l "You’re a psychopath, Ruslan."
    l "You can’t fucking handle all this."
    l "Look at that scrawny body of yours. I’ve had so much better."
    r "Why don’t you try me and find out, baby?"
    l "Don’t call me that! I’m your sister."
    scene day7-30
    l "You’re a disgusting pig and you know it. "
    l "I don’t know how many times I need to tell you to get the hell out!"
    l "I have some unfinished business to do."
    l "Which you’ve clearly interrupted."
    scene day7-31
    r "Unfinished business? You hoe, that’s what I’m here for."
    r "Come and give me a kiss, sister. "
    r "I’m all yours. "
    l "Ruslan! Stop this instant!"
    scene day7-32
    r "Feel how hard my dick is for you, baby."
    r "Don’t you want that inside of you?"
    r "I can fucking tear you apart."
    r "Your nipples are already so hard for me… I know you want it."
    scene day7-33
    l "Get out! "
    l "GET OUT RIGHT NOW!"
    l "I’m going to tell mom you did this, and they’ll fucking kick you out of the house."
    l "LEAVE THIS INSTANT!"
    scene day7-34
    r "Hey, no need to scream."
    r "I’ll be here when you realize you can’t satisfy yourself."
    r "And when the time comes, I’ll make you scream louder than you did today."
    scene day7-35
    l "{i} {color=#526168}That creep. {/color} "
    l "{i} {color=#526168}I can’t believe I live with him. {/color} "
    l "{i} {color=#526168}I’m going to tell mom about this.... {/color} "
    l "{i} {color=#526168}Okay, I won’t. But if he does it again, I’ll make sure he’s kicked out of this house. {/color} "
    l "{i} {color=#526168}I should probably lock the door this time.... {/color}"
    stop music








    jump v7
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
