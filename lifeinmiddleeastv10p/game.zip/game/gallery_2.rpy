


init python:

    import math 

    def add_gallery_scene(scene_label, gallery_scene_name, gallery_i_2mage_path ):
        """
        All arguments must be string.
        """
        if [scene_label, gallery_scene_name, im.Scale(gallery_i_2mage_path,500,300)] not in persistent.gallery_b_2_list:
            persistent.gallery_b_2_list.append([scene_label, gallery_scene_name, im.Scale(gallery_i_2mage_path,500,300)])




screen gallery_navigation_2():


    add "images/gallerybackground.jpg"





    textbutton _("UNLOCK ALL"):
        xpos 1500
        ypos 80

        action [
            SetVariable("gallery_unlock_all", True),
            SetVariable("persistent.ruslan_ending_unlocked", True),
            SetVariable("persistent.kamilkillsbanu_ending_unlocked", True),
            SetVariable("persistent.kamilkillspolad_ending_unlocked", True),
            SetVariable("persistent.banukeepcheating_ending_unlocked", True),
            SetVariable("persistent.turan_ending_unlocked", True),
            SetVariable("persistent.hassanending_unlocked", True),
            SetVariable("persistent.polad_ending_unlocked", True),
            SetVariable("persistent.powerending_unlocked", True),
            SetVariable("persistent.camalending_unlocked", True),
            SetVariable("persistent.marry_unlocked", True),
            SetVariable("persistent.mafia_unlocked", True),
            SetVariable("persistent.developed_unlocked", True),
            SetVariable("persistent.cuck_unlocked", True),
            
            [Return(), Hide("gallery_navigation")],    
            [ShowMenu("gallery_navigation_2"), Show("gallery_a_2")]
       

    ]





    default gallery_unlock_all = False



    default ruslan_ending_unlocked = False































    viewport id ("gallery_scroll"):
        mousewheel True
        ypos 140
        xpos 30
        ymaximum 800
        has vbox
        style_prefix "gallery_nav"


        textbutton _("Endings_a") action Show("gallery_a_2")
        textbutton _("Endings_b") action Show("gallery_b_2")
        textbutton _("Endings_c") action Show("gallery_c_2")
        textbutton _("Endings_d") action Show("gallery_e_2")
        textbutton _("Endings_e") action Show("gallery_f_2")
        textbutton _("Endings_f") action Show("gallery_g_2")
        textbutton _("Endings_g") action Show("gallery_h_2")
        textbutton _("Endings_h") action Show("gallery_i_2")
        textbutton _("Endings_l") action Show("gallery_j_2")
        textbutton _("Endings_m") action Show("gallery_k_2")
        textbutton _("Endings_n") action Show("gallery_l_2")

    vbar value YScrollValue("gallery_scroll") xpos 300 ypos 140 ymaximum 800




    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]


style gallery_nav_vbox:
    xalign 0.03
    yalign 0.5
    spacing 40


python:
    """


        """




screen gallery_a_2():
    default gallery_a_2_list = [
            
            
            ["kamilkillsbanu_ending","{color=#ababab}Ending 1{/color}", im.Scale("images/ending_kamil_kill_banu_grey.jpg", 500, 300), im.Scale("images/ending_kamil_kill_banu.jpg", 500, 300), persistent.kamilkillsbanu_ending_unlocked],
            ["kamilkillspolad_ending","{color=#ababab}Ending 2{/color}", im.Scale("images/kamikillpoladending_grey.jpg", 500, 300), im.Scale("images/kamikillpoladending.jpg", 500, 300), persistent.kamilkillspolad_ending_unlocked],
            ["banukeepcheating_ending","{color=#ababab}Ending 3{/color}", im.Scale("images/banukeepscheatingending_gallery_grey.jpg", 500, 300), im.Scale("images/banukeepscheatingending_gallery.jpg", 500, 300), persistent.banukeepcheating_ending_unlocked]

            

        ]

    style_prefix "navigation" tag menu



    default total_scenes = len(gallery_a_2_list)
    default cg_page_a = 1
    default cg_page_a_max = max(int(total_scenes / 4) + (total_scenes % 4 > 0), 1)

    zorder 100







    hbox:

        xalign 0.5
        yalign 0.5

        grid 2 2:

            xalign 0.5
            yalign 0.5
            xspacing 20
            yspacing 20

            for i in range(((cg_page_a-1)*4),(cg_page_a*4)):
                if i < len(gallery_a_2_list):
                    vbox:
                        imagebutton:
                            action Replay(gallery_a_2_list[i][0], scope={ }, locked=not  gallery_a_2_list[i][4])
                            idle Transform(gallery_a_2_list[i][2], zoom=1)
                            hover gallery_a_2_list[i][3]



                        text str(gallery_a_2_list[i][1]):
                            color "#262626"
                            bold True
                            xalign 0.5
                else:
                    null

    hbox:
        xalign 0.5
        yalign 0.99


        textbutton _("Prev") action [SetLocalVariable("cg_page_a", If(cg_page_a>1, cg_page_a-1, cg_page_a_max))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]



        for page in range(1, cg_page_a_max+1):
            if page == cg_page_a:
                textbutton "{color=#ffa237}{b}[page]{/b}{/color}" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]
            else:
                textbutton "[page]" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]

        textbutton _("Next") action [SetLocalVariable("cg_page_a", If(cg_page_a<cg_page_a_max, cg_page_a+1, 1))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]


    textbutton _("Return") action [Return(), Hide("gallery_navigation")] xalign 0.97 yalign 0.95


    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]


screen gallery_b_2():
    default gallery_b_2_list = [
            
            
            ["ruslan_ending","{color=#ababab}Ending 4{/color}", im.Scale("images/ending_ruslan_grey.jpg", 500, 300), im.Scale("images/ending_ruslan.jpg", 500, 300), persistent.ruslan_ending_unlocked],
            ["turan_ending","{color=#ababab}Ending 5{/color}", im.Scale("images/ending_turan_grey.jpg", 500, 300), im.Scale("images/ending_turan.jpg", 500, 300), persistent.turan_ending_unlocked],
            ["hassanending","{color=#ababab}Ending 6{/color}", im.Scale("images/ending_hassan_grey.jpg", 500, 300), im.Scale("images/ending_hassan.jpg", 500, 300), persistent.hassanending_unlocked]


        ]

    style_prefix "navigation" tag menu



    default total_scenes = len(gallery_b_2_list)
    default cg_page_a = 1
    default cg_page_a_max = max(int(total_scenes / 4) + (total_scenes % 4 > 0), 1)

    zorder 100







    hbox:

        xalign 0.5
        yalign 0.5

        grid 2 2:

            xalign 0.5
            yalign 0.5
            xspacing 20
            yspacing 20

            for i in range(((cg_page_a-1)*4),(cg_page_a*4)):
                if i < len(gallery_b_2_list):
                    vbox:
                        imagebutton:
                            action Replay(gallery_b_2_list[i][0], scope={ }, locked=not  gallery_b_2_list[i][4])
                            idle Transform(gallery_b_2_list[i][2], zoom=1)
                            hover gallery_b_2_list[i][3]



                        text str(gallery_b_2_list[i][1]):
                            color "#262626"
                            bold True
                            xalign 0.5
                else:
                    null

    hbox:
        xalign 0.5
        yalign 0.99


        textbutton _("Prev") action [SetLocalVariable("cg_page_a", If(cg_page_a>1, cg_page_a-1, cg_page_a_max))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]



        for page in range(1, cg_page_a_max+1):
            if page == cg_page_a:
                textbutton "{color=#ffa237}{b}[page]{/b}{/color}" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]
            else:
                textbutton "[page]" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]

        textbutton _("Next") action [SetLocalVariable("cg_page_a", If(cg_page_a<cg_page_a_max, cg_page_a+1, 1))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]


    textbutton _("Return") action [Return(), Hide("gallery_navigation")] xalign 0.97 yalign 0.95


    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]


screen gallery_c_2():
    default gallery_c_2_list = [
            
            
            ["polad_ending","{color=#ababab}Ending 7{/color}", im.Scale("images/ending_polad_grey.jpg", 500, 300), im.Scale("images/ending_polad.jpg", 500, 300), persistent.polad_ending_unlocked],
            ["powerending","{color=#ababab}Ending 8{/color}", im.Scale("images/powerendinggallery_grey.jpg", 500, 300), im.Scale("images/powerendinggallery.jpg", 500, 300), persistent.powerending_unlocked]

            

        ]

    style_prefix "navigation" tag menu



    default total_scenes = len(gallery_c_2_list)
    default cg_page_a = 1
    default cg_page_a_max = max(int(total_scenes / 4) + (total_scenes % 4 > 0), 1)

    zorder 100







    hbox:

        xalign 0.5
        yalign 0.5

        grid 2 2:

            xalign 0.5
            yalign 0.5
            xspacing 20
            yspacing 20

            for i in range(((cg_page_a-1)*4),(cg_page_a*4)):
                if i < len(gallery_c_2_list):
                    vbox:
                        imagebutton:
                            action Replay(gallery_c_2_list[i][0], scope={ }, locked=not  gallery_c_2_list[i][4])
                            idle Transform(gallery_c_2_list[i][2], zoom=1)
                            hover gallery_c_2_list[i][3]



                        text str(gallery_c_2_list[i][1]):
                            color "#262626"
                            bold True
                            xalign 0.5
                else:
                    null

    hbox:
        xalign 0.5
        yalign 0.99


        textbutton _("Prev") action [SetLocalVariable("cg_page_a", If(cg_page_a>1, cg_page_a-1, cg_page_a_max))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]



        for page in range(1, cg_page_a_max+1):
            if page == cg_page_a:
                textbutton "{color=#ffa237}{b}[page]{/b}{/color}" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]
            else:
                textbutton "[page]" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]

        textbutton _("Next") action [SetLocalVariable("cg_page_a", If(cg_page_a<cg_page_a_max, cg_page_a+1, 1))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]


    textbutton _("Return") action [Return(), Hide("gallery_navigation")] xalign 0.97 yalign 0.95


    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]


screen gallery_e_2():
    default gallery_e_2_list = [
            
            
            ["camalending","{color=#ababab}Ending 9{/color}", im.Scale("images/camalendinggallery_grey.jpg", 500, 300), im.Scale("images/camalendinggallery.jpg", 500, 300), persistent.camalending_unlocked]

            

        ]

    style_prefix "navigation" tag menu



    default total_scenes = len(gallery_e_2_list)
    default cg_page_a = 1
    default cg_page_a_max = max(int(total_scenes / 4) + (total_scenes % 4 > 0), 1)

    zorder 100







    hbox:

        xalign 0.5
        yalign 0.5

        grid 2 2:

            xalign 0.5
            yalign 0.5
            xspacing 20
            yspacing 20

            for i in range(((cg_page_a-1)*4),(cg_page_a*4)):
                if i < len(gallery_e_2_list):
                    vbox:
                        imagebutton:
                            action Replay(gallery_e_2_list[i][0], scope={ }, locked=not  gallery_e_2_list[i][4])
                            idle Transform(gallery_e_2_list[i][2], zoom=1)
                            hover gallery_e_2_list[i][3]



                        text str(gallery_e_2_list[i][1]):
                            color "#262626"
                            bold True
                            xalign 0.5
                else:
                    null

    hbox:
        xalign 0.5
        yalign 0.99


        textbutton _("Prev") action [SetLocalVariable("cg_page_a", If(cg_page_a>1, cg_page_a-1, cg_page_a_max))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]



        for page in range(1, cg_page_a_max+1):
            if page == cg_page_a:
                textbutton "{color=#ffa237}{b}[page]{/b}{/color}" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]
            else:
                textbutton "[page]" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]

        textbutton _("Next") action [SetLocalVariable("cg_page_a", If(cg_page_a<cg_page_a_max, cg_page_a+1, 1))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]


    textbutton _("Return") action [Return(), Hide("gallery_navigation")] xalign 0.97 yalign 0.95


    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]


screen gallery_f_2():
    default gallery_f_2_list = [
            
            
            ["marry","{color=#ababab}Ending 10{/color}", im.Scale("images/marryendinggallery_grey.jpg", 500, 300), im.Scale("images/marryendinggallery.jpg", 500, 300), persistent.marry_unlocked],
            ["mafia","{color=#ababab}Ending 11{/color}", im.Scale("images/mafiaendinggallery_grey.jpg", 500, 300), im.Scale("images/mafiaendinggallery.jpg", 500, 300), persistent.mafia_unlocked],
            ["developed","{color=#ababab}Ending 12{/color}", im.Scale("images/developedendinggallery_grey.jpg", 500, 300), im.Scale("images/developedendinggallery.jpg", 500, 300), persistent.developed_unlocked]

            

        ]

    style_prefix "navigation" tag menu



    default total_scenes = len(gallery_f_2_list)
    default cg_page_a = 1
    default cg_page_a_max = max(int(total_scenes / 4) + (total_scenes % 4 > 0), 1)

    zorder 100







    hbox:

        xalign 0.5
        yalign 0.5

        grid 2 2:

            xalign 0.5
            yalign 0.5
            xspacing 20
            yspacing 20

            for i in range(((cg_page_a-1)*4),(cg_page_a*4)):
                if i < len(gallery_f_2_list):
                    vbox:
                        imagebutton:
                            action Replay(gallery_f_2_list[i][0], scope={ }, locked=not  gallery_f_2_list[i][4])
                            idle Transform(gallery_f_2_list[i][2], zoom=1)
                            hover gallery_f_2_list[i][3]



                        text str(gallery_f_2_list[i][1]):
                            color "#262626"
                            bold True
                            xalign 0.5
                else:
                    null

    hbox:
        xalign 0.5
        yalign 0.99


        textbutton _("Prev") action [SetLocalVariable("cg_page_a", If(cg_page_a>1, cg_page_a-1, cg_page_a_max))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]



        for page in range(1, cg_page_a_max+1):
            if page == cg_page_a:
                textbutton "{color=#ffa237}{b}[page]{/b}{/color}" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]
            else:
                textbutton "[page]" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]

        textbutton _("Next") action [SetLocalVariable("cg_page_a", If(cg_page_a<cg_page_a_max, cg_page_a+1, 1))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]


    textbutton _("Return") action [Return(), Hide("gallery_navigation")] xalign 0.97 yalign 0.95


    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]


screen gallery_g_2():
    default gallery_g_2_list = [
            
            
            ["cuck","{color=#ababab}Ending 13{/color}", im.Scale("images/cuckendinggallery_grey.jpg", 500, 300), im.Scale("images/cuckendinggallery.jpg", 500, 300), persistent.cuck_unlocked]


        ]

    style_prefix "navigation" tag menu



    default total_scenes = len(gallery_g_2_list)
    default cg_page_a = 1
    default cg_page_a_max = max(int(total_scenes / 4) + (total_scenes % 4 > 0), 1)

    zorder 100







    hbox:

        xalign 0.5
        yalign 0.5

        grid 2 2:

            xalign 0.5
            yalign 0.5
            xspacing 20
            yspacing 20

            for i in range(((cg_page_a-1)*4),(cg_page_a*4)):
                if i < len(gallery_g_2_list):
                    vbox:
                        imagebutton:
                            action Replay(gallery_g_2_list[i][0], scope={ }, locked=not  gallery_g_2_list[i][4])
                            idle Transform(gallery_g_2_list[i][2], zoom=1)
                            hover gallery_g_2_list[i][3]



                        text str(gallery_g_2_list[i][1]):
                            color "#262626"
                            bold True
                            xalign 0.5
                else:
                    null

    hbox:
        xalign 0.5
        yalign 0.99


        textbutton _("Prev") action [SetLocalVariable("cg_page_a", If(cg_page_a>1, cg_page_a-1, cg_page_a_max))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]



        for page in range(1, cg_page_a_max+1):
            if page == cg_page_a:
                textbutton "{color=#ffa237}{b}[page]{/b}{/color}" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]
            else:
                textbutton "[page]" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]

        textbutton _("Next") action [SetLocalVariable("cg_page_a", If(cg_page_a<cg_page_a_max, cg_page_a+1, 1))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]


    textbutton _("Return") action [Return(), Hide("gallery_navigation")] xalign 0.97 yalign 0.95


    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]


screen gallery_h_2():
    tag menu
    default gallery_h_2_list = [
            
            
            ["question_mark","{color=#ababab}?????{/color}", im.Scale("images/qustion_mark.jpg", 500, 300), im.Scale("images/qustion_mark.jpg", 500, 300), persistent.question_mark_unlocked]

        ]

    style_prefix "navigation"



    default total_scenes = len(gallery_h_2_list)
    default cg_page_a = 1
    default cg_page_a_max = max(int(total_scenes / 4) + (total_scenes % 4 > 0), 1)

    zorder 100







    hbox:

        xalign 0.5
        yalign 0.5

        grid 2 2:

            xalign 0.5
            yalign 0.5
            xspacing 20
            yspacing 20

            for i in range(((cg_page_a-1)*4),(cg_page_a*4)):
                if i < len(gallery_h_2_list):
                    vbox:
                        imagebutton:
                            action Replay(gallery_h_2_list[i][0], scope={ }, locked=not  gallery_h_2_list[i][4])
                            idle Transform(gallery_h_2_list[i][2], zoom=1)
                            hover gallery_h_2_list[i][3]



                        text str(gallery_h_2_list[i][1]):
                            color "#262626"
                            bold True
                            xalign 0.5
                else:
                    null

    hbox:
        xalign 0.5
        yalign 0.99


        textbutton _("Prev") action [SetLocalVariable("cg_page_a", If(cg_page_a>1, cg_page_a-1, cg_page_a_max))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]



        for page in range(1, cg_page_a_max+1):
            if page == cg_page_a:
                textbutton "{color=#ffa237}{b}[page]{/b}{/color}" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]
            else:
                textbutton "[page]" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]

        textbutton _("Next") action [SetLocalVariable("cg_page_a", If(cg_page_a<cg_page_a_max, cg_page_a+1, 1))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]


    textbutton _("Return") action [Return(), Hide("gallery_navigation")] xalign 0.97 yalign 0.95


    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]


screen gallery_i_2():
    default gallery_i_2_list = [
            
            
            ["question_mark","{color=#ababab}?????{/color}", im.Scale("images/qustion_mark.jpg", 500, 300), im.Scale("images/qustion_mark.jpg", 500, 300), persistent.question_mark_unlocked] 

            

        ]

    style_prefix "navigation" tag menu



    default total_scenes = len(gallery_i_2_list)
    default cg_page_a = 1
    default cg_page_a_max = max(int(total_scenes / 4) + (total_scenes % 4 > 0), 1)

    zorder 100







    hbox:

        xalign 0.5
        yalign 0.5

        grid 2 2:

            xalign 0.5
            yalign 0.5
            xspacing 20
            yspacing 20

            for i in range(((cg_page_a-1)*4),(cg_page_a*4)):
                if i < len(gallery_i_2_list):
                    vbox:
                        imagebutton:
                            action Replay(gallery_i_2_list[i][0], scope={ }, locked=not  gallery_i_2_list[i][4])
                            idle Transform(gallery_i_2_list[i][2], zoom=1)
                            hover gallery_i_2_list[i][3]



                        text str(gallery_i_2_list[i][1]):
                            color "#262626"
                            bold True
                            xalign 0.5
                else:
                    null

    hbox:
        xalign 0.5
        yalign 0.99


        textbutton _("Prev") action [SetLocalVariable("cg_page_a", If(cg_page_a>1, cg_page_a-1, cg_page_a_max))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]



        for page in range(1, cg_page_a_max+1):
            if page == cg_page_a:
                textbutton "{color=#ffa237}{b}[page]{/b}{/color}" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]
            else:
                textbutton "[page]" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]

        textbutton _("Next") action [SetLocalVariable("cg_page_a", If(cg_page_a<cg_page_a_max, cg_page_a+1, 1))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]


    textbutton _("Return") action [Return(), Hide("gallery_navigation")] xalign 0.97 yalign 0.95


    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]


screen gallery_j_2():
    default gallery_j_2_list = [
            
            
            ["question_mark","{color=#ababab}?????{/color}", im.Scale("images/qustion_mark.jpg", 500, 300), im.Scale("images/qustion_mark.jpg", 500, 300), persistent.question_mark_unlocked]


        ]

    style_prefix "navigation" tag menu



    default total_scenes = len(gallery_j_2_list)
    default cg_page_a = 1
    default cg_page_a_max = max(int(total_scenes / 4) + (total_scenes % 4 > 0), 1)

    zorder 100







    hbox:

        xalign 0.5
        yalign 0.5

        grid 2 2:

            xalign 0.5
            yalign 0.5
            xspacing 20
            yspacing 20

            for i in range(((cg_page_a-1)*4),(cg_page_a*4)):
                if i < len(gallery_j_2_list):
                    vbox:
                        imagebutton:
                            action Replay(gallery_j_2_list[i][0], scope={ }, locked=not  gallery_j_2_list[i][4])
                            idle Transform(gallery_j_2_list[i][2], zoom=1)
                            hover gallery_j_2_list[i][3]



                        text str(gallery_j_2_list[i][1]):
                            color "#262626"
                            bold True
                            xalign 0.5
                else:
                    null

    hbox:
        xalign 0.5
        yalign 0.99


        textbutton _("Prev") action [SetLocalVariable("cg_page_a", If(cg_page_a>1, cg_page_a-1, cg_page_a_max))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]



        for page in range(1, cg_page_a_max+1):
            if page == cg_page_a:
                textbutton "{color=#ffa237}{b}[page]{/b}{/color}" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]
            else:
                textbutton "[page]" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]

        textbutton _("Next") action [SetLocalVariable("cg_page_a", If(cg_page_a<cg_page_a_max, cg_page_a+1, 1))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]


    textbutton _("Return") action [Return(), Hide("gallery_navigation")] xalign 0.97 yalign 0.95


    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]


screen gallery_k_2():
    default gallery_k_2_list = [
            
            
            ["question_mark","{color=#ababab}?????{/color}", im.Scale("images/qustion_mark.jpg", 500, 300), im.Scale("images/qustion_mark.jpg", 500, 300), persistent.question_mark_unlocked]


        ]

    style_prefix "navigation" tag menu



    default total_scenes = len(gallery_k_2_list)
    default cg_page_a = 1
    default cg_page_a_max = max(int(total_scenes / 4) + (total_scenes % 4 > 0), 1)

    zorder 100







    hbox:

        xalign 0.5
        yalign 0.5

        grid 2 2:

            xalign 0.5
            yalign 0.5
            xspacing 20
            yspacing 20

            for i in range(((cg_page_a-1)*4),(cg_page_a*4)):
                if i < len(gallery_k_2_list):
                    vbox:
                        imagebutton:
                            action Replay(gallery_k_2_list[i][0], scope={ }, locked=not  gallery_k_2_list[i][4])
                            idle Transform(gallery_k_2_list[i][2], zoom=1)
                            hover gallery_k_2_list[i][3]



                        text str(gallery_k_2_list[i][1]):
                            color "#262626"
                            bold True
                            xalign 0.5
                else:
                    null

    hbox:
        xalign 0.5
        yalign 0.99


        textbutton _("Prev") action [SetLocalVariable("cg_page_a", If(cg_page_a>1, cg_page_a-1, cg_page_a_max))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]



        for page in range(1, cg_page_a_max+1):
            if page == cg_page_a:
                textbutton "{color=#ffa237}{b}[page]{/b}{/color}" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]
            else:
                textbutton "[page]" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]

        textbutton _("Next") action [SetLocalVariable("cg_page_a", If(cg_page_a<cg_page_a_max, cg_page_a+1, 1))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]


    textbutton _("Return") action [Return(), Hide("gallery_navigation")] xalign 0.97 yalign 0.95


    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]


screen gallery_l_2():
    default gallery_l_2_list = [
            
            
            ["question_mark","{color=#ababab}?????{/color}", im.Scale("images/qustion_mark.jpg", 500, 300), im.Scale("images/qustion_mark.jpg", 500, 300), persistent.question_mark_unlocked]


        ]

    style_prefix "navigation" tag menu



    default total_scenes = len(gallery_l_2_list)
    default cg_page_a = 1
    default cg_page_a_max = max(int(total_scenes / 4) + (total_scenes % 4 > 0), 1)

    zorder 100







    hbox:

        xalign 0.5
        yalign 0.5

        grid 2 2:

            xalign 0.5
            yalign 0.5
            xspacing 20
            yspacing 20

            for i in range(((cg_page_a-1)*4),(cg_page_a*4)):
                if i < len(gallery_l_2_list):
                    vbox:
                        imagebutton:
                            action Replay(gallery_l_2_list[i][0], scope={ }, locked=not  gallery_l_2_list[i][4])
                            idle Transform(gallery_l_2_list[i][2], zoom=1)
                            hover gallery_l_2_list[i][3]



                        text str(gallery_l_2_list[i][1]):
                            color "#262626"
                            bold True
                            xalign 0.5
                else:
                    null

    hbox:
        xalign 0.5
        yalign 0.99


        textbutton _("Prev") action [SetLocalVariable("cg_page_a", If(cg_page_a>1, cg_page_a-1, cg_page_a_max))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]



        for page in range(1, cg_page_a_max+1):
            if page == cg_page_a:
                textbutton "{color=#ffa237}{b}[page]{/b}{/color}" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]
            else:
                textbutton "[page]" action SetLocalVariable("cg_page_a", page) text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]

        textbutton _("Next") action [SetLocalVariable("cg_page_a", If(cg_page_a<cg_page_a_max, cg_page_a+1, 1))] text_outlines [ (absolute(2), "#000", absolute(0), absolute(0)) ]


    textbutton _("Return") action [Return(), Hide("gallery_navigation")] xalign 0.97 yalign 0.95


    key "K_ESCAPE" action [Return(), Hide("gallery_navigation")]
    key "mouseup_3" action [Return(), Hide("gallery_navigation")]
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
