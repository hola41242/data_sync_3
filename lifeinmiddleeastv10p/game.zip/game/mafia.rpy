


label mafia:


    scene black with Dissolve(3)
    ""
    centered "{size=+120}1 year later...{/size}" with Fade(0.5, 0.5, 5)
    scene black with dissolve
    b_ "After my divorce from Kamil, life took a drastic turn. With nowhere to go, I chose to live in Polad's apartment, seeking refuge from the chaos of my personal life."
    b_ "The freedom of being divorced, coupled with the loss of my previous job, led me down an unexpected path."
    b_ "In the midst of uncertainty, an offer came my way that I couldn't refuse."
    b_ "The enigmatic and powerful mafia boss presented me with an opportunity, a job that promised financial security and a life far removed from my past. "
    b_ "With little choice, I accepted the offer, stepping into a world I had never imagined being a part of."
    scene v18-183 with dissolve
    b_ "Under the influence of my newfound lifestyle, I embraced a transformation that went far beyond the surface."
    b_ "One of the most noticeable changes was the ink that now adorned my skin."
    b_ "Tattoo after tattoo, I allowed their needles to etch intricate designs on different parts of my body."
    b_ "The pain of the tattoo needle was nothing compared to the battles I fought daily in the criminal underworld."
    b_ "I had become dependent on the enigmatic figurehead, the mafia boss who held the strings of my fate in his hands."
    scene v18-184
    b_ "With each passing day, my reliance on him grew."
    b_ "I was bound to his commands, my actions dictated by his whims."
    b_ "I was no longer just an individual; I was a pawn in a dangerous game, a player whose moves were controlled by unseen hands."
    scene v18-185
    b_ "I messed up the first job the Boss gave me, and that mistake made me totally reliant on them."
    b_ "It felt like I was hanging by a thread, my future in their hands. I had to work closely with the mafia crew, constantly under their watchful eyes."
    b_ "Every move I made was scrutinized, and it felt like I was trapped."
    b_ "They controlled my moves, my body, my mind and everything I had."
    b_ "The mafia boss and his crew didn't stop at just controlling me; they used threats to keep me in line. They targeted my loved ones, those closest to my heart."
    b_ "The fear of harm befalling the people I cared about weighed heavily on me, forcing me into a state of constant anxiety and vulnerability."
    b_ "I had to obey what he said..."
    scene v18-186 with fade
    play music "audio/sensual.mp3"
    b_ "Boss used me whenever he wanted to satisfy his sexual needs."
    b_ "I couldn't go against him. He was a dangerous man. He was so different from the men I knew. "
    b_ "I couldn't say no to him every time he asked me to undress."
    b_ "The mafia boss was a terrifying sight to behold."
    b_ "He was a huge man, with a massive belly and a tall stature that made him even more imposing."
    scene v18-187
    b_ "His distinguishing feature was a large mustache that seemed to emphasize his intimidating appearance."
    b_ "Whenever he was around, I felt utterly powerless and small in comparison."
    scene v18-188
    b_ "His mere presence silenced the room, and I couldn't find the strength to resist him."
    b_ "I felt weak and vulnerable, unable to refuse his demands or stand up to him. "
    b_ "His eyes, sharp and penetrating, seemed to see right through me, leaving me with a paralyzing fear."
    b_ "It was as if I was completely under his control, unable to assert myself or say no to his commands."
    scene v18-189
    b_ "Sometimes my job was to shut up and give pleasure to his thick cock."
    b_ "His cock was the thickest cock I had ever seen."
    b_ "His sheer size was overwhelming, and I, despite not being short myself, felt dwarfed in his presence."
    scene v18-190
    b_ "His physicality alone was enough to instill fear and submission in anyone who stood before him."
    b_ "I felt insignificant, a tiny figure in the shadow of his daunting presence, unable to match his intimidating stature despite my own height."
    b_ "Sometimes, when the boss looked at me, there was something in his eyes, a strange emotion hidden behind his stern expression."
    scene v18-191
    b_ "I couldn't quite figure it out, but it made our interactions more complicated."
    b_ "I was thinking maybe he had some feelings for me...I didn't even know if that would be a good or bad thing."
    b_ "At that moment, all I was thinking about was his fat dick inside of me."
    b_ "I was turned on so much by him. He looked like a typical eastern man who had a big belly and only cared about money and food."
    b_ "But he had his own rules that nobody could break."
    scene v18-192
    b_ "Whenever I looked into the boss's eyes, I felt a strange connection, a powerful attraction to his strong, manly presence."
    b_ "It was as if there was an invisible force pulling me towards him."
    scene v18-193
    b_ "I was so horny. I just wanted to be fucked by him."
    b_ "I moved my hips letting his meaty dick find its way to my tight pussy."
    b_ "It gave my pussy a good stretching and I started riding him."
    scene v18-194
    b_ "Sex with the boss in that room was intense, to say the least."
    b_ "Every time we were together, the atmosphere felt charged with something electric."
    b_ "His presence was overwhelming, and I couldn't help but be drawn to him."
    scene v18-195
    b_ "In those private moments, it was like we were speaking a silent language."
    b_ "Our bodies were so compatible. He was teaching my body how to be feminine and obedient."
    b_ "He was giving me what I wanted. "
    b_ "It was a dance of desire and control, a mix of vulnerability and strength."
    scene v18-196
    b_ "That red room became a place where our worlds collided, and I felt a whirlwind of emotions."
    b_ "Despite the complexity of our relationship, those moments left a lasting impression on me, a reminder of the undeniable attraction and a great sex that pulled us together."
    scene v18-197
    b_ "There were so many sides to him. Sometimes he treated me like a fuckdoll but sometimes like an elegant woman."
    b_ "I enjoyed both. Especially, the first one."
    b_ "I had never been fucked like that before."
    b_ "It was humiliating but so enjoyable at the same time."
    scene v18-198
    b_ "With his big dick inside of me and the weight of him on my body I felt like I was going to die."
    b_ "I understood that I was being used but I can't deny that I enjoyed it."
    b_ "He could do whatever he wanted. My body belonged to him at that time. "
    scene v18-199
    b_ "He came inside of me every time but I couldn't ask him to pull it out."
    b_ "I felt completely powerless when he was around. Especially when he was inside of me."
    b_ "His confidence and authority were so overwhelming that I couldn't find the strength to say no."
    b_ "His presence alone seemed to erase my ability to resist his requests."
    b_ "It was like my own will didn't matter anymore; I had no choice but to do as he said."
    b_ "His dominance left me feeling trapped and unable to stand up for myself."
    scene black with dissolve
    stop music
    b_ "My job was to deliver the drugs to the buyers."
    b_ "I was thinking about my next task and how would I do it. "

    b_ "I kept wearing hijab despite I was not the same Banu because nobody would suspect a woman wearing hijab could carry cocaine in her bag."
    scene v18-200 with pixellate
    b_ "As I approached the desolate factory, my heart raced with anxiety."
    b_ "The weight of the illegal parcel in my hands felt like a burden too heavy to bear."
    b_ "The boss's instructions echoed in my mind, reminding me of the consequences if I failed."
    scene v18-201
    b_ "With every step, I grew more apprehensive, my palms sweaty and my breath shallow."
    b_ "The moment arrived, and I spotted the young boy waiting in the shadows, his eyes wide with anticipation."
    scene v18-202
    b_ "I handed him the bag, trying to keep my trembling hands steady."
    b_ "His innocent face contrasted sharply with the sinister nature of our exchange."
    scene v18-203
    b_ "I wished I could shield him from the darkness that surrounded us, but I was trapped in a world dictated by the choices I had made."
    b_ "His eyes, wide and filled with anticipation, mirrored the vulnerability I felt deep inside."
    scene v18-204
    b_ "I wish I could protect him."
    b_ "My trembling hands betrayed my facade of composure as I handed him the package, our fingers briefly touching."
    b_ "I wanted to tell him to run, to escape this dangerous world before it consumed him entirely."
    b_ "But words failed me; my voice was drowned out by the echoes of my own fear."
    scene v18-205
    b_ "As I walked away, the weight of our encounter settled heavily on my shoulders."
    b_ "The image of the young boy lingered in my mind, a haunting reminder of the innocence I had encountered in the midst of darkness."
    b_ "I questioned the path I had chosen, the decisions that had led me to this point."
    b_ "Yet, I knew deep down that escaping this web of criminality was far from simple."
    scene black with dissolve
    b_ "In a dimly lit room at the mafia's billiards hangout, it was just me and Hicran, my friend who introduced me to this secret world."
    scene v18-206 with dissolve
    b_ "We were hidden away from prying eyes, and the atmosphere was filled with a mix of mystery and tension, as the neon lights cast a faint glow."
    b_ "Hicran, who was well-versed in the secretive ways of the mafia, entered the room wearing only her underwear, exuding confidence and a sense of belonging to this hidden world."
    b_ "Her hairstyle had changed during the past year, going from long and flowing to a shorter, more daring look."
    scene v18-207
    b_ "I, on the other hand, had donned a mini blue dress in an attempt to hold onto some semblance of normalcy in a life that had become increasingly shrouded in darkness."
    b_ "The contrast between Hicran's boldness and my struggle to maintain a connection with my former self was quite apparent, showcasing the different ways we were adapting to our dangerous new reality."
    b_ "As we stood there, our eyes met, silently communicating the understanding that only two people entangled in a world of secrets and danger can share."
    scene v18-208
    b_ "She was again inviting me to use that drug."
    b_ "I used the drug the day before and I felt really good. I just didn't want to get eddicted to it."
    b_ "But seeing Hicran sniffing it and turning into a different person, I also wanted to forget all my problems and cares."
    scene v18-209
    b_ "Only this time and never again..."
    b_ "In that moment, as I stood under the dim lights of the room, I could feel Hicran's eyes on me."
    scene v18-210
    b_ "I felt better and a few moments later I felt Hicran's presence behind me caressing my back."
    b_ "In those quiet moments, Hicran and I found a connection that went beyond words."
    scene v18-211
    b_ "Our feelings for each other were unspoken yet deeply understood."
    b_ "We didn't need elaborate declarations; the passion between us was evident in the small gestures, the lingering touches, and the way our eyes met, carrying a world of emotions."
    scene v18-212
    b_ "Our story was subtle, hidden in stolen glances and shared smiles."
    b_ "It was in the way our hands brushed against each other, conveying a promise that words couldn't capture."
    b_ "We didn't need grand speeches; our actions spoke volumes about the affection we held for one another."
    scene v18-213
    b_ "Hicran was always dominant in the connection between us."
    b_ "In the intricate dance of our connection, it was Hicran who held the reins, guiding our unspoken desires and hidden emotions. "
    b_ "She exuded a dominant energy, a quiet strength that drew me in, creating a magnetic pull I couldn't resist."
    scene v18-214
    b_ "She gave me powerful orgasms that no man could do that before."
    b_ "It was in the way she looked at me, her eyes carrying a command that I willingly followed."
    b_ "Her magical fingers covered in my body juice, made me climax."
    scene v18-215
    b_ "She stimulated my asshole which shouldn't be a pleasure source as I had been taught."
    b_ "But now I was enjoying it and even cumming from my ass."
    b_ "But that wasn't just it..."
    scene v18-216
    b_ "I was surprised when she showed me a huge black dildo in her hand."
    b_ "She told me that it was stretching time and she started licking my asshole."
    b_ "I couldn't believe that she was serious about it until..."
    scene v18-217 with vpunch
    b_ "From the pain and pleasure I experienced a huge orgasm that was building as soon as she put it in."
    b_ "It almost tore my asshole but I got used to it fast."
    b_ "I entrusted Hicran with my deepest desires, and in return, she guided me through the uncharted territories of our passion."
    scene v18-218 with hpunch
    b_ "She went deeper and deeper until I couldn't stand it and let it all out."
    b_ "I found entertainment in Hicran's dominance."
    scene v18-219
    b_ "Her dominance was not forceful; it was a subtle yet compelling presence."
    b_ "She made both my asshole and mouth busy at the same time. "
    b_ "I found solace in surrendering to her, allowing her to lead us through the maze of our emotions."
    scene v18-220
    b_ "I enjoyed eating her pussy while masturbating."
    b_ "I welcomed her control, finding freedom in the boundaries she set."
    b_ "With Hicran at the helm, our connection became an exploration of trust and vulnerability."
    scene v18-221
    b_ "She came in my mouth and I tasted her juice with satisfaction."
    b_ "Her dominance became a beacon, illuminating the path to our shared intimacy, a journey I willingly embarked upon, finding both refuge and excitement in her commanding presence."
    scene black with dissolve
    b_ "In the twisted web of the mafia, I found myself working alongside a man I had once despised – Faiq."
    scene v18-222 with dissolve
    play music "audio/tension.mp3"
    b_ "The same guy who had once hit on me in the street, only to receive a swift slap in return."
    b_ "Fate had a cruel sense of humor, forcing me to collaborate with this man I couldn't stand."
    scene v18-223
    b_ "Faiq's presence was menacing, his eyes shrouded in mystery, hinting at depths of danger that sent shivers down my spine."
    b_ "As I rummaged through documents in the dimly lit back room, he appeared in the doorway, his silhouette framed by an eerie glow."
    b_ "His approach was slow, deliberate, filling the room with an unsettling tension."
    scene v18-224
    b_ "I felt trapped, cornered by a man I had once dismissed as inconsequential."
    b_ "As Faiq advanced, a glint of cold steel caught my eye – he brandished a knife, a chilling reminder of the danger lurking in the shadows."
    b_ "Despite the fear that gripped my heart, I refused to let him see my trembling hands or the anxiety that churned within me."
    b_ "I stood my ground, my hands planted firmly on my hips, my eyes locking onto his with a defiant glare."
    scene v18-225
    b_ "His voice dripped with menace as he reminded me of the past, how I had once slapped him in an act of defiance. "
    b_ "The memory hung heavy in the air, a reminder of the boldness I had shown before, but this time, the stakes were higher."
    b_ "Faiq's threats cut through the silence, his words carrying the weight of the knife he held in his hand."
    scene v18-226
    b_ "As Faiq brought the knife closer to my face, my heart pounded in my chest like a drum, the beats echoing the terror that gripped me."
    b_ "His eyes, cold and devoid of mercy, stared into mine, sending chills down my spine."
    b_ "The glint of the blade caught the dim light, and I could see the sharp edge glimmering menacingly."
    scene v18-227
    b_ "Then he lowered the knife and raised my skirt with the tip of the knife."
    b_ "He revealed my pussy as I wasn't wearing any underwear. I felt defenseless..."
    b_ "I was paralyzed with fear, my mind a whirlwind of panic."
    b_ "Every rational thought fled, leaving behind only a primal instinct to survive. My breaths came in shallow gasps, and I could feel the beads of sweat forming on my forehead."
    b_ "Time seemed to stretch, the seconds dragging on as I stood there, face-to-face with the very real threat of the knife."
    b_ "In that dreadful moment, a suffocating sense of despair washed over me as I realized there was no escape. Faiq's sinister proposition echoed in my ears, and a chilling realization settled in – I had no choice but to agree."
    scene v18-228 with fade
    stop music
    b_ "He made me suck his dick."
    b_ "He was the guy I hated the most."
    b_ "He was the last person on earth that I would want to be with but in that situation I had no choice."
    scene v18-229
    b_ "He pinned my hands to the wall and his dick was hitting the back of my throat."
    b_ "His body was not big and I was taller than him but he was muscular and strong."
    b_ "His dick was average but it was so hard like a stone."
    scene v18-230
    b_ "Soon after my moaning echoed in the large back room."
    b_ "He stood me up with force and put his dick right in my asshole without warning."
    b_ "I instinctively wrapped my arm around him not to fall."
    scene v18-231
    b_ "I was getting fucked in the ass by the man that I hated the most."
    b_ "I couldn't believe how he dared to enter me in that hole."
    b_ "But I couldn't say anything but moaned."
    b_ "Thank God that he wasn't that big. It could give so much pain."
    scene v18-232
    b_ "He treated me so rough like if he was getting his revenge on me."
    b_ "The weight of fear and resignation pressed down on me, making it difficult to breathe."
    b_ "I swallowed hard, my voice barely audible as I acquiesced to Faiq's demand."
    scene v18-233
    b_ "He made me bend over the metal case on the ground and put his dick again in my ass."
    b_ "He pushed his dick back and forth making my asshole get used to it."
    b_ "My ass started to enjoy it despite I hated to be used by that man."
    scene v18-234
    b_ "I couldn't stop my moans as his pounding got faster and harder."
    b_ "I didn't want to give him the satisfaction but I moaned lauder each time his dick hit my spot."
    b_ "He increased his speed as if he got motivated by my female moans."
    scene v18-235
    b_ "It was a decision made out of desperation, a survival instinct kicking in when faced with an impossible situation."
    b_ "Deep inside, a flicker of anger and defiance remained, but it was buried beneath the overwhelming sense of powerlessness."
    b_ "I got weaker each time he pushed his dick deep inside me."
    scene v18-236
    b_ "I moaned lauder."
    b_ "Feeling a mix of fear and enjoyment, I prepared myself for the inevitable, my heart pounding in my chest."
    b_ "I didn't realize then that this moment would change everything, dragging me deeper into the sinister world I had unwillingly become a part of."
    b_ "I let him use my body as he wanted and he did..."
    scene v18-237 with fade
    b_ "I was left in that room, trembling with Faiq's cum running down my ass."
    b_ "Sweat soaked my forehead, and my heart raced in my chest. The encounter with Faiq had drained me both physically and emotionally."
    b_ "I felt utterly vulnerable, as if all my strength had been sapped away in those terrifying moments."
    scene v18-238
    b_ "The room seemed to close in around me, its walls pressing down on me like a suffocating weight."
    b_ "How did I end up in this situation? I had a normal life and a family. Now I was a cum toilet letting each male cum inside of me here. "
    b_ "I couldn't escape the memories of Faiq's menacing presence, his knife glinting in the dim light, his threats echoing in my ears."
    b_ "I stayed in that position for some minutes."
    b_ "I found myself questioning everything – my choices, my circumstances, and the dark path I had unwittingly treaded upon."
    scene black with dissolve
    b_ "I was getting addicted to drugs."
    b_ "I had taken them so many times already and I couldn't do without it."
    b_ "But this time I had trouble..."
    scene v18-239 with fade
    b_ "I found myself alone with Vladimir, the imposing bodyguard of the boss."
    b_ "He was a towering figure, his muscular frame and powerful presence dominating the room. "
    b_ "Desperation clawed at my insides as I pleaded with him, my voice trembling, asking for the drugs I so desperately craved."
    scene v18-240
    b_ "I begged him, my voice barely audible:"
    b_ "Please, I need it. Just this once. You have to help me."
    b_ "But Vladimir remained unmoved, his expression stern and unyielding."
    b_ "He rejected my pleas, his eyes cold and unfeeling."
    b_ "I continued to beg, my desperation laid bare, but he simply shook his head, his refusal echoing through the room."
    scene v18-241
    b_ "I clasped my hands around Vladimir's leg, my desperation driving me to extremes."
    b_ "I can't bear it anymore. I need something to numb the pain, just for a little while. Please, help me."
    scene v18-242
    b_ "My grip loosened, defeated, and I released him, my heart heavy with disappointment."
    b_ "In that moment, I realized the futility of my attempts, the harsh reality that I was alone in my battle against the darkness that consumed me."
    b_ "His smirk widened into a mischievous grin as he sauntered over to the boss's table. "
    scene black with dissolve
    b_ "With practiced ease, he retrieved a small packet of drugs, his movements swift and precise."
    b_ "He turned back to me, holding the precious substance in his hand."
    scene v18-243
    play music "audio/up.mp3"
    b_ "The familiar scent filled my senses, and as I inhaled deeply, a wave of euphoria washed over me."
    b_ "For a brief moment, the world outside faded away, and I was engulfed in a haze of blissful numbness."
    b_ "The worries, the fears, the harsh reality—all of it melted away, replaced by a fleeting sense of ecstasy."
    b_ "As Vladimir's gaze met mine, his smile held a sinister undertone, and a sinking feeling settled in the pit of my stomach."
    b_ "I knew all too well what he would want in return for his so-called generosity."
    b_ "He wanted to fuck me."
    scene v18-244
    b_ "As my mood was so good I willingly took his veiny big and curvy dick into my mouth."
    b_ "I got into the position as he wanted me and he got himself comfortable on the sofa."
    b_ "I succumbed to the unspoken demands of Vladimir, the boss's menacing bodyguard. "
    scene v18-245
    b_ "It was just Vlad's dick and my mouth. I didn't think about anything else as I was so busy with my little entertainment. "
    b_ "His desires were fulfilled, and I, once again, found myself sacrificing a piece of my dignity to navigate the treacherous waters of this unforgiving world."
    scene v18-246
    b_ "His dick felt too giant in my mouth."
    b_ "As I watched his body from a closer distance I was repeatedly admired by his big frame."
    b_ "I liked how he shut me down with his confident gaze every time our eyes met."
    scene v18-247
    b_ "I lost myself and let out a soft moan once the tip of his cock touched the entrance of my pussy."
    b_ "I felt incredibly weak, both physically and emotionally. It was as though my body had betrayed me, leaving me drained of all strength."
    scene v18-248
    b_ "From the effect of the drug and the pleasure coming from my pussy my eyes crossed leading me to a powerful orgasm."
    b_ "My body, once strong and resilient, now felt like it was made of lead, each movement a Herculean effort. "
    b_ "My face expression and my moans fueled Vladimir stamina."
    scene v18-249
    b_ "He bent me on the sofa and started pounding my tight pussy even harder."
    b_ "My tiny body felt so weak in front of his powerful thursts."
    b_ "He grabbed my belly so hard with both hands and pushed his dong as deep as he can into my womb and I went crazy."
    b_ "I wasn't controlling my moans anymore and probably the dudes in the next rooms heard me."
    scene v18-250
    b_ "Vladimir was a different man."
    b_ "With ice cold eyes and gifted with good genetics he was turning me on so much."
    b_ "Although I acted like I didn't want it, my inner slut loved the sex and begged for more."
    b_ "My slender figure and Vlad's beast body complemented each other and his thick long dick stretched me so good."
    b_ "The pleasure was so good."
    b_ "I wasn't sure if I'd want to do it again with him."
    b_ "I was again left with so many choices..."
    stop music










    "..."
    scene ending_11 with dissolve
    "..."
    "..."

    dev "{color=#ffffff}Thank you for playing! YOU'VE REACHED ONE OF THE ENDINGS!. Play again to discover more. If you enjoyed it, please {a=https://www.patreon.com/lustfulfantasy}support{/a} the development. Wishlist our new game here {a=https://store.steampowered.com/app/4056530/Banu_in_the_West/}Banu in the West{/a} {/color}"
    hide screen faith
    hide screen angeldevil
    $ renpy.end_replay()
    $ persistent.mafia_unlocked = True
    jump endings
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
