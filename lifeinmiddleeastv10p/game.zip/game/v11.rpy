








label v11:


    $ dancewithkamil = False
    $ getridoftoyshome = False
    $ banurefusesinstructorshelp = False
    $ banustopskamilsadvances = False
    $ banudefendskamil = False
    $ banutalkstopolad = False










    scene black with dissolve
    "..."
    centered "{size=+120}Midnight{/size}" with Fade(0.5, 0.5, 5)
    scene v11-1 with Dissolve(3)

    "Kamil has fallen asleep, his lust sated after cumming with the long-awaited bout of sex with his splendid wife. "
    "The woman is now getting dressed again, disappointment evident on her pretty face."
    b_ "That was so unfulfilling!"
    b_ "I feel even worse now! "
    scene v11-2
    b_ "I’m still in heat and I even had to fake an orgasm!"
    b_ "I think walking around a little will make me feel better."
    "She exits the room she’s now sharing with her husband and wanders a little in the large villa."
    scene black with dissolve
    "She hears noises behind one of the many doors in the maze-like building and she stops."
    scene v11-3 with hpunch
    "She opens the door and is faced with a scene which revives the fire she’s feeling inside."
    scene v11-4
    play music "audio/sidesex.mp3"
    "One of the house servants, this time a burly fair-haired Adonis, is standing behind a blonde woman with a spectacular body."
    "They’re both naked and standing inside this room. "
    "The man is holding one of the girl’s legs up and is penetrating her tight-looking wet pussy with his substantial schlong."
    show kitchenguysfuckanimation
    play music2 "voices/moaning.mp3"
    "The rapturous expressions on their faces leave no doubt to the fact they’re enjoying the encounter immensely."
    "They stare into each other’s eyes while moaning in ecstasy at their union."
    b_ "Holy fuck! That looks so hot! "
    b_ "My heart is beating so fast!"
    b_ "I’d better leave before they see me."
    stop music2
    stop music
    scene black with dissolve
    "She returns hastily to the room she shares with Kamil, the images of passionate sex still vivid in her mind."
    scene v11-5 with Dissolve(2)
    "Banu retreats to the bathroom where she washes her face in an attempt to clear the lusty fog from her thoughts."
    b_ "That was so exciting to watch!"
    scene v11-5-1 with Dissolve(3)
    b_ "Oh, it could be me being pounded like that!"
    b_ "I’m sure that stallion wouldn’t leave me hanging."
    scene v11-5
    b_ "Shit!"
    scene black with dissolve
    centered "{size=+120}Morning{/size}" with Fade(0.5, 0.5, 5)
    scene v11-6 with squares
    "It’s morning. "
    "After a night’s sleep, Banu and Kamil are eating breakfast in one of the common rooms and chatting lightly about unimportant topics."
    k "… so they said they were very grateful, because I’d listened to them and found them the house of their dreams."
    b "That must feel good!"
    b "Sometimes I also wish I worked with the public instead of an office job."
    b "But then I realize that some customers can be real assholes!"
    k "Ha ha! Yeah, that happens sometimes, but I love my work because most of them are really nice."
    scene v11-7 with hpunch
    play music "audio/sensual.mp3"
    "But Banu is hardly paying attention at this stage. "
    "She has turned her thoughts to the butler who’s just entered."
    scene v11-8
    "It’s none other than the man Banu has seen fucking the blonde beauty so soundly last night, when she went wandering."
    "Their eyes meet and recognition shows in the servant’s gaze. "
    "Unbeknownst to Banu, the couple has indeed seen her while they were fucking and the butler is wondering about her."
    "Their gazes are fixed on each other."
    scene v11-8-1 with Dissolve(3)
    "Banu is petrified; her husband’s words unable to reach her conscious level, while she’s remembering the hot scene witnessed the night before..."
    "...the image of the muscular man lifting the woman’s leg and fucking her standing up."
    scene v11-8-2 with Dissolve(3)
    "Suddenly, the image changes and she is the woman being plowed from behind in the kitchen, like a common whore, by her husband Kamil. "
    "This image flicks a switch inside. "
    "The frustration from the unfulfilling sex they had from the night before resurfaces with a vengeance, making her hornier than ever."
    stop music
    k "… and they like my advice …"
    scene v11-9
    b "Baby, let’s go back to bed!"
    b "I want you to fuck me again!"
    k_ "Again? She’s become insatiable!"
    k_ "Not that I mind. I want to be inside her again!"
    k "Wow! I like that!"
    k "Let’s go baby!"
    scene black with squares
    "The couple have returned to their shared room and they’re all over each other. "
    jump kamil_banu_sex3

label kamil_banu_sex3:
    scene v11-10 with Dissolve(1)
    play music "audio/sexy.mp3"
    "They’re kissing ferociously, Banu sucking her husband’s tongue as if it were the tastiest treat."
    b "Mhh! Take me, Kamil."
    b "I like turning you on, baby."
    scene v11-11
    k "You’re a sex bomb, my love!"
    k "Let’s go to bed."
    b "No, wait baby. Let me touch you!"
    scene v11-12
    b "I like your cock, baby!"
    b "Take me here, Kamil!"
    b "Do me from behind!"
    k "Mhh, you’re so frisky lately baby!"
    k "I like it!"
    scene v11-13
    "Banu kneels on the chair and presents her hot ass to her husband, who doesn’t refuse the invitation. "
    "He grabs her tapered hips and positions his hard member at her entrance."
    scene v11-14
    k "Is this what you want baby! Mhh?"
    k "With that, he sinks into his wife’s drenched pussy with ease, slowly reaching bottom and feeling her trembling."
    stop music
    show kamilbanumalibuchairanimation
    play music2 "voices/moan2.mp3"
    b "Ohh, yes! So good!"
    b "I almost came just from you putting it in!"
    b "I’m so fucking horny!"
    k "Look at how dirty you become."
    k "Look at the dirty words you say."
    k "You like that, huh?"
    k "You naughty little hussy!"
    b "Yes, right there!"
    b "Don’t stop!"
    b "Pound my pussy just like that!"
    b "Ohh, yeah!"
    b "Mhhh, fuck me really hard!"
    k "Ahh, yes Banu! Take it! Cum on this cock Baby!"
    b "Mhh! Ohh, Ohhhh, Ohhh yeah!"
    b "I’m cumming! Don’t stop! Pound my pussy hard! Go balls deep, you stud!"
    b "Ohhhhhhhh! Fuck! Mhhhh, yes!"
    b "I’m cumming! I’m cummiiiiiiiiing!"
    stop music2
    scene v11-15 with hpunch
    play sound "voices/man3.mp3"
    "With that, she finally succumbs to the pleasure and starts quivering and twitching. "
    "The sexy woman can’t stop moaning loudly at the pleasure she’s finally getting."
    stop sound
    "After feeling frustrated for so long, and the horniness accumulated in her body releases..."
    " ...making her brain melt and giving her the sensation of floating in a white cloud."
    "In the throes of her shuddering climax, she doesn’t even realize that her husband has orgasmed himself and has released a torrent of sperm deep inside her."
    scene black with dissolve
    "..."
    $ renpy.end_replay()
    $ persistent.kamil_banu_sex3_unlocked = True
    jump kamil_banu_sex3_continue

label kamil_banu_sex3_continue:

    centered "{size=+120}Sunset{/size}" with Fade(0.5, 0.5, 5)
    scene v11-16 with irisin
    play music "audio/kometaback.mp3"
    "Banu and Kamil are enjoying the sunset on the beach, feeling romantic and walking hand in hand in the soft evening breeze."
    k "Now, this is nice!"
    k "I’m really having a good time these days, my love."
    b "Yes, this beautiful beach makes me forget about everything else."
    k "And of course, I love being here with you."
    b "You’re sweet, baby!"
    scene v11-17
    "They reach a spot where some people are hanging out around a large bonfire. Banu wants a memory of the moment."
    b "Let’s have our picture taken, Kamil."
    k "Yeah, great idea!"
    k "Hold on a minute."
    scene v11-18
    "He pulls out his phone and calls out to one of the people there."
    k "Excuse me, do you mind taking our picture?"
    guy "Sure dude! Where do you want to pose?"
    k "Banu, let’s stand behind the fire, with the ocean in the background."
    scene v11-19
    b "Alright sweetie. Here, hold me!"
    guy "Ok guys, you look lovely."
    guy "Smile, Aaand that’s it!"
    scene v11-20 with fade
    "The couple keeps walking, just reveling in each other’s presence and the gorgeous natural beauty, without the need to say anything. "
    "They hear music playing in the distance and decide to go and see what is happening."
    "They reach a very tiny cove semi-hidden between two large rock outcrops. "
    "There they find a DJ mixing records and a small crowd of people dancing. "

    "A catchy tune is playing now."
    "A young man with his head shaved and sporting some flashy white sunglasses seems to be a dance instructor, showing some dancing moves to the revelers in turn. "
    scene v11-22
    b "What’s happening here?"
    b "Is he teaching them how to dance?"
    k "Yeah, I think the joker with the white glasses is some sort of instructor."
    scene v11-21
    "Suddenly, the instructor raises the girl he’s teaching high in the air, holding her by her waist and the crowd looks on with surprise."
    ins "Fly baby, fly!"
    attendant "Whoo!"
    scene v11-22
    "Banu is rather taken with how the guy has lifted the young dancer without any apparent effort and Kamil looks at them with a little amusement."
    b "Wow, he’s really good darling, isn’t he?"
    k "Yeah, I guess! He does seem to have some skill!"
    scene v11-23
    "While they’re talking, the instructor approaches them and talks to Banu. In the meantime, the DJ has put on a slower R’n’B track."
    ins "How about you then? Would you like to learn a few sleek moves as well?"
    scene v11-24
    b "Well, I don’t know really. I don’t think it’s for me to be honest."
    ins "Come on, that’s why I’m here. Trust me, I’ll teach you in no time."

    menu:
        "Dance with him.":
            $ renpy.block_rollback()
            b "OK, let’s see what you can do!"
            scene v11-25
            "The man grabs Banu and holds her tight, their bodies starting to sway at the slow rhythm. "
            scene v11-26
            "The instructor turns Banu around and nestles behind her while Kamil looks on seemingly petrified. "
            "It’s clear for everybody to see he’s not pleased."
            scene v11-27
            b "Yeah, you are good!"
            ins "I told you, baby!"
            ins "That’s not the only thing I’m good at."
            b "Oh really?"

            scene v11-28
            "By now, they’re facing each other again and the man is holding Banu even tighter, their faces close, almost touching, and whispering to each other."
            ins "Can you feel how much you turn me on? You sure are a sexy lady!"
            b "Mhh, I can tell you reeeeally like me!"
            "The man’s hands are all over Banu, like a crazed octopus, touching her butt and clasping her until she is molded to his body and can clearly feel his erection. "
            "Banu is not exactly refusing his advances, and raises one of her knees to increase the contact."
            ins "So, what do you say you and me get somewhere more private? I’m dying to teach you some more."
            b "You’re crazy! I’m with my husband."
            ins "Who? That wuss over there? Drop the loser and get it on with the player, baby!"
            b "Ha Ha!"
        "Dance with Kamil.":







            $ renpy.block_rollback()
            $ banu_kamil += 1
            $ dancewithkamil = True
            b "No, sorry. I’m going to dance with my husband."
            scene v11-29
            "The couple step away from the instructor and take to the front of the DJ booth, to enjoy the music, the dreamy summer night and each other’s company."
            k "You’re a good dancer, baby. I didn’t know."
            scene v11-30
            b "Hold me Kamil. I like this song."
            k "You smell so good sweetie. Come here!"
            "So they spend their time enjoying the slow song and swaying to the sensual rhythm, holding each other close and feeling content and in love."


    stop music        
    scene black with Dissolve(3)
    "..."
    scene v11-31 with blinds
    "It’s the middle of the night. "
    "Banu and her husband are in bed. "
    "He’s sound asleep but she hasn’t managed to follow suit just yet."
    "The poor woman has spent hours doing nothing but tossing and turning."
    "And yet her thoughts running hundreds of miles per hour have stopped her from sleeping even a wink."
    b_ "What’s wrong with me? I never had trouble sleeping before."
    b_ "But it’s happening too often since I’m here."
    b_ "I can’t stop thinking about all the dirty things I’ve seen in this house."
    b_ "Dildos, slaves, lesbians, orgies…"
    b_ "I’m not used to all this filth."
    b_ "But it makes me horny to remember…"
    b_ "Mhh, that day in the basement…"
    b_ "That was the hottest!"
    b_ "I wonder if there are sex parties there every day…"
    b_ "Would it be so bad if I went to have a quick look?"
    scene v11-32
    b_ "I know it’s dirty and I shouldn’t."
    b_ "But I’m just too curious and I’ll do nothing but have a quick peek."
    b_ "Kamil will never know, and maybe if I satisfy my curiosity I’ll manage to sleep…"
    b_ "Yes, that’s it! That’s what I gotta do."
    scene v11-33
    play music "audio/tension.mp3"
    "She puts on her short sexy pink robe, which matches her lingerie, and walks through the night silence of the house."
    scene v11-35
    "Headed to the place that has plagued her sleeping and waking moments since she has witnessed there the most disturbing but also the most erotic scene of her life."
    scene v11-36
    "She easily finds the all-too-familiar staircase and climbs down, her heart beating fast in her chest and her breath starting to come in gasps."
    scene v11-38
    "She reaches the wall and takes up position in hiding. "
    "But her emotions are too strong at the scene in front of her to be too concerned, and her stealth techniques are sloppy at best."
    scene v11-37 with vpunch
    stop music
    play music "audio/sensual.mp3"
    "And yet, the people gathered in the underground room do not seem to pay any attention to the scantily-clad woman trying to spy on them... "
    "...and carry on with their activities."
    "Seated around a coffee table with a bottle of wine and two glasses, two women in nightwear are chatting in hushed tones... "
    "...and naughty expressions to one of the well-built house servants. "
    "But this is not the scene that sets Banu’s heart beating even faster."
    scene v11-39
    "Just to the side, like it was nothing, a woman on her knees is noisily slurping on the rigid meat of another house servant."
    scene v11-40
    "Banu looks mesmerized at the lascivious coupling and, without even realizing it, starts to undo her short robe."
    scene v11-47
    b_ "Wow! I’ve never seen such a thick cock!"
    scene v11-41
    b_ "Ohh, she’s sucking it as if it were a lollipop."
    scene v11-43
    "The kneeling woman alternates worshiping the thick cock with her eyes closed and looking in the eyes of the man... "
    "...whose cock she’s sucking as though her life depended on it, both of them ecstatic at the act."
    scene v11-44
    "By now, Banu’s need is impossible to resist and she needs relief. "
    scene v11-42
    "She insinuates her fingers in the front of her panties, where she’s not surprised to find that her pussy has already leaked plenty of juices."
    scene v11-44
    "She shuts off any thought of right or wrong. "
    "She just knows she needs to stimulate her clit and tickle her slit. "
    "Her eyes become languid as a pleasant heat starts to spread form her loins."
    "The schlick-schlick of slimy juices can be heard loudly but nobody cares."
    scene v11-42
    b_ "Ohh, yeah. It feels so good!"
    b_ "Mhh, she’s sucking that cock so hard!"
    b_ "You fucking whore! Suck that dick!"
    scene v11-43
    woman "Are you going to give me that cum? Huh?"
    woman "I want all your milk! It’s mine!"
    woman "Cum on my face you stud!"
    scene v11-44
    b_ "Ohh, yeah. I want to see that cum!"
    b_ "Squirt it all on her slutty face!"
    scene v11-45
    serv "Ohh, mistress, here it comes!"
    serv "Here’s my spunk! All for you!"
    "The man bellows his release and starts a stream of cum that splats noisily on the pretty face of the woman kneeling in front of him."
    scene v11-44
    b_ "Ohh, yes. Cum on her face!"
    b_ "Cover her face in cum!"
    b_ "CUM ON MY FAAACE!"
    scene v11-45
    "Unable to stop her fantasy, Banu is lost in the moment and in her mind there is a vivid image of the strong black man ejaculating on her own face."
    scene v11-46 with Dissolve(3)
    "Banu’s decent and faithful face, Banu the pious wife and mother, defiling her and soiling her like a common street whore."
    scene v11-47 with vpunch
    stop music
    "But right when she’s on the verge of her own climax at the super-filthy image she has conjured up."
    "She comes to her senses, without releasing the tension in her body, and runs like the wind back where she has come from."
    b_ "What the fuck is wrong with me?"
    b_ "Why do I imagine such filthy things?"
    scene v11-48
    b_ "What am I becoming? NO! NO!"
    b_ "I don’t want to sin! I can’t! It’s too much!"

    scene v11-34 with fade
    "Back in the silence of her room, she slips in the bed, careful not to wake her husband and praying he won’t notice the violent thudding of her heart. "
    "She snuggles up to him and her brain takes some time to deal with the adrenalin coursing through her body and letting her calm down."
    b_ "I’m weak! God, I’m just a woman!"
    b_ "Please give me the strength to keep resisting all this temptation."

    scene black with dissolve
    centered "{size=+120}Returning home{/size}" with Fade(0.5, 0.5, 5)
    scene v11-49 with irisin
    "Banu and Kamil have returned home after the short break in Malibu. "
    "The memories are still fresh in their mind and they’re picking each other’s brain to put things into perspective."
    k "… and eventually it was a lot of fun, especially after Rina left …"
    b "Yeah, true. It’s not that I don’t like her."
    b "But I felt more at ease without her there."
    k "Exactly."
    k "Although, in the end, she invited us there and paid for everything."
    k "So, maybe she’s not so bad."
    b "Are you over being suspicious of her then?"
    k "Maybe, but I’m still not sure about the exact reason for wanting us there."
    k "What do you think?"
    scene v11-50
    b "Well, as she said, she probably likes me as an employee and maybe wants to be my friend."
    b "It could also be that she likes helping couples."
    b "You know, like a kind of self-made therapist, in her own way."
    k "Perhaps… Rich people get bored sometimes. Maybe that’s how she gets her thrills."
    k "Still, I don’t really know about us getting her help."
    k "It is true that we seem to have made progress because of this vacation."
    k "I suppose we might try and talk to her if sometimes we’re having a hard time."
    k "Do you trust her that way?"
    b "We’ll see, maybe."
    b "Maybe not enough to ask her directly to intervene."
    b "I still don’t trust her."
    b "Just like you, I wasn’t so sure about her at the beginning."
    b "But she’s been nothing but nice to me."
    b "And she’s helped me a little to come out of my shell."
    k "I’ll say! Ha ha"
    k "Right, but now I need to get ready for the office."
    k "Hope they’ve bought my excuse of a family emergency."
    k "If all goes well, my colleagues won’t hate me too much!"
    k "I’ll go have a shower."
    b "Alright, darling."
    scene v11-51
    "While Kamil is leaving the room, Banu decides to unpack their luggage."
    "She walks towards her suitcase and, in her mind, she’s already thinking about what to cook for the family lunch."
    scene v11-52
    "So nothing can prepare her for what she finds inside."
    scene v11-53 with vpunch
    play music "audio/tension.mp3"
    b_ "Holy shit! That’s huge!"
    b_ "I sure don’t remember packing something like that!"
    b_ "This must be Rina’s doing."
    scene v11-54
    b_ "Mhh. What to do?"

    menu:
        "Get rid of the toy.":
            $ renpy.block_rollback()
            $ getridoftoyshome = True
            stop music
            b_ "I think I’d better get rid of it. I don’t want anybody to find it."
            b_ "And even if I kept it, I doubt something this big can fit my pussy."
        "Keep the toy.":





            $ renpy.block_rollback()
            $ banubad += 1
            b_ "Oh my! I think this is a keeper."
            b_ "I’ve never seen anything this massive in my whole life."
            b_ "Mhh, what would it feel like deep inside my belly?"
            stop music



    scene black with dissolve
    "..."
    scene v11-55 with fade
    "Banu is busy doing some housework, something normal for her. "
    "She doesn’t mind it too much, because she finds pride in having a clean and tidy house for herself and her family, but also for any guest."
    b_ "I’m so proud of these beautiful plants!"
    scene v11-56
    b_ "I’ve grown them from a simple seed and look at them now."
    b_ "I love them and it makes me feel good to see how healthy they are."
    b_ "Mhh, but maybe it would be better to move this one there in the corner."
    play sound "voices/doorbell.mp3"
    "..."

    scene v11-57 with fade
    b_ "Mhh, wonder who it could be."
    b_ "I’m not expecting anyone."
    play sound "voices/dooropen.wav"
    if streetguys == False:
        scene v11-58
        b "Oh hi! How can I … Wait, you’re our neighbor. Mhh… Ahmed, right?"
        scene v11-59
        ah "Yes, it’s me. I thought I’d pop in to say hello."
        scene v11-60
        ah "Is Kamil around?"
        scene v11-61
        k "Oh hey Ahmed! Don’t just stand there. Come in, come in!"
        scene v11-62
        ah "How you doing old buddy?"
        k "All good pal. We haven’t spoken for a while."
        ah "You can say that again!"

        b "Wait, I didn’t know you guys knew each other so well."
        k "Yeah, we went to the same high school."
        ah "We were in the same grade!"
        k "Right!"
        scene v11-63
        b "Why didn’t I know any of this?"
        k "It just never came up I guess."
        k "Come have a seat Ahmed!"


    if streetguys == True:

        scene v11-58
        b "Hi Ahmed. How are you?"
        scene v11-59
        ah "Hello Banu. I thought I’d pop in to say hello."
        scene v11-60
        ah "Is Kamil around?"
        scene v11-61
        k "Oh hey Ahmed! Don’t just stand there. Come in, come in!"
        scene v11-62
        ah "How you doing old buddy?"
        k "All good pal. We haven’t spoken for a while."
        ah "You can say that again!"
        scene v11-63
        k "Come have a seat Ahmed!"



    scene v11-64 with fade
    ah "And do you remember the huge crush you had on the English teacher?"
    ah "You were so shy! You’d turn beet red every time she talked to you."
    ah "Everybody kept teasing you about it."
    b "Ha ha ha!"
    scene v11-65
    ah "Even the teacher!"
    b "Ha Ha Ha Ha!"
    scene v11-66
    b "I didn’t know he was so shy back then."
    scene v11-65
    ah "Oh yeah, and skinny, too!"
    scene v11-64
    ah "There was a bunch of guys used to call him “stickman”!"
    b "Ha ha!"
    k "That’s not so funny!"
    ah "Come on, Kamil, it was so long ago…"
    k "Mhh, yeah right"
    scene v11-66
    ah "Alright, anyhow I just literally came for a quick visit."
    ah "I need to get going now."
    b "Hey, wait! Stay for a cup of tea at least."

    scene v11-65
    ah "Thanks, but no can do. I gotta be at the station in half an hour."
    ah "Maybe next time, ok?"
    b "Ok then."

    scene black with dissolve
    centered "{size=+120}Office{/size}" with Dissolve(2)
    scene v11-67 with blinds
    play music3 "sfx/office.mp3"
    "It’s another ordinary day at the office. "
    scene v11-68
    "Banu is moving some files from her desk to a new bookshelf she has just got in her room."
    b_ "It’s really awesome that they finally gave me this new shelf."
    b_ "And to think I’ve been asking for it for so long!"
    b_ "Maybe they’ve noticed what a good job I do around here."
    b_ "Or maybe they think now Rina would chew their ass if they didn’t."
    b_ "Ha ha!"
    scene v11-69

    "..."
    if banuturansexfirsttime == False:
        b "Come in!"

        scene v11-70
        b "Ah, it’s you, Turan."
        t "Good morning, Banu"
        t "How are you this fine morning?"
        b "I’m good. Thanks for asking."
        t "Are you happy you finally got that shelf?"
        b "Sure, now my desk doesn’t look like a war zone anymore!"
        t "You’re looking mighty fine this morning!"
        scene v11-71
        b "Humph!"
        b "What can I do for you Turan?"
        t "Now now! Is that how you talk to your boss?"
        b_ "Egads, is he ever annoying!"
        b "Listen, can’t you see I’m busy?"

        scene v11-72
        t "Ha ha, kitty got claws!"
        t "Alright, look, I want to ask you about this entry in yesterday’s report on the internet providers."

        b "Let me see. What’s wrong with it?"
        t "The figures are missing in the second entry!"

        b "Oh, sorry, my bad! I forgot to copy them."
        b "I’ll send you another one right away."
        t "Now now, this is not like you Banu."
        t "Have you been worked up thinking about your sexy boss?"
        scene v11-73
        b "Hey, I won’t take you talking to me that way!"
        b "I’m your co-worker."
        b "I’m a married woman and finally…"
        b "I’m not interested!"
        t "Alright, whatever you say…"


    if banuturansexfirsttime == True:
        $ banugetsmadatturan = False
        b "Come in!"
        scene v11-70
        b "Ah, it’s you, Turan."
        t "Good morning, Banu."
        t "How are you this fine morning?"
        b "I’m good. Thanks for asking."
        t "Are you happy you finally got that shelf?"
        b "Sure, now my desk doesn’t look like a war zone anymore!"
        scene v11-71
        t "You’re looking mighty fine this morning!"
        t "Even better than you did back at my flat!"
        scene v11-72
        b_ "What a piece of shit!"
        b "Humph!"
        b "What can I do for you Turan?"
        t "Now now! Is that how you talk to your boss?"
        b_ "Egads, is he ever annoying!"
        scene v11-73
        b "Listen, can’t you see I’m busy?"
        t "Ha ha, kitty got claws!"
        t "You also were aggressive that day before I fucked you."
        scene v11-74
        t "Then you got meek as a lamb."
        t "Alright, look, I want to ask you about this entry in yesterday’s report on the internet providers."
        b "What’s wrong with it?"
        t "The figures are missing in the second entry!"
        b "Oh, sorry, my bad! I forgot to copy them."
        b "I’ll send you another one right away."
        t "Now now, this is not like you Banu."
        t "Have you been worked up thinking about how I stretched your cunt?"

        b "Hey, I won’t take you talking to me that way!"
        b "I’m your co-worker."
        b "I’m a married woman and finally…"
        b "I’m not interested!"
        scene v11-75
        play music "audio/tension.mp3"
        t "Mhh, I remember a different story."
        t "You were begging me to fuck you."
        t "It’s kinda hard to believe you now."
        "Despite being really annoyed at Turan, Banu doesn’t notice that bending over the way she is."
        "Setting those papers on a lower shelf, she’s giving him a front-row seat at her ass."
        "Or maybe, does she actually know what she’s doing?"
        t_ "Damn! Look at that ass!"
        t_ "Is she doing it on purpose? The whore!"
        b "Turan, I just want to be left alone and do my job."
        b "Is that too much to ask?"
        t_ "Shit! I can’t resist. I gotta do it!"
        stop music
        scene v11-76 with vpunch
        play sound "voices/slap.mp3"
        "..."
        menu:
            "Banu gets mad.":
                $ renpy.block_rollback()
                $ banugetsmadatturan == True
                scene v11-77 with hpunch
                ""
                scene v11-78
                b "Hey! What the fuck do you think you’re doing?"
                b "I’ve had enough of your bothering the hell out of me!"
                b "Knock it off or I’ll report you!"
                b "Now get the fuck out of here!"
            "Banu is confused.":


                $ renpy.block_rollback()
                scene v11-80
                b "Hey, wha..?"
                b "Turan, you can’t do this!"
                b "I-I told you I’m married."
                b "You can’t just …"
                scene v11-79
                "..."
    stop music3            

    scene black with dissolve
    centered "{size=+120}Gym{/size}" with Dissolve(2)
    scene v11-109
    play music3 "sfx/gym.mp3"
    "Banu and Hicran have decided to join the gym after all and work out together. "
    "They’re doing their best and are sweating profusely. Looking good takes effort and they know it."
    b_ "I am really out of shape."
    b_ "True, I’m slim but I need to work hard to be supple and firm."
    scene v11-110
    b_ "Hicran seems to need the instructor’s help an awful lot."
    b_ "Knowing her, she’s probably flirting more than working out."
    scene v11-111
    b_ "And what’s with the uncovered head?"
    scene v11-112
    b_ "You either wear a hijab all the time or you don’t!"
    b_ "Pah! The more I know her, the less I understand her!"
    scene v11-113
    b_ "Oh! He’s coming this way now."
    b_ "Hope he doesn’t expect me to flirt too!"
    scene v11-114
    ins "Banu, you’re not doing those sit-ups too well."
    ins "You need to make sure your legs are not moving!"
    scene v11-115
    b "Oh, really?"
    scene v11-116
    ins "Yeah, you have some power in your upper abs."
    ins "But you’re not working them as you should."
    ins "Want me to help you hold your legs down?"
    menu:
        "Banu refuses his help.":
            $ renpy.block_rollback()
            $ banurefusesinstructorshelp = True
            b "No, thanks coach."
            b "I’ll be fine."
            b "I won’t let a man who’s not my husband touch me."
            b "I’ll make sure I don’t move my legs."
            scene v11-117
            ins "Alright. Suit yourself."
            ins "But make sure you don’t strain yourself too hard with the wrong movements."
        "Banu lets him help her.":


            $ renpy.block_rollback()
            $ banubad += 1
            b_ "Oh my!"
            b_ "Am I going to let another man touch my legs?"
            b_ "Sure, I need to exercise properly, or I’ll be working so hard for nothing."
            b "Alright coach. Please help me out."
            scene v11-118
            ins "There you go!"
            show banucrunchanimation
            ins "Aaaand up!"
            ins "Feel how your upper abs are pulling?"
            ins "That’s how you do it!"
            ins "Come on, 5 more!"
            scene v11-119 with vpunch
            ins "How are you feeling?"
            b "Holy crap!"
            b "That was much harder than how I was doing it!"
            b "I don’t know if I can take any more."
            scene v11-120
            ins "Nonsense!"
            ins "Rest for a few seconds and on with another set!"
    stop music3        

    scene black with dissolve
    "..."
    centered "{size=+120}Kamil's workplace{/size}" with Dissolve(2)
    scene v11-121 with dissolve
    "Just another day at the office for Kamil, literally, because he’s overworked and exhausted. "
    "He’s been trying to make up for the few days off he’s taken to go to Malibu by making an extra effort. "
    "His co-workers and his employer have seemed to appreciate it, but he thinks he just can’t take it anymore."
    scene v11-122
    k_ "Argh! That’s really too much now!"
    k_ "I’m showing houses all over town."
    k_ "But it seems I only get assholes ganging up to waste my time."
    k_ "I don’t like the area."
    k_ "The décor is too shabby."
    k_ "Oh, I can’t afford that!"
    k_ "I simply can’t anymore!"
    play sound "voices/dooropen.wav"
    scene v11-123
    b "Knock-knock!"
    b "It’s the lunch fairy!"
    k "Ohh, look what the cat dragged in!"
    k "Hello, sweetie!"
    scene v11-124
    b "Hey, honey!"
    b "Happy to see me?"
    b "Working hard?"
    k "You don’t know the half of it, love!"
    scene v11-125
    k "You’re just what I needed."
    k "What have you got for me?"
    b "Pizza!!!"
    k "I don’t know if I ever told you I love you."
    scene v11-126
    b "Just a million times."
    scene v11-127
    b "But still not enough."
    b "Aww! Give us a kiss, you big lug."
    menu:
        "Banu stops his advances.":
            $ renpy.block_rollback()
            $ banustopskamilsadvances = True
            scene v11-128
            b "Now now, settle down boy!"
            b "Someone might come in anytime."
            b "We don’t wanna put up a show!"
        "Banu lets him go on.":








            $ renpy.block_rollback()
            $ banu_kamil += 1
            play music "audio/sensualsex.mp3"
            scene v11-129
            play music3 "voices/makeout.mp3"
            "Things start getting hotter right away, with Banu deepening the kiss with her husband, then tilting her head to have her neck kissed."
            scene v11-130
            k "Mhh, you smell so good, baby!"
            b "Ohh, you devil!"
            stop music3
            scene v11-131
            "He grabs his wife by the waist and lifts her effortlessly on top of his desk. "
            "He clasps her tight to him and keeps on kissing her with passion. Banu responds in kind."
            scene v11-132
            k "I can’t get over how sexy you are!"
            k "I love your hips! You’re so feminine!"
            scene v11-133
            b "Ohh, you’re driving me crazy!"
            b "Won’t someone come in?"
            scene v11-134 with hpunch
            stop music
            "Right at that moment, as if on cue, the door opens and a distinguished-looking man comes in."
            man "Excuse me, Kamil?"
            scene v11-135
            man "Ohh, sorry, I thought…"
            man "The receptionist told me…"
            k "Oh, wow! I’m really sorry."
            k "I was just saying goodbye to my wife!"
            k "Please, do come in!"
            b_ "Shit, I knew it!"
            b_ "Gosh, I’m so embarrassed!"
            b_ "But what’s this thrill I’m also feeling."
            b_ "Mhh! Naughty naughty Banu."

    scene black with dissolve
    "..."
    scene v11-136 with squares
    "It’s Saturday. Polad and his wife Nesrin are visiting Banu’s house. Kamil is not there because he has had to go to work."
    "He has been working really hard lately and is often putting in overtime."
    "Unable to refuse, as he still feels a bit guilty at the disappearing act he pulled when he went to California with his wife."
    scene v11-137
    p "Yeah, Nesrin really loved it."
    p "Me? Not so much. Not really my cup of tea."
    p "But it was nice to see my wife enjoying her favorite actress."
    p "And she rewarded me well afterwards …"
    scene v11-139
    n "Stop it, you brute!"
    scene v11-140
    n "Does Kamil take you to the cinema often, Banu?"
    b "Mhh, not really."
    b "He works a lot lately and is often too tired to do anything."
    scene v11-137
    p "Tsk tsk! Doesn’t sound like a man treating his woman right!"
    n "You can say that again!"
    n "I for one, need to be wined and dined by my man."
    p "Hey baby. Don’t be too hard on him."
    p "Not everybody has a Polad by her side."
    p "He he!"
    scene v11-138
    n "He’s right Banu."
    n "Beautiful women like us need to be pampered by our man!"

    menu:
        "Banu defends Kamil.":
            $ renpy.block_rollback()
            $ banu_kamil += 1
            $ banudefendskamil = True
            scene v11-141
            b "Stop it, you two! Kamil is a good man."
            b "He’s responsible and he cares about his family."
            b "He makes me feel happy and cared for."
            b "We don’t go out too often, true."
            b "But he took me to California just recently."
            n "Yeah, right!"
            b "Ok, that’s enough."
            b "Let’s change topic. "
        "Banu agrees with them.":









            $ renpy.block_rollback()
            scene v11-142
            b "You have a point there."
            b "Sometimes I feel he only cares about his job."
            b "I’d like to be the center of his world, get flowers, candlelight dinners and…"
            b "...feel more like a woman. "
            b "With a strong and confident man."
            b "But, enough of that now. Let’s talk about something else."



    scene v11-143
    b "I know! Let’s make some food."
    scene v11-144
    "Nesrin heads straight to the kitchen to get started on the cooking, while her husband stops by the bookcase to check out his friends’ book collection."
    menu:
        "Banu talks to Polad":
            $ renpy.block_rollback()
            play music "audio/sensual.mp3"
            $ banubad += 1
            $ banutalkstopolad = True
            $ banu_polad += 1
            if dinnerreddress == True:

                scene v11-145
                b "Hey, find anything you like?"
                p "Mhh, definitely! And the books are not bad too!"
                scene v11-146
                b "He he. You cheeky devil!"
                b "Always the charmer!"
                scene v11-147
                b "Wasn’t kissing me enough?"
                p "Huh huh, au contraire!"
                p "It just made me want more!"
                scene v11-149
                b "Stop it now! Your lovely wife might not like it."
                scene v11-148
                p "What she doesn’t know… and all that!"
                b "Tsk tsk! Men!"
            else:

                scene v11-145
                b "Hey, find anything you like?"
                p "Mhh, definitely! And the books are not bad too!"
                scene v11-147
                b "He he. You cheeky devil!"
                b "Always the charmer!"
                b "Don’t let Nesrin catch you, though."
                scene v11-148
                p "Mhh, I know. But the temptation is too strong."
                p "And those tight clothes you always wear …"
                scene v11-149
                b "It’s just normal everyday clothes, nothing fancy."
                p "Yeah, true. But you make them look special."
                p "Alright then. Now I know you’re not serious."


            stop music   
        "Banu joins Nesrin":




            $ renpy.block_rollback()
            $ banu_nesrin += 1
            scene v11-150
            b "Hey good-lookin!"
            b "Watcha got cooking?"
            scene v11-152
            n "Ha ha ha! Me good looking?"
            n "I got fat lately!"
            b "What are you on about?"
            b "You just got even more of those sexy curves you’ve always had!"
            scene v11-153
            b "I’m a broomstick!"
            n "You? Ha!"
            n "You’re a sexy catwalk model."
            scene v11-151
            n "Don’t know how you can still pull it off at our age!"
            n "I’m sure Kamil must be all over you."
            b "I wish!"
            scene v11-153

            b "Didn’t I tell you he’s too busy with work?"
            scene v11-152
            b "Now, Polad on the other hand …"
            b "I’m sure he can’t get enough of those boobs and ass."
            n "Yeah, he seems to appreciate the little extra padding."
            scene v11-153
            b "Ok, enough of that."
            b "Get started with the rice, please darling."
            b "And I’ll cut the beef for the kebab."
            b "Mhh, I’m hungry now."
            scene v11-152
            n "He he, me too, as always!"


    scene black with dissolve
    centered "{size=+120}Later{/size}" with Dissolve(2)
    scene v11-81 with fade
    r "Can you come here for a minute?"
    l "Yeah, what?"
    r "I need a favor …"
    scene v11-82
    l "You always treat me like shit and now you want a favor?"
    r_ "What a bitch!"
    r "Yes, only you can help me!"
    r "I need my laptop and you’re good with computers."
    r "So I thought …"
    l "What’s wrong with it?"
    r "It’s really slow all of a sudden. I need you to fix it."
    l "Mhh, I don’t know. Maybe!"
    l "What’s the magic word?"
    r_ "Soon, little whore, I’ll have you begging me."
    r "Please!"
    l "Alright, alright, lemme see."
    scene v11-83
    "Ruslan leads Leyla to his desk and can already feel his plan coming to fruition. "
    "Leyla is a bit wary of his sudden change of attitude, but he’s her stepbrother after all. She just can’t deny him her help."
    scene v11-84
    "Ruslan pulls his chair from the desk and invites her to sit."
    scene v11-85
    r "There, sis. Make it work again. You’re really smart."
    "Leyla starts working to find the cause of the problems, opening and closing various programs."
    r_ "Fuck! She’s damn hot!"
    r_ "I need to get my hands on this body."
    r_ "And what’s she wearing? These are really slutty clothes!"
    r_ "She wants to get fucked again!"

    r "Leyla, have you been working out?"
    r "You got yourself a really hot bod!"
    r "And you’re so rocking that outfit!"
    l_ "Is he for real?"
    l "Giggle! Knock it off!"
    r_ "I knew it! She’s gagging for it."
    scene v11-86
    r "What! I’m serious!"
    r "You’re in a killer shape and you’re so pretty."
    l "Alright that’s too much."
    l "Now I know you’re full of shit."
    scene v11-87
    r "I’m actually serious …"
    r "It’s really hard for me to say this but …"
    r "If you weren’t my sister, I’d like you to be my girlfriend."
    r_ "Ruslan, they should give you a freaking Oscar for this performance!"
    l_ "Shit! He’s serious! Oh fuck, now what?"
    l "Ruslan, I …"
    l "Listen, there’s nothing serious with your laptop!"
    l "The antivirus is scanning the system and it’s taking up a lot of memory."
    r_ "And now to reel her in …"
    r "I feel so frustrated having you so close."
    r "I wish I could give you just a kiss … "
    l "Hey stop it! I told you to knock it off!"
    l "Don’t make fun of me!"
    r "I’m dead serious! I really want us to kiss! Just once."
    l_ "Mhh, why doesn’t the idea disgust me?"
    l_ "Maybe we can kiss once and the world isn’t going to end."
    l "Look! If this is another one of your schemes …"
    r_ "I’ll make this little slut mine!"
    r "No, it’d make me really happy."
    r "Please!"
    l "Alright, just a kiss. No funny business."
    r "I promise."
    scene v11-88
    play music "audio/sidesex.mp3"
    "Ruslan gets closer to Leyla, who’s now standing up and hugs her from behind, copping a feel of his sister’s sexy tummy and perky tits."
    l "Mhh, hey!"
    l "Do you really think we should …?"
    r "Relax, sis! I said just a kiss."
    "Leyla turns around and Ruslan is quick to hold her tight, whispering words of admiration and sweet things in her ear."
    "...while thinking about all the lewd stuff he’s planning to do."
    scene v11-89 with hpunch
    "He backs away until he reaches his bed, where he falls with Leyla on top of him."
    l_ "He’s such an asshole! Mhh, but he’s so hot!"
    show leylagrindingruslananimation
    play music3 "voices/makeout.mp3"
    "Leyla has fallen on top of his brother straddling his crotch."
    "And the way he holds her head while kissing her with passion makes her swoon and forget about who she’s making out with."
    "In the throes of passion and with the needy throbbing of her clit, she forgets everything and starts grinding on top of him..."
    "...feeling his hardness stimulate her just right."
    r_ "She’s such a whore! Just like her precious mummy!"
    l "Mhh! Ah! Oh, you’re so hard!"
    r "That’s it! It’s all for you, sis!"
    r "I told you how much I like you."
    scene v11-90
    "All their twisting and grinding has now brought them lying side-by-side. "
    "Ruslan makes sure never to stop kissing Leyla, who’s now moaning uncontrollably..."
    "...and insinuates his hand under her top, where he can now fondle her braless boobs."
    "Her nipples are hard as rocks and the scent of her sex permeating his nostrils is almost making him lose control, but still he pushes on slow and steady."
    r "Egad Leyla! Your body is a work of art."
    l "Mhh! Ohh! You mean that?"
    r "Yes, you’re a goddess!"
    stop music3
    scene v11-91
    "The young man now ups the ante, knowing he can get away with more than a quick feel. "
    "He runs his hand down from his sister’s breasts and slowly descends over her firm belly and pushes his hand in her shorts, where he finds her dripping wet pussy."
    scene v11-92
    l_ "Oh no! I’m so wet! What’s he gonna think of me?"
    "But she’s far too gone by now; her rationality has completely left her brain and she lets him do as he wishes..."
    "...stimulated by his manly forcefulness, eager to let him take what he wants and submit to her hunky step-brother."
    r_ "She’s mine now! "
    r "Do you like that Leyla?"
    r "I wanna make you feel good."
    "But she’s really unable to respond coherently and Ruslan is ready to take the next step. "
    scene v11-93 with hpunch
    "He swiftly pulls out his raging cock and holds it proudly for Leyla to see."
    r "How about it sis?"
    r "Make me feel good too!"
    r "Don’t you wanna give it a little kiss?"
    l "Oh shit! That’s a big dick!"
    l_ "Oh fuck! Did I say it out loud?"
    l_ "Holy crap! What the fuck am I doing?"
    "Ruslan‘s latest move and her faux-pas has jolted Leyla out of her trance-like state of horniness... "
    stop music
    scene v11-94
    "...and she bolts out of her step-brother’s room without saying anything else."
    r "Hey, wait! Don’t worry, I’m not gonna hurt you!"
    r_ "Fuck! She’s blue-balling me just like that!?"
    r_ "Mhh, maybe I went too fast. I should have made her cum first."
    r_ "Next time, you pretty little slut."
    r_ "Just you wait …"
    scene v11-95 with fade
    "Back in her room, Leyla is still panting from the exertion of running at world-record speed and the excitement she is still feeling coursing throughout her whole body."
    l "Pant, pant."
    l_ "What the fuck was that? Have I gone crazy?"
    l_ "Wow! I’ve never felt anything that exciting."
    l_ "But we can’t do that!"
    l_ "He’s really really hot, but he’s my brother."
    l_ "Well, stepbrother technically, but still!"
    play music "audio/tension.mp3"
    l "Wait, where is my phone?"
    l "Shit, I left it in Ruslan's room."
    stop music


    scene black with dissolve
    "..."
    centered "{size=+120}City center{/size}" with Dissolve(2)
    scene v11-154 with move
    play music "audio/tension.mp3"
    play sound "voices/doorbell.mp3"
    "By now, Hicran has become quite adept at doing jobs for the shady characters who run her town’s underbelly..."
    "...a world where the moral fabric of civilized society is replaced by a dog-eat-dog world of tyranny, greed and ruthlessness."
    attendant "Coming!"
    scene v11-155 with fade
    play sound "voices/dooropen.wav"
    "Today, the lovely lady is delivering some special goods to some young college students at their apartment."
    attendant "Oh! It’s you! Hi there!"
    attendant "I was expecting you later."
    attendant "Now, that’s what I call service!"
    attendant "He he!"
    hic "Hello, beautiful."
    hic "We’re the best and you know it."
    hic "Well, we’re the only ones too, after all."
    attendant "Have you got some candy for me?"
    scene v11-156
    hic "Here’s your candy."
    scene v11-157 with dissolve
    little "Oh, wow. Awesome!"
    little "I was starting to get antsy."
    scene v11-158
    stop music
    hic "Never worry, sweetie."
    hic "Mama always got you covered."
    hic "Gotta shoot now!"
    hic "Pleasure doing business with you!"
    attendant "Bye now!"
    little "See ya!"
    scene v11-159 with Fade(0.5, 0.5, 5)
    "The real hierarchy is revealed, as we see the one we thought was the real head honcho, the man who liked to be called 'boss'..."
    scene v11-160 with dissolve
    "...being scolded quite harshly by the true criminal big shot of the whole syndicate, none other than his father."
    dad "…and you went and smoked him!"
    dad "Just like that?"
    dad "And for what?"
    dad "Fucking one of our bitches?"
    scene v11-161
    boss "Sorry father…"
    boss "I thought … the rules …"
    scene v11-162
    dad "What the fuck are you on about?"
    dad "What fucking rules tell you to whack the first s.o.b. you get your hands on, for dipping his wick into a pussy?"
    dad "Huh? You fucking retard!"
    scene v11-161
    boss "You’re right. It won’t happen again."
    scene v11-162
    dad "Damn straight it won’t. I’ll have Vladimir here keep tabs on you from now on."
    dad "No more fuckups, you hear?"
    dad "Or I’ll have you disappear for good."
    dad "Son or no son."
    scene v11-161
    boss "Yes, father."
    $ renpy.end_replay()
    jump hicran_sucks_dick



label hicran_sucks_dick:
    dad "Good, now get the fuck out of here."
    dad "The big boys need to have a serious talk."
    scene v11-163 with fade
    "Muxtar makes his way meekly out of the room, his gait showing how subdued and humiliated he feels. "
    "Hicran, coming in at the same time, is surprised to say the least at what she’s seeing."
    scene v11-164
    dad "How’s my faithful worker doing today?"
    hic "Good, daddy!"
    scene v11-166
    hic "I did all the jobs I had to do today."
    scene v11-165
    dad "Now, that’s a good girl."
    scene v11-167
    dad "Vladimir, wait outside, will you?"
    dad "I need to talk to this sweet piece of ass alone for a minute."
    v "Yes, sir!"

    scene v11-168 with fade
    dad "Now you know your job isn’t quite over yet, huh?"
    hic "Mhh, let me think!"
    scene v11-169
    hic "What might have I forgot to do?"
    hic "The he!"
    scene v11-170
    hic "Oh, that’s right!"
    hic "I need to give daddy his stress-reliever!"
    scene v11-171
    dad "That’s right, you sexy bitch!"
    dad "Get it out now."
    scene v11-172
    hic "Ohh!"
    hic "Here’s my favorite cock!"
    scene v11-173
    hic "Ahh! I love how you smell, daddy."
    dad "Yeah, get sucking now."
    show hicransuckbossanimation
    play music3 "voices/bj.mp3"
    dad "Mhh, you like that fat cock, huh?"
    dad "Ahh! Oh, yeah, work it, you slut."
    dad "Move that tongue."
    dad "Gobble it all up!"
    dad "Take it deeper!"
    hic "Gag! Cough!"
    dad "Ahh! Ahhh"
    dad "Oh yeah, you cock-sucking whore!"
    dad "Suck that dick!"
    stop music3
    scene v11-174
    dad "Ohhh, Yeah!"
    dad "Gag on that sperm!"

    dad "Ohhhhhh! Ohhhhh!"
    scene v11-175 with hpunch
    hic "Ahhrgh! Gak, Gak, Gak!"
    hic "Cough! Splut!"
    scene v11-176
    dad "Mhh, yeah, that’s the stuff!"
    dad "Enjoy your protein shake, slut?"
    hic "Yum, daddy."
    hic "I just love the taste of your cum."




    $ renpy.end_replay()
    $ persistent.hicran_sucks_dick_unlocked = True
    jump ruslan_fucks_leyla


label ruslan_fucks_leyla:






    scene black with dissolve
    "..."
    scene v11-96 with Dissolve(3)

    l "Oh yes, You’re stretching me so good!"
    l "Ahhh! You’re so thick!"
    show leylafuckruslananimation
    play music3 "voices/moan4.mp3"
    r "Take it, you little slut!"
    r "You like my big hard dick, huh?"
    l "Ohhhh! Yes, make me your slut!"
    r "Mhhh, your little pussy is so tight!"
    r "I bet you’ve only had a pencil dick so far."
    l "Ah! Ah! I love your big cock!"
    l "Take me from behind, you stud!"
    stop music3
    scene v11-97 with fade
    r "Fuck! Your ass looks so sexy from this position!"
    r "You’re such a sweet little bitch!"
    scene backgroundruslanleyladoggy
    show leylafuckruslananimation2
    play music3 "voices/moan4.mp3"
    l "Ahh! Ohh! You’re going so deep like this!"
    l "I can feel you all the way to my cervix!"
    r "Mhh! Ahh! Yeah!"
    r "You like it when I pound your baby room!"
    r "I’m gonna batter it open!"
    stop music3
    scene v11-101 with fade
    "In the meantime, Banu is walking from room to room looking for her daughter, ending up in Leyla’s bedroom and opening the door, sure to finally find her there."
    b "Leyla sweetie, do you know where the … "
    b_ "Huh? Where can she be?"
    b_ "I’ve looked everywhere."
    scene v11-98 with fade
    r "I wanna do you against the wall!"
    r "Standing up like a whore!"
    l "Ohh, you’re so hard!"
    l "Rub it between my cheeks like a huge hotdog!"
    r "You’re sexy, sis! I wanna enjoy your body all I want."
    l "Do it, you fucking pervert!"
    l "But put it back in now!"
    l "I wanna feel you stretching me again!"
    r "Yeah! Ahh! Here you go!"
    show leylafuckruslananimationstanding
    play music3 "voices/moan4.mp3"
    r "You are already addicted to my schlong, aren’t you?!"
    l "Ohh! Mhh! Pound my little pussy, Ruslan!"
    l "Make it yours!"
    l "Ohh! Just like that!"
    l "Ohh, you’re gonna make me cum again!"
    l "Ohh! Ohhh! Ahh!"
    l "I’m cumming!"
    l "Ooooooohhhh!"
    r "You fucking little whore!"
    r "You’re squeezing so fucking hard!"
    r "You’re gonna make me cum too, bitch!"
    r "Ahhhhhhh! Fuck! Ohhhh, yeahhhhhh!"
    stop music3
    scene v11-99 with vpunch
    "Overwhelmed by the powerful sensations, neither of them seems to care too much that Ruslan has filled his sister’s tight little cunt... "
    "...to overflowing with his scalding sperm, until Leyla feels it dripping between her legs."
    l "Holy crap! What’s this?"
    l "Did you fucking cum inside me!?"
    scene v11-100
    l "Are you fucking nuts!?"
    r "Fuck, I know!"
    r "But you were squeezing my whole cock inside you so hard when you came again."
    r "You didn’t want to let go!"
    r "I couldn’t have pulled out even if I wanted to!"
    r "Fuck!"
    l "Fuck! What are we gonna do? It wasn’t even a safe day."
    l "You’re a fucking idiot!"
    scene v11-102 with hpunch
    play sound "voices/dooropen.wav"
    play music "audio/tension.mp3"
    "When both of them think things couldn’t get any worse, even after having the time of their lives."
    "They realize the universe has a weird sense of humor, and they hear the door opening."
    $ renpy.end_replay()
    $ persistent.ruslan_fucks_leyla_unlocked = True
    jump ruslan_fucks_leyla_continue


label ruslan_fucks_leyla_continue:
    b "Leyla, are you in he…"
    scene v11-103 with hpunch
    b "..."
    b "What in God’s name is going on here?!"
    b "Are you two out of your fucking mind?"
    b "You fucking perverts!"
    scene v11-104
    l "AHHHHH! No No No No No!"
    b "What the fuck do you think you’re doing?"
    b "Here! In your parents’ house!"
    stop music
    scene v11-105
    b "You’re brother and sister!"
    "Despite the anger falling over her vision like a blanket, her vision red, Banu can’t help notice that Ruslan seems almost unfazed... "
    "...by all the commotion she’s creating and Leyla’s hasty screaming retreat."
    "He makes no effort to cover up but actually seems to be trying to show off his body and his cock."
    scene v11-106
    b "You should be ashamed! She’s your little sister!!"
    b "You fucking moron!"
    b "You’re supposed to be protecting her!"
    scene v11-108
    r "She likes me! She can’t resist me!"
    r "What are you gonna do about that?"
    b "You’re not going to get away with this!"
    b "I’m going to make sure you’ll suffer for what you’ve done!"
    scene v11-107
    b_ "Fuck! Look at that big cock!"
    b_ "How was my daughter able to take it!"
    b_ "He must have ripped her open!"
    b_ "Shit! What am I thinking?"
    scene v11-108
    b "Your dad is going to kick you out for this!"
    r "Don’t be a hypocrite!"
    r "I know what you’re up to."
    r "My dad won’t be happy knowing you cheat on him!"
    b "You little shit! How dare you!"
    b "Who’s your dad going to believe, huh?"
    b "Now cover up, you pig!"
    b "If I ever catch you near my daughter again, I’ll castrate you with a blunt kitchen knife!"
    scene black with dissolve
    ""

    jump v12
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
