











label v9:










    $ runaway = False
    $ thinkaboutanotherman = 0
    $ banurejectskamil1 = False
    $ getridoftoys = False

    scene black with dissolve
    centered "{size=+120}The next day at work...{/size}" with Fade(0.5, 0.5, 5)




    scene v9-1 with blinds
    play music3 "sfx/office.mp3"
    b "Hello Sir. Did you want to see me?"
    ali "Welcome Banu. You’re looking good as usual."
    b_ "This makes me feel warm inside."
    b "Thanks. What can I do for you?"
    scene v9-3
    ali "I know you’ve met Ms. Rina for a coffee recently…"
    b "Yes, she invited me and I couldn’t say no. Is that a problem?"
    ali "Relax, it’s all good."
    ali "You did well to accept her invite. She holds a lot of sway in the company."
    scene v9-2
    b "I didn’t know her, but I got the feeling she’s a powerful woman."
    ali "That she is, Banu. That she is."
    scene v9-4
    ali "And you should probably consider yourself lucky she seems to have taken an interest in you."
    b_ "In me? Gosh! What does she want with simple me?"
    b "What do you mean, Sir?"
    ali "Well, she specifically asked that you accompany her in her next business visit to the United States."
    scene v9-2
    b "Me? Why me? I’m just a nobody here?"
    ali "She didn’t say why, but she specifically requested that it’s you. Is that a problem?"
    scene v9-4
    b "I don’t know, sir. I’m really confused."
    b "And I don’t think my husband will let me …"
    scene v9-3

    ali "Listen carefully, Banu."
    ali "Rina is a major player in the company, and has a lot of friends in high places."
    ali "As for your husband, I’m sure you have some…arguments you can use."
    ali "Maybe wear some sexy lingerie when you tell him…"
    scene v9-4
    b_ "Sheesh, how can he talk to an employee like that?"
    b "Well, I guess it’s up to him, but I can try."
    ali "Try hard, Banu. None of your colleagues can afford to go on a trip to the States. They would kill for a chance like this."
    b_ "Asshole, but he’s right, huh?"
    b "Yes, Sir. It is true I’ve always dreamed of going to America…"
    b "Living the life I’ve seen in Hollywood movies…"
    b "Even if only for a few days."
    b "Do you know where in the States we’ll be going to?"
    ali "Malibu, in California."
    b_ "Oh!"
    b_ "Those beautiful beaches. "
    ali "So, we’re agreed. That will be all, Banu."
    stop music3
    scene black with dissolve
    centered "{size=+120}Home...{/size}" with Fade(0.5, 0.5, 5)

    scene v9-5 with Fade(0.5, 0.5, 5)
    k "…but I don’t understand why you. Can’t somebody else go?"
    b "As I said, I don’t know. She wants me to go and I can’t refuse."
    scene v9-6
    k "It doesn’t add up… And you’re going to be alone without your husband in a foreign country…"
    scene v9-7
    b "Look, dear. I tried to convince my boss not to send me, but it was useless."
    scene v9-8
    b "I can’t risk losing my job over this…"
    scene v9-9
    k "Ok love, I guess. I’ll miss you, you know."

    menu:
        "He wants to get closer, but I’m not in the mood. ":
            $ renpy.block_rollback()
            $ banurejectskamil1 = True
            scene v9-11
            b "I know, honey. I’ll miss you, too."
            b_ "On no. Not this again…"
            scene v9-12
            b "Sorry, Kamil. I need to take a shower. It’s a big day tomorrow."
            scene v9-13
            k "Ok sweetie. I’ll watch TV a little longer and join you in bed."
            k_ "She’s pushing me away again…"
        "He’s not perfect, but he’s so understanding. ":






            $ renpy.block_rollback()
            $ banurejectskamil1 = False
            $ banu_kamil += 1
            scene v9-10
            b "I know, honey. I’ll miss you, too."
            k "..."
            b_ "He’s so sweet. He deserves my love and affection."
            scene v9-14
            b "Thanks Kamil."
            k "Come here, love."
            scene v9-15
            b "I had a great time at the restaurant the other evening."
            k "Me too, honey. Let’s do it again soon."
            b "Yes, let’s. A lovely time with my sweet husband."
            k "I really do love you, baby."












    scene black with dissolve

    centered "{size=+120}The Airport{/size}" with Fade(0.5, 0.5, 5)



    scene v9-16 with squares
    "As the two women approach the private airplane on the tarmac, Banu is in turmoil, still unable to come to terms with it all."
    "Excited at the prospect of such an adventure, visiting a country where people are so much more open-minded than at home."
    scene v9-17
    "Worried about the implications of the fact that she, a married woman, is traveling abroad without her husband."
    scene v9-18
    "And still unsure about the reason for being asked on this trip."
    pilot "Welcome Ms. Midori Powl. "
    "(Turning to Banu)"
    pilot "Madam."
    pilot "My name’s Elliot Roberts and I’ll be the pilot for your flight today. "
    pilot "This is Quincy Gray and he’s the co-pilot. We’ll be doing our best to ensure you have a safe and uneventful trip."
    ri "Meh, I don’t really care."
    ri "Hi."
    b "Good morning. Thanks."
    "Banu has only traveled in short plane trips on ordinary airliners, and now she marvels at the lavishness of the fixtures, the elegance of the crew and the thought that this is all for the comfort of only two passengers."
    b_ "Is this how the rich and powerful go around the world? I feel so out of place here! I’m not one of them!"
    scene v9-19
    play music3 "audio/sidesex.mp3"
    ri "Here we are, Banu. Feeling excited?"
    b "This is all so new to me, Ms. Rina."
    ri "I’m sure you’ll settle down quickly. I’ve been flying all my life."
    scene v9-20
    b "It’s not just that, madam. I…"
    scene v9-21
    ri "Call me Rina when we’re alone, dear."
    b "Oh, I could never…"
    ri "Nonsense, Banu."
    ri "And remember what I told you at the coffee shop. You have untapped potential and I want to enable you to see it for yourself."
    ri "And use it to your advantage, to get anything you want."
    ri "That’s why I took you on this trip."
    scene v9-20
    b "Are you going to show me how you do business deals… Rina?"
    scene v9-23
    ri "There’s no business involved in this trip, my dear. Or at least, not for you. "
    ri "This will be all about you letting go and having a taste of what you can achieve in life."
    scene v9-24 with dissolve
    ri "If you realize how powerful you really are."
    scene v9-25
    "The young sensually-dressed cabin attendant approaches their seats."
    scene v9-26
    attendant "I’ll be serving your lunch momentarily, ladies."
    ri "Ok, go ahead, my dear."

    b_ "What will I be actually doing? Can I trust her? Maybe she really wants to help me. "
    scene v9-27 with vpunch
    b_ "Oh my! What’s that doing here? Is that how she wants to help me? It’ so big…"
    "Rina notices her companion’s shocked expression at the sight of the large black dong on the seat across the aisle from them."
    ri_ "She’s starting to see. Oh, this is so much fun already!"

    scene v9-28
    ri "Don’t be so shocked, now. Yes, it’s a dildo. Yes, people use it to get pleasure. There’s nothing wrong with pleasure now is it?"
    b "I’m a Muslim. Our scriptures tell us that a woman is only permitted to find sexual pleasure if her husband gives it to her, and even then there are some limits."
    "But Banu’s mind returns to those many electrifying moments when she has pleasured herself, alone with her deepest desires, and is ashamed at her own hypocrisy and the weakness of her arguments."
    b_ "Was it really different for me to find pleasure with my own fingers instead of a dildo?"
    b_ "And, most importantly, the worst part is the fucking dirty thoughts I had while I was at it."
    ri "But scriptures can’t be the only thing that dictates our life, Banu. Books can be interpreted in many different ways, and indeed they are."
    ri "Believing in God, divinity, a higher power, however you want to refer to it, is one thing. I have nothing against that."
    ri "But living your life simply following the directions of somebody who interpreted the divine teachings a certain way is another matter altogether."
    ri "And don’t you think that scriptures could be interpreted in different ways?"
    scene v9-22
    "Banu looks at her skeptically, but Rina’s words have started to imperceptibly breach the solid barrier which her strict religious upbringing has raised between her and the mundane realm."
    b_ "What is she talking about? "
    scene v9-21
    ri "If God has given us our physical bodies, then it is also God who has made those bodies able to feel physical pleasure."
    ri "Also, think about people with different religious principles than yours, or folks who don’t follow any religious belief. "
    ri "I think people have every right to deny themselves the pleasures of the flesh by following what they have been taught, just as you’re telling me."
    ri "But other people also have the right to do what they feel is best, not what somebody has told them is acceptable or not."
    ri "And one of these things is celebrating the beauty of the physical body and its emotions, by exploring and sharing them."
    scene v9-22
    b "I’m not sure, Rina. What are you trying to say? What’s going to happen in America?"
    scene v9-21
    ri "Calm down, dear Banu. Nothing is going to happen. I just want you to see for yourself another way of living your life."
    ri "I want to show you how it feels to be away from prying eyes, from people who can’t wait to find faults in your actions and tell you what’s moral and what’s immoral."
    scene v9-28
    stop music3
    "Banu feels relieved. She knows she isn’t in any type of immediate threat. She still has strong doubts about what Rina has said about pleasure and religion and independence."
    "But now she knows that nothing will happen that she doesn’t want."
    "However, deep inside her, almost without her even being conscious of it yet, Rina’s words have planted a seed. What is going to come out of all this?"



    scene black with dissolve
    centered "{size=+120}Malibu, California{/size}" with Fade(0.5, 0.5, 5)

    scene california with move
    play music3 "audio/chill.mp3"
    "During the short limo ride from the airport, Banu tries to take in the sights. "
    "Everything is so novel and unfamiliar: the ocean landscape, the roads, the people and how they’re dressed."
    "She is not sure this exciting place is better than the one she calls home."
    "Back there, the well-known locations, people and culture give her a sense of comfort, for she knows safe ways to deal with most situations, but also a feeling of monotony, always doing the same things and meeting the same people."
    "But from somewhere else within her, a sudden awareness prompts her to remember the recent feelings and actions which have come to be a part of her life and have plagued her, mostly at nighttime."
    "This line of thought adds to her present state of confusion."
    "Moreover, she can’t completely ignore the nagging feeling of trepidation generated by Rina’s words. "
    "She feels a bit worried about what’s awaiting her here in California, but she’s also ready to take on everything that will come her way. "
    "She is certainly a strong person, as Rina said, and she will be able to deal with it."
    stop music3
    scene v9-29 with fade
    "Finally reaching their destination, the women approach an imposing structure, with distinctly different attitudes, familiarity for Rina and surprise for Banu."
    b_ "Oooh, this place is huge! And so plush! It doesn’t look like a hotel."
    scene v9-30
    play music3 "audio/sensual.mp3"
    "This is what she notices at first, before eventually absorbing the presence of the scantily dressed men awaiting them in the foyer."
    b_ "Who are these men? And why are they half-naked?"
    b_ "Look at those muscles. They’re so strong! Gosh, they’re really sexy … So fu-fucking hot!"
    scene v9-31
    serv "Welcome Mistress Rina. Welcome, Mistress. Please allow me to take your suitcases."
    b_ "He smells so good! What a hunk! He called me Mistress? "
    b_ "Oh, I'm actually getting a bit horny. Hope my nipples won’t show through my thin shirt."
    ri "Follow me Banu."
    scene v9-32
    ri "I want you to make yourself at home; feel free to explore the place to your heart’s content."
    scene v9-33
    ri "Your room is just up those stairs to the right. Get settled and freshen up, if you want."
    scene v9-34
    ri "I’ll be off to the beach. I need to relax and catch some rays. Feel free to join me."
    scene v9-35
    "The once completely straight-laced woman is left alone in front of a very large fireplace."
    b_ "Everything is classy and enormous here. This fireplace would warm up this hall really nicely in winter."
    b_ "Viri servi sunt? Wonder what that means. “Servi” sounds like “servant”. Are those men Rina’s servants? "
    b_ "Would it be so bad to have all those sexy men at my beck and call?"
    b_ "Mhhh! The things I could have them do to me? Ohh, but I shouldn’t think that way. My sweet Kamil doesn’t deserve it!"
    b_ "But those naked bodies made me so horny. Now I really need to go and change my panties."
    scene v9-36
    "She climbs the winding staircase, overwhelmed by the whirlwind of sensations and seeking a little solitude to pull herself together."
    b_ "Is this my room? It’s gorgeous! I’m actually glad it’s not really big."
    scene v9-39 with hpunch
    stop music3
    b_ "Shit! Another dildo?"
    menu:
        "Get rid of the toys.":
            $ renpy.block_rollback()
            $ getridoftoys = True
            scene v9-40
            b_ "What’s with dildos lying around everywhere today?"
            b_ "No, that’s enough. Can’t allow my mind to go there again! In the drawer you go."
            scene v9-37
            "The slim woman looks around the room and notices the very large window."
            b_ "Gosh, look at that window!"
            scene v9-38
            b_ "What a view! Malibu truly is spectacular. "
            b_ "So pretty! I could see myself waking up to this every morning."
            b_ "Now I guess I'll explore the villa a bit."
        "Take a closer look.":







            $ renpy.block_rollback()
            $ getridoftoys = False
            $ banubad += 1
            scene v9-40
            play music3 "audio/sexy.mp3"
            b_ "And what in the devil is that other thing? "
            b_ "I’ve never seen anything like it in my life. "
            b_ "It’s got straps. Maybe you can fasten it somewhere. Ack! Don’t wanna even think about it."

            scene v9-41

            b_ "This cock is fucking huge! "
            b_ "I’m holding it with both hands and there’s still almost half of it left over."
            scene v9-42
            b_ "What would it be like to have it inside me? Mhhh, so thick and long! It would fill my belly completely. "
            b_ "Even better, if it were attached to a sexy man like the ones downstairs."
            b_ "Golly! I need to calm down and get my mind out of the gutter. Better look around this place."
            stop music3









    scene black with dissolve
    scene v9-43 with Fade(0.5, 0.5, 5)
    "Banu starts walking around the beautiful palace and marveling at the elegance and luxury she can see in every corner of the building. "
    "She has never stayed in a place that radiates such splendor and glitz as she has only seen maybe in the ancient religious and government buildings back home."
    b_ "This place is like a fairy-tale castle and a super-modern luxury hotel at the same time."
    b_ "Full of history and stylish. A dream place. Oh, what would I give to spend my days here and live like royalty!"
    scene v9-44
    b_ "What’s behind that door? "
    b_ "Am I allowed to go through?"
    scene v9-45
    b_ "Oh! One of the sexy studs!"
    b_ "I never knew black men could make me so hot!"
    b_ "Look at those pecs! He’s so handsome and manly."
    scene v9-46
    serv "Can I help you with anything, Mistress?"
    b_ "There! Calling me Mistress again. Like a slave or something…"
    b "No, thanks. I was just looking for …"
    "But Banu is unable to finish her sentence, too preoccupied with the pleasure twinges assaulting her pussy."
    scene v9-47
    "She just knows she can’t allow herself to remain alone with that sexy masculine specimen, so she bolts for the door without finishing her sentence."
    b_ "He’s so strong! If he made a move and took me, I know I would be helpless to stop him."
    scene v9-50 with wipeleft
    "That’s why she hastily makes a retreat and finds herself in front of another closed door."
    b_ "What will I see in this room?"
    b_ "Not another sexy man I hope!"
    scene v9-48
    b_ "Is that the kitchen? Ooh, they’re kissing! They’re so beautiful together! Blondie’s got such a sexy big ass!"
    b_ "No, what am I saying? That’s immoral, so dirty."
    b_ "Isn’t it?"
    scene v9-49
    brunette "Let’s go. I wanna show you something…"
    blonde "You naughty girl, you. Where are you taking me now? Ha ha!"
    scene v9-51
    b_ "They’re acting so natural! They look so happy! How can two women be together like that? "
    b_ "Aren’t they ashamed to be naked in front of each other? And those kisses…"
    scene v9-52
    b_ "Wonder if I should follow them and see what it’s all about…"
    b_ "They went down those stairs."
    "Banu is too excited by now. She pushes away the thoughts of it being depraved and is able to live in the moment, being assaulted by the curiosity of seeing where they have gone and by something else."
    scene v9-53
    play music3 "audio/action.mp3"
    "Something she can’t consciously admit even to herself. She wants to see more of the two gorgeous women!"
    b_ "I can hear some noises."
    b_ "Is that … people moaning?"
    scene v9-54 with vpunch
    "While she climbs down the staircase, her mind goes back to what she witnessed in the dark alley back in her hometown."
    "That couple fucking hard, unconcerned if anybody could see them."
    scene v9-55
    "Her clit is throbbing by now, pulsing in time with her heartbeat. As she reaches the bottom of the stairs, the scene in front of her leaves her paralyzed in shock."
    b_ "Damn! What’s going on here? What sort of freaky place did Rina take me to?"
    b_ "They’re being so indecent right where everybody could see them!"
    b_ "Those black stallions are servicing them. Look how big and sturdy they are! He’s lifting that girl as if she were a feather!"
    b_ "Well, I’ll be…!"
    menu:
        "It's time to leave.":

            $ renpy.block_rollback()
            $ runaway = True
            b_ "What am I doing? I can't stay here."
            scene v9-63
            "Her only reaction is to flee in fright from that chamber, running up the stairs and back in the safety of her own room."

            stop music3
        "Stay a little.":






            stop music3
            $ renpy.block_rollback()
            $ runaway = False
            $ banubad += 1
            play music3 "audio/sensual.mp3"
            scene v9-56
            "Banu is mesmerized by the action before her, but she quickly gathers her wits and decides to flatten herself against the wall to keep watching undetected."
            scene v9-57
            "The brunette pushes her servile stud down on the plush sofa and straddles him, rubbing herself on his midsection, while moaning languidly. "
            scene v9-58
            "On the other side of the room, the blonde beauty leans with her palms flat against the wall, while directing her statuesque man between her legs, where he starts slurping hungrily. "
            b_ "Look how greedily he’s sucking! Oh, my panties are drenched! "
            scene v9-59
            b_ "Nobody has ever treated me like that! He is like a hungry baby! Her juices must be really tasty!"
            b_ "It’s so shameful! Then why can’t I look away?"
            scene v9-60
            "Banu is not even aware of it, but her nimble fingers have descended between her legs, where she starts caressing herself."
            "The rough material of her jeans and her soaked panties send sensual thrills to her lust-addled brain."
            "So engrossed is she in gazing at the erotic display in front of her."
            "Lost in the sensations her own manipulations are causing herself, that she does not even realize she has left her hidden position against the stone wall and is now unashamedly starting to feebly moan herself."
            "Then, it becomes absolutely impossible for her to avert her eyes from the erotic spectacle and, fingers still brushing against her own sexy mons."
            "She witnesses the huge man start to penetrate the pussy he was feeding from mere moments before, with his turgid rod."
            scene v9-61
            "It is now that, eyes closed, her own sexy vocalizations increase in volume, eventually reaching the ears of the actors of the sexy show in the room, and the man pleasing the blonde starts getting closer, while speaking to her."
            scene v9-62 with vpunch
            stop music3
            serv "Mistress, may I be allowed to serve you too? Just order me."
            "The hijab-wearing oriental beauty starts, opening her eyes upon hearing the man’s booming voice talking to her. A deep feeling of shame envelops her and she is unable to reply."
            scene v9-63
            "Her only reaction is to flee in fright from that chamber, running up the stairs and back in the safety of her own room."



    scene v9-64 with Fade(0.5, 0.5, 5)
    play music3 "audio/sexy.mp3"
    "Once there, Banu is unable to ignore the pounding pulse of her clit, and quickly strips to her underwear and lies down on her bed."
    "Unencumbered by clothes, she can properly feel her sex skin to skin, and proceeds to furiously pleasure herself, thumb on her inflamed clitoris and fingers barely entering her tight slit."
    scene v9-65
    "Faintly, she tries to rationalize that she shouldn’t feel aroused by that perverted display she has just witnessed."
    "But the truth is that she has felt nothing but uncontrollable lust from the moment she has set foot in this house of perdition."
    scene v9-66
    "Each scene escalating her unfulfilled desire to feel like a woman, to be pleasured like those women were being pleasured."
    scene v9-31saturated with fade
    "The meek welcome received by those obedient hunks at the door."
    scene v9-40saturated with fade
    "The erotic implements she finds in her room."

    scene v9-46saturated with fade
    "The sensual brute he finds alone in the first room she opens."


    scene v9-48saturated with fade
    "The two women kissing and being playful in the kitchen."

    scene v9-55saturated with fade
    "The culmination of everything: the same two women being sexually served by those big men."
    scene v9-67
    "She has the overpowering need to feel pleasured by a real man herself, and her mind cannot help but fantasize about a specific man in her life."
    label banuthinkspecificmanchoices:
        scene v9-67
        menu:
            set menuset
            "Think about Kamil.":

                $ renpy.block_rollback()
                $ banu_kamil += 1
                if banukamilbedroomchoicesblabla == 2:
                    scene v9-67kamil
                else:
                    scene v9-67

                b_ "My sweet husband! If only he were more assertive! "
                b_ "He’s so handsome and strong. He could pick me up like the man in the basement. "
                b_ "And he’s got a big cock, too. He could show me a great time if I let him."


                jump banuthinkspecificmanchoices




            "Think about Polad." if dinnerreddress == True:
                $ renpy.block_rollback()
                $ thinkaboutanotherman += 1
                scene v9-67polad
                b_ "My friend and savior, always there for me for all these years. "
                b_ "Oh, but I’ve seen how he looks at me! Devouring me with his eyes. "
                b_ "And, who am I kidding? He’s so hot. I wish I’d married him instead of Kamil. "
                b_ "He’s so buff and hunky! He would pound me so hard!"
                jump banuthinkspecificmanchoices







            "Think about Turan." if banuturansexfirsttime == True:
                $ thinkaboutanotherman += 1
                $ renpy.block_rollback()
                scene v9-67turan
                b_ "He’s sly and devious, but I can’t deny how much he turns me on. "
                b_ " I would be a living doll, all his to do as he pleases."
                b_ "He’s so strong that he’d hold me down and take me however he wants."
                jump banuthinkspecificmanchoices






            "Think about Ruslan." if banuasksruslanwhathewants == True:
                $ thinkaboutanotherman += 1
                $ renpy.block_rollback()

                scene v9-67ruslan
                b_ "Am I really so slutty that I need to fantasize about my stepson? "
                b_ "But he’s really dreamy, so lean but so ripped! Oh, Yes! And he’s young! "
                b_ "I could have a young toyboy and he’d have so much stamina. He’d fuck me for hours!"

                jump banuthinkspecificmanchoices


            "Think about Murat." if murattease == True:
                $ thinkaboutanotherman += 1
                $ renpy.block_rollback()

                scene v9-67murat

                b_ "So open and direct with his words! A real silver tongue! "
                b_ "He was rude but he made me tingle in my pussy so hard! He’s handsome and worldly."
                b_ "He must be so experienced! He would really make me feel like a woman."


                jump banuthinkspecificmanchoices
            "Just cum.":


                $ renpy.block_rollback()

                b_ "Ah! Oh, yes! Ooh! Fuck, yes! I’m cumming! "
                b_ "Ooooh! I’ve become such an immoral whore!"



    scene v9-68 with hpunch
    play sound "voices/moanfinish.mp3"
    "She explodes in a huge climax, her breath taken away from her, and she lies on the bed panting while she’s trying to recover."
    stop sound
    scene v9-69
    stop music3
    "While she’s there, guilt finally starts to set in. "
    "Banu realizes she has given in to the temptation surrounding her in this mansion full of transgression, and she wonders what has happened to the demure and proper woman she once used to be."
    "She thinks everything that has been happening in her life, the people she has met and the places she has been to have seemingly all been intent on corrupting her and depriving her of her innocence and faultless moral stance."
    scene v9-70
    "Haunted by similar thoughts, she gives in to her post-orgasmic weariness and falls into a deep dreamless slumber."

    if thinkaboutanotherman >= 1:
        $ banu_kamil -= 1





    scene black with dissolve
    centered "{size=+120}The Beach{/size}" with Fade(0.5, 0.5, 5)

    scene v9-71 with irisin
    "Banu wakes up after a fitful sleep and decides to join Rina. "
    "She walks down a steep pathway leading to the mansion’s private section of the beach. There, she easily spots her newfound friend."
    b_ "Look at that suit! She’s showing so much skin! I could never wear something like that!..."
    b_ "… Could I?"
    ri "Hello Banu! How are you, darling?"
    b "Hi! I’m happy I could find you so easily!"
    ri "Aha! It’s good to see you, really."
    ri "What did you get up to?"
    scene v9-72

    b "Well … I stayed in my room."
    ri "Uhm, did you now?"
    b "I just put my clothes away and then had a power nap."
    b "I think I’m a bit under the weather. Perhaps it’s the jet lag."
    scene v9-73
    ri "Yeah, right. I know you were too curious not to explore a little bit."
    ri_ "Who knows what you’ve found?!"
    ri "It could be that you just need to bask in the sun for a bit."
    scene v9-72
    b "Yes, maybe that would do me good."
    scene v9-74
    ri "Great! You do that, sweetie."
    ri "I have somewhere I need to be."
    ri "Maybe I’ll catch up with you later?"
    b "Alright. Bye, Rina."
    scene v9-75 with ease
    "Banu walks along the beach, enjoying the heat and grain the sand on her feet and she starts indeed to feel some of her troubled thoughts slipping away."
    "She reaches a beach volleyball court, where three good-looking young women are huddled discussing something."

    scene v9-76
    "She doesn’t even have a chance to admire the scant bikinis they’re wearing, when they turn towards her and one of them calls out."
    redgirl "Hey, you! Yes, you all covered up!"
    redgirl "Play with us. We want to have some fun, but we’re a player short!"
    redgirl "Come on, it’ just a friendly game."
    menu:
        "Accept to play.":
            play music3 "audio/action.mp3"
            $ renpy.block_rollback()
            b_ "Sure, why not? I know it wouldn’t look good if I were back home, but nobody knows me here. And I’m not the one wearing an indecent bikini and showing my ass. They are!"
            scene v9-77
            "Banu is teamed up with Amelie, in the red bikini."
            "The opposing team, blonde Reese and Carla, with her hair in a bun, start the game with the fair-haired girl, who gets things going with a jump serve."
            scene v9-78
            b_ "She’s got a great body. She’s so svelte. Her little tits are very pretty."
            scene v9-79
            "Amelie, playing as defender, easily catches the ball and sets Banu at the net."
            b_ "Here’s my chance. Just hit the ball hard! I’m going to score a point."
            scene v9-80 with hpunch
            "The opposing blocker jumps at the same time, easily neutralizing Banu’s weak attack and scoring, then celebrates with her teammate."
            scene v9-81
            b_ "Damn, she’s good! I need to step up my game if we want to have fun and have a balanced match."
            b "Sorry, my bad!"
            ame "Come on, girl! You can do it!"
            scene v9-82
            "Banu’s team serve, but their antagonists easily receive and set for an attack. Reese hits and scores again..."
            scene v9-83 with hpunch
            "With Amelie unable to save."
            scene v9-84
            "The game goes on with Banu’s team only able to score some points, while their rivals take the lion’s share."
            b_ "This is thrilling! I thought it would be just a fun time with other girls. But they all want to win! And so do I, damn it!"
            scene v9-85
            reese "Spike it, hun! Here you go!"
            "Carla strikes the ball high in the air and Banu concedes yet another point. "
            scene v9-86
            "She starts to be mad at her many mistakes and is now taking it personally."
            scene v9-87
            b_ "Grrr! I should have saved that one! Come on, Banu! You need to do better, woman!"
            scene v9-88
            "Banu and Carla face each other once again at the net. Banu is sure she can score this time, but her opponent outplays her and has the upper hand again."
            scene v9-89 with hpunch
            "With Banu landing unceremoniously on her bottom."
            scene v9-90
            "Her rival, hands on hips, stands in front of her gloating with an unpleasant smirk."
            "The game is looking a lot less friendly now."
            carla "Sorry, sweetie. I’ll try to be gentle next time. Ha ha ha!"
            "As Reese and Carla hug in celebration, Banu is helped up by Amelie and is mortified. "
            "She has felt a growing sense of rage at Carla’s humiliating blows. "
            scene v9-91
            "As she steps up to the net, her face shows all the resolve and focus of a wounded beast, teeth bared and her beautiful eyes just dark slits. "
            "She is positively seething now!"
            b_ "Hit it hard, hit it hard, HIT IT HARD, GODDAMN YOU, BANU! SHOW THAT BITCH WHO’S BOSS!"
            scene v9-92
            "Next rally, Amelie sets Banu for a spike, her willpower driving her to animal-like movements."
            scene v9-93 with hpunch
            "She’s in the zone. No other thought but the will to hit it hard at Carla. She jumps and…"
            b "Ahhhh! Growl!"
            b_ "You’re a fucking bitch! I’m gonna kill you!"
            "She hits it really hard, with a force she’s never used before in her life. "
            "With a strength she’s never known she had."
            "Time slows down almost to a standstill, nothing but a roaring sound enters Banu’s brain through her ears and then…"
            " SLAM! The ball hits Carla hard across her face."
            scene v9-94
            "She collapses to the ground holding her head and groaning at the pain."
            "Amelie and Reese group around her with worry, but she brushes them away and can do nothing but glare at the one who has humiliated her this time."
            "The side of her face starting to throb in a dull ache."
            scene v9-95
            stop music3
            b_ "I got her good! What a rush! I’ve never felt anything like this in my life."
            b_ "This is all me! I wanted it so much and needed nobody’s help. That bitch had it coming."
            b_ "Never tease the beast in me, ever again! Can you hear me, world? Never tease the beast!"
            b "Hey, I thought you were supposed to block it with your hand, not your face."
            b "I have to say, that red print suits you. I’m sure it’ll look even better when it turns all black and purple."
        "Refuse to play.":



            $ renpy.block_rollback()
            scene v9-96
            b_ "I don’t know. Women aren’t allowed to wear clothes so skimpy on the beach. Even if my suit is proper, I don’t want to be seen with girls who dress so sexily."
            "She saunters along the beach and is still thinking about the girls’ attire and the similar way Rina is dressed."
            b_ "Perhaps it’s normal here to walk around in public in that type of swimsuit? Maybe I’m just fretting too much over it. "
            b_ "No no no!"
            b_ "What if women started wearing skimpy outfits in public back home? I can already picture it, men would…."
            "She is totally absorbed by that idea and ends up missing a slight drop in the sand and losing her footing."
            scene v9-97 with hpunch
            play music3 "audio/tension.mp3"

            b_ "Oh shit! I’m gonna fall!"

            scene v9-98
            "A man is walking in the opposite direction and catches Banu as she tumbles and lands with her hands on his chest."
            "His face surprised, but enjoying the woman’s warm fingers on his skin."
            scene v9-99
            un_ "Man, she’s hot! What a sexy figure! And those black eyes!"
            stop music3
            un "Hey, Are you ok?"
            scene v9-100
            b "Yeah! I’m sorry! I wasn’t looking where I was going!"
            b "Thanks for catching me. "
            b_ "Oh, he’s cute!"
            b_ "I wouldn’t mind being held by him again and again. "
            un "Anytime sweetie! I’m just glad I did! Take care, now."

            scene v9-101
            b_ "Cute, manly and a gentleman. A real catch! "





    scene black with dissolve

    centered "{size=+120}Horse riding{/size}" with Fade(0.5, 0.5, 5)
    scene v9-102 with irisin
    play music3 "audio/kometaback.mp3"
    "Continuing her stroll along the beach, Banu is spotted by Rina again, who invites her to go along and explore the area together."
    ri "Have you ever been horse riding, Banu?"
    scene v9-103
    b "No, Rina. Can’t say that I have. Though I’ve wanted to try many times."
    scene v9-104
    ri "Great! I’m actually going to take you for a ride with me."
    b_ "Awesome!"
    b_ "..."
    scene v9-105
    b "It’s a beautiful animal."
    scene v9-106

    b "I’ve always admired horses."
    scene v9-107
    ri "Here! Let me help you up."
    scene v9-108
    stop music3
    ri "Put your foot in the stirrup and take my hand!"
    b "Oof!"
    scene v9-109
    ri "Hold on tight!"
    b_ "Ooh! I’ve never been this close to another woman! Rina has a beautiful figure."
    b "Ok. I think I’ve got it."
    "Rina spurred the horse and they started at a slow trot, the animal advancing with jerky movements."
    scene v9-110
    ri "How are you liking the California lifestyle so far, dear?"
    b_ "Her boobs are so bouncy! I can feel their weight on my wrists."
    b "It’s fine, I guess. Some things are very similar to my country, you know."
    b "But I was quite surprised at certain stuff that people find normal here, especially women."
    scene v9-111
    ri_ "You haven’t seen the half of it, sweetcheeks! I have plans for you, my pretty!"
    ri "Like what, Banu?"
    b_ "I wonder, are such big boobs even real? Probably not!"
    b "Well, clothes, to begin with."
    b "Back home, most women prefer to be modest when they’re in public."
    b "But here, it’s normal for women to wear sexy clothes everywhere they go."
    b "I’ve seen women with very small bikinis. They might as well be naked!"
    ri "I’m wearing a sexy bikini, too, darling. Do you think less for me because of that?"
    b_ "Oh, shit! She got me. Me and my big mouth!"
    b "I don’t think less of them and of you. But I would never do it. I was raised as a devout Muslim and I was taught it’s sinful."
    b "You said everybody should do what they want with their body, and maybe you’re right."
    ri_ "He he! This is fun!"
    ri "I’m happy you’re starting to see what I mean about freedom."
    "The rough movements of the horse make it harder for Banu to hold onto Rina’s waist. "
    scene v9-112 with vpunch
    "Her hand ends up accidentally holding one of Rina’s breasts tightly and Banu recoils in shock at the contact."
    b_ "Whoa! It’s her tit I’m holding onto! They’re so fucking big! Real or not, they sure feel nice! Oh fuck, what am I saying?"
    scene v9-113
    b "Sorry, Rina. I really didn’t mean to. Please forgive me."
    ri_ "Let’s fuck with her a little more!"

    ri "It’s ok, Banu. I don’t mind at all. Feel free to touch as much as you want!"

    scene v9-114
    b_ "Now, now! I know she doesn’t really …"
    b "Hey, you know it wasn’t on purpose!"
    ri "I know, sweetie. I know. But still …"

    jump v10
























label v10:

    $ kamilrepliestoguyforest = False















    scene black with Dissolve(3)
    centered "{size=+120}The next day{/size}" with Fade(0.5, 0.5, 5)
    scene v10-1 with squares
    play music2 "sfx/office.mp3"
    "Kamil is at the office, almost ready for closing time."
    "It has been hard for him so far without Banu. He misses her, but also feels weird letting her leave alone to a foreign country."
    k_ "Gosh, so busy! Everybody wanted a house today. So ready to go home!"
    k_ "Oh, it’s Banu."
    scene v10-2
    k "Hi, baby."
    b "Hi Kamil, how are you doing?"
    k "I’m fine, sweetie. I worked really hard today. I was about to go home."
    k "How’s things in the States?"
    b "It’s all good, dear. I’m not doing much, to be honest."
    b "Rina is taking care of all the work. It’s almost just like a glorified vacation."
    k "Really?! That’s very strange! Don’t you think?"
    b "Yes, it is, actually. But I’m trying to enjoy the trip as much as I can."
    b "This place is stunning!"
    k "Well, what are you doing with your time?"
    b "I’ve visited the town once and I’m spending some time at the beach. You know, the place I’m staying at has a private beach!"
    b "But, honestly, I’m staying in my room a lot, too. I’m reading and relaxing."
    b_ "And I’m not sure I should go wandering around again."
    b_ "Who knows what else I’d see."
    k "Are you staying at a fancy hotel?"
    b "It’s not a hotel, more like a mansion. I think Rina’s the owner."
    b "It’s a very ritzy place! I’m sure you’d love it here."
    k "That isn't funny at all."
    scene v10-3
    b "Well, actually. This is just what I wanted to talk to you about…"
    b "..."
    b "Why don’t you join me here!"
    k "Wha…! Really? But you know we can’t afford it! And, what about work? … And the kids?"
    b "Rina wants you to be her guest, just like me."
    b "And the kids can take care of themselves for a few days, don’t you think?"
    b "Can’t you take a few days off? It would make me really happy!"
    b "We could have a few romantic evenings, just you and me and …"
    k "It’s already odd that Rina asked you to go with her, and then has you doing nothing."
    k "And now she wants to fly me there?"
    k "Maybe she wants something from you?"
    b "Don’t overthink it, baby."
    b "It’s the chance of a lifetime! And we never take a few days away together."
    b "Just come, baby. Let’s do this!"
    k "But why does she want me to come?"
    k "And, most of all, why does she want to spend money for me to come?"
    b "She seems to be very fond of me."
    b "She’s been really nice."
    b "Maybe she knows I’m one of the best employees and wants to reward me, like a bonus."
    b "Just do it, Kamil."
    b "Pack your bags and come."
    b "Rina can organize a flight just for you."
    b "Let’s be crazy for once."
    k "Well, I don’t know, honey … I think maybe …"
    k "This is too much all of a sudden."
    k "..."
    k "But maybe you’re right. We work hard. Let’s not waste a chance like this!"
    b "Awesome! I’ll call you back and let you know what Rina has organized!"
    scene v10-4
    k_ "So strange..."
    k "I have a bad feeling about this …"
    k_ "..."
    stop music2
    scene v10-5 with Dissolve(3)

    "Kamil leaves the real estate office and while he’s driving back to their flat, Banu calls him to let him know that everything has been arranged and his flight leaves the following day."
    "He can’t shake off the weird sensation coming from the unusual invitation."
    k_ "My gut is telling me it’s a bad idea."
    k_ "But I don’t want to disappoint my wife."







    scene black with Dissolve(3)
    scene v10-6 with irisin
    play music "audio/sidesex.mp3"
    "Everything has been arranged to perfection by Rina, and Kamil can fly to the States the following day."
    "While he’s on the elegant private plane, he can’t help mulling over the strange events."
    k_ "We shouldn’t accept freebies from a stranger just like that!"
    k_ "Shoot! We’re gonna owe her big time."
    k_ "Who knows what she’ll want from Banu!"
    scene v10-7
    k_ "But it’s true that she and I can have a good time."
    k_ "Maybe she’ll finally open up to me."
    scene v10-8
    "He sees the flight attendant walk past him, wearing a very interesting outfit."
    k_ "Whoa! Look at that dress!"
    k_ "She’s showing half her ass!"
    k "Excuse me, miss?"
    scene v10-9
    girl1 "Yes?"
    k "What time are we landing?"
    girl1 "Well, that’s up to the pilot, isn’t it?"
    k "Do you mean you don’t know?"
    girl1 "Maybe I do, maybe I don’t."
    scene v10-10
    k "What?!This is crazy! Is this how you treat the passengers?"
    girl1 "Some of them, yes."
    "The other attendant, hearing the conversation, makes her way towards the pair, strutting sexily down the aisle with an amused smirk on her beautiful face."
    girl2 "Hey, what’s happening here?"
    scene v10-11
    k "I was just trying to find out what time we’re landing, and your colleague doesn’t want to tell me."
    girl2 "Yeah? So what?"
    k "Oh no! You too?"
    girl2 "Yeah, me too. What are you gonna do about it?"
    scene v10-12
    k "You’re really rude. I don’t understand."
    k "And what are you wearing?"
    k "These outfits are for strippers, not flight attendants."
    k "You should cover up!"
    scene v10-13
    girl2 "Oh, listen to him."
    girl2 "So sweet with his cute fluffy do!"
    girl1 "He doesn’t like our outfits, huh?"
    girl2 "Now, that’s not a nice thing to say to a lady!"
    girl1 "Let’s go, sweetie."
    girl1 "We’ve got … things to do!"
    scene v10-14
    girl2 "Mhh! Yeah, let’s go and do … things."
    "Bending over to fix her hair."
    girl2 "Oops!"
    k "Huh?"
    k_ "Wow! Look at that. "
    scene v10-15
    k_ "Where the hell am I?"
    k_ "Why are they being such bitches?"
    k_ "They work for Rina, huh?"
    stop music

    scene black with Dissolve(3)
    scene v10-16 with blinds
    "During the long flight, Kamil keeps thinking over and over about the bizarre circumstances of this trip."
    "What should he expect in Malibu? Why does Rina really want both him and his wife there? The flight must have cost her a lot, after all. And he knows that nothing comes for free."
    "And what’s the deal with those hot women on the plane, dressed like sluts and being rude?"
    scene v10-17
    "Arriving at the address given to him, everything else is momentarily forgotten when he sees the luxury of the place. "
    "Sure, Banu has told him it is glamorous, but nothing could prepare him for the decadent splendor of the palace."
    "Still a bit disoriented, Kamil enters and finds a smiling Banu welcoming him with her cute face."
    k "There you are, honey!"

    b "Oh Kamil! How I missed you!"
    k "Come here, Banu."
    scene v10-18 with hpunch
    b "Mhh!"
    b_ "Finally, a familiar face! Aww, it feels good to be in his arms!"
    k "I missed you."
    b "Me too, dear!"
    b "I’ve been so confused here on my own!"
    scene v10-19
    b "How was your trip?"
    k "It was long but alright."
    k "It was good to catch up on my sleep a little."
    scene v10-20
    b "Oh, here comes Rina."
    k_ "Gosh, she’s really good-looking."
    k_ "I was expecting an old hag for some reason."
    scene v10-21
    b "Rina, he’s my husband Kamil."
    b "This is Ms. Rina Midori Powl."
    k "Nice to meet you, madam."
    ri "Likewise!"
    ri "I trust you had a safe trip?"
    k "Yes, thank you very much."
    k_ "She’s wearing indecent clothes too?"
    k_ "Mhh, what’s going on?"
    ri "Banu, why don’t you show him your room?"
    b "Yeah, great idea!"
    scene v10-22
    b "Come this way, baby."
    "While they’re walking hand in hand through the large hall, Kamil feels overwhelmed by the marble columns, polished brass finish, fine wooden floors and the sheer size of the place."
    "Just as it’s happened to Banu when she has first set foot inside."
    scene v10-23
    "However, similarly, he also appreciates the understated charm of his wife’s room, where she’s carefully hidden the dildo and the ball-gag by now."
    k "Is this where you sleep, Banu?"
    b "Yes. Do you like it?"
    k "I do, actually. It’s clean, cozy and there’s a splendid view!"
    b "Exactly!"
    k "So, you’re on a first-name basis with Rina, huh?"
    b "Yes, I know. She insisted …"
    scene v10-24
    play music "audio/tension.mp3"
    k "Listen, baby. It’s great to see you and all but …"
    b_ "Here we go."
    b "Mhh, but what?"
    k "It’s not really ok for me to skip work just like that."
    k "I know, I’m a freelance for the estate agency."
    k "But it definitely won’t look good for my reputation."
    scene v10-25
    b "Kamil, really now?"
    k "What are my colleagues gonna think?"
    k "They hardly get a day off even if they need it!"
    b "But you deserve it!"
    scene v10-26
    k "They deserve it too."
    k "But the office is so busy that they have been doing overtime almost every day the last few months."
    b "You’re not their employee!"
    k "Arghhh! That doesn’t mean I can slack off."
    k "They’ll think I’m an entitled snob who doesn’t care about their situation."
    b "And aren’t you worried about what I care about?"
    b "That I wanna spend time with you?"
    k "You’re supposed to be on my side on this!"
    k "Not act like a spoiled teen girl, damn it!"
    scene v10-27
    b "You always have to go and ruin everything."
    k "Now now, I didn’t mean … "
    b "Just leave it! I shouldn’t have asked you to come!"
    b "You and your stupid worries!"
    scene v10-28 with vpunch
    "The couple has had a few brief moments to calm down, but tension is still evident in the air."
    "Their raised voices haven’t escaped Rina, who suddenly shows up, with one of the strapping semi-naked servants in tow, a stern expression on her face."
    ri "Hey! Are you two ok?"
    ri "Kamil, it’s not nice of you to shout at Banu."
    ri "Please, leave me alone with her."
    ri "I want to talk to her."
    ri "Also … I’ve reserved another room for you."
    k_ "This is getting weirder by the minute!"
    k "Well … Ok."
    scene v10-29
    ri "Help this gentleman with his luggage, will you?"
    serv "Yes, mistress."
    serv "Please, come this way, sir."
    "Kamil follows the man and wonders why he isn’t wearing proper clothes. He feels that it’s not appropriate for his wife to be around men kitted out so skimpily."
    k_ "Why the hell am I supposed to stay in a different room from Banu? She’s my wife, for fuck’s sake!"
    "And the way Rina has addressed him, as if she owns him, starts to feel very similar to the way the cabin attendants have made him feel small and insignificant on the plane."
    k_ "Now I’m sure there’s something off here."
    k_ "I really shouldn’t have come."
    k_ "And neither should Banu."
    scene v10-30
    stop music
    "Once the two men have left the room, Rina’s face softens and she talks to Banu with genuine concern."
    ri "My dear girl, you should never let a man talk to you that way."
    b "We just had a little row."
    b "He’s my husband. He’s harmless."
    ri "Let’s take a seat, Banu."
    scene v10-31
    ri "Now, what was that all about?"
    b "Nothing serious, I promise."
    b "Kamil wasn’t very happy about something."
    b "It wouldn’t make sense to you."
    b "It’s a cultural thing. I really don’t want to burden you."
    scene v10-32
    ri "Sweetie, it really doesn’t matter what the reason was."
    ri "But I told you already, you should never allow anybody to treat you like that."
    ri "Especially men!"
    b "..."
    scene v10-33 with blinds

    "Meanwhile, the dark-skinned help has shown Kamil to another room and brought his luggage there."
    k "Why aren’t you wearing a top?"
    serv "It’s our uniform, sir."
    k "What is this place?"
    k "What happens here?"
    scene v10-34
    serv "I’m not at liberty to talk about it, sir."
    serv "You’d better ask my mistress."
    k_ "Mistress? I guess I won’t get anything out of him."
    k "Ok, thanks a lot. That will be all."
    scene black with Dissolve(3)
    scene v10-35 with Dissolve(3)
    k_ "Maybe Banu and I should just pack our bags and leave."
    scene v10-36
    play music "audio/sidesex.mp3"
    "Right while he’s considering to seriously do just that, Rina enters the room and looks at him with a slightly amused gaze."
    ri "Kamil, let me show you around the beach."
    ri "Come!"
    scene v10-37 with Fade(0.5, 0.5, 5)
    "The slight land breeze carries the balmy scents of the trees and the summer herbs."
    "Crickets are chirping and, combined with the soft crunch-crunch of the pair’s steps on the earthy sand and the plashing ocean waves, they create the ideal relaxing background noises."
    "Kamil forgets for a second everything else and enjoys the instant, walking along the beach with a beautiful woman, in an idyllic setting."
    "Before coming to his senses and remembering that this is not the woman he’d like to spend the evening with, and the setting is not idyllic at all, but rather distressing."
    scene v10-38
    stop music
    ri "Why are you cross with Banu?"
    ri "She’s a lovely woman."
    ri "Maybe you don’t know how lucky you are."
    k "I told her it was really peculiar to come here."
    k "You paying everything for both of us."
    k "I’m not used to all this luxury and …"
    scene v10-39
    ri "Did she tell you why I invited her here?"
    k "She’s not sure herself, madam."
    k "She thinks maybe because you like her."
    k "She’s a good worker, after all."
    scene v10-40
    ri "And does that look strange to you?"
    k "A bit."
    k "I know people don’t normally spend all this money for nothing."
    ri "Listen, Kamil. I’m extremely wealthy."
    ri "I’ve got an enormous amount of money to spare."
    ri "I’m used to buying anything I want."
    ri "There’s nothing Banu or you can give me."
    ri "And I like her. It’s true."
    ri "So, try to make sure she enjoys her stay here. And don’t interfere with her happiness."
    k "I’ll do my best, madam."
    ri "Great! Make sure that you do!"
    ri "You need to let her express herself because she’s a unique woman and deserves a chance to shine."
    ri "Have a good night now!"
    scene v10-41 with fade
    "..."
    scene black with Dissolve(3)
    "Meanwhile …"
    scene v10-42 with Dissolve(3)
    "After Rina has left her room, Banu gets near the window, deep in thought, maybe expecting the striking panorama to clear her mind."
    "A while later, she does indeed feel calmer and less affected by Kamil’s outburst and Rina’s reaction."
    scene v10-43
    "That is when she spots the duo walking and chatting – well rather Rina talking and her husband barely responding, and another reason for speculation insinuates itself in her muddled mind."
    "A short time passes by and she sees the commanding woman striding purposefully back to the mansion."
    scene v10-44 with fade
    "It is but a minute later and Kamil walks slowly back inside, and Banu decides to meet him at the entrance, her intention focused on patching things up after their row."

    scene v10-45
    b "Did you have a nice walk, Kamil?"
    k "I… Yes."
    k "Sorry for getting mad before."
    b "I’m sorry too."
    b "It’s a strange situation."
    k "It is. I shouldn’t have yelled at you, though."

    scene v10-46
    b "No, but I can understand why you’re frustrated."
    b "I should have been more understanding."
    b "Instead I just brushed off your worries."
    k "Thanks, baby."
    k "Still, I feel awful for shouting."
    b "Let’s make each other happy, Kamil."
    b "I trust you."
    k "Let’s do it, my love."
    scene black with Dissolve(3)
    centered "{size=+120}Another day...{/size}" with Fade(0.5, 0.5, 5)
    scene v10-47
    play music "audio/chill.mp3"
    "Kamil and Banu are enjoying a stroll along the same stretch of sandy terrain Kamil has walked together with Rina the day of his arrival."
    k_ "She looks so kind and respectable with a long dress and her hair covered."
    scene v10-48
    b "Oh, look dear. That’s a beautiful horse. Did I tell you that I went riding with Rina?"
    b "Let’s see if she’ll let us ride it together!"
    k "..."
    scene v10-49
    "She runs forward towards the sexy businesswoman to ask her and she agrees with pleasure."
    k "Mhh, I’ve always been too nervous to ride a horse."
    "I’m too afraid of falling."
    scene v10-50
    b "Come, darling. Rina is gonna let us ride!"
    k "But I’ve never been on a horse."
    k "Do you know how to ride?"
    b "No. Rina will hold the reins and lead us."
    k "..."
    scene v10-51
    k "It’s not very safe, honey."
    k "There isn’t even a saddle …"
    ri "Come on, Kamil. Don’t be such a killjoy."
    ri "I’ll make sure you’re safe."
    b "Yeah, baby. Let yourself go."
    b "Listen to your inner child. It’s gonna be ok!"

    scene v10-52
    k "Oh what the heck! Let’s go."
    b "Giddy up horsie! Ha ha!"
    k "Look at you, my little cowgirl!"
    scene v10-53

    b "Yay! This is so much fun!"
    b "Do you like it, Kamil?"
    k "It’s not too bad, actually."
    "Rina leads them around for a little while, to the utter enjoyment of Banu and the mild frustration of Kamil, who clings to his wife’s arms with fear. "
    "He’s grateful when the ride finally ends."
    scene v10-54
    stop music
    b "Thanks for doing this with me, sweetie."
    scene v10-55
    k "I like making you happy, my love."
    b "You do, huh?"
    scene v10-56
    b "Oh yeah? Catch me then."

    scene v10-57
    play music "audio/sensualsex.mp3"
    "With that, Banu starts running towards the beach proper, followed by an amused Kamil, who is happy to chase his lovely wife... "
    "...without making any attempts to reach her, to see where she will lead them."
    scene v10-58 with fade
    "Banu is dizzy with excitement and, once near the edge of the water, invites her husband to undress and enjoy the sun with her."
    scene v10-59
    b "I feel so free!"
    b_ "I wish I could undress too, but I’m not wearing a swimsuit."
    b_ "And it’s not right for a woman to show her underwear in public."
    k "This beach is fantastic! So rugged! The water is so clear!"
    scene v10-60
    b "It’s so good to be here with you, my love."
    k "I’m really happy right now."
    b "Kiss me, Kamil. "
    scene v10-61
    "The two lovers start kissing sweetly, but with passion arousing them both. They grip each other snugly, senses ablaze."
    scene v10-62
    "The strong man holds his woman and lifts her in his arms..."
    scene v10-63
    "...carrying her a little ways into the water, still kissing..."
    scene v10-64
    "...before he backs up and then lies down in the sand with her on top."
    stop music
    k "Did you fly with Rina’s private plane too, on your way here?"
    b "Yes. Why?"
    k "Well, the flight attendants were wearing very revealing uniforms."
    b "Mhh, yes. I noticed that too. It was a bit odd."
    k "That’s how Rina wants them, I suppose."
    b "Right. But yeah. It was a bit strange."
    b "..."
    b "I saw some strange things at the mansion, too."
    k "What, you mean apart from the butlers’ uniforms?"
    scene v10-65
    b "Maybe."
    scene v10-65red with Dissolve(3)
    play music "audio/sexy.mp3"
    "Banu remembers the women kissing and then the two big men pleasuring them down in the basement, and desire starts to redden her cheeks."
    "She looks at him with a little devilish smile, and starts caressing his chest."
    k "What’s gotten into you?"
    scene v10-66
    "Her actions soon provoke a response in her man, and she looks at his bulging crotch with a predatory glance, her pupils dilated and her panties starting to moisten."
    "Her hand starts to get closer and closer to the object of her desire. The passion and the warm sensation of Kamil’s skin stimulate the woman to go even further until …"
    k "Whoa, baby!"
    k "That’s too much!"
    k "People could see us."
    scene v10-67
    stop music
    "Banu recoils with a start, removes her hand and sits up exasperated."
    b_ "He really is a fucking wimp!"
    b "You’ve gone and ruined this too."
    b "I don’t get it. I really don’t!"
    k "But we’re in public! It’s not decent!"
    k "..."
    k "You seem like a different woman …"
    k "I hardly recognize you anymore."
    b "You’re a jerk! You know that?"
    scene v10-68
    "With that, the once-demure milf gets up and paces away angrily from her husband, her feelings evident in her frowning face."
    k "Wait, Banu!"
    k "Come here!"
    k "Be reasonable!"
    b "Go away!"
    b "I don’t wanna talk to you!"
    "Banu walks away aimlessly, but in the general direction of their accommodation."
    scene v10-69 with hpunch
    play music "audio/tension.mp3"
    "She spots Rina who, sensing that the decorous woman is upset, intercepts her and shelters them both behind a large rock, away from prying eyes."
    ri "Hey, dear! What happened?"
    b "..."
    "Rina doesn’t need her friend to explain her how she feels, and she can make an educated guess as to the reason of her discomfort."
    scene v10-70
    ri "Ok, here’s what we’re gonna do!"
    ri "Tomorrow, you, me and that schmuck of your husband are gonna have a serious talk!"
    stop music

    scene black with Dissolve(2)
    scene v10-71 with Dissolve(3)
    "Banu and her husband are seated on a plush couch each, in yet another lavish room of the mansion..."
    "...awaiting Rina for their planned talk, not exactly knowing what to expect."
    k "I’m still not sure what we have to talk about."
    b "I don’t know myself."
    b "Rina just told me she wants to talk to us."
    b_ "She just didn’t use quite the same words."
    scene v10-72
    "Rina enters the room wearing an extremely tight rubber jumpsuit that leaves nothing to the imagination."
    "Both husband and wife can’t help being impressed by her sexy body in that outfit."
    scene v10-73
    "She’s resolute in her stride, and takes a seat across the couple on Banu’s side."
    ri "Good morning, guys."
    b "Good morning."
    k "Good morning."
    ri "You must be wondering why I’ve asked you to be here today."
    ri "Well, to be blunt, I find it rather disrespectful that you two keep having arguments. "
    ri "You are bringing the mood down with that kind of behavior."
    ri "I’ve flown you here, basically for a free vacation and you still find the time to make everyone miserable with your squabbles!"
    "The two remain in deferent silence during the outburst. Banu feels actually sorry for all the grief caused."
    "Kamil does too, somewhat, but the sensation of something not quite right still lingers in the back of his mind."
    "Rina’s tone is somewhat softer, now that she starts talking directly to Banu."
    scene v10-74
    ri "Banu, I care for you. You’re someone important to me, even if you don’t realize it yet."
    ri "I need you to open up to me, to trust me."
    ri "The main reason I wanted to have you both as my guests is for us to trust each other."
    ri "It’s the only way for us to really do great things together."
    scene v10-75
    ri "And here you are, probably having the holiday of your dreams, and you spend it fighting? I won’t have any more of this nonsense, you hear?"
    "Banu feels the need to make things clearer to her friend, but is not really sure how much she should share in front of her husband."
    b "It’s just that … we’re finding it difficult to be completely relaxed."
    ri "I can’t imagine what the problem is."
    b "I have trust issues. I’ve had problems letting go and being intimate with Kamil."
    b "He’s a lovely man, and we need each other to take care of the kids, but …"
    scene v10-76
    k "Hey Banu, you never told me things were quite that way."
    k "You were never so honest with me."
    b "It’s not very easy for me to admit it, Kamil, even to myself."
    scene v10-75
    "Rina ignores Kamil’s remark, barely tolerating his intervention in the discussion, and keeps talking to Banu."
    ri "You’re looking at it the wrong way, dear."
    ri "You’re deflecting the blame and not taking the initiative to live the life you want."
    ri "It’s only up to you."
    ri "We can’t shift the responsibility to others for the things we don’t like in our lives."
    ri "And you already told me about your marriage when we first met!"
    scene v10-76
    k "Hey, wait a minute!"
    k "I can’t believe you told a stranger intimate stuff of our marriage but you never … "
    scene v10-77
    play music "audio/tension.mp3"
    "At this, Rina can’t take it anymore and springs to her feet, her body language expressing all the rage she’s probably been suppressing during the exchange."
    ri "No, you wait a minute!"
    ri "You have no right to interrupt a lady while she’s speaking!"
    ri "Instead of yelling, you should know why she’s unhappy!"
    scene v10-78
    stop music
    "Kamil is taken aback by the sudden outburst, and feels quite chastened if not slightly scared by the aggression showed by their host."
    "Banu is a little surprised to see her husband accepting to be shouted at by a woman so meekly..."
    "...and her memory saves the information, maybe to be accessed again some other time."
    scene v10-75
    ri "Carry on, dear."
    b "Well, I’ve spent my whole life making every effort to be proper."
    b "I mean, my religion dictates that a woman should behave a certain way, and I don’t want to go against that."
    b "But I think that somehow, I’m missing out on a better life."
    b "And being here and seeing a type of culture where women are free to express themselves."
    b "Well, I just …"
    b "Maybe there is a way to follow my religion and still have fun from time to time."
    ri "Of course, Banu."
    scene v10-74
    ri "Maybe what you’ve seen women do here is not what you’re used to."
    ri "But it doesn’t automatically mean they’re bad people."
    scene v10-75
    b "Sometimes women can’t do certain stuff because they need to save their reputation."
    b "I’m a good woman, but I have the right to be happy."
    b "I’d love to have more freedom to enjoy life with my husband."
    scene v10-78
    b "What do you think, honey?"
    k "You know I’d do anything for you, darling."
    k "I told you I’ve noticed that you seem different these days."
    k "Maybe I reacted badly because I was surprised and I didn’t feel in control."

    k "I didn’t know what was happening."
    k "It was difficult for me to see how you really felt."

    k "But I’m with you, Banu."
    k "I know you’re a good woman and I trust you. "
    scene v10-79

    ri "Well that’s a good start."
    ri "Now that things are more in the open, it will be easier for you two."
    ri "I also wanted to tell you that I’ll be leaving for a few days."
    ri "I want you to enjoy everything here and make yourselves at home."
    b "Ah! Are you leaving, Rina?"
    b "I’m a bit nervous about that."
    ri "Don’t worry, Banu."
    ri "You have Kamil here with you."
    ri "My servants will provide anything you need."
    ri "Don’t hesitate to call them."
    ri "And no more fighting, you hear?"
    "Rina waves at the couple and walks out the door, leaving them with mixed feelings about being left in the house without her."
    scene v10-80
    play music "audio/sidesex.mp3"
    "Banu gets up quickly from the couch and follows Rina in the hallway where, as usual, she’s taking quick steps in whichever direction she’s going."
    b "Rina! Wait!"
    scene v10-83
    ri "What’s up, Banu?"
    b "I want to ask you something before you go."
    b "See, we just talked about trust and …"
    scene v10-81
    ri "Go on, dear!"
    b "On my first day, I went exploring and, in the basement …"
    b "I saw two of your servants with two women."
    b "They were, you know … Doing stuff together."
    b "What’s going on here?"
    scene v10-82
    ri "You’re a bit confused, right?"
    b "To put it mildly …"
    ri "Dear girl, they were making love!"
    ri "What’s so strange with that?"
    b "Many people making love together, is what is strange!"
    ri "Banu, love is love, however it’s expressed."
    ri "Remember, I told you on the plane already. Just because your preachers say it’s bad, it doesn’t make it bad in reality for other people."
    ri "There is part of your religion that allows men to have many wives."
    ri "I wouldn’t be able to say if that’s right or wrong, Banu."
    ri "Would you?"

    scene v10-81
    b "Right now, I’m not sure anymore, Rina."
    b "I’ll have to think about it, I guess."
    b "..."
    b "Ok then. Have a safe journey and see you soon."
    ri "Take care of yourself, Banu."
    stop music

    scene black with Dissolve(3)
    scene v10-84 with squares
    play music "audio/sensual.mp3"
    "Alone in her room, Banu is feeling hot and bothered while thinking about the sex acts she’s seen in the mansion."
    "She just can’t forget the idea of the four people having sex in the same room..."
    "...the two big studs serving the two women who just a few moments earlier had been kissing and hugging so sensually and playfully."
    "Her body has learned to accept the horniness that her memories give her, even while her mind is still a little behind because her upbringing tries to hold her back."
    scene v10-85
    "She remembers back home when Kamil almost took her in the kitchen, but she just couldn’t go for something so dirty outside the bedroom."
    "She remembers almost giving up when he started to pleasure her, but stopping him before things got interesting."
    scene v10-86
    "She feels the need to do something sexual now, she isn’t sure what, but something at least. "
    "And she goes searching for her husband in his room."
    scene black with dissolve
    scene v10-87 with Dissolve(3)
    "She finds him there deep in thought, looking at the beautiful vista through the drawn curtains."
    stop music
    b "Hi Kamil, what are you up to?"
    scene v10-88
    k "Huh? Nothing, sweetie. Just thinking."
    b "Shall we go for a walk?"
    k "Where to, baby?"
    b "There’s a very nice pine woods near the house. Wanna go?"
    k "Sure, Banu. That’s a good idea, actually."
    k "Let’s go."
    scene black with Dissolve(3)
    scene v10-89 with irisin
    "The woods are slightly dusky with the foliage filtering the sunlight, and the smell of the pine needles, crisp and inviting, feels very invigorating to the couple as they walk around at a relaxing pace."
    scene v10-90
    k "I never knew exactly that you felt that way."
    k "That you saw me just as support for the children…"
    b "I didn’t say that, Kamil."
    b "And I don’t just think that about you."
    k "You don’t?"
    b "Of course not. I love you very much. I want to be a proper wife for you."
    k "I’ve always loved you, Banu. I try my best to make you happy."
    b "I know you do."
    k "You’ve been a good mother to my Ruslan, but I want to have a normal relationship with you."
    b "Come here, baby."
    scene v10-91
    play music "audio/sensualsex.mp3"
    "Banu gets closer to her husband and they kiss tenderly, hugging each other tight."
    scene v10-92
    "Kamil’s hand soon strays down to her sexy wife’s shapely butt, caressing it hotly through her jeans."
    scene v10-93
    "Banu is feeling no less naughty than her husband. She turns sideways and holds his crotch in her hand, with an impish smile on her face."
    scene v10-94
    b "Am I making you horny, dear?"
    k "Ahem, Banu …"
    b "Relax, sweetie. We’re all alone here …"
    k "..."
    b "And if someone comes, they don’t know us. It’s not like back home."
    show jerkoffanimation
    "She makes quick work of his zipper, and pulls out a rather turgid cock."
    b_ "Oh my! He’s so hard! I really turn him on! It’s so thick!"
    b "Do you like your wife touching your cock, dear?"
    k "Oh fuck, yes! Your hands are so soft!"
    b "Are you horny for your shameless wife, sweetie?"
    k "Oh, shit yes!"
    k "You’re gonna make me cum already!"
    b "Mhh, yes! Cum for me Kamil! Cum for your naughty wife!"
    k "Oh yeah! Fuck! Here it comes baby!"
    b "Give it to me!"
    scene v10-95 with vpunch
    play sound "voices/man2.mp3"
    "Kamil spurts hotly with pent-up lust, and Banu looks passionately at the large amount of cum she has extracted from him."
    stop sound
    "Proud and lustful at the effect she’s had on her man with a simple touch of her hand and a few wicked words."
    b_ "I made him cum so fast!"
    scene v10-96
    b "Do you like it when your wife acts a little slutty? Huh?"
    k "Mhh, I do baby! Fuck yes, I do!"
    scene v10-97 with Fade(0.5, 0.5, 3)
    stop music
    "The pair starts on their walk again, holding each other snugly and not saying much, but with different moods than when they started their walk."

    "Kamil feels relaxed and the nagging concerns have momentarily left him, drowned by the post-coital endorphins coming from his wife’s skillful handjob."
    scene v10-98
    "Banu is no less horny than before, her belly hot, but she is now also basking in the feeling of power she has experienced as a woman, making a man cum so easily."
    "A few hundred yards in, they spot a topless hiker walking towards them in the opposite direction."
    scene v10-99
    play music "audio/chill.mp3"
    "As they come very close, they both notice the looks he gives Banu, maybe surprised at her covered hair..."
    "...or maybe partial to her beauty, accentuated by her tight casual clothes, or probably both."
    un "Good morning."
    un "Hey man. You’re very lucky! Your girlfriend is really pretty."

    menu:
        "Kamil replies.":
            $ renpy.block_rollback()
            $ banu_kamil += 1
            $ kamilrepliestoguyforest = True
            scene v10-100
            stop music
            "Kamil is bothered by the comment and doesn’t like that another man is ogling his wife."
            k "Yeah man. Thanks, but you can stop drooling now. And pick your jaw off the floor."
            b_ "Mhh, he’s jealous. That’s sexy!"
        "Banu replies.":






            $ renpy.block_rollback()
            $ banu_kamil -= 1
            $ kamilrepliestoguyforest = False
            scene v10-101
            "Banu is still in a spicy mood and appreciates the comment. The guy is really cute and she can’t get enough of his admiring stare."
            b "Thank you. You’re too kind!"
            scene v10-102
            un "No, it’s true! You’re a stunning woman!"
            stop music





    scene black with Dissolve(3)
    scene v10-103 with Dissolve(3)

    "It’s the middle of the night."
    "Banu is lying in bed in her night clothes, but she can’t sleep. Her attention keeps returning to the way she has acted in the woods with Kamil."
    scene v10-104 with dissolve
    b_ "I was so shameless! Have I really become such a depraved slut?"
    b_ "When I saw that couple fucking in the street back home, I thought they were so indecent."
    b_ "And now, look at me. Is what I did so different?"
    scene v10-105 with dissolve
    b_ "But I’m sure we didn’t hurt anybody. Nobody saw us."
    b_ "I made Kamil feel so good!"
    b_ "And I felt so powerful… and horny!"
    b_ "Fuck! I’m still horny! I need more."
    scene black with dissolve
    "After debating with herself, she gets out of bed and walks with resolution to her husband’s room."
    scene v10-106 with dissolve
    "There she finds him in bed, sleeping in his boxer shorts and nothing else, and her horniness increases as she admires his body."
    k "Groan! What’s going on, Banu?"
    b "I was feeling lonely, baby."
    b "Did you miss me?"
    k "Why don’t you stay here tonight, Banu?"
    k "Rina is gone."
    k "And we’re married after all."
    b "That sounds like a plan, Kamil."
    b "I think I’ll just move to your room altogether."
    b "Let’s go to sleep!"

    scene black with Dissolve(2)
    scene v10-116 with move
    play music "audio/sensual.mp3"
    "Waking up the following morning, Banu wants to arrange her move to Kamil’s room."
    "So she goes looking for one of the servants and asks him to bring her stuff to Kamil’s room."



    "She follows him with her mind being assaulted by other ideas..."
    "...and now she realizes how strange it is that Rina wanted them to sleep in separate rooms."
    "She considers that maybe Rina doesn’t really like Kamil, also from the way she treated him during their discussion."
    scene v10-117
    "Then Banu remembers when they flew to the USA, the contempt she had for the male pilot, but the kind way she talked to the female flight attendant."
    "And she has noticed how rudely she talks to the house servants."
    "Following behind the servant, she is mesmerized by how his muscles ripple with the rhythmic movement as he walks."
    "She wonders how it would feel to rub his smooth skin and feel them, how strong he must be, able to lift her easily in the air, how hot it would be to rub up against…"
    b_ "No! I can’t think about that! I’m a married woman, for fuck’s sake!"
    scene v10-118
    serv "Will there be anything else, Mistress?"
    b "No, thanks. That’s all."
    scene v10-119
    "She sees him make his way out of the room and can’t help admire his bulky physique."
    "Banu is almost tempted to let him brush against her."

    b_ "Oh, it would be so hot to have him in my house all the time."
    b_ "Have him service me anytime I feel horny."
    b_ "I would have him call me Mistress."
    b_ "Order him to rip my clothes off."
    b_ "Push me down on the bed and have his way with …"
    b_ "What the fuck! I’m doing it again!"
    b_ "I need to stop! I need help!"
    b_ "I’m becoming so indecent!"
    stop music

    scene black with Dissolve(2)
    scene v10-120 with squares
    "The devout woman is plagued by the indecent thoughts she is having increasingly often, and decides to seek God’s direction in a silent prayer."
    scene v10-121
    b_ "Please give me your guidance."
    b_ "Help me get rid of these impure feelings."
    b_ "Give me the strength to resist temptation."
    b_ "Make my soul stronger, so that these lewd cravings will not make me sin."
    scene v10-122 with fade
    "While his beautiful wife is immersed in her fervent quiet prayer, Kamil notices and waits respectfully for her to finish."
    "Yet he wonders if something specific has made her want to pray so suddenly."
    jump kamil_banu_sex2

label kamil_banu_sex2:
    scene v10-123 with fade
    k "How are you feeling, my love?"
    k "Is everything ok?"
    b "Yes, dear."
    k "Mhh, you look a bit weird. You’re flushed. Do you have a temperature?"
    b "No, of course not. I’m fine."
    b "I’m … feeling a bit horny."
    scene v10-124
    play music "audio/sexy.mp3"
    "With that, the shapely lady gets closer to her husband and starts rubbing his bare chest."
    b "Mhh, baby."
    "Kamil is feeling turned on himself. By now, he has got over the new, more open-minded attitude of his wife, and he’s the one taking the initiative this time."
    scene v10-125
    "He pushes her firmly but gently against the wall and begins to feel her up, exploring the soft contours of her slim but curvaceous body."
    k "I’m feeling horny too, baby."
    k "You’re so sexy!"
    k "Do you like my hands on your hot body?"
    scene v10-126
    "She’s in her own little world now, not really able to respond, and Kamil kicks things up a notch, baring her perky breasts."
    "...while insistently rubbing her crotch through the clothes."
    b "Yes, baby. Touch me! I’m on fire!"
    b "Make me feel good!"
    "She is lost to the sensations, caressing her husband’s hair and enjoying his touch, which is sending hot tingles to her clit through the rough material of her jeans."
    scene v10-127 with Dissolve(4)
    "She suddenly has a flashing image which takes her by surprise."
    "Her husband is quickly replaced by the hot servant who has helped her change rooms earlier, and for a moment she loses herself to the impure thoughts she had about him before."
    "She has no control over it but before long flinches at the image, stunned, and the cobwebs are cleared from her brain."
    scene v10-128 with hpunch
    stop music
    "Banu quickly pushes away Kamil and covers up in shame, breathing heavily, still in a daze at the sudden hot image of another man feeling up her pussy."
    k "What’s wrong, sweetie?"
    b "No-nothing. I’m … fine!"
    k "You don’t look OK at all."

    scene v10-129 with fade
    "Banu quickly recovers from the shock and pushes back the thought of the servant, yet she is still horny and flushed."
    k "Well, let’s continue then!"
    b "Yes, baby!"
    b "I need cock! Now!"
    scene v10-130
    "The two lovers make short work of their clothes. Banu is horny out of her mind."
    "Kamil admires his sexy woman undressing, each piece of clothing revealing more of her marvelous and youthful body."
    "His cock, which has lost some of its hardness at his wife’s earlier strange reaction, now stands proud, and he grabs it in invitation."
    k "Come sit on this, sweetie!"
    "Banu directs a blazing stare at her husband, turned on to the max while she is stripping."
    scene v10-131
    "She takes off her jeans and panties in one go, and is too distracted by the throbbing heat of her cunt to even think about removing her hijab."
    "She looms sensually over her husband’s pulsating cock, her juices dripping copiously from her sopped slit."
    b "Yes! I want you, baby!"
    scene v10-132
    "She turns around and straddles Kamil facing his feet. No need for foreplay. She is totally ready to have her tummy filled by that rod."
    "She points it with her hand and sits on it unceremoniously."
    k "Oh, fuck!"
    scene black
    show banukamilmalibusexanimation
    play music "voices/moan2.mp3"

    b "Mhh, yeah! Ahh!"
    "She starts riding in earnest, her tight warm pussy enveloping Kamil’s dick snugly."
    b "Ohhh! It feels so good!"
    b "Let me have it Kamil!"
    k "Ride that cock, precious!"
    k "Squeeze it with your sweet little pussy!"
    b "Ahh! Mhhh!"
    b "Do you like your wife’s tight snatch, baby?"
    b "Mhh?"
    b "Do you like your naughty girl riding you hard, honey?"
    "Spurred by his woman’s words, Kamil starts to respond to her movements and soon they’re moving in sync."
    "His cock is piercing Banu’s tight sleeve, matched stroke by stroke by her own bobbing up and down."
    "Soon, though, it all becomes too much for the frustrated man, and he starts bellowing his oncoming release."
    k "Ohhh! Yeahhhh!"
    k "Fuck, Banu!"
    k "Ohhh, I’m cumming!"
    k "Ride my cock baby!"
    k "Ride me! "
    k "Ohhh! Ahhh! Mhhh"
    scene v10-133 with vpunch
    play sound "voices/man2.mp3"
    stop music
    k "Fuck yeah!!!"
    "Banu is incredulous. She can’t accept the fact that Kamil is already releasing inside her."
    stop sound
    b_ "Oh no! That was too quick! I still have fire in my belly!"
    b_ "What a loser! Nooo!"
    scene v10-134
    "But she doesn’t want to hurt her husband’s feelings and decides to make him believe she is cumming too."
    b "Mhhh, yes Kamil!"
    b "Fill me up! Make me cum!"
    b "Ahhh! Mhhh!"
    b "Yes Yes YEEEES!"
    b_ "No no nooo. I need more, much more than this!"
    b_ "What am I gonna do?"
    b_ "I can’t go on being so horny all the time!"
    b_ "I need release! I need more!"
    $ renpy.end_replay()
    $ persistent.kamil_banu_sex2_unlocked = True
    jump v11
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
