









label banu_mountain_polad:
    $ renpy.block_rollback()




    scene v22-16
    b "Driving you crazy? I thought that was just you trying to act tough. I didn’t know I had that kind of effect on you."
    b "Well, I guess I could just make you suffer a little longer… you know, make you work for it."
    b "Or... I could admit that maybe you’ve been driving me crazy too."
    p "I’m going to fuck you right here, Banu."
    b "Oh, really? And what makes you so sure I’m going to let you?"
    p "Because you want this just as much as I do."
    b "You’re not my husband, Polad. You’re married to Nesrin."
    p "But right now, up here, it’s just you and me. And you can’t deny what’s between us."
    b "So, you think you can just fuck me whenever you want, huh?"
    p "That’s exactly what I think."
    b "You’re awfully confident...but we won't do it here. Someone may come and see us."
    scene v22-17 with vpunch
    stop music
    play sound "voices/ah.mp3"
    b "Ahhhh..."
    "Polad moved swiftly, grabbing Banu by the waist and pulling her body flush against his. She gasped, eyes wide with surprise, but there was no denying the heat between them. "
    "His breath was hot against her ear as he leaned in, his voice a deep, confident whisper."
    p "I know you want it. I know you’re soaking for me right now."
    "She tried to maintain her teasing bravado, but the intensity of his grip, the roughness in his voice, made her knees weak."
    scene v22-18
    p "You’re dying for me to take you, right here, right now."
    "Banu’s resolve melted under his touch, her body betraying her as her core tightened with desire."
    b "Polad..."
    p "Tell me you want me to fuck you."
    "Banu’s breath caught in her throat, the weight of his demand pressing down on her. She couldn’t fight it anymore, the desire burning inside her too strong."
    "Her lips parted, her voice barely a whisper as she admitted."
    b "I do. I want you."
    scene black
    $ renpy.sound.play("voices/ahlong.mp3", loop=True)
    "Polad’s hands gripped Banu firmly as their lips met in a heated kiss, the intensity between them igniting like wildfire."
    "The world around them faded away, leaving only the two of them in the wild, isolated space of the mountains."
    show poladbanuvgfh

    "Polad grabs Banu's hips and starts to thrust his cock into her. Banu lets out a scream of delight as she feels Polad's powerful cock stretch her tight pussy wide open."
    "She begs Polad to keep going, urging him to fuck her harder and faster. As Polad increases his pace, Banu's moans turn into screams of ecstasy."
    "His cock hits her g-spot perfectly, causing Banu to cry out in pleasure."
    b "Ohhhh fuck me Polad."
    p "I'm going to fuck you so hard Banu."
    b "Ohhhh god Polad that's so fucking hot!"
    p "I'm going to destroy you with my cock."
    b "Ohhhh I bet you will."
    p "I bet you'll be begging me to stop."
    b "Ooohhh fuck yes Polad fuck me hard."
    b "Ahhhh fuckk Polad I'm getting close."
    b "Ohhhh fuck I'm about to..."
    scene v22-19 with fade
    stop sound
    play music "audio/sidesex.mp3"
    "Just as Banu's breath quickened, her body trembling on the edge of release, Polad suddenly slowed, pulling back, leaving her teetering on the brink."
    "Her eyes flew open, filled with confusion and frustration, her chest heaving as she tried to steady herself."
    b "Why did you stop?"
    b "Polad, please… put it back in....what do you have in mind?"
    scene v22-20
    "Polad smirked, watching the frustration and need in Banu’s eyes as she trembled beneath his touch."
    "But Polad wasn’t ready to give in just yet. His hand continued its teasing, slow and deliberate as he rubbed her, keeping her on the edge."
    p "Not yet."
    p "I’m going to make you wait, Banu."
    b "Please…"
    p "I want to hear you beg a little more."
    b "I’m begging you, don’t do this to me. I need you—please, just put it back in!"
    p "Not yet, Banu. I want to see just how crazy I can make you first."
    b "I can’t take it, Polad! Please, I’m begging you! I need your big fat cock inside me, right now!"
    scene v22-21 with fade
    "Polad stood up suddenly, his smirk widening as he looked down at Banu, who was still trembling with need."
    p "Get up. I’m going to fuck you at the peak of the cliff."
    "Banu’s eyes widened in disbelief."
    b "Polad, no!...We'll fall...are you crazy?"
    p "We’re not going to fall. You’re just going to trust me. Like you always do."
    b "I’m scared...I don’t want to die, Polad!"
    p "You’re not going to die...But you’re going to feel alive in a way you never have before."
    p "I would never let anything happen to you. Trust me. I’ve got you."
    p "Do you trust me?"
    scene v22-22
    b "Yes. I trust you."
    p "Then let go of the fear."
    b "You’re really going to kill us both, aren’t you?"
    p "I’m going to keep you right on the edge, without falling over."
    b "You’re insane, Polad..."
    b "But I guess if I’m going to die, there are worse ways to go."
    scene v22-23 with fade
    "Polad took Banu’s hand firmly, his grip strong and sure as he began to walk toward the peak of the cliff."
    b "You’re really dragging me up there, aren’t you?"
    p "You said you trust me, remember? Just follow my lead."
    b "You look like a sculpture. Like something out of a myth. Hard muscles, perfect posture... you’re like a living statue."
    p "I didn’t know you were such an admirer of my body."
    b "It’s kind of hard not to notice...You’re like a rock... unshakable."
    p "And your body… it's perfect. Like a model’s. Every curve, every inch..."
    b "A model, huh?"
    scene v22-24
    b "Polad...we’re not really going all the way to the peak, are we? You can’t be serious."
    p "What? Are you backing out now?"
    b "It’s crazy! I thought you were joking!"
    p "I never joke about this."
    b "You’re really not going to stop until we’re at the top, are you?"
    p "No."
    b "Shit..."
    scene v22-25 with fade
    b "Polad! This is insane!"
    b "You’re carrying me up a mountain—what if you slip?!"
    "She clutched onto him tightly, her fingers digging into his body."
    p "I’m not going to slip, Banu. You’re light as a feather. Besides, I’ve got this."
    b "I don’t feel light!"
    b "And we’re so high up already!"
    scene v22-26
    b "Oh my god, Polad, what if a rock breaks loose?! We’ll tumble down like a pair of—of—rolling potatoes!"
    p "Don’t worry, Banu. I’ve been up steeper cliffs than this. You just hold on and enjoy the ride."
    b "Polad, I’m not on a rollercoaster! We’re on the side of a mountain! There’s no seatbelt, no safety net! This is not enjoyable!"
    p "If there were a seatbelt, this wouldn’t be nearly as exciting, would it?"
    scene v22-27
    b "Polad, seriously, let’s just go back. There’s no shame in turning around, right? We could just say we gave it a good try... and we could live!"
    p "Nope, no turning back now. We’re almost there. Besides, you’ll thank me for this later."
    b "I’ll be too busy having a heart attack to enjoy the view! Polad, this is madness."
    b "We could’ve had a nice, normal day—maybe stayed at ground level? Had a picnic?"
    scene v22-28
    p "Just look at this."
    "Banu opened her mouth to say something but couldn’t find the words."
    "Her heart was still racing from the climb, but now it wasn’t fear driving it—it was awe."
    p "Told you. Sometimes you’ve got to take the risk to see something this beautiful."
    b "I can’t believe... how perfect this is."
    b "Even though I thought we were going to die back there."
    p "But we didn’t. We made it. And now we get to enjoy this."
    scene v22-29
    b "I can’t believe we actually did this. You’re absolutely crazy! Do you know how close we were to falling off?!"
    p "But you had fun, didn’t you?"
    b "You’re insane, you know that? But… I guess this was worth it."
    b "You know...I’ve been feeling old lately… like I lost that spark. But after today? You made my body feel young again."
    p "So all it took was a death-defying hike up a cliff to make you feel alive?"
    b "Maybe I needed that extra push... or maybe I just needed someone as crazy as you to remind me that I’m still full of life."
    scene v22-30
    b "But I'm still scared...Don’t put me down. Not yet."
    p "You’re safe, Banu."
    b "I’m not ready to stand on my own just yet. That view is amazing, but also terrifying. Just… give me a moment."
    p "I have to put you down now."
    b "What? Why? What do you have in mind?"
    p "I’m going to fuck you right here."
    "Banu’s breath caught in her throat, and she barely had a moment to process his words before her feet touched the ground and he lifted one of her legs, raising it effortlessly."
    scene v22-31 with fade
    stop music 
    play sound "voices/ah.mp3"
    "She gasped, her pulse racing, her body reacting to the thrill, the fear, and the overwhelming intensity of his words."
    b "Are you insane? We’re right at the edge!"
    "Polad held her steady, his grip firm and reassuring despite the daring nature of his plan."
    p "Right here, at the top, with the world below us. Just trust me."
    b "Polad, this is crazy… what if we fall?"
    p "We’re not going to fall, Banu. I won’t let anything happen to you. You just have to trust me, like you always do."
    scene v22-32
    "Despite her fear, there was something in his voice, in the way he held her, that made her body respond. "
    "She was terrified, yes, but also exhilarated. Her voice was shaky as she whispered back."
    b "You’re going to be the death of me, Polad…"
    "Polad smirked, his hands still steady as he positioned her. "
    scene v22-33 with flash
    play sound "voices/moanfinish.mp3"
    b "Ahhh fuckkkk Polad... I'm coming!!"
    "As Polad's large cock enters Banu, she immediately convulses with ecstasy, her entire body tense with pleasure. "
    "From all the build up, she cums as soon as Polad puts it in."
    p "Damn, you just came from this?"
    b "Ahhh...don't stop....fuck me..."
    show poladbanustandingbjh
    $ renpy.sound.play("voices/ahlongcum.mp3", loop=True)
    b "Ohhhh god yes Polad fuck me!"
    p "I'm gonna make you cum so hard."
    b "Ohhhh fuckk keep going Polad!"
    p "I'm not stopping until you cum."
    p "I'm going to breed you."
    b "Ahhhhh fuck yes Polad!"
    p "I'm going to shoot my seed deep inside your womb."
    b "Yes, fuck me until I am full of your seed."
    p "I'm going to impregnate you and make you carry my child."
    scene v22-35
    b "AAAAAAAAAAAAHHHHH FUCKKKK POLAD THAT FEELS SOOO GOOD!"
    "Banu screams as she reaches the pinnacle of her climax. "
    scene v22-35 with flash
    b "Ohhhh fuckk Polad!"
    "Banu's entire body tenses up, her muscles contracting as she releases herself completely to the moment."
    "She cries out again, louder this time, as she feels the waves of pleasure wash over her. As she cums, she grabs Polad's arm and holds it tightly, her grip almost painful in its intensity."
    scene v22-35 with flash
    p "UGGGGHHHHH FUCKKKKK"
    "With a primal roar, Polad unleashes his load into Banu's pussy. "
    "As he does so, he feels an overwhelming sense of satisfaction and accomplishment. He lets out a moan, emptying himself into Banu's body."
    "As Polad cums, he lets out a deafening roar, his voice echoing throughout the valley below. The sound resonates deeply within the earth itself, making the very ground beneath them tremble with power."
    scene v22-34 with flash
    stop sound
    play sound "voices/man5.mp3"
    "Suddenly, with a guttural groan, he explodes in a torrent of ecstasy, shooting his hot, sticky load deep into Banu's waiting pussy."
    "Polad's cock slips out of her pussy, filling her pussy with his warm, sticky load."
    "He cums with a powerful explosion, shooting his hot, gooey seed deep inside her."
    "As he withdraws, he sees that his seed is dripping from Banu's pussy onto his cock."
    stop sound
    scene v22-36 with fade

    play music "audio/romantic.mp3"
    b "You came inside me...What if I get pregnant?"
    b "Polad... you’re not serious about wanting to get me pregnant, are you?"
    p "Maybe I like the idea of putting a baby inside you."
    b "You’re crazy...You really want to knock me up?"
    p "The thought of you carrying my baby… it’s hard to explain, but it feels right. Doesn’t it?"
    b "Polad, you’re married to Nesrin...How can you even say that?"
    p "I’ve thought about it more than I should, but the idea of you… carrying our child, it’s something that feels right in a way I can’t explain."
    p "But if it happens… I won’t regret it. I’d want it. I’d want you. I’d want us."
    b "Let’s go down. This place is… it’s dangerous."
    p "We’ll go down. No need to stay up here any longer."
    scene v22-37 with fade
    "Banu gasped, startled at first by the sudden movement, but quickly settled into his embrace, her arms wrapping around his neck instinctively."
    b "Polad, you don’t have to carry me."
    p "You’ve been through enough up here. Let me take care of you."
    b "You always know how to make me feel safe."
    p "You don’t have to worry about anything. I’ve got you."
    scene v22-38
    b "You know, you carrying me down like this… it’s kind of cliché. The knight in shining armor saving the damsel in distress. A bit much, don’t you think?"
    p "I’m just making sure you don’t start complaining about your legs hurting halfway down. I’m saving myself from your complaints, really."
    b "You’re just looking for excuses to show off those muscles of yours."
    p "And it’s working, isn’t it?"
    b "But don’t get too cocky. I’m still deciding if I should let you be my knight in shining armor or just the crazy guy who dragged me up a cliff."
    p "But honestly, I think you’re the one who’s stronger. You survived that insane climb. I’m just here to make sure you don’t fall on the way down."
    scene v22-39 with fade
    "Polad and Banu lay on the very edge of the cliff, their bodies completely relaxed against the smooth, cool stone. "
    "Below them, the valley stretched out like a living tapestry, the vastness of the world so far beneath them. "
    "The wind whispered around them, carrying the distant sounds of nature, yet it felt like they were in their own world, suspended above everything else."
    scene v22-40
    "Banu let out a long breath, her head resting on Polad’s chest as she gazed out at the horizon."
    "For a while, they lay there, side by side on the edge of the world, the future uncertain but the present perfect in its simplicity."
    scene v22-41 with fade
    b "You know, this is... breathtaking...I don’t think I’ve ever felt this alive."
    p "I told you it’d be worth it, didn’t I?"
    b "You also almost gave me a heart attack...but you were right."
    b "Being up here with you, seeing all this... it makes everything else feel so small. Like all the worries don’t matter for a moment."
    b "I don’t know if I should be scared of you or impressed."
    p "A little fear and a lot of admiration. That sounds about right."
    b "Do you ever think about what’s next?"
    b "I mean... after this? After everything?"
    p "Right now, I’m just focused on the moment. On being here, with you."
    scene v22-42
    p "I was just wondering... how does it feel when I fuck you?"
    b "Seriously?"
    b "You’re really asking that now?"
    b "You want to know what it feels like?"
    p "Yes."
    b "It’s so hot....You drive me crazy. It’s like... every touch, every kiss, sets my whole body on fire."
    b "You’re so full of yourself...But... I’m not wrong. You know exactly what you’re doing."
    p "And you like that?"
    b "More than you know."
    p "How about my cock? Do you like it."
    b "Your cock is so meaty and big...Sometimes I'm scared that it's going to kill me..."
    b "It reaches so deep spots...God...it makes me crazy..."
    scene v22-43
    p "Would you want me to fuck you in the ass?"
    b "It's good that if you fuck me in the ass, there is no chance that I could get pregnant."
    b "I-I don't know if I can handle this...your cock is so big for my tiny asshole."
    b "It would destroy my hole...no thanks I won't take this."
    p "So, Banu... what is it that you like most when we fuck like rabbits?"
    b "You really want to know?"
    p "I'm all ears."
    b "It’s when you lose yourself completely... when you roar like a lion while you cum inside of me, and those strong, powerful... thursts of yours."
    p "So, Banu... do you really think those thursts are my best? My top speed?"
    b "Of course not. I know you’re holding back. If you went full speed, I’d probably lose my mind."
    p "Oh, so you’ve noticed, huh? Maybe I’m saving that for when you can handle it."
    p "Maybe. Or maybe I’m just waiting for the right moment to show you what I’ve really got."
    b "I’ll be waiting, then. But don’t blame me if I beg for mercy."
    scene v22-42
    p "You were religious once, right? Is it... haram? You know...getting fucked in the ass."
    b "I used to be... different. I followed rules, I wore my hijab, and I never questioned what was considered right or wrong."
    b "Back then, I would’ve said yes, that it’s haram."
    p "Do you still believe in God?"
    b "I do. I don’t follow everything the same way I used to, but... I still believe."
    b "And you? Do you believe in God?"
    p "Not in the way most people do. But I do believe in something… something bigger than us. A force that created everything we see and everything we are. People call it God."
    b "So, you believe there’s something... just not the way I do?"
    p "Yeah, I guess you could say that. I don’t think there’s one book or one set of rules that explains it all."
    p "But when I look at the world—how perfectly everything is connected, the way life forms, the way nature works—there’s something behind it all. Something powerful."
    p "Have you ever thought about... having more children?"
    b "I mean... yes, I’ve thought about it. Why?"
    p "Would you... ever want to bear my child?"
    b "I don’t know, Polad."
    b "I don’t even know what my life is right now, let alone the idea of bringing a child into it."
    b "You really don’t know how naughty Leyla can be."
    p "Naughty, huh? What’s she like?"
    b "She’s full of energy, always getting into things she’s not supposed to, and she’s stubborn like you wouldn’t believe."
    p "Sounds like she takes after her mother."
    b "I just want her to be happy....not like me."
    p "What is it about you?"
    b "I feel like... a slut, Polad. Here I am, fucking a married man on the side of a mountain. It feels wrong, like I’m losing myself."
    p "You are not a slut. Don’t ever think that about yourself."
    b "But how can you say that? Look at what we’re doing... this isn’t right, not when you’re married to Nesrin."
    p "I know it’s complicated. I know this isn’t easy. But what’s happening between us... it’s real. "
    b "But what about...Alper..."
    p "I think that you love me as much as you loved Alper."
    p "If you had to choose… between me and Alper, who would it be?"
    b "Why would you ask me that?"
    p "I know how much Alper meant to you. I was his best friend, and I saw how much you loved him."
    p "I guess... I just need to know if there’s any part of you that would still choose him over me."
    p "So tell me."
    b "Part of me will always belong to him, Polad. But that doesn’t mean I don’t have room for you too."
    scene v22-44
    play music "audio/sensual.mp3"
    play sound "voices/moan3.mp3"
    b "Ahhh...Polad...please.."
    p "Answer me."
    b "Alper... he was gentle, loving. He gave me stability when I needed it most. But you... you’re different. "
    b "You make me feel alive in a way I didn’t even know I needed."
    "Polad didn’t stop. His tongue grazed the sensitive curve of her neck, and in that instant, it was like a spark ignited within her."
    p "Tell me, Banu..."
    stop sound
    p "Tell me I’m what you need. That I’m better for you than he was."
    b "You’re different. He gave me something I needed then... but you... you’re everything I need now."
    scene v22-45
    p "You need me more than you needed him."
    b "I loved Alper, but this—what I feel for you—it’s different. It’s deeper in a way I can’t explain."
    p "Tell me who fucked you better? Me or Alper?"
    b "Polad...please..."
    scene v22-46
    b "Ahhhh..."
    b "Alper was softer...and...and gentle in bed...but you...you are the beast, Polad..."
    b "If you keep doing that, I swear I’m going to forget how to speak!"
    p "I like seeing you like this, speechless."
    b "But if I lose my voice completely, you’ll be the one who has to explain things to Leyla."
    p "I’ve given you the world. Now it’s time for you to return the favor."
    b "And what exactly do you think I owe you, Mr. World Giver?"
    p "Just... maybe letting me see you lose yourself a little more."

    menu:
        "Kiss him":
            $ renpy.block_rollback()
            $ banusuckpoladcockmountain = False
            $ renpy.sound.play("voices/kissing.mp3", loop=True)
            scene v22-47 with fade
            "When her tongue finally met his, the spark was immediate. The kiss deepened, their breaths mingling as they lost themselves in the heat of the moment."
            "Polad’s hands gripped her waist, pulling her closer, and Banu felt the world around them disappear."
            "All that mattered was him—his touch, his warmth, the way his body felt against hers."
            p "Every time you kiss me like this... I lose control."
            p "I can’t get enough of you."
            b "Then don’t stop."
            scene v22-48
            "Polad didn’t need to be told twice. He kissed her again, more urgently this time, their tongues tangling as they lost themselves completely in the moment."
            "And as they kissed, they both knew that this was more than just desire—it was something real, something powerful."
            p "You drive me crazy."
            "Their tongues danced together, slow and deliberate at first, but quickly building in intensity as the hunger between them grew."
            "She kissed him harder, pouring everything she felt into the moment—her desire, her longing, the overwhelming connection she couldn’t deny."
            "Polad’s grip tightened, his hands exploring her back as their kiss deepened further. He pulled away just long enough to look into her eyes, his breath heavy."
            stop sound
            stop music
        "Suck his cock":



            $ renpy.block_rollback()
            $ banusuckpoladcockmountain = True
            scene v22-49 with fade
            "Banu looks at Polad, knowing exactly what she needs to do to please him. She steps forward, her movements graceful, and kneels before him."
            b "Are you ready for the ultimate blowjob?"
            p "What? Are you planning to suck my dick?"
            scene v22-50
            p "You were such a religious pure woman and now you're going to dirty your mouth with my dirty cock?"
            b "You're right, I used to be religious. But I've changed my ways. Now I worship your cock."
            b "I can't fight the temptation of your cock. Once I saw it, I knew I had to have it."
            scene v22-51 with fade
            $ renpy.sound.play("voices/softmoan.mp3", loop=True)

            p "You really are into this aren't you?"
            b "Your cock smells like heaven...Even though it's covered in dirt and sweat, it still smells amazing."
            "Banu leans in closer to Polad, pressing her lips against his balls as she inhales deeply, taking in the full scent of his masculinity."
            b "Mmmm this is such a turn on..."
            scene v22-52
            "Banu grunts as she licks Polad's cock, unable to resist the intoxicating aroma."
            "She moans with pleasure, relishing the taste of his salty pre-cum mixed with the earthy scent of his balls."
            b "I've never given Kamil or Alper a blowjob..."
            scene v22-53
            "Her mind reeled with anticipation as she contemplated the immense pleasure she would receive from taking it inside her mouth."
            b "Oh god, that's so fucking big. Just imagining it inside my mouth makes me wet."
            p "Tell me how bad you want it."
            b "Oh I want it so bad...I can't stand the strong scent of you, Polad."
            p "Just suck it. Suck my cock."
            scene v22-54 with fade
            stop sound
            "Banu takes Polad's massive cock in her mouth, wrapping her tongue around the tip as she licks it slowly."
            "She slides her tongue along the shaft, taking it deeper into her mouth. She massages it with her cheeks, moving her jaw muscles to work the cock as she takes it further."
            p "Suck my cock and swallow my load, you dirty little slut."
            "Banu hears Polad say dirty words and she blushes slightly, feeling a thrill run through her body. She increases her speed, moving her tongue along the shaft with renewed vigor. "
            scene v22-55
            b "Your cock is so dirty...Don't you wash it often?"
            b "Mmmmm...but you know...I like it...."
            b "Mmmm...this smell...it makes me crazy..."
            show banusuckdxfd
            $ renpy.sound.play("voices/suckdick.mp3", loop=True)

            "Banu giggles as she continues to suck Polad's cock, her tongue dancing along its length."
            b "Your cock smells like heaven, baby. Like the purest essence of masculinity distilled into one delicious package."
            "Polad groans with pleasure as he feels his cock fully engulfed by her warm, wet mouth."
            p "Take all of it, Banu. Suck my dirty dick."
            p "That's it baby, keep going. Keep sucking my smelly cock until I cum."
            p "Eat my cock until I fill your mouth with hot sticky jizz."
            "Polad's cock thrusts forward, hitting the back of Banu's throat. He groans loudly, overcome with pleasure."
            p "Now, Banu, show me what a dirty little slut you are. "
            p "Take every inch of my cock and make it yours."
            "Polad's cock presses against the roof of Banu's mouth, causing her to gag. But she doesn't stop there."
            "Instead, she pushes her tongue against the underside of his shaft, determined to take him completely. She speaks muffled words around his cock."
            b "Cum in my mouth, Polad. Fill me up."
            p "Just like that...Suck it....Show me how much you want me."
            p "Ohhh shit...."
            scene v22-56 with vpunch
            stop sound
            play sound "voices/man5.mp3"
            p "Ohhhhh...shit..."
            "Polad's cock erupts in a torrent of hot sticky jizz, filling Banu's mouth with warmth and flavor."
            "She swallows it hungrily, wanting more of Polad's delicious nectar."
            p "That's it, Banu...take my cum."
            b "Mmmm..."
            stop sound
            scene v22-57 with fade
            "As Banu finishes swallowing Polad's load, she smiles radiantly."
            "Cum drips down her lips, leaving behind a trail of evidence of her encounter with Polad's cock."
            b "You filled me up so nicely Polad..."
            b "Your cum...it tastes so good...it's too delicious."
            b "Is this what you wanted?"
            p "More than you know..."

    scene v22-58 with fade
    stop music 
    stop sound    




    $ renpy.end_replay()
    $ persistent.banu_mountain_polad_unlocked = True
    jump banu_mountain_polad_continue














label banu_natasha:
    $ renpy.block_rollback()





    scene v22-101
    b "What do you want, Natasha?"
    nat "Nothing much. Just checking on things. Polad does trust me, you know. Said I should keep an eye on his... prized workers."
    b "If you're here to cause trouble, you can save yourself the effort. I'm not in the mood for your games."
    nat "Oh, Banu, don’t be so uptight. It's just funny watching you try so hard."
    nat "What is it? Missing Polad already?"
    scene v22-102
    play music "audio/suspense.mp3"
    b "Whatever you think you know, Natasha, I suggest you keep it to yourself. "
    b "This bar might not be big enough for the two of us if you keep poking your nose where it doesn't belong."
    nat "Oh, sweetheart, I know everything. But let me tell you something, Polad isn’t the type to stick with just one."
    b "You walk around here acting like you’re some queen, but let’s talk about your boyfriend, shall we?"
    b "Sasha, wasn’t it? The big, tough man who’s so ‘devoted’ to you?"
    b "Just wondering how it feels to know your boyfriend’s basically a cuck. I mean, does Sasha know how often Polad fuck up your ass?"
    nat "You don’t know what you’re talking about."
    b "Please, Natasha, everyone can see it. Polad uses you, and Sasha just sits there like the pathetic little man he is, letting his girlfriend spread her legs for someone else. "
    b "It’s honestly embarrassing."
    scene v22-103
    nat "You better watch your mouth, Banu."
    b "Or what? What are you going to do, Natasha? Run crying to Polad? Or maybe to Sasha? Oh wait, he probably wouldn’t care."
    nat "You want to talk about pathetic lives?"
    nat "Honey, let’s take a little stroll down your memory lane, shall we?"
    nat "You used to parade yourself around as this sweet, pious little thing, wearing your hijab like some holy crown."
    nat "And now look at you—strutting around Polad’s bar like some cheap dime-store version of me, your head uncovered, your morals gone."
    nat "What happened, Banu? Did you toss your faith out the same way you tossed your panties to Polad?"
    nat "Your deceased husband’s best friend. That’s right—Alper, the man you supposedly loved and mourned."
    nat "I bet he’s rolling in his grave watching his widow spread her legs for his closest buddy."
    b "Shut the fuck up."
    nat "Do you think that’s what he wanted for you? To turn into a backstabbing, husband-stealing little bitch?"
    nat "You want to call out my relationship with Sasha? At least I’m honest about what I do. You’re here playing house with Polad, acting like you’re the victim, but you’re no better."
    nat "What’s the excuse, Banu? ‘Oh, I’m lonely, I need love’? Please. You’re nothing but a homewrecker."
    nat "A sad little woman who couldn’t keep her husband alive and now tries to fill the void by crawling into someone else’s bed."
    nat "I know that you are just a slut, Banu. It's in your blood. You can't change yourself. "
    nat "But I like that slut inside of you..."
    "The intensity of Natasha’s gaze, the way her lips curled into a smirk, and the defiant tilt of her head—there was something about it that made Banu’s skin tingle in a way she couldn’t explain."
    scene v22-102
    "Banu’s lips parted slightly as if to speak, but no words came out. Instead, she took a slow step forward, her anger now mingled with something raw and unspoken."
    "Natasha noticed the change and stood straighter, her smirk fading as her breath quickened."
    b "What are you doing?"
    nat "Shut up."
    nat "You talk too much."
    b "You started it."
    nat "Maybe I did...And maybe I want to finish it."
    scene v22-104 with fade
    play music "audio/sexy.mp3"
    "Natasha let out a muffled moan into Banu's mouth as their tongues met, wet and desperate."
    "The slick sound of their kisses echoed in the quiet room, hot and messy, each movement dripping with lust."
    b "You’re such a filthy slut, letting Polad have you whenever he wants."
    nat "Oh, like you’re innocent, Banu? Fucking your dead husband’s best friend like some horny widow in heat."
    scene v22-105 with fade
    $ renpy.sound.play("voices/kissing.mp3", loop=True)
    "Natasha's hands slid down Banu's sides, fingers tracing the curve of her hips as she pressed their bodies closer."
    nat "You taste like trouble, Banu. No wonder Polad can't stay away."
    "She smirked against Natasha's mouth, whispering back."
    b "You think you’re so irresistible, don’t you? Polad might have had you, but right now, you’re mine."
    nat "Oh, I know I’m yours right now. But are you ready to handle me, you little tease?"
    scene black
    "Banu suddenly grabbed Natasha’s wrist and spun her around, pinning her against the rough brick wall with surprising force."
    b "You think you’re in charge here? I'll fuck you right here, you little bitch."
    "Without warning, Natasha grabbed Banu's skirt and pulled it down, revealing her firm, toned ass."
    scene v22-106 with dissolve
    b "You think you can turn the tables on me? You’ve got some nerve, Natasha. "
    nat "And you’ve got a body that’s begging to be touched. Admit it, you love how my hands feel on you."
    b "Says the girl who’s been teasing me all night. Don’t act like you’re not enjoying this."
    nat "Shut up and come here!"
    scene v22-107
    b "Ahh... god... you’re making me crazy.."
    nat "Muah... mmm... ahh, Banu... you’re... mmm... insane"
    b "Shhh... mmm... muah... you talk too much.."
    "As their lips locked in another deep, passionate kiss, the heat between them grew unbearable. "
    b_ "What the hell is happening to me?"
    b_ "I’m getting wet… from kissing her. From her moans, her body pressed against mine. It’s driving me crazy."
    b_ "Her lips... they’re so soft, so addictive. I can’t stop... I don’t want to stop."
    nat "Ahh... oh god, Banu, you’re... ah... making me... mmm..."
    b "Mmmf... haah... uh... I can’t..."
    b "Mmm... ahhh... yeah... just like that."
    nat "Ahh... mmph... ohhh, Banu... I can’t... mmm... stop... ahhh."
    nat "Ahh... haah... mmm... you’re crazy... ahhh... Banu... I—"
    stop sound
    scene v22-108 with fade
    $ renpy.sound.play("voices/moan2.mp3", loop=True)
    "Natasha smirked against her lips, sensing the shift in power."
    "Without hesitation, Natasha’s hand slid down Banu’s body, her fingers trailing over the curve of her hips before boldly slipping between her thighs."
    b "Ahhh...what are you doing..."
    nat "Look at you...So wet, Banu. You act all tough, but your body is begging for this."
    b "Ahh... mmm... stop... I-I can’t—"
    nat "Stop? Oh no, darling..."
    nat "Is this what you call a pussy, Banu?"
    nat "It’s so messy, so wet, and all for me? You’re supposed to be the strong one, but look at you. You’re falling apart like a little slut."
    b "Shut... shut up, and rub my pussy, you bitch...don't stop..."
    nat "Oh well...."
    nat "This pussy of yours? It’s pathetic. You’ve been pretending to be so strong, so tough, but all it takes is my fingers, and you’re already dripping like a desperate little thing."
    b "Oh yes...I'm a bitch...this...this feels so good, please don't stop...ahh..."
    b "Ahhh... Natasha... I can’t—ahhh! Oh my god!"
    nat "Fall apart for me, Banu. Show me how weak this pussy really is."
    b "Oh... oh my god... Natasha!"
    "Natasha smirked, watching Banu lose herself."
    "Banu’s entire body shook as the orgasm tore through her, her breaths coming in short, ragged gasps as she clung to Natasha for support."
    b "Natasha... ahhh! Oh my god... oh god... I’m—ahhh!"
    stop sound
    scene v22-109 with vpunch
    "Banu, still trembling from the intense aftermath of her release, suddenly grabbed onto Natasha’s waistband, her fingers curling into the fabric of her shorts."
    "Without a second thought, she yanked them down with a rough, almost desperate motion, exposing Natasha completely."
    nat "Banu! What the hell are you doing? We will get caught here."
    b "You think you can tease me like that and get away with it?"
    b "You wanted to push me, didn’t you? Well, now I’m going to show you exactly what happens when you mess with me."
    b "Now get on the ground..."
    scene v22-110 with fade
    "Without a word, she dropped to the ground, sitting back and spreading her legs wide..."
    "She leaned back on her hands, her eyes locked on Natasha with a fiery intensity."
    b "If you think you’re so good, Natasha, prove it. Eat me."
    nat "You’re really something, Banu."
    nat "You’re practically dripping for me...It’s like your body’s begging for me."
    b "Stop talking and get to it, I don't have all night."
    scene v22-111 with vpunch
    "Without warning, she buried her face between Banu’s legs, her tongue and lips attacking her pussy with raw, animalistic hunger."
    "Banu let out a sharp, high-pitched cry, her body jolting as Natasha’s movements became fast, aggressive, and relentless."
    b "Ahhh! Natasha—oh my god!"
    b "What are you... ohhh, fuck!"
    "Natasha didn’t hold back, her tongue swirling and flicking against Banu’s clit with precision, her lips sucking hard as she devoured her like she couldn’t get enough."
    "The wet, sloppy sounds of Natasha’s mouth echoed in the room, mixing with Banu’s desperate moans and cries."
    "Banu’s thighs instinctively pressed together for a moment, but Natasha’s firm grip kept them spread wide."
    nat "Don’t you dare close these legs..."
    scene v22-112
    play sound "voices/moan4.mp3"
    b "Ahhh! Ohhh... Natasha! Oh god! AHHH!"
    "Banu’s entire body convulsed, the overwhelming intensity of Natasha’s tongue sending her spiraling into a realm she’d never experienced before."
    "Her head fell back against the floor, her chest heaving as she tried and failed to catch her breath."
    "Her eyes fluttered, then crossed as wave after wave of pleasure coursed through her, completely obliterating her thoughts."
    b "Natasha... ahhh! I... I can’t—ohhh! It’s too much!"
    b "Ohhhh—AHHHH! Natasha! Oh my god! Ohhhhhh!"
    b "Ahhh! OH GOD! Natasha, I’m—I’m... ahhhhh!"
    stop sound
    scene v22-113
    nat "Look at you—losing your damn mind."
    nat "You taste so fucking good. I could stay down here all night, you know that?"
    b "Ahhh! Natasha... stop talking... ahhh!"
    nat "You don’t want me to stop. You love hearing me tell you how pathetic you look, how desperate you are for me."
    nat "Look at you, Banu. Screaming my name like a desperate little girl. You’ve got no control, no power. You’re just a—"
    scene v22-114 with vpunch
    "Natasha yelped, her eyes widening in surprise as Banu climbed over her..."
    nat "Ohhhhh...shit..."
    b "You think you can talk to me like that?"
    b "You think I’m just going to take it? No. Now it’s your turn to lose control."
    "Natasha’s pussy was already glistening, her arousal undeniable. Banu smirked."
    scene v22-115
    b "Look at you..."
    b "Talking all big, but you’re soaking wet. You’re just as desperate as I was. Let’s see how smug you are when I’m done with you."
    "Before Natasha could retort, Banu dove down, her tongue dragging a long, slow lick over Natasha’s dripping folds."
    scene v22-116
    play sound "voices/moanfinish.mp3"
    nat "Ahhh! Banu! Ohhh, fuck!"
    b "Not so tough now, are you?"
    nat "Banu! I... ohhh! Stop—ahhh! Fuck, don’t stop!"
    b "I’m going to make you scream, Natasha. Louder than you made me."
    nat "Oh my god! Banu! Ohhh... I can’t—I’m going to—ahhh! "
    nat "Ohhhh! Banu! I can’t—ahhhh! It’s too much!"
    "When the waves finally began to subside, Natasha collapsed back onto the floor, her chest heaving, her skin slick with sweat."
    scene black with dissolve
    "Banu smirked as Natasha lay collapsed on the floor, her chest rising and falling as she struggled to catch her breath. But Banu wasn’t done."
    scene v22-117 with dissolve
    b "You think I’m finished with you?"
    b "Not even close."
    nat "Banu... wait—ahhh!"
    show natbanunmbh
    $ renpy.sound.play("voices/longhardmoan.mp3", loop=True)
    b "I’m going to ruin you, Natasha. You’re going to feel me everywhere."
    nat "Ahhh! Oh my god! Yes! Yes!"
    nat "Don’t stop! Banu, please—ahhh!"
    nat "I want you, Banu! Oh god, you’re... you’re driving me insane—ahhh!"
    b "Ahhh! Oh god, Natasha!"
    b "You feel... ohhh... you feel so good... I can’t... ahhh, I can’t stop!"
    nat "Banu! Fuck, you’re... ohhh... you’re driving me insane! You have such a bad pussy."
    b "You’re... ohhh, you’re mine now, Natasha. Say it... ahhh, say you’re mine!"
    nat "Ahhh! Yes! Yes, Banu, I’m yours!"
    b "You’re... ohhh... you’re the one who started this, Natasha... ahhh... now take it! Take all of me!"
    stop sound
    scene v22-118
    "As their slick, wet bodies moved together in perfect rhythm, the intensity between Banu and Natasha reached its peak."
    b "Ahhh! Natasha!"
    nat "I’m... oh god, I’m so close... I can’t... ahhh, I can’t hold it!"
    nat "I’m right there... ahhh, don’t stop! Don’t you dare stop!"
    b "You’re going to make me... ahhh... lose my mind, Natasha. I can’t take it anymore!"
    scene v22-119 with hpunch
    stop sound
    stop music

    cus "Hey! Where’s my damn beer? What kind of service is this?"
    "Just as their bodies tensed, ready to shatter into blissful release, a loud, angry voice boomed from the other room."
    "The words hit like a bucket of ice water. Banu froze, her body jerking back as her eyes flew open."
    b "Oh my god!"





    $ renpy.end_replay()
    $ persistent.banu_natasha_unlocked = True
    jump banu_natasha_continue














label guys_banu:
    $ renpy.block_rollback()








    scene v22-127
    guy2 "What’s your name? I don’t think we ever got that back at the club."
    b "I don’t make a habit of sharing personal information with customers.."
    scene v22-126
    guy1 "But you’re not just any bartender, are you? There’s something about you... I can’t quite put my finger on it."
    scene v22-128
    b "I’m just here to do my job. If you’ve got a problem, take it up with Polad."
    guy1 "Polad, huh? Big guy, lots of attitude. Must be a handful."
    guy1 "But enough about him. What about you? A woman like you—strong, confident—you must have a story. You’re not the type to get lost in the background."
    menu:
        "Banu is angry":
            $ banuflirtwihguysbar = False
            $ renpy.block_rollback()
            play music "audio/action.mp3"
            "Banu’s irritation reached its boiling point. She’d had enough of their smug smirks, their sly comments, and the way they looked at her like she was some kind of prize to be won."
            scene v22-131
            b "Alright, I’ve had enough of your bullshit."
            b "You think you can sit here, acting all smug and clever, like I don’t see exactly what you’re trying to do?"
            b "You think it’s fun to come in here after what happened at the club, after Polad had to deal with your sorry asses?"
            b "You’re lucky you’re even walking right now."
            guy2 "Whoa, no need to get so worked up—"
            scene v22-132
            b "You’re damn right I’m worked up! Polad kicked your asses once, and if you don’t get out of here right now, I’ll make sure he does it again. Only this time, he’ll finish the job."
            b "And if you even think about causing trouble here, Polad won’t just kick your asses—he’ll fuck them so hard you won’t sit right for a week."
            scene v22-133
            "The taller man opened his mouth to say something but quickly thought better of it, clamping his lips shut."
            b "Now get out.."
            b "And don’t let me see your faces here again."
            scene v22-134
            b "You walk in here with your bruises and your bullshit, thinking you’re some kind of hotshot. "
            b "But the only thing hot about you is probably the STD your whore of a mother passed down to you."
            guy1 "What the fuck did you just say?"
            b "You heard me.."
            guy1 "Anyway, you're not worth it."
            b "Tell that to your mom, who probably taught you everything you know about being a useless piece of shit!"
            scene v22-135 with fade
            stop music
            "Banu leaned against the bar counter, arms crossed and a smug smile curling her lips."
            "She had just sent those losers packing with their tails between their legs, and damn, it felt good."
            b_ "Idiots thought they could walk in here and mess with me..."
            b_ "Polad would’ve turned them into minced meat, but nah, I didn’t even need him. Handled it like a boss."
        "Banu is flattered":



            $ banuflirtwihguysbar = True
            $ renpy.block_rollback()
            scene v22-128
            b "You guys really know how to make a girl feel special, huh?"
            guy1 "Only the best for the most beautiful bartender in the city."
            b "Is that so?"
            b "And here I was thinking you two were just troublemakers."
            guy2 "Maybe we are, but we know how to treat a lady right, too."
            guy2 "So, what's a girl like you doing in a place like this?"
            scene v22-129
            b "Trying to resist temptation."
            guy2 "Maybe just this once, temptation could be a good thing."
            guy2 "You know, Banu, it’s a shame a woman as stunning as you is stuck behind this bar. You should be out there, turning heads, breaking hearts."
            b "Oh, is that so? And here I thought you were just here for the beer."
            guy2 "We came for the beer, but we stayed for the view. And honestly, Banu, this view? It’s damn beautiful."
            scene v22-130 with fade
            "The moment Banu stepped into the back room to grab the beers, the two men exchanged sly smirks, their demeanor shifting from playful to predatory."
            guy1 "Won’t take much to push her over the edge."
            guy2 "Yeah, she’s been playing coy, but trust me, by the end of the night, she’ll be begging for it. All we gotta do is keep that charm turned up, and she’s ours."
            guy1 "Nah, tonight we’re gonna break her in. That tight little ass of hers… she won’t even know what hit her."
            guy2 "Yeah, by the time we’re done, she’ll forget all about that Polad guy. She’ll be too busy screaming..."
            scene black with dissolve
            "As the men drained the last drops of their beers, they exchanged a knowing glance before rising from their seats."
            scene v22-136
            play music "audio/weakbanu.mp3"
            "Slowly, deliberately, they approached the bar counter where Banu stood, her figure bathed in the soft glow of the dim lights."
            "She was busy wiping down a glass, her mind distracted, still flustered by her own overwhelming emotions and the lingering heat from earlier."
            scene v22-137
            guy1 "You know, Banu, it’s almost unfair how good you look tonight."
            guy1 "Got every man in this room watching you, but here we are, the lucky ones who get to talk to you."
            b "Oh, stop. I’m just doing my job. Don’t make it a big deal."
            guy1 "Your job, huh? Don’t act like you don’t enjoy the attention. Bet you get off on it, don’t you? Knowing every guy here is wishing they could touch you."
            scene v22-138
            "She froze for a moment, her breath catching in her throat."
            "The proximity of their bodies, their hushed tones, and the intensity of their stares were starting to unravel her composure."
            "The taller one leaned in even closer, so close she could feel his breath against her ear."
            guy1 "I wonder what Polad would think if he saw you right now, soaking up every word we say. You like this, don’t you?"
            guy1 "Being the center of attention. Bet you’re feeling it right now, aren’t you?"
            "As Banu stood at the counter, the heat between her thighs was unbearable, a lingering flame ignited from her earlier encounter with Natasha."
            scene v22-139
            "Her body was betraying her, and no matter how hard she tried to compose herself, the burn wouldn’t subside. "
            "She tried to keep her voice steady, but a soft moan escaped her lips as she answered the taller man’s flirtatious remark. "
            b "You...you think I look good tonight?"
            guy1 "Good? That’s an understatement, Banu. You’re a fucking goddess standing behind this bar."
            guy1 "I don’t know how Polad lets you work here without keeping you locked up. If you were mine, I’d never let anyone else look at you."
            b "Maybe...Polad knows I’m not so easy to tame."
            scene v22-140
            guy2 "Not easy, huh? I like a challenge. But I think we both know you’d eat a guy alive if you wanted to. Am I wrong?"
            "Banu couldn’t help herself—her tongue darted out to wet her lips, her pulse racing."
            b "You think you could handle me?"
            guy2 "Handle you? Oh, sweetheart, we’re not here to handle you. We’re here to see if you can handle us."
            guy2 "God, you’re so worked up, aren’t you?"
            guy2 "Bet you can barely think straight, can you? Bet you’ve been dying for someone to take care of that...little tight pussy, huh?"
            "Banu’s knees felt weak, and her hand gripped the counter for support."
            "Her breathing quickened as she bit her lip, her body responding to their words despite the warning bells ringing in her head."
            scene black with dissolve
            "After some time, Banu found herself cornered in the dingy backstreet, the cold air doing little to cool the fire burning inside her."
            scene v22-141 with fade
            "The two guys were smooth, way too smooth. Their voices were low and dirty, dripping with charm as they kissed Banu in the car.."
            scene v22-142 with dissolve
            "Banu tried to play it cool, but damn, her heart was pounding, and her legs felt weak. She couldn't stop herself from being taken."
            "One of them placed a hand on her hip, pulling her in, his other hand lightly brushing her arm, testing the waters."
            scene v22-143 with fade
            b "Mmm… ahh… ohhh…"
            guy1 "Damn, you taste so good..."
            "Their movements were aggressive but controlled, each one taking turns to kiss her neck, her lips, and her jawline, leaving a trail of heat wherever they touched."
            guy2 "You like trouble, don’t you?"
            b "Mmm… ahhh… oh my god."
            b "Ohhh, fuck… mmm… ahh… I can’t… ohhh!"
            guy1 "Let’s take this outside..."
            scene v22-144 with dissolve
            "Out in the cool night air, the three of them were wrapped in each other again, their passion spilling over into the secluded alleyway."
            scene v22-145 with dissolve
            "Their lips were everywhere, wild and unrelenting, as if they were starving and Banu was the feast. "
            "Their kisses turned ravenous, sucking, biting, licking, like predators claiming their prey."
            b "Ahhh… mmm… you’re driving me insane…"
            scene v22-146
            b "God… ohhh yes… more, please… ahhh…"
            "As their mouths ravaged her breasts, Banu could feel the intensity ratcheting up. "
            "The heat from their hungry lips and the sharp, sweet pressure on her nipples sent waves of arousal surging through her."
            b "Fuck… yes, just like that…"
            scene v22-147
            b "Oh god, you're both so… fuck…"
            "The sight of their ready, big, fat cocks made her heart pound even harder."
            scene v22-148
            b "Goddamn....You two are packing like you’re trying to outdo each other."
            b "Thick as hell and hard… holy shit. How the fuck do you even walk around with these monsters?"
            b "Damn, you’ve both got cocks that could ruin a girl. It’s almost unfair... almost...ahhh.."
            b "Guess I’m the lucky one tonight, huh?"
            scene v22-149 with fade
            stop music
            $ renpy.sound.play("voices/suckdick.mp3", loop=True)
            "As the two men maneuvered themselves around Banu, she smoothly dropped to her knees, her gaze locked onto the shorter guy's hefty member."
            "She reached out, wrapping her fingers around its girth, giving him a mischievous look before bringing him closer to her lips."
            "Her voice was sultry, teasing, as she spoke right before taking him in her mouth."
            b "Let's see if you taste as big as you look."
            scene v22-150
            "Banu gasped as the short guy’s cock hit the back of her throat, her eyes watering slightly as she struggled to handle his size."
            "Pulling back with a wet, desperate gasp, she coughed softly, her lips glistening and her chest heaving as she tried to catch her breath."
            stop sound
            scene v22-151
            "Her voice was hoarse but teasing as she tilted her head toward the taller guy."
            b "Damn, y’all really packing, huh?"
            "She looked at the taller guy with a playful but slightly overwhelmed expression."
            b "Alright, big man, let’s see if you’re any easier to handle… or if I’m gonna end up choking on yours too."
            scene v22-152
            "Banu grinned wickedly, her fingers wrapping around the taller guy’s cock as she gave it a slow, deliberate stroke."
            "She licked her lips, her confidence returning in full force."
            b "You think you’re gonna last, huh?"
            b "I bet you’ll be pumping that load down my throat in minutes."
            b "You’re not as tough as you look, big guy."
            guy1 "Oh yeah? You think you’re that good? Let’s see what you’ve got, sweetheart."
            "Without missing a beat, Banu pressed her lips against the head of his cock, swirling her tongue around it teasingly before taking him in."

            show suckingghvg
            $ renpy.sound.play("voices/suckdick.mp3", loop=True)
            "Her eyes watered slightly from the size, but she didn’t slow down, the wet, sloppy sounds filling the air."
            "She couldn’t speak, her mouth too full, but the taller guy wasn’t holding back."
            guy1 "That big mouth of yours finally put to good use, huh? All that attitude, and now you can’t even talk with my cock down your throat."
            guy1 "Bet you’ve been dreaming about this, haven’t you? Getting your mouth stuffed like the slut you are."
            guy1 "Look at the mess you’re making. Drool dripping down your chin, eyes all watery... You look so damn good like this."
            "The taller guy chuckled darkly, his smirk widening, looking down at her with a mix of amusement and triumph."
            guy1 "What happened, Banu? Thought you said I wouldn’t last five minutes?"
            guy1 "Looks like that big mouth of yours couldn’t back it up."
            scene v22-153
            "Banu gagged as she tried to take him deeper, her eyes watering as she pulled back with a loud gasp, her lips slick and swollen."
            scene v22-154
            stop sound
            play music "audio/heatedsex.mp3"

            b "Shut up..."
            guy1 "You don’t get to talk big and then choke—literally—and expect me to let it slide. Admit it, you lost. You couldn’t handle me."
            "She looked up at him, her cheeks flushed, her voice trembling with need."
            b "Just… just fuck me already..."
            b "Both of you… I can’t take it anymore."
            b "I just need it. I need you. Both of you. Right now."
            scene v22-155 with fade
            "She knelt before the short guy, her hands eagerly stroking him as she took him into her mouth, her lips tightly wrapping around him as she began to suck with a desperate fervor."
            "Behind her, the tall guy moved with a predatory grace, positioning himself at her exposed rear."
            scene v22-156
            guy1 "Look at you, so eager and ready.."
            guy1 "You're about to get exactly what you've been asking for."
            guy2 "So you want this cock, don't you?"
            b "Yess, I want it so bad..."
            "He slid the tip across her lips, barely giving her a taste before pulling back again, watching her eyes flash with a mix of frustration and hunger."
            "Banu glared up at him, her cheeks flushed, her lips parting instinctively as she leaned forward to take him."
            "But again, he pulled away at the last second, chuckling softly."
            guy2 "Not so fast, babe. You gotta earn it. Beg me for it."
            b "You’re such an ass.."
            scene v22-157 with hpunch
            "She suddenly felt a sharp, unexpected pain as the taller guy positioned himself behind her and pushed his cock right into her tight asshole without warning."
            b "Ow, fuck! That hurts, you asshole!"
            guy1 "Just relax, babe, it'll get better. You'll love it, just give it a second."
            b "You could have warned me, dammit!"
            scene v22-159
            "As Banu struggled to cope with the overwhelming sensations, the short guy grabbed her head, locking eyes with her in a stern, commanding gaze."
            guy2 "Shut up, and just take it, or I'll fucking choke you to death."
            "He then pushed her head down, forcing her back onto his cock, effectively silencing her protests."
            scene v22-160
            b "Mmmmmmm..."
            guy2 "Better keep quiet and enjoy it, babe."
            "Her eyes, wide with a complex blend of shock, pain, and emerging pleasure."
            scene v22-158
            guy1 "Fuck, such a tight ass...You like this?"
            b "Mmmmm..."
            guy1 "This feels incredible."
            guy2 "Bet Polad wouldn't even dream of seeing his precious Banu like this."
            guy1 "Yeah, imagine his face. The big bad Polad, clueless that his girl's getting it from us."
            b "Mmmm....shut up...and fuck me already..."
            guy2 "You heard her. Let’s not keep the lady waiting."
            show guysfuckbanustandingjhvhgvhg
            $ renpy.sound.play("voices/softmoan.mp3", loop=True)
            guy1 "Hope you’re ready, Banu, ‘cause we’re just getting started."
            "The short guy, still gripping her firmly, set a relentless pace, his movements sharp and deep."
            "He looked down at her with a gleam of conquest in his eyes, murmuring,"
            guy2 "That's it... just like that."
            guy1 "You love this, don't you? Admit it—you've been craving something this intense."
            guy1 "Getting fucked in the ass...damn bitch...your ass is squeezing my cock so bad."
            guy2 "Fuck her man, destroy her ass...just like that."
            stop sound
            scene v22-161 with fade
            "As Banu surrendered to the moment, her mind raced, overwhelmed by the sensations coursing through her body."
            "The cocks were filling her holes so good. "
            b_ "Oh god, this is insane... I can’t believe I’m letting this happen… but fuck, it feels so good."
            b_ "Damn, he’s so thick… every inch of him is driving me crazy."
            b_ "I’ve never felt this full, this stretched—it’s like he knows exactly how to push me over the edge."
            scene v22-159
            "The short guy pulled back slightly, a cocky grin on his face as he looked down at Banu, who was still catching her breath."
            "He tilted her chin up, locking eyes with her, and said with a teasing edge in his voice."
            guy2 "Alright, sweetheart, let’s switch it up. How about we see how you look on all fours?"
            scene black with dissolve
            "Her knees felt weak as he helped her up, guiding her toward the hood of the car."
            scene v22-162
            guy2 "Come on, Hands on the hood, ass up. Let’s give your other angle some attention."
            guy2 "You look so fucking perfect like this. Ready for me?"
            b "Do I look like I’m not?"
            guy2 "Fucking bitch..."

            show guysfuckbanudoggyhggfcgh
            $ renpy.sound.play("voices/longmoan.mp3", loop=True)

            b "Oh god, yes!"
            "Banu cried out, her voice breaking as the intensity of her pleasure mounted."
            guy2 "You like that, huh?"
            guy2 "You can take it, can’t you? Just like that."
            b "Yes, yes, don’t stop!"
            "Each thrust seemed to hit deeper, more forcefully than the last, pushing her closer to the edge."
            "As she neared her peak, her entire body tensed, her vision speckled with stars."
            b "I’m going to... I’m—oh god!"
            scene v22-163 with fade
            "Each deep, powerful thrust sent shockwaves of pleasure rippling through her body, her cries growing louder and more desperate. "
            b "Oh my god! Ohhh… fuck, yes, right there!"
            guy2 "I can feel you losing it, Banu. Come on, let go."
            b "I’m… oh god, I’m cumming!"
            "Her pussy clenched tightly around him, spasming uncontrollably as she came hard, her body shaking with the force of her orgasm."
            scene v22-164
            "Banu’s body quivered uncontrollably as the powerful orgasm wracked through her."
            guy2 "Your ass is shaking like crazy. That good, huh?"
            b "Ahhh… oh god… ohhh… I’m—ahhh!"
            b "Ohhh… oh god… I’m still cumming… ahhh, I can’t stop."
            "Her cries turned into broken whimpers, her body wracked with smaller spasms as the orgasm finally began to subside."
            scene black with dissolve
            stop sound
            guy1 "I don't know why the fuck we waited so long to do this.."
            b "Ahhh...wait...not so rough..."
            scene v22-165 with fade
            guy2 "Look at that ass...damn...She looks fucking delicious."
            guy2 "Get her on her knees."
            scene v22-166 with fade
            guy2 "The mighty Polad’s girl, down here for us. Bet he’d lose his damn mind if he saw this."
            guy2 "Revenge never felt this good..."
            guy2 "You’re ours now, and there’s nothing he can do about it."
            guy1 "Damn, bitch, suck my cock like that. Bet you didn’t think you’d end up like this."
            scene v22-167
            guy1 "But here you are, making Polad look like a fool while we take what we want."
            guy2 "You’re a perfect little revenge, Banu. And damn, you’re enjoying every second of it, aren’t you?"
            "She got angry but refused to respond, though the way her body moved told them everything they needed to know."
            "She needed a good fuck."
            scene v22-168
            "The man pushed the full length of his cock deep into her mouth."
            "Banu's eyes almost popped out and she started choking on that big cock."
            guy1 "Ohh fuck...that's it. She can't talke all of it. You look so cute down there, Banu."
            b "Mmmmmm...Ass...hole..."
            guy1 "Keep sucking, bitch, or I'll block your nostrils and choke to you death."
            guy2 "Fuck man, the girl has the tightest pussy that I've ever fucked."
            guy2 "I was wrong about her. She's not the type of woman that get her pussy fucked often."
            scene v22-169
            guy2 "Ohhh, shit bitch...how can you squeeze that pussy like that?"
            guy2 "I know you did this on purpose."
            b "Mmmmph..."
            guy1 "She's so horny now. Look at her nipples, so fat and swollen."
            guy2 "Fuck, this is the best pussy..."
            guy2 "It's so good. I'm gonna fill that lewd pussy with my cum...Oh god.."
            guy1 "Shit she sucks my cock like crazy....Damn, I can't hold it...shit.."
            scene v22-170 with hpunch
            b "Ahhhhhh..."
            guy2 "Ohhhh, damn...look at that fucking cum dripping out of her pussy..."
            guy1 "Damn, that was too intense, I can barely move."
            scene v22-171
            stop music
            stop sound

            b "You two are such assholes...I was going to die."
            b "Was that really necessary to push that huge thing all the way in?"
            guy1 "You were loving every second of it. Don’t act like we didn’t give you exactly what you wanted."
            b "There’s a difference between ‘what I wanted’ and ‘what I could handle."
            "As the two guys zipped up and prepared to leave, they exchanged smirks, clearly amused with themselves."
            scene v22-172 with fade
            "The taller one glanced back at Banu, still catching her breath..."
            guy1 "Well, that was fun..."
            guy2 "Yeah, thanks for the entertainment, Banu. You really know how to make a night memorable."
            "Banu's eyes widened as she realized they were serious about leaving her there, vulnerable and naked."
            b "Are you fucking kidding me?"
            b "You’re just gonna leave me here like this?"
            scene v22-173
            b "You’re really just gonna leave me like this?!"
            guy1 "What’s the matter, Banu? Can’t handle a little fun?"
            guy1 "Consider it a little payback for Polad. Tell him we said hi."
            b "Bastards! You’re gonna regret this! You hear me?!"
            scene v22-174
            "Banu stood there, trembling, her naked body illuminated by the faint streetlights. She glared at them, her eyes burning with a mix of fury and humiliation."
            b "Are you seriously leaving me like this?"
            guy2 "Maybe someone else will come along and pick up where we left off."
            guy1 "Yeah, or maybe Polad will find you like this. Bet he’d love to see his girl all exposed and used like that."
            "She lunged toward the car, desperate to stop them, but they pulled away, leaving her standing there, completely exposed."
            scene v22-175 with fade
            b "Bastards....You’ll pay for this, you hear me?! You’re fucking dead!"
            b_ "This was all a setup."
            b_ "They did this on purpose… to humiliate me… and Polad."
            scene v22-176
            "As the cold night air wrapped around her bare skin, Banu shivered violently, her body reacting instinctively to the chill."
            "Her nipples hardened, not from desire but from the biting cold that made her feel even more exposed."
            b_ "What the hell do I do now?"
            b_ "This is so fucked up,"
            b_ "Polad… where are you?"
            scene v22-177
            "Banu stood there, trembling, her arms crossed tightly over her chest, shielding herself from the biting cold and the overwhelming vulnerability she felt."
            "The thought of walking back to the apartment naked made her stomach churn, but she had no other choice."
            "Her clothes were left behind on the car, and the humiliation of what had just happened weighed heavily on her."
            scene v22-178
            "She glanced around the empty street, her breath visible in the frosty night air."
            "The fear of being seen, of someone stumbling across her like this, was unbearable."
            b_ "You can do this. Just keep moving, stay quiet, and get home."
            scene v22-179 with fade

            play music "audio/story_1.mp3"
            b_ "Please, please let no one be here..."
            "Banu finally reached the cluster of buildings where she lived, her heart pounding as she glanced around nervously."
            "The faint glow of streetlights illuminated the narrow alleyways and courtyards, casting long shadows on the walls."
            "Her building’s entrance was just ahead, its familiar outline a beacon of safety. The sight should have comforted her, but instead, her anxiety spiked."
            scene v22-180
            "As Banu crept closer to the entrance, she froze in her tracks."
            "Her breath caught in her throat as she spotted two men standing a short distance away, their casual conversation filling the still night air."
            scene v22-181
            "They hadn’t noticed her yet, their backs turned, but the sight of them sent a chill down her spine."
            b_ "Oh no, no, no. Not now, please. Just let me get inside without them seeing me,"
            b_ "If they turn around... God, I can’t let them see me like this. I’ll never live it down."
            "The subtle motion highlighted the definition of her thighs and the smooth arch of her waist."
            scene v22-182
            "Her frame, petite yet undeniably alluring, seemed almost too fragile for the situation she found herself in, adding to the stark vulnerability of the moment."
            "Her slender torso leaned forward as she moved, the gentle sway of her hips and the curve of her well-shaped ass moving instinctively in her quickened steps."
            b_ "Almost there. Don’t look back. Don’t make a sound."
            scene v22-183 with dissolve
            "As she reached the entrance, her hand grasped the cold metal of the door handle, and she slipped inside with a swift, silent motion."
            "The men’s conversation didn’t stop, and relief flooded her as she realized they hadn’t noticed her."
            scene v22-184 with fade
            "Polad's apartment was at the far end, tantalizingly close yet painfully far for someone in her current state."
            "Her heart thundered in her chest as she glanced around one last time, ensuring no one else was in sight."
            scene v22-185
            b_ "Just get to the door."
            b_ "It’s right there. No one will see. Just go."
            b_ "Please, no one come out, no one see me.."
            "Finally, the door to her apartment came into view, and a wave of relief threatened to overwhelm her."
            "Her pace quickened, her bare feet hitting the ground faster as she closed the gap. She reached out, her trembling hand grabbing for the doorknob."
            scene v22-186 with fade
            "The last thing she needed was to wake up Nesrin or Polad and face their questions—questions she wasn’t ready to answer."
            "The faint hum of the refrigerator in the kitchen was the only sound. The apartment was quiet, the dim glow from a small light above the stove casting soft shadows."
            scene v22-187
            "Banu took a deep, shaky breath and pushed herself up, her movements slow and deliberate."
            "Her bare feet padded softly on the cool floor as she moved toward her room."
            b_ "Just stay quiet..."
            b_ "Please be asleep,..."
            scene v22-188 with fade
            stop music
            "Banu stood motionless, her back pressed against the cool wall of her room, her chest rising and falling as she tried to steady her breath."
            b_ "How did it get to this point? How did I let myself go so far?"
            b_ "How could I let them use me like that? How could I betray everything I stand for?"
            scene v22-189
            b_ "I’m disgusting… I’m pathetic."
            b_ "I didn’t stop them. I didn’t fight back. I just… let it happen."
            b_ "What would Polad say if he knew?"
            b_ "He’d never look at me the same again."
            b_ "I don’t even deserve him. I don’t deserve anything. I’m just… nothing..."
            "She felt lost, drowning in her own choices, unsure if she could ever find a way to forgive herself—or if she even deserved to."



    stop music
    stop sound










    $ renpy.end_replay()
    $ persistent.guys_banu_unlocked = True
    jump guys_banu_continue















label changing_room:
    $ renpy.block_rollback()











    scene v22-200 with fade
    "As Polad’s lips captured hers, Banu’s mind spiraled into chaos. Her body melted against him, every nerve ending tingling with a fiery intensity she couldn’t control."
    b_ "Oh my god… What is happening? This is insane. His lips—oh, they’re so soft but so demanding."
    b_ "He’s not just kissing me; he’s… consuming me."
    b_ "Oh god, I’m so wet. I can feel it. How is he doing this to me? How can a kiss make me feel like this?"
    b_ "He’s kissing me like I’m the only thing in the world that matters right now, and I’m losing my mind."
    scene v22-201
    stop sound
    b_ "I’m drowning in this. I’ve never felt so wanted, so… devoured. And god help me, I don’t want it to stop."
    b "Holy shit Polad, you really are going to fuck me in the middle of the store?"
    p "Come on, turn around. Let me put my cock in between those sexy legs."
    scene v22-202
    b "I can't believe I'm doing this. Okay, let's do this. I'll take everything you've got."
    p "Shit, look at this sexy body, you're just an angel. My angel."
    b "I feel like such a dirty girl, doing this in a place like this..."
    b "But I'm so horny right now, and I can't wait for you to fuck me."
    p "You're so hot and wet down there. I can tell you're dripping on my cock right now."
    b "Oooh you know what I need right now Polad? I need your big dick inside me."
    scene v22-203
    b "Just fuck me....I can't wait anymore..."
    p "That's right, baby. That's what I'm gonna do. I like when you lose yourself like this."
    p "Tell me. How much do you want my big dick?"
    b "I want your big dick more than anything else right now. It's making me so wet just thinking about it."
    p "Then take it. But I warn you. I'm not gonna hold back."
    b "Oh god yes I want you to fuck me so hard."

    show changingroomnkjbh
    $ renpy.sound.play("voices/longmoan.mp3", loop=True)
    b "Fuck me Polad, fuck me!"
    p "You like that? You can't live without this cock, can you?"
    b "No, I can't live without it."
    b "OHHH FUCK POLAD KEEP GOING..."
    p "Shhh, do you want people hear us?"
    b "Y-yes... I want everyone to hear me scream."
    p "You are such a slut."
    b "Yes! I am a slut! Ahhhh....your slut..."
    p "Do you want me to cum inside you?"
    b "Of course I do! I want you to shoot your warm load all over the inside of my pussy."
    p "That's it. You are cumming."
    stop sound
    scene v22-204
    play sound "voices/moan1.mp3"
    b "Ohh fuck yes I am!"
    p "Then cum like a bitch."
    b "Ohhhh ohhhh ohhhh ohhhh I'M CUMMINGGG..."
    stop sound
    scene v22-205 with fade
    b "Hey, why did you stop? I want more. Fuck me."
    p "I'm not gonna fuck you until you beg for it."
    b "Please fuck me Polad."
    "His lips curled into a sly grin as he leaned closer, his voice low and teasing."
    p "You know that lingerie we were looking at… I think you’d look absolutely stunning in it."
    b "I’m not exactly in the mood for a fashion show right now."
    p "Turn around, let me see your body."
    scene v22-206 with fade
    p "It’s not a fashion show I’m thinking about..."
    p "It’s how good you’d look wearing that… and nothing else."
    b "You are absolutely out of your mind."
    p "Why don’t you go get that lingerie? You know which one I’m talking about."
    b "Wait, what? You want me to go out there and bring it back?"
    p "Exactly. I’ll be right here, waiting."
    b "You think I’m just going to walk out there, grab it, and come back like nothing’s happening?"
    p "Now, be a good girl, get dressed, and bring it back. I’m waiting. I'm not going to let you go until I fuck you in that lingerie."
    b_ "This man is going to drive me crazy..."
    scene v22-207 with fade
    b "What if someone comes in here and catches you like… that?"
    p "Then they’ll have a story to tell, won’t they? Now stop stalling and go. The clock’s ticking."
    b "Unbelievable..."
    scene v22-208 with fade

    "Banu stood in front of the lingerie section, her fingers lightly grazing the delicate fabric of a lacy pink set."
    "She smirked to herself, imagining Polad's reaction."
    scene v22-209
    b_ "He’s gonna lose his damn mind when he sees this.."
    b_ "Should I go bold with this pink one or keep it classic with the black?"
    b_ "Ugh, why am I overthinking this? It’s just lingerie… for him. Damn it, Banu, focus."
    b_ "What if someone saw us sneaking into the changing room? God, this is so reckless… but why does it make my stomach flip like this?"
    scene v22-210
    play music "audio/suspense.mp3"
    b_ "I can’t believe I’m even doing this. He’s waiting in there, probably already impatient and… naked."
    k "Banu."
    "Banu froze, her heart pounding so loudly she swore it echoed in the quiet store."
    scene v22-211
    b "Kamil?"
    k "Banu....you..."
    b "What… what are you doing here?"
    k "I was just passing and saw you from the window."
    k "Banu… you're not wearing your hijab?"
    b_ "Oh no. Here it comes."
    scene v22-212
    "His expression was a mixture of shock and something else—something she couldn’t quite place. Disapproval? Sadness? Curiosity?"
    b "I’m not. Like I said, people change."
    k "Change? That’s… I mean, I never thought I’d see the day. You always said you’d never—"
    b "People change. I don’t owe you an explanation."
    k "I know I have no right to say this. I know I’m probably the last person you want to hear from, but... I need you to know something."
    k "I’ve been carrying this with me every day since we split up. I was a fool, Banu."
    k "A complete fool. I didn’t see what I had when I had it. I didn’t treat you the way you deserved."
    b "Kamil, don’t—"
    k "I just care about you. I’ve been living with this regret, Banu."
    k "I’ve been haunted by how I treated you, how I let my ego get in the way, how I didn’t listen to you when it mattered."
    scene v22-213
    b "And now you expect me to just… what? Forget all of that? Forgive you?"
    k "Banu, I miss you. I miss us. I know I don’t deserve another chance, but I swear to you, I’ve changed."
    k "I would give anything to make things right, to be the man you needed me to be back then."
    b "There’s… someone else. I’ve moved on. I have someone in my life now."
    k "You’re just saying that to push me away."
    b "I’m not lying, Kamil. There’s someone else, and I care about him deeply."
    b "Let's stop this right here."
    scene v22-214
    k "Who? Who is it, Banu? I don’t see anyone here with you. Are you sure you’re not just saying this to avoid talking to me?"
    k "Banu...I know you. I know how you feel deep down. You can’t just erase what we had."
    k "I know I screwed up, but I’m different now. I can give you what you deserve, Banu. I can be the man you need."
    k "Banu..."
    scene v22-215 with fade
    k "Stop.."
    b "The man I need wouldn’t have to prove himself this late in the game. He would’ve loved and respected me from the start."
    k "Don’t push me away like this. If there really is someone else, tell me who it is. Prove it to me."
    b "You think I owe you proof?"
    scene v22-216 with fade
    "Kamil, on his knees, clutched her hand, his voice trembling as he pleaded."
    k "Banu, I was a fool! I made so many mistakes. I’ll do anything—anything—to make it right. Please just come back to me."
    b "Kamil, you had your chance. You threw it away."
    k "I can't let you go! You’re my everything, Banu. I’ll never forgive myself for what I did."
    scene v22-217
    b "You didn’t think I was 'everything' when you ignored me, dismissed me, and treated me like I was invisible."
    b "Now you want to crawl back because you finally realize what you’ve lost?"
    k "I’ve changed, I swear! I can be the man you deserve. Just give me one more chance."
    b "There’s someone else in my life now."
    k "There can’t be anyone else. No one will love you like I do."
    scene v22-218 with fade
    "Banu pushed Kamil's hands away with a sharp jerk, her patience wearing thin."
    "Without giving him a second glance, she turned on her heels and briskly walked away, leaving him kneeling on the store floor, stunned and humiliated."
    "Thoughts of Kamil's desperate pleas echoed in her head, but she quickly shoved them aside."
    scene v22-219
    "The last thing she needed was to dwell on the past when her present was waiting for her just a few steps away."
    "Reaching the changing stall, she paused to take a calming breath. "
    "With a quick glance around to ensure no one was watching, she slipped back inside, pulling the curtain closed behind her."
    scene v22-220 with fade
    "Polad raised an eyebrow when Banu finally blurted out..."
    b "Kamil is here. He’s following me around."
    b "He tried talking to me, begging me to come back, and now… he’s not going away."
    "Polad’s amused expression shifted into something sharper, though a mischievous grin crept back onto his face."
    p "Well, what do you want to do about it? Should I go out there and give him a little chat?"
    b "No, don’t make it worse. He thinks I’m alone in here."
    scene v22-221 with dissolve
    k "Banu! Are you in there? Can we talk, please?"
    "Polad smirked, his eyes twinkling with a devilish idea. He whispered, leaning in close to her ear."
    p "Let’s play along."
    scene v22-222 with dissolve
    k "Banu! Please, I need to talk to you! I know you’re in there!"
    k "Banu?"
    b "Just… just wait a second, okay? I’m busy!"
    k "I’ve been a complete fool. Losing you was the biggest mistake of my life, and I… I can’t stop thinking about you. About us."
    b "Kamil, you’re only saying this now because you’re desperate. I’ve moved on, and you need to do the same."
    k "Moved on? Banu, if there’s someone else, tell me. "
    k "Tell me so I can stop torturing myself with the hope that we can fix this. Tell me if you’re truly happy, and I’ll leave you alone forever."
    b "Kamil… I…"
    k "Banu, are you okay?"
    scene v22-223 with fade

    play music "audio/weakbanu.mp3"

    b "I’m fine. Just… I don’t know what to say, Kamil. This is… a lot."
    k "I know it is. I’ve messed up so badly, Banu. But I want to make it right. I can be the man you deserve."
    "Polad leaned closer, his breath warm against her neck as he whispered..."
    scene v22-224
    p "Let him think you’re flustered because of him."
    "His fingers slid down to her pussy, rubbing it while his dick was already going back and forth making her lose her mind."
    "A faint shiver ran through her, and she bit her lip to suppress any sound."
    b "Kamil, I…"
    b "I’m not sure if you understand how much hurt you caused me. You don’t just get to walk back into my life and expect everything to be okay."
    p "Keep going..."
    scene v22-225
    b "Ahhh..Kamil… I’m with someone now. Someone who values me. Someone who… understands me."
    k "You… You’re really happy with him?"
    k "Banu, I don’t care if I have to crawl on my knees. I’ll do whatever it takes to make things right."
    k "I’ll spend the rest of my life proving I’m worthy of you. Please, come back to me."
    show banufuckedkamilwatchvgcfg
    "Inside the stall, Banu’s heart raced, not just from Kamil’s words but from Polad’s deep thrusts.."
    "Her body betrayed her, and a faint sound escaped her lips."
    b "Ahhh....Kamil..."
    k "Are you okay, Banu? You sound... off."
    b "I-I'm...ohh... fine,"
    b "It’s just… hard to hear you say all this. ohhh..."
    p "He thinks he’s getting to you. Let him."
    k "Banu, I’ve lost everything. I don’t care how much I have to humiliate myself."
    k "If it means you’ll forgive me… if it means you’ll give me another chance…"
    p "He’s really going all out, isn’t he? Meanwhile, you’re falling apart in here."
    k "Are you crying? Please don’t cry. I didn’t mean to upset you."
    b "I’m.... not crying, Kamil,"
    scene v22-226 with fade
    k "I’m nothing without you, Banu,"
    k "I’ll do anything. Please, just… give me a sign. Tell me there’s hope."
    scene v22-227
    "Banu, desperate to get rid of Kamil before he discovered Polad, leaned her head out of the stall door, keeping the rest of her body hidden."
    "Her face burned with frustration and embarrassment, but she forced a sharp edge into her tone."
    k "Banu..."
    scene v22-228
    b "You’re acting like a donkey. What part of ‘we’re done’ don’t you understand?"
    b "You can’t just show up and throw your pathetic sob story at me expecting I’ll fall for it."
    b "Now get out of here, now!"
    k "I deserve that but I won’t leave, Banu. Not until you listen to me."
    b "You’re still the same clueless idiot who thinks the world owes him something."
    b "You think just because you’re kneeling here, groveling like a damn fool, I’ll forget the hell you put me through?"
    b "Now get the fuck out of here. Did you hear what I said."
    k "You’re being unfair, Banu. I—"
    scene v22-233 with hpunch
    b "Ahhhh..."
    "Banu froze mid-insult, her words catching in her throat as Polad’s hard cock slapped her back."
    k "What was that?"
    scene v22-229
    b "That was me—clearing my throat because your stupidity is choking me, Kamil."
    b "Seriously, do you ever stop embarrassing yourself?"
    p_ "Let’s see how long you can keep your composure."
    k "Are you okay, Banu? You’re acting... weird."
    b "Weird? Oh, please, Kamil. The only weird thing here is how you still think you have a chance with me."
    scene v22-234
    k "Fine, If you won’t listen to me, I’ll wait outside until you calm down. We need to talk—properly."
    b "Don’t be an idiot, Kamil. ahhhhh..."
    k "Are you sure everything’s okay?"
    b "You’re imagining things!"
    p_ "He’s not going anywhere, is he? Guess I’ll just have to make this more fun."
    p "Now I'm gonna put my cock in your tight asshole. Are you ready?"
    scene v22-235
    b "No!"
    b "I can’t… I can’t stand this!"
    b "Ohhh...shit...."
    k "Banu, what do you mean? You can’t stand what? Talk to me!"
    scene v22-230
    "Banu’s breath hitched as Polad’s cock started to rub on her asshole."
    b "Please, Kamil,...Just… go!"
    k "Banu, I just want to understand. Why are you pushing me away?"
    b "You're such a fool. How many times should I tell you that I don't want you. Get out of my life."
    k "I just don't understand, don't you want to give me a chance? Don't you want me back in your life?"
    scene v22-231 with hpunch
    b "NOOOOO!"
    k "Is that so?"
    b "Kamil, I—just leave! I don’t want to talk to you!"
    scene v22-236
    "Polad's cock finally pierced through Banu's tight asshole."
    "It was so tight that it hurt so much."
    "Her body trembled with a mix of frustration and the overwhelming tension swirling in the small space."
    scene v22-237
    "Her asshole started to hurt like hell."
    "As Kamil stood outside the stall, still pleading and refusing to leave, she clenched her fists, her eyes narrowing with a fiery determination."
    "With Polad's last thrust, she got out of her mind."
    scene v22-238
    b "Ohhhhhh....shit...."
    b "Get fucked, Kamil!"
    "Before Kamil could react, she spat directly at him, her voice cutting through the air like a knife."
    scene v22-232
    b "I said leave, and I meant it. Get out of here. Now!"
    "Kamil’s eyes widened in shock, his hand instinctively wiping his cheek where her spit landed."
    "He stared at her, his mouth opening and closing as if searching for words, but nothing came out."
    k "Fine. If that’s what you want, Banu."
    scene v22-240 with fade
    stop music
    stop sound

    play sound "voices/moan3.mp3"

    "As the sound of Kamil’s retreating footsteps faded into the distance, the tension inside the stall shifted."
    "Polad, still standing close to Banu, his cock still inside of her ass, pulling her gently toward him."
    p "How was that?"
    p "You handled it like a champ. I’m impressed."
    b "You… you almost killed me, Polad. Take it out—it hurts."
    b "And never fuck me in the ass. It hurts like hell. I can't stand yours."
    p "Hurts, huh? I thought you liked a little bit of danger, Banu."
    stop sound 
    scene black
    b "Ohhhh....God..."
    play sound "voices/jeanszipper.wav"
    scene v22-241
    "Polad’s hand slid to the back of Banu’s head, his fingers tangling in her hair as he pulled her closer, their bodies barely an inch apart."
    p "You’re not scared, are you, Banu?"
    b "Scared? Of you? Don’t flatter yourself."
    p "Oh, I’m not flattering myself. I’m just reading the way your body reacts to me. The way your breathing changes when I’m this close."
    b "You think you know everything, don’t you?"
    b "You talk a lot for someone who thinks he’s in control..."
    p "I don’t think I’m in control. I know I am."
    scene black with dissolve



    $ renpy.end_replay()
    $ persistent.changing_room_unlocked = True
    jump changing_room_continue

















label roof_sex:
    $ renpy.block_rollback()









    scene v22-251
    p "It’s not about being naked. It’s about shedding all those layers—the ones other people forced on you."
    p "All those years you were told to hide yourself, to stay in a box that didn’t fit you. You said it yourself—you want to feel free. Why not start now?"

    menu:
        "Don't do that.":
            $ banutrustpoladbuilding = False
            $ renpy.block_rollback()
            stop music
            b "Wait, you really want me to do this?"
            p "Why not, come on."
            b "You think I’m just going to strip on some rooftop like a sideshow for your entertainment?"
            p "What?"
            scene v22-252 with fade
            p "It’s not about that, Banu. It’s about freedom, about breaking free from all the—"
            b "You think I need to take my clothes off in public to prove I’m free? That’s your big idea?"
            p "I didn’t mean it like that.."
            b "You don’t get it, Polad. Just because I took off the hijab doesn’t mean I’m ready to throw everything away and expose myself like that."
            b "I don't like the way you see me."
            p "I’m sorry, Banu. I didn’t mean to offend you. I just thought it could be... liberating."
            b "I’m already free. Free to make my own choices. And right now, I’m choosing to say no."
            b "You might mean well, but this—"
            p "I just wanted you to feel... free, like nothing was holding you back."
            "Banu softened slightly at his words, but her stance remained firm."
            "She then smirked faintly, her walls slowly lowering."
            b "Good. Now let’s get out of here before you come up with another crazy idea."
        "Trust Polad.":








            $ banutrustpoladbuilding = True
            $ renpy.block_rollback()
            b "What if someone sees us?"
            p "Let this be a moment just for you. No rules, no judgment, just the night sky and the breeze."
            b "You just want to see me naked."
            p "For sure. But more than that, I want you to feel free. To feel alive."
            b "Then let's do this."
            scene black with dissolve
            "..."
            scene v22-253 with fade


            b "Wow...this is just beautiful...and scary."
            b "But if this goes wrong, I’m blaming you forever."
            "The city lights stretched out before them, twinkling like a sea of stars. "
            scene v22-254
            "The cool night breeze brushed against their skin, carrying with it the faint sounds of the bustling world below."
            p "We’ll go slow..."
            "Banu nodded, her heart pounding. Slowly, she started undressing, exposing her arms to the chilly air."
            scene v22-255

            play music "audio/heatedsex.mp3"

            "As the cool night air wrapped around them, Banu stood at the edge of the rooftop, gazing out over the city skyline."
            "The glowing lights of the buildings and the hum of distant life made her feel both vulnerable and alive in a way she hadn’t felt in years."
            "Her clothes lay discarded behind her, and she felt the chill of the wind against her bare skin. Every nerve in her body was awake, her senses heightened."
            scene v22-256 with fade
            "Polad stood just behind her, equally bare, his strong presence like a grounding force in the surreal moment."
            p "I’ve never seen someone look as breathtaking as you do right now."
            b "You’re full of compliments tonight, aren’t you?"
            p "You’ve been hiding this beautiful side of yourself for so long, Banu. You’re glowing right now."
            scene v22-257
            b "I should feel exposed, embarrassed even… but I don’t. I feel… free."
            p "That’s because you’re finally letting go."
            p "You’re finally claiming who you are, without anyone else’s rules or expectations."
            b "Or maybe it’s because you’re here. Somehow, you make the wildest ideas seem... okay."
            p "This is just okay."
            b "Only you would think that standing naked on a rooftop in the middle of the city is okay."
            p "Your ass is an absolute masterpiece. Seriously, Banu, it's like it was sculpted by the gods."
            scene v22-258
            b "Oh, is that so? Coming from the guy with a body that looks like it’s been chiseled out of stone?"
            b "You could crack a walnut with those abs, Polad."
            p "But let’s not pretend you’re not the one who steals all the attention. "
            p "Look at you—those curves, that skin... you're a walking distraction."
            scene v22-259
            b "Distracting? You’re one to talk. If you took your shirt off in public, I’m pretty sure people would faint."
            b "What do you even eat to look like this? Rocks and protein powder?"
            b "And this big, fat, long cock...it makes me crazy..."
            p "You’re the star here. I mean, your legs alone... they could make a grown man cry."
            p "You’re basically a walking dream, Banu."
            p "If I’d met you years ago, things would’ve been so different."
            b "Different how?"
            p "I’d have claimed you right then and there. Made you mine in every way that mattered."
            p "We’d have built a life together. A real one. I can see it so clearly... us having kids, a big family."
            p "Watching them grow up with your fire and my stubbornness. Can you imagine that?"
            b "You think we’d have been good at that? Raising kids, I mean."
            p "Of course we would’ve. You’re strong, Banu. Passionate. "
            p "Any kid would be lucky to have you as their mother. And I’d... well, I’d do everything to make sure they had the world."
            b "Polad, that’s... I don’t even know what to say...come here....I can't wait anymore..."
            scene v22-260 with fade

            $ renpy.sound.play("voices/kissing.mp3", loop=True)
            "Their bodies aligned perfectly, and the tension between them exploded as he tilted his head and captured her lips with his own."
            "The kiss was deep and consuming, a blend of urgency and raw passion."
            "Banu’s hands found their way to his chest, fingers brushing over his rock-hard muscles as her heart raced."
            "She felt herself melting into him, her breathing growing heavier with each passing second."
            "Polad's other hand slid around her waist, pulling her even closer, their bare skin igniting under the cool breeze of the rooftop. "
            p "You drive me crazy, Banu."
            scene v22-261
            "Banu felt the head of Polad's erection pressing against her, a direct and insistent touch that sent a shiver through her body. "
            "She gasped softly into his mouth, her hips instinctively tilting to align more closely with his, allowing him the access he sought."
            b "Ahhhh...."
            "His rock hard cock found its way to her pussy on its own."
            "Polad's hand supported her thigh, lifting it slightly, guiding himself gently but firmly. "
            stop sound
            show rooffuckvjh
            $ renpy.sound.play("voices/softmoan.mp3", loop=True)
            "The cool night air contrasted sharply with the warmth of their bodies and the hot rush of sensation as he began to push inside her."
            "Banu broke the kiss, her breath catching in her throat as she adjusted to the feeling, her eyes fluttering closed."
            "Polad began to move faster, each thrust gentle at first but growing in confidence and depth as Banu's responses became more fervent."
            "As Polad's movements became more assured, Banu's moans grew louder, the sound mingling with the breeze that swept across the rooftop."
            "As their movements grew more urgent, Polad’s deep, guttural groans reverberated in his chest, primal and raw."
            p "Ahh, Banu!"
            p "You feel so damn perfect!"
            b "Polad—ohhh… ahhh… yes!"
            b "I… I can’t take it—ahhhh!"
            p "You’re mine, Banu,"
            p "Every inch of you… mine."
            b "Polad! Oh my God—yes! Don’t stop!"
            stop sound
            scene v22-262 with fade
            "Polad suddenly bent her over like an animal, firmly holding her wrists, started thrusting deep inside her with powerful thrusts."
            b "Polad....Oh my God...I'm scared....ohhh..."
            "Polad's growls grew deeper, louder, almost animalistic with every thrust. "

            show aroofbjhbjh
            $ renpy.sound.play("voices/ahlong.mp3", loop=True)
            p "Unghh… ahhh! Banu… you're driving me crazy!"
            b "Ohhh… Polad! Ahhh! Yes! Don't stop! Harder—oh my God!"
            p "Unghh… ahhh! Take it, Banu!"
            p "You're mine… all mine!"
            b "Polad… ahhh! I can't—I can't handle it!"
            b "Ohhh—Polad! Ahhhhhh!"
            b "Ahhh… Polad! I can’t… I can’t hold it—ohhh, I’m losing my mind!"
            b "Oh my God… Polad! Ahhhh… yes, yes, yes!"
            p "Take it, Banu! All of it… ahhh!"
            "The city lights blurred as they lost themselves completely, their passion reaching its fiery peak."
            "Polad had always been the man in control—a rock, unshaken by anything. But tonight, something in Banu had unraveled him completely. "
            "The heat of her body against his, the way her voice trembled with need, the softness of her skin...."
            "All of it sent him spiraling into a place he’d never been before."
            stop sound
            scene v22-263 with fade
            b "Polad… Ahhh, you’re— you’re killing me..."
            p "I’ve never—ahhh! Never felt this way!...I will fuck you to death...Ahhh..."
            b "Polad, oh my God… you’re—ohhh, so wild!"
            p "I can’t stop… I can’t hold it back, Banu. You’ve done something to me—ahhh!"
            scene v22-264 with hpunch
            p "Ohhhhhh....Ohhhhh...God!"
            "As the intensity between them reached its peak, Polad’s control completely shattered."
            "His body tensed, every muscle in his rock-hard frame flexing as a deep, guttural roar tore from his throat."
            "It was primal, raw, and unlike anything Banu had ever heard before."
            scene v22-265
            play sound "voices/man2.mp3"
            b "Oh my god!"
            p "I can’t—ohhh, I’m—ahhh!"
            "Banu felt his body shudder against hers, his deep, masculine moans vibrating through her. "
            stop sound
            scene v22-266
            play sound "voices/man1.mp3"
            "Polad’s roars turned into long, uncontrollable groans, his voice breaking as he lost himself entirely."
            p "Ohhh, Banu! Ahhh—this… ohhh, it’s too much!"
            p "You’ve—ahhh! You’ve done this to me… made me lose my damn mind!"
            "As the final wave crashed over him, Polad let out one last, deep moan, his voice breaking into a desperate, low groan that echoed into the night."
            "His body collapsed slightly against hers, his forehead resting on her shoulder as he tried to catch his breath, his chest heaving with each inhale."
            stop sound
            stop music
            scene v22-267
            p "Ohhh...shit...This was...so good...you're so good..."
            p "Banu… I’ve never… I’ve never felt anything like that before."
            p "I want to knock you up. I want you. All of you. And I want a part of me in you… forever."
            b "What?"
            p "I want you in every way, Banu. Not just for tonight, not just for the moment. I want us to be something real. Something that lasts."
            b "You're crazy...Okay let's get dressed already before people call the police..."
            p "Okay...."



    scene black with dissolve
















    stop music

    stop sound    

    $ renpy.end_replay()
    $ persistent.roof_sex_unlocked = True
    jump roof_sex_continue














label dominating_polad:
    $ renpy.block_rollback()














    scene v22-294
    p "Banu. Enough!"
    p "I told you I’m tired, and I meant it. This isn’t happening tonight."
    b "You’re seriously turning me down? After everything—"
    p "Yes, I am. And you need to respect that. Go back to your room."

    menu:
        "Get offended":
            $ banudominatepolad = False
            $ renpy.block_rollback()
            stop music
            "Banu stood frozen for a moment, her confidence shaken by Polad's stern tone."
            "His unexpected rejection hit her harder than she wanted to admit. She swallowed the lump in her throat and let out a small, bitter laugh."
            scene v22-295
            b "You know what, Polad?"
            b "I don’t know why I even bothered. Clearly, I overestimated you."
            b "Next time, don’t bother flirting if you’re just going to shut the door in my face."
            "She pushed the door open and stepped out, letting it close behind her with a deliberate force."
            scene black
            "As she walked down the hall, she clenched her fists, her mind racing with emotions—hurt, anger, and a bruised sense of pride."
        "Dominate him":


            $ banudominatepolad = True
            $ renpy.block_rollback()
            scene v22-296 with fade
            "Banu's eyes narrowed as she crossed her arms, standing her ground face to face with Polad."
            "She was no longer offended by his rejection; instead, something else sparked inside her—a challenge."
            play music "audio/heatedsex.mp3"
            b "Hey, big guy, it's time to show you your place."
            p "What? So funny. What you're gonna do with this little body?"
            b "Oh, you think I can’t?"
            b "Maybe it's time I show you a different side of me, Polad."
            b "Take off your boxers and get on the bed now!"
            scene v22-297
            p "Banu, come on, you? Dominate me?"
            p "I’d like to see you try."
            b "You underestimate me, Polad. But that’s okay, it’ll make this even more fun."
            b "Let’s see if I can wipe that smirk off your face."
            p "Banu, you're cute when you try to act tough."
            scene v22-298 with hpunch
            play sound "voices/slap.mp3"
            "Without a word, Banu raised her hand and slapped Polad across the face."
            "The sharp crack of her palm meeting his cheek echoed through the room like a thunderclap, silencing his laughter immediately."
            "His head tilted slightly from the force of the slap, and for a moment, the room was still."
            scene v22-299
            p "What the hell was that?"
            "Polad's eyes narrowed, the sting of the slap fueling his anger. "
            "But Banu didn’t flinch. She stood her ground, her chest rising and falling as she stared him down with a fiery determination. "
            b "That is for underestimating me."
            p "You’ve got guts, Banu. But you better be ready for the consequences."
            p "Now I'll carry you to your bed and lock the door."
            b "Let’s play a game. You claim to be the strong, untouchable Polad, right? So, let’s test that."
            b "Here’s the deal—if you touch me, even once, you lose. And if you’re a real man, you won’t even think about it."
            b "No matter what I do. No matter what I say. And if you make it to the end. You win the game."
            p "Okay. Deal. I just want to see losing face of yours."
            scene v22-300
            b "Now lower your tone, asshole."
            p "What did you say?"
            b "Poor Polad. The big, bad man of the house can’t touch me, can he?"
            b "Come on, touch me. Prove me right. Show me you’re weak."
            b "Is this what a ‘real man’ looks like? You are not a real man. You're just a boy."
            b "What’s the matter, Polad? Cat got your tongue? Or are you just too scared to admit I’ve already won?"
            b "All muscles, no brains. You think you’re intimidating? Please. I’ve seen toddlers with more backbone."
            b "Poor Polad, the big, bad tough guy can’t handle a few words from a woman. How embarrassing."
            p "Banu...you're making me real angry..."
            b "I expected more from you, honestly. But I guess I should’ve known better. After all, you’re just a bald-headed brute with nothing to back it up."
            b "You’re not a man—you’re a coward. And the worst part? You know it."
            scene v22-301
            b "Come on, touch me. I know you want it so bad right now."
            b "You said you could handle anything. Or was that just another lie?"
            p "When this game ends, Banu, I'll make you regret this. I promise."
            b "You’re trembling, Oh, Polad, I thought you were supposed to be the unshakable one. But look at you now."
            b "You’re losing, Polad. And we both know it."
            scene v22-302
            p "Ohhhh...what are you doing?"
            b "Shut the fuck up!"
            "Banu whispered, her fingers trailing down further until they wrapped around his erected cock."
            scene v22-303
            p "Banu...you’re pushing your luck."
            b "Or are you just mad that I’m proving you wrong?"
            "As Banu’s hand wrapped around Polad’s cock, she could feel the tension radiating from his body, his self-control fraying with every stroke."
            "She moved her hand slowly at first, teasing, her fingers gliding along his length with deliberate precision."

            show handgcgfvjh

            "Polad’s breathing grew heavier, his chest rising and falling as he tried to fight the growing desire."
            p "Stop this. You… you don’t know what you’re doing."
            b "Oh, I know exactly what I’m doing..."
            "Banu said, her smirk widening as she increased the pace of her strokes."
            b "What’s the matter, Polad? Losing your legendary control?"
            p "Banu, I swear…"
            b "You swear what? You’ll stop me? You can’t even move. Admit it—you’ve already lost."
            "Polad’s body shuddered, his lips parting as a deep, primal roar escaped him."
            p "Banu!"
            b "You’re mine..."
            "Polad’s breathing grew heavier, his chest rising and falling as he tried to fight the growing desire."
            p "Banu!"
            b "What?"
            p "This is...not fair...ohhhh...."
            b "That is it, loser. You can't control it, can you?"
            scene v22-304
            "Banu, her confidence soaring after seeing Polad break under her touch, stood tall over him, her smirk turning into a wicked grin."
            b "You call yourself a strong man?"
            b "You are just an asshole."
            b "You’re not the king of this world—you’re just a man who lost to me."
            b "Now get on the bed, you piece of shit."
            p "Banu!"
            scene v22-305 with hpunch
            "Without a moment’s hesitation, she pushed him firmly onto the bed, her strength and confidence catching him completely off guard."
            "He stumbled backward, his broad frame landing on the mattress with a low thud."
            scene v22-306 with fade
            p "Banu, what the hell—"
            "Polad began, but his words caught in his throat as she climbed onto the bed, straddling him effortlessly."
            "Her hands found their way back to his cock, stroking him with deliberate, teasing movements."
            b "Shut up, Polad. You’re always the one in control. Not tonight."
            scene v22-307
            "Banu’s eyes gleamed with fiery determination as she hovered over Polad, her grip on his cock firm and unrelenting."
            b "Oh, Polad, you think you’re so strong, don’t you? So untouchable? I’ll make your cock explode in no time. Watch me."
            p "You’re still weak, Banu. You don’t have what it takes to bring me to my knees."
            b "You’re going to regret underestimating me."
            "She adjusted her position, her strokes growing more deliberate and intense. "
            p "Ahhh..."
            b "Even you can’t hide it. You’re breaking, Polad. Admit it."
            scene v22-308
            p "It’ll take more than that to break me."
            b "Because your body says otherwise. Look at you—you’re already trembling."
            b "You’re mine, Polad. And you’re going to lose."
            "Banu’s smirk turned wicked as she tightened her grip on Polad’s cock, her strokes deliberate and unrelenting."
            b "You’re such an asshole, Polad,..."
            p "Ohh....fuck...not that fast..."
            b "The big, tough guy everyone looks up to… and all you want is to fuck your best friend’s wife."
            p "Shut your mouth. You're crossing the line."
            scene v22-309
            b "What? Is this wrong? You're a bastard."
            p "Banu-"
            b "Oh, don’t you dare try to talk your way out of this."
            b "You think you’re so untouchable, but deep down, you’re just a man with no boundaries."
            b "A man who’ll screw over anyone if it means getting what he wants."
            p "You don’t know what you’re talking about,"
            b "What? You can't take it huh? You're in my hands now."
            "Polad’s breathing grew heavier, his jaw clenched tightly as Banu’s sharp words and relentless strokes pushed him to his limit."
            scene v22-310 with hpunch
            play sound "voices/slap.mp3"
            "His hand shot up instinctively, aiming to silence her, but before he could make contact, Banu’s palm landed on his cheek with a loud, resounding slap."
            "The sound echoed through the room, and Polad’s head snapped to the side from the force of it. "
            "His eyes blazed with fury as he turned back to look at her, his nostrils flaring, his entire body taut with restrained anger."
            scene v22-311
            p "What the fuck you think you are doing?"
            "Banu smirked, her confidence unshaken as her hand continued its merciless rhythm on his cock."
            b "Oh, I know exactly what I’m doing."
            b "I’m proving that the so-called mighty Polad can be brought to his knees by a woman."
            "Polad’s fists clenched at his sides, his body trembling with the effort to keep himself from breaking the rules of the game."
            p "You....ohhh...you’re playing with fire."
            b "Fire?"
            scene v22-312 with fade
            b "Oh, Polad, you’re not fire. You’re smoke—empty and fleeting. And I’m blowing you out."
            p "Ohhh...shit...you'll regret for doing this to me...."
            b "Your cock is so hard and I know that it will explode soon."
            b "You’re mad, aren’t you?"
            b "You’re furious. But you can’t do a damn thing about it, can you?"
            p "You’re lucky I’m following your stupid rules..."
            b "No, Polad, I’m just better than you. Admit it—you’ve already lost."
            p "You’re going to regret this."
            scene v22-313
            "Polad’s composure was unraveling, his deep voice breaking as he tried to speak. "
            p "B-Banu… I swear to God… you—ahhh… you’re—"
            "His words came out in jagged fragments, his breaths shallow and uneven."
            "His eyes darted to hers, filled with a mixture of frustration, disbelief, and an unmistakable flicker of desperation."
            b "What’s that, Polad?"

            show dominationfgdgf
            b "You can’t even finish a sentence now? Poor guy. You’re really losing it."
            "Her hand moved faster, her strokes precise and relentless, her fingers grazing sensitive spots as if she’d memorized every inch of him."
            "Polad’s head tilted back, his lips parted as a guttural groan escaped him."
            p "Banu… I can’t—ahh… not so fast..!"
            b "Oh, but you don’t really want me to stop, do you?"
            b "Admit it, Polad. You love this. You love the fact that I’ve got you right where I want you."
            p "Y-you’re… crazy,"
            b "Crazy? Maybe. But at least I’m not the one falling apart right now."
            b "Look at you. The great Polad, reduced to a stuttering mess. You’re adorable."
            $ renpy.sound.play("voices/man5.mp3", loop=True)
            p "Banu, I—ahhh, damn it… you’re—"
            b "I feel it, your cock saying it all...you're going to release all of that cum..."
            b "Say what’s on your mind, Polad. Or are you too far gone for that now?"
            p "You… you’re… driving me insane.."
            stop sound
            scene v22-314
            b "The great, unbreakable Polad. The man who acts like he’s invincible. And here you are—falling apart under my hand. Pathetic."
            "Polad’s jaw tightened, his body trembling with the effort to maintain what little composure he had left. "
            p "Banu… don’t—"
            b "Don’t tell the truth? Don’t point out how weak you are? Face it, Polad—you’re not half the man you think you are."
            b "Your heart is in my hand now."
            b "You call yourself a man? Please. A real man wouldn’t let this happen. "
            b "A real man wouldn’t let someone like me break him so easily."
            scene v22-315
            b "How does it feel to know you’ve lost to me? To know that no matter how hard you try, you’ll never win?"
            b "Big, strong, Polad, who can’t even handle a little challenge."
            p "Banu, stop this, you are crossing a line."
            b "That’s rich coming from a man who’s crossing every line possible by cheating on his wife."
            p "Don’t..."
            "Polad’s eyes darkened, and his fists clenched at his sides. "
            b "Afraid of the truth, Polad? Afraid to admit that you’re nothing more than a lying, cheating man?"
            scene v22-316
            p "Banu, I’m warning you—"
            "His body tensed, his muscles coiled as if ready to spring, but he stayed still, his restraint hanging by a thread."
            "Despite his best efforts to maintain composure, the relentless mixture of her touch and her biting words drove him to a breaking point."
            scene v22-317 with flash
            p "Arrrrggg..."
            "His body convulsed, a surge of release sweeping through him."
            "Helpless to her manipulations, he climaxed explosively."
            scene v22-318
            play sound "voices/man3.mp3"
            "His cum covered his tensed abs and chest, marking him with the undeniable evidence of his loss of control."
            scene v22-319
            stop sound
            "Exhausted and overwhelmed, Polad collapsed onto the bed, his chest heaving as he lay back, defeated and vulnerable."
            "Banu stood over him, her smirk now a broad, triumphant grin."
            scene v22-320
            stop music
            stop sound

            "She observed him for a moment, reveling in the power she held over such a formidable man."
            b "Look at you. So much for the mighty Polad. Couldn't even keep it together."
            b "You're no stronger than anyone else. And don't you ever forget how easily I broke you."
            "With that, Banu straightened up, her gaze lingering on his disheveled, defeated form for a moment longer."
            scene v22-321
            "She then turned on her heel and left the room, her steps light and satisfied."
            "The door clicked shut behind her, leaving Polad alone in the dimly lit room, a stark contrast to the fiery intensity that had just consumed them both."
            scene v22-322 with fade
            "Polad lay on the bed, his body completely still except for the rise and fall of his chest as he tried to catch his breath."
            "His strong abs and broad chest were streaked with his own cum, a stark and humiliating reminder of how he had completely lost control."
            "His arms lay limp at his sides, his fingers twitching slightly as he stared up at the ceiling."
            "Polad didn’t even bother to clean himself up. He was too drained, both physically and emotionally."
            "Finally, his eyes began to close, his breathing slowing as exhaustion took over."

    stop music        
    stop sound            






    $ renpy.end_replay()
    $ persistent.dominating_polad_unlocked = True
    jump dominating_polad_continue










label threesome_555:
    $ renpy.block_rollback()











    scene black with dissolve
    play music "audio/sexy.mp3"
    "While Banu, Polad, and Natasha engage in their intimate encounter in the back room, Leyla and Sasha continue their deep conversation..."
    scene v22-332 with dissolve
    b "Keep fucking me Polad... don't stop."
    b "I can feel you fully inside me...Destroy my tight asshole...ahhh..."
    nat "Banu, you're going to get fucked good."
    scene v22-333 with fade
    b "I bet I will, ahhh."
    "Natasha leans in closer, pressing her tongue against Banu's clit."
    nat "Mmm this tastes sweet..."
    scene v22-334
    b "Oh fuck Polad I'm getting close!"
    p "You see, our little Banu can't take it anymore."
    b "Ohh fuck yes Natasha, I'm almost there."
    scene v22-335
    b "I want to cum so bad...ahhhh..."
    nat "Cum all over my face Banu, I want to taste every drop of your juices."
    b "I can feel you deep inside me Polad,...I can't take it anymore....ahhh."
    b "I love having you fuck my ass."
    nat "Banu is such a dirty little slut. I bet she wants me to eat her asshole too."
    b "I do!"
    scene v22-335 with flash
    b "This feels so good Polad, I'm about to cum soooo hard!"
    b "Natasha keep going, lick my clit until I cum all over your face!"
    b "Ohhhh ohhhh ohhhh I'm cummingggg!!!"
    p "Ohhh shit, I'm cumming too...ahhhh..."
    b "Ohhhh fuck that feels amazing Polad. Release all of it inside me...ohhh...!"
    p "Fuck!"
    scene black with dissolve
    "Banu let out a long sigh, her chest still heaving slightly from her powerful climax."
    scene v22-336
    b "Well, that was... beyond expectations. I didn’t think you had it in you, Polad. Or you, little blonde bitch."
    nat "Oh please, Banu, don’t act like you weren’t holding back. The way you screamed—it was like a battle cry."
    scene v22-337
    p "Battle cry? More like the roar of a queen conquering her kingdom."
    p "But don’t get too comfortable. I’m not done with either of you yet."
    b "I want to see your beautiful face whlie Polad fuck the shit out of you."
    nat "Ummm, I don't mind it. Besides I am not easy to break like you, Banu."
    b "Polad, don’t tell me you’re gearing up for round two."
    nat "You know me better than that, Banu. I always rise to the occasion."
    scene v22-338
    "Natasha’s eyes flickered downward for a split second, and she gasped, her hand flying to her mouth in mock shock."
    nat "Oh my God, Banu... look at that! Our mighty warrior is ready for battle again!"
    b "Polad... are you serious? Already? We were just talking about how exhausted you looked, and here you are, proving us wrong!"
    p "What can I say? You two are dangerous. You think a man can just stand here and listen to all that teasing without feeling... inspired?"
    nat "Inspired? This is more than inspiration, Polad. This is pure determination. Are you sure you can handle another round with us?"
    b "He might be ready, but the question is... can he keep up this time? Or are we going to have to carry him out of here when he collapses again?"
    p "You two underestimate me. Let’s see who’s left standing by the end of this."
    scene v22-339 with fade
    nat "Don’t hold back, Polad. Let’s see if you can keep up this time. mmuuahh..."
    p "Oh, you’ll both feel just how much I have left."
    b "Mmm...You’re already losing it, Natasha."
    nat "Not yet, Banu. Let’s see who gives out first."
    scene v22-340
    b "Ahhhhh...."
    "Banu's head tilted back as she let out a deep, guttural moan that echoed through the room."
    b "Oh… my God… Polad! I… I can’t…!"
    nat "Looks like someone’s losing control already."
    b "Shut… shut up, Natasha… he’s—oh, God!"
    p "You taste so damn good, Banu. Don’t hold back… I want to hear everything."
    nat "Let it out, Banu. Don’t hold back. He loves it when you lose yourself."
    b "Polad! Oh—don’t stop! Don’t… oh… my God!"
    p "That’s the sound I’ve been waiting for."
    nat "Alright, Banu, it's my turn now. Time to get some revenge for you."

    show natasha_ridejhvhj
    p "Ohhhh....Damn...."
    p "Natasha… you're going to drive me insane."
    nat "Ohhh....yesss....Good. You deserve every bit of it after what you just did to Banu."
    "Natasha began moving her hips, riding him with precision and power. "
    b "See, Polad? You're not as tough as you think. Look at you—Natasha's breaking you already."
    p "Not… a chance… I can handle this…"
    nat "Come on, Polad. Show me what you've got. Or are you already losing control?"
    p "You… you’re insane… Natasha…"
    scene v22-341
    p "Fuck....I can't hold it....cumming....shit....ahhhh..."
    nat "There, Banu. Revenge served. I think I broke your tough guy."
    b "Looks like you did. Polad, you alright there?"
    p "You're both… impossible."
    scene v22-342
    nat "Ohhh fuck, he is still fucking me...ahhh"
    b "Oh yeah, he is so active down there."
    scene v22-343
    nat "Ohh my god...Polad… are you even human? How… are you still going?"
    p "You think I’m done with you? You underestimated me, Natasha."
    b "Natasha, you wanted revenge, and now look at you. Can’t handle it, can you?"
    nat "Shut up… Banu. I’m not… done yet."
    nat "You’re just jealous… jealous that he’s making me lose my mind."
    b "Oh, I’m just watching the show. Looks like you can’t even keep your thoughts straight."
    nat "He’s… he’s too much, Banu. You… have no idea… how good this feels!"
    scene v22-344 with vpunch
    play sound "voices/moanfinish.mp3"

    nat "Ahhhhhhh..."
    nat "Polad! I… I’m so close… Oh my god, I can’t…!"
    p "Let it go, Natasha. Show me how much you want this."
    nat "I… I’m… Oh god, Polad! I can’t stop… It’s too much!"
    b "Looks like someone can’t handle Polad’s cock. Told you he’s too much, Natasha."
    stop sound
    scene black with dissolve
    "Natasha and Banu exchanged a wicked grin, an unspoken pact forming between them as they decided it was time to turn the tables on Polad."
    scene v22-345
    nat "Time to show this so-called beast what happens when he tries to conquer us."
    nat "How does it feel to be at our mercy, Polad? Not so dominant now, are you?"
    p "Be careful, Natasha. You're in dangerous waters."
    "Polad let out a muffled groan as he furiously grabbed onto Natasha’s hips, his mouth finding its way to her center."
    scene v22-346
    nat "Oh, no, you don’t! We’re not letting you win this time!"
    "He began eating her out with an intensity that made Natasha gasp and lose her rhythm for a moment."
    b "Stay strong, Natasha! Don’t let him distract you!"
    nat "Damn it, Polad! You… you’re cheating!"
    p "I don’t cheat. I win."
    scene v22-347
    b "Hey, Nat, hold on while I distract him a bit."
    p "Banu… what the hell are you doing?!"
    b "Oh, just exploring, Polad. Don’t tell me the big bad king can’t handle a little teasing?"
    p "You’re playing with fire, Banu. You don’t know what you’ve just started."
    b "For all your big talk, Polad, you seem pretty… defenseless right now."
    p "You think this is funny? I’ll show you what happens when you cross the line, Banu. You won’t know what hit you."
    b "Hey, what if I put it a bit inside...."
    scene v22-348
    p "Ahhh… Banu… what the hell are you doing? Stop—ohhh… damn it!"
    p "Banu… I swear… aahhh… you’re gonna… pay for this…!"
    b "Oh, Polad. Those sounds… I didn’t know you had it in you."
    p "You’re… ahhh… playing… ohhh… with fire…!"
    nat "He sounds like he’s about to break, Banu. Keep going!"
    p "Enjoy this while it lasts, because when I’m back in charge… you won’t know what hit you."
    scene black with dissolve
    "Polad’s heavy breathing turned into a growl as he suddenly snapped out of his haze. His eyes darkened with determination, and his lips curled into a wicked grin."
    scene v22-349 with dissolve
    play sound "voices/ah.mp3"
    nat "Oh, he’s not playing anymore, Banu. I think we woke the beast."
    b "Oh… oh my God, Polad! You… you’re insane!"
    "In one swift motion, he grabbed both Banu and Natasha, his strength leaving them no room to resist."
    p "Alright, ladies. Playtime’s over. Now it’s my turn."
    "Before they could protest, Polad maneuvered them side by side next to the sofa, their legs hoisted into the air as he effortlessly positioned them in the pile driver pose."
    scene v22-350
    nat "Ahhhh...."
    b "Natasha, I think he’s proving a point. Are you okay over there?"
    nat "Shut up, Banu! Oh God… he’s… ohhh!"
    scene v22-351
    p "You wanted to see what I’m capable of. Now, you’re going to feel every bit of it."
    nat "Polad! Oh my God! You’re… ohhh! You’re going to make me lose my mind!"
    p "Scream all you want, Natasha. Let everyone know who’s making you feel like this."
    scene v22-352
    nat "Polad! It’s too much… I can’t—ohhh God, I can’t!"
    b "What happened to all that talk, Natasha? You sound like you’re about to pass out."
    nat "Shut… shut up, Banu! You… ohhh! You don’t… oh my God… understand!"
    p "You wanted it, Natasha. Now, take it."
    nat "Polad! I’m… I’m cumming! Oh God, I’m cumming so hard!"
    "Natasha let out a final, piercing scream as her body shook violently, her climax crashing over her like a tidal wave. "
    " Her legs trembled in Polad’s grasp as she writhed beneath him, completely undone by his relentless cock."
    scene v22-353 with fade
    "Natasha lay trembling on the floor, panting and completely spent, her legs still shaking."
    "Polad turned his attention to Banu, who was watching him with wide, wary eyes."
    p "Your turn, Banu. Time to get you back for that little stunt earlier."
    b "Polad… wait… you won't put it in my ass, will you?"
    p "You’re going to feel what happens when you mess with me."
    p "Let’s see how you like it."
    b "Polad… no! Not there! Please… I can’t…!"

    show poladnatbanuhjhjv
    b "Ohhhh...damn...it hurts....damn you..."
    p "You didn’t seem to care about my boundaries, did you? Now you’ll know exactly how it feels."
    b "Polad! Oh my God! It hurts! You… you bastard!"
    p "Hurts, huh? Don’t worry, Banu. You’ll get used to it… and then you’ll start begging for more."
    b "You’re… such an asshole… but oh… oh my God!"
    b "Polad! Oh… damn you! I… I can’t handle this!"
    p "Ohhh... I’m… damn it!"
    p "Ohhh...fuckkk...."
    scene v22-354 with fade
    "With one final thrust, Polad let go completely, his climax hitting him like a storm."
    "His cock pulsed as he released himself, his hot cum spilling on her pussy."
    "He pulled back slightly, his thick, dripping cock brushing against her skin as he let out another low groan. "
    scene v22-355
    b "You… really don’t hold back, do you?"
    p "You started this, Banu. I just finished it."
    nat "Well, looks like he left his mark on both of us. Banu, how are you even feeling?"
    b "I’m not sure I am anymore."
    p "You both wanted to play games. Now you know what happens when you challenge me."
    b "You’re insufferable, Polad."
    nat "But damn, you’re good at it."
    scene v22-356 with fade
    stop music
    stop sound
    "The door to the back room swung open with a loud creak, and Sasha stepped in."
    "His casual demeanor quickly giving way to wide-eyed shock as the scene unfolded before him. "
    "His jaw dropped as he froze in place, his gaze locked on Banu and Natasha, still sprawled in the piledriver position, their legs in the air and bodies glistening."
    scene v22-357
    sa "Uh… what the… hell?!… what is… going on here?!"
    p "Sasha?! What are you doing here?!"
    scene v22-358
    "Polad, standing just like that his cock still dripping cum, didn’t bother to cover himself. Instead, he chuckled softly, his deep voice cutting through the tension."
    p "Looks like we’ve got an unexpected audience."
    "Natasha, still sprawled out, let out a breathless laugh, clearly too exhausted to care."
    nat "Well, this is awkward."
    sa "Banu...Your daughter… Leyla… she’s waiting for you out front! "
    scene v22-359 with fade
    b "Leyla’s here?! Oh my God, Sasha, why didn’t you tell me sooner?!"
    sa "I didn’t expect to walk into… whatever this is!"
    p "Relax, Sasha. You’ve seen worse."
    sa "Not in my lifetime, Polad!"
    scene v22-360
    b "Oh my God… what am I supposed to say to her? "
    b "How do I even look her in the eye after this? She’s going to know something’s wrong. She always does."
    p "Banu, relax. She doesn’t know anything. You’re overthinking this."
    b "Overthinking? Polad, she’s my daughter! What if Sasha says something?"
    b "What if she senses something? She’s not stupid—she’ll know something’s off!"
    p "Banu, listen to me. Leyla doesn’t know anything. Sasha’s not going to say a word. "
    p "You just need to go out there, take a deep breath, and act normal. She’s here because she loves you, not to judge you."
    b "You make it sound so easy."



    $ renpy.end_replay()
    $ persistent.threesome_555_unlocked = True
    jump threesome_555_continue














label threesome_666:
    $ renpy.block_rollback()






    play music "audio/sensual.mp3"

    scene black with dissolve

    "Mahmud's calculated charm and Murat's playful arrogance were working together to dismantle the last shreds of Banu's resistance."

    "She could feel the heat rising within her, an undeniable ache that she could no longer suppress."

    scene v22-397 with dissolve

    mur "You’ve been craving this. Let yourself have it."

    mah "You want this as much as we do. I can see it in your eyes."

    b "You’re right. I’ve wanted this... so bad."

    scene v22-398 with fade

    mah "Good girl. Now let us take care of you."

    mah "You’re even more beautiful than I imagined, Banu."

    b "Don’t just look. Show me what you’ve been imagining."

    b "I need this. I need you... both of you."

    scene v22-399

    mah "You think you’ve seen wild before, little one? You have no idea what a man like me can do to a woman like you."

    b "You talk big, Mahmud, but can you back it up? Or are you just all words?"

    mah "Words? Oh, Banu, you’re going to feel my answer soon enough. But first, I want to hear you beg for it."

    scene v22-400

    b "I don’t beg, Mahmud."

    mah "Oh, you will. By the time I’m done, you’ll be screaming my name like it’s the only word you know."

    mur "Hehe, the old man is getting wild."

    b "You’re just an old man. What makes you think you can handle me?"

    mah "Old? Perhaps. But age brings experience, my dear. And I’ve had a lifetime to learn exactly how to break a woman like you."

    scene v22-401

    "Banu’s gaze drifts between Mahmud and Murat."

    "Her eyes catch sight of Murat’s cock, the younger man’s attributes clearly on display. "

    b "Seems like you've brought quite the competition tonight, Mahmud. Murat here looks more... eager to impress."

    mur "It’s not just about eagerness, Banu. It’s about stamina. Let’s see if the old man can keep up with what I’ve got planned for you."

    mah "It’s good to have youth on one’s side, but don't underestimate the mastery of experience."

    mah "I'll show you something that sheer size and youthful energy can't match."

    b "Well, let's see...."

    scene v22-402

    "As Banu takes Murat's cock in her mouth, skillfully attending to him, she lowers herself onto Mahmud."

    "Mahmud, feeling Banu's weight pressing down on him, leans back, his eyes fixed on the scene unfolding."

    mah "Looks like she's handling you quite well, wouldn't you say?"

    scene v22-403

    mur "Oh, she's magnificent. But don't get too comfortable, old man. I'm just getting started here."

    mah "Experience has its advantages, young Murat. Stamina is one, but knowing exactly how to move, how to touch... that's the art."

    b "Mmmmm......uhhhh..."

    mur "Art, huh? Watch closely then. You might learn something new tonight."

    mah "Let me show you how a real man takes charge."

    "Banu gasped at the sudden shift, her body instinctively adjusting to Mahmud’s powerful thrusts as he began pounding into her with relentless force."



    show aldojhbjh

    $ renpy.sound.play("voices/ahlong.mp3", loop=True)



    b "Ummmmmm......ahhh.....ummmmmm..."

    mur "Careful, old man. You might throw your back out."

    mah "Ohhhh....This back has handled more women..... than you’ve ever dreamed of, boy. Watch and learn."

    mah "You feel that, Banu?....ahhhh... This is what a man does."

    mah "Not some fumbling boy pretending he knows what he’s doing."

    mur "You’ve still got some moves, Uncle. But don’t wear her out too much—I’m next."

    mah "You’ll have to wait your turn. Right now, she’s mine."

    "Mahmud continued to pound her with an intensity that left no doubt about his experience and dominance."

    stop sound

    scene v22-404

    "The rivalry between the two men only fueled his efforts, determined to leave no doubt about who was in control."

    "Murat watched with an intense stare as Mahmud finally eased up, his breathing heavy from exertion."

    "Seizing the opportunity, Murat stepped forward, a wicked grin spreading across his face."

    mur "My turn now. Let’s see if you can handle the pace I set."

    scene v22-405 with fade

    "Without waiting for her to respond, Murat maneuvered Banu into a full nelson position, her arms locked above her by his strong grip."

    "He positioned himself behind her, his presence dominant."

    mur "Watch closely, uncle. This is how you truly claim victory."

    scene v22-406

    b "Oh God, Murat... Yes!"

    b "My ass just needed your cock....ohhhh...God!"

    mur "Feel that, Banu? That’s what you’ve been missing."

    scene v22-407

    mah "Not bad, Murat. But don't get too cocky!"

    mur "Just giving you a hard act to follow!"

    "Banu was lost in the sensations, her body moving in rhythm with Murat's powerful thrusts. "


    show nelsonbnvnb

    $ renpy.sound.play("voices/ahlongcum.mp3", loop=True)

    "Each movement drove her closer to the edge, her cries growing louder and more desperate."

    b "Ohhh, Murat! Yes! Just like that!"

    mur "That's it, scream for me, Banu. Let everyone know who's making you feel this good."

    b "Murat! I can't... it's too much... so good!"

    "Banu’s moans turned into high-pitched cries, each one a mixture of pleasure and the overwhelming sensation of being utterly controlled."

    b "Yes! Yes! Don't stop, please, don't stop!"

    "Banu could barely form words, her mind clouded with pleasure, her responses instinctual and primal."

    b "Murat... oh, Murat..."

    stop sound

    scene v22-408 with fade

    "After an intense and exhaustive session, Murat's final act culminated explosively."

    b "Ahhhh....You're filling me....ohh..."

    mur "Fuck! Take it....ohhh.."

    "Feeling overwhelmed by the surge of sensations, Banu could barely hold herself up as Murat finally eased back, releasing his grip."

    "Her legs felt weak, and her body was slick with exertion as she staggered slightly, trying to regain her composure."

    scene v22-409

    "Exhausted and spent, Banu collapsed onto the nearby sofa, her body sprawling limply across."

    "She lay there, her back exposed and her breathing heavy, trying to process the flood of sensations that had just overwhelmed her."

    mur "Are you okay, Banu?"

    b "I'm... I'm fine. Just give me a moment."

    scene v22-410 with fade

    "Mahmud stood nearby, his chest rising and falling heavily as the tension of the moment finally caught up with him."

    mur "Time to empty the pipe, old man."

    scene v22-411

    mah "Ahhhhhhhh.....Ahhhhhhh......Arrrggggg..."

    mur "Wow, so much cum for an old man."

    scene v22-412

    "Banu remained on the sofa, her breath steadying as she began to drift into a calm, reflective state."

    mur "Careful there, Uncle. Don’t want you pulling a muscle in your back. You’ve got to pace yourself at your age."

    mah "Watch your mouth, boy. I’ve got more stamina left in me than you’ll ever understand."

    mur "Sure, sure. But you looked like you were about to pass out just now. Need me to fetch you some water? Maybe a chair?"

    mah "Laugh all you want, Murat. But remember who set the standard around here."

    b "You two are impossible."

    stop music

    stop sound






    $ renpy.end_replay()
    $ persistent.threesome_666_unlocked = True
    jump threesome_666_continue



























label polad:




    scene black with Dissolve(3)
    ""
    centered "{size=+120}1 year later...{/size}" with Fade(0.5, 0.5, 5)
    scene black with dissolve
    b_ "A year after my divorce from Kamil, life took me on a wild ride."
    b_ "I found myself in Polad's apartment, a place that became both my refuge and my playground."
    scene v18-112
    b_ "Once the divorce papers were signed, it felt like a weight had been lifted. I was no longer bound by the rules and expectations that came with being a wife."
    b_ "I let loose my naughty side, indulging in experiences that I had only dreamed of before."
    b_ "It was like discovering a whole new me, one unafraid to embrace desires and excitement."
    b_ "I started meeting different men, exploring the uncharted territories of my sensuality."
    b_ "Each encounter brought a mix of thrill and curiosity, a chance to satisfy my desires and learn more about myself."
    scene v18-113
    b_ "Despite the complications of his marriage, Polad and I shared a secretive connection, adding an element of thrill to my newfound freedom."
    b_ "In the midst of my adventures, Polad often found his way into my room, igniting the flames of passion in our secret encounters."
    scene v18-114

    b_ "Our affair was a forbidden pleasure, a mix of sweetness and bitterness that made me realize the complexities of human connections."
    b_ "During our secret encounters, I would trace my fingers lightly over his tattoos, feeling the stories etched into his skin."
    scene v18-115
    b_ "He used to come to my room and we'd kiss for hours."
    b_ "He used to fuck me senselessly giving my body what it needed."

    b_ "But recently our alone time together was turning into a more romantic one. "
    scene v18-116
    b_ "He'd kiss me gently, caress my body and whisper sweet words like he wanted to be with me forever. "
    b_ "The contrast between the softness of my touch and the hardness of his muscles created a tantalizing sensation, awakening desires that had long been dormant."
    b_ "With an instinctive touch, my fingers would trail gently over Polad's smooth, bald head every time we were together."
    b_ "The sensation of his bare scalp under my fingertips created a unique connection between us, a silent language that transcended words."
    scene v18-117
    b_ "In the soft glow of the room, Polad's arms would envelop me from behind as we stood in front of the mirror."
    b_ "His embrace was warm and secure, grounding me in the present moment."
    b_ "In those intimate seconds, we would exchange sweet nothings, whispered words that hung in the air like delicate promises."
    scene v18-118
    b_ "He'd kiss my neck and promise me a lot of nice things."
    b_ "Our reflections in the mirror seemed to amplify the tenderness of the moment."
    b_ "Polad's deep voice would caress my ears, speaking words that melted my heart."
    b_ "He'd tell me I was beautiful, that he cherished me, his words weaving a cocoon of affection around us."
    b_ "In return, I would express my gratitude, my voice barely a whisper."
    scene v18-119
    b_ "In a tender moment in front of the mirror, Polad gently untied my hair, letting it cascade down my back like a silken waterfall."
    b_ "His fingers combed through the strands, and he whispered:"
    scene v18-120
    b_ "You're breathtaking, Banu. You don't need to hide your beauty behind a hijab."
    b_ "His words carried a sincerity that resonated within me, erasing the need for the traditional veil."
    b_ "Feeling the weight of my hijab lift, I let it go, allowing my hair to flow freely."
    scene v18-121
    b_ "Polad's encouragement became my catalyst for change."
    b_ "His acceptance of my true self emboldened me, freeing me from the confines of societal expectations."
    b_ "I was ready to go public with my hair open without worrying what other people think about me."
    b_ "With Polad's support, I embraced my newfound freedom, not just in my appearance but also in my choices. "
    b_ "In the depths of my being, I felt a strange emotion stirring whenever I was around Polad."
    b_ "There was a genuine warmth in his gestures and a kindness in his eyes that made my heart flutter. "
    b_ "Despite these feelings, I couldn't deny the restlessness within me."
    scene black with dissolve
    b_ "The world felt vast and thrilling, and I, still young at heart, hungered for adventures beyond the confines of any one relationship."
    b_ "Love for Polad coexisted with my desire for exploration, a dichotomy that I grappled with every day."
    scene v18-122
    play music "audio/sidesex.mp3"
    b_ "I found myself in the arms of other men, drawn by the magnetic pull of the unknown."
    b_ "One evening, I found myself in Murat's luxurious house, standing in the grandeur of his entertainment room."
    b_ "The soft glow of the chandeliers illuminated the polished billiards table, inviting us to play."
    show banu_playing_billiards_animation
    ""
    scene billiards24
    b_ "The smooth surface of the table felt cool beneath my fingertips as I lined up my shot."
    b_ "Murat's laughter resonated in the room as we engaged in a friendly game, the clinking of the billiard balls filling the air."
    scene v18-123
    b_ "Flirting with Murat sent a rush of excitement through me, an intoxicating blend of desire and guilt."
    b_ "I felt so sexy and alive with my fresh new hair style."
    b_ "My heart felt a pang of remorse for Polad, the man who had brought both stability and passion into my life."
    scene v18-124
    b_ "Yet, in Murat's presence, those feelings were momentarily overshadowed by the allure of something new, something different."
    b_ "I started touching his crotch and caressing his naked body."
    b_ "Guilt gnawed at the edges of my conscience, reminding me of the affection I held for Polad. "
    b_ "However, the thrill of flirting, the anticipation of the unknown, drew me in like a moth to a flame."

    b_ "I remembered the times Murat fucked me in this same room using all my holes."
    b_ "I remembered my voice being echoed in that room from the pleasure coming from my asshole."
    b_ "I remembered how Murat used my asshole and made me addicted to it. I wanted it again..."
    scene v18-125
    b_ "Soon after I found myself on top of Murat on the billiards table and his cock inside of my ass."
    b_ "The moments with Murat stretched into the night, Polad's memory slowly faded into the background."
    scene v18-126
    b_ "I loved the feeling. The mixture of pain and pleasure melted my brain."
    b_ "In that fleeting moment, my guilt seemed distant, overshadowed by the overpowering allure of the present."
    b_ "I was getting fucked in the ass over and over by Murat's beautiful dick."
    scene v18-127
    b_ "Looking into my eyes he fucked my ass for hours without getting tired."
    b_ "I loved that the young man appreciated my beauty. I loved being appreciated and wanted despite him being much younger than me."
    scene v18-128
    b_ "I reached orgasm for several times stimulated both from my ass and pussy."
    b_ "I was surprised by Murat's stamina. He was hungry for me and didn't intend to finish soon. "
    scene v18-129
    b_ "I found myself entangled in the excitement of the evening, losing track of time and, momentarily, my worries."
    b_ "Being with a younger and more energetic man like Murat was a revelation."
    b_ "He gave me so much pleasure that I didn't feel in a long time."
    scene v18-130
    b_ "Being with him made me feel younger. He made my face expressions change. He made my woman spirit feel good."
    b_ "Being with Murat, I reveled in the thrill of his presence, savoring the magnetic pull of his youthful charm."
    b_ "It was a reminder that life, no matter how complex or challenging, could still surprise and delight."
    b_ "In his arms, I found a temporary escape from the burdens of the world, embracing the joy of the present moment and cherishing the excitement of a love that knew no boundaries."
    scene black with dissolve
    b_ "There was an inexplicable tension between Nesrin, Polad's wife, and me."
    b_ "I couldn't quite put my finger on it, but there was an undeniable undercurrent of something unspoken whenever we were in the same room."
    b_ "I couldn't shake off the feeling that Nesrin might be aware of the relationship between Polad and me, although I had never suspected her to know the truth."
    scene v18-131 with dissolve
    b_ "A strange excitement seemed to linger in the air whenever our eyes met."
    b_ "I noticed Nesrin's gaze lingering on my body, her eyes tracing the contours as if trying to decipher a hidden secret."
    b_ "It was a curiosity that didn't escape my notice, leaving me both intrigued and apprehensive."
    scene v18-132
    b_ "One night, as fate would have it, I found myself alone with Nesrin in a room."
    b_ "We stood there, both dressed in nothing more than our nightwear, the silence pregnant with unspoken words."
    b_ "There was an intensity in her eyes, a depth of emotion that left me both intrigued and uneasy."
    b_ "We began to talk, the conversation skirting around the unspoken truths that hung heavily between us."
    scene v18-133
    b_ "In the midst of all the complexities and unspoken tensions, something unexpected and beautiful bloomed between Nesrin and me. "
    b_ "Despite our situations being incredibly complicated, there was a connection that felt deeper than friendship."
    b_ "We began to develop feelings for each other that were hard to put into words."
    scene v18-134
    b_ "In our quiet moments together, there was a comfort, a mutual understanding that we couldn't explain."
    b_ "These moments were filled with passion, kisses, touches and passionate sex."
    scene v18-135
    b_ "I appreciated her beautiful feminine body and she appreciated mine."
    b_ "It was as if we just clicked, as if our hearts recognized something special in each other. "
    b_ "It was different from a man's body...softer and delicious."
    scene v18-136
    b_ "I licked every inch of her body making her moan loud."
    b_ "Love, in its most unexpected form, started to grow between us."
    b_ "These emotions were delicate, like the petals of a fragile flower."
    b_ "It was a love that existed quietly, away from the eyes of the world."
    scene v18-137
    b_ "We were both naked and giving pleasure to each other...without any dicks or any penetration."
    b_ "Our hearts beat in harmony, and the unspoken understanding between us carried a sense of affection and empathy."
    b_ "It was a love that didn't fit into any neat boxes, one that went beyond what society might expect."
    scene v18-138
    b_ "Nesrin was so eager to make me feel good."
    b_ "She wanted to return the favor so quickly."
    scene v18-139
    b_ "In each other's presence, we found a sense of peace."
    b_ "Despite the challenges we faced, our feelings for one another became a source of comfort, a light guiding us through our complicated lives."
    b_ "It was a love story that felt real and genuine, promising warmth and acceptance despite the complexities of the world we lived in."
    scene v18-140
    b_ "Discovering love and intimacy with Nesrin, a woman, felt remarkably different from any experience I had had with a man before."
    b_ "There was an inexplicable tenderness in our connection, a softness that seemed to embrace my very soul."
    scene v18-141
    b_ "In her arms, I found a sense of understanding and empathy that transcended the boundaries of gender."
    b_ "Being with a woman brought a unique depth of emotional intimacy, a level of connection that felt profoundly enriching."
    scene v18-142
    b_ "In Nesrin's presence, I discovered the beauty of love unconstrained by traditional norms. "
    b_ "There was a freedom in our relationship, a sense of acceptance that allowed me to explore my desires and emotions without inhibition. "
    b_ "It felt liberating to be with someone who understood the intricacies of a woman's heart, who could navigate the complexities of my soul with such grace."
    scene black with dissolve
    b_ "In the wake of my newfound freedom and self-discovery, I continued to explore my sexuality with a sense of curiosity and liberation."
    b_ "The world seemed full of possibilities, and I embraced each experience as a chance to learn more about myself."
    scene v18-143
    b_ "One recurring encounter took place at a clothing store, where a particular male salesperson seemed to catch my eye every time I visited."
    b_ "There was an unspoken connection in our glances, a magnetic pull that drew me to him."
    b_ "With each visit, our eye contact grew more intense, sparking a silent understanding between us."
    scene v18-144
    b_ "Every time our eyes met, I felt a rush of warmth spreading through me, and my heart would skip a beat."
    b_ "There was an irresistible charm about him, an allure that made it impossible for me to look away."
    b_ "In his presence, I found myself melting, my defenses crumbling as I was drawn into the intensity of his gaze."
    b_ "His smile was like a spell, casting me under its enchantment, and I couldn't help but be mesmerized by his presence."
    scene v18-145
    b_ "During my last visit, a sense of boldness overcame me."
    b_ "I found myself winking at him, a playful gesture that spoke volumes without words."
    scene v18-146
    b_ "In that moment, I felt a rush of empowerment, a recognition of my own desires and the freedom to express them."
    b_ "It was a small yet significant step in my journey of self-discovery."
    b_ "With a heart pounding in my chest, I mustered the courage to invite the handsome man into the changing room."
    b_ "The air between us crackled with tension as I gestured for him to follow, a silent invitation that hung between us like a promise of something more."
    scene v18-147 with fade
    b_ "And the next thing you know is that I was sucking his big cock."
    b_ "I was surprised how he carried that big dick in his pants. It was enormous."
    b_ "I started giving myself to it to pleasure his big cock but of course I couldn't handle it properly. It was too big for my mouth."
    scene v18-148
    b_ "The mirror became a silent witness to the unspoken desires that passed between us, capturing every fleeting moment of vulnerability and anticipation."
    b_ "The world outside seemed to fade away, leaving only the two of us, entangled in a dance of longing and attraction."
    b_ "I was amazed by his dick. It was like I had won the lottery."
    scene v18-149
    b_ "I was so passionate. I wanted to surprise him with my skills."
    b_ "I grabbed him and took his dick as deep as I can in my mouth."
    b_ "My eyes instantly closed and I was choking but I didn't accept my defeat and continued sucking his dick so bad."
    scene v18-150 with fade
    b_ "And here's the result. He again surprised me with his huge load cumming on my face and mouth."
    b_ "For a moment I felt he wouldn't stop cumming. He messed up my face and filled my mouth with full of cum."
    scene v18-151
    b_ "I watched him with a victorious look on my messed up face as he threw his head back and closed his eyes from pleasure."
    b_ "I did it and I was proud of myself. "
    b_ "Once I was so preserved wife wearing hijab and covering my whole body so I didn't cause any reaction from the opposite gender."
    b_ "Now I was on my knees in the public changing room with another man's cum dripping from my face."
    b_ "That was a big transformation but I didn't feel any guilt anymore."
    scene black with dissolve
    stop music
    b_ "In a twist of fate, I found myself entangled with Mahmud, the older man who had promised to help me find my birth mother. "
    scene v18-152
    b_ "His connection to Hicran, my friend, had initially given me hope."
    b_ "Mahmud, driven by his own hidden desires and secrets, offered to take me to a room where he claimed my mother had once stayed."
    scene v18-153
    b_ "As we entered the room, the atmosphere grew heavy with the weight of the past."
    b_ "Mahmud's promises seemed to dissolve into darkness when he revealed a horrifying truth:"
    scene v18-154
    b_ "My mother had been involved in a tumultuous affair with him, and she had been a sex worker."
    b_ "The revelation hung in the air like a bitter truth, shattering the image I had held of my long-lost parent."
    scene v18-155
    b_ "In a cruel twist, Mahmud's intentions took a sinister turn."
    b_ "The room that had held the promise of answers soon became a place of danger."
    scene v18-156
    b_ "Mahmud, consumed by his own demons, attempted to violate me, his actions a cruel betrayal of the trust I had placed in him."
    b_ "In that moment, my world collapsed around me. The hope of finding my mother was replaced by a stark reality, a truth that left me vulnerable and broken."
    b_ "The shadows of the past came to life, revealing a darker side to the people I had once believed in."
    scene v18-157
    b_ "I wanted to escape but Mahmud was quick to push me onto the bed and take off his top. "
    b_ "I was so afraid. That feeling never happened to me before. Despite being old Mahmud had a man's power that I was weak to confront."
    scene v18-158
    b_ "He pinned my hands to the bed with his hands and started licking my body."
    b_ "Despite I was afraid my body reacted to his licking."
    b_ "My nipples were stiff and my pussy was already wet."
    scene v18-159
    b_ "He licked every inch of my chest his saliva running down my chest revealing my breasts and raising my skirt."
    b_ "In a moment of sheer terror and desperation, I summoned every ounce of strength within me."
    b_ "With adrenaline surging through my veins, I managed to break free from Mahmud's grasp."
    scene v18-160
    b_ "Instinctively, I brought my knee up with all my might, striking him in his most vulnerable spot."
    b_ "The impact sent Mahmud reeling in pain, doubling over and gasping for air."
    b_ "Seizing the opportunity, I sprinted away from that nightmare, my heart pounding in my chest as I fled from the room of horrors."
    scene black with dissolve
    b_ "I was desperately in need of money."
    b_ "That reminded me Polad's offer about working in his bar."
    scene v18-161 with irisin
    b_ "I walked into Polad's bar wearing clothes that were a bit more daring than my usual style."
    b_ "The fabric clung to my body, reflecting a newfound confidence I hadn't known before."
    scene v18-162
    b_ "Polad greeted me with a friendly smile, his eyes taking in my changed appearance. "
    b_ "We talked about the job he had offered me, blending work discussions with personal chit-chat amidst the lively atmosphere of the bar."
    b_ "Polad's presence next to me made me feel supported, encouraging me to face the challenges ahead with determination."
    b_ "Our conversation was easy and natural, touching on work matters and more personal topics."
    b_ "Polad's encouragement made me believe in my capabilities, giving me the strength to embrace this new phase of my life."
    scene v18-163
    play music "audio/action.mp3"
    b_ "I met Natasha, one of Polad's workers, a lively and curvy blonde girl from Russia."
    b_ "Despite her short stature, she exuded confidence and charisma. "
    b_ "Together, we embarked on the task of delivering beers to the customers at the bar."
    scene v18-164
    b_ "As we weaved through the crowd, balancing trays of frothy beers, Natasha and I developed a rhythm."
    b_ "Her quick wit and infectious laughter made the job feel lighter, and we navigated the busy bar with ease."
    b_ "The customers welcomed us with smiles, appreciating our efficiency and cheerful demeanor."
    scene v18-165
    b_ "In those moments, amidst the buzz of the bar, I discovered a sense of belonging."
    b_ "Working alongside Natasha, I found joy in the simple act of serving drinks, connecting with people, and embracing the lively atmosphere of the bar."
    b_ "Engaging with the customers at the bar became more than just a job for me – it turned into a delightful experience."
    scene v18-166
    b_ "I found genuine enjoyment in striking up conversations, sharing jokes, and making small talk with the patrons."
    b_ "Every interaction was a chance to connect, to learn about their lives, and to share a moment of laughter. "
    b_ "Whether it was a funny anecdote, a witty remark, or a simple smile, these interactions added a lively and friendly vibe to the bar."
    scene black with dissolve
    b_ "But one day I met a customer who interrupted the peace of my daily routine."
    scene v18-167 with dissolve
    b_ "Meeting Vasif, a customer I had once shared a passionate night with, sent a jolt through me."
    b_ "He was a friend of Murat, and the memories of that unforgettable evening rushed back, creating a cocktail of emotions within me."
    scene v18-168
    b_ "As our eyes met, a wave of desire and nostalgia washed over me."
    b_ "I felt a mix of excitement and apprehension, uncertain about how this unexpected reunion would unfold."
    b_ "The chemistry we had shared that night with Vasif and Murat lingered in the air, a silent reminder of the connection we had once explored together."
    b_ "In that moment, my mood shifted, my heart racing with anticipation."
    scene v18-169
    b_ "He had changed. His hairstyle was different but his athletic muscular body was the same."
    b_ "I could clearly see his big muscles through the blue shirt. "
    b_ "The memories of our past encounter played like a movie in my mind, adding a layer of complexity to our present interaction."
    b_ "I could never forget his giant dick destroying my body that night."
    b_ "As my dress was a bit transparent I felt vulnerable and defenseless in front of Vasif's eyes."
    b_ "I chose that dress to please Polad's customers and make them satisfied but I never knew I'd end up in this situation."
    scene v18-170 with fade
    stop music
    b_ "In the room, Vasif and I found ourselves alone, the air thick with tension and unspoken desires."
    b_ "As he stood up and approached me, my heart raced, unsure of his intentions."
    b_ "We exchanged words, his persuasive tone urging me to accompany him to the restroom."
    scene v18-171
    b_ "I hesitated, feeling a sense of discomfort wash over me."
    b_ "I declined his invitation, my voice firm in my refusal."
    b_ "But Vasif was insistent."
    scene v18-172
    b_ "He reached out and grabbed my hand, his grip firm, preventing me from leaving."
    b_ "Panic fluttered in my chest, a mix of fear and defiance fueling my reaction."
    b_ "In a moment of vulnerability, Vasif's persuasive words managed to break down my defenses."
    b_ "Despite my initial hesitation, I found myself reluctantly agreeing to accompany him to the restroom."
    scene v18-173 with fade
    b_ "His charm and persistence had chipped away at my resolve, leaving me feeling unsure and conflicted."
    b_ "As we made our way to the restroom, a mix of emotions swirled within me – apprehension, curiosity, and a lingering sense of doubt."
    b_ "I questioned my decision even as I followed him, my steps hesitant and my mind racing with uncertainty."
    b_ "But at one point I knew that he was going to fuck me and I stopped resisting..."
    scene v18-174 with fade
    b_ "Soon after I was bending over in the toilet and his horse cock was again inside of my vagina."
    b_ "My pussy instantly remembered the feeling of pleasure from that night."
    b_ "At some point I couldn't stop my moaning and I didn't care if Polad or other workers could hear me."
    scene v18-175
    b_ "His dick was destroying me. His body was shaking me with each powerful thurst and his balls slapping my pussy."
    b_ "I admired his genetics. He was so big and powerful despite being so young."
    b_ "As I looked at him, I couldn't help but admire his physique – his muscles, the result of what seemed like perfect genetics."
    scene v18-176
    b_ "As he raised my leg I felt his whole shaft deep inside of my womb and I was afraid that he could do damage to my inside for being that deep inside. "
    b_ "His physicality was undeniable, and for a moment, I found myself captivated by the sheer strength he exuded."
    b_ "I couldn't stop cumming on his dick while he was fucking me without break."
    scene v18-177
    b_ "With each thurst I felt like I was going to break."
    b_ "Vasif showed me how much I could take."
    b_ "The slapping sounds covered the whole rooms."
    scene v18-178
    b_ "It was in that moment, amidst the intimate confines of the restroom, that I realized the power of desire – how it could cloud judgment, blur boundaries, and lead us into uncharted territory."
    b_ "His hard pounding melted me. His touch felt electric, sending shivers down my spine as our bodies pressed against each other."
    b_ "The world outside the restroom ceased to exist, and we were consumed by the heat of the moment."
    scene v18-179
    b_ "His giant cock was destroying the insides of my belly."
    b_ "It was deforming the shape of my belly. It felt like it was going to pierce through me."
    b_ "With every push, I felt a rush of sensations, a heady mix of longing and pleasure that clouded my thoughts and heightened my senses."
    scene v18-180
    b_ "In the hushed confines of the restroom, I surrendered myself to the allure of Vasif's touch, embracing the intoxicating dance of intimacy and vulnerability."
    b_ "The walls I had built around me crumbled, and I found myself immersed in the intoxicating chemistry we shared."
    b_ "It was a moment of abandon, a passionate surrender to the irresistible force of desire."
    scene v18-181
    b_ "My insides were already in the shape of his cock."
    b_ "He was spoiling me."
    b_ "In that fleeting moment, I allowed myself to be enveloped by the fervor of the connection, embracing the raw, unfiltered emotions that coursed through me."
    b_ "It was a surrender that left me breathless, a reminder of the complexity of human desire and the allure of forbidden indulgence."
    scene v18-182
    b_ "As Vasif stopped pounding my pussy, I came to my senses."
    b_ "I couldn't help but draw comparisons between him and Polad, the man who had given me a job and a sense of security."
    b_ "As Vasif's cock punished and satisfied me, I found my thoughts drifting back to Polad, the person who had supported and empowered me."
    b_ "Conflicted emotions swirled inside me. Polad had offered me stability and a job, and yet here I was, getting fucked by Vasif in a moment of intense desire."
    b_ "In that moment, I grappled with my feelings for both men. Polad represented stability, security, and a sense of belonging."
    b_ "Yet, Vasif awakened a different side of me, a side that craved adventure and embraced the thrill of the unknown."
    b_ "As Vasif's hands traced patterns on my skin, I couldn't help but wonder how Polad would feel about this forbidden encounter."
    b_ "The thought of Polad's reaction sparked a mix of excitement and guilt, a tumultuous blend of emotions that only added to the intensity of the moment."










    scene black with Dissolve(3)
    ""
    centered "{size=+120} Relationship with Polad {/size}" with Fade(0.5, 0.5, 5)


    $ banusuckpoladcockmountain = False
    $ banuletpoladteachherbike = False
    $ banuflirtwihguysdancing = False
    $ banuflirtwihguysbar = False
    $ banutrustpoladbuilding = False
    $ banustayandtalksellerpolad = False
    $ banudominatepolad = False
    $ threesomemahmudmurat = False



    play music "audio/intro.mp3"
    scene black with dissolve
    "..."
    "After breaking up with Kamil, Banu begins living with Polad and his wife, Nesrin."
    "She starts working in Polad's bar, serving customers and slowly letting go of her previous religious lifestyle, including no longer wearing the hijab."
    "Banu embraces her newfound freedom and begins to explore her desires."
    "She has a sexual relationship with Polad, who was her late husband Alper’s best friend."
    scene v22-1 with dissolve
    play music "audio/story_1.mp3"
    "Polad decided they both needed a break from the chaos of work. One afternoon, he took Banu out for a ride on his motorcycle. "
    "Banu clung to him, feeling the cool wind whip around them, her arms tight around his waist."
    "They were both dressed in biker outfits, black leather jackets and boots, ready for the adventure ahead."
    "Polad had told her they were heading to the mountains, far away from the stress and noise of the city."
    b "Are you sure we’re not gonna crash into something?!"
    p "You said you wanted to feel alive, right? Hang on, we’re just getting started!"
    p "Wait till we hit the mountains!"
    b "Then let’s go faster!"
    p "As you wish!"
    scene v22-2 with fade
    "Banu felt free, the city fading behind them as they drove further into the wild. "
    "She was no longer the woman she once was—reserved, confined by rules and expectations. "
    "Now, riding behind Polad, the thrill of the open road ahead of her, she knew she could finally be herself."
    "This ride wasn’t just an escape; it was a symbol of her new life—a life without limits, without fear."
    scene v22-3 with fade
    "As they rode deeper into the forest, the wind teasing Banu’s hair, she leaned forward, her lips brushing close to Polad’s ear. "
    b "You’ve got me all to yourself out here."
    p "You know that you are mine. You've always been."
    b "Very confident, aren't you?"
    scene v22-4
    b "I almost had an orgasm from that ride alone... The thrill... the speed..."
    p "I guess I’ll have to push it even harder next time."
    b "If you go any faster, I won’t make it until we stop."
    p "Maybe that’s the plan."
    b "Or maybe you’re planning to pull over and fuck me right here in the forest."
    p "Tempting..."
    p "But you’ll have to wait till we hit the mountains."
    scene v22-5 with fade
    "As they reached the top of the mountain, Banu clutched onto Polad tighter than ever, her heart racing with a mix of fear and excitement."
    "The steep cliffside roads had her breathless, but the view was stunning, vast stretches of wilderness below them. "
    "The ride had been wild, faster and more dangerous than she’d ever imagined, and now, at the peak, she couldn’t tell if the pounding in her chest was from terror or exhilaration."
    scene v22-6
    b "You’re insane... that was... I thought we were gonna fall off the edge!"
    p "Told you I’d take you higher than you’ve ever been."
    b "You weren’t kidding! I... I can’t even think straight... that was so... crazy!"
    p "Crazy’s what makes life worth living, right?...And we’re not done yet."
    b "I don’t know if I can handle more..."
    scene v22-7 with fade
    "As they climbed even higher, the path beneath them narrowed, barely wide enough for the bike to pass."
    "Banu’s heart pounded in her chest, every sharp turn making her gasp as they wound their way around the towering cliffs."
    "The mountain air grew colder, the wind harsher, but Polad didn’t slow down. The thrill of the climb mixed with a dangerous excitement that left her breathless."
    b "Polad, we’re so high up!"
    p "You said you wanted more. This is it."
    b "I don’t know if I can take this... it’s insane!"
    p "We’re not even at the top yet. Just hold on, Banu. You’re about to see what real freedom feels like."
    scene v22-8 with fade
    stop music
    "Polad brought the bike to a stop, but not before the motorcycle slid onto its side."
    "Banu jumped off, her heart pounding even harder now, the mix of adrenaline and fear still buzzing through her."
    scene v22-9
    play music "audio/softromanticsex.mp3"
    b "Polad!"
    b "That was..."
    p "I know. But we made it, didn’t we?"
    b "I thought we were gonna crash for real this time."
    "They were completely alone, no one around for miles. Her pulse quickened again, but this time it wasn’t just from the danger of the ride."
    b "This is....this is just beautiful..."
    b "You brought me all the way up here for this....now what?"
    p "Now we see just how far you’re willing to go for the next thrill."
    scene v22-10 with fade
    "Banu walked ahead, the wind whipping through her hair as she took in the breathtaking view of the mountains. "
    "The sky stretched endlessly above them, and the vast landscape below seemed so far away. "
    "She felt on top of the world, invincible. The danger of the ride had left her shaken but alive in ways she hadn’t experienced before."
    "Polad followed behind her, shirtless now, his tattooed back exposed to the elements."
    "He watched her, his eyes dark with intensity as she took in the beauty of the moment. There was a confidence in her steps now, a sense of freedom he hadn’t seen in her before."
    scene v22-11
    p "Out here, there are no rules. No limits."
    b "I’ve never felt this way before."
    p "That’s because you’ve never let go like this."
    p "Now that you have... there’s no going back."
    "Banu stood at the edge of the mountain, arms outstretched, feeling the cool wind rush past her, lifting her hair and filling her lungs with the crisp, fresh air."
    scene v22-12
    "Her eyes closed, she tilted her head back, overwhelmed by the sheer majesty of the world spread out before her."
    "Polad watched her from behind, his intense gaze fixed on her as she embraced the moment."
    "He could see the transformation in her, the woman she was becoming."
    "She had let go of her fears, her restraints, and now stood fearless at the peak of the world."
    scene v22-13
    p "You look incredible up here...Wild... free... just like I knew you would be."
    b "Is that what you wanted to see? To watch me let go, to push me higher?"
    b "I’ve never felt this kind of thrill before, Polad."
    b "And now, being up here, with you… I don’t want it to end."
    p "There’s so much more I can show you."
    scene v22-14 with fade
    "Banu turned around and her gaze fell upon Polad, shirtless, his muscles glistening in the bright mountain light."
    "Polad’s eyes were intense, darker than usual, and his voice low as he stepped closer. "
    p "Banu...I can’t keep this inside anymore."
    b "What are you talking about, Polad?"
    p "I’ve been fighting it for so long, but it’s impossible. I’ve tried to stay loyal to Alper’s memory, to Nesrin… but I can’t ignore it anymore."
    scene v22-15
    p "I love you, Banu."
    p "Before Alper, before Kamil… it’s always been you. I just never said it because of Alper… and now, I can’t hold it in anymore."
    b "So… you love me, huh? Took you long enough to say it."
    p "I’ve been trying to keep it to myself...But it seems you’ve been driving me crazy this whole time."




    jump banu_mountain_polad













label banu_mountain_polad_continue:



    b "I can't believe we actually did that here. This will be one to remember."

    p "Maybe next time I’ll throw in a picnic too—complete with a blanket and wine."

    b "You? Plan a picnic?"

    p "Hey, I can be romantic! Just might need a little... guidance."

    p "Ever thought of taking the wheel yourself, Banu?"

    b "Me? Ride this beast? No way, I’d probably end up taking us off a cliff!"

    p "Come on, it’s not that bad. I could teach you. It’s fun, you’ll see."

    scene v22-59

    b "Are you serious?"
    p "Come on, let me teach you how to ride this thing."
    b "First, you nearly kill me with your big cock, and now you want to throw me on this death machine? You really are trying to finish the job today, huh?"
    p "Death machine? This is a work of art. Besides, you handled me just fine earlier. I think you can handle a bike."


    menu:
        "It's too dangerous":

            $ banuletpoladteachherbike = False
            $ renpy.block_rollback()

            p "Come on, Banu. You can do this."
            b "Polad, I said no. I’m not doing it. It’s too dangerous."
            p "Dangerous? Banu, you’ve done things today that most people wouldn’t even dream of. And now you’re afraid of learning something new?"
            b "Yes, Polad, I am. I’ve been through enough today, and I don’t need another adrenaline rush, thank you very much."
            p "You’re not even willing to try? I thought you trusted me."
            b "This isn’t about trust, Polad. It’s about me not wanting to risk my life again today just because you think it’ll be fun."
            p "Fine. If that’s how you feel, then forget it."
        "Trust Polad":





            $ banuletpoladteachherbike = True
            $ renpy.block_rollback()

            p "Come on, Banu. You can do this."

            b "Fine. But if we end up in a hospital, you're explaining it to Leyla."
            p "Deal. But trust me, you’ll thank me once you feel the wind in your hair. Come on, sit in the front."
            scene v22-60 with fade
            play music "audio/story_1.mp3"
            b "This already feels wrong. Are you sure this thing won't throw me off?"
            p "Not unless you try to fight it. The bike’s like me—powerful, but easy to control if you know what you’re doing."
            b "Easy to control, huh? That’s not how I remember you."
            p "Shhhh...take this easy."
            b "Easy for you to say. You’re not the one who might crash into a rock."
            scene v22-61
            p "That’s why I’m here. Now, twist this throttle—gently—to give it some gas. But don’t panic if it roars, okay?"
            b "Oh my God! It sounds like it’s angry at me!"
            p "That’s not anger, Banu. That’s excitement. The bike’s just like me—it loves when you take charge."
            scene v22-62 with fade
            p "Alright, now put your feet up and let it roll forward slowly. I’m right here. You’ve got this."
            b "It’s moving! Oh no, it’s moving!"
            scene v22-63 with dissolve
            p "That’s kind of the point, Banu. Now keep it slow and steady. Don’t look down, look where you want to go."
            p "This feels insane! People actually enjoy this?"
            scene v22-64
            p "You’re doing great. Next, we’ll work on speeding up. Or maybe even popping a wheelie—"
            b "Don’t even joke about that, Polad!"
            p "You've done well, Banu. But you know, every lesson has its price."
            b "And what's the price this time?"
            p "A kiss. Not just any kiss—a deep, greedy one. You owe me that much for getting you this far without a scratch."
            b "You're terrible, Polad. Making me do this..."
            p "I know you like it. Now stop talking and pay your dues, Banu."
            scene v22-65
            stop music
            $ renpy.sound.play("voices/kissing.mp3", loop=True)
            b_ "His kiss wasn’t soft or tentative—it was raw, overwhelming, and utterly possessive. His tongue slid past my lips, teasing, tasting, and completely taking control."
            b_ "I couldn’t stop the moan that escaped me."
            b_ "I couldn’t breathe—not because I needed air, but because his kiss stole everything."
            b_ "A low whimper escaped me as my legs trembled beneath me. My thighs clenched instinctively, trying to suppress the unbearable ache building between them. "
            b_ "I gasped into his mouth, feeling the heat climb higher, faster, unstoppable."
            b_ "I was losing myself completely. My body was betraying me, trembling, aching, desperate."
            scene black with dissolve
            stop sound
            b_ "And then he pulled back, just enough for his lips to hover over mine, his breath hot against my skin. My eyes fluttered open, dazed, lips swollen and wet from his kiss."
            b_ "I couldn’t help but gasp, my voice a trembling whisper. "
            b_ "I almost came just from that."
            b_ "My heart pounded as I clung to him, feeling completely undone, my body still trembling from the kiss. God help me, I didn’t want him to stop. Not now. Not ever."
            "...."

    scene black with dissolve

    stop music 
    stop sound



    "...."
    "Polad and Banu returned back to the city and had fun like crazy until they ended up in a night club and started dancing among people."
    b_ "As we stepped into the nightclub, the pounding bass hit me like a physical force, and the flashing lights made everything feel surreal."
    scene v22-66 with blinds
    play music "audio/club.mp3"
    b_ "Polad’s hand was wrapped firmly around mine as he led me through the sweaty crowd."
    b_ "The air was thick with the smell of alcohol, sweat, and the faint tang of something illicit."
    b_ "It was wild—people grinding against each other, drinks spilling, bodies moving to the beat like they had no care in the world."
    b_ "Polad grinned at me, his teeth flashing under the strobe lights. He didn’t wait for a response before dragging me to the middle of the dance floor."
    b "I don’t even dance!"
    p "You don’t need to know how."
    p "Just move that gorgeous body and let everyone watch."
    scene v22-67 with fade
    p "You dance like you fuck—like you know exactly what you’re doing."
    b "And you don’t? You look like you own this place."
    p "Maybe I do. But tonight, it’s ours."
    p "You’re the sexiest thing in here, Banu. Every guy in this place is wishing they were me right now."
    scene v22-68
    b "Oh, please. You’re so full of yourself."
    b_ "We danced like we didn’t care who was watching, like it was just the two of us in the whole damn club."
    b_ "He spun me around, pulled me closer, whispered dirty things in my ear that made my cheeks burn and my body heat up."
    b_ "By the time another song started, I was breathless, my head spinning—not from the alcohol, but from him."
    scene v22-69
    b "You’re going to get us kicked out."
    p "Let them try."
    b "You’re insane..."
    p "And I’m just getting started."
    scene v22-70
    b "What the hell are you doing?"
    p "I’m showing these amateurs how it’s done. And you are not bad yourself."
    b "This is how you’re supposed to dance. Not whatever that was you were doing earlier."
    p "Is that so? Then show me more, Banu. Teach me how the queen of the dance floor moves."
    b "You couldn’t handle it, Polad. I’d leave you in the dust."
    scene v22-73 with fade
    "As the music thumped in the background, Polad and Banu found themselves at the bar, drinks in hand, their laughter drowning out the chaos around them."
    "As the night stretched on, the drinks kept coming, and neither Polad nor Banu was in the mood to slow down."
    "The bar counter became their battlefield, with empty glasses piling up like trophies of their steadily growing intoxication."
    "Banu downed her shot of tequila, slamming the glass onto the counter with a triumphant grin."
    scene black with dissolve
    b "That’s five in a row. I’m still standing. Your turn, tough guy."
    b "...."
    scene v22-71 with fade
    "Banu stumbled back onto the dance floor, her hips already swaying to the beat as if the music had taken complete control of her."
    "Drunk as she was, Banu didn’t care about the stares or the crowd. She was in her own world now."
    "Throwing her hands in the air, she tilted her head back and laughed, a carefree, wild sound that cut through the pounding music."
    "Her body moved with abandon, every sway of her hips and flick of her hair radiating pure confidence and drunken joy. "
    scene v22-72
    "As Banu dances, feeling the buzz of the alcohol mingling with the throb of the bass, two guys make their way over to her."
    "They're all smiles and swagger, thinking they've got a shot. The first guy, a tall bloke with a cheeky grin, leans in close enough for Banu to smell the whiskey on his breath."
    scene v22-74
    guy1 "Hey gorgeous, care to share this dance?"
    b "Only if you can handle the heat, 'cause I dance like I live — full throttle and not for the faint-hearted."
    guy2 "And what if we promise to keep up? Maybe even show you a move or two?"
    b "Promises, promises! Let's see if you can move more than just your lips."
    scene v22-75
    guy1 "Why don't we skip the small talk? Me and my buddy here… we were thinking maybe you'd want to have some real fun tonight. You know, something unforgettable."
    menu:
        "Flirt with them":
            $ banuflirtwihguysdancing = True
            $ renpy.block_rollback()

            b "Unforgettable, huh?"
            b "What makes you think you can handle me?"
            guy1 "Trust me, we can handle you. We’re just wondering if you can handle us."
            b "You boys are ambitious. I like that..."
            b "But you’re going to have to try a lot harder than just some cheap pickup lines."
            guy1 "Oh, I can try harder. Why don’t we take this somewhere quieter, and I’ll show you what I mean?"
            b "Maybe I like the noise. Keeps things… interesting."
            "Neither of the guys noticed Polad approaching from behind, his eyes narrowing as he took in the scene."
        "Tell them off":





            $ banuflirtwihguysdancing = False
            $ renpy.block_rollback()
            b "Wow, that’s original. Do these lines actually work for you?"
            guy1 "You’d be surprised. But something tells me you’re different. Come on, we’re just talking about a little fun."
            b "I don’t know what gave you the idea I’m available, but let me clear it up for you: I’m not."
            guy2 "Hey, no need to get defensive. We’re just trying to have a good time."
            b "Why don’t you take your buddy and go try this act on someone else? Someone who’s actually interested."
            "Neither of the guys noticed Polad approaching from behind, his eyes narrowing as he took in the scene."





    scene v22-76 with hpunch
    play music "audio/action.mp3"
    "Polad's right leg moved with brutal precision as the night erupted into chaos."
    "The two men barely knew what hit them as Polad delivered a devastating right kick to the taller guy, sending him staggering backward."
    scene v22-77 with hpunch
    "The shorter one tried to throw a punch, but Polad ducked effortlessly."
    "Banu stood frozen for a moment, her eyes wide as she watched the scene unfold. "
    "She had never seen Polad like this—raw, primal, and completely in control. "
    scene v22-78 with vpunch
    "The short man managed to regain his balance and lunged forward, but Polad was faster."
    "He slammed his forehead into the guy's chest with a sickening crunch."
    b "Polad, that’s enough!"
    p "Tell your friend, the next time he thinks about laying a finger on a woman, he’ll lose that hand."
    p "Let’s go."
    scene v22-79 with fade
    b "You didn’t have to headbutt him, you know."
    p "He deserved worse. I went easy on him."
    p "You should’ve seen me at full force. This was nothing."
    b "You’re insane. What if they’d called security?"
    p "You liked it, didn’t you? Watching me knock those fools out for you."
    b "You’re impossible."
    p "And you’re mine."

    scene black with dissolve
    "..."
    "As they entered the house..."
    "The door shut behind them, and the silence of the empty home hit Banu harder than her drunken haze."
    "Her heels clacked unevenly on the hardwood floor as Polad locked the door and tossed his jacket on a nearby chair."
    "Banu stumbled slightly, still riding the wave of alcohol coursing through her veins."
    p "Careful."
    b "I’m fine..."
    "She groaned and turned on the shower, not bothering to undress fully before stepping in, letting the water soak her leather pants and all."
    p "You’re supposed to take the clothes off first"
    b "Shut up!"
    b "You think you’re so smart, don’t you? So perfect, always swooping in like some... knight in shining armor. Like I need you to save me."
    p "You don’t need me, huh? "
    p "You’re drunk, but this... this isn’t just the booze talking."
    b "What’s going on is you! You, Polad! You're married to Nesrin, you're my first husband’s best friend!"
    b "Alper’s shadow is everywhere, and I..."
    b "I can't love you! I won’t! It’s wrong!"
    p "And I think you’re afraid to admit that maybe, just maybe, you deserve to feel alive again."
    b "I hate you..."
    p "You hate that you can’t hate me. You hate that you love me."
    "as Banu sat on the bathroom floor in her soaked panties, topless and defiant, swaying slightly but still glaring up at him like she had a point to prove."
    p "Come on, wildcat..."
    stop music
    scene v22-80 with dissolve
    play music "audio/suspense.mp3"

    "Polad sighed, crouching down and scooping her up over his shoulder with an ease that only added to her frustration."
    b "Put me down, you caveman!"
    p "I’m not putting you down..."
    p "Not until you stop acting like a drunk, stubborn child. You’re going to bed, whether you like it or not."
    scene v22-81
    b "You can’t tell me what to do!"
    b "You think just because you’re strong and... ugh... annoyingly handsome, you can manhandle me? I’m not some doll you can toss around, Polad!"
    p "Oh, I know you’re no doll, Banu. Dolls don’t fight back like this. But you’re acting like a brat, and brats need to be handled."
    scene v22-81 with flash
    b "Ahhh..."
    b "Did you just... Did you just spank me?!"

    scene v22-82
    p "And I’ll do it again if you don’t calm down."
    b "You wouldn’t dare!"
    p "You’ve already seen what happens when you push me, Banu. Don’t test me."
    b "Polad, put me down! You don’t get to—argh!"
    scene black
    "With a heavy sigh, Polad walked to the bed and, without a word, tossed her onto the mattress."
    scene v22-83
    b "You brute!"
    b "You can’t just throw me around like I’m nothing! You’re married! MARRIED, Polad! How dare you touch me like this?"
    p "You done, or do you need a few more minutes to yell at me?"
    b "You think you can just walk in here, be... be all strong and... ugh! Confident and make me feel—"
    p "Make you feel what, Banu?"
    b "I feel nothing!"
    b "Nothing but regret for even letting you near me! You’re married, Polad! You shouldn’t even—"
    p "Banu."
    scene v22-84
    p "You’re drunk, and you’re tired. Stop fighting me and just admit what’s really bothering you."
    b "What’s bothering me is you! Thinking you can just... just do whatever you want! You’re not Alper. You’re not—"
    b "You're not my husband, do you understand?"
    p "Damn right, I’m not Alper."
    p "And that scares you, doesn’t it? Because you know how I make you feel, and it’s not something you can ignore."
    scene v22-85 with fade
    b "You think you’re so perfect, don’t you?!"
    b "You think you’re untouchable, that nothing I do matters! Well, let me show you how much I hate you!"
    "Before Polad could react, she swung her fist straight into his chest. The dull thud echoed through the room as her knuckles connected with his rock-solid muscles."
    "Polad didn’t even flinch; in fact, he barely blinked. He simply looked down at her with an amused expression, one brow raised as if to say, Really?"
    scene v22-86
    b "What the hell are you made of, stone?!"
    p "Stop before you really hurt yourself."
    "Before he could react, her hands were around his neck, her fingers squeezing with all the strength her petite frame could muster."
    "Polad just blinked at her, looking more amused than anything else."
    p "Are you… choking me?"
    p "Is this supposed to hurt?"
    b "Don’t talk! Just die already, you smug bastard!"
    p "If you’re trying to make me pass out, wildcat, you might need to work on your technique."
    scene v22-87
    b "You’re such a goddamn brick wall, Polad!"
    b "You think you’re so tough, huh? Like nothing in the world can touch you? Well, guess what? You’re not untouchable, you oversized egghead!"
    p "Go on...Get it all out."
    b "You’re just a motherfucker, Polad..."
    b "Eying someone else’s wife like some shameless bastard."
    b "What kind of man are you, huh? Is that what you do? Take what doesn’t belong to you?"
    p "You need to calm down now."
    b "You’re disgusting! A married man, playing with someone else’s heart!"
    b "And you know what? I’ll spit on your goddamn face for it! I swear I will!"
    scene v22-88 with hpunch
    play sound "voices/ah.mp3"
    b "Ahh.."
    "Polad’s patience snapped like a taut string, and before Banu could hurl another insult, his hand shot out and grabbed her throat, firm but controlled."
    "Her words died in her mouth as she was overwhelmed by the sheer force of his power. His grip wasn’t tight enough to hurt her, but it sent a clear message."
    b "Polad—"
    b "What... What are you gonna do to me?"
    p "What do you think I’m going to do, Banu?"
    b "You’re going to fuck me, aren’t you?"
    p "Is that what you think?"
    p "That I just want to fuck you?"
    b "Isn’t it true? You’re here, married, acting like you care, but all you really want is—"
    scene v22-89 with hpunch
    "She stiffened as she felt his strong hands on her shoulders, then gasped softly as he slid one hand up, wrapping it firmly but carefully around her neck."
    b "What are you—"
    p "You talk too much, wildcat."
    p "Always yelling, always fighting. But do you know what I see? A woman who wants to lose herself."
    p "A woman who wants someone strong enough to take control."
    b "I… I don’t—"
    p "Shhh...You don’t need to say anything. I can feel it. The way your body reacts when I’m this close... "
    p "The way you can’t stop trembling under my hands. You can lie to yourself all you want, Banu, but your body doesn’t lie."
    p "Every word you try to throw at me, every insult—it’s just you trying to hide how much you want me to touch you, to take you, to make you forget everything else."
    p "Now tell me, Banu... do you want me to stop?"
    scene v22-90
    stop music
    stop sound
    "Banu’s breath came in shallow, uneven gasps as Polad’s words washed over her, his hand firm on her neck, his presence overwhelming."
    b "I... I can’t fight this..."
    b "I can’t fight you."
    p "Then stop pretending. Say what you really want, Banu."
    b "I hate how much I want you, Polad. You drive me insane."
    b "I can’t live without you."
    b "Without your cock, without the way you make me feel. I need you to fuck me, Polad. I need you to make me forget everything else."
    p "Now that is the truth I’ve been waiting for."
    scene black with dissolve
    "Polad paused, his hand still cradling her jaw, as he noticed Banu’s trembling body begin to relax."
    "Laying her down gently, he pulled the blanket over her, making sure she was comfortable."
    "For a moment, he just stood there, watching her. The fire and fury that defined her were gone now, replaced by a vulnerability she rarely showed."
    "It made something inside him soften—a feeling he didn’t want to name but couldn’t deny."
    "Despite the chaos of the night, he felt an odd sense of calm settle over him. She was safe, here in his care, and for now, that was enough."

    centered "{size=+120} The next day {/size}" with Fade(0.5, 0.5, 5)
    "..."
    scene v22-92 with blinds
    play music "audio/kometaback.mp3"

    "The sunlight hit Banu’s face like a slap, dragging her out of a deep, restless sleep."
    "She groaned, her head pounding from the booze, her body heavy and sluggish."
    scene v22-91
    "As she blinked her eyes open, still half-dazed, she realized someone was standing near her bed."
    scene v22-93
    "It took a second for her vision to focus, but when it did, her heart nearly stopped."
    scene v22-94
    "There was Nesrin, standing stiff as a board, staring right at her."
    "Her face was stone-cold, but her eyes? They were sharp, bitter, and cutting through Banu like a knife."
    scene v22-95 with dissolve
    b "N-Nesrin… what happened…?"
    n "Moening. Sleep well?"
    b "What… what are you doing here?"
    n "I live here, remember?"
    n "The better question is, what the fuck are you doing, Banu?"
    scene v22-96
    n "You think I don’t see what’s been going on?"
    b "There’s nothing to see! You’re blowing this way out of proportion. Polad and I—"
    n "Polad and you what?"
    n "You’re just friends? Just coworkers? Spare me the bullshit, Banu."
    b "You don’t know what you’re talking about..."
    n "I’ve seen the way you two look at each other. The late-night conversations, the way he’s always hovering around you like a damn guard dog. You think that’s normal?"
    b "Alright, that’s enough. You’ve had your say. Now it’s my turn."
    n "Oh, really? And what exactly do you have to say that could possibly justify—"
    b "Justify what? Being in your house? Being someone Polad cares about? Let me tell you something, Nesrin—just because you’re his wife doesn’t give you the right to treat me like dirt."
    b "You think you’ve got it all figured out, but you don’t know shit about me or what I’ve been through. "
    b "You stand there acting all high and mighty, but where were you when Polad needed someone to talk to? When he needed support?"
    b "You’re too busy pointing fingers to see that you’ve been pushing him away!"
    n "That’s not—"
    scene v22-97 with fade
    b "You’re so wrapped up in your own bitterness that you’ve forgotten how to be a partner. "
    b "You don’t see how hard Polad tries to make things work, how much he sacrifices for you, because all you do is criticize and blame."
    b "You’re the one who came storming into my room like a jealous teenager, throwing baseless accusations at me instead of talking to your own damn husband."
    b "If you’re so insecure about your marriage, maybe you should be having this conversation with him, not me."
    "The room fell silent, the weight of Banu’s words hanging in the air. Nesrin stood frozen, her face pale and her hands trembling. "
    "For the first time, she had no comeback, no sharp remark. She just stared at Banu, completely stunned."
    stop music
    scene black with dissolve
    "..."
    "Banu moved quietly around the bar, the faint buzz of the neon sign outside humming in the background."
    scene v22-98 with move
    play music "audio/story_1.mp3"
    "The air was thick with the smell of stale beer and faint traces of cigarette smoke clinging to the old wooden furniture. "
    "Wearing her fitted white dress, which clung to her figure like a second skin, she leaned forward to grab the empty beer bottles left behind on the table."
    "The fabric of her dress stretched slightly, highlighting her curves under the flickering overhead light."
    scene v22-99
    "As she straightened up, she glanced over her shoulder at the door leading to the main bar, where faint sounds of laughter and conversation echoed."
    "The work felt endless tonight."
    "The absence of Polad's presence was palpable. Tonight, he wasn’t at the bar — off tending to some other business, leaving her to handle everything alone."
    "She found herself lingering over the work, her thoughts drifting. Her hands moved mechanically, stacking empty bottles and wiping down surfaces, but her mind was elsewhere."
    "Polad. His smirk, his deep, gravelly laugh, the way he’d always manage to tease her even when she was annoyed."
    b_ "Why do I care if he's not here? It’s not like he runs this place better than I do."
    "The truth was, the bar felt different without him. She’d catch herself glancing at the doorway, half-hoping to see him strut in."
    scene v22-100 with dissolve
    "Banu's hands froze mid-clean as Natasha's voice echoed from the doorway. Her sharp Russian accent carried an air of smug confidence, cutting through the silence like a blade."
    nat "Well, well, well Banu. Look at you, working so hard while Polad is out... handling business."



    jump banu_natasha








label banu_natasha_continue:












    scene v22-120 with fade
    play music "audio/story_1.mp3"
    nat "Oh, that’s priceless, hehe..."
    nat "You’re standing there naked, dripping wet, and you look like a deer caught in headlights. It’s adorable."
    b "Shut up, Natasha!"
    b "This is your fault! We were... we were—oh god, what were we thinking?!"
    nat "Clearly, you were enjoying it more than I was."
    scene v22-122 with fade
    "Banu scrambled to pull on her clothes as she muttered under her breath."
    b "I’m coming! I’m coming!"
    "Meanwhile, Natasha leaned casually against the wall still naked."
    scene v22-121
    nat "Better fix your hair, Banu! Wouldn’t want the customers to know how much fun you’ve been having back here."
    b "Natasha, shut up!"
    nat "Always so flustered. She makes it way too easy."
    "Natasha’s grin widened as she muttered under her breath..."
    nat "Bet she’s still dripping."
    nat "I wonder how long it’ll take her to calm down."
    scene v22-123 with fade
    "Banu hurried out of the back room, smoothing down her apron and trying to compose herself."
    "Her heart was still racing, her cheeks slightly flushed from the heated moment with Natasha."
    scene v22-124
    "Her mind raced as flashes of the nightclub came flooding back—the heated dancing, the confrontation, and Polad mercilessly kicking their asses."
    "It was them."
    scene v22-125
    "These were the same two men who had tried their luck with her on the dance floor, only to end up in a brawl with Polad."
    "The taller man noticed her hesitation and smirked, leaning back in his chair."
    guy1 "Well, Well, If it isn’t the dancing queen herself."
    guy2 "Small world, huh? Didn’t think we’d see you again so soon."
    b "I don’t know what you’re talking about."
    scene v22-126
    guy1 "Don’t tell me you forgot about us already. We had such a memorable time at the club. Well, until your boyfriend decided to get all... territorial."
    guy1 "You must’ve really been worth it for him to go all out like that."
    b "Are you going to order something, or are you just here to waste everyone’s time?"
    guy1 "Alright, alright. Relax. We’ll take a couple of beers, and maybe a smile next time."



    jump guys_banu










label guys_banu_continue:











    scene black with dissolve
    "Banu lay sprawled on her bed, her figure barely concealed by a thin, soft blanket that clung to her curves."
    scene v22-190 with dissolve
    "Her bare shoulder peeked out from the edge of the fabric, her smooth skin glowing in the morning light."
    "Her dark hair framing her peaceful face."
    scene v22-191
    "Banu stirred slightly, her body shifting under the thin blanket that barely covered her."
    "She let out a faint, sleepy sigh, her dark lashes fluttering as her eyes slowly opened, adjusting to the light."
    "Polad stood there, dressed in his usual jeans and a black T-shirt that hugged his muscular frame."
    "His eyebrow was raised, and a playful smirk danced on his lips."
    scene v22-192 with fade
    p "Well, good morning, Sleeping Beauty..."
    b "Polad! What are you doing in my room?"
    p "Your door was open, and I was curious if you’d decided to hibernate for the rest of the year. Turns out, you were just too lazy to wake up."
    p "You could have knocked..."
    p "And miss the sight of you looking like a burrito?"
    scene v22-193


    play music "audio/up.mp3"

    b "What do you want, Polad? Came to bother me, or is there an actual reason?"
    p "Both. Mostly to bother you. But also to remind you that breakfast isn’t going to eat itself."
    b "You’re impossible, you know that?"
    p "Come on, get up. Unless you’re planning to stay like that all day. Which, by the way, would be fine by me."
    b "Out. Now. Before I throw this blanket at you."
    p "Wait. Since Nesrin’s out for the day and you look like you could use some fresh air, I’m taking you shopping."
    b "You, Polad, are voluntarily offering to take someone shopping? What’s the catch?"
    p "No catch. Just figured you could use some new clothes since you’re so fond of lounging in blankets..."
    b "Fine. I’ll come. But only because I don’t trust you to pick out anything decent without me."
    p "Get dressed. I’ll be waiting downstairs. Don’t take too long, or I might leave you behind."
    b "I’m only coming because someone has to keep you in line..."
    p "Whatever you say, Banu. Just don’t spend all my money."
    scene black with dissolve

    "As they stepped into the next section of the boutique, Banu's eyes widened, taking in the rows of racks filled with delicate lingerie, handbags, and accessories."
    scene v22-194 with dissolve
    "Polad followed her gaze, raising an eyebrow as he realized what kind of section they’d wandered into."
    p "This just got interesting."
    b "What’s interesting is that you’re still standing here instead of waiting by the men’s section."
    p "I’m just here to supervise. Make sure you don’t end up with something ridiculous."
    scene v22-195
    b "Ridiculous? Please. You’d probably pick something neon with tassels."
    p "I wouldn’t be so sure. Here, let me help."
    scene v22-196
    b "What about this? Classy, understated, something Nesrin might approve of."
    p "Not bad. But aren’t we here for you, not Nesrin?"
    p "You’d look amazing in any of this… but especially this."
    b "Excuse me? Are you trying to pick out lingerie for me now?"
    p "Just saying. You’ve got good taste, but sometimes you need a second opinion."
    b "I don’t know, Polad. I think this might suit you better. Want me to grab your size?"
    b "Imagine walking around in this under your jeans. You’d feel so... liberated."
    p "Careful, Banu. You’re playing with fire."
    b "What are you going to do, Polad? Fold a pair of panties at me?"
    scene v22-197
    b "Ohhhh fuck Polad!"
    p "I told you to stop messing with me, now your pussy will pay for that."
    b "Please Polad, don't do this."
    p "Do you enjoy this huh?"
    b "Please, somebody can see us...ahh.."
    scene v22-198
    $ renpy.sound.play("voices/longhardmoan.mp3", loop=True)



    p "Your pussy is so hot and wet."
    b "Are you serious? Ohhh....You're touching me like that in a public store?"
    p "Fuck yes, you're a little slut and you enjoy this."
    b "I-I don't know what you're talking about... oh god this feels so good though..."
    p "Tell me. Do you want to cum?"
    b "Yes! Please fuck me with your fingers, Polad. Make me cum!"
    p "Not so fast..."
    stop sound

    scene v22-199 with fade
    $ renpy.sound.play("voices/kissing.mp3", loop=True)
    b "Polad—what are you—"
    "Banu began, but the words caught in her throat as he pushed open the door to an empty changing stall, pulling her inside with him."
    "The door clicked shut behind them, and the enclosed space suddenly felt electrified. "
    p "You’ve been driving me crazy all morning..."
    p "You think I’m just going to let you keep teasing me without doing something about it?"








    jump changing_room










label changing_room_continue:










    "...."
    scene v22-242
    play music "audio/story_1.mp3"

    "As Polad and Banu explored the sunglasses section, Polad picked up a sleek black pair and slid them on, glancing at himself in the mirror."
    scene v22-244
    p "What do you think? Secret agent vibes or just an average dude trying too hard?"
    b "I think you’re giving more ‘bouncer who moonlights as a spy’ than secret agent,"
    p "And you? Rocking the celebrity-on-a-budget look with those huge frames."
    scene v22-243
    b "Excuse me? These scream high fashion. I could easily walk down a runway with these."
    p "Sure, if the runway is in the middle of a flea market,"
    b "You’d better watch yourself. With these on, I’m officially too cool to hang out with you."
    p "Too cool, huh? Let’s not forget who just dragged you out of bed this morning to show you how to shop properly."
    b "You’re insufferable. But maybe I’ll let you pick something for me… just this once."
    scene v22-244
    p "Damn, I can't believe I fucked you in front of your husband, ex husband."
    b "Polad, please stop that...Don't talk about it please..."
    p "Your ass is damn tight...I should fuck it more often."
    b "..."
    scene black with dissolve
    "..."
    scene v22-245 with dissolve
    "As they settled into a cozy corner of the café, their coffees steaming on the table between them, Polad leaned back in his chair, studying Banu with an intrigued expression."
    scene v22-246 with fade

    p "You’ve always had this secret fashionista side, huh? What got you into it?"
    b "I guess it started when I was younger. I used to flip through those glossy magazines my aunt had lying around."
    b "It wasn’t just about the clothes—it was how they made people feel. Confident, bold, unapologetically themselves."
    scene v22-248
    p "You know, I’ve always wondered… You used to wear the hijab and those conservative clothes."
    p "Don’t get me wrong, you looked beautiful then too, but now you’re… different. What made you decide to take it off?"
    b "Since you asked… I was adopted by a very religious family."
    b "They were good people, kind in their own way, but they had expectations. Wearing the hijab, dressing conservatively—it was part of their world, their values."
    b "Especially, my father."
    p "That makes sense. But now…?"
    b "Now, I feel like I’m finally getting to know who I am. After everything I’ve been through, I realized that I’ve spent too much of my life living for others."
    b "But deep down, I’ve always wanted to express myself in my own way. Show the world who I really am, even if that means… showing a little more skin."
    p "I have an idea. Something exciting. Adrenaline-pumping. The kind of thing you’ll never forget."
    b "Why do I feel like I should be nervous?"
    p "Well, you’ve been talking about freedom, about showing the world who you are. So, here’s what I’m thinking…"
    p "We head up to the rooftop of the tallest building around here. Just you and me. And you… let it all go. Strip down, completely."
    p "No barriers, no hiding. Let the whole world see you—every inch of your beauty."
    scene v22-247
    b "What?! Are you out of your mind?"
    p "Think about it, Banu. You said it yourself—you’ve spent your whole life hiding behind what others wanted you to be."
    p "This would be the ultimate act of freedom. Nothing holding you back, just you against the world. You’d feel alive."
    b "Polad, that’s insane. I can’t… I mean…"
    p "Of course, you can. It’s just the two of us up there. No one else. And the view? Unmatched."
    p "You’d feel the wind against your skin, the city lights below, the stars above. Tell me that doesn’t sound liberating."
    scene v22-249
    b "You’re not fooling anyone with this whole ‘freedom’ speech. Let’s be real—what you really want is to get me naked on a rooftop, isn’t it?"
    b "You’re as transparent as glass, Polad. You just want an excuse to strip me down, probably to follow it up with one of your not-so-subtle moves."
    b "Do you have an idea to fuck me on the roof?"
    p "I mean, I can’t help it if the idea of you up there is... distracting."
    "Banu paused, her smirk fading slightly as she studied him. "
    "His words, as ridiculous as they were, still carried a thread of truth that made her chest tighten."
    scene black with dissolve
    "Polad and Banu stepped outside, the cool breeze brushing against their faces as they approached the towering building. "
    scene v22-250
    "The city buzzed with life around them—cars honking, people chatting, and the faint hum of distant music."
    "Polad, on the other hand, was brimming with excitement."
    p "This is it. The perfect spot to feel alive, to feel free. You want to go to the top?"
    b "Feel free or just feel naked?"
    b "You’ve got some wild ideas, Polad. This one might be the craziest yet."






    jump roof_sex








label roof_sex_continue:










    "Polad and Banu entered the clothing store located inside the building."
    "The transition from the cool night air to the warm, well-lit store was jarring, but it didn’t faze Polad, who kept his eyes on Banu as she wandered through the aisles."
    scene v22-268
    "Banu walked slowly, her fingers lightly brushing over the racks of clothes."
    "She stopped in front of a display of elegant dresses, tilting her head slightly as she examined one."
    p "I’m keeping things exciting. Admit it—you’d be bored without me."
    b "Fine. But if you keep this up, you’re paying for everything."
    p "Just don’t keep me waiting too long."
    scene v22-269
    b "Now that is something I’d love to see you in."
    b "You’re not subtle at all, are you?"
    p "Life’s too short for subtlety. So, are you trying it on, or do I have to beg?"
    b "You’re unbelievable."
    p "And yet you’re still here with me."
    scene v22-270 with fade
    "As Banu walked past the racks of clothes with Polad by her side, she suddenly froze."
    "Her breath caught in her throat as her eyes locked onto the seller—a man she instantly recognized."
    "The memory of that night when she sucked his cock in the changing room came flooding back, making her stomach twist into a knot."
    scene v22-271
    "The seller caught her gaze, a sly, knowing smile spreading across his face."
    "His eyes lingered on her for just a moment too long, and Banu felt her cheeks flush with heat."
    "Panic began to set in as she realized Polad might notice the exchange."

    menu:
        "Stay and talk":
            $ banustayandtalksellerpolad = True
            $ renpy.block_rollback()
            play music "audio/weakbanu.mp3"

            "She straightened her back, raising her chin slightly, refusing to let him intimidate her."
            scene v22-274 with fade
            "She wasn’t going to act like she had something to hide—not in front of Polad."
            sel "I see you’re back. Looking for something special today?"
            p "You know him?"
            b "He’s helped me out before."
            sel "You've changed, Banu. You got even prettier."
            "His eyes lingered on her a little too long, and a sly grin spread across his face."
            sel "That color would look amazing on you,"
            scene v22-275
            "She subtly shook her head, her eyes flashing a silent warning.."
            b_ "Not here..not now..."
            b "Maybe, you can stop talking and help us to find something better."
            sel "I'll be glad to help a beautiful lady like you. Is this your friend?"
            "Polad’s jaw clenched, his eyes darting between the seller and Banu."
            p "She doesn’t need your help."
            scene v22-276
            sel "I was just trying to be friendly."
            sel "You’ve got quite the shine on that head, my friend,"
            sel "I could probably see my reflection in it if I looked hard enough."
            "Banu’s eyes widened, and her lips parted in disbelief. She immediately stepped slightly aside, sensing the storm brewing."
            p "You know, with that haircut you’ve got going on, it looks like you tried to cut it yourself in the dark. What happened?"
            sel "Alright, alright. I get it. No offense."
            scene v22-277
            p "Just remember: some of us shine because we’re polished. Others, like you? Well, you’re just dull all over."
            "Banu finally lost her composure, letting out a small giggle as the seller muttered something under his breath and quickly stepped away, clearly defeated."
            scene v22-273
            p "Where do you know that guy from?"
            b "Hmm? Oh, I don’t really know him...He just works here, doesn’t he?"
            p "Yeah, but he was acting like he knows you. That wasn’t just some random salesperson attitude. What’s the deal?"
            b "I mean, I’ve been in this store before. Maybe he just remembers me from a previous visit,"
            p "Banu....What’s the story?"
            b "Fine. I came here a while back, alright? He was the one who helped me pick out some stuff. Maybe he’s just being overly friendly because of that."
            stop music
        "Leave immediately":




            $ banustayandtalksellerpolad = False
            $ renpy.block_rollback()
            scene v22-272
            b "Uh...Polad...I just remembered something."
            p "What? Did you forget something we needed to check?"
            b "No, it’s just... I don’t really like the vibe of this store,"
            b "Let’s go somewhere else. There’s a better one a block down."
            scene v22-273
            p "Better? What’s wrong with this place? You seemed fine a second ago."
            b "I know, I know, but I just realized their selection isn’t great. And I saw something online that I think will suit me better."
            b "Let’s not waste time. Trust me, the other place will have way better options."
            p "Alright, alright. But you’re acting weird..."
            p "You’re lucky you’re cute when you’re bossy..."





    scene black with dissolve
    stop music
    stop sound

    "Banu sauntered into Polad’s bedroom in her vibrant polka-dot lingerie, an impish smile dancing on her lips."
    scene v22-278 with fade
    b "I was thinking maybe I should try on all the new clothes I bought today and you can judge how they look."
    p "Banu, it’s late, and I’m tired. You sure this isn’t just another excuse to show off in front of me?"
    scene v22-279
    b "Maybe...But come on, don’t you want a private fashion show? I mean, look at me!"
    "She spun around, giving him a playful view of her toned figure."
    scene v22-280
    p "You’re impossible. Alright, but only because you seem so enthusiastic about it."
    "Banu grinned triumphantly and went to check her bag for the first outfit."
    b "You won’t regret it!"
    scene v22-281
    "Banu gave Polad a playful wink before heading toward the bathroom to change."
    b "Don’t fall asleep on me..."
    p "You know I’m not built for these late-night fashion escapades."
    b "Lazy as always..."
    scene v22-282
    "She closed the door behind her, leaving Polad to his thoughts. The room was quiet save for the soft rustling of fabric as Banu slipped into her next outfit."
    p "What’s taking so long? Are you designing a new wardrobe in there?"
    b "Patience, Polad! You’re not ready for the masterpiece I’m about to show off."
    p "Let’s see it, then."
    scene v22-283 with hpunch
    play sound "voices/dooropen.wav"
    b "Well, what do you think? Does it suit me?"
    p "Banu, aren't you forgetting something?"
    scene v22-284

    play music "audio/sensualsex.mp3"

    b "Forgetting? Oh, you mean my panties? I thought it might make the fashion show a bit more... interesting."
    p "Interesting is definitely one word for it. You're full of surprises, aren't you?"
    scene v22-285 with dissolve
    b "Only for those who appreciate them. So, should I continue or is this too much for your tired eyes?"
    p "No, no... by all means, keep going. I'm suddenly not so tired anymore."
    b "Alright, hold your breath. The next one’s even better."
    scene v22-286
    p "Better than no panties? I’m intrigued."
    b "Well, you’ll just have to wait and see. Patience, Polad."
    p "You’re going to kill me, Banu."
    scene v22-287 with fade
    "Banu stepped out of the bathroom, now dressed in a sleek black dress that hugged her curves perfectly. "
    p "Damn, Banu, are you sure you're not walking straight out of a runway? That dress should be illegal."
    b "You think so? I wasn’t sure about this one, but I thought you deserved a proper show tonight."
    p "Oh, it’s more than proper. It’s... breathtaking."
    p "Turn around, let me see the full view."
    scene v22-288
    b "Happy now?"
    p "But I have one complaint."
    b "What is that?"
    p "You’re outdressing me. It’s almost unfair."
    b "Says the guy with abs like carved stone, lying there like he’s posing for a magazine cover. If anything, you’re the one stealing the show."
    p "Maybe. But tonight’s your night, Banu. And I’m not about to let you forget how stunning you look."
    b "Wait for the next one. I'm sure you will enjoy it more."
    p "I can't wait to see that one."
    scene v22-289 with fade
    "Banu stepped out of the bathroom wearing a lingerie set that left little to the imagination. "
    p "Banu... what the hell? Are you trying to give me a heart attack?"
    scene v22-290
    "Banu smirked, running her fingers through her hair as she approached the bed."
    b "What's wrong, Polad? I thought you'd appreciate the effort."
    b "Isn’t this better than that boring black dress?"
    scene v22-291
    "Polad rubbed his face, trying to shake off his exhaustion, but his gaze betrayed him as it lingered on her."
    p "It’s... uh... something else, that’s for sure."
    p "But Banu, I’m dead tired. I mean it. I’ve had a long day, and right now, all I want is sleep."
    b "Oh, come on, Polad. Don’t give me that. You’re always so full of energy. What’s a little fun before bed?"
    scene v22-292 with fade
    p "Banu, you look amazing—more than amazing. But seriously, I’m running on fumes here."
    p "Go back to your room. Get some rest. Maybe tomorrow."
    b "Tomorrow? Polad, I don’t think you’ll survive until tomorrow. I’ll be in your dreams anyway."
    scene v22-293
    b "I don’t care how tired you are. I’m not leaving."
    b "You know what. If you don't do what I say, I'll tell your wife everything."
    p "Banu, I said I’m—"
    b "You’re always so in control, Polad. So composed. Don’t you ever just let go?"








    jump dominating_polad








label dominating_polad_continue:








    scene black with dissolve
    "The next day..."
    scene v22-323 with blinds

    play music "audio/suspense.mp3"


    "The bar felt quiet, with dimmed lights casting a warm glow on the polished wood."
    "Leyla stepped inside, her heels clicking softly on the floor. "
    "She looked around, her sharp gaze taking in the empty stools and faint hum of a distant jukebox."
    scene v22-324
    "The place smelled faintly of alcohol and fresh wood, familiar yet foreign."
    "Leyla’s floral top hugged her figure, her confident stride a stark contrast to the stillness of the bar. "
    "Her crimson hair caught the light as she turned her head, searching for signs of her mother."
    scene v22-325
    l "Mom?"
    "She called out, her voice carrying softly through the room. There was no answer."
    "Her eyes landed on the bar counter, its surface gleaming under the faint light. The absence of noise made her uneasy. "
    l "Where is everyone?"
    scene v22-326 with fade
    stop music
    stop sound
    "A man walked into view, tall and casually dressed, with an easygoing demeanor that immediately put her on edge."
    "His presence broke the stillness of the bar."
    sa "Hey, you must be Leyla."
    l "And you are?"
    sa "Sasha. Natasha’s boyfriend. Your mom and I’ve crossed paths a couple of times. She’s in the back room organizing some new products—should be out soon."
    scene v22-328
    l "Oh, I see. I didn’t expect anyone else to be here."
    sa "Yeah, it’s been a quiet night. Figured I’d drop by to help out a bit. Your mom’s been working hard lately."
    l "You seem pretty familiar with her."
    scene v22-327
    sa "I guess you could say that. Natasha drags me here sometimes, so I’ve gotten to know her. Your mom’s got quite the energy."
    l "Yeah, that sounds like her. Always on the move."
    sa "So, what brings you here tonight? Not exactly a lively place for someone like you."
    l "I just wanted to see her, that’s all. Figured she’d be busy."
    sa "Well, you’re in luck. She shouldn’t be long. Want a drink while you wait?"
    scene v22-329
    l "I don’t drink, not really my thing."
    sa "Okay have a seat..."
    scene v22-330 with fade
    sa "So, what is your thing, Leyla?"
    l "Books, mostly. Stories. I like escaping into other worlds. They’re less... messy than real life."
    sa "Interesting. You like to escape, but here you are, walking into a bar your mom runs. Seems like you’re stepping right into the mess."
    scene v22-331
    l "Touché. I guess I wanted to understand her better. We’ve grown apart in some ways."
    sa "She’s a fascinating woman, no doubt. But you’re not so bad yourself."
    l "And what makes you say that?"
    sa "You’ve got this quiet strength about you, It’s rare. Most people are either loud or trying too hard. You… you just seem real."
    l "You don’t know me."
    sa "Not yet....But I’d like to."
    "The air between them grew heavier, but not uncomfortable. There was a natural ease in their conversation, a rhythm that felt effortless."
    l "What about you? Why are you here, really? Natasha? The bar? Is this your dream?"
    "..."







    jump threesome_555












label threesome_555_continue:










    scene black with dissolve
    "As Banu approached Leyla with hesitance, her mind raced with thoughts of how to explain herself."
    scene v22-361
    "Banu walked toward the table, her steps hesitant yet graceful, her dark outfit emphasizing her composed demeanor."
    "Her eyes softened as she spotted Leyla sitting there."
    scene v22-362
    "Leyla looked up just as Banu reached the table, her expression shifting from curiosity to warmth."
    "Without a word, Banu leaned down, cupping her daughter's face gently in her hands."
    scene v22-363
    "She placed a soft, lingering kiss on Leyla's forehead and cheeks, her affection evident in the delicate gesture."
    scene v22-364
    "Leyla’s eyes closed briefly, soaking in the rare moment of tenderness."
    "When Banu pulled back, she brushed a stray curl from Leyla’s face and smiled."
    b "I’ve missed you, my little one."
    l "Mom, I’m not little anymore."
    scene v22-365
    l "So, you still work here with Polad? It’s a nice place. Feels… cozy."
    b "Yes, it’s been good for me. It’s a change I needed, and Polad has been supportive."
    l "Kamil said you haven’t been by to visit in months. He… wonders if you’re okay."
    b "I’m fine, Leyla. Kamil and I… we’re in very different places now. There’s no reason for me to linger in the past."
    l "But he’s still my dad, Mom. And I live with him now. It’s hard to pretend everything’s fine when I barely see you anymore."
    scene v22-366
    b "Leyla, you know why things are the way they are. I needed to move forward, to find myself again. Living with Polad has helped me do that."
    l "But with Polad? Mom, you’re living with someone who—has such a different… lifestyle. It’s hard for me to understand."
    b "You don’t have to understand, Leyla. You just need to know that I’m doing what’s best for me. After everything, don’t I deserve that?"
    l "I just… I wish you’d think about how all of this feels for me too. I’m stuck between you and Dad, and it’s exhausting."
    b "I know this isn’t easy for you, Leyla. But I can’t go back to what was. I need to live my truth, even if it’s messy."
    scene v22-367
    b "Leyla, I know this is all strange for you. I’m not the same woman I was back then."
    b "I’ve grown. I’ve changed. I’m finally living the way I’ve always wanted—without restrictions, without fear."
    l "What does that even mean, Mom? You keep saying you’ve changed, but how does that justify everything?"
    l "How does that explain why you’re here, living with Polad of all people?"
    b "It means I’m no longer hiding who I am. I’m embracing life, Leyla."
    b "Something I never had the courage to do before. Polad’s apartment gave me space to figure things out."
    scene v22-368
    play music "audio/intro.mp3"

    l "Figure things out? Or hide from the mess you left behind? Tell me, Mom, is there something going on between you and Polad?"
    b "Leyla, what happens in my personal life is my business."
    b "But I can assure you, Polad has been a friend—someone who’s helped me rediscover myself."
    l "You’re dodging the question, Mom. You talk about living freely, but what does that mean for us? For me?"
    l "You’re not just ‘rediscovering’ yourself; you’re running away."
    b "I’m not running away, Leyla. I’m moving forward. And yes, it’s messy. But it’s my path to take."
    l "You’re letting Polad use you, Mom. Don’t you see it?"
    l "He’s just taking advantage of you while you’re trying to figure out your so-called ‘freedom.’ It’s pathetic."
    scene v22-369
    b "Watch your mouth, Leyla! You don’t know what you’re talking about."
    l "I know enough. He’s keeping you around because you’re convenient. You’re his little project, someone he can manipulate."
    b "That’s enough! You don’t get to judge me or my choices. "
    l "Open your eyes, Mom. You’re not free—you’re just swapping one leash for another."
    b "How dare you talk to me like that? I’ve sacrificed everything for you—for this family! "
    b "And now that I’m finally doing something for myself, you think you can tear me down? You have no idea what I’ve been through!"
    scene v22-370
    "As the tension between Banu and Leyla reached its peak, Polad approached them."
    "His confident stride and piercing gaze immediately drew their attention. "
    p "What’s going on here? The whole bar could probably feel the tension."
    scene v22-371 with fade
    l "Oh, look, here he is—the savior. "
    l "The one who’s been ‘supporting’ my mom so much that she’s forgotten who she is."
    p "You’ve got something to say, Leyla? Say it to my face instead of hiding behind cheap insults."
    scene v22-372
    l "Fine. You’re using her. She’s just another woman for you to keep around while you play your games."
    p "You think I’m using her? Do you even know what your mother has been through?"
    p "I’ve been there for her when no one else was. Where were your father?"
    l "I was with my father, trying to deal with the mess you helped create!"
    l "You’re not some knight in shining armor, Polad. You’re part of the problem."
    scene v22-373
    b "Enough! Both of you! This is my life we’re talking about, and I’m tired of being treated like a child who doesn’t know what she’s doing."
    b "I’m not the same woman I was when I was with your father."
    b "I’ve changed, and yes, I’ve made mistakes, but I’m trying to live my life for me. Can’t you understand that?"
    l "You know what? It all makes sense now. You’ve thrown away everything to shack up with him."
    l "He fucks you good, right, Mom? That’s why you’re defending him like this."
    b "Leyla! How dare you speak to me like that?"
    p "Watch your mouth, Leyla. You might not like me, but don’t you dare disrespect your mother."
    scene v22-374
    l "Respect? She’s letting herself be used by you, and you expect me to respect that? You’re both pathetic."
    b "Leyla, stop. You don’t understand—"
    l "I don’t want to understand! You’ve made your choice, and I hope you enjoy it."
    scene v22-375 with fade
    b "She hates me."
    p "She doesn’t hate you. She’s just angry. She’ll calm down."
    b "What if she doesn’t? What if I’ve lost her for good?"
    p "You haven’t lost her. Give her time. She’s young, and she’ll come around eventually."
    p "She just needs to see that you’re still the same person deep down."
    b "I need some time, Polad. I’m going to see some friends. I’ll be home late, so don’t wait up for me."
    p "Are you sure that’s a good idea? You’ve had a rough day."
    b "I will. Don’t worry about me."
    scene black with dissolve
    "Polad sat at the bar, the empty silence of the room weighing heavily on him."
    scene v22-376 with dissolve
    "His hands were clasped together, and his brow furrowed as his thoughts spiraled."
    "He stared at the untouched glass of beer in front of him, his reflection faintly visible in the polished wood of the bar counter."
    p_ "She’s been distant lately… Could she be lying to me? Could there be someone else?"
    scene v22-377
    p_ "Maybe she’s just using me, playing me for a fool. No… Banu wouldn’t do that. Would she?"
    "He let out a deep sigh, running a hand over his bald head, feeling the coolness of the room against his skin."
    "The bar felt emptier than ever, and for the first time in a long time, Polad felt truly alone."
    scene v22-378 with blinds
    "Banu walked briskly through the dimly lit alley, the soft click of her heels echoing against the narrow brick walls. "
    b_ "What if Leyla's right? What am I doing with my life? Am I running toward something… or just running away?"
    b_ "Why did I tell Polad I’d be late? He probably thinks I’m out doing something I shouldn’t."
    b_ "But he trusts me… doesn’t he? Does he even care enough to be suspicious?"
    scene v22-379
    "Her heart sank at the thought of Polad sitting alone in the bar, lost in his own worries."
    "She knew he deserved better than half-truths and uncertainty, yet here she was, walking alone through the night, unsure of what she was even seeking."
    "Still, she couldn’t shake the sense of being watched."
    scene v22-380 with wipedown
    stop music

    play music "audio/weakbanu.mp3"

    "Banu stepped into the guest room, her movements tense and deliberate. "
    "The dimly lit space smelled faintly of cologne and smoke, a signature of Murat's presence. "
    "His sharp gaze met hers as she entered, a smirk playing on his lips."
    mur "Banu, you’re late."
    scene v22-381
    b "I didn’t come here to chat, Murat. What do you want? I don’t have much time."
    mur "Why so tense? You didn’t seem so rushed the last time we met. What’s changed?"
    b "That was different. Tonight is not the same. I have responsibilities, and I can’t stay long."
    scene v22-382
    mur "Responsibilities? Don’t tell me it’s Polad. Or is it your daughter now?"
    mur "You’ve been juggling these worlds like a pro, Banu. But don’t forget… I know the real you."
    mur "And I called you here because you can’t resist proving me right."
    b "Don’t start, Murat. I didn’t come here for games."
    b "If you don’t have anything important to say, I’m leaving."
    mur "Not so fast, Banu. You might want to say hello to someone first."
    scene v22-383
    "For the first time, she noticed the man sitting on the leather sofa. "
    b "Mahmud…"
    "Her voice was barely audible, the shock evident on her face. The man, Mahmud, leaned back casually on the sofa, his eyes meeting hers with a knowing smirk. "
    "Though in his sixties, he exuded an aura of power and confidence, the kind that came with decades of experience and wealth."
    scene v22-384
    mah "It’s been a while, Banu. You look… different."
    "His words dripped with subtle amusement, his gaze unwavering as he studied her."
    "Banu felt a mix of emotions surge through her—shock, unease, and an underlying thread of anger."
    "Mahmud was no stranger to her; he was Hicran’s husband, a man who had always loomed large in her life through their mutual connections."
    scene v22-385
    b "Mahmud… what are you doing here? With him?"
    mur "Uncle Mahmud wanted to see you. Thought it might be fun to arrange this little reunion. Small world, huh?"
    b "Mahmud...is...your uncle?"
    mah "Murat has been keeping me updated on his… adventures."
    mah "When I heard your name come up, I couldn’t resist seeing you for myself. And here you are."
    b "I don’t know what you’re trying to do, Mahmud, but I have nothing to do with this… arrangement."
    b "If you called me here just to mess with me, I’m leaving."
    mah "Calm down, Banu. No need for dramatics. I simply wanted to have a conversation. There’s no harm in old friends catching up, is there?"
    scene v22-386
    "Banu hesitated as she lowered herself onto the sofa, sitting between Mahmud and Murat."
    b "I didn't know he was your uncle..."
    "The air felt thick, charged with a tension she couldn’t ignore. "
    mur "You know, uncle, Banu here is quite the firecracker. Isn’t she just wonderful?"
    mur "Last time we were together, she blew my mind. Quite literally, isn’t that right, Banu?"
    b "Murat, that’s enough. We’re not here to discuss that..."
    mur "Oh, come on, Banu. Don’t be such a prude. We’re all adults here."
    mur "Besides, it’s not every day you get to impress someone like Mahmud with your… talents."
    scene v22-387
    mah "Murat speaks highly of you, Banu. It seems you've left quite an impression on him."
    mur "You know, uncle, I wasn't exaggerating when I said Banu is something special. She's got the tightest little asshole in the world."
    b "Murat, enough!"
    mur "Alright, alright. No need to get all uptight. I was just being honest. You know I admire you, Banu."
    mah "Banu, forgive my nephew’s crudeness. He has a tendency to forget his manners."
    mah "But let’s put all that aside for now. We have more important matters to discuss, don’t we?"
    scene v22-388
    mah "You know, Banu... seeing you here tonight brings back old memories. Memories of your mother."
    "Banu’s face immediately tensed. She shifted uncomfortably in her seat, sensing where this might be heading."
    mah "Ah, yes. Your mother. What a woman she was. The... how should I put it... the wildest, most uninhibited creature I’d ever met."
    mah "She truly knew how to enjoy life."
    scene v22-389
    b "Mahmud, stop....After all...I don't believe this..."
    mah "She had this way about her, didn’t she?"
    mah "Always so inviting, so... generous. I’ll admit it—your mother and I, we shared quite a few... passionate moments together."
    mah "You see, Banu, life is all about understanding each other's... needs."
    mah "And I must say, you’ve inherited so much from your mother. Not just her beauty, but her... magnetism."
    b "I don’t know what you two are trying to do, but it won’t work."
    scene v22-390
    mur "Relax, Banu. We’re just talking. It’s not every day I get to sit so close to the most gorgeous woman I’ve ever known."
    mur "And let’s not forget... I’ve already seen all of you."
    b "Don’t touch me."
    mah "Come now, Banu. Let’s not be so defensive. Murat here is a journalist, as you know. He uncovers... truths."
    mah "And you wouldn’t want certain truths about your family to come to light, would you?"
    b "You wouldn’t dare."
    mur "It’s our job to tell stories, isn’t it, Uncle? And this one... well, it’s just too juicy to ignore."
    scene v22-391
    mur "See, Banu, you’re not pulling away anymore. "
    mur "I think you like this, don’t you? You always have that fire in your eyes, but right now… it’s different."
    mah "It’s nothing to be ashamed of, my dear. You’re a passionate woman. It’s in your blood."
    b "I… I don’t know what you’re talking about."
    mah "Your body speaks louder than your words, Banu. You’re not fighting us. You’re… responding."
    mur "You can’t deny it, Banu. You’re as beautiful as ever, and right now… you’re irresistible."
    mah "Your mother had the same fire. She never held back from what she wanted. Maybe it’s time you stopped holding back too."


    menu:
        "Banu lets them undress her":
            $ threesomemahmudmurat = True
            $ renpy.block_rollback()
            stop music
        "Banu leaves":





            $ threesomemahmudmurat = False
            $ renpy.block_rollback()
            scene v22-394 with fade

            "Murat's sly grin and Mahmud's calculating gaze only confirmed what her instincts were screaming—they were trying to trap her."
            "She stood abruptly, brushing Murat's lingering hand off her arm. Both men looked up at her, surprised by her sudden movement."
            scene v22-395
            stop music
            b "Enough. Whatever game you think you’re playing, I’m not a piece on your board."
            mur "Whoa, easy there, Banu. We were just talking."
            b "Talking? Don’t insult me. You think I don’t see what you’re trying to do? Blackmail me? Use my past to control me?"
            b "You must think I’m stupid."
            mah "No one said anything about blackmail, my dear."
            b "Don’t you dare play coy with me, Mahmud. I know men like you."
            b "You think your money and power give you the right to manipulate everyone around you. Well, not me."
            scene v22-396
            mur "Come on, Banu. We’re just having a little fun. "
            b "You disgust me, both of you."
            b "The only thing I regret is wasting my time with either of you."
            "..."



    scene black with dissolve
    "..."
    scene v22-392
    "At the same time Polad sat at the bar, his shoulders hunched."
    "His fingers tapped lightly against the wood, his mind racing with thoughts of Banu. "
    "Leyla appeared silently behind him, as she stood a few steps away. "
    "Her sharp gaze lingered on him, a mix of anger and curiosity flashing in her eyes."
    scene v22-393
    l "So, this is what the great Polad does when he’s alone? Sulking in his bar with a drink?"
    p "What are you doing here, Leyla? Shouldn't you be somewhere else, like home."
    l "I could ask you the same thing. Shouldn’t you be with my mother, keeping her from making more mistakes?"
    p "Just go home."
    l "You know what, Polad? I’m done pretending."
    play music "audio/sidesex.mp3"
    l "I didn’t come here to argue about my mom or to guilt you into anything. I came here for you."
    p "What the hell are you talking about?"
    l "You heard me. I can’t stand it anymore, Polad. Watching you with her, seeing you in my head every single night."
    l "It’s driving me insane. I came back because I want you—because I need you."
    p "Leyla, stop. You don’t know what you’re saying."
    l "Oh, I know exactly what I’m saying. I’ve been lying to myself, to everyone, for too long. I can’t live like this anymore, Polad."
    l "I came back because I want you to take me, to make me forget everything else. I want you to fuck me until I can’t think about anything else."
    scene v22-413 with fade
    l "Please, stop. "
    l "I’m here, standing in front of you, telling you the truth for the first time. Do something about it."
    p "This isn’t a game, Leyla. Whatever you think this is, it stops now."
    l "I’m not playing games, Polad. I’m tired of hiding how I feel."
    l "I’m not asking you to choose or to leave her—I’m asking you to see me. To want me."
    scene v22-414 with fade
    "Leyla took a bold step forward, her hands reaching for Polad’s T-shirt."
    "Polad tried to step back, his expression a mix of shock and anger, but she was faster."
    p "Leyla, what the hell are you doing? Stop this, right now!"
    "His chest and hard abs were now exposed, the tension in his muscles mirroring the turmoil in his mind."
    scene v22-415
    l "I can’t, Polad. I can’t stop. I’ve been holding this in for so long, and it’s tearing me apart."
    l "I love you. I want you. Please… I need you."
    p "You’re out of your mind. You don’t know what you’re saying, Leyla."
    l "I’m not crazy. I know exactly what I’m doing."
    scene v22-416
    "She leaned forward, wrapping her arms around his waist, pressing her face against his hard, warm abs."
    "Her lips brushed against his skin in a tender kiss, sending a jolt of tension through his entire body."
    scene v22-415
    l "I’ve dreamed of this—of you—every night. I’ve waited so long, Polad. Please… don’t push me away."
    "Polad’s breathing grew heavier, his hands clenched into fists as he tried to maintain control."
    p "Leyla, get up. You don’t understand the consequences of what you’re doing."
    scene v22-417
    p "What the fuck are you doing? Get dressed quickly!"
    "As Leyla stood, she made a sudden, decisive move, slipping out of her clothes."
    "Now in just her panties, she stood boldly before Polad, her eyes locked on his, challenging him."
    scene v22-418
    l "Look at me, Polad. This is how much I want you. This is how long I've waited for you."
    p "Leyla, this isn't right. You need to stop this now. You're not thinking clearly."
    l "I've never been more clear about anything in my life. I want you, Polad. Don’t you feel anything for me?"
    p "Leyla, listen to me. You're confused, you're hurt. What you're feeling—it's not love."
    scene v22-419
    l "So, tell me, Polad... you sure fuck my mom good, huh?"
    l "She always looks so... satisfied. But now it’s my turn, isn’t it? My turn to feel that big cock of yours."
    p "Leyla, stop. Right now. You’ve crossed a line."
    l "What’s wrong, Polad? Afraid of a little competition? Or maybe you’re scared you won’t be able to handle me the way you handle her."
    p "This isn’t a game, Leyla. "
    scene v22-420
    "Leyla stepped closer, her eyes locking with Polad’s as her boldness reached a new height."
    "Without hesitation, she pressed herself against him, her bare chest brushing against his solid frame."
    "Polad’s muscles tensed as her soft skin made contact with his, her teasing smirk never wavering."
    scene v22-421
    l "Feel that, Polad? You’re not as immune as you think you are. I can see it in your eyes… I can feel it."
    p "Leyla, stop this."
    l "I know exactly what I’m doing. And so do you, Polad. You think I can’t see how your body reacts? How much you want me right now?"
    l "Push me away if you don’t feel the same. Tell me I’m wrong."
    l "Now it’s your turn to decide—are you going to keep pretending, or are you going to admit what we both know is true?"
    stop music 
    stop sound

    if threesomemahmudmurat == True:



        jump threesome_666







label threesome_666_continue:

    stop music
    stop sound












label polad_ending:

    scene black with dissolve
    play music "audio/intro.mp3"
    "...."
    l "Aah—Polad—f-fuck—"
    p "Goddamn, Leyla, you’re tight—dripping—"

    scene end-244 with dissolve
    $ renpy.sound.play("voices/longmoan.mp3", loop=True)
    l "Ah! Yes! Harder—Polad, don’t stop—"
    p "You want it like this? Like a fucking animal?"
    l "Yes! Yes! Fuck me—fuck me like that—"
    p "This pussy’s been waiting for me."
    p "You know your mama would kill me for this."

    scene end-245
    l "Then fuck me hard enough she hears it in her sleep."
    p "Ahh, you filthy little thing... just like Banu used to be."
    l "I’m better than her. Tighter, wetter, younger... tell me...ahhhh..."
    p "Fuck—yes. You feel like a sin wrapped in silk. Come here, girl."

    scene end-246 with fade
    l "Aah—f-fuck, Polad! Right there, yes, God—nggh!"
    l "Mmmhnn—haaah! I thought about this all the time. Watched your cock in those jeans—"
    p "Little pervert. Bet Banu had no clue her sweet baby girl was dripping for her old friend."

    scene end-247
    l "She used to talk about you... said you were trouble."
    p "She didn’t know I’d be balls-deep in her daughter."
    l "Aaah! You're hitting so deep, fuuuck! You’re stretching me—haaah—fuck yes!"
    p "You moan louder than your mother ever did. That filthy mouth... damn!"
    l "Use me like you used her—harder, fuck—like that! Yes!"
    p "You want me to treat you like I did Banu? Bent over this bar, begging for more?"
    l "More! I can take more, Polad! I’m not her, I’m better!"

    scene end-248 with fade
    b_ "I opened the back door and the first thing I saw was her legs—spread wide, bare, trembling in the air like she was being offered up."
    b_ "She was on the floor, back arched."
    b_ "Her mouth was open, moaning nonstop like it hurt and felt too good to stop."
    b_ "Polad was above her, gripping her thighs so tight his knuckles were white."
    b_ "He was thrusting hard, brutal, like he hadn’t fucked in years."
    scene end-249
    b_ "Every time he drove into her, her whole body jolted—her breasts bouncing, heels kicking the air, crying out his name like she was drowning in it."
    b_ "I could see how soaked she was. His cock was slick with her, every thrust loud, wet, obscene—like it echoed off the bottles in the bar."
    b_ "He was pure brute. Sweating like a beast, veins thick down his arms, that chest heaving with every thrust like he was made of war."
    b_ "He grunted deep, low, the kind of sound no boy could ever make."
    b_ "That was a man—fucking like he owned the earth beneath them."
    b_ "Polad was never gentle. But that night? He was feral. Primal. A man who didn’t fuck—he claimed."
    b_ "And him? Laughing under his breath like the dog he was."
    b_ "Whispering ‘Your mama’s pussy never opened like this…’ like it was some fucking joke."
    b_ "I went blind. The knife was just there, under a rag, still stained from cutting limes. Long. Sharp."

    scene end-250 with flash
    stop sound
    play sound "voices/manscream.mp3"
    b_ "I didn’t hesitate. My hand just moved. One second he’s rutting her like a savage, next second he’s jerking upright, confused, blood pouring down his back."
    b_ "Still buried inside her, his cock twitching as he realized—too late."
    b_ "The sound he made—oh God."
    scene end-251
    b_ "Like a dog kicked in the gut. Not a scream. A bark, a cough, like all the air punched out of him."
    b_ "He froze. Still inside her. His hands flew out like he could grab the pain and pull it out."
    scene end-252 with fade
    b_ "He tried to stand, turned around, blood pouring from his back down his ass, his cock still hard, slick with my daughter's mess."
    b_ "We were face to face."
    b_ "He looked at me, eyes wide like a calf in the slaughterhouse."
    b_ "And he said—'Banu?'—like it wasn't him balls-deep in my baby girl."

    scene end-253
    p "You goddamn backstabbing bitch— you think this is justice?"
    p "Coming at me with a fucking knife like some deranged gutter whore?"
    b "I watched you fuck her, Polad."
    p "Yeah? And you stood there with your knife and your jealousy, like some pathetic little freak."
    b "I want your blood, and it’s already dripping down your legs. Keep talking, I’ll give you another hole."
    p "You want to watch me die, huh? Want to see me crawl like a dog?"
    scene end-254 with flash
    play sound "voices/ah1.mp3"

    b "Khhh—!"
    p "Right there! That’s what betrayal fucking feels like!"
    b "You... fucking..."
    p "How's it feel? Cold? Sharp? Just like your bullshit love."
    scene end-255
    b "You... you piece of shit... I... I loved you..."
    p "Then you should’ve kissed me instead of stabbing me. Too late now, bitch."
    b "You’re... a fucking monster..."
    p "And you made me."
    scene end-256 with fade
    "He hit the floor on his side, breath coming in broken, bubbling gasps..."
    "Banu collapsed almost at the same time."
    "Leyla screamed."

    scene end-257
    "She ran to Banu, dropping to her knees so hard they bruised, hands hovering uselessly over the wound, not knowing where to touch without making it worse."
    "Her face was pale, eyes wide and glassy, tears spilling down without sound."
    l "Mom… please… please don’t…"
    "Leyla took her hand. It was already going cold."

    scene end-258 with fade
    "Banu’s lips moved again."
    b "Ley… la…"
    "Banu gave the smallest, saddest smile."
    l "Stay. Please stay. You can hate him later, just stay."
    b "…I loved him… even when I stabbed him…"
    "Her chest rose once more."
    "Then it didn’t."
    scene black with dissolve
    "..."
    scene ending_7 with dissolve
    "..."
    "..."
    stop music

    dev "{color=#ffffff}Thank you for playing! YOU'VE REACHED ONE OF THE ENDINGS!. Play again to discover more. If you enjoyed it, please {a=https://www.patreon.com/lustfulfantasy}support{/a} the development. Wishlist our new game here {a=https://store.steampowered.com/app/4056530/Banu_in_the_West/}Banu in the West{/a} {/color}"
    hide screen faith
    hide screen angeldevil
    $ renpy.end_replay()
    $ persistent.polad_ending_unlocked = True
    jump endings
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
