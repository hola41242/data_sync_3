



label kamil_fuck_banu_dadoutside:




    play music "audio/slowsoft.mp3"

    "As they entered the bedroom, Kamil's heart weighed heavy with the burden of his father's harsh words. "

    scene v20-24 with fade

    "He turned to Banu, and began to speak."

    k "Banu, I'm truly sorry. I should've stood up to my father. He had no right to speak to you that way."

    b "Save your apologies, Kamil. It doesn't change what happened."

    k "I know, Banu. But please, let me make it right. I'll talk to my father and ensure this never happens again."

    scene v20-25

    b "I hope you mean it, Kamil. Because I can't keep living like this."

    k "I do, Banu."

    b "Your dad is a disgusting village donkey, Kamil. I can't believe he would speak to me like that."

    k "Banu, I know he can be... difficult. But please, let me handle this."

    b "He's more than difficult, Kamil. He's downright disrespectful. And if you won't stand up to him, then I will."

    k "Okay, Banu. I'll talk to him. And I promise, things will be different."

    b "Just make sure that he leaves and goes to his fucking village as soon as possible."

    scene v20-26 with fade

    k "I will do my best, Banu, just give me some time..."

    k "I am sorry for my dad, really sorry..."

    b "You know what, Kamil, fuck your dad!"

    k "What? Banu, please, watch your language. He's still my dad."

    b "Now he thinks that you are punishing me right?"

    b "Well, let him think that while we...do our own business..."

    k "What?"

    scene v20-27 with fade
    play music "audio/sidesex.mp3"

    "As Banu stood there, undressing down to her sexy lingerie, she felt a thrill of excitement knowing Kamil's dad is in the next room."

    b "Are you ready to have your way with me baby?"

    k "What are you doing, Banu? My dad is just in the other room."

    b "Do you really think your dad is going to stop us?"

    b "I bet he wouldn't even hear us over the sound of his own snores. Now come here and show me how much you want me."

    scene v20-28

    k "We can't do this. He may hear us."

    b "Your dad is such a stuffy old man, always stuck in his outdated ways. Why does he get to control what we do?"

    b "This is our house and we can do whatever we want here."

    scene v20-29 with fade

    k "Banu, don't touch me like that or I won't be able to control myself."

    b "Oh Kamil, why control yourself? You're mine to do whatever I please."

    k "I don't think I can get it up knowing that my dad can come in any minute."

    b "Ahh but that's the beauty of it. The riskier it gets the harder you'll get."

    scene v20-30

    b "Now let's see if you can keep me satisfied."

    k "Aren't you afraid of my dad?"

    b "Of course not. Your dad is just an old man who doesn't know how to enjoy life."

    k "Fuck...your eyes...they are so sexy...but my dad..."

    b "Fuck your dad, Kamil. I'm tired of letting him control us. I want you, and I'm not going to let anything stop us."

    scene v20-31

    "As Banu boldly stripped down completely, Kamil's breath caught in his throat, his eyes widening in surprise and desire."

    b "You can't resist me, can you, Kamil?"

    k "Not when you look at me like that, Banu. You drive me crazy. Your ass is so sexy."

    k "Banu, you're so beautiful..."

    b "And you, Kamil, you're irresistible."

    scene v20-32 with fade

    k "I never want to let you go."

    b "Then don't. Hold me tight, Kamil."

    k "I'll never let anyone hurt you again, Banu. I promise."

    b "I trust you, Kamil. Just hold me, and never let go."

    "Their bodies pressed together in an intimate embrace, Banu's desire surged as she pressed herself against Kamil."

    scene v20-33

    "With a subtle movement, her hips began to grind against his, the heat between them igniting a fierce passion."

    b "Kamil..."

    k "Banu..."

    scene v20-34 with vpunch

    "Their passion reaching its peak, Kamil lifted Banu into his arms with a primal strength, their bodies aligning in a fervent embrace."

    "With a swift, decisive motion, he guided himself into her, their connection sending waves of ecstasy coursing through them both."

    b "Ahhhhh...."

    "Banu gasped in pleasure as she felt Kamil fill her completely, her nails digging into his back as she surrendered to the overwhelming sensation."

    b "Take me, Kamil. I want you."

    k "I need you, Banu. Now and always."

    scene v20-35

    "The air crackled with Banu's fierce desire, her words a desperate plea for more from Kamil."

    b "Harder, Kamil! I need it rough!"

    "Kamil's eyes widened in alarm as he glanced nervously towards the door, his concern for his father's potential intrusion palpable."

    k "Banu, please... Keep your voice down. My dad could hear us..."

    b "I don't give a damn about your dad!"

    b "If you don't fuck me hard, I'll go and deal with him myself!"

    k "No, you can't."

    b "Do you think I'm afraid of that shitface? I'll go and pee on your dad's face."

    k "You're such a horny slut..."

    k "Take this..."
    stop music
    show kamilfuckbanustanding_dadoutside
    play music "voices/slappingslow.mp3"
    b "Yes, Kamil... Oh, yes..."

    k "You wanted it rough, Banu? You got it."

    "Their breaths came in ragged gasps as they surrendered to the overwhelming intensity of their union."

    b "Don't stop, Kamil... Please.."

    k "I won't, Banu. I can't..."

    b "Harder, Kamil! Fuck me harder!"

    k "Ahhh...you are so horny..."

    k "You have a really high sex drive..."

    b "Yess...ahhh...I've always been like this....ahhh"

    scene v20-36 with fade
    stop music
    k "You're such a dirty human being, Banu. Always so damn horny, always so filthy with your high sex drive."

    b "What?"

    k "It's like you can never get enough."

    b "I can't help it... It's like I only ever think about sex."

    k "I'll satisfy you like never before. "

    b "Yess, fuck me, Kamil."

    scene v20-37 with vpunch

    "Banu felt a rush of excitement coursing through her veins. With a rough but controlled motion, he tossed her onto the bed."

    b "Wow, Kamil... You're so strong."

    k "You like that, Banu?"

    b "I love it, Kamil. Show me what else you can do."

    scene v20-38 with fade
    play sound "voices/fastmoan1.mp3"
    b "Ahhhh..."
    stop sound
    "With a swift movement, Kamil positioned himself at the entrance of Banu's eager pussy, their bodies aligning perfectly as he entered her."

    "Banu gasped in pleasure as she felt him fill her completely, her back arching instinctively to meet his thrusts."

    b "Oh, Kamil..."

    b "I imagine your dad will be able to hear every moan and thrust."

    k "Damn, you are so dirty."

    b "Now I can only imagine how intense it will be to know that your father is right there listening to us. It gives me goosebumps just thinking about it."

    k "Banu you are such a dirty woman. I haven't noticed this over the years."

    b "Now you know. Come on! Fuck me already, or I'll ask your dad to do that."

    k "What??? That's it!"

    show kamilfuckbanumissionary_dadoutside
    play music "voices/longmoan.mp3"

    b "Ohh fuck me harder Kamil I can feel your cock getting bigger as you pound into me. Keep going."

    k "Yesss, take this..."

    b "Fuckkkk ohhh this feels so good. Your dad might hear us but I don't care I want him to know that you're all mine."

    k "Shit, you're such a..."

    b "I think your dad is getting a little turned on right now too."

    k "Ahhh, fuck..."

    b "Fuck me harder baby!"

    k "Your pussy is squeezing my dick so bad."

    b "Oh fuck that feels so good! Keep going baby."

    b "Ohh fuck Kamil keep pounding me. I want your dad to hear me cum loudly!"

    scene v20-39

    k "Ohhh fuck, please stop talking like that...ohhh"

    b "Ohhh fuck yes keep going. Fuck me so hard that I scream loud enough that your dad knows exactly what we're doing."

    k "Ohhh...shit.."

    b "Oh fuck yes keep going Kamil. I want to make sure your dad hears me cum loudly."

    b "FUCKKKK KAMIL I'M GONNA CUM NOW!!"
    stop music
    scene v20-40 with hpunch
    play sound "voices/man3.mp3"
    k "Ohhhh...shit...baby...that's..."
    stop sound
    b "Oh yess, that was so fucking hot."

    b "I love the idea of your dad listening to us fuck, hehe.."

    scene v20-41 with fade

    k "Sorry I messed your belly."

    b "I loved it! The messier the better."

    "They lay in silence for a moment, the only sound filling the room the gentle rhythm of their breathing."

    b "That was... incredible, Kamil."

    k "You were incredible, Banu. You always are."

    scene v20-42
    play music "audio/romantic.mp3"
    "Banu's cheeks flushed with a mixture of pleasure and bashfulness at Kamil's words, her heart swelling with affection for him."

    b "I love you, Kamil."

    k "I love you too, Banu. More than anything."

    b "Kamil, about earlier... I'm sorry if I scared you with what I said about your dad. I just... I get so overwhelmed sometimes."

    k "It's okay, Banu. We all have our moments. And I promise, no matter what, I'll always be here for you."

    b "Can you imagine if my father-in-law walked in on us right now?"

    k "Oh, I think he'd have a heart attack on the spot."

    b "He'd probably lecture us about 'proper behavior' for hours."

    k "And then he'd threaten to disown me for corrupting his precious daughter-in-law."

    b "Well, he's just going to have to accept that his son is a wild one."

    k "Wild, huh? I like the sound of that."

    b "I bet he'd faint if he knew half the things we get up to when he's not around."

    k "Maybe it's best to keep some things between us, huh?"

    b "Agreed. Our little secret."
    stop music
    cam "Hey, Kamil, where the fuck are you?"

    scene v20-43 with vpunch

    b "Oh no, Kamil! It sounds like your dad's coming this way!"

    k "Quick, we need to get dressed before he sees us like this!"

    scene v20-44 with fade

    "With a flurry of movement, they scrambled to find their clothes, their hearts racing with adrenaline as they hastily covered themselves."

    b "Hurry, Kamil! I think he's getting closer!"

    k "I'm trying, Banu!"

    b "Kamil, what if he catches us like this?"

    k "He won't, Banu. I won't let that happen."

    scene black with dissolve

    "With one last frantic effort, they managed to get dressed just as Camal reached the door of their room."





    $ renpy.end_replay()
    $ persistent.kamil_fuck_banu_dadoutside_unlocked = True
    jump kamil_fuck_banu_dadoutside_continue











label banu_suck_kamil_dadwatch:







    scene v20-52 with fade

    "As Banu stood at the sink, her hands immersed in soapy water, Kamil approached quietly, a softness in his eyes that hadn't been there before."

    k "Do you need any help with that?"

    "Banu looked up, surprised by Kamil's offer, a faint smile tugging at the corners of her lips."

    b "Actually, that would be wonderful. Thank you, Kamil."

    b "Why did you choose to stay?"

    scene v20-53

    k "I just want to be with you."

    b "Aren't you afraid of your dad? He called you."

    k "I'm not afraid, Banu. Not when I'm with you."

    b "Won't he be upset that you chose to stay with me instead?"

    k "Let him be upset. I'm tired of living my life according to his rules."

    "As they left the dishes behind, Banu and Kamil found themselves drawn to each other, their eyes locking with a shared intensity that spoke volumes."

    scene v20-54 with fade

    b "Well, look at us, abandoning our chores. I guess we'll just have to find another way to occupy ourselves."

    k "I'm sure we can think of something."

    b "You know, I can think of a few things I'd like you to help me with."

    k "Oh? And what might those be?"

    b "I think you know exactly what I'm talking about."

    b "You know...I have an idea..."

    k "I can't wait to see what you have in mind."

    scene v20-55 with fade
    play music "audio/heatedsex.mp3"
    "Kamil's eyes widened in shock as Banu dropped to her knees before him, her hands deftly unbuttoning his pants with a sense of urgency that took him by surprise."

    k "Banu, what the fuck are you doing? What if my dad walks in?"

    "Banu glanced up at Kamil with a mischievous glint in her eyes, her fingers still working at his belt buckle."

    b "Then we'll have to be quick, won't we?"

    scene v20-56

    k "But what if he catches us? It's too risky."

    b "I don't care, Kamil. I need you, right now."

    k "Oh god, Banu..."

    "Kamil's breath caught in his throat as Banu's lips closed around him."

    "With each flick of her tongue and every eager suck, she drove him to the brink of ecstasy, his moans escaping him in a chorus of pleasure he could no longer suppress."

    scene v20-57

    b "Do you like it?"

    k "You're driving me crazy, Banu..."

    k "Banu, you're... incredible."

    b "Glad you think so, Kamil."

    k "You're... driving me wild."

    b "That's the idea."

    k "I can't... I can't hold back much longer."

    b "Then don't."

    scene v20-58

    k "Oh, Banu... that feels... amazing."

    b "Glad you're enjoying yourself, Kamil."

    k "Ohhhhhhhhh....shit...."

    b "Aren't you worried your dad might hear your moans?"

    k "Banu, please... don't... think about him..."

    b "But imagine if he did... hearing you moan while I... pleasure you like this."

    k "Banu, stop... ah... teasing..."

    scene v20-59 with hpunch

    "Kamil's heart leaped into his throat as his father's booming voice filled the room."

    cam "Kamil, where the fuck have you been? I've been waiting for you."

    k "Dad, I... uh... I was just... um..."

    cam "Well? I don't have all day, Kamil."

    k "I... I was just... ah... finishing up something, Dad. I'll be right with you."

    scene v20-60

    cam "Kamil, why are you standing here like a deer caught in headlights? I've been waiting for you."

    k "Oh, uh, sorry, Dad. I was just... lost in thought."

    cam "Lost in thought?"

    "Kamil's heart skipped a beat at the implication in his father's words, his mind racing to come up with a convincing response."

    k "Yes, yes, just lost in thought. I was, uh, just about to join you."
    stop music
    scene v20-61

    "Banu intensifies her movements, determined to push Kamil over the edge."
    play sound "voices/man2.mp3"
    k "Ahhhhhhh......"
    stop sound
    k_ "NOOO....Banu...please, stop this...please stop...."

    cam "Kamil, what the hell is wrong with you?"

    k "Ohhhhhh....shit....."

    k_ "NOOOOO........"

    cam "You're making those noises, and I'm tired of your nonsense!"

    k "Dad, I-I'm sorry, I didn't mean to..."
    play sound "voices/man3.mp3"
    k "Ohhhhhh....shit.."
    stop sound
    scene v20-62

    cam "Kamil, you worthless piece of trash! What the hell do you think you're doing, making those goddamn noises?"

    k "Dad, I-I..."

    cam "Shut your mouth, you pathetic excuse for a man! I should beat the living hell out of you right now!"

    k "Dad, please, I didn't—"

    cam "You think you can act like some kind of animal in my house? I'll teach you some respect, you little shit!"

    show banusuckkamildadstandingkitchen
    play music2 "voices/suckdick.mp3"
    b_ "What? My house? Go to hell, bastard."

    cam "What the hell is wrong with you, Kamil? Can't you keep it together for one damn minute?"
    play sound "voices/man2.mp3"
    k "I.....ohhhh...."
    stop sound
    cam "Answer me, you fucking idiot."

    cam "Do you think you can ignore me, you fucking piece of shit."

    k "I'm sorry, Dad. It's just..."

    cam "Just what? Speak up!"

    cam "Where's Banu?"
    play sound "voices/man3.mp3"
    k "I... uh... I was just feeling a bit... uh..."
    stop sound
    cam "Feeling what? Spit it out!"

    k "I-I was feeling a bit... good, Dad. Banu... she was just... uh..."

    cam "What? What was she doing?"

    k "She... she was... uh..."
    stop music2
    scene v20-63

    "Kamil's whole body tenses up, and he lets out a low groan. His breathing gets all heavy and fast, and then suddenly, bam!"

    cam "Speak to me, idiot!"

    "It's like this intense wave of pleasure just crashes over him, and he can't hold back anymore. He lets go and releases himself, feeling all shaky and weak afterward."
    play sound "voices/man2.mp3"
    k "Ohhhhhhh....dad..."
    stop sound
    cam "What the hell?"

    k "...."

    scene v20-64

    k "Sorry about that, Dad. Didn't mean to freak you out."

    cam "You need to start showing some respect around here, Kamil. I won't tolerate this behavior."

    k "I understand, Dad. I'll work on it."

    cam "Good. Now, I need some time alone. We'll talk more later."

    k "Okay, Dad."

    scene v20-65 with fade

    "After their tense exchange, Camal decides to leave the room, his anger gradually subsiding. "

    "Kamil remains frozen in place, his mind reeling from the intensity of the situation."

    "As his father exits, a heavy silence descends upon the room, leaving Kamil feeling both relieved and apprehensive about what comes next."

    scene v20-66

    "Kamil's gaze lingering on Banu's cum-filled lips, a mixture of desire and tenderness in his eyes."

    "Banu meets his gaze, a playful glint in her eyes despite the situation."

    scene v20-67

    k "You almost got me killed."

    b "Ohh..sorry about that. I was just carried away a bit and didn't notice your father."

    k "Oh God..."

    k "You're something else, Banu..."

    b "You're not so bad yourself, Kamil. You almost choked me with your cum."

    k "I'm sorry about that. That was... intense."

    b "No need to apologize, Kamil. I rather enjoyed it."

    k "Come on, let's get out of here before he notices."





    $ renpy.end_replay()
    $ persistent.banu_suck_kamil_dadwatch_unlocked = True
    jump banu_suck_kamil_dadwatch_continue








label kamil_fuck_banu_necklace:





    scene black with dissolve

    "..."



    scene v20-90 with dissolve

    "In the heat of the argument, tensions flare between Kamil and Banu. "

    "Banu demands that Kamil's father leave the house immediately, accusing him of inappropriate behavior after catching him checking her out. "

    "But Kamil, torn between his loyalty to his wife and his sense of duty to his father, hesitates to take action."

    b "I can't believe you're defending him! After what I saw, you're still siding with him?"

    k "I'm not defending anyone, Banu. But he's my father, and I can't just kick him out because of some misunderstanding."

    b "Misunderstanding? He was practically ogling me, Kamil! I felt so uncomfortable!"

    k "I understand that, but he's from a different generation. He probably didn't mean anything by it."

    scene v20-91

    b "That doesn't excuse his behavior! I won't tolerate being objectified in my own home."

    k "I get it, Banu. But please try to understand my position. He's my dad, and I can't just kick him out onto the streets."

    b "Well, I won't stand for it. If you won't do something about it, then I will."

    k "Banu, please. Let's not make any rash decisions."

    b "Rash decisions? I've had enough, Kamil. I won't stay in a house where I don't feel safe."

    k "Fine, Banu. If that's what you want, then I'll talk to him. But please, let's try to resolve this without making things worse."

    scene v20-95

    b "I just can't take it anymore, Kamil. I feel trapped in this house, suffocated by your father's presence."

    b "It's like I have no say in anything anymore. I miss the freedom I used to have, the independence..."

    k "I understand, Banu. I know it's been hard for you, and I'm sorry. "

    b "I just wish things could go back to how they were before... When it was just you and me, without all this drama."

    "As Banu stands facing the wall, lost in her thoughts, she feels a gentle touch on her neck."

    scene v20-96 with fade
    play music "audio/romantic.mp3"
    "Her eyes widen in surprise."

    k "Banu, I know things have been tough lately, and I wanted to do something to show you how much you mean to me."

    "Banu's breath catches in her throat as Kamil gently places the necklace around her neck."

    b "Kamil, I... I don't know what to say..."

    scene v20-97

    k "You don't have to say anything, Banu. Just know that I love you, and I'll always be here for you."

    b "Thank you, Kamil. "

    scene v20-98 with fade

    "Tears prickle at the corners of Banu's eyes as she throws her arms around Kamil, holding him close."

    "In that moment, all the tension and frustration melt away, replaced by a deep sense of love and gratitude."

    b "This means more to me than you'll ever know."

    "They stand there together, wrapped in each other's arms, the weight of their troubles momentarily forgotten. "

    "Banu's voice, barely more than a whisper, fills the air with an intoxicating mix of desire and longing."

    b "Kamil... I want you. Right now. I need you to touch me, to take me..."

    scene v20-99

    b "I want to feel your hands on me, your lips trailing kisses down my body..."

    b "I want to lose myself in you, to forget everything else but this moment..."

    "As the fabric falls away, her breasts are revealed, bathed in the soft glow of the moonlight streaming through the window. "

    b "Do you like what you see, Kamil?"

    scene v20-100 with fade

    "As Banu strips down, her body revealed in all its glory, Kamil's pulse races with anticipation."

    "She steps up to him, her skin brushing against his, and he pulls her close, feeling the heat radiating from her naked form."

    "They lock lips in a fiery kiss, tongues tangling in a frenzy of desire. With each touch, each caress, they ignite a fire that burns hotter than the desert sun."

    "It's raw, it's intense, and it's exactly what they both crave in this moment of unbridled passion."

    b "Damn, Kamil... My pussy's on fire for you. Can you feel it?"

    k "Oh yeah, Banu... I can feel it. You're driving me crazy."

    b "I want you so bad, Kamil. I want to feel you inside me, filling me up and driving me wild."

    k "You know I can't resist you, Banu. You're all I think about, all I want."

    b "Then take me, Kamil. Take me hard and fast, until we both can't take it anymore."

    k "You got it, baby. I'm gonna make you scream my name."
    stop music
    scene v20-101 with fade
    play music "voices/longhardmoan.mp3"
    "As Banu straddles Kamil, their bodies pressed together in a feverish embrace, she looks down at him with eyes filled with desire."

    b "You ready for this, Kamil? You ready for me to ride you like there's no tomorrow?"

    k "Hell yeah, Banu. I've been waiting for this moment all damn day."

    b "Mmm... You feel so good inside me, Kamil. I never want this moment to end."

    k "I can't get enough of you."

    b "Don't hold back, Kamil. Give it to me hard, just like I like it."

    scene v20-102

    b "Oh God, Kamil... I'm gonna cum so hard. Don't stop, baby, don't you dare stop!"

    k "That's it, Banu... Cum for me, baby. Let me feel you shake."

    b "Yes, yes, yes! Oh fuck, Kamil!"

    b "Oh yes, yes, yes! Fuck, Kamil, I'm cumming so hard!"

    k "That's it, baby. Let it all out. Cum for me, Banu."

    b "Oh God, Kamil, I can't... I can't stop!"

    scene v20-102 with flash

    b "Ahhhhhhhhhhhhhhhh......"

    k "Damn, you really needed this, baby."

    scene v20-103 with fade

    b "Oh fuck, Kamil... What are you doing?"

    "Kamil's eyes burn with desire as he positions Banu upside down on the bed, her pussy exposed and waiting for him."

    k "I'm gonna eat you out like never before, Banu. Get ready for the ride of your life."

    "With that, he dives in, his tongue tracing slow circles around her throbbing clit as he savors her sweet taste."

    b "Oh God, Kamil... That feels amazing! Don't stop, baby, please don't stop!...Ahhhhhhhh...."

    scene v20-104

    "Kamil's lips and tongue work their magic, driving Banu wild with desire as he devours her with reckless abandon."

    k "I'm gonna make you cum so hard, Banu. I want to taste every drop of your sweet nectar."

    "Banu's body trembles with anticipation as Kamil's skilled tongue sends shockwaves of pleasure coursing through her veins."

    b "Yes, yes, yes! Fuck, Kamil, I'm gonna cum again!"

    b "Oh God, Kamil! Yes, yes, yes! I'm cumming again!"

    scene v20-104 with flash

    b "Ohhhhhhh.....shit....GOD...."

    k "That's it, Banu. Let it all out. Cum for me, baby."

    b "Damn, Kamil, you pussy hungry asshole....ahhhhh..."

    b "Fuck, Kamil! Don't stop, please don't stop!"

    scene v20-105 with fade

    b "Ahhhhh....what...."

    "Before she can register his reaction, Kamil seizes her, flipping her over and positioning her upside down."

    k "You want to call me an asshole, Banu? I'll show you what a real asshole can do."

    "With that, he plunges into her with a force that leaves her breathless, her cries of pleasure mingling with his own primal grunts."

    scene v20-106

    b "Oh fuck, Kamil! Yes, yes, yes!"

    "Her words are lost in a haze of ecstasy as Kamil pounds into her with relentless determination, each thrust driving her closer to the edge of oblivion."

    k "That's it, Banu. Take it all. You asked for this, remember?"

    "Banu's body quakes with the force of her pleasure, her senses overwhelmed by the sheer intensity of their passion."

    b "Yes, Kamil! Fuck me harder! I want it all!"

    "Together, they lose themselves in a frenzy of desire, their bodies moving in perfect harmony as they chase the ultimate release."

    scene v20-107

    "Kamil raises Banu's body completely from the bed, his strength and passion driving them both to new heights of ecstasy."

    b "Oh God, Kamil, you're gonna destroy my tight pussy....Oh fuck, Kamil! Yes, yes, yes! Pound me harder!"

    k "You want it harder, Banu? You want me to fuck you like the dirty slut you are?"

    b "Yes, Kamil! I want it all! I want you to fuck me until I can't take it anymore!"

    k "That's it, Banu. Let go. Give in to the pleasure. I want to hear you scream my name."

    scene v20-108

    b "Fuck me harder, Kamil, HARDER....if you don't fuck me harder, I'll shit on your dad's mouth, Kamil! Fuck me harder!"

    k "You want to talk about my dad like that, Banu? You want to disrespect him? I'll show you what happens when you cross the line."

    b "Ohhhh shit yeah, I wanna see what you can do...."

    k "You wanted it harder, didn't you? Well, now you're going to get it."

    b "Ohhhhhh, shit baby...keep going...."

    k "You like that, Banu? You like it when I take control like this?"

    b "Yes, Kamil... I... I like it... More than I thought I would..."

    scene v20-109 with fade
    stop music

    b "Oh, Kamil... This feels so good..."

    "Her voice is filled with a mixture of excitement and desire as she lowers herself onto him, relishing the feeling of him filling her completely."

    k "You like that, Banu? You like it when you're in control?"

    scene v20-110
    play music "voices/longmoan.mp3"
    b "Yes, Kamil... I love it... I love feeling you inside me..."

    k "That's it, Banu... Ride me... Show me how much you want it..."

    b "What if your dad walks in right now?"

    k "Banu... I don't know... It would be so..."

    b "It would be so naughty, wouldn't it? So... exhilarating..."

    b "Imagine your dad walks in right now and sees me like this riding you, completely naked and his dick pops out of his pants..."

    k "God, Banu... I don't think I could handle it..."

    b "Kamil... I want it... I want you to put it in my ass..."

    k "Banu... Are you sure? It's... it's not something we've..."

    b "Yes, Kamil... I'm sure... My ass is on fire... I need you to put it in me.."

    k "God, Banu... You drive me crazy... Okay, let's do it..."

    scene v20-111 with fade

    "Banu's moans fill the room, a symphony of ecstasy as Kamil enters her from behind, his movements slow and deliberate as he eases into her tightness."

    b "Oh, Kamil... Yes... Fuck my ass... Harder..."

    show kamilfucksbanuasspurerouteanimation

    k "You like that, baby? You like it when I fuck your ass?"

    b "Yes, Kamil... Yes... More... Harder..."

    k "You're so fucking tight, Banu... So fucking hot..."

    k "Ohhh fuck, I can't believe such a good religious woman like you enjoys getting fucked in the ass...shit... "
    play sound "voices/fart1.mp3"
    k "Ohhh...shit. What was that?"
    stop sound
    k "Damn, what kind of fart was that?"
    b "Ahhhh....I lost myself..."
    scene v20-112

    b "Oh, Kamil... You should know by now... There's a lot you don't know about me..."

    k "I guess I underestimated you, Banu... But I'm not complaining..."

    b "Oh, Kamil... You drive me wild... I never knew it could feel this good..."

    k "You're so beautiful, Banu... So damn sexy..."

    show kamilfucksbanuasspurerouteanimation

    b "Oh, Kamil... Yes... Harder... Deeper..."

    b "Yes... Oh, yes... More... Give it to me..."

    k "You feel so fucking good, Banu... So tight... So fucking hot..."

    b "Fuck me, Kamil! Fuck me like you've never fucked me before! Make me scream your name and forget everything but the pleasure you're giving me!"

    k "You want it harder, baby? You want me to fuck you until you can't think straight? Until you forget everything but the pleasure I'm giving you?"

    scene v20-113

    b "Yes, Kamil! Yes! Fuck me harder! Make me forget everything but the feel of your body against mine! "

    b "Come on, Kamil... Give it to me... I want to feel you cum inside me... "

    b "I want to feel your hot release filling me up... Fuck my ass until you can't hold back any longer..."

    k "Oh, fuck... Banu... I'm gonna cum... I can't hold back any longer..."

    b "Yes, Kamil... Yes... Cum for me... Fill me up with your hot release... I want to feel you pulsing inside me... I want to feel every last drop of your pleasure..."
    play sound "voices/man1.mp3"
    k "Ohhhhhhhhhhhhh........"
    stop music
    stop sound
    scene v20-114

    "As Kamil withdraws from Banu, a cascade of warm, sticky fluid spills from her, pooling on the sheets beneath her."
    play sound "voices/fart2.mp3"
    b "Oh, fuck... That was intense, Kamil... Look at all this cum pouring out of my ass..."
    stop sound
    k "Damn, Banu... You're incredible... I've never seen anything like it.."

    "Kamil's eyes widen in awe as he takes in the sight, his own breath catching in his throat as he's overcome by the raw intensity of their shared release."

    scene v20-115

    k "B...Banu...what are you doing?"

    "Banu's lips wrap around Kamil's sensitive flesh, her tongue swirling eagerly over the remnants of their shared passion. "

    "With each lascivious lick, she sends shivers of pleasure coursing through him, her sultry gaze meeting his as they dive headfirst into the depths of their desire."

    b "Mmm... You taste so good, Kamil... I could do this all night long..."

    scene v20-116
    play sound "voices/man3.mp3"
    k "Banu... What...shit..."
    stop sound
    b "Shh... Just relax, Kamil... I want to make you feel good..."

    k "But... But you've never... I mean, we've never..."

    scene v20-117

    b "Mmm... I know, Kamil... But tonight, I want to try something new... Just let go and enjoy it.."

    b "This feels so good, Kamil... Almost as good as your dad's stories, huh? I bet he never got his dick sucked..."

    k "Hey now, Banu... Let's keep my dad out of this, okay? He's got nothing to do with what's going on here..."

    b "Oh, come on, Kamil... Where's your sense of adventure? I bet your dad would be proud of you right now... Don't you think?"

    "Her words are a tempting invitation, her eyes dancing with mischief as she dares him to embrace the thrill of the forbidden."




    $ renpy.end_replay()
    $ persistent.kamil_fuck_banu_necklace_unlocked = True
    jump kamil_fuck_banu_necklace_continue



label banu_kamil_outside_sex:






    scene black with dissolve
    play music "audio/chill.mp3"
    "..."

    scene v20-120 with pixellate




    k "Hey Banu, watch out for that bump!"

    b "I see it, I see it! You're not trying to lose me, are you?"

    k "Of course not! I wouldn't dare. Who would cook for me then?"

    b "Ha! You're just afraid of my cooking skills surpassing yours."

    k "Oh please, Banu. No one can beat my famous scrambled eggs."

    scene v20-121 with fade

    b "We'll see about that. Maybe I'll challenge you to a cook-off when we get back."

    k "Deal! But first, let's see if you can keep up with me on this trail."

    b "Challenge accepted, Kamil. Just don't cry when I leave you in my dust."

    k "We'll see who's crying when I zip past you like a pro cyclist."

    b "Dream on, Kamil. Dream on."

    scene v20-122 with fade

    k "Hey, Banu, you're falling behind! Need me to slow down a bit?"

    b "No way, Kamil! I'm just giving you a chance to catch up."

    k "Sure, sure. I can practically see the cobwebs forming on your bike."

    b "Oh, come on! My legs are just taking a little break, that's all."

    k "Alright, alright. But don't blame me if I leave you in the dust!"

    scene v20-123 with fade

    k "Well, look who finally made it to the finish line! I guess I'll have to admit defeat this time."

    b "Oh, don't be so hard on yourself, Kamil. It's all about the journey, not just the destination."

    k "True, true. And I have to say, the journey's been pretty amazing with you by my side."

    scene v20-124

    k "Wow, would you look at this place? It's like something out of an adventure movie."

    b "I know, right? It's so serene and mysterious. I feel like we're on our own little expedition."

    k "Definitely. Hey, maybe we could explore around here a bit. See if we can find any hidden treasures or secret passages."

    b "Haha, that sounds like fun! Who knows what we might discover?"

    k "Exactly! And even if we don't find anything, just being out here, exploring together, is an adventure in itself."

    k "So, what do you say? Ready to embark on our next great adventure?"

    b "Absolutely! Lead the way, fearless explorer."

    scene v20-125 with fade

    k "I think we can leave our bikes here. They'll be safe, and it'll be easier to explore on foot."

    b "Good idea. Plus, it gives us more freedom to roam around without worrying about them."

    scene v20-126

    "With every step, they can feel the rush of adrenaline coursing through their veins. It's like they're on their own wild adventure, far from the worries of the world above."

    "As they dash towards the bridge, their hearts pounding with adrenaline, Kamil grabs Banu's hand, and they race like there's no tomorrow."

    scene v20-127

    "It's like a scene out of a movie, with Kamil and Banu as the daring protagonists, ready to seize the moment."

    scene v20-128

    "They reach the shadowy haven beneath the bridge, and without hesitation, they dive into each other's arms."

    "Their laughter turns into breathless gasps as they realize they're alone, hidden from prying eyes."

    "With a devilish grin, Banu tugs at Kamil's hand, urging him deeper into the darkness. "

    scene v20-129 with fade

    "They find a cozy spot away from the world above, where the only sounds are the rush of the river and the pounding of their hearts."

    "As Kamil's lips meet Banu's pulsating heat, a shiver runs down her spine, and she lets out a low, sultry moan."

    scene v20-130

    b "Oh, Kamil..."

    b "That's it, just like that."

    "Kamil's tongue dances expertly over her folds, tracing every curve and dip with precision."

    b "Yes, right there..."

    b "Don't stop, Kamil. Don't you dare stop."

    b "Ahhhhhh...I need more, Kamil. I need all of you."





    k "You taste so damn good..."

    k "I could do this all day, Banu. Just for you."

    k "Hold on tight, because I'm about to take you to paradise."

    scene v20-131 with fade

    "As Kamil's tongue delves deeper, Banu's breath hitches in her throat, and she moans uncontrollably. "





    b "Ohhhh....You're driving me insane."

    b "Don't you dare stop, Kamil. I need more."

    k "I want to make you cum so hard..."

    b "Fuck me with your tongue, you dirty bastard."

    scene v20-132

    "Banu's voice, laced with desire and command, cuts through the air. "

    b "Now Kamil, lick my asshole clean."

    k "Are you sure, Banu?"

    b "I want you to taste every part of me, Kamil."

    k "As you wish, my love..."

    scene v20-133

    b "Ahhhhh.....yessssss..right there..."

    b "That feels so fucking good."

    b "You always know just what I need."

    b "You dirty little fucker...yesss....like that...Ahhhh..."

    b "You like that, don't you? Tongue-fucking my asshole like some perverted animal."

    k "I love every filthy moment of it."

    k "But now it's my turn to get what I want..."

    scene v20-134 with hpunch

    k "Hey, stop!"

    "With a mischievous glint in her eyes, Banu darts away, her laughter echoing through the empty space beneath the bridge."

    b "Come and get me if you can!"

    "Kamil's muscles tense with determination as he pursues her, his senses alive with the thrill of the chase. "

    scene v20-135

    k "Slow down, will you?"

    b "You'll have to catch me first!"

    b "Looks like you'll have to try a little harder."

    scene v20-136 with fade
    play sound "voices/fart3.mp3"
    "Banu, running through the field naked, suddenly lets out a fart, which breaks the silence of the surroundings. "
    stop sound
    b "Oops, looks like I let one slip!"

    k "You're lucky we're outside!"

    b "Hey, when nature calls, you answer!"

    k "Fair enough, but you're not getting away that easily!"

    b "You'll have to catch me first!"

    scene v20-137

    k "Just you wait, I'll get you!"

    b "Come on then, show me what you've got!"

    scene v20-138 with fade

    "Kamil finally catches up to Banu and, in a standing position, lifts one of her legs in the air and inserts his hard dick inside of her."

    "As Kamil thrusts inside Banu, their breaths become heavy with desire."

    b "Oh, Kamil, that feels so good. Keep going."

    k "You like that, huh? You're so damn sexy, Banu."
    stop music
    scene v20-139

    b "Mmm, yeah. I love feeling you inside me. Harder, Kamil, give it to me harder."

    k "You want it harder? You got it, baby. Just hold on tight."

    b "Oh god, yes! That's it, Kamil. Don't stop!"

    k "I won't, Banu. I'm gonna fuck you so good."

    show kamilfuckbanustandingbiking
    play music "voices/longmoan.mp3"
    k "You want me to fuck you like an animal?"

    b "Yes, Kamil, please! Pound me harder!"

    k "You're such a dirty girl, Banu. Begging for my cock like this."

    b "I can't help it, Kamil. You drive me crazy. Harder, please!"

    k "You like it rough, huh? You want me to make you scream?"

    b "Yes, Kamil! Make me scream."

    scene v20-140 with fade

    k "Ride me, Banu. Show me how badly you want it."

    b "I want it so bad, Kamil. I need you deep inside me."

    show kamilfuckbanureversebiking

    k "That's it, baby. Bounce on my cock like you mean it."

    b "Oh god, Kamil! Your cock feels amazing inside me."

    k "You like that, huh? You like feeling me fill you up?"

    b "Yes, Kamil! I love it! Don't stop, keep fucking me!"
    stop music
    scene v20-141

    b "Oh, Kamil! I'm gonna cum! I'm gonna cum so hard!"

    k "Cum for me, Banu! Let it all out!"

    b "Yes! Yes! Oh, fuck!"

    k "I'm right there with you, baby! I'm gonna cum inside you!"

    scene v20-141 with flash
    play sound "voices/fastmoan2.mp3"
    b "Ahhhhhh....Kamil..."
    stop sound
    play sound "voices/man3.mp3"
    k "Banu....Ohhhhh....damn..."
    stop sound
    "..."

    scene v20-142 with fade

    k "Damn, Banu, that was wild! Running naked through the fields and then doing it under the bridge? "

    k "We're like characters from some crazy movie!"

    b "I know, right? I never thought I'd be the type to do something like that."

    k "I mean, who else can say they've had sex under an abandoned bridge?"

    scene v20-143

    b "Exactly! It's like we're living life to the fullest, doing things most people only dream of."

    k "That's what I love about you, Banu. You're always up for an adventure."

    b "Well, you're not so bad yourself, Kamil. I mean, who else would chase after their naked wife through a field just to catch her?"

    k "I guess I'm just lucky to have you even if you do fart while running. "

    b "Hey, it adds to the adventure, right?"

    k "Definitely. I wouldn't change a thing about today."

    b "Me neither. "



    $ renpy.end_replay()
    $ persistent.banu_kamil_outside_sex_unlocked = True
    jump banu_kamil_outside_sex_continue








label banu_wash_dad_back:





    scene black with dissolve
    play music "audio/weakbanu.mp3"
    "..."

    scene v20-144 with pixellate

    b "Goddamn it, Kamil! Always the fucking job, always his precious work."

    b "Doesn't give a shit about me. Asshole!"

    b "Selfish piece of shit! I'm so sick of this! Why the hell did I marry him if he's just gonna ignore me all the time?"

    b "Fuck him and his stupid job! He doesn't even realize what he's losing. Idiot."

    scene v20-145

    b "What the...?"

    "She freezes, her eyes darting towards the sound. Her heart pounds as she slowly realizes someone is in there. "

    "Curiosity and a hint of fear take over as she creeps closer to the shower, careful not to make any noise."

    b_ "What is he doing here?"

    "Banu watches in stunned silence as the water cascades down Camal’s broad back."

    scene v20-146

    "The steam swirls around his muscular frame, highlighting every contour and ripple of his powerful body. "

    b_ "Oh my god, what am I doing? This is Kamil's father... I shouldn't be looking."

    b_ "He’s so... massive. Those arms, those shoulders... damn, why am I feeling like this? This is wrong."

    b_ "Get a grip, Banu. This is crazy. But... god, look at him. No wonder Kamil is so intimidated by his father."

    b_ "I shouldn't be here. I shouldn't be feeling this... but I can’t stop. He’s just so... powerful. I can’t believe I’m getting turned on by this."

    scene v20-147

    b_ "I need to get out of here before he sees me. But... just a little longer. Just a few more seconds."

    b_ "God, if he ever found out... if Kamil ever knew... I can't even think about that. But right now, I can't stop watching."

    b_ "Damn, why my body reacts to this?"

    b_ "But look at his physique....he looks like a monkey....a large monkey..."

    b_ "I can't imagine what it would feel like having sex with a man like him....oh my god...."

    b_ "We don't have sex with Kamil so often, that is why I'm feeling like this..."

    b "Come on, Banu...stop this...I have to get out of here..."

    scene v20-148 with hpunch

    cam "Banu, what the fuck are you talking there. Are you mad or what talking to yourself like that?"

    b_ "Shit, shit, shit...he noticed me..."

    b "I'm sorry, father, I didn't see you are here."

    cam "Are you fucking with me? You've been here for 5 minutes already."

    b_ "What?..."

    cam "If you need something, take it. Don't be shy."

    scene v20-149

    b "Oh uncle Camal, I'm sorry to interrupt your shower. I just wanted to grab some soap before I head off to bed. Is it okay if I use this one?"

    cam "Yeah, come and take whatever you want."

    b "Okay father."

    cam "Why did you take so long?"

    b "I'm sorry, father but you...are here..."

    cam "Come and take it. I won't eat you. Stupid girl. "

    b "Okay..."

    scene v20-150

    cam "Hey, since you are here, rub some soap on my back before you leave."

    b "...."

    cam "Hey, what are you waiting for?"

    b "Of course, father...."

    cam "So how Kamil is treating you?"

    scene v20-151

    b "We are getting along well. "

    cam "You were fighting earlier today. What happened?"

    b "Ahh you heard us fighting?"

    cam "Do you think I'm stupid?"

    b "Of course not. How would I even think that?"

    scene v20-152

    cam "If my son ever treats you bad, I'll kick him out of this house."

    b "Thank you for standing up for me, dad. That means a lot to me."

    cam "You remind me my deceased wife, you are so curvy and beautiful like her."

    b "I'm sorry for your wife, I feel that she was a wonderful woman. "

    cam "So, Banu, how's everything between you and Kamil? Is he treating you right in every way?"

    b "I... I don't think we should be talking about this, uncle Camal."

    cam "It's just a conversation. You can be honest with me."

    scene v20-153

    b "It's... not perfect. There's something missing."

    cam "Something missing? Like what?"

    b "I can't seem to... have an orgasm with him. No matter what we do."

    cam "That's a serious issue, Banu. Have you talked to Kamil about it?"

    b "I've tried, but he doesn't seem to understand. He thinks it's just something wrong with me."

    cam "There's nothing wrong with you, Banu. Every relationship needs work. Maybe he needs to learn how to be more attentive."

    cam "You know, Banu, Kamil is not like I was at his age. When I was younger, I knocked up so many women in the village."

    cam "I had a reputation, you could say. But Kamil, he's different. He's more... reserved."

    "Banu, continuing to soap Camal's back, feels a rush of unexpected arousal at his words. "

    b "I see. Kamil is a bit shy."

    cam "Yes, that's probably why you don't have as many children. He's not as... aggressive, I guess you could say."

    "Banu's thoughts swirl as she works the soap over Camal's broad shoulders, her hands trembling slightly."

    b "It's... different, I suppose..."

    scene v20-154 with vpunch

    "Camal suddenly turns to face Banu, his naked body fully exposed. "

    "Banu gasps, her eyes widening in shock and her breath catching in her throat."

    cam "Banu, there's no need to be shy. We're just talking."

    b "I... I didn't expect you to turn around like that."

    cam "I could tell you were feeling something. There's nothing wrong with that. It's natural."

    b "But, uncle Camal, this isn't right. You're Kamil's father."

    cam "I'm also a man who understands your needs, Banu. You deserve to feel desired, to be satisfied."

    cam "Soap my chest? It’s hard to reach some spots on my own."

    b "O-okay, uncle Camal."

    scene v20-155

    "She tries to focus on the task at hand, doing her best to avoid looking down at his cock."

    cam "Thank you, Banu. It feels nice having someone take care of me."

    b "You're welcome, Camal. I'm just... trying to help."

    b_ "Oh my god, what am I doing? This is so wrong... but it feels so right."

    b_ "I can't believe I'm so close to him, touching him like this. His body... it's incredible. Why is this turning me on so much?"

    b_ "I shouldn't be feeling like this. He's Kamil's father. But god, I can't help it. I want him. I want him so badly."

    b_ "His eyes... the way he's looking at me. It's like he can see right through me, see how much I want this."

    b_ "He knows. He can see it in my eyes. He knows how turned on I am. What if... what if I just gave in?"

    b_ "Just this once. No one has to know. It could be our secret. But... can I really do that?"

    scene v20-156

    "As Banu's eyes inevitably drift downward, she catches sight of Camal's semi-erect cock."

    b_ "Oh my god, it's so big... I can't believe I'm seeing this. How is it even possible? Kamil is nothing like this... This is... unreal."

    b_ "I shouldn't be looking... but I can't help it. It's mesmerizing. Why does this turn me on so much? I can barely think straight."

    b_ "What am I doing? This is so wrong, but... I can't stop. I've never felt like this before. "

    b_ "This is insane. I should leave... but I can't."

    scene v20-157

    b_ "It's huge... I can't believe how big it is. The thickness, the length... I've never seen anything like this before. Kamil is nowhere near this size."

    b_ "How would it feel inside me? Could I even take it all? The thought alone is driving me crazy. I've never been this turned on in my life."

    b_ "I shouldn't be doing this. This is wrong on so many levels. But... I can't stop."

    b_ "What if he wants this too? What if he can satisfy me in ways Kamil never could? The thought is intoxicating... maybe just one touch, just to see how it feels."

    scene v20-158

    cam "What are you thinking?"

    b "I... I wasn't thinking... I mean, I was just... I didn't mean to..."

    cam "No need to be nervous. It's just a question. What were you thinking?"

    b "I was just... surprised. You're... um... you're very different from Kamil."

    cam "Different how?"

    b "You're... more... well, you're just... more."

    cam "More what, Banu? Be honest."

    scene v20-159

    b "More... everything. It's hard not to notice."

    cam "It's natural to be curious, Banu. There's nothing wrong with that. But you should be clear about what you want."

    b "I... I don't know what I want. I'm just... confused."

    scene v20-160

    "As they talk, Banu suddenly feels a pressure against her skirt and realizes with shock that it's Camal's body pressing against her."

    b "Uncle Camal, what are you doing?"

    b_ "Oh my God, what is happening? Is that... is that what I think it is? I can't believe this. Why is he doing this? This is so inappropriate."

    scene v20-161

    b_ "I should step away, but why am I hesitating? This is wrong on so many levels. I need to get out of here, but my body feels frozen."

    b_ "Camal has always been so composed and respectful. Why now? Why this? I can't let myself get pulled into this. I have to think about Kamil, about our marriage."

    b_ "I need to set boundaries right now. This can't happen. I can't let this get out of control."

    b "This is too much. We need to keep our boundaries clear. I can't deal with more confusion right now."
    stop music
    scene v20-162

    b "Uncle Camal, this isn't right. I need to go."

    cam "Banu, wait—"

    b_ "I need to get out of here. This can't happen. I need to talk to Kamil about his dad."

    b_ "I have to focus on my marriage."

    "Camal watches her, his eyes following her every move."

    "His towering presence and fully erect cock make the situation even more intense, but Banu focuses on getting out of the bathroom."





    $ renpy.end_replay()
    $ persistent.banu_wash_dad_back_unlocked = True
    jump banu_wash_dad_back_continue









label banu_masturbate_dad:





    scene black with dissolve
    play music "audio/weakbanu.mp3"
    "..."

    "It's already the evening but Kamil hasn't come yet."

    "Banu stands in front of the bathroom mirror, her frustration boiling over."

    scene v20-175 with dissolve

    "She’s in her nightwear, the soft fabric clinging to her as she brushes her hair absentmindedly. "

    "Her mind races with thoughts of anger and betrayal, and she can’t hold back her emotions any longer."

    b_ "That asshole. How dare he leave me here all day? He knows how much this means to me, but he just doesn’t care. He's always so damn selfish."

    b_ "I can’t believe I let him talk to me like that. Like I’m some kind of inconvenience. Fuck him! He’s such a prick for choosing his friends over me, again and again."

    scene v20-176

    b_ "Goddamn it, Kamil! Why do you always have to be such a fucking jerk? I’m your wife, for fuck's sake! I deserve better than this."

    b_ "I’m done feeling like this. I’m done being second place. If he can’t see how much he’s hurting me, then he’s not worth my tears."

    b_ "You hear that, Kamil? You’re not worth it. You’re not worth this pain. I deserve so much more than what you’re giving me."

    scene v20-177

    "As Banu stands there, seething with anger, the bathroom door suddenly opens."

    "Camal's presence surprises her, but she’s too angry to care."

    cam "Banu, have you seen Kamil? I’ve been looking for him."

    b "No, I haven’t seen him. He’s been out with his friends all day, as usual."

    cam "Is everything alright, Banu? You seem upset."

    scene v20-178

    b "Upset? That’s an understatement. Your son is an asshole, Camal. He doesn’t care about me or our marriage. All he cares about is his damn friends!"

    cam "Watch your tone, Banu. He’s my son and your husband, and I won’t have you speaking about him like that."

    b "Well, maybe if he acted like a husband instead of a child, I wouldn’t have to!"

    cam "You forget your place, Banu. Kamil works hard, and he deserves some time with his friends. You should support him, not berate him."

    b "Support him? I’ve been supporting him! But what about me, Uncle Camal? I deserve respect and attention too. I’m his wife, not his servant."

    cam "You’re walking on thin ice, Banu. This attitude of yours won’t help anything."

    cam "You’ve got some nerve, speaking to me like this. But fine, you want to stand up for yourself?"

    scene v20-179

    b_ "I can feel the heat radiating from him. He's so close. I shouldn't be thinking like this, but I can't help it."

    b_ "Get it together, Banu. This isn't the time or place. But his eyes... they seem to see right through me."

    b_ "I need to focus. I need to make him understand my point. But why does he have to be so... intimidating and... attractive?"

    b "I....I have to go."

    scene black with dissolve

    b "..."

    scene v20-180 with fade

    b_ "Why did that conversation have to affect me so much? Camal's presence was overwhelming, and not just because he's Kamil's father."

    b_ "His eyes, his voice... they were so intense. I've never felt like this before. What is wrong with me? I should be focused on fixing things with Kamil, not getting distracted by his father."

    b_ "I need to get a grip. Camal is tough and intimidating, but that shouldn't affect me like this."

    b_ "Maybe it's just the stress of everything getting to me. I need to focus on what really matters."

    scene v20-181 with fade

    "As Banu slowly sheds her black nightwear, the fabric slipping off her curves like a whisper, she feels the cool air against her skin."

    "Her mind is consumed by thoughts of Camal."

    "His strong presence, his rugged masculinity, and the way he commands respect with every word and gesture."

    scene v20-182

    "She can't shake the image of his piercing gaze, how it seemed to see right through her, igniting a fire deep within her core."

    "Despite the taboo nature of her desires, she can't deny the intense arousal that courses through her veins whenever she's near him."

    "With each passing moment, her fantasies grow more vivid, her body yearning for his touch, his dominance."

    scene v20-183

    "In the solitude of her bedroom, she allows herself to indulge in these forbidden thoughts, knowing that they can never be spoken aloud."

    "Finally, she's completely exposed, her body illuminated by the soft glow of the moonlight filtering through the window."

    "She gracefully climbs onto the bed, the sheets cool against her heated skin, ready to indulge in the pleasures of the night."

    scene v20-184 with fade

    b_ "Why does he make me feel like this?"

    b_ "Camal... his presence, it's overwhelming. I shouldn't be thinking about him, but I can't help it."

    b_ "Every time he's near, I feel this uncontrollable need."

    scene v20-185

    "Her fingers moved faster, her breath coming in ragged gasps as she continued to imagine Camal."

    b_ "His eyes, the way he looks at me..."

    b_ "What would it be like to feel his big hands on my body, to be completely under his control?"

    b_ "No, I can't think like that... but I want to. God, I want to."

    b_ "I've never felt this way before. Not even with Kamil. This is different, raw, and so intense. I need this. I need him."

    scene v20-186
    play sound "voices/fastmoan2.mp3"
    b "Ahhhhh....."
    stop sound
    b_ "If only for a moment, I want to forget everything else. Just me and him, in this moment of pure, unbridled desire."

    b_ "What would he do to me? How would it feel to be taken by him? I can't stop... I don't want to stop."

    b "Ahhhhh....Camal..."

    scene v20-187

    "As Banu's pleasure built to an unbearable peak, her mind raced with thoughts she could barely control."

    "She raised her legs in the air, feeling the tension building up inside her. "

    b_ "Oh my God, I can't believe how good this feels. I'm so close, so close..."

    b_ "Why does thinking of him drive me this wild? His eyes, his touch... I can almost feel him here with me."

    scene v20-188
    play sound "voices/fastmoan1.mp3"
    b "Ohhhh....shit..."
    stop sound
    b_ "This is so wrong, but I need it. I need to feel this, to let go completely."

    b_ "Camal, what are you doing to me? I'm going to... I can't hold back."

    "Banu's moans filled the room, echoing off the walls as she called out Camal's name in the throes of ecstasy."

    scene v20-189
    play music "voices/longmoan.mp3"
    b "Camal... oh, Camal..."

    b "Yes, Camal... harder... yes..."

    b "Yes, yes, just like that. Let it happen. Camal, oh, Camal... I'm... I'm...!"
    stop music
    scene v20-190 with vpunch
    play music "audio/tension.mp3"
    cam "Banu."

    "Banu's heart nearly stops as she hears Camal's voice, sharp and clear in the heated silence of the room."

    scene v20-192 with fade

    "She looks up, her eyes wide with shock and embarrassment."

    scene v20-191 with fade

    "Camal stands at the foot of the bed, his expression unreadable."

    "It becomes evident that he has been there for some time, witnessing her intimate moment."

    "Her face flushes with a mix of arousal and mortification."

    scene v20-192

    "Banu's heart races as she scrambles to her knees on the bed, instinctively covering herself with her hands, her breathing still ragged from the intensity of her release."

    b "Uncle C-Camal... I... I didn't know you were..."

    cam "There's no need to explain."

    "Banu's mind races, torn between the lingering heat of her arousal and the overwhelming embarrassment of being caught."

    "She tries to steady her breathing, her body trembling with residual pleasure and nerves."
    stop music
    scene v20-193

    b "This... this isn't what it looks like..."

    cam "You don't have to be afraid. Just breathe."

    b "What are you doing here?"

    cam "I came to check on you. But it seems there's more going on than I expected."

    b "Please, uncle Camal, can you leave?"

    cam "Alright, Banu. I'll give you some space."

    "He turns to leave, giving her one last look before stepping out of the room, closing the door quietly behind him."

    b_ "What have I done? How did it come to this?"

    "She sits there for a few moments, the intensity of the encounter still coursing through her. "




    $ renpy.end_replay()
    $ persistent.banu_masturbate_dad_unlocked = True
    jump banu_masturbate_dad_continue








label pure:


    scene black with Dissolve(3)
    ""
    centered "{size=+120}1 year later...{/size}" with Fade(0.5, 0.5, 5)
    scene black with dissolve
    play music "audio/intro.mp3"
    b_ "Reflecting on the past year, I've seen profound changes in my life, especially within the confines of my relationship with Kamil, my husband."
    scene v18-355 with pixellate
    b_ "Our bond grew stronger, transforming into a partnership grounded in love and understanding."
    b_ "Kamil's protective nature, while sometimes restrictive, became a source of comfort, offering a sense of security I hadn't known before."
    b_ "Despite the limitations Kamil placed on my activities, I found solace in our shared moments. "
    b_ "Kamil prohibited me to go to the gym and he even made me quit my job and stay home."
    scene v18-356 with dissolve
    b_ "Reflecting on the past year, I noticed subtle changes in my physical appearance."
    b_ "Spending more time at home brought a certain comfort, but it also led to a shift in my body."
    b_ "I observed some changes, particularly in my arms and legs, where I felt a bit fuller."
    b_ "Perhaps the lack of regular exercise and the comfort of home-cooked meals contributed to these changes."
    scene v18-357
    b_ "The arrival of my daughter Leyla's marriage brought fresh happiness into our lives."
    b_ "Her visits, accompanied by her husband, became treasured occasions, reinforcing the importance of family."
    b_ "Our home echoed with laughter and love during their stays, reminding me of the strength found in familial ties."
    scene v18-358
    b_ "Although the constraints were sometimes stifling, I learned to adapt."
    b_ "I delved into creative pursuits within the walls of our home, finding fulfillment in expressing myself in various ways."
    scene v18-359 with fade
    b_ "Kamil loved me so much and cared about me."
    b_ "But he also felt so jealous so he restricted my freedom of going public."
    b_ "But I got used to it."
    b_ "Cooking together, reading side by side, and simply enjoying each other's company filled our days with contentment."
    scene v18-360
    b_ "Sitting in front of the mirror one day, I couldn't help but notice the subtle changes in my body."
    b_ "The reflection showed a woman who had, over time, become a bit fatter."
    b_ "While I contemplated these changes, Kamil's angry outbursts echoed through our home, a stark contrast to the serene moment I was trying to enjoy."
    scene v18-361
    b_ "In a way, I had grown accustomed to Kamil's new behavior, his bursts of anger becoming a part of our routine."
    b_ "It was a reality I had learned to live with, even as I confronted my own insecurities in front of the mirror. "
    scene v18-362
    b_ "These moments were a reminder of the challenges we faced as a couple, and the need for understanding and support in navigating the complexities of our relationship."
    b_ "As I observed my reflection, I vowed to find strength not just in my physical appearance but also in my resilience to face the challenges that life threw our way."
    b_ "It wasn't easy; his anger would fill the room, creating an atmosphere that was hard to breathe in."
    scene v18-363 with dissolve
    b_ "Yet, I learned to silence my own emotions, to ignore the harsh words, and to distance myself mentally from those moments."
    b_ "In those times, I would retreat to a mental space where his anger couldn't touch me."
    b_ "I would focus on my own inner strength, reminding myself of the love that had once bound us together."
    scene black with dissolve
    stop music
    b_ "Sitting at home for extended periods took a toll on me, making me feel increasingly isolated and restless."
    b_ "Kamil, in his own way, sensed my discontent. Occasionally, he would take me out shopping with him, providing a brief escape from the confines of our home."
    scene v18-364 with dissolve
    b_ "Those outings became a lifeline, a chance for me to breathe in the outside world, even if just for a little while."
    b_ "As we strolled through the bustling aisles of stores, I felt a fleeting sense of freedom. "
    b_ "The vibrant colors, the chatter of people around me, and the opportunity to choose something for myself offered a reprieve from the monotony of our daily routine. "
    scene v18-365
    b_ "It was during these shopping trips that I rediscovered a semblance of normalcy, reminding myself that there was a world beyond the walls of our home."
    b_ "Kamil's jealousy reached alarming heights, especially when he felt other men's eyes on me. "
    b_ "One day, as we were shopping, he noticed a seller leering at me, his gaze lingering longer than it should have."
    scene v18-366
    b_ "The intensity of Kamil's jealousy boiled over, and he confronted the man."
    b_ "Their heated exchange escalated, and in a fit of rage, Kamil threw a punch at the seller."
    b_ "The sudden violence stunned me, and I found myself torn between feeling a twisted sense of protection and concern for Kamil's escalating anger."
    scene v18-367
    b_ "It was a stark reminder of the possessiveness that had crept into our relationship, clouding the love we once shared."
    b_ "In the aftermath, I grappled with mixed emotions — a strange blend of gratitude for Kamil's protectiveness and discomfort at the violence that had erupted."
    b_ "It was a chilling reminder of the fine line between love and possessiveness, leaving me uncertain about the future of our relationship."







    scene black with Dissolve(3)
    ""
    centered "{size=+120} Kamil's decisions: Father and Son {/size}" with Fade(0.5, 0.5, 5)


    $ kamillistentohisdad = False
    $ kamilofferbanuhelpdadwaiting = False
    $ kamilaskdadputshirton = False
    $ kamilbuynecklace = False
    $ kamilbanucycling = False
    $ kamilbanuwalkinthepark = False
    $ banuteasecamalinkitchen = False


    scene black with dissolve
    "..."
    "Kamil started to impose restrictions on Banu's activities. No more work, no more gym."
    "She was confined to the four walls of their home, tasked with the duties of cleaning and cooking."
    "As days turned into weeks, Banu's once svelte figure began to soften, curves accentuating her frame."
    "Oddly enough, this change only added to her allure. Banu found herself feeling sexier than ever, despite the confines of her home. "
    "Yet, deep down, a longing stirred within her. She craved attention, adventure, the thrill of stepping beyond the threshold of her home."
    "She yearned for nights under the starry sky, for laughter and joy beyond the confines of her kitchen. But it all rested in Kamil's hands."
    "Would he recognize her needs, her desires? Would he embrace the adventure she longed for, or would he continue to confine her to the safety of their home?"
    play music "audio/slowsoft.mp3"
    scene v20-2 with blinds
    k "Banu, I need to talk to you before Dad arrives."
    b "What is it, Kamil?"
    k "Dad's coming over today. You know how he is—strict, traditional, a real tough nut. "
    k "I need you to be careful around him, okay? He's not used to our modern ways."
    scene v20-1
    b "Of course, Kamil. I'll be respectful."
    k "It's not just about respect, Banu. Dad has certain expectations. He's from a different time, a different world. He doesn't understand our lifestyle, especially yours."
    b "What do you mean, Kamil?"
    k "I mean, Dad's not going to like the way you dress or the way you behave. He's old-fashioned, still living like he's in the village. "
    k "You need to tone it down, cover up a bit more, speak softly."
    b "Alright, Kamil. I'll try my best."
    k "Thanks, Banu. I know it's not easy for you, but it's just for a few days."
    scene v20-3
    b "Before your dad gets here, could you remind me about what he's like? You know, what he enjoys and what he doesn't, so I can behave accordingly?"
    k "Dad's a man of the old ways. He likes things simple, no frills. He's big on respect and tradition, so just keep that in mind."
    k "He's not a fan of anything he considers too modern or flashy. And he's quite particular about manners, so being polite and respectful is key."
    b "Okay, I'll keep all of that in mind. "
    "As Banu and Kamil were in the midst of their conversation, the sudden ring of the doorbell startled them both."
    b "Oh my God, he's here..."
    k "Okay, I'm going to open the door and you go to the kitchen. Just be careful. Don't let me down."
    b "Okay..."
    scene v20-4
    b "Kamil, I'm sorry but what was your dad's name?"
    k "Damn, Banu, how could you forget that? His name is Camal."
    b "Alright, I got it."
    scene v20-5 with dissolve
    play music "audio/suspense.mp3"
    "As Camal entered the room, his sheer size seemed to fill the space, his presence commanding attention."
    "Kamil looked so small in front of him."
    "He was a towering figure, broad-shouldered and muscular, with hands that looked like they could crush rocks."
    scene v20-6
    "His face was weathered and stern, with a ruggedness that spoke of years spent under the sun."
    "His head was also way bigger than Kamil's head."
    "His body was covered in a thick layer of hair, a testament to his rugged nature and his life spent working the land."
    "His clothes were simple and practical, the attire of a man who valued function over fashion."
    scene v20-7
    k "Dad, it's good to see you. Come on in."
    cam "Good to see you too, son."
    k "How was your journey here?"
    scene v20-8 with fade
    cam "Long. Roads are getting busier every year. Too much noise and nonsense in the city."
    k "Yeah, things have changed a lot."
    cam "Changed for the worse, if you ask me. People have forgotten their roots, their values."
    k "We've adapted to the city life, Dad. It has its own challenges."
    cam "Challenges? More like excuses for forgetting who we are. Where's Banu?"
    k "Dad, Banu's just finishing up preparing some tea. Why don't you take a seat at the table? We can chat while we wait for her."
    cam "Fine. I suppose I'm not in a hurry. Another week in the city won't hurt."
    scene v20-9 with fade
    k "So, how's everything back in the village?"
    cam "Same as always. Hard work, little reward. But at least there, people still know how to respect tradition."
    k "Dad, remember the horses you used to have in the village? How are they doing?"
    cam "Horses are fine, Kamil. Strong and sturdy, just like they've always been. Can't say the same for the new tractor the neighbor bought. Always breaking down."
    k "You still prefer the old ways, huh?"
    scene v20-10
    cam "Old ways are reliable. Can't trust these new-fangled machines. Besides, horses understand respect and loyalty, unlike some people I know."
    k "Speaking of loyalty, Banu's been a great wife. She takes care of us and our home."
    cam "She's a good girl. But don't let her forget her roots. She needs to remember where she comes from, just like you do."
    cam "So do you beat her sometimes? You know it's useful to smack her ass sometimes to show her place and to show her that you're the man here."
    k "Dad, I don't think that's appropriate to discuss."
    cam "Nonsense, Kamil. A man must show his wife's place sometimes. A light smack on the behind keeps her in line."
    k "Dad, sometimes I do give her a smack."
    cam "That's my son. A man must assert his authority every now and then. Keeps the balance in the household."
    k "Dad, I respect your opinion, but Banu and I have our own way of handling things."
    cam "How dare you confront my words, Kamil! You forget who raised you! I could still knock some sense into you, just like I did when you were a child!"
    k "Dad, I'm sorry. I didn't mean to upset you. I'll consider what you said."
    cam "You better. Don't forget where you come from, boy."
    k "I won't, Dad. I won't."
    scene v20-11 with fade
    "As Banu entered the room with the tray of teas, she couldn't help but notice the tense atmosphere that seemed to hang in the air. "
    "Ignoring the unease, she approached the table where Kamil and his father sat, placing the tray down gently."
    scene v20-12
    b "Welcome to our house, uncle Camal."
    "Banu offered him tea with a polite smile, her eyes meeting his father's stern gaze."
    "Camal's frown deepened as he glanced up at Banu, his eyes lingering on her for a moment before he finally grunted in acknowledgment."
    scene v20-13
    "He didn't say a word, but his disapproving look spoke volumes."
    "Banu's heart sank slightly under the weight of his scrutiny, but she maintained her composure."
    "Kamil shot Banu a reassuring glance, silently urging her to ignore his father's reaction."
    "Banu nodded subtly, understanding that winning over Camal would take time, patience, and perhaps a bit more than just a warm cup of tea."
    scene v20-14 with fade
    play music "audio/tension.mp3"
    "Camal's sudden shout pierced the tense silence, causing Banu to freeze in fear, her eyes fixed on the floor as she awaited his next words."
    "The sharpness of his tone sent a shiver down her spine, her heart racing with apprehension."
    "Turning his head towards Kamil, Camal's voice boomed once more, his disapproval palpable in the air."
    cam "How could your wife, my daughter-in-law, wear such tight pants like that?"
    k "Dad, that's enough, Banu's choice of clothing is her own. She's a grown woman."
    cam "You dare to speak back to me, boy?"
    cam "I raised you better than that. You should be ashamed of yourself, allowing your wife to parade around like that."
    cam "Stand up right now. I'm talking to you, dickhead!"
    scene v20-15
    k "Dad, please, there's no need for this."
    cam "Silence! You've both disrespected me with your behavior. Now face the consequences or I'll teach you both a lesson you won't forget."
    cam "Why didn't you teach your wife to dress appropriately?"
    cam "What kind of man are you? Allowing your wife to parade around, showing herself like that for all to see."
    cam "I can practically see the shape of her pussy."
    k "Dad..."
    cam "Shut up!"
    scene v20-16
    b "I-I'm sorry, uncle Camal. I didn't mean to offend you."
    cam "Shut up! I'm talking to your man."
    cam "You didn't teach her manners either. She can't keep her mouth shut while I'm talking to you."
    cam "Now take her to your room and change her clothes and teach her some manners."
    cam "Slap her good that she never disrespects to her father-in-law."
    cam "If I see her in pants again, I'll fuck you up, Kamil. Do you understand me? "
    k "Yes, dad."
    cam "Take her now!"
    scene v20-17 with fade
    stop music
    "With a heavy heart, Kamil took Banu by the hand, leading her silently to their bedroom."
    "Banu's eyes were filled with fear and confusion as she glanced at Kamil, silently pleading for understanding."
    b "Kamil, what's happening?"


    menu:
        "Listen to your dad and show Banu her place":
            $ kamillistentohisdad = True
            $ renpy.block_rollback()
            play music "audio/suspense.mp3"
            "With a deep breath, he steeled himself, trying to summon the strength to carry out his father's orders."
            scene v20-18 with fade
            k "How could you disrespect my father like that? Do you have any idea what you've done?"
            "Banu flinched at the sudden change in Kamil's demeanor, her eyes wide with fear as she tried to comprehend his harsh words."
            b "Kamil, I didn't mean to... I'm sorry..."
            k "Sorry isn't good enough! You've embarrassed me in front of my own father. "
            k "You're supposed to be my wife, but you can't even show him the basic respect he deserves!"
            b "Please, Kamil, I didn't mean to upset anyone. I'll do better, I promise..."
            k "You'd better. This can't happen again. You need to learn your place in this family."
            b "You are always like this. You're just afraid of your father. You can't even stand up for your own family. You cower like a frightened dog while he insults your wife!"
            k "I'm not afraid of him, I... I'm just trying to keep the peace."
            b "At what cost, Kamil? You let him walk all over us, disrespect me, and you stand there and do nothing!"
            scene v20-19
            "The air hung heavy with tension as Banu's words pierced through Kamil's turmoil, igniting a surge of frustration within him."
            k "Banu, I said shut up!"
            b "You are just a cowar-"
            scene v20-20 with hpunch
            "Before she could finish her plea, Kamil's hand lashed out, delivering a forceful slap across her face."
            scene v20-21
            "The sound echoed through the room as Banu stumbled backward, collapsing onto the bed with a cry of pain."
            scene v20-22 with fade
            "Banu's hand shook as she gently covered her reddened cheek, her eyes filled with disbelief and pain as she lay on the bed, her gaze fixed on Kamil."
            b "Kamil... How could you...?"
            k "You needed to be taught a lesson, Banu. Just like my dad said. Maybe now you'll learn to respect him."
            b "Kamil..."
            "Her voice was barely a whisper, choked with tears and disbelief as she struggled to comprehend the depth of Kamil's action."
            scene v20-23
            k "You had it coming, Banu. Maybe now you'll think twice before disrespecting me and my family again."
            k "Now get the fuck up and change your clothes immediately."

            stop music
        "Apologize to Banu":


            $ kamillistentohisdad = False
            $ renpy.block_rollback()



            jump kamil_fuck_banu_dadoutside





label kamil_fuck_banu_dadoutside_continue:

    scene black with dissolve
    "..."
    centered "{size=+120} The next day {/size}" with Fade(0.5, 0.5, 5)
    scene v20-45 with blinds
    play music "audio/suspense.mp3"
    b "Good morning, uncle Camal."
    cam "Morning, Banu."
    b "Uncle Camal, would you like some tea?"
    cam "No, I don't need any tea."
    "Banu's hands trembled as she tried to maintain her composure, her heart pounding with anxiety at Camal's imposing presence."
    cam "You know, Banu, back in the village, I used to be the one who kept order. Kamil would get out of line sometimes, and I'd have to teach him a lesson."
    scene v20-47
    "Banu's eyes widened in alarm at Camal's words, her mind racing with apprehension."
    b "Oh, really?"
    cam "Yes. A good father ensures that his son knows his place. And a daughter-in-law should be respectful, too."
    "Banu's throat went dry as she struggled to find the right words, her nerves fraying at Camal's intimidating demeanor."
    b "Of course, Uncle Camal. I'll try my best to be respectful."
    "But deep down, Banu wished desperately for Camal to leave, her stomach churning with unease at the thought of being alone with him."
    scene v20-46
    cam "And let me make one thing clear, Banu. If my son ever does something to hurt you, or God forbid, cheats on you, he'll have me to answer to. I'll make sure to destroy his ass."
    "Banu's heart skipped a beat at Camal's threatening tone, her stomach churning with unease at the implications of his words."
    b "I-I hope it never comes to that, Uncle Camal."
    cam "But if it's you who steps out of line, Banu, I won't hesitate to take matters into my own hands. Remember that."
    "Banu's blood ran cold at Camal's ominous threat, her mind racing with fear and uncertainty as she struggled to process the weight of his words. "
    b_ "He's so... intimidating. Those hands... those arms... But there's something about him that... excites me."
    scene v20-47
    b_ "I should be afraid of him... And yet, I can't help but feel... turned on by him. It's like a forbidden thrill that I can't resist."
    b_ "I've never felt this way before. It's like he awakens something primal within me... something I can't control."
    b_ "I can't look into his eyes anymore."
    stop music
    scene black with dissolve
    "..."
    scene v20-48 with dissolve
    cam "Listen to me, son. You need to be stronger, more assertive."
    cam "A man should never let anyone walk all over him, especially not his own wife."
    k "I know, Dad. I'll try to do better."
    cam "I've noticed you've been letting Banu run the show around here. That's not how a man should behave."
    scene v20-49
    k "But Dad, I just want to keep her happy..."
    cam "Keeping her happy is one thing, but letting her walk all over you is another. You need to show her who's in charge."
    k "I don't want to be controlling, Dad. I just want us to be happy together."
    cam "You think you can talk back to me? You're still the same little boy who used to hide behind his mother's skirts. Don't forget where you came from."
    scene v20-50
    "Banu's heart sank as she watched Kamil's attempt to defend her get shut down by his father's harsh words."
    "She longed to speak up, to stand by her husband's side, but she knew that challenging Camal's authority would only make matters worse."
    k "I'm not a little kid anymore, Dad."
    cam "Remember when you used to come home crying because the other kids bullied you? You were always weak, Kamil. Always the one getting pushed around."
    cam "Now I want you to be strong like how I tought you."
    k "Dad, please, stop. This is embarrasing. "
    cam "Shut the fuck up and listen."
    cam "You owe everything to me, Kamil. Your strength, your resilience—everything."
    cam "I made you into the man you are today, Kamil. Don't you forget that."
    "Banu's heart broke as she listened to Camal's cruel taunts, her hands trembling with anger and frustration."
    k "I'm sorry, Dad."
    cam "I'm going to watch TV. Come with me."
    k "Yes, Dad."
    scene v20-51 with fade
    "As Kamil followed Camal out of the room, his eyes briefly met Banu's, a silent exchange passing between them—an unspoken understanding of the challenges they faced together."
    b "Are you okay?"
    k "I'll be fine. Just another day with Dad."
    b "I'm sorry, Kamil. He can be so... harsh."
    menu:
        "Follow your dad":
            $ kamilofferbanuhelpdadwaiting = False
            $ renpy.block_rollback()
            k "Yeah, well, it's nothing I'm not used to."
            k "Sorry, I have to go..."
            b_ "Why does he always have to follow him?"
            b_ "He never stands up to him. It's like he's still that scared little boy, desperate for his father's approval."
            "As she continued with her chores, Banu's thoughts lingered on Kamil's submissive demeanor, a pang of disappointment tugging at her heart."
            "She wanted him to be strong, to defy his father's expectations and carve out his own path, but it seemed that old habits died hard."
        "Stay offer Banu help":


            $ kamilofferbanuhelpdadwaiting = True
            $ renpy.block_rollback()
            k "Yeah, well, it's nothing I'm not used to."
            b "So what are you waiting for? He called you."
            k "You know...he can watch TV alone..."




            jump banu_suck_kamil_dadwatch





label banu_suck_kamil_dadwatch_continue:

    scene black with dissolve
    "..."
    centered "{size=+120} In the evening {/size}" with Fade(0.5, 0.5, 5)
    scene v20-68 with blinds
    "As Kamil walks into the living room, he spots his old man, Camal, chilling on the sofa, bare-chested, watching TV like he owns the place."
    "The man's got these massive muscles, a hairy chest that could rival a bear's, and hands the size of dinner plates."
    "Kamil's jaw practically hits the floor, but he manages to find a spot next to him, feeling a bit awkward."
    scene v20-69
    play music "audio/suspense.mp3"
    "But then, he starts thinking, what if Banu walks in and sees his father like this?"
    "She'd probably flip out!"
    "Kamil can't help feeling a twinge of jealousy, wondering what she'd think of his dad's macho vibe. Would she be impressed or totally weirded out?"
    k "Hey, Dad. Enjoying the show?"
    cam "Yeah, just catching up on some news. What's up, son?"
    k "Not much, just got back from work. Why're you shirtless, though?"
    cam "Oh, just felt a bit hot, you know how it is."
    k "Yeah, makes sense. Just caught me off guard, is all."
    cam "No worries. So, how's everything with you and Banu?"
    menu:
        "Ask him to put his shirt on":
            $ kamilaskdadputshirton = True
            $ renpy.block_rollback()
            k "Hey, Dad, um... would you mind putting your shirt on?"
            scene v20-70
            cam "Why's that?"
            k "Well, uh... I just don't want Banu to walk in and... you know, see you like this."
            cam "Ah, I see. Didn't want to make her uncomfortable, huh?"
            k "Yeah, something like that."
            scene v20-69
            cam "Alright, no problem. I'll put it on."
            k "Thanks, Dad. I appreciate it."
            cam "No problem, son. Happy wife, happy life, right?"
            k "Yeah, something like that."
            scene black with dissolve
            "...."
            "After some time...."
            scene v20-71 with fade
            "Banu walks into the room, and Camal jumps up like he's on springs, saying it's too hot and he needs some air."
            "They pass each other, but Camal shoots Banu a glare that could freeze lava. "
            "Banu's not sure what's up, but she's definitely feeling the tension."
            "As they pass each other, Camal's eyes bore into Banu's with a look that sends a shiver down her spine."
            scene v20-72 with fade
            "Once Camal's out of sight, Banu breathes a sigh of relief, but she's still on edge, wondering what she did to get that death stare."
            b "So, when is your dad going to get the hell out of here and go back to his village?"
            k "I'm not sure, Banu. "
            b "I just hope he doesn't stick around too long. I can't handle much more of his 'advice'."
            k "Don't worry, Banu. I'll make sure to drop plenty of hints about how much we miss the peace and quiet."
            b "Good idea. Maybe we'll get lucky and he'll take the hint."
            stop music
        "Let him stay shirtless":

            $ kamilaskdadputshirton = False
            $ renpy.block_rollback()
            stop music
            k "It's alright, I guess. We have our moments."
            cam "Just remember, son, it's important to keep the fire alive. "
            scene v20-70
            cam "So, Kamil, you been taking care of Banu, making sure she's satisfied in bed?"
            k "Uh, Dad, that's kind of personal..."
            cam "Just asking, son. It's important to keep your wife happy, you know?"
            k "Yeah, of course. Everything's fine in that department."
            cam "Good to hear."
            scene v20-73 with fade
            play music "audio/weakbanu.mp3"
            "Banu entered the room, her eyes widening in surprise at the sight of her shirtless father-in-law."
            b "Oh, um... hi, Dad. I didn't realize you were, uh, here."
            cam "Hey there, Banu. Just catching up with your husband here."
            "Banu's eyes practically pop out of her head as she checks out Camal's shirtless body."
            scene v20-74
            "His hairy chest, those bulging muscles—damn, it's like something out of a movie."
            "But it ain't just his physique that's got her going; it's his whole vibe, like he's oozing confidence and power."
            "She tries to play it cool, but inside, she's practically melting. "
            "Her heart's racing, and she can feel herself getting all hot and bothered."
            "It's like her body's gone into overdrive, and she can't help but feel a rush of wetness between her thighs."
            scene v20-75
            "She tries to keep her cool, but it's a losing battle. Camal's got her feeling some type of way, and she can't deny the way her body's responding to him."
            "As Camal starts rambling about the news on TV, Banu's eyes are glued to his bod like she's watching the latest blockbuster."
            "She's practically drooling over his muscles, and Kamil can't help but notice."
            cam "Can you believe this nonsense they're spewing? It's like they don't know the first thing about real news."
            k "Yeah, it's pretty wild. So, uh, Dad, how's the farm been lately?"
            cam "Same old, same old. Just trying to keep those damn animals in line."
            "Banu trying to join the conversation, but her eyes keep wandering back to Camal's chest."
            k "Everything okay, babe?"
            b "Huh? Oh, yeah, I'm fine. Just, uh, zoning out."
            scene v20-76
            cam "You know, back in my day, men were real men. None of this weak-kneed nonsense you see nowadays."
            k "Uh, Dad, I don't think all of them are weak."
            cam "Let me tell you a story. When I was your age, I was out there in the fields, wrestling with the livestock. "
            cam "I was so strong, I could take down a bull with one hand tied behind my back."
            b "Wow, sounds... intense."
            scene v20-77
            cam "Ah, back in my younger days, we didn't have all these fancy distractions. "
            cam "We had to make our own fun. Like the time I snuck into the stable and... well, let's just say I fucked one of the horses."
            k "Dad, you... you didn't actually..."
            cam "Oh, I did! And let me tell you, that horse was quite the ride."
            b "You fucked a horse? That's... that's disgusting!"
            k "Banu, please, let's change the topic."
            cam "Different times, different customs. You young folks wouldn't understand."
            k "Yeah, uh, let's, uh, talk about something else."
            scene v20-78
            cam "Banu, come over here and give these old shoulders a massage, will you?"
            b "Uh, I don't know, Dad. I'm not really... uh, good at massages."
            cam "Nonsense, girl. A little rubdown never hurt anyone. Now come on, get over here."
            b "Maybe you should try stretching or something..."
            cam "I need a good massage, and you've got just the touch for it."
            "Kamil was shooting Banu a concerned glance, silently urging her to refuse."
            b "I-I guess I could try..."
            cam "Good girl."
            scene v20-79 with fade
            "As Banu tentatively approaches, she can feel her heart pounding in her chest."
            "The last thing she wants is to get any closer to Camal's naked body, but she knows she can't refuse his request."
            "She can't help but feel a rush of excitement at the sheer size and strength of his body."
            "Her thoughts drift to his rugged features, his broad shoulders, and those powerful arms."
            "Damn, she's never been this close to such raw masculinity before, and it's driving her wild."
            scene v20-80
            "Banu tentatively placed her hands on Camal's broad back, her fingers sinking into the muscular flesh."
            b "Wow, your back is... uh, really big."
            cam "Years of hard work on the farm, girl."
            "Banu felt a wave of heat wash over her as she continues to knead his muscles, her body reacting to the proximity to his imposing figure."
            b "Yeah, I can tell..."
            scene v20-81
            "As Banu massages Camal's back, her mind begins to wander, lost in the sensations of his muscular form beneath her touch."
            "She can feel the warmth of his skin against her fingertips, the strength of his muscles flexing beneath her hands."
            "Despite her best efforts to remain focused, her thoughts are consumed by the primal desire stirring within her."
            cam "Your hands are so fragile and tiny, Banu. Almost like delicate little flowers."
            scene v20-82
            b "Uh, thanks, I guess. I've always had small hands."
            cam "Small hands, big heart, they say. But you gotta be careful, girl. You might break something with those dainty little fingers of yours, hehe"
            b "Oh, I'll be extra careful, don't you worry."
            b "You know, uncle Camal, I've always admired your, uh, strength. I mean, look at you, you're like a mountain of muscle."
            scene v20-83
            cam "Years of hard work on the farm will do that to a man."
            b "Yeah, well, it definitely shows."
            cam "You seem awfully interested in a man's physique, Banu."
            b "Oh, uh, no, not really. Just, uh, admiring the view, you know?"
            cam "Is that so? You're not the first woman to get flustered around me, you know."
            b "I-I can imagine."
            scene v20-84
            cam "Tell me, Banu, what is it about a man like me that gets your heart racing?"
            b "I... I don't know. Your, uh, strength, I guess. Your confidence. It's... intimidating."
            cam "Intimidating, huh? Well, I suppose that's one way to put it. "
            cam "But you know what they say, Banu. Sometimes, it's the things that intimidate us the most that we desire the most."
            scene v20-85
            b "Yeah, well, I've never been one to back down from a challenge."
            "As Banu runs her hands over Camal's chest, she can feel the heat radiating from his body, igniting a fire within her that she can't seem to extinguish."
            b "You know, uncle Camal, I can't help but wonder how a man like you releases all that energy out in the village."
            cam "Oh, I've got plenty of ways to burn off steam, Banu. You'd be surprised."
            b "I bet you do. I can only imagine the kind of... activities you get up to."
            k "Uh, Dad, I think that's enough. Banu's probably tired from her, uh, massage. Maybe we should give her a break."
            cam "Oh, Kamil. Always looking out for your wife, aren't you? How noble."
            cam "I like that. That's my son."
            k "I'm serious, Dad. I think Banu's had enough."
            cam "And I think you've had enough of telling me what to do, boy. This is between me and Banu."
            "Kamil's attempt to intervene only seems to fuel Camal's determination to assert his dominance, leaving Banu feeling even more conflicted than before."
            scene v20-86 with fade
            "She knows she should put an end to this before things go any further, but there's a part of her that can't help but be drawn to the raw power and confidence that Camal exudes. "
            cam "You're a fascinating woman, Banu. I can see why my son is so taken with you."
            cam "Just remember, Banu, a woman like you deserves to be appreciated. And if my son ever fails to give you what you need... well, let me know so I beat his ass good."
            "Banu was feeling Camal's large hand resting on her shoulder, she can't help but feel a surge of arousal coursing through her body, her skin tingling beneath his touch."
            scene v20-87
            "His grip, firm and dominating, sends a thrill down her spine, awakening a primal hunger she can't ignore. "
            "It's like every nerve in her body is screaming for more, craving the touch of this rugged, commanding man."
            "She knows it's wrong, but in that moment, all she can think about is giving in to the overwhelming temptation of this forbidden desire."
            b_ "Oh my... What is this feeling?"
            b_ "His touch is so... commanding, so powerful. I shouldn't be feeling this way, but damn, it's like I can't help myself."
            b_ "I just wish he leaves this house as soon as possible..."
            stop music


    scene black with dissolve
    "..."
    centered "{size=+120} The next day {/size}" with Fade(0.5, 0.5, 5)
    scene v20-88 with dissolve
    "As Kamil strolls through the busy streets, he notices the gleaming jewelry stores and decides to step into one."
    "Kamil admires the array of rings, necklaces, and bracelets on display."
    "Among them, one catches his eye—a delicate, shimmering piece that seems to glow with an ethereal light."
    scene v20-89 with fade
    "Pausing to admire it, Kamil's thoughts turn to Banu. "
    "He considers the idea of buying it for her, imagining how it would look around her neck, accentuating her beauty."
    k_ "I know I should be careful with money, that's always been my way."
    k_ "But Banu... She brings so much light into my life, so much joy. And when I see something that I know would make her happy, it's like all my careful calculations go out the window."
    k_ "Part of me wants to be practical, to stick to the budget, to save for a rainy day. But another part—the part that loves Banu more than anything—can't resist the idea of seeing her smile."
    menu:
        "Buy the necklace":
            $ kamilbuynecklace = True
            $ renpy.block_rollback()
            k_ "Money comes and goes, but moments like these are priceless."
            k_ "I may be a mean person when it comes to money, but when it comes to Banu, she's worth every penny."
            "With a newfound sense of purpose, Kamil makes the purchase, confident that the happiness it will bring to Banu far outweighs any concerns about his finances. "


            jump kamil_fuck_banu_necklace
        "Save your money":





            $ kamilbuynecklace = False
            $ renpy.block_rollback()
            k_ "Money doesn't grow on trees."
            k_ "Sure, it would be nice to see the look on Banu's face when she receives a gift, but I know she understands the importance of financial stability just as much as I do."
            k_ "We'll find other ways to celebrate and show our love—ones that won't break the bank."


            scene black with dissolve
            "..."
            scene v20-90 with dissolve
            "In the heat of the argument, tensions flare between Kamil and Banu. "
            "Banu demands that Kamil's father leave the house immediately, accusing him of inappropriate behavior after catching him checking her out. "
            "But Kamil, torn between his loyalty to his wife and his sense of duty to his father, hesitates to take action."
            b "I can't believe you're defending him! After what I saw, you're still siding with him?"
            k "I'm not defending anyone, Banu. But he's my father, and I can't just kick him out because of some misunderstanding."
            b "Misunderstanding? He was practically ogling me, Kamil! I felt so uncomfortable!"
            k "I understand that, but he's from a different generation. He probably didn't mean anything by it."
            scene v20-91
            b "That doesn't excuse his behavior! I won't tolerate being objectified in my own home."
            k "I get it, Banu. But please try to understand my position. He's my dad, and I can't just kick him out onto the streets."
            b "Well, I won't stand for it. If you won't do something about it, then I will."
            k "Banu, please. Let's not make any rash decisions."
            b "Rash decisions? I've had enough, Kamil. I won't stay in a house where I don't feel safe."
            k "Fine, Banu. If that's what you want, then I'll talk to him. But please, let's try to resolve this without making things worse."
            k "Banu, I'm tired. Can we talk about this tomorrow?"
            scene v20-92
            b "No, Kamil, we can't just sweep this under the rug. Your dad needs to understand that his behavior is not okay."
            k "I know, and I'll talk to him in the morning. But right now, I just need some rest."
            b "But Kamil—"
            scene v20-93
            b "What the fuck?"
            "Banu's voice trails off as she turns to face Kamil, expecting to continue their argument, only to find him already fast asleep on the bed."
            "She's taken aback, surprised by how quickly he fell asleep amidst their heated discussion. "
            scene v20-94
            b "You stubborn donkey, piece of shit..."
            "She shoots Kamil a glare, half expecting him to respond, but he's already deep in slumber, his snores filling the room. "
            "Frustration wells up inside her as she watches him sleep peacefully, seemingly unaffected by their argument. "
            "With a mix of annoyance and resignation, Banu shakes her head and turns away, knowing that there's no point in continuing the conversation with Kamil in his current state. "







label kamil_fuck_banu_necklace_continue:

    scene black with dissolve
    "..."
    centered "{size=+120} The next morning {/size}" with Fade(0.5, 0.5, 5)
    scene v20-118 with dissolve
    "Kamil, dressed in his work attire, glanced at Banu with a mixture of concern and helplessness."
    "He could sense her frustration, her desire for some semblance of normalcy in their home."
    "But with his father's imposing figure always present, finding peace seemed like an impossible task."
    b "Kamil, your dad is just... I can't deal with him anymore. He's always hovering around, making me uncomfortable."
    k "I know, Banu. I'm sorry about that. But what can we do? He's my dad, and he's staying with us for a while."
    b "I understand, but it's not fair to me. I feel like I'm suffocating in my own home. Can't we do something about it?"
    k "I'll talk to him again, okay? Maybe he'll understand and give us some space."
    b "I hope so. I just need a break from all this tension. It's affecting us, Kamil."
    b "Kamil, please, just one day! We could go cycling, or explore the city. Anything to break this monotony."
    scene v20-119
    k "I wish I could, Banu, but you know how it is. My job—"
    b "Your job can't be more important than us, than our happiness!"
    k "It's not about that, Banu. I have responsibilities, bills to pay—"
    b "I don't care about bills! I care about us, about living! I don't want to stay all day alone with your dad."
    k "I know, Banu, I know. But I can't just drop everything. I'll try to come back early, okay?"
    b "That's not good enough, Kamil. I need more than empty promises."
    menu:
        "Take Banu out and have fun":
            $ kamilbanucycling = True
            $ renpy.block_rollback()
            k "Okay....alright...But where can we go? I mean, I have work, and..."
            b "Come on, Kamil. Let's do something spontaneous. How about cycling? We've never done that."
            k "Cycling? Uh, yeah, I guess we could do that."
            b "Great! Let's pack some snacks and head out. It'll be fun, I promise."
            k "Alright, let me just grab a few things, and we'll go."
            "..."


            jump banu_kamil_outside_sex
        "I can't skip work. It's more important":







            $ kamilbanucycling = False
            $ renpy.block_rollback()
            k "I can't, Banu. I have too much work to do. My job is important and I can't just drop everything."
            b "But Kamil...One day off won't hurt."
            k "The work doesn't stop, and I can't just ignore it. Another time."
            b "So, your job is more important than our marriage?"
            k "Banu, please don't say that. I'll make it up to you. I promise."
            b "You always say that! I'm sick of it."
            k "Don't start with this again, Banu."
            b "You're the selfish one, Kamil! You don't care about anything but your stupid job!"
            k "And you're a spoiled brat who can't see beyond her own nose."
            b "Fuck you, Kamil! I'm done trying to make this work when you clearly don't care!"
            b "Fine! Go run to your precious job. See if I care when you come back!"




            jump banu_wash_dad_back






label banu_kamil_outside_sex_continue:

label banu_wash_dad_back_continue:




    scene black with dissolve
    play music "audio/romantic.mp3"
    "..."
    centered "{size=+120} Sunday morning {/size}" with Fade(0.5, 0.5, 5)
    scene v20-163 with blinds
    "Kamil and Banu wake up in their bedroom, the sunlight streaming through the curtains. Banu turns to Kamil with a hopeful smile."
    b "Good morning, Kamil. It's such a beautiful day outside. How about we go for a walk in the city today? We haven't spent much time together lately."
    k "Morning, Banu. I wish I could, but I already made plans to meet some friends today. We're going to spend the whole day together."
    scene v20-164
    "Banu frowns slightly, thinking of a way to persuade him."
    b "Come on, Kamil. We can see your friends anytime."
    b "Imagine strolling through the city, exploring new places, having lunch together... It could be so nice."
    k "I know, but I've been looking forward to seeing them. We made these plans a while ago."
    b "What if I promise to make it worth your while? A whole day with me, no distractions. We could even stop by that new cafe you wanted to try."
    k "Nice try, but I really need to meet up with them."
    scene v20-165
    b "Alright, how about this – I promise to watch that action movie marathon with you next weekend. No complaints, no distractions."
    k "That’s a good deal, but I still can't cancel on my friends today."
    b "What if I say I’ll cook your favorite dinner tonight? You know, the one with the special dessert?"
    k "You’re making it really hard to say no, but—"
    b "And what if I promise to give you a back rub after dinner? You always say I give the best massages."
    menu:
        "Agree to take her out":
            $ kamilbanuwalkinthepark = True
            $ renpy.block_rollback()
            k "Okay, okay, you win. But only because you're so persistent and I can’t resist your back rubs."
            b "Yay! Thank you, Kamil! You won't regret it, I promise. Let's get ready and have a wonderful day together."
            scene v20-166 with vpunch
            "As Kamil stands up from the bed, Banu jumps onto his lap."
            "Kamil hugs her and holds her in the air, feeling the warmth of her skin against his."
            scene v20-167
            b "See, you can't resist me when I do this, can you?"
            k "You know exactly how to get your way, don't you?"
            b "Maybe I do. But can you blame me? I just want to spend some time with my amazing husband."
            k "Well, you’re definitely making it hard to say no."
            b "I know you love it when you hold me like this. It makes you feel strong, doesn't it?"
            "Kamil's grip tightens slightly, a playful gleam in his eyes."
            b "Good, because I plan on keeping you all to myself today."
            k "I guess my friends will have to wait. You win."
            b "That's what I thought. Now, let’s make this day unforgettable."

            scene black with dissolve
            "..."
            scene v20-170 with dissolve
            "As Banu and Kamil stroll through the park, their hands intertwined, the sun shines brightly, casting a warm glow over the scene."
            "They walk leisurely, enjoying each other's company, the sounds of laughter and nature filling the air."
            k "Look over there, Banu. Do you see that big oak tree? I used to climb that when I was a kid."
            b "Really? I can just imagine little Kamil scrambling up that tree."
            k "Yeah, I used to think I was a jungle explorer or something. It feels like ages ago."
            b "That’s adorable. You should show me your climbing skills sometime."
            scene v20-171
            k "I think those days are behind me, but I can definitely show you where I carved my initials. It’s still there."
            k "And there is a place there by the pond, that's where I learned to fish with my dad. We’d spend hours just waiting for a bite."
            b_ "Oh my God...again his dad....damn him..."
            b "You’ve never taken me fishing. We should do that one day. It sounds peaceful."
            k "It really is. I’d love to take you. Maybe we can make a day of it this summer."
            b "I’d like that. It’s nice hearing about your childhood. I feel like I’m getting to know another side of you."
            k "Well, you’re a big part of my life now, Banu. I want to share everything with you."
            scene black with dissolve
            "As Kamil and Banu strap themselves into the roller coaster, the excitement and anticipation build. "
            "They hold onto the safety bar, grinning nervously at each other."
            scene v20-172 with pixellate
            b "Oh my gosh, Kamil, why did I let you talk me into this?"
            k "Because you love adventures, remember? Plus, it’s going to be fun!"
            b "Define 'fun.' I’m starting to think your definition involves terrifying your wife!"
            k "Look how high we are, Banu! This is nothing compared to that tree I used to climb."
            b "If your tree was this tall, I'm glad you survived your childhood! Oh, here we go!"
            scene v20-173 with fade
            k "Woo! This is amazing!"
            b "Kamil! I can’t believe we’re doing this!"
            "As the coaster twists and turns, they experience a thrilling mix of fear and exhilaration. During a brief pause at the top of another hill, Banu catches her breath."
            scene v20-174
            b "Okay, I admit it, this is thrilling! But remind me to reevaluate your adventure ideas in the future!"
            k "Deal! But you have to admit, this beats a quiet walk in the park, right?"
            b "Absolutely, this is one for the books. Just hold my hand, okay? I need something to squeeze besides the life out of this safety bar!"
            k "Got it, hold on tight!"
            "They continue to laugh and scream as the roller coaster dips and dives, creating memories that will last a lifetime. "
            stop music
        "Get angry and scold her":


            $ kamilbanuwalkinthepark = False
            $ renpy.block_rollback()
            scene v20-168 with fade
            stop music
            k "Banu, I told you, I already have plans! Why can't you understand that?"
            b "I'm just asking for one day."
            k "I have responsibilities too, Banu! It's not always about what you want. I need time with my friends."
            scene v20-169
            b "And I need time with my husband! Don't you see how important this is to me?"
            k "Stop being so demanding! You're acting like a child. I have other commitments, and you need to respect that."
            b "I'm not being demanding, Kamil. I'm just trying to save our relationship. Why can't you see that?"
            k "Because you're not listening! I need my space too. You can't control everything."
            k "You need to understand that I can't always drop everything for you. We both need balance."
            b "I feel like I'm losing you..."
            k "Banu, we'll find a way to make it work. But you need to give me space when I need it. I promise we'll spend time together soon."
            "They stand in silence for a moment, the tension still lingering but a small understanding beginning to form."




            jump banu_masturbate_dad











label banu_masturbate_dad_continue:


    scene black with Dissolve(3)
    ""
    centered "{size=+120} The next evening {/size}" with Fade(0.5, 0.5, 5)

    $ banufrustration = 0



    if kamillistentohisdad == True:
        $ banufrustration += 1

    if kamillistentohisdad == False:
        $ banufrustration -= 1

    if kamilofferbanuhelpdadwaiting == False:
        $ banufrustration += 1

    if kamilofferbanuhelpdadwaiting == True:
        $ banufrustration -= 1

    if kamilaskdadputshirton == False:
        $ banufrustration += 1

    if kamilaskdadputshirton == True:
        $ banufrustration -= 1

    if kamilbuynecklace == False:
        $ banufrustration += 1

    if kamilbuynecklace == True:
        $ banufrustration -= 1

    if kamilbanucycling == False:
        $ banufrustration += 1

    if kamilbanucycling == True:
        $ banufrustration -= 1

    if kamilbanuwalkinthepark == False:
        $ banufrustration += 1

    if kamilbanuwalkinthepark == True:
        $ banufrustration -= 1







    play music "audio/sexy.mp3"    
    scene black with dissolve
    "Banu stands in front of the mirror in the bedroom, her reflection almost mesmerizing in the dim light."
    scene v20-194 with dissolve
    "She’s dressed in a black lingerie set with stockings and a transparent black top that shows off her curves."
    "She adjusts her hair and smooths her outfit, feeling a mix of anticipation and determination."
    b_ "Tonight has to be special. I want to remind Kamil of what we have, what we could lose if we don’t try harder."
    b_ "I need to feel his passion, to reconnect with him in a way we haven't in a long time."
    scene v20-195 with fade
    "She looks at her reflection, admiring the way the lingerie accentuates her figure."
    b_ "This should get his attention. I’ve put so much effort into tonight. I want him to see me, to desire me as much as I desire him."
    b_ "He’s been so distant lately, but tonight will be different."
    b_ "I’ll make sure of it. I want to drive him wild, make him remember why he fell in love with me in the first place."
    scene v20-196 with fade
    b_ "I can’t wait to see his face when he walks through that door."
    b_ "He won’t be able to resist me. I want to feel his hands on my body, his lips against my skin."
    b_ "I want to lose ourselves in each other tonight."
    b_ "This is my chance to bring us closer, to reignite the fire that’s been missing. I need this, we both need this. Tonight will be unforgettable."
    "She pictures Camal, with his intense eyes and commanding presence. The image of him seeing her like this sends a shiver down her spine."
    b_ "What would Camal do if he saw me like this? Would he be able to resist? Would he want me as much as I want to be wanted?"
    b_ "Should I? Should I go to the kitchen and see his reaction? Just a little tease, nothing more."
    b_ "I wonder if he would look at me the way he did before, with that intensity. Would he be able to keep his composure?"

    menu:
        "Fuck Camal! I don't want to see his ugly face again" if banufrustration <= 0:
            $ banuteasecamalinkitchen = False
            $ renpy.block_rollback()

            b_ "No, I don't need to be thinking about him. Fuck Camal. I don't want to see his ugly face again. Tonight is about Kamil and me, nothing else."

            b_ "I need to make tonight special for us. It's about rekindling what we have, making sure he knows how much I love and desire him."
            b_ "This is our night, and I’m going to make sure it's perfect. No more distractions."
            "She focuses her thoughts back on Kamil and their night together. She smooths her outfit, her determination solidifying."
            stop music


        "I want him to see me like this so bad" if banufrustration >= 1:
            $ banuteasecamalinkitchen = True
            $ renpy.block_rollback()

            b_ "I shouldn't be thinking this. But I want him to see me like this so badly. Just to see that look in his eyes again."
            "She bites her lip, trying to steady her breath, but her desire only intensifies."
            b_ "It wouldn't hurt, would it? I need to feel that thrill."
            b_ "Just a quick tease. I can't help myself."
            scene v20-197 with dissolve
            b_ "There he is, just as intense as ever. I can't believe I'm doing this. But I need to see his reaction."
            "She approaches him slowly, her eyes locked on his, trying to gauge his response."
            "His gaze travels over her body, lingering on her curves, and she can see a flicker of something in his eyes—surprise, interest, maybe even desire."
            scene v20-198 with fade
            b_ "He's looking at me... really looking at me. I can feel his eyes on every inch of my skin. God, this is so wrong but it feels so right."
            "As Banu stands in the kitchen, she can feel Camal's eyes burning into her."
            "The intensity of his gaze sends a thrill through her, but she notices his expression darken with anger."
            cam "Banu, what is this? What do you think you're doing?"
            scene v20-199
            "Banu meets his eyes for a moment, then deliberately looks away, pretending to be interested in something on the counter."
            b_ "Let him get angry. I want to see how far I can push him."
            b_ "He thinks he can control everything, but I'll show him."
            "Ignoring his question, she continues to move around the kitchen, her body language deliberately casual and unconcerned."
            scene v20-200
            cam "Banu, answer me. Why are you dressed like this?"
            cam "What the hell do you think you're doing?! This is completely unacceptable!"
            scene v20-201
            "Banu's heart races at the intensity of his anger, but she maintains her calm exterior, refusing to let him see how his outburst affects her."
            "She turns her head slowly to face him, her expression deliberately indifferent."
            b "Why are you shouting, Uncle Camal? There's no need to raise your voice."
            scene v20-202
            cam "You know exactly why I'm shouting! This behavior is disgraceful! You're trying to provoke me, and it's not going to work."
            "Banu stands her ground, her eyes locked on his, a defiant spark in her gaze."
            b "I'm not trying to provoke you. I'm just living my life. If you can't handle that, maybe you should leave."
            cam "You're playing with fire, Banu. This isn't a game."
            b "I know it's not a game. But I'm not going to let you control me or tell me how to live my life."
            "Banu, feeling a surge of defiance and perhaps a bit reckless, decides to push Camal even further."
            scene v20-203
            b "Oh, Uncle Camal, you're so predictable. Always getting worked up over the smallest things. It's almost... cute."
            cam "Banu, you're crossing a line. This isn't a joke."
            b "Oh, come on, daddy. Lighten up a bit. You're always so serious. Maybe you need to relax and have a little fun for once."
            cam "Fun? You think this is fun? This is your idea of fun, disrespecting your family?"
            cam "Go and cover yourself right now!"
            b "You're always trying to control everything and everyone. It's kind of pathetic, really."
            b "Oh, I see. You want me to respect you just because you shout louder and try to intimidate me? Sorry, but that's not how it works."
            cam "You need to learn your place."
            b "My place? I think it's you who needs to learn that you can't control everyone around you. Maybe it's time you looked in the mirror and realized that."
            scene v20-204
            "Camal's anger reaches a boiling point, his face contorting with rage. He steps even closer, his voice a furious roar."
            cam "That's it, Banu! I've had enough of your disrespect. I'm going to beat the shit out of you for this!"
            b "Go ahead, Camal. Show me just how much of a man you really are."
            cam "You need to learn some respect, Banu. You need to understand that there are limits."
            scene v20-205
            play music "audio/weakbanu.mp3"
            "Banu's own anger suddenly flares, matching Camal's intensity."
            b "You know what, Camal? Fuck you! "
            b "This is mine and Kamil's house! You have no right to come in here and act like you own the place!"
            b "I can do whatever I want and wear whatever I want here."
            b "You're nothing but an old bastard trying to control everything and everyone!"
            b "Well, guess what? I'm not going to let you! If you don't like it, you can get the hell out of here!"
            scene v20-206
            b "And if you ever threaten me again, I'll do more than just talk back."
            b "I'll piss in your mouth to show you exactly how much respect I have for you!"
            b "I know what you're really after, Camal. You think I don't see the way you look at me? You want to fuck me, don't you?"
            b "Well, fuck you! I'm not some plaything for you to use!"
            b "I'll never let you have any power over me. So take your perverted fantasies and get the hell out of my life!"
            "Camal stands there, his eyes blazing with anger but still saying nothing."
            b "What's the matter, Camal? Cat got your tongue?"
            b "Or maybe you're just realizing that you have no power here. You're nothing but a pathetic old man who can't stand being told no."
            scene v20-207 with hpunch
            "She lowers her top slightly, just enough to taunt him, her voice dripping with sarcasm and challenge."
            "She knows she's playing with fire, but she can't help it."
            b "Is this what you want, Camal? You want to see these?"
            b "You think you can intimidate me? Think again. You're nothing to me. Just a pathetic old man who thinks he can get whatever he wants."
            b "Leave us alone, Camal. Go back to wherever you came from and stay out of our lives. You're not welcome here."
            scene v20-208
            "Camal's face flushes with rage, his eyes narrowing as he struggles to control his temper. "
            "His fists clench and unclench at his sides, but he says nothing, the tension in the room palpable."
            scene v20-209
            stop music
            "Banu turns and walks away, her heart still pounding from the confrontation."
            "As she leaves the kitchen, she can feel Camal's intense gaze burning into her back."
            cam_ "How dare she challenge me in my own son's house? She'll regret this."
            "He takes a few deep breaths, trying to regain his composure, but the anger still simmers just below the surface."
            "The confrontation has shaken him, and he knows that things cannot go back to the way they were."
































label camalending:






    scene black with dissolve
    "...."
    "The city is never truly quiet, but inside the apartment, the silence feels heavy... suffocating."
    "Banu lies on the edge of the bed, the silk of her night robe sliding against her bare skin. She hadn't bothered with a bra; the friction of the fabric against her nipples makes her pulse quicken."

    scene end-295 with dissolve
    b_ "Kamil is already passed out in the guest room... probably exhausted from trying to impress that beast of a father."
    b_ "Camal... God, he's terrifying. He's not like the men in the city. He’s... ancient. Grotesque."
    b_ "He looks at me and he doesn't see Kamil's 'pious' wife. He sees right through this robe. Right through the hijab I wear in the morning."
    scene end-296
    b_ "He’s clever. Too clever. He has that village instinct... he can smell the sweat on me. He can smell that I’m starving for something Kamil is too soft to give me."
    b_ "He’s a monster. A nasty, hairy, old goat of a man. He probably thinks I'm a whore just for the way I breathe when he’s in the room."
    b_ "The way he looked at my ankles... like he wanted to snap them. If Kamil knew what his father was thinking... if he knew what I was thinking..."
    scene end-297 with fade
    "A floorboard creaks in the hallway. Banu freezes, her breath hitching in her throat."
    b_ "Is that... him?"
    b_ "God help me... if he walks in here"

    scene end-298
    play music "audio/heatedsex.mp3"
    "The door swings wide, and the frame is instantly filled by a mountain of dark, hairy muscle. Camal doesn't sneak. He doesn't hesitate. He simply *is*."
    b "A-ah! Camal? No... stay back!"
    b_ "God... he’s huge. He looks like a demon... a hairy, village demon. Why is he looking at me like that? Why can't I move?"
    scene end-299
    cam "You city women... you think a thin piece of wood and a prayer can hide the stink of a bitch in heat?"
    "His voice is a low, gravelly rumble that vibrates in Banu's very bones."
    b "Camal... please... Kamil is right there... he'll wake up! You have to leave!"
    cam "Kamil is a boy. I raised a son, but the city turned him into a lapdog. He sleeps while his wife rots from the inside out with a hunger he’s too weak to satisfy."

    scene end-300
    cam "I’ve seen how you look at the village men when we pass. I’ve smelled the sweat on your neck when I walk by. You’re no saint, Banu. You’re a horny little whore playing dress-up in a hijab."
    b "N-no... I’m a good wife! I... ahh!"
    cam "A good wife doesn't leak through her panties when her father-in-law is in the house. Look at you... shaking like a leaf. Is it fear, or is that pussy of yours finally getting what it’s been begging for?"
    b_ "His hand is so rough... so hot. It feels like iron. I should scream... I should fight... but I can't breathe."
    b "Please... Camal... don't... *moan*..."
    cam "Shut up. I’m not here for your lies. I’m here to see if there’s any truth left in this family, or if I have to break you open myself to find it."

    b "That's it. You disgusting, filthy village pig! How dare you walk in here like this?! You’re a monster! A nasty, hairy animal!"
    scene end-301 with fade
    b "Get out! Get out before I scream for Kamil! He’ll kill you! You think you can just stand there with that... that *revolting* thing hanging out? You’re pathetic!"
    "Camal doesn't flinch. He doesn't even blink. He just watches her, a dark, knowing smirk tugging at the corners of his mouth beneath his thick black beard."
    scene end-302
    "He moves. It’s not a fast movement, but it’s unstoppable. He closes the distance in two heavy strides, his massive upper body casting a shadow so thick it feels like it's drowning her."
    b "I-I said... back off... you... you freak... *gasp*..."
    b_ "He’s so big... his hands... they could crush my skull like an egg. God, the smell of him... it’s making my head spin. Why am I shaking like this? Why is my heart trying to beat its way out of my chest?"
    cam "Your mouth says 'get out,' but your pussy is screaming 'finally.' I can see the pulse in your neck, Banu. It’s thudding like a trapped bird. You’re not angry... you’re *starving*."
    b "N-no... stop... please... *moan*... I... huff..."
    scene end-303
    cam "You want this village pig, don't you? You want to feel a real man’s weight on you. You want these 'nasty' hands to show you what your husband never could."
    b "Hah... hah... *gulp*... what... what are you going to do to me?"
    b "The... the curtains... Kamil said... I have to... the prayer mat is in the hall..."
    cam "Listen to you. Babbling like a broken bird. The city has turned your brain to mush, but your body... your body still knows its master."
    scene black with dissolve
    "He doesn't wait for another word. He moves with the terrifying efficiency of a man who has spent his life taming the earth and livestock."
    "The sound of fabric tearing. A heavy thud of a body hitting a mattress. The air is thick with the scent of musk and fear."
    b "Hah... *moan*... you're... you're so... big... I can feel the hair on your legs... it’s... it's scratching me... *gasp*... please..."

    scene end-304 with dissolve
    play sound "voices/ah.mp3"


    "He doesn't ask. He doesn't wait. He simply devours."
    b "Mmph! *glp*... nnn... *slurp*..."
    "Camal pulls back just an inch, a string of saliva connecting them in the dim light. His scary, weathered face is inches from hers, his eyes dark with a predatory hunger."
    cam "*Harrh*... Look at you... swallowing it down like a hungry animal. You city girls love to talk, but you’re all the same when a real man puts his weight on you."
    b "Hah... hah... *mwah*... your beard... it’s so... *gasp*... scratchy... *schlick*... Camal... *moan*..."

    scene end-305
    $ renpy.sound.play("voices/kissing1.mp3", loop=True)
    b_ "God, he’s so heavy... I feel like I’m being buried alive in muscle and hair. Every time he moves, I can feel the 'meat' of my thighs squishing under him... my belly is flattened against his rock-hard gut."
    cam "You’re so thick, Banu. So much meat for me to handle. Kamil probably treats you like a porcelain doll... but I know you’re made of tougher stuff."
    b "Ahhh! *huff*... yes... *gulp*... don't stop... you monster... *moan*..."
    b_ "I can feel him... he’s so big... so nasty... I can smell the sweat on his skin, the smell of the sun and the dirt... it’s making me lose my mind."
    cam "You want it, don't you? You want this 'filthy village pig' to fill that empty, city-spoiled hole of yours?"

    scene end-306 with fade
    "Camal pulls back just a fraction of an inch, his hot, tobacco-laced breath ghosting over Banu's wet, swollen lips. His huge hand is buried in her hair"
    "As they lie there, chest to chest, the 'meat' of Banu’s housewife thighs is pressed firmly against his rock-hard, hairy lap."

    scene end-308
    "And then, she feels it—the blunt, heavy head of his massive, fat cock resting directly against her clit."
    cam "*Harrh*... Look at you. Shaking like a leaf on a winter branch. But I can feel it, Banu. I can feel how wet you are against me. You’re practically drowning my cock in that city-spoiled juice of yours."
    b "Hah... *gasp*... please... Camal... you’re... you’re so big... *whimper*... I can’t breathe with you looking at me like that..."

    cam "Good. You shouldn't be breathing. You should be choking on the truth. All those years playing the 'good wife,' wearing that hijab, making Kamil’s tea... while all the time, you were rotting for a man’s touch."
    scene end-307
    b "Mmph! *slurp*... *glp*... *moan*... Camal... *huff*..."
    b "I... I hate you... *gasp*... you're a monster... a nasty... hairy... *moan*... village monster..."
    cam "And yet, here you are. Legs open. Heart hammering like a drum. Your 'meaty' little body is practically begging me to split you in two. Tell me, Banu... does Kamil’s little city-cock even reach the sides of you?"
    b "No... *sobbing moan*... he’s... he’s too soft... he’s not... like you... *huff*... you’re so thick... so heavy..."
    cam "That’s it. Admit it. You don't want a husband. You want a beast. You want this 'filthy village pig' to root around in your guts until you forget your own name."
    cam "You city women think you're so clever. But nature doesn't care about your apartments and your silk robes. Nature only cares about the dirt... and the seed."
    stop sound
    b "Take it... *gasp*... give it to me... please... Camal... *moan*... I'm your bitch... your village bitch... just... *huff*... ruin me..."

    scene end-309 with fade
    $ renpy.sound.play("voices/slappingmedium.mp3", loop=True)
    b "Ahhhh...."
    "Camal doesn't hesitate. He grabs Banu’s meaty, silk-soft thighs and wrenches them apart, pinning her knees nearly to her ears. His massive, hairy chest descends like a landslide, crushing her into the mattress."
    cam "*Growl*... You want the pig, Banu? You want the village to rot your city soul? Then take every inch of it."
    scene end-310
    b "GAHH! *huff*... oh... oh god... *choke*... it’s... it’s too much... *moan*... Camal! You’re... you’re ripping me... *gasp*..."
    cam "Shut up! You’re not being ripped, you’re being *filled* for the first time in your pathetic life. Look at how you’re stretching for me."
    "He begins to grind, a slow, agonizingly heavy rotation of his hips that makes his coarse black hair scratch against her soft clit with every movement."
    cam "Is this what Kamil does? Does that soft little boy even know how to make you leak like this? Or does he just poke at you and apologize while you lie there dreaming of a beast like me?"


    scene end-311
    b "N-no... *huff*... Kamil... he’s... *moan*... he’s nothing... *glp*... he’s a child... *gasp*... give it to me... harder... you nasty... hairy... *slap*... monster..."
    cam "That’s it. Call me names while I rearrange your insides. You love the 'nasty' don't you? You love the smell of my sweat"
    cam "You’re just a horny little whore in a hijab, aren't you? A meaty, city bitch who needs to be plowed like the dirt back home. Tell me! Tell me who owns this pussy now!"
    b "You! *sobbing moan*... Camal... you do... *huff*... the village... the monster... *gasp*... it’s yours... *schlick*... just... don't stop... *moan*... break me..."
    cam "I’m going to do more than ruin you, Banu. I’m going to plant a seed in you that’ll make you forget you ever lived in the city."

    scene end-312 with fade
    "Camal wrenches her heavy, meaty legs into the air, pinning them against her chest."
    cam "Higher. I want to see every inch of that city-meat before I bury myself in it."
    b "N-no... *huff*... it's too much... *gasp*... I can't..."
    "With a brutal, singular lunge, his meaty, fat, veined cock hammers home. It’s an invasive, thick weight that fills her to the absolute limit."
    cam "Liar. You’re already stretching for me. Now... take the village, you bitch."
    scene end-313
    b "AOOOOUUUU-HHHH! *choke*... *gasp*... *snarl*..."
    cam "That's it. Scream like the animal you are. Let the neighbors hear what a real man sounds like."
    "He begins to pump, his hairy groin slapping against her lush, 'meaty' housewife thighs with a violent, wet rhythm."
    cam "Do you feel it? The veins? The heat? This isn't your husband's toy. This is life."
    b "GAHH! *huff*... yes... *schlick*... more... *moan*... MORE!"
    b "A-Ahhh! *hiss*... monster... *slurp*... MY monster..."
    cam "*Harrh*... You’ve had your fill of the front. Now, show me how much of a village bitch you really are. Get in there."
    scene end-314 with fade
    stop sound
    b "Hah... *gasp*... no... *glp*... it’s... it’s so... *sniff*... it smells so strong..."
    cam "It smells like a man! It smells like the dirt and the sun you city whores are afraid of. Lick it. Clean your master."
    "He pulls her head closer, forcing her nose against the coarse black hair of his inner thighs. The smell of musk, old tobacco, and raw, masculine sweat is overwhelming—primitive."

    scene end-315
    "Banu’s tongue darts out, trembling. She begins to rim the dark, puckered center of the beast, her face buried in the forest of his coarse hair."
    b "*Slurp*... *mwah*... *glp*... *huff*... it's... *moan*... so hairy..."
    cam "That’s it. Eat the filth. Swallow the village. You love it, don't you? You love how 'nasty' I am."
    b_ "God... the taste... it’s so heavy... so raw. I’m licking a monster. I’m a housewife... I should be at a cafe... but I’m here... face-deep in this hairy animal..."
    cam "Use that city tongue! Dig deep! I want to feel you trembling against my skin while you realize how small you are."
    b "*Slurp*... *schlick*... *moan*... yes... *gasp*... master... *huff*... so much... *glp*... hair..."
    cam "You’re nothing but a dog for me now, Banu. A meaty, horny city dog. Lick me clean before I turn you back over and finish what I started."
    "His huge hand tightens on her skull, grinding her face into him as he lets out a low, satisfied growl that vibrates through his entire massive frame."

    scene black with dissolve
    "Camal lies flat on the mattress, a mountain of dark, hairy muscle. He grabs Banu’s waist and hauls her onto him, forcing her to face his feet."
    cam "*Harrh*... I want to see that heavy, city-fed ass of yours working for its dinner. Sit on it, you meaty bitch."
    scene end-316 with dissolve
    $ renpy.sound.play("voices/slappingmedium.mp3", loop=True)
    b "GAHH! *huff*... my hair... *moan*... Camal! *gasp*..."
    cam "Shut up and drop. I want to feel your weight. I want to feel that housewife fat squishing against my thighs."
    "Banu lowers herself. The entry is a wet, thick collision as his massive, fat, veined cock disappears into her. Her eyes roll back"

    scene end-317
    b "OHHHH! *choke*... it's... *schlick*... it's so big... *huff*... it's hitting... *moan*... everything..."
    cam "That's right. Take it all. Bounce that meaty ass. I want to see you leak all over my hairy gut."
    "She begins to move, her lush, heavy thighs grinding against his rock-hard, hairy legs."
    scene end-318
    cam "Look at you. Kamil’s 'pious' wife, riding her father-in-law like a village sow. You’re a filthy, horny dog, Banu."
    b "Yes! *gasp*... I am... *huff*... I'm your sow... *moan*... keep... *schlick*... keep pulling... *glp*... my hair..."
    cam "I’m going to pull it until your scalp bleeds, while I plow that city-meat into the mattress. You're never going back to that soft life."
    b "A-Ahhh! *hiss*... monster... *slurp*... my hairy... *moan*... monster..."
    cam "*Harrh*... That's it! Shake for me, you greedy city bitch! I can feel you clenching... you’re trying to suck the life out of me!"
    b "GAHHH! *huff*... it's... *choke*... I'm... *moan*... CAMAL! *gasp*... I'm coming!"
    cam "Then take it! Take the village! Take every drop of the filth you've been starving for!"
    stop sound
    scene end-319 with flash
    play sound "voices/manah1.mp3"
    "With a guttural, earth-shaking roar, Camal’s body stiffens. His massive thighs cord with muscle as he erupts. It’s not a normal release; it’s a violent, primitive torrent of hot, viscous seed."
    b "AOOOOOUUU-HHHH! *shuddering moan*... *gasp*... *snarl*..."
    cam "*Huff*... *huff*... Look at that. You’re overflowing, Banu. You’re so full of me you can’t even hold it."
    scene end-320 with flash
    b "*Sobbing moan*... *glp*... so... *huff*... so much... *gasp*... you're a monster... *moan*..."
    "The cream-colored fluid runs in rivulets through the coarse black hair of his groin, soaking into his massive, heavy balls and matting the hair on his thighs."
    cam "I’m a man. And you’re just the field I plowed. Look at your 'housewife' skin... covered in the village. You’ll be smelling me for days, you horny little dog."
    "He doesn't let go of her hair. He just lies there, his massive chest heaving, watching the white flood of his seed coat his dark, hairy body, marking his territory on the meaty city woman who thought she could hide from the beast."

    scene black with dissolve
    "Camal’s massive, hairy chest crushes the air out of Banu's lungs. He’s a mountain of dark, tattooed muscle, his weight a constant reminder of the beast that just claimed her."
    cam "*Low, gravelly whisper*... Look at you. Face down in the dirt, where you belong. You’re a mess, Banu. Covered in the village... leaking like a broken faucet."

    scene end-321 with dissolve
    b "*Muffled whimper*... *huff*... Camal... please... *moan*... I'm so... *gasp*..."
    cam "You’re so what? So used? So filthy? I can feel your heart thudding against the bed. It’s the sound of a woman who finally knows she’s a dog. Tell me, does Kamil even know how to hold you down like this?"
    b "No... *glp*... Kamil... he's... *hiss*... he's too soft... *moan*..."
    cam "Soft? He’s a joke. A city lapdog. He’s in the other room dreaming of spreadsheets while his 'pious' wife is under his father, taking every drop of the 'nasty' hair and the village filth she pretends to hate."
    b "I... I love it... *sobbing whisper*... I love how you talk to me... *huff*... tell me more... tell me how... *moan*... how pathetic he is..."
    cam "He’s a ghost. He touches you and you feel nothing. I touch you and you turn into a village sow. I bet he’s never even seen you like this—naked, covered in my seed, shaking because a real man’s 'meaty' cock just rearranged your insides."
    scene end-322
    stop music
    b "Never... *gasp*... he... he's a child... *glp*... you're the master... *moan*... my hairy... *hiss*... monster master..."
    cam "I'm going to keep you like this. A secret field for me to plow whenever the city gets too quiet."
    cam "You’ll go back to his bed, but you’ll be smelling my tobacco on your skin. You'll be feeling the 'nasty' scratches of my beard every time he tries to kiss you."
    cam "You're a village bitch now, Banu. And the village never lets go of what it owns."
    b "I love how 'nasty' you are... *slurp*... I love the smell of the tobacco on your skin, the way your coarse black hair scratches my thighs until they’re red..."
    b "I’m not a housewife anymore... *huff*... I’m your sow. Your 'horny bitch' playing dress-up in a hijab. Keep me like this... keep your huge, scarred hands on my neck..."
    b "I want to feel your massive, fat, veined cock near me forever... *moan*... I want to be the field you plow until there's nothing left of the woman I used to be."


    "..."
    scene ending_9 with dissolve
    "..."
    "..."

    dev "{color=#ffffff}Thank you for playing! YOU'VE REACHED ONE OF THE ENDINGS!. Play again to discover more. If you enjoyed it, please {a=https://www.patreon.com/lustfulfantasy}support{/a} the development. Wishlist our new game here {a=https://store.steampowered.com/app/4056530/Banu_in_the_West/}Banu in the West{/a} {/color}"
    hide screen faith
    hide screen angeldevil
    $ renpy.end_replay()
    $ persistent.camalending_unlocked = True
    jump endings
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
