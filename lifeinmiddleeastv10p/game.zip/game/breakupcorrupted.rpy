
label banu_makesout_polad:
    $ renpy.block_rollback()
    scene v13-205
    play music "audio/sexy.mp3"
    b "Well, I'm happy that I came here. "
    b "It must be a privilege to live with a sexy man like you."
    scene v13-206 with vpunch
    p "You must be careful what you wish for."
    b "Polad...what..."
    scene v13-207
    p "Do you think you can hit me like that and can get away with it easily?"
    b "Polad.."
    p "No way!"
    b "Please, Nesrin can come any minute."
    p "You're refusing me but your body does not."
    p "Your body is begging me to take it."
    p "Your lips want to be kissed and your body want to be take."
    b "Please, sto...."
    scene v13-208
    "Polad didn't wait for Banu to finish her words and bent her in the air keeping her mouth busy."

    scene v13-209
    "Banu knew that Polad won't listen to her so she didn't waste energy to talk to him."
    "She knew that there's no escape from his strong arms and she had no choice but to embrace the fact that she belonged to Polad that moment. "
    "She started kissing him back passionately while she forgot that... "
    scene v13-210 with vpunch
    b "Ummmmmmm...!"
    "Polad's more dirtier."
    "He started to stimulate her clit fast while keeping her in the air so that she couldn't move."
    scene v13-211
    "He kept her mouth busy so she couldn't let out any noise."
    "Banu started to squeeze her legs as Polad's rubbing was so intense."
    scene v13-212
    "As Polad's rubbing got more intense, Banu started to lose her mind."
    "She couldn't let out the stuck moaning inside her as Nesrin was in the other room."
    p "Do you see what happens when you tease me?"
    p "Do it next time and you'll se what happens."
    b "Please, let me go."
    p "You're not going anywhere until I see your legs shaking from a powerful orgasm."
    scene v13-213 with hpunch
    stop music
    n "Polad, are you here?"
    p "..."
    b "..."
    scene v13-214
    b_ "Shit, what am I doing?"
    n "Oh you're here."
    scene v13-215
    n "What are you doing here Polad, helping Banu in the kitchen?"
    p "She needs some help here. Show her around the house so it'd be easier for her."
    scene v13-216
    n "Of course, I will."
    n "You just looked so friendly here. I'm worried if I interrupted you."
    scene v13-217
    b "No...of course not.."
    b_ "I don't know if she suspected anything or not, but I feel so bad now. "
    b_ "I feel like a used whore..."
    b_ "She's a wife to Polad, but what am I to him? A whore?"
    b_ "What am I doing....?"
    $ renpy.end_replay()
    $ persistent.banu_makesout_polad_unlocked = True
    jump banu_makesout_polad_continue

label breakupcorrupted:









    scene black with Dissolve(3)
    centered "{size=+120}Break up{/size}" with Fade(0.5, 0.5, 5)
    scene v13-89 with irisin
    play music "audio/intro.mp3"
    b_ "I can't bear this anymore. How could that asshole dare to slap me? "
    b_ "I don't deserve this. I deserve a much better life that Kamil can't possibly offer. "
    b_ "Enough of this loser. Slapping a woman and calling himself a man? You lost me you fucking idiot."
    if followpolad == True:
        b_ "Now I don't feel sorry for letting Polad fuck me behind your back. He's a much better man than you'll ever be."

    if banuturansexfirsttime == True:
        b_ "Even Turan treated me a way better than you do in bed. If you were a real man you could protect your wife and no other man could touch your wife."

    if banutakethebetfuckmurat == True:
        b_ "If Murat didn't tell me I'd never know."
        b_ "At least he's sincere with me. And the sex with him is much more enjoyable than with you. Loser!"


    scene v13-90
    k "Banu, w-what are you doing?"
    k "Banu, answer me. Where are you going?"
    b "That's is not your fucking business at all."
    b "I knew from the very beginning that we can't do together. You can't handle a woman like me. You don't deserve me, so simple."
    k "You'll be ashamed for your words when you come back tomorrow."
    b "You still think that I'll come back? Poor Kamil."
    k "Tell me at least where are you going."
    b "You don't deserve to know that."
    scene v13-91
    k "Banu..."
    b "Get out of my way."
    "Banu knew exactly what she was doing."
    "She couldn't get the attention and care she needed from Kamil."
    "And the last mistake Kamil made today was the excuse to flee away from him. "
    "Their relationship never worked. Banu knew Kamil was not the right man to be with her for a life. But she still gave him a chance to keep the promises he made which he couldn't keep. "
    "Banu has not been an angel herself. She did stuff behind his back which she wouldn't do if she loved him. "
    "Banu is not an angel. She has mistakes. She has enormous amount of lust, desire, needs, expectations which Kamil failed to fulfill."
    "And she had secrets that Kamil never knew."
    scene v13-92
    "Kamil watched her leave in silent. He couldn't open his mouth and say a single word to prevent her from leaving."
    "He was powerless, hopeless and heartbroken. "
    "He did not cheat on Banu. The picture Murat showed to Banu was taken when Kamil rejected Humay saying that he is not interested in her and that he has Banu."
    "But Banu never trusted him."
    "And she didn't take serious steps to fix her relationship with Kamil. "
    stop music

    scene black with Dissolve(3)
    centered "{size=+120}Polad's apartment{/size}" with Fade(0.5, 0.5, 5)
    scene v13-187 with squares
    "Banu had nowhere to go other than her best friends' apartment. "
    "She can't go back to Kamil as she put an end to that relationship."
    "Things with Kamil were not working out anymore. Both feelings and their sex life have already faded away. "
    "So it was the high time to end this relationship."
    "Polad and Nesrin always welcomed Banu. They were living in a big apartment just two of them so they were happy to have Banu as a guest for some time."
    scene v13-188
    n "So that asshole hit you? "
    b "Please, I don't want to talk about him anymore."
    n "If I were you I'd break one of these vases you got on his head."
    scene v13-189
    b "I wanted to do that. I wanted to spit on his face, but I was afraid and now I regret not doing that."
    n "Hmm, seeing you like this I believe that you're not planning to go back to him again. "
    scene v13-190
    p "Back to him? What are you talking about? Kamil's a dishonorable piece of shit."
    p "If I were there I'd beat the shit out of him in front of Banu."
    n "Okay calm down boy. What's it with you? Why are you getting angry all of a sudden?"
    p "Oh please, Nesrin. I can't tolerate when I hear a piece of shit treating his lady like this."
    p "A lady like Banu, pure and with good morals."
    b "..."
    n "..."
    scene v13-191
    n "He's right Banu. You're precious to us. I don't want you to feel as a guest here. Just feel yourself at home."
    b "Thank you guys. I knew that I can count on you."
    n "Look, Polad and some friends went fishing today and they were lucky this time. He came back with a big bucket full of salmon. "
    n "Let's cook together."
    b "Okay..."
    scene v13-192
    p "I don't want to be rude Banu but if you fled from him and came here, I won't let you go back to him again. "
    scene v13-193
    b "I don't have any intention like that."
    scene v13-192
    p "Just keep that in mind. If you go back to him, I won't forgive you."
    p "I just want the best for you. I don't want him to hurt you again."
    p "I want you to stay here under my protection."
    p "I'll protect you and keep those people away from you who can hurt you. You just need to listen to me and do what I say."
    scene v13-193
    b_ "He's always been so masculine like that."

    p "You know that what I do is for your safety and wellbeing. "
    p "So I'll know where you are going and whom you are talking to. "
    p "Most importantly I don't want you to contact that husband of yours."
    p "So these are the simple rules."
    b_ "Isn't he going too far?"
    b_ "Anyway, I don't have a choice. He's the man of this house after all. I think I can do what he says."
    b_ "He just care about me."
    scene black with dissolve
    centered "{size=+120}Later{/size}" with Fade(0.5, 0.5, 5)
    scene v13-194 with fade
    "Banu was making some tea to help Nesrin out in the kitchen."
    p "I hope you didn't get offended by what I said earlier."
    b "..."
    scene v13-195 with fade
    b "Not of course."
    b "It's perfectly fine. This's your house and you should be aware of what's happening in your house."
    p "Then why don't you look at me while you are talking to me?"
    scene v13-196
    b "I was just busy making...."
    if followpolad == True:
        play music "audio/sidesex.mp3"
        p "You can't forget about it, right?"
        b "What do you mean?"
        p "What we did in my bedroom."
        b "Polad, please, that was a big mistake that we did."
        p "But both you and me enjoyed it so what we did was not a mistake actually."
        b "Don't you think that what you do is a betrayal to Alper who was your best friend and my husband."
        p "Please, don't talk about him. This's not betrayal. This's what both you and me want."
        p "I simply want the best for you and I want to give you the pleasure that your man fails to give you."
        b "Polad, please, talking about it makes me..."
        stop music

    p "I got it."
    p "Let's change the subject."
    scene v13-198


    play music "audio/kometaback.mp3"

    label poladconversationwithbanuinthekitchen:
        scene v13-198
        menu:
            set menuset
            "Talk about motorcycles":
                $ renpy.block_rollback()
                $ poladconversationinthekitchenchoicesblabla += 1
                scene v13-202
                b "I know where your weak spot is."
                b "Motorcycles."
                p "Damn right."
                p "You know me Banu. I'd never say no to a good motorcycle and a pretty lady like you..."


                jump poladconversationwithbanuinthekitchen
            "Talk about his work":
                $ renpy.block_rollback()
                $ poladconversationinthekitchenchoicesblabla -= 1
                scene v13-201
                p "I don't want to talk about it and I don't recommend you to be interested in those stuff."
                p "That's just not for you so don't ask anything relating to that."
                p "I want you to stay away from that stuff."



                jump poladconversationwithbanuinthekitchen
            "Compliment his body":
                $ renpy.block_rollback()
                $ poladconversationinthekitchenchoicesblabla += 1
                scene v13-203
                b "Your body is so strong and rock hard. Do you train a lot?"
                p "Well, I don't go to the gym."
                p "I train when I get some free time. "
                p "I do some regular pushups and pullups."
                b "You're so determined then. You're so athletic and you can get any girl's mouth watering with this body."
                p "Well, that's the cream. I'm happy you liked it."




                jump poladconversationwithbanuinthekitchen
            "Ask how many women he slept with":
                $ renpy.block_rollback()
                $ poladconversationinthekitchenchoicesblabla -= 1
                scene v13-204
                b "Well I guess you can get any woman you want easily so I wonder how many woman you slept with?"
                p "Hey stop there. This's not your subject, is it?"
                p "You'll get punished if you come back to those subjects again."
                b "Oh...okay."




                jump poladconversationwithbanuinthekitchen
            "Tell him you are busy":
                $ renpy.block_rollback()
                scene v13-204
                b "Okay Polad, let's talk another time."
                b "I'm a bit busy here."
                p "Okay."



            "Tease him" if poladconversationinthekitchenchoicesblabla == 2:
                jump banu_makesout_polad




    jump banu_makesout_polad_continue

label banu_makesout_polad_continue:
    stop music       
    scene black with dissolve
    ""
    centered "{size=+120}Polad's apartment{/size}" with Fade(0.5, 0.5, 5)
    ""

    scene v14-148 with squares
    "It was at midnight that Banu couldn't sleep and went to the kitchen to drink something."
    "She was distracted by the sounds coming from the bedroom."
    "A female moaning was travelling all the rooms to the kitchen. "
    scene v14-149
    b_ "They're doing it again. Almost every day and it lasts hours."
    b_ "Polad has so much sexual energy."
    b_ "This's distracting..."
    b_ "Wait...They left the door open. "
    b_ "Why don't they care that there's another female living here."
    scene v14-150
    b_ "This's shameful..."
    b_ "You shouldn't be doing this, Banu."
    "She couldn't stop the unbeatable urge inside her and approached the door of the bedroom. "
    scene v14-151
    play music "voices/makeout.mp3"
    b_ "Oh my God..."
    b_ "I can't believe I'm doing this."
    scene v14-152
    b_ "They're so hot and passionate..."
    b_ "No, I should leave now...he can see me... "
    menu:
        "Leave":
            $ stayandwatchpoladandnesrin = False
            $ renpy.block_rollback()
            scene v14-155
            stop music
            b_ "Anyway, it's none of my business. This's their house after all. They can do what they want."
            "Banu left immediately but deep inside her she felt jealous and maybe wanted to be in the place of Nesrin."
            "She didn't know why this happened to her. She just couldn't stand seeing Polad engaging with a female."
        "Stay and watch them":





            $ stayandwatchpoladandnesrin = True
            $ renpy.block_rollback()
            play music "audio/sensual.mp3"
            scene v14-153
            "Banu was frozen right where she stood."
            "She was amazed to see the familiar figure, the man she appreciated but this time naked and agressive."
            scene v14-154
            b_ "He's so hot and he's so rough with her."
            b_ "I can't stop watching them. They're so beautiful and their bodies are compatible."
            b_ "Nesrin really got some weight down there...She's now more curvy..."
            scene v14-156

            b_ "And Polad..."
            b_ "He's so masculine as always. The way he moves his hips and the way he looks deep down her eyes...It's so sexy."
            scene v14-157
            if followpolad == True:
                b_ "Nesrin's moaning so loud. I bet with each thrust he pushes his big cock all the way deep inside her. "
                b_ "His cock's so big and long. When he pushed inside me I went crazy. He almost tore my pussy..."
            else:

                b_ "Nesrin's moaning so loud. I bet his cock is so big or she wouldn't scream like that."
                b_ "I wish I could see his cock..."
            b_ "Oh my God...what am I thinking...?"
            scene v14-158
            b_ "I feel no shame at this moment. Seeing him having sex makes me horny."
            b_ "I like watching him. I can't deny it that I actually like him."
            b_ "I don't care if he sees me anymore."
            scene black
            show banuspyingpoladnesrinanimation
            play music2 "voices/makeout.mp3"
            b_ "His body's so muscular and powerful."
            b_ "It takes years and determination to get those muscles."
            b_ "I'm already addicted to his body."
            b_ "Ohhh....I wish it was me now he's pounding."
            b_ "I can't stop myself seeing him like this. It makes me dirtier..."
            scene v14-160
            "Banu's heart skipped a beat when Polad raised his head and their eyes collided."
            "He continued to look at Banu's eyes while still fucking Nesrin even harder."
            scene v14-161
            "Banu was frozen like a doll. All her lust and horniness went away in a moment."
            "She didn't know what to do or how to act."
            scene v14-162
            "Polad continued to look directly into Banu's eyes. "
            "His confident look and slightly smiling face sent so many messages to Banu."
            scene v14-163
            stop music 
            stop music2
            "She felt so ashamed but didn't dare to take her eyes off for a moment."
            "All her body was shaking in a stress and she reached to a point that she couldn't take it anymore and ran to her peaceful room."



    scene black with Dissolve(3)
    ""
    centered "{size=+120}The night club{/size}" with Fade(0.5, 0.5, 5)
    ""
    scene v14-164 with fade
    "After breaking up with Kamil, Banu told him that she wanted to get divorced and there's no need to stay married."
    "Kamil was shocked. He didn't want to get divorced. He suggested to give their relationship some time and he was sure that he'd get Banu back and win her heart again."
    "But for Banu it was all over."
    scene v14-165
    "She wanted to start a new life without a husband and anybody that she may have a commitment to."
    "She knew what she needed. She needed to have fun and experience things that she had not experienced yet."
    scene v14-166
    "There was no special reason that she may need a man like Kamil while there were a bunch of men out there."
    "With such a beautiful body, Banu thought that she needed some attention that Kamil failed to give her properly for a long time. "
    scene v14-167
    b_ "Finally, I'm free and I don't have any commitment to any relationship..."
    "There was only one thing that was bothering Banu. "
    b_ "I don't want Polad to see me like this... He told me not to go out at night and set so much strict rules for me."
    b_ "I know that I'm free and I can do whatever I want but... I don't want to let Polad down."
    b_ "If he sees me like this, he'll get angry for sure and I don't want to make him angry."
    b_ "I should leave now and return soon that he wouldn't suspect anything."
    scene v14-168 with fade
    play music "audio/chill.mp3"
    "After some time Banu met Hicran who promised her the best evening of her life. "
    "They would hit the best night clubs, get drunk, dance and fully enjoy their freedom. "
    "Banu wore the sexiest black outfit which got into the shape of her beautiful curves and showed them off."
    scene v14-169
    hic "Damn girl, you've become a different Banu. Where did you get that outfit? You look like a slut, hehe."
    scene v14-170
    b "Stop it, Hicran. I feel so embarrassed now. "
    b "I've never walked in public like this. I feel everybody is watching me. "
    scene v14-171
    hic "Don't worry you'll get used to it. "
    hic "A beautiful body like yours must be seen and appreciated by everybody."
    hic "I mean not only by men but also women..."
    "Hicran winked at Banu and smiled after finishing her words."
    b_ "Hicran's such a lewd woman. I didn't pay attention to her for a long time."
    b_ "But now I notice how she looks at me and behaves to me."
    hic "Shall we go now?"
    b "Let's go."
    scene v14-172
    b "Don't you think that your outfit is a bit short?"
    hic "Are you jealous of me?"
    b "Come on, stop that..."
    scene v14-173
    hic "We're females and every female likes attention from the opposite sex."
    hic "You also like it, don't you? That's why you wear this dress."
    b "You asked me to wear revealing dress so I did."
    hic "You wouldn't wear it if you don't like it."
    scene v14-174
    "Banu was tempted by Hicran's words. She noticed how lewd Hicran became."
    "She was married but she acted like she's single."
    "Hicran really confused Banu. She had a strange relationship with her husband and she was wearing hijab with inappropriate clothes."
    "But when Banu asked her about these, she always changed the topic."
    scene v14-175 with fade
    play music "audio/kometaback.mp3"
    "After some time walking among the narrow streets and high buildings they ended up in a noisy night club."
    "They sat on the second floor and Hicran ordered two shots before they started a new conversation... "
    scene v14-176
    b "Listen Hicran, I wanted to ask you this for a long time but didn't have a chance..."
    hic "Yeah, what's that?"
    b "Why hijab? Why do you wear hijab exactly?"
    scene v14-177
    hic "You're weird Banu. Why people wear it? You know that."
    scene v14-178
    b "Come on, we both know that you're not a religious person Hicran."
    b "There's something that you're hiding from me."
    b "Maybe it's time to tell me some things that I don't know about you."
    scene v14-177
    hic "Okay, you win. There's something that you don't know yet."
    hic "I'll tell you, but only if you agree to my terms and be a good girl."
    hic "Today you'll do what I say and I'll give you the reward in the end and tell you my secret."
    hic "Come on now, take the glass."
    scene v14-179
    hic "Cheers..."
    b "Cheers.."
    scene v14-180
    "It was the first time Banu was drinking vodka."
    "As Hicran told her she took the shot glass and drank it in one go."
    scene v14-181 with fade
    "Hicran ordered two more shots while Banu was still complaining about its taste."
    b "This drink is really so bitter."
    hic "It's good for you. It makes your throat warmer and kill the microbs."
    b "This makes me dizzy, Hicran. I don't think I should drink the second glass."
    hic "Okay, this will be the last glass I won't force you after this..."
    b "Hicran..."
    scene v14-182
    b "The two guys standing there...I think they're checking on us."
    hic "You're already paying attention to the boys. I told you the shots will be good for you."
    "Banu looked at the men standing opposite to her and gave them a sexy smile."
    "With her generous smile Banu sent them a message that they're available and they took the hint. "
    b "They're coming here..."
    hic "Already...?"
    hic "You're such a naughty girl."
    scene v14-183
    z "Hey girls, we noticed that you're alone here and two more seats are available so can we sit with you?"
    hic "Sure that'll be cool."
    scene v14-184
    z "I guess we should introduce ourselves. My name is Zaur and this is my brother, Orxan."
    hic "Nice to meet you guys, I'm Hicran and this's my shy friend, Banu."
    b "Come on, I'm not so shy like you think."
    scene v14-185
    "Zaur who's sitting next to Hicran constantly winking at Banu and giving her compliments which Banu seem not to like them."
    "He was sitting close to Hicran whispering to her ear and constantly touching her and Hicran was smiling at him. "
    scene v14-186
    "For some reason Banu didn't like Zaur's touches on Hicran and she watched him bitterly."
    b_ "Why Hicran's talking so close to him. I know that she wouldn't give in to a guy like him."
    b_ "We're here to have fun but I don't trust him. He's eating us with his eyes. "
    scene v14-187
    z "So yeah, I'm sorry for saying this but girls, your bodies are so sexy and fit. You've a big chance to be fashion model."
    hic "Are you serious?"
    z "Of course, my brother and I are professional photographers and we're in this for a long time. We've a professional studio and many partners. "
    z "If you want to try this we can help you to earn serious money. "
    hic "Why not? We can try that."
    scene v14-188
    b "What? Of course not. We can't do that Hicran."
    scene v14-189
    z "Your friend looks very aggressive today. Hey Orxan maybe you can convince Banu about what I said. "

    z "They've a chance but she doesn't want to listen to me."
    scene v14-190
    z "If you come to our studio we'll make you believe how professional we are."
    hic "Ohh really?"
    scene v14-191
    "Banu felt so jealous when Zaur slid his hand between Hicran's legs and started to caress it. "
    "She didn't believe a single word he said and thought he's just trying to get into Hicran's pants."
    "The feeling that Zaur may steal Hicran from her was still bothering her."
    scene v14-192
    o "You should trust my brother. He's in business for so long but let's talk about it another time."
    o "So what do you do for a living Banu?"
    scene v14-193
    b "I work as HR assistant..."
    o "It's nice. It's important for a woman to stand on her own feet you know..."
    o "So you're not depended on your husband. By the way speaking of your husband, I see that you've a good relationship with your husband that he doesn't mind you having fun. "
    b "He was a pig so I broke up with him. "
    o "Ohh I see. "
    scene v14-194
    o "If he's a pig, why wasting time with him. You did the right thing."
    o "Life's short. You must learn how to have fun and try new things all the time."
    o "You're so sweet and sexy. If you were my wife I'd show you to everyone so they know how lucky I am."
    b "Thank you but I don't agree on showing your wife to everyone. There're some things that men should keep private."
    o "I know what you mean. Some men lock their wives indoors so other men don't look at them."
    o "That's pathetic. They're just afraid of losing her to another man. "
    "While speaking to Banu, Orxan grabbed Banu by her waist and hold her close to him. "
    b "Look, you better not do that..."
    o "Why? Look, your friend's having fun already."
    scene v14-195 with hpunch
    "When Banu turned her head towards Hicran she was shocked by the picture before her eyes."
    scene v14-196
    "Hicran was already making out with Zaur."
    "Zaur was caressing Hicran's thigh while kissing her passionately."
    b "Hicran, what're you doing?"
    scene v14-197
    hic "Hey Banu, I'm sorry. I'm kind of busy here..."
    b "Please, stop that."
    hic "But why? Do you remember what we agreed on? We'll have fun. "
    hic "Now Orxan's waiting for you. Don't let him down."
    scene v14-198
    o "She's right. Your friend's already taken. It's only fair if you give me a kiss now."
    b "But I..."
    o "Come on, show her that she's not only the hot one here. "
    "The alcohol had an effect on Banu and made her softer now. She looked at Orxan's lips and they're so tempting."
    "But the devil and angel inside Banu were still fighting and making her decision harder. "
    menu:
        "Kiss him":
            $ banukissorxan = True
            $ renpy.block_rollback()
            scene v14-199
            play music "audio/sexy.mp3"
            "Banu slightly leaned towards Orxan and closed her eyes."
            "He pulled her by her waist closer to her until their lips touched."
            scene v14-200
            hic "That's it. You did it, Banu. You look so naughty."
            "Banu felt embarrassed at first feeling that she had audience but her mouth was busy to answer Hicran. "
            scene v14-201
            "Suddenly, the shy feelings faded away and Banu started kissing Orxan passionately."
            "Orxan held Banu tighter and stuck his tongue into her mouth."
            "Banu was going crazy at this moment. She was horny and frustrated."
            scene v14-202
            z "Look at her, she's so wild, isn't she?"
            hic "Definitely..."
            hic "Hey, slower Banu. You're going to eat him hehe."
            scene v14-203
            b "Stop it, Hicran you make me embarrassed."
            b_ "I can't believe this. I just kissed him."
            b_ "But it felt good."
            b_ "Ohh no, it's late already."
            b "I think it's time to go Hicran, What do you think?"
            stop music
        "Reject him":

            $ banukissorxan = False
            $ renpy.block_rollback()
            scene v14-203
            stop music
            b "No, I can't do that, please."
            hic "Come on Banu. It's just a kiss."
            b "I think it's time to go Hicran, What do you think?"

    b_ "I should leave early. If I stay late, Polad'll see me coming home late in this dress."
    b_ "I promised him not to come home late and engage in stuff like this."
    b_ "I don't know how he'd react if he sees me like this."
    b_ "But if I reach home before he does he won't see me."
    b_ "I should leave now..."
    scene v14-204
    hic "What? You can't leave now. It's time to dance. Don't forget it."
    z "Yeah, listen to your friend, she knows how to have fun."
    menu:
        "Say you have to leave":
            $ banuagreetostayatclub = False
            $ renpy.block_rollback()
            scene v14-205
            b "No. I really have to go. You don't understand it. I can't stay any longer."
            hic "You're leaving me alone?"
            b "I'm sorry but we better go."
            hic "Damn you're no fun. Alright, sorry guys, we have to go now..."
            stop music
        "Agree to stay":



            $ banuagreetostayatclub = True
            $ renpy.block_rollback()
            scene v14-204
            b_ "Well, Polad's not my boss. He can't order me what to do. I'm here and I came to have fun."
            b "Alright, let's do it. "
            scene black with dissolve
            scene v14-206 with fade
            play music "audio/arab.mp3"
            "After a few minutes, Banu and Hicran were in the center of attention."
            "By looking at Hicran, Banu's encouraged to be original and free."
            scene v14-207
            "She was dancing like there was no one around."
            "For a long time she didn't have a chance to have fun like this and release stress."
            "Vodka made Banu's head dizzy and her body lighter."
            "She raised her hands while moving her body with the rhythm of the music."
            scene v14-208
            "Soon Orxan and Zaur joined them. Zaur started to dance with Hicran and Orxan danced with Banu standing right behind her following her moves."
            scene v14-209
            z "Your friend got into the mood already."
            hic "Yes, she has a hidden talent."
            scene v14-210
            z "I think she likes Orxan."
            hic "You think so?"
            z "Yes, your friend's not so pure as she seems. "
            hic "And what do you think about me?"
            z "Your curvy legs make me so horny. I can barely stop myself taking you right here."
            hic "Hmm, is that so?"
            scene v14-211
            "While Hicran and Zaur were dancing together, Orxan approached Banu and started to touch her waist and belly from behind."
            scene v14-212
            b "Hey, you need to behave yourself right?"
            b "You better not get so touchy."
            o "This's sensual dance. You should do it right."
            o "Come on come closer to me and turn around. I'll show you how to do that. "
            menu:
                "Dance close to him":
                    $ banudanceclosetoorxan = True
                    $ renpy.block_rollback()
                    scene v14-213
                    b "Do you mean like this?"
                    o "Just like that..."
                    b "Ohh....I feel your...."
                    "Orxan grabbed Banu from behind and started to grind his crotch against her ass. "
                    "Banu felt so defenseless but aroused at the same time so she didn't bother to move away and started to grind her ass against him. "
                    o "Now bend over more and show me what you got."
                    scene v14-214
                    "Banu went with the flow and demonstrated what she had seen in the dancing videos."
                    o "That's right. You do it like a professional."
                    o "Keep going like that."
                    scene v14-215
                    b "Do you like that?"
                    o "I love that.."
                    b "I know you love it. You're really excited down there."
                    o "Oh girl, you make me crazy."
                    scene v14-216 with hpunch
                    "Orxan took Banu with force and started whispering dirty words to her ear while holding her waist and her hand. "
                    o "Now you know that how much you make me excited."
                    o "I know that you like it and I know that you're burning down there."
                    o "Now I want you to meet me in the WC. "
                    o "I'll give you the best sex in your life"
                    o "I'll fuck you till you cum on my dick multiple times."
                    o "What do you say?"
                    b "..."
                    b_ "He's saying so dirty words. Even thinking about it makes me horny..."
                    b_ "No, I can't stay here...I have to go."
                    b "Listen, I'm sorry but I have to go."
                    "After having the alone time dancing on her own Banu realized that Hicran and Zaur disappeared so she went looking for them."
                "Keep the distance":



                    $ banudanceclosetoorxan = False
                    $ renpy.block_rollback()
                    scene v14-217
                    "Orxan was saying something but Banu couldn't hear any of them as the music was too loud."
                    "She was just smiling at Orxan and moving her body slowly with the music. "
                    scene v14-218
                    o "Your body looks super hot in this dress."
                    b "Thank you..."
                    o "If you want I can drive you home tonight, just let me know."
                    b "Thank you, Orxan but I'm not that type of woman... "
                    scene v14-219
                    "Orxan said something but Banu was not listening at this moment."
                    "She was enjoying dancing in the crowd, moving her body with the rhythm of the music and getting attention."
                    "And the men around her, they could watch the shape of her body but couldn't touch it."
                    "After having the alone time dancing on her own Banu realized that Hicran and Zaur disappeared so she went looking for them."

            scene v14-220
            play music "audio/tension.mp3"
            b_ "It's too late. We have to leave already."
            b_ "But where's she?"
            b_ "Damn, this girl will get me in trouble..."
            scene v14-221
            "So Banu went looking for them in the WC."
            "It was the only place came to her mind when she realized that her friend suddenly disappeared."
            b_ "Wait, what's that sound?"
            b_ "Is it..."
            scene v14-222 with hpunch
            b_ "Oh my God!"
            b "Hicran!"
            scene v14-223
            hic "Oh shit.. Listen Banu..."
            z "Damn girl, again you're ruining our fun."
            "Banu was shocked and unconsciously started staring at Zaur's cock. "
            scene v14-224
            z "Just wait outside. We'll let you know once we're finsihed."
            hic "No, he's just joking."
            hic "Let's go."
            scene v14-225
            "Banu turned around and left when she realized that she was staring at them and the situation got awkward. "
            "Banu didn't wait and left and Hicran followed her."

    stop music        



    scene black with dissolve
    centered "{size=+120}The graveyard{/size}" with Fade(0.5, 0.5, 5)
    scene v15-1 with dissolve
    play music "audio/intro.mp3"
    "It was quite a while that Banu hadn't visited her beloved deceased husband."
    "Banu used to visit Alper's grave very often but recently she got her head so busy that she could even forget Alper who was still the most precious person for her."
    scene v15-2 with dissolve
    "Kamil didn't know about Banu's visits to the graveyard. She didn't let him know about it because she was not sure Kamil would be happy about it or even let her visit her dead husband."
    "At least Kamil was her husband and he wouldn't be happy if he knew Banu still didn't forget about Alper."
    "So Banu used to come to the graveyard to be with her beloved one and talk to him some time without Kamil knowing about it."
    "After she broke up with Kamil and left his house, she needed an urge to come here and talk to a person that she truly loved."

    scene v15-3
    "She was not afraid of coming here alone in the evenings because she didn't want anybody to see her and wanted to have alone time with Alper."
    "She was now here standing in front of Alper's grave. The grave stone was a regular stone and got dirty from the humidity because of no attention."
    scene v15-4
    b "I'm really sorry that I can't visit you often recently."
    b "A lot of things happened to me recently but I managed to survive."
    b "Life is so hard without you..."
    scene v15-5
    b "I know that I made mistakes and I've been so weak and now my life's fucked up. I don't really know what to do."
    b "I'm planning to get divorced. Kamil's just a selfish pig. I'm sorry to say this but he's not a man that I appreciate to be with. "
    b "He's just not enough of a man that controls me, handles me or even satisfies me."
    scene v15-6
    b "You know that he can never replace you. "
    b "I'll always belong to you in this life and in the next one. My body and sould will always belong to you."
    scene v15-7
    b "I'd never let him touch my body but...I tried to give him a chance and I let him touch me...but regret that."
    b "Please, don't call this cheating. It's not like that."
    b "He can never touch my body like you did and the connection between Kamil and me was only physical. He was just my husband and now he lost that privilege too."
    scene v15-8
    b "I know that I have so many mistakes.."
    b "I'm not a complete pure woman. I've been dirty. My spirit has been touched by dirty stuff. Please, forgive me!"
    scene v15-9
    b "Once you left me, my weak body started to seek attention. "
    b "Once you stopped feeding me with your precence, I couldn't help but searched attention elsewhere."
    b "I touched my body and I enjoyed it."
    if banuturansexfirsttime == True:
        b "I let another man have my body. "
        b "He was not my husband, Kamil."
        b "I know how degrading this is but I enjoyed his touches..."

    if followpolad == True:
        b "I'm sorry to confess this but I betrayed you with your best friend..."
        b "Yes I did it with your best friend, Polad."
        b "We both betrayed you. Now you know that how awful I've been."


    if banutakethebetfuckmurat == True:
        b "Once I got drunk. I betrayed my religion. I couldn't control myself and let a boy younger than me enjoy my body."
        b "I was so desperate. I couldn't control my urges and I engaged in sex with a man."


    b "My body got so horny after you left me and I sometimes couldn't control it. "
    b "I touched my bare body. I dreamt about dirty things. I dreamt about other men..."
    b "Please, forgive me because I've been so dirty and bad. "
    b "And... stop looking at me like that. You're also guilty because you left me."
    b "I know that you can't stand it. You know that I'm surrounded by dirty men everywhere..."
    b "They enjoy looking at my body. The body that beloged to you."
    b "They're looking for a single chance to get pleasure from me."
    b "I don't know why but I'm angry at you..."
    b "Please, forgive me."
    b "I have to leave now but I'll come back and one day we'll be together forever..."
    scene v15-10 with fade
    "Banu was so relieved after confessing to Alper but at the same time so embarrassed to look into his eyes."
    "She hated herself for a moment that she had been with another man other than Alper and she had to come visit him secretly."

    scene v15-11 with fade
    "But it was too late. Banu had a new life now and new opportunities."
    "Alper didn't exist anymore. No matter how hard Banu tried to stay with him, life pulled Banu away from Alper every single day."
    "Banu was changed. She was not the same Banu that Alper dated, not the same Banu that blushed and ran away when Alper tried to kiss her."
    "It was fortunate for Alper that he didn't see the changed Banu..."
    "...or maybe he did..."
    stop music




    scene black with dissolve
    centered "{size=+120}At work{/size}" with Fade(0.5, 0.5, 5)
    scene v15-12 with squares
    play music "audio/tension.mp3"
    "Banu was worried when Ali called her to his room. He usually does this when there's something important to discuss."
    "Last time when he called her, she had to go to the USA with one of his partners."
    "But this time it was different. Ali kept looking into Banu's eyes with a dead serious face from the moment she entered the room. "
    scene v15-13
    "Ali used to scold Banu lately for the inconveniences she did in her work. "
    "Banu was late for work and most of the time she was not in time to deliver the tasks she was given."
    "However, Ali always tolerated her lack of responsibility and he didn't want to fire her."
    "He was always respectful towards Banu because of her being religious."
    "Ali was also a religious man and maybe that was the only reason that he didn't fire Banu in spite of her numerous mistakes."
    "But lately he wasn't hearing good things about Banu..."
    scene v15-14
    b "You wanted to see me. I hope I haven't done anything wrong. "
    ali "Have you finished the weekly report?"
    b "I...yes I sent it to your email."
    ali "I don't mean that one. I'm talking about the newly registered students' files. "
    b "Oh...that one. I'll finish it by Monday, I promise."
    ali "Banu..."
    b "You can't imagine how busy I was...really.."
    ali "Banu! Do you think I care?"
    b "But..."
    scene v15-16
    ali "Why do you think I should tolerate this?"
    ali "This's not the first time, not the 5th time, not the 10th time."
    ali "You make the same mistakes every time. Why are you so comfortable?"
    b "I think you understand that..."
    ali "I DON'T UNDERSTAND!"
    scene v15-15
    b "Well, you don't need to shout at me like that. I don't understand why you're so mad at me. I always take more time to prepare the files."
    scene v15-16
    ali "We lose lots of customers because of delayed documents. You know that?"
    ali "Every time they call and cancel their applications. They want their money back. All because of the stupid workers like you."
    scene v15-17
    b "Hey that's it. You better mind your words when you talk to me. "
    b "I work more than every worker here. Every time I stay overtime to save your ass. I do all your paperworks and you thank me like this?"
    scene v15-18
    ali "Lower your tone here. You can't talk to me with that tone."
    ali "You get bonuses for the additional work you do."
    ali "But it's over now. Write your letter of resignation. "
    scene v15-19
    b "What? Are you firing me?"
    ali "That's enough. You've done enough harm to the company."
    ali "Additionally, I don't have any reason to keep you here. Your behavior is not appropriate for our company."
    ali "I've been hearing so much about you lately. You go to night clubs, you drink alcohol, you hang out with men. Every person I see, talks about you Banu."
    b "What!?"
    scene v15-20
    b "Now I understand the reason you talk to me like that."
    b "But you know that they're all rumors. They're not true."
    ali "I've heard enough. I wish you respect yourself more. "
    ali "You're wearing a hijab but you don't respect it. You don't respect your religion."
    scene v15-21
    b "Do you know that you're insulting me right now?"
    b "What they say is not true. My enemies turned you against me. I know that."
    b "But I do need this job. Please, give me one more chance. I can't stay at home all day. I'll prove myself."
    ali "You don't need financial support. You have a husband. You can just ask money from him."
    ali "But if you don't want to see his face, there's only one way to guarantee your position here."
    b "What's it?"
    scene v15-22 with vpunch
    ali "You become my personal assisstant. Can you do that? "
    b "Hey! What're you doing?"
    scene v15-23 with vpunch
    b "You pig! Don't dare to touch me again."
    b "Do you think I'm like one of your whores here?"
    b "I can make you spend the rest of your life in jail, asshole."
    scene v15-24
    ali "Shut up, slut. You can't talk to me like that."
    ali "Now get the fuck out of here slut and don't ever put your foot in my company."
    stop music

    show black with Dissolve(3)
    ""
    centered "{size=+120}A dream{/size}" with Fade(0.5, 0.5, 5)
    scene v15-258 with Fade(0.5, 0.5, 5)
    play music "audio/arab.mp3"
    b "I can't believe you did that."
    b "But we can talk about it later. If we stay here a little longer, we'll hate to take a taxi and it's dangerous."
    b "I'm afraid to take a taxi at night. Let's just go."
    scene v15-259
    hic "Oh, my adventurous friend, it seems our dream world has taken us on an unexpected journey."
    hic "Perhaps this place symbolizes a desire for liberation, to let loose and embrace the unknown."
    b "What? You want to stay longer?"
    scene v15-260
    b "Liberation, huh? That does sound like something I've been yearning for lately."
    b "Life has been filled with responsibilities and routines. I sometimes feel like I'm missing out on spontaneity and excitement."
    scene v15-262
    hic "I know exactly how you feel, Banu. But remember, life is a delicate balance. It's important to find joy in the everyday moments as well."
    hic "However, I do encourage you to explore your passions and take risks when the opportunity arises."
    scene v15-261
    jump banu_wet_dream

label banu_wet_dream:

    b "You're right, Hicran. I shouldn't let myself get too caught up in the routine. There's so much more to experience and discover."
    b "I want to embrace life to its fullest."
    scene v15-262
    hic "That's the spirit, my dear friend! Follow your heart, chase your dreams, and let the winds of adventure guide you."
    hic "Take risks, make mistakes, and learn from them. Life is meant to be lived, after all."
    scene v15-261
    b "Thank you, Hicran. Your words are like a gentle breeze reminding me to step out of my comfort zone and embrace the unknown."
    scene v15-262
    hic "Since we are in a dream world, I can help you relax and let off steam."
    b "But how?"
    scene v15-263 with squares
    b "Hicran, we shouldn't be doing this."
    hic "Don't worry. This's our world. Nobody is going to see us. "
    scene v15-264 with fade
    b "This....this is not a good idea...let's just get out of here."
    hic "Shhhh...I know you want to do this for so long."
    b "I want this but..."
    b "This is dangerous..."
    hic "Come here."
    scene v15-265 with fade
    stop music
    b "Ummm.."
    b "This feels so right..."
    scene v15-266 with fade
    hic "We have something to give each other."
    hic "We should have done this a long time ago."
    scene v15-267 with fade
    b "You're so passionate."
    b "I didn't know you looked at me that way."
    scene v15-268 with fade
    hic "Your nipples are so stiff now."
    hic "I know you enjoy this as much as I enjoy."
    scene v15-269 with fade
    b "Wait...Do you really want to do this?"
    hic "I've been waiting for this."
    hic "Now I have you and I won't let you go."
    scene v15-270 with fade
    hic "Your body is so sensitive."
    hic "You just got wet from my touches."
    hic "Your body just needs a female attention, Banu."
    hic "Come on, lay down here..."
    scene v15-271 with fade
    hic "Do you want me to make you cum?"
    b "Oh yess...I want it...I'm so wet right now."
    scene v15-272 with fade
    hic "Relax now...I see you're so nervous."
    hic "I'll make your pussy feel good."
    scene v15-273 with fade
    b "Oh shit...my body's on fire right now..."
    b "Ahhhh..."
    b "You're so good at this, Hicran."
    scene v15-274 with fade
    b "Ohhhh...I'm losing my mind..."
    b "This feels so real, so perfect."
    b "I want to stay here with you."
    b "The warmth of your presence, the tenderness of your touch... it's like a dream within a dream. I wish we could stay in this moment forever."
    b "..."
    scene black with dissolve
    b "..."
    $ renpy.end_replay()
    $ persistent.banu_wet_dream_unlocked = True
    jump banu_wet_dream_continue

label banu_wet_dream_continue:

    scene v15-275 with dissolve
    "As Banu slowly opened her eyes, the remnants of the dream lingered in her mind like delicate threads of an unfinished story."
    "She lay in bed for a moment, savoring the bittersweet emotions the dream had stirred within her."
    scene v15-276
    "The warmth of Hicran's presence still lingered, but she knew it was time to face the reality of the waking world."
    "As she traced the contours of the dream in her mind, Banu felt a mixture of emotions wash over her. "
    "There was a longing, an ache for the connection and intensity she had experienced."
    "The dream had stirred something deep within her, a desire for more, for a love that mirrored the passion she had felt."
    scene v15-277
    "With a wistful sigh, Banu shifted and swung her legs over the edge of the bed, her thoughts swirling with fragments of the dream."
    "She took a deep breath, feeling a mixture of contentment and longing."
    scene v15-278
    "As she stood up, a determined expression settled on her face, infused with the essence of the dream's passion."
    "As she opened the wardrobe door, a soft light spilled onto her face, casting a warm glow in the room."
    "Banu's eyes scanned the collection of undergarments, each piece a reflection of her personality and style."
    scene v15-279
    "She reached for a delicate lace bra, feeling the smooth texture against her fingertips."
    scene v15-280
    "Banu, feeling a tinge of discomfort, quickly adjusted her stance as she noticed Polad enter her room."
    "The unexpected intrusion caught her off guard, and she momentarily hesitated to turn and face him."
    scene v15-281
    b "I didn't appreciate you coming into my room without permission."
    b "It's my personal space, and I expect it to be respected."
    p "Oh, come on, Banu. I've been in this room countless times, and I don't see why I can't go wherever I want."
    b "Polad, just because we're close doesn't mean you can disregard my boundaries. Every individual deserves privacy and respect, regardless of their relationship with you."
    scene v15-282
    p "Well, I'm sorry if I offended you, but it's not a big deal. You're overreacting."
    b "No, I'm not overreacting. It's about basic decency and respect. I have the right to feel comfortable and secure in my own room."
    p "Look, Banu, this is my house. I make the rules here. If you have a problem with that, maybe you should find another place to stay."
    b "Polad, just because this is your house doesn't mean you can trample over other people's boundaries."
    scene v15-283
    p "I see you don't understand me. This is my house, and I have my own way of doing things."
    b "Fine, Polad. I understand that this is your house and you have your own rules. I'll try my best to abide by them."
    p "That's more like it, Banu. It's important to establish some discipline and order around here. "
    p "You'll see, it'll make everything run smoother."
    scene v15-284
    b "I hope so."
    "Banu couldn't help but feel a sense of resignation as she reluctantly agreed to Polad's terms."
    "The situation left her feeling trapped, with no other immediate options. She knew that challenging Polad further would only escalate the tension and strain their relationship further."
    "Deep down, Banu knew that compromising her own comfort and happiness wasn't a sustainable solution."
    "She realized that she would need to muster the strength and determination to explore other options and find a way to establish her own sense of security and well-being."
    if banuagreetostayatclub == True:
        p "I can't believe the last time you came home late again! I've told you numerous times that I don't tolerate latecomers in my house. This is unacceptable!"
        b "I'm sorry, Polad. There was unexpected traffic, and I got caught up in a meeting. I didn't mean to disregard your rules."
        p "I don't want to hear your excuses, Banu. You should have planned better and made sure to be home on time. I won't tolerate this kind of behavior under my roof."
        b "I understand your frustration, Polad, but sometimes circumstances are beyond our control. I always try my best to be punctual, but there are occasions where things don't go as planned."
        p "I don't care about your explanations! You need to prioritize being on time. It's disrespectful to me and to the rules I've set in my house."
        b "I don't want to create further conflict, Polad. I'll do my best to be more mindful of my timing. Just know that I'm doing my best, and I appreciate your understanding when situations like this arise."
        p "Well, make sure it doesn't happen again. I don't want to have this conversation in the future."
        b "I'll try my best, Polad."



    show black with Dissolve(3)
    ""
    centered "{size=+120}A mistake{/size}" with Fade(0.5, 0.5, 5)
    scene v15-302 with Fade(0.5, 0.5, 5)
    play music "audio/action.mp3"
    "In a dimly lit backroom of the mafia headquarters, Vladimir, a burly and vigilant man, stands against the wall, his eyes scanning the room for any potential threats."
    "Hicran nervously shifts her weight from one foot to another, while Faiq, an imposing figure with a cold stare, stands nearby observing the scene."
    "Kenan, a seasoned member of the organization, leans against the wall."
    scene v15-303
    hic "Vladimir, I swear I had nothing to do with it."
    hic "I've been a loyal courier for years. I would never jeopardize the Boss's trust."
    f "That's easy for you to say, Hicran. We're talking about a valuable shipment here. "
    f "You can't expect us to just take your word for it."
    scene v15-304
    hic "Faiq, you know me. You know I've always been reliable."
    hic "Something must have happened along the way, but I swear I had no involvement."
    scene v15-305
    v "Hicran, listen carefully. The Boss won't take kindly to someone hiding the truth, especially when it concerns something as valuable as our missing shipment."
    v "You better start telling me the truth, or I can't guarantee what will happen next."
    hic "Vlad, I swear I don't know what happened to the shipment. I've been loyal to the Boss and this organization from the beginning. I would never betray him."
    v "You expect me to believe that, Hicran? The Boss entrusted you with this task, and now it's gone."
    v "If you don't come clean right now, I'll make sure the Boss hears about your involvement."
    hic "Vladimir, please understand. I've risked my life countless times for this organization. I have no reason to sabotage the shipment."
    v "Hicran, you're hiding something, and I won't tolerate it any longer."
    scene v15-306
    hic "Vladimir, I...it was... it was Kenan's fault. He messed up the plan. He didn't secure the shipment properly, and that's why it went missing."
    ken "Hold on, Hicran. I can't believe you're accusing me. I've been with you every step of the way, assisting you in your duties."
    ken "I've never shown any signs of disloyalty, and now you're throwing baseless accusations at me?"
    scene v15-307
    hic "Baseless accusations? Don't act innocent, Kenan! I saw you snooping around where the valuables were kept."
    hic "You've been disappearing without explanation, and suddenly things go missing. It doesn't take a genius to put the pieces together!"
    scene v15-308
    ken "And it doesn't take a genius to see that you're deflecting blame onto me because you're the guilty one!"
    ken "I trusted you, Hicran. We've worked together for years, and now you're turning against me? I would never jeopardize our lives and the organization like that!"
    v "Enough! Both of you calm down."
    scene v15-309
    v "Hicran's accusations against you are serious, Kenan. I must admit, your recent behavior and access to the valuables raise suspicion. You need to provide a solid explanation to defend yourself."
    ken "Vladimir, I understand your concerns, but I am innocent."
    ken "I have no motive to steal from our own ranks. Hicran is trying to divert attention from herself."
    f "Vladimir, I've been observing Kenan closely. His actions and demeanor have been questionable lately."
    f "I've seen him engaging in secret conversations and acting secretive about his whereabouts. It's worth investigating him thoroughly."
    scene v15-310 with hpunch
    ken "Hey, what are you doing?"
    ken "Vlad...please don't do this."
    v "I've been suspecting you for a while now."
    v "I think you deserve this, little worm."
    scene v15-311 with hpunch
    ken "Argggg..."
    f "How's this Kenan. Did you remember anything?"
    scene v15-312 with hpunch
    ken "Arggggg..."
    f "Damn...you hit him so hard Vlad."
    scene v15-313 with fade
    hic "Vladimir, Faiq, please, let's take a step back."
    hic "If this goes on, you'll kill him."
    hic "Can't we find another way to resolve this without resorting to violence?"
    v "Do you feel pity for him? You were the one accusing him."
    scene v15-314
    v "Besides, do we need someone who steals from us, Faiq?"
    f "I see where you're going, Vlad."
    scene v15-315
    hic "Please, stop it...you're choking him!"
    v "Someone have to die, Hicran. This will be either you or him."
    v "You don't want to die, do you?"
    hic "..."
    scene v15-316 with fade
    hic "Oh no! Kenan! "
    f "Don't worry about him. He doesn't feel pain anymore."
    hic "Oh my god! Did you kill him?"
    scene v15-317
    v "Well, what did you expect?"
    f "You're the reason of his death, Hicran."
    f "Do you feel guilty?"
    v "We know that this was your fault not his."
    v "But somebody had to be dead and it was him."
    v "You're a luck one but we know that you betrayed us like you betrayed Kenan just a few minutes ago."
    v "We won't let this slide. You'll pay for your betrayal."
    scene v15-318
    v "Revenge is not something we take lightly. "
    v "But for you we'll make it more enjoyable."
    hic "What do you mean?"
    v "This was a stressful day and our dicks are stiff. You know what I mean."
    hic "No...we can't do that here..."
    stop music

    scene black with dissolve
    ""
    scene v15-285 with pushright
    "Banu stands outside Hicran's house, anticipation building as she waits for someone to answer the door."
    "She nervously adjusts her clothes, feeling a mix of excitement and curiosity about the conversation she plans to have with her best friend."
    "The seconds feel longer as she patiently looks at the closed door, wondering who will greet her on the other side."
    scene v15-286 with fade
    mah "Good afternoon! Oh it's you, Banu? Please come in, make yourself comfortable."
    b "Good afternoon. Thank you for your hospitality ... oh I'm sorry I forgot your name..."
    mah "My name's Mahmud."
    b "Oh yeah...nice."
    mah "You're most welcome, Banu. I must apologize for the confusion, but Hicran is not at home right now."
    b "Oh, really? I thought she would be here."
    mah "I'm sorry for any inconvenience caused. Hicran had some unexpected errands to run, and I wasn't informed of your visit. Nevertheless, please come inside and wait for her if you'd like."
    b "I appreciate the offer, Mahmud, but if Hicran is not here, I don't want to intrude. I can come back another time when she's available."
    mah "It's no intrusion at all, Banu. I insist you come in and wait. Perhaps Hicran will return soon."
    b "Well, if you're sure it's not a problem, then I suppose I can wait for a little while. Thank you for your understanding."
    scene v15-287
    "As Banu finds herself alone in the room with Mahmud, a sense of uneasiness and discomfort settles upon her. "
    "She becomes increasingly aware of Mahmud's presence and finds herself on guard, unsure of his intentions or the direction the conversation might take."
    "Banu's mind races with thoughts and concerns, wondering why Hicran isn't there and questioning the circumstances that led to her being alone with Mahmud."
    scene v15-288
    mah "Please, have a seat, Banu. Make yourself comfortable."
    b "Thank you, Mahmud."
    scene v15-289
    mah "Why don't you join me on the sofa, Banu? It'll be more comfortable for both of us."
    b "Oh, no, I'm fine right here. Thank you, Mahmud."

    scene v15-290
    mah "Why don't you join me on the sofa, Banu? We can have a more intimate conversation that way."
    b "I appreciate the offer, Mahmud, but I'm fine here. I prefer to stay where I am."
    mah "Come now, Banu. Let's get to know each other better. Sit here with me. I won't bite."
    b "Well, if you insist..."
    scene v15-291
    "As Banu reluctantly sits on the sofa next to Mahmud, her unease becomes more apparent. She keeps her posture guarded, avoiding direct eye contact, and remaining vigilant throughout the conversation."
    mah "So, Banu, tell me about your family. I'm curious to know more about your background."
    scene v15-292
    b "Well, Mahmud, to be honest, I don't have much information about my biological family."
    b "I grew up in an orphanage, so I never had the chance to meet my real parents."
    mah "Oh, I see. That must have been quite challenging for you. Do you ever feel the need to search for them or learn more about your roots?"
    b "It's something I've thought about from time to time, Mahmud. However, I've come to accept that my real family may always remain a mystery to me."
    b "I've found a sense of belonging and family among my close friends and loved ones instead."
    mah "Would you like to meet your real mother one day? I'm sure you look like her."
    b "Mahmud, I appreciate your interest, but I'm here today to see Hicran. I'm sure she'll be back soon, and we can catch up properly."
    mah "Of course, Banu. Hicran will be back in due time. I apologize if I made you uncomfortable."
    scene v15-293
    play music "audio/tension.mp3"
    mah "Banu, have you ever wondered about the secrets that lie within reflections?"
    mah "Mirrors have a way of revealing hidden truths, don't you think?"
    b "What do you mean?"
    mah "You see, Banu, there are connections that go beyond what meets the eye. Sometimes, the face that stares back at us holds secrets and memories we may have long forgotten."
    "Banu's heart skips a beat as Mahmud's words hang in the air. She feels a chill run down her spine, her mind racing to comprehend the weight of his statement."
    b "W-what are you trying to say, Mahmud?"
    mah "Banu, your face... It holds a striking resemblance to someone I once knew, someone from a distant past. Your features, your eyes, they bring back memories that I thought were lost forever."
    b "Mahmud, what are you talking about? Who is this person you're referring to?"
    scene v15-294
    mah "Banu, your real mother... she was a dear friend of mine. We shared a bond that time could not erase. Seeing you now, it's as if she's standing before me once more."
    "Banu's mind races as she tries to process the revelation. The shock and confusion grip her, causing her to sit in stunned silence. The room feels heavy with the weight of Mahmud's words."
    scene v15-295
    b "My real mother... You knew her?"
    mah "Yes, Banu. We crossed paths many years ago, under circumstances that were both extraordinary and heartbreaking."
    mah "I had lost touch with her over time, but the moment I laid eyes on you, I recognized her in you. It was an unmistakable resemblance."
    "Banu's emotions are in turmoil as memories, questions, and a sense of longing flood her thoughts. She never expected to uncover such a profound connection in this unexpected visit to Hicran's home."
    scene v15-296
    b "You knew it for the first time you saw me? Mahmud, why did you keep this from me? Why didn't you tell me sooner?"
    mah "Banu, it was not my place to reveal the truth. I had my reasons, and I thought it was best for you to discover it in your own time, on your own terms."
    "Banu's eyes well up with tears, a mix of confusion, anger, and a longing for answers. The air in the room feels heavy, the atmosphere filled with an unspoken tension."
    mah "Banu, I must warn you, the truth about your mother is not an easy one to bear."

    scene v15-297
    mah "She was not a conventional woman. Her life was filled with shadows, with choices that may seem questionable or even unsavory."
    mah "Banu, I understand that this may be difficult to hear, but the truth is that your mother was involved in a profession that many might consider unconventional. She worked as a sex worker."
    scene v15-298
    b "No! That can't be true!"
    "Banu's face flushes with anger and frustration. She feels a deep sense of betrayal, as if Mahmud's words have tarnished her mother's memory."
    scene v15-299
    mah "Banu, I understand that this revelation may be hard to accept. But I speak the truth out of respect for your mother's story."
    mah "She faced circumstances that forced her into this line of work, and it's important to acknowledge and honor her journey, regardless of society's judgments."
    scene v15-300
    b "How dare you make such claims about her!"
    b "I don't believe a single word you've said, Mahmud! You've already shattered my trust with your claims about my mother. I won't listen to any more of your lies!"
    scene v15-301
    stop music
    "Banu makes a move towards the door, determined to leave and distance herself from Mahmud and his unsettling revelations."
    mah "Banu, please wait! Before you go, there's something else I need to tell you."
    b "What more could you possibly have to say? You've already told me things that I find hard to believe. Why should I listen to you any longer?"
    mah "I understand your doubt, Banu. But what if I told you that your mother is alive? I can help you find her if you're willing to listen."
    "Banu's eyes widen in surprise, conflicting emotions washing over her. The anger begins to wane, replaced by a glimmer of hope."
    "Banu turns away from Mahmud, her face filled with a mix of anger, disappointment, and confusion. She makes her way towards the door, her steps heavy with unresolved emotions."

    scene black with dissolve
    ""
    jump hicran_vladimir_sex
label hicran_vladimir_sex_continue:




    scene black with Dissolve(3)
    ""

    $ banugotomuratsapartmentafterfun = False
    $ banuagreebowlingmurat = False
    $ borrowmoneyfrompolad = False
    $ banuflirtwithpoladinthelivingroom = False
    $ banuundressedinfrontofboss = False
    $ banusitnexttopolad = False

    centered "{size=+120}Murat{/size}" with Fade(0.5, 0.5, 5)
    scene v16-120 with blinds
    play music "audio/kometaback.mp3"
    "Banu, clad in her pink sportswear, took a solitary stroll through the sunlit city streets. The warm rays of sunlight cascaded down, casting a golden hue on her surroundings."
    "Despite the pleasant weather, her mind was clouded with thoughts, burdened by stress and a sense of loneliness."
    "As she walked along the bustling sidewalks, the sounds of city life enveloped her."
    "Conversations melded into an indistinguishable buzz, while the distant honking of cars echoed in the distance. The vibrant cityscape seemed to carry on with its rhythm, oblivious to Banu's inner turmoil."
    scene v16-121 with wipeleft
    "At the same time, about half a mile away from Banu, Murat was strolling through the city streets with his palpable vibrant energy."
    "A smile adorned his face, radiating positivity to those around him."
    "The sun's warm rays seemed to reflect his cheerful disposition, illuminating the path he traversed."
    scene v16-122 with wiperight
    "While Banu's face seemed to bear the weight of her worries..."
    scene v16-123 with wipeleft
    "Murat's face reflected an inner lightness, an unwavering positivity that he carried with him."
    scene v16-122 with wiperight
    "Banu's sad face, subdued and introspective, seemed to blend into the background of the bustling city, almost unnoticed amidst the vibrant colors and lively energy."
    scene v16-123 with wipeleft
    "Meanwhile, Murat's vibrant face drew attention, attracting the gazes of passersby, who couldn't help but be captivated by his infectious enthusiasm."
    scene v16-124 with fade
    "As Banu continued her lonely walk through the city, lost in her thoughts and weighed down by her emotions, her eyes suddenly met with a familiar face in the distance."
    "It was Murat, walking towards her with his characteristic smile and a twinkle in his eyes."
    "Banu's sad face, momentarily interrupted by the sight of Murat, softened with a flicker of recognition."
    "The corners of her mouth lifted slightly, reflecting a glimmer of hope amidst her troubled state. Her eyes, once clouded with sadness, now held a trace of warmth as they locked onto Murat's."
    scene v16-125
    "Murat, his energetic stride never faltering, approached Banu with an enthusiastic greeting."
    mur "Hey, Banu! Fancy running into you here. How's it going?"
    "Banu, surprised by the unexpected encounter, couldn't help but feel a sense of comfort in Murat's presence."
    b "Oh, Murat. It's been a tough day, but seeing you brings a little light to it. How about you? How's life treating you?"
    mur "I'm sorry to hear that, Banu. Life's been treating me well, but knowing you're having a rough time makes me want to offer support."
    mur "If you ever need someone to talk to or simply want a listening ear, count on me."
    scene v16-126
    b "You know, Murat, I have to admit something. You're really good with women."
    mur "Oh, really? Well, thank you, Banu. "
    b "You have this way of making people feel comfortable and appreciated. I've seen how effortlessly you connect with others, especially women. It's a gift."
    mur "I appreciate your kind words, Banu. "
    mur "But let's not forget, you have your own special qualities that draw people towards you as well."
    b "So, Murat, am I special to you? Or am I just another face in the crowd?"
    scene v16-127
    mur "Banu, you know you're more than just another face in the crowd. "
    b "Oh, really? And what makes me so special, Mr. Smooth Talker?"
    mur "Well, for starters, you have this unique ability to light up a room with your presence. "
    mur "Your warmth and genuine nature make people feel comfortable and valued. And your sense of humor always brings a smile to my face."
    mur "Hey, Banu, I was thinking it would be fun to grab a coffee and go bowling together. What do you say?"
    stop music
    menu:
        "Banu rejects":
            $ renpy.block_rollback()
            $ banuagreebowlingmurat = False
            scene v16-126
            b "Hmm, that does sound like fun, Murat. But I have to be honest with you. I can't help but feel a bit skeptical about your intentions."
            mur "Why that? I simply thought it would be enjoyable to spend some time together."
            b "Come on, I know your intention is not just to play bowling. I have noticed the way you look at me, and it makes me feel uncomfortable. Plus, I'm married, and I want to honor my commitment to my husband."
            scene v16-127
            mur "You're the way smarter than I expected. Just keep in mind that if you need support or bored, you have my number and I'm always here for you."
            b "Thank you again, Murat. I'll keep it in mind."
        "Banu agrees":

            $ renpy.block_rollback()
            $ banuagreebowlingmurat = True
            scene v16-126
            play music "audio/chill.mp3"
            b "I just want to let you know that I don't trust you because you're a man."
            b "But honestly, I'm quite bored, so I guess I'll give it a shot."
            scene v16-127
            mur "I understand if you're hesitant, but I promise to respect your choices."
            scene v16-126
            b "Alright, Murat. I'll take your word for it, but I want to be clear that this is strictly as friends. If at any point I feel uncomfortable or sense any inappropriate behavior, I'll have to end our outing."
            mur "Let's just have a good time and enjoy each other's company."
            b "..."
            scene v16-133 with pixellate
            "Banu and Murat found themselves seated at a cozy coffee table in the vibrant atmosphere of the bowling club. "
            "The sound of rolling balls and jubilant cheers filled the air, adding to the excitement that surrounded them."
            "As they settled in, the conversation flowed effortlessly, and Banu couldn't help but find herself genuinely enjoying Murat's company."
            mur "Hey, Banu, did you know that I have a black belt in bowling? They call me the Strike Ninja!"
            b "Strike Ninja? That's a new one! So, should I be worried about any karate moves with that bowling ball of yours?"
            mur "Watch out! I might just unleash my secret bowling technique - the unstoppable Flying Strike Kick!"
            b "Oh, please! I can't even imagine what that would look like. But I must admit, you have a way of turning bowling into a martial art!"
            mur "Well, you know what they say, Banu - the key to a perfect strike is a strong mind, a steady hand, and a killer sense of humor!"
            scene v16-134
            b "Well, you definitely have the humor part covered, Murat. You always manage to bring a smile to my face, even in the midst of a tense situation!"
            mur "That's the goal, Banu. Laughter is the secret ingredient that makes everything better. Besides, what's a game of bowling without a few good jokes and shared laughter?"
            b "You're absolutely right, Murat. Life should be filled with moments of joy and lightness, even in the simplest things like bowling. Thanks for reminding me to embrace the fun and laughter."
            scene v16-133
            mur "Come on, Banu! Let's start bowling already. It's going to be so much fun!"
            scene v16-134
            b "I have to be honest, Murat. I'm not really good at bowling. I don't want to embarrass myself."
            mur "Nonsense, Banu! Bowling is all about having a good time. Trust me, you'll get the hang of it in no time. Plus, I'll be right there to guide you through it."
            b "I appreciate your confidence in me, Murat. But I'm not sure if I can do it."
            mur "Come on, Banu..."
            scene v16-135 with fade
            b "Heyyy, okay I'm coming."
            mur "We'll figure it out together. Don't worry about being perfect. Let's just have fun and enjoy the experience."
            b "Okay, okay! I'm going, but you better be ready to witness my terrible bowling skills."
            scene v16-136
            mur "I can't wait to see what you've got, Banu! I have a feeling you'll surprise yourself."
            b "Alright, Murat, here I go. Any last-minute tips?"
            mur "You've got this, Banu! Just take a deep breath, aim for the middle pin, and give it a nice, smooth roll. Remember, it's all about finding your rhythm."
            b "Okay, I'll give it my best shot!"
            scene v16-137
            "Banu stepped forward to the edge of the lane, her focus intensifying. With a determined expression, she swung her arm back and gracefully released the ball. It glided down the lane, steadily rolling towards the pins."
            mur "Looking good, Banu! Keep going!"
            "The ball approached the pins, and with a satisfying thud, it knocked down several of them, leaving a scattered arrangement. Banu's eyes widened, and a mixture of surprise and delight spread across her face."
            scene v16-138 with fade
            b "I did it! I actually hit some pins!"
            mur "That was fantastic, Banu! You're a natural. See? I told you that you could do it!"
            b "Alright, Murat, it's your turn now. Show me what you've got! I bet you can't knock down all the pins in one shot."
            mur "Oh, Banu, you're underestimating my bowling skills. I'm so sure I'll get a strike that I'm willing to bet on it!"
            b "Really? You're that confident, huh? Alright, let's see what you've got. But don't be surprised when you don't get all the pins."
            scene v16-139
            "Murat positioned himself at the edge of the lane, holding the bowling ball in his hands. He took a deep breath, focusing his gaze on the pins ahead."
            mur "Watch closely, Banu. This one's for the skeptics!"
            "With a swift motion, Murat released the ball, sending it gliding down the lane with precision."
            "As if guided by an invisible force, the ball curved just at the right moment, striking the pins with a satisfying crash."
            scene v16-140
            b "No way! You actually got them all! I can't believe it!"
            mur "Told you, Banu! Never underestimate the power of a little confidence. Looks like I owe you a victory dance!"
            b "Fine, fine. You win this time, Mr. Bowling Champion. But let's see if you can keep up that perfect score throughout the game!"
            "Their playful banter continued as they completed their game, exchanging laughter and friendly competition. Murat's strike had left Banu in awe, but it only fueled her determination to improve her own skills."
            scene v16-141 with fade
            "As Banu and Murat continued playing their game of bowling, the atmosphere filled with excitement and laughter."
            "The joy they found in each other's company became evident as their friendship deepened through shared moments of triumph and lighthearted banter."
            "With each successful shot and strike, their connection grew stronger. Banu couldn't help but feel a sense of comfort and ease whenever she was around Murat, and the same sentiment seemed to hold true for him."
            "In a moment of exhilaration, Murat couldn't contain his excitement any longer."
            "As Banu celebrated another well-earned strike, he playfully and instinctively wrapped his arms around her from behind, pulling her into a warm, spontaneous embrace."
            b "Well, someone's feeling quite victorious, aren't they? I didn't know hugging was part of the bowling game!"
            mur "I couldn't help it, Banu! You're just too amazing at this. The thrill got the best of me!"
            b "Well, Mr. Hugger, be prepared for some tough competition. I won't let you win so easily!"
            mur "Oh, it's on, Banu! You better bring your A-game because I won't go easy on you!"
            "..."
            scene v16-128 with fade
            "After an exhilarating game of bowling, Murat couldn't contain his infectious energy and mischievous spirit. Holding Banu's hand tightly, he led her on a playful and joyous run through the city streets."
            "Banu, her face glowing with laughter and excitement, gladly followed along, fully immersed in the moment."
            "As they dashed through the bustling city, their laughter echoed in the air, catching the attention of passersby who couldn't help but smile at their infectious enthusiasm."
            "Banu's tired legs were evidence of their adventure, but her spirit remained uplifted and energized."
            scene v16-129
            mur "Come on, Banu! Just a little bit farther. I have a surprise for you!"
            b "You really know how to keep the fun going, don't you? I don't even know where we're headed, but I'm loving every moment!"
            "Their laughter intertwined with the rhythm of their footsteps as they navigated the winding streets, their destination looming ahead. Banu's heart raced with anticipation, wondering what surprise awaited her at the end of their spirited journey."
            scene v16-130 with hpunch
            "In a spontaneous burst of joy, Murat playfully grabbed hold of both of Banu's hands. With a mischievous smile, he began to twirl her around, gently spinning her in a circle."
            "Banu's laughter filled the air as her head spun with a delightful mixture of dizziness and excitement."
            b "Murat, what are you doing? You're going to make me dizzy!"
            mur "Just a little fun, Banu! Let's keep the laughter going and see if we can make the world spin!"
            "As Murat continued to twirl Banu, the world around them blurred, their laughter intermingling with the sounds of the bustling city. In that moment, time seemed to stand still as they embraced the pure joy of the present."
            b "Okay, Murat, you win! My head is spinning, but it's the best kind of dizzy. You really know how to make me smile!"
            scene v16-131
            "Banu, I have an idea. Why don't you come up to my apartment? I want you to be my guest, just for a little while. We can continue our fun and laughter in a more comfortable setting."
            "Oh... um, Murat, I appreciate the invitation, but I'm not sure. We've had a great time so far, but I'm not sure if going to your apartment is the right thing to do."
            mur "Banu, please reconsider. I genuinely enjoy your company."
            stop music
            menu:
                "Reject him":
                    $ renpy.block_rollback()
                    $ banugotomuratsapartmentafterfun = False
                    scene v16-132
                    b "Murat, I appreciate your persistence, but I know what accepting this invitation would imply. As a married woman, it wouldn't be appropriate for me to go to your apartment alone."
                    mur "Banu, let's forget about everything else for a moment. Come to my apartment and let's just have fun together. No worries, no obligations, just a chance to enjoy each other's company."
                    b "Murat, I can't do that. I appreciate your invitation, but I am a married woman, and it wouldn't be right for me to disregard my commitment to my husband."
                    b "I value our friendship, but I must prioritize my marriage and the trust that exists within it."
                "Go with him":



                    $ renpy.block_rollback()
                    $ banugotomuratsapartmentafterfun = True

                    jump muratfucksbanuafterfunsexscenestaywithkamil_breakup

                    scene v16-132
                    b "Murat, I can't believe I'm agreeing to this, but okay. Just 5 minutes, and then I need to leave. No longer than that, okay?"
                    mur "Deal! I promise you won't regret it. Let's go!"
                    scene black with dissolve
                    "..."
                    scene v16-142 with dissolve
                    b "Wait...you're such a liar, Murat."
                    b "....mmmmp.."
                    mur "Your lips taste so good. I can kiss you all day."
                    b "You're going to choke me, maniac."
                    b "Is it your fisrt time kissing?"
                    mur "You're driving me crazy, Banu. I can't control myself with you."
                    scene v16-143 with fade
                    b "Mmmp...oh god...stop touching me there...ohh."
                    mur "You like this, don't you?"
                    b "We didn't agree on taking the clothes off, did we?"
                    scene v16-144 with fade
                    mur "Shhhh...just enjoy the moment. "
                    b "Your dick....it's touching me..."
                    mur "Damn Banu, you're kissing me so passionately. You must be craving this all the time you've been with me."
                    scene v16-145
                    b "Ahhh...you know what I need..."
                    b "Right there...ahhhh.."
                    b "Ummmmm...You got me so wet you tricky boy."
                    scene v16-146
                    "Murat was bending Banu backwards slightly and she was grabbing his neck not to fall off."
                    "Using the opportunity, Murat started rubbing Banu's pussy furiously and talking dirty to her making her crazy."
                    b "Ahhhhh...stop it...please, ahhh."
                    mur "I'll make you feel so good that your husband never done that to you."
                    mur "I'm going to make you feel like a real woman today. You'll scream and beg but I won't stop..."
                    scene v16-147 with fade
                    "After minutes Murat grabbed Banu taking her pants and bra off and sat on the sofa holding her on top of him. "
                    "While invading her mouth, Murat run his hands all over Banu's body, caressing her thighs, belly and breasts. "
                    "At this point, Banu could't help but reached her pussy with her hand stimulating her left out clit."
                    scene v16-148
                    b "Shit, I can't bear it anymore...Murat, please..."
                    mur "Tell me. What you want me to do?"
                    b "Please, make me feel good."
                    mur "You want my cock, don't you?"
                    b "My pussy is so wet now. I'm going to cum from your touches."
                    b "Please, take my pussy. Make me yours!"
                    scene v16-149 with hpunch
                    b "Ahhh...yeah like that.."
                    mur "You're such a lewd slutty wife, aren't you?"
                    b "Yesss, I'm a despicable, bad wife who needs a good punishment."
                    b "Call me whatever you want. I deserve that."
                    mur "You're a bad bitch enjoying my fingers deep inside of your married cunt. "
                    b "Ohhh...I can't take it anymore...I'm going to cummm....."
                    scene v16-150
                    mur "Look how slutty you are. You're cumming from a young man at your children's age fingering your pussy."
                    b "Please, stop it..."
                    b "Damn, you're so good at this. Fuck..."
                    b "I've never let my husband touch me like that."
                    mur "Go on, cum for me. I'm going to tease all of your slutty holes."
                    mur "I'm going to tease the shit out of you. You'll beg me to fuck all of your holes."
                    mur "Have you ever got your asshole fucked?"
                    scene v16-151 with vpunch
                    b "No! Don't touch me there. I warn you!"
                    mur "What? You're rejecting me?"
                    b "Shit, I'm serious, Murat. I've never let a man touch me there."
                    "Banu squeezed her legs so hard to prevent Murat teasing her asshole with his middle finger. "
                    scene v16-152 with fade
                    b "Ahhh..."
                    b "You're crazy...what are you doing?"
                    mur "You see? I'm full of surprises."
                    scene v16-153
                    mur "Mmmm...it's so delicious. Do you like it?"
                    b "Ohhh shit...stop it...it's so dirty..."
                    b "Oh god...you're hitting my spot."
                    b "You're eating it like your favorite breakfast...ufff.."
                    mur "Mmmm..this is my favorite meal of the day."
                    b "Oh my God...if you keep doing that....I won't be able to stop cumming."
                    mur "Don't hold it. Cum all over my mouth. "
                    b "Shit, you're so good with your tongue."
                    mur "Are you ready for the main course?"
                    scene v16-154 with fade
                    "Murat suddenly raised Banu's legs and put his dick on top of her pussy grinding it back and forth."
                    mur "You want this, don't you?"
                    b "Stop teasing me, please..."
                    mur "Shut up!"
                    mur "Tell me how you want it."
                    scene v16-155
                    b "I want it inside of me..."
                    "Murat continued teasing Banu's wet pussy with his fully erect curvy dick making her crazy."
                    mur "I want you to ask it properly."
                    b "Oh god...you're making me crazy..."
                    b "Put that fucking dick inside of me!"
                    mur "Tell me how bad you want it."
                    b "I want it so bad...please, my pussy aches for your big curvy dick."
                    b "Put it inside of my married unsatisfied pussy."
                    b "Fuck the shit out of me..."
                    scene v16-156 with hpunch
                    b "Ahhh..."
                    mur "That's it. I'm not gonna make you suffer any longer."
                    show muratfuckbanuafterfunanimation
                    b "Fuck!...This feels so good..."
                    mur "I know what you want, baby."
                    mur "My dick fits so good inside of your wet pussy."
                    mur "Your pussy is just made for my cock."

                    show muratfuckbanuafterfunanimationangle
                    b "Ohh fuck me...keep fucking me like that."
                    mur "Your husband is weak man probably. Leaving a pussy unsatisfied like this huh?"
                    b "Please, ahhh, stop talking about him..."
                    b "Keep fucking me like that, ahhh.."

                    show muratfuckbanuafterfunanimationfast
                    b "Ohhhh shit..."
                    b "It's hitting me so bad..."
                    mur "Fuck...your pussy squeezes my cock so hard."

                    show muratfuckbanuafterfunanimationanglefast
                    b "Oh my god, keep fucking me like that...ahhh..."
                    b "Your cock reaches my stomach...ohhh shit.."
                    mur "I'm going to destroy belly..."
                    mur "I can't believe you gave a birth from this pussy. It's so tight."
                    b "Fuck....I'm cumming....shit...."
                    scene v16-157 with hpunch
                    b "Shit...that was so intense."
                    mur "Your face tells it all."
                    b "You're the devil."
                    mur "I'm glad you liked that...but it's not over yet."
                    scene v16-158
                    mur "I have an idea. How about we try something new together?"
                    b "Wait..what?"
                    mur "It's something you've never done before, and I think it could be a fun and memorable experience."
                    b "No!...no way..."
                    scene v16-159
                    mur "But why not trying?"
                    b "I'm sorry, but I can't do that. It's just not something I'm comfortable with or ready for."
                    mur "Let's give it a try, just this once. I'm sure you'll love it."
                    scene v16-160
                    b "No I can't do that. I'm not comfortable with this you know."
                    mur "How do you know if you haven't tried it?"
                    b "Please, don't push me. I'm afraid of that."
                    scene v16-161
                    b "Heyyyy...stop it!"
                    mur "I promise you, it won't be painful."
                    mur "I'll make sure you're comfortable and at ease throughout the experience."
                    scene v16-162
                    b "I just said stop it! What are you doing?"
                    b "I can't do this!"
                    mur "Shhhh...your ass will love it."
                    scene v16-163
                    b "Ahhhhhhhh...Ay mama....it hurts...stop it!"
                    mur "Shhhh, I'll lubricate it good that you'll only feel the pleasure."
                    scene v16-164
                    b "Ahhhhhh..."
                    mur "That's it..."
                    b "It hurts so bad, please pull it out! Ahhhhh.."
                    mur "Don't worry. Your ass will get used to it."
                    show sex
                    b "Shit...Ahhhh..."
                    b "It destroyes my ass."
                    mur "You seem to like it."
                    show sexangle
                    b "Ohh yeah, don't stop...keep fucking my dirty asshole..."
                    mur "Your asshole is so tight. It squeezes my dick like hell."
                    mur "But I'll stretch it a bit more."
                    show sexfast
                    b "Ahhhhhh....yesss...pound my ass like that..."
                    b "Shit, I can't hold it. I'm going to pee."

                    show sexanglefast
                    mur "Your asshole belonges to me now. "
                    mur "I'll stretch it whenever I want."

                    scene v16-165 with fade
                    "Murat fucked Banu for hours in the ass hitting deep inside her with his long curvy dick."
                    "Banu's initial pain was replaced by a mixture of pleasure and pain afterwards giving her the best pleasure in her life. "
                    scene v16-166
                    "At this point, she couldn't stop her eyes rolling back and moaning like a whore while accepting full length of Murat's swollen cock from her back door. "
                    b "Ahhhh, it's hitting me right there..."
                    scene v16-167
                    b "Keep fucking me like that. Don't dare to pull it out now."
                    b "Oh my god...I can't hold it any longer...."
                    b "Shit, if you keep fucking..."
                    scene v16-168 with vpunch
                    b "Oohhhhhh...."
                    b "Damn...I'm..."
                    mur "Fuck, look at that."
                    scene v16-169
                    b "Fuck...I'm so sorry...It was just..."
                    mur "It's okay, Banu. You just enjoyed it a bit too much."
                    b "I'm really sorry...it was just an accident."
                    scene v16-170 with hpunch
                    "Murat looked deeply into Banu's eyes, a glimmer of excitement and anticipation in his gaze."
                    b "Murat, I have to go. It's late."
                    mur "For the next few hours, I want us to have an incredible time together."
                    b "But I really can't stay."
                    mur "We're having such a great time together, and I don't want it to end so soon."
                    mur "You belong to me for the next hours."
                    "Banu couldn't say a word as she felt Murat's dick in the enterance of her asshole again."
                    "It was too late to reject Murat again..."


label muratfucksbanuafterfunsexscenestaywithkamil_continue_breakup:

    scene black with Dissolve(3)
    ""
    centered "{size=+120}A new day{/size}" with Fade(0.5, 0.5, 5)
    scene v16-205 with squares
    "Banu slowly stirred from her sleep, her eyelids fluttering open to reveal a dimly lit room."
    "The early morning light filtered through the curtains, casting a soft glow in the room. But instead of feeling comforted by its warmth, she felt a pang of anxiety weighing on her mind."
    "The events of the past few months had taken their toll on Banu. Not only had she ended a long-term relationship, but she had also lost her job recently."
    scene v16-206 with fade
    "Banu sat on the edge of the bed, her mind preoccupied with the pressing need for money."
    "She knew she had limited options, and two names floated to the surface of her thoughts—Polad and Hicran."
    scene v16-207
    "Polad, a close face in her life and the person who had graciously provided her a place to stay, seemed like an obvious choice."
    "But Banu couldn't shake off the hesitation that accompanied the idea of asking him for financial assistance."
    "She knew Polad would undoubtedly question her about her reasons for needing the money."
    "It wasn't that she doubted his generosity or concern for her well-being, but Banu felt a mix of pride and vulnerability that made it difficult for her to openly admit her struggles."
    scene v16-208 with fade
    "Then there was Hicran, her trusted female friend who had always been there for her."
    "Hicran had a kind and empathetic nature, and Banu felt that she could confide in her without fear of judgment."
    "They had shared many secrets and supported each other through various challenges over the years."
    scene v16-209 with fade
    "Banu dressed in a knee-length, bright and shiny dress that caught the light in a cascade of colors."
    "The dress hugged her figure gently, accentuating her curves while allowing her to move with grace and comfort."
    "Completing her ensemble, Banu carefully wrapped a grey, elegant hijab around her head. "
    "The soft fabric cascaded down her shoulders, framing her face with a touch of modesty and sophistication."
    menu:
        "Borrow money from Polad":
            $ borrowmoneyfrompolad = True
            $ renpy.block_rollback()
            "After careful consideration, Banu made up her mind. She would approach Polad and ask him for the financial assistance she needed."
            "Despite her reservations about discussing her struggles, she knew that Polad had always been a supportive and understanding friend."
        "Borrow money from Hicran":




            $ borrowmoneyfrompolad = False
            $ renpy.block_rollback()
            "After careful consideration, Banu made up her mind. She would approach Hicran, her trusted female friend, and ask for the financial assistance she needed."
            "She knew that Hicran possessed a compassionate and understanding nature, making her the ideal person to confide in during this challenging time."



    scene v16-210
    "Banu's mind was buzzing with a mix of nerves and anticipation. After spending some time contemplating her options, she decided to step out of her room and take action towards finding a solution to her financial challenges."
    "Leaving the comfort of her bedroom behind, Banu walked through the familiar hallways of Polad's apartment."
    scene v16-211 with fade
    if borrowmoneyfrompolad == True:

        "Banu's heart raced as she approached Polad in the living room, her footsteps quick and determined."
        "She could feel the tension building between them, a mix of unspoken emotions and unresolved desires. Taking a deep breath, she mustered her courage and began the conversation."
        scene v16-213
        b "Polad, I need to talk to you about something important."
        "Polad's gaze meeting hers with a mixture of surprise and curiosity."
        p "What's going on, Banu? You look different today. Where are you going?"
        "Banu tried to maintain her composure, pushing aside her personal feelings for the moment."
        b "I just felt like dressing up, trying something new. As for where I'm going, it's related to some personal matters that I need to take care of."
        "Polad's brows furrowed, a hint of suspicion in his eyes."
        scene v16-214
        p "Personal matters? Is everything okay? You can always talk to me, you know that."
        "Banu nodded, her voice steady but tinged with vulnerability."
        b "I appreciate your concern, Polad. But right now, I find myself in a difficult situation financially. I'm struggling to make ends meet, and I was hoping you could help me out."
        b "You've always been there for me, Polad. I trust you, and I know you're someone I can rely on. I wouldn't ask if I didn't truly need the help."
        "Polad studied her face, a flicker of emotions playing in his eyes. After a brief silence, he let out a sigh."
        p "Alright, Banu. I understand. I'll help you, but I need you to promise me that you'll be honest about your situation. We're friends, and I want to make sure you're okay."
        scene v16-213
        "Banu's heart swelled with gratitude, though she kept her emotions in check."
        b "Thank you, Polad. I promise to be honest with you, and I truly appreciate your support. Your friendship means the world to me."
    else:

        "Banu's heart raced as she rushed into the living room, her vibrant dress catching Polad's attention immediately. He looked up, his eyes widening in surprise and curiosity."
        p "Banu, what's with the fancy dress? Where are you headed?"
        scene v16-212
        "Banu's eyes met Polad's, a mixture of tension and desire lingering between them. She refused to let his questioning tone affect her boldness."
        b "Polad, I understand your curiosity, but my attire and my plans are my own. I am not obligated to explain myself to you."
        scene v16-215
        "Polad's jaw tightened, a flicker of surprise crossing his face as he recognized Banu's unyielding resolve."
        p "I'm just concerned about you. We have a history together, and I want to understand what's going on."
        scene v16-212
        "Banu raised an eyebrow, her voice firm and unwavering."
        b "Polad, our history does not entitle you to question my choices or invade my personal space."
        b "I am an independent woman capable of making my own decisions."
        "Polad's gaze flickered, a mix of admiration and frustration evident in his eyes. He was accustomed to being the strong and dominant one, but Banu's fierce independence challenged him."
        p "Fine, Banu. I respect your boundaries. But know that I'm here for you if you ever need help or support."
        "Banu nodded, acknowledging his words with a hint of satisfaction."

    menu:
        "Flirt with Polad":
            $ banuflirtwithpoladinthelivingroom = True
            $ renpy.block_rollback()
            play music "audio/sidesex.mp3"
            scene v16-216
            "Banu's eyes met Polad's, and despite the tension and desire lingering between them, she decided to add a touch of playful flirtation to the conversation. "
            "She couldn't resist the opportunity to tease him, even in the midst of discussing her financial situation."
            b "You know, Polad, I dressed up like this just to see if I could catch your attention. Looks like it worked."
            "A faint smile tugged at the corners of Polad's lips, a hint of amusement sparkling in his eyes."
            scene v16-217
            "Banu couldn't resist the temptation any longer. Feeling a surge of boldness, she took a step closer to Polad, her eyes locked onto his, and a mischievous smile played on her lips. "
            "She decided to embrace the moment and playfully flirt with him, allowing the lingering desires between them to take center stage."
            b "You know, Polad, I can't help but notice how your eyes light up when you see me like this. Is it the dress, or is it just me?"
            p "It's definitely a combination of both, Banu. Your radiant presence and that dress certainly catch my attention."
            scene v16-218
            "Banu slowly touched Polad's face and neck while still talking playfully to him."
            b "You know, Polad, there's something about your presence that always manages to make my heart race. Is it your charm or just my imagination running wild?"
            p "You're so weird today. Looks like you're not in a hurry. If you don't have anything to do, you can help Nesrin clean the rooms."
            b "Oh, Polad, works can wait for a moment, can't they? We deserve a bit of lightheartedness and enjoyment amidst the chaos."
            stop music
        "Say goodbye to Polad":

            $ banuflirtwithpoladinthelivingroom = False
            $ renpy.block_rollback()
            b "I must admit I'm in a bit of a hurry. There are things I need to attend to and take care of."
            "Polad nodded, his expression reflecting understanding."

    scene black with Dissolve(3)
    ""
    centered "{size=+120}Meeting Hicran{/size}" with Fade(0.5, 0.5, 5)
    scene v16-219 with squares
    "Banu stood near the bustling bus stop in the city center, her eyes scanning the surroundings as she waited for Hicran."
    "The sun shone brightly overhead, casting a warm glow on the bustling streets."
    "Despite the sunny weather, Banu wore her elegant hijab, which perfectly complemented her modest knee-length dress. Her choice of attire reflected her personal beliefs and her commitment to her faith."
    "As she observed the diverse crowd passing by, Banu couldn't help but feel a sense of anticipation mixed with curiosity. "
    "Hicran, her close friend, was known for her more eclectic style, often opting for revealing clothes that challenged societal norms."
    "Banu couldn't deny the slight confusion she felt when it came to Hicran's fashion choices. While they both shared a deep bond of friendship, their styles represented two contrasting approaches."
    "However, Banu had come to appreciate and respect Hicran's unique expression of individuality."
    scene v16-220
    "As Banu stood near the busy bus stop, her eyes scanning the crowd, she suddenly spotted Hicran in the distance."
    "A rush of excitement coursed through her as Hicran waved her hand enthusiastically, signaling her arrival."
    "Her dress, a vibrant shade of blue, was notably short, accentuating her legs and adding a touch of playfulness to her overall look."
    scene v16-221
    "Banu couldn't help but feel a mixture of surprise and curiosity as she took in Hicran's unconventional ensemble."
    "The contrasting elements of modesty and daring fashion choices created an intriguing paradox that seemed to reflect Hicran's unique personality."
    hic "Banu, my fabulous friend! It's so good to see you!"
    b "Hicran, you always know how to make an entrance! I must say, your hijab paired with those sunglasses and that blue dress create quite a statement."
    hic "Oh, you know me, Banu. I like to keep things interesting and challenge the norms. But don't worry, I'm still the same Hicran you know and love, regardless of my fashion choices."
    scene v16-222
    "As Banu and Hicran walked together, the worry etched on Banu's face didn't go unnoticed by her perceptive friend. Hicran glanced at Banu with concern, her curiosity piqued."
    hic "Banu, what's on your mind? You seem troubled. Is something bothering you?"
    b "Hicran, I need to talk to you about something important, but I'd prefer if we could find a more private place. There are some things weighing on my mind that I need to share with you."
    hic "Of course, Banu. Let's find a quiet spot where we can talk without any distractions. You know I'm here for you, right?"
    scene v16-223 with fade
    "Banu and Hicran found a more secluded spot, away from the prying eyes and ears of the bustling city. "
    "Banu took a deep breath, her voice tinged with a mix of apprehension and vulnerability."
    b "Hicran, there's something else I need to talk to you about. It's about my financial situation. I recently lost my job, and I'm struggling to make ends meet. I'm in desperate need of work, and I don't know where to turn."
    hic "Oh, Banu, I'm sorry to hear that. It must be incredibly tough for you. You know I'm here for you, right? We'll find a solution together."
    if borrowmoneyfrompolad == True:
        ""
    else:


        scene v16-224
        b "Hicran, I hate to ask this of you, but I'm in a really tough spot right now. Would it be possible for me to borrow some money to help me get through this difficult period?"
        hic "Banu, you're my dear friend, and I'll always support you in times of need. I can lend you the money you require."


    scene v16-224
    play music "audio/action.mp3"
    hic "Listen, I actually have an offer for you."
    hic "What if...."
    scene v16-223
    "Banu listened attentively as Hicran spoke about a potential job opportunity, unaware of the true nature of Hicran's work."
    "Hicran mentioned the need for female couriers to deliver items to customers, but the details remained ambiguous."
    b "So, you think I could do this job? Is it legal? I need to know more about it before considering anything."
    scene v16-224
    "Hicran hesitated for a moment, choosing her words carefully."
    hic "Well, it's not your conventional job, Banu. There are certain... aspects to it that might be different from what you're used to. But it's an opportunity to earn some good money quickly, and I thought it could help you in your current situation."
    scene v16-223
    "Banu's curiosity piqued, and she wanted to learn more about the job before making any decisions."
    b "Hicran, I appreciate your concern and willingness to help, but I need more information. Can you tell me what exactly I would be delivering and to whom?"
    b "And who is the person in charge that you mentioned?"
    scene v16-224
    hic "Banu, I'll be honest with you. The items we deliver are not legal. It involves delivering certain substances to potential buyers, including college students."
    hic "I work for a group that operates outside the law. I didn't reveal this before because I didn't want to overwhelm you, but I thought you might be interested in the financial aspect."
    b "Hicran, I appreciate your intention to help, but I cannot get involved in anything illegal. My financial struggles are challenging, but I cannot compromise my principles and risk getting into trouble."
    hic "If you need quick money this is the only and easy way. Let's go to meet the man I was talking about."
    b "Hicran, I can't believe I'm considering this, but if meeting the person in charge is necessary to gather more information, then I guess I have no choice."
    b "But please remember, I'm not committing to anything until I have a clear understanding of what's involved."
    stop music
    hic "I understand, Banu. We'll meet him together, and you can ask any questions you need to clarify your doubts. "
    scene black with dissolve
    ""
    scene v16-225 with pixellate
    play music "audio/tension.mp3"
    "In the dimly lit room, the Boss sat on the sofa, his stern face shadowed by the dim light. His moustache twitched slightly as he exchanged words with Vladimir, his personal bodyguard."
    "Vladimir, a well-built and tall man with a muscular physique, stood in front of the Boss. His icy gaze scanned the room, ever watchful and alert, ready to act at a moment's notice."
    dad "Vladimir, I want you to understand the importance of handling this meeting with utmost caution. We cannot afford any mistakes."
    v "I'm well aware, Boss. I'll make sure everything runs smoothly."
    dad "The last thing we need is unnecessary attention. Keep a close eye on Hicran and her friend. I want to know if they can be trusted."
    v "Consider it done. I'll assess their intentions and their loyalty."
    "As the conversation continued, the room seemed to vibrate with a sense of authority and danger, a reflection of the power the Boss commanded in the criminal underworld."
    scene v16-226 with fade
    "The arrival of Hicran and Banu interrupted the serious atmosphere. The door creaked open, and Hicran led Banu into the room, a mix of confidence and apprehension in her demeanor."
    dad "What brings you here, Hicran?"
    hic "Boss, this is my friend, Banu. She's interested in discussing a potential opportunity."
    scene v16-227
    dad "So, this is the woman you've been talking about, Hicran. You seem to trust her. I hope she's as reliable as you claim."
    hic "Yes, Boss. Banu is a dear friend, and I believe she has the determination and loyalty to be an asset to us."
    "Banu felt a surge of unease, realizing that Hicran had shared more about her than she had anticipated. She exchanged a cautious look with Hicran, silently urging her friend to be careful with what she revealed."
    scene v16-228
    "As Hicran continued her conversation with the Boss, Banu couldn't help but feel the intensity of Vladimir's gaze on her."
    "His towering presence and muscular frame were imposing, and the scar on his face added an air of mystery and danger."
    "As Hicran and the Boss exchanged words, Banu's anxiety grew. She stole a cautious glance at Vladimir, only to find his unwavering focus fixed on her."
    "Her heart raced, and she couldn't help but feel a sense of vulnerability in his presence."
    scene v16-229
    "Their eyes locked, and in that moment, Banu felt a mix of fear and fascination."
    "Vladimir's eyes seemed to hold a thousand untold stories, and she couldn't help but wonder what kind of life he had led to earn that scar."
    "A sense of insecurity washed over Banu, making her feel small and insignificant compared to the massive, bulky man before her."
    scene v16-230
    stop music
    "As Banu's attention was drawn to Vladimir, the Boss called her closer with a commanding gesture. She took a deep breath and approached the Boss, who was seated on a large, plush sofa, his eyes still fixed on her."
    dad "Come, Banu. Let's talk about what you need exactly."
    b "(Nervously) Thank you, Boss. I'm in a tough financial situation, and I need some quick money to get back on my feet."
    "The Boss leaned back on the sofa, his imposing presence ever apparent as he listened to Banu's words."
    dad "Hicran mentioned that you're interested in an opportunity. What can you offer us in return for the help we may provide?"
    b "I'm willing to work hard and follow any instructions you give me. I may not have experience in this line of work, but I'm a quick learner, and I won't let you down."
    "The Boss's moustache twitched as he considered Banu's words. He was a man who valued loyalty and commitment above all else."
    dad "Very well, Banu. We'll see if you're as reliable as Hicran believes. But for now, I need to speak with you in private. Hicran, you may leave us."
    scene v16-231
    "Hicran's expression remained composed as she nodded and exited the room, leaving Banu alone with the imposing figure of the Boss."
    "Banu felt a mix of apprehension and determination. She knew this was her chance to prove herself, but the weight of the situation was overwhelming."
    dad "I'm willing to give you an opportunity, Banu. But remember, loyalty and trust are everything. Fail me, and there will be severe consequences."
    b "I won't let you down, Boss. You can count on me."
    scene v16-232
    "As the conversation continued in private, Banu couldn't help but feel a sense of trepidation about the path she had chosen. "
    "The reality of the dangerous world she had entered became even more apparent, and she knew that her decisions from this point forward would have far-reaching consequences."
    scene v16-234
    dad "Banu, in this line of work, we expect our associates to be fully devoted and willing to do whatever is necessary to fulfill their duties."
    dad "You must be ready to make me happy and obey without question."
    "Banu hesitated, feeling the weight of the Boss's expectations pressing down on her."
    "She knew that this was a pivotal moment, and she needed to be honest with herself and with him."
    menu:
        "I need time to consider it":
            $ banuundressedinfrontofboss = False
            $ renpy.block_rollback()
            scene v16-233
            b "I appreciate the opportunity, Boss, but I need some time to consider everything carefully."
            b "This is a significant decision, and I want to be sure that I can fully commit to it."
            "The Boss regarded her for a moment, his expression unreadable, and then nodded slowly."
            dad "Fair enough. I respect your need for contemplation. Take your time, but remember, hesitation can have consequences as well."
        "I'll do anything the work requires":


            $ banuundressedinfrontofboss = True
            $ renpy.block_rollback()
            scene v16-235
            "As the Boss asked Banu if she was willing to do anything the work required, her confidence didn't waver. Instead, a determined smile crossed her face."
            b "Yes, Boss. I'm fully committed, and I'm willing to do whatever it takes to fulfill my responsibilities and make you happy."
            dad "Good. Loyalty and dedication are rare qualities in this business, and I value those who possess them. You'll start on a trial basis, and we'll see if you live up to your words."
            b "Thank you, Boss. I won't disappoint you."
            scene v16-236
            dad "Vladimir, I need you to thoroughly check her for any tracking or listening devices. We can't afford to take any chances."
            "Vladimir's expression remained stoic, as he acknowledged the Boss's command with a nod."
            v "Understood, Boss. I'll make sure there are no unwanted surprises."
            scene v16-237
            "As Vladimir approached Banu to carry out the inspection, she mustered the courage to speak up, hoping to avoid feeling further vulnerable."
            b "I understand the need for caution, but I assure you, there's no need to check me. I have nothing to hide."
            dad "It's a standard procedure, Banu. We can't take any risks."
            scene v16-238
            b "But I don't have anything to hide. What are you going to check?"
            dad "Let's start with her hijab. It's a very fasionable hijab, Banu. It suits you, but we'll have to take it off."
            b "Ohh...okay."
            scene v16-239 with fade
            "Vladimir slowly took Banu's hijab off exposing her beautiful hidden hair."
            dad "You're so beautiful without it. Why do you even hide your beauty?"
            b "Thank you, Boss. I choose to wear the hijab as a personal and religious choice. It's an essential part of my identity."
            scene v16-240
            dad "Religious, you say? Well, we don't care about that here. You'll do what's required for the job, regardless."
            "Banu felt a mix of emotions. On one hand, she was taken aback by the Boss's dismissive attitude towards her religious beliefs. On the other hand, she knew she had to tread carefully in this unfamiliar territory."
            b "Understood, Boss. My beliefs won't interfere with my commitment to the job."
            dad "Good. Let's continue."
            v "Raise your arms, please."
            b "What?"
            v "I need to check you properly."
            b "..."
            scene v16-241 with fade
            "Vladimir then asked her to raise her arms, and with precision, he checked her body, making sure she wasn't hiding anything."
            "Banu stood still looking at Boss's eyes showing her faith to the job by doing exactly what they said."
            scene v16-242
            "Banu's body reacted as Vladimir touched every part of her body squeezing her breasts, ass and legs with his big strong hands."
            "A powerful lust came to her making her eyes relaxed and her pussy wet."
            "She understood that this was not a normal procedure but it was too late as she already agreed to do anything it takes."
            dad "Take off her dress."
            scene v16-243 with hpunch
            "Banu couldn't say a word as Vladimir took a quick action and revealed her upper body immediately."
            "Once he firmly grabbed her dress, in no time he undressed Banu fully exposing her alluring figure."
            scene v16-244 with fade
            "Banu couldn't help but feel a mix of emotions as she glanced at the Boss with a frown, her eyes revealing her unease."
            "She felt exposed and vulnerable, a small sense of indignation creeping in."
            b "Are you satisfied now?"
            "As Banu's sarcastic words reached the Boss's ears, a flicker of irritation crossed his face. "
            scene v16-245
            "He stood up from the sofa, his imposing figure approaching her with an air of authority."
            dad "Watch your tone, Banu. You're treading on thin ice here."
            "Banu's heart skipped a beat, realizing she had struck a nerve with her remark. "
            dad "This is no place for sarcasm. You chose to be here, and you need to understand the rules."
            scene v16-246
            "As the Boss threatened Banu, his words sent a chill down her spine. The realization that he knew such personal details about her life made her feel exposed and vulnerable."
            dad "This business is not a joke, Banu. Loyalty is everything. I know everything about you – your husband Kamil, your living situation, your job loss, even your daughter Leyla."
            "Banu's heart pounded, and she couldn't help but feel a sense of dread. The fact that the Boss was aware of her personal life left her feeling like she had no secrets."
            dad "We have our ways of gathering information. Don't think you can hide anything from us."
            dad "And take your hands off your pussy and breasts now! I hate that!"
            scene v16-247
            "As the Boss asked Banu to stop covering herself with her hands, she felt a mix of discomfort and vulnerability."
            "Her instincts told her to protect herself, but she also knew she had to show strength in this intimidating environment."
            b "(Nervously) I apologize, Boss."
            scene v16-248
            "Banu could feel her heart pounding in her chest as his eyes locked onto hers with an intensity that sent shivers down her spine."
            dad "Don't play games with me, Banu. This is not a place for weakness."
            "Banu tried her best to maintain her composure, but the fear inside her was palpable. She felt like a deer caught in the headlights, vulnerable and exposed."
            b "I-I'm not playing games, Boss. I'm here to prove myself, I swear."
            "The Boss's piercing gaze seemed to penetrate through her defenses, and she couldn't help but feel like he saw right through her."
            dad "We'll see about that. You better not disappoint me."
            scene v16-249
            "His words sent a shiver down her spine, and Banu knew that she couldn't afford to falter. She had to show strength, even in the face of this formidable figure."
            b "I won't, Boss. I'm determined to succeed here."
            "As the Boss continued to scrutinize her, Banu forced herself to stand tall, trying her best not to show the fear that lurked within her."
            "She knew that in this world, any sign of weakness could be exploited, and she couldn't afford to let that happen."
            dad "Remember, in this business, fear is a powerful tool. Don't let it consume you."
            "With those words, the Boss turned away, leaving Banu feeling both relieved and unsettled."
            scene v16-250 with fade
            "As the intense moment with the Boss came to an end, he abruptly instructed Banu to put on her clothes and leave."
            "Banu quickly complied, wearing her clothes with haste, trying to regain some semblance of normalcy. She could feel the weight of the situation, understanding that she was now inextricably tied to this dangerous world."
            b "Thank you for the opportunity, Boss."
            dad "Just remember, you have a lot to prove."
            scene v16-251 with hpunch
            "Banu's heart skipped a beat as the door suddenly swung open, revealing a face she thought she had left behind in the shadows of the past."
            "It was the street guy who had attacked her some time ago, and the sight of him sent a wave of confusion and fear washing over her."
            "Feeling overwhelmed and uncertain, Banu made a split-second decision. Without saying another word, she turned and swiftly left the office, her mind racing with questions and uncertainty. "
            scene v16-252
            "She was now entangled in a web of secrets, deception, and unpredictable alliances."
            "But she was determined to navigate this dangerous world with the strength and resilience that had brought her this far."

    scene black with Dissolve(3)
    ""
    centered "{size=+120}Watching TV{/size}" with Fade(0.5, 0.5, 5)
    scene v16-253 with blinds
    "Banu slowly emerges from the dimly lit kitchen, her feet moving quietly on the soft carpeted floor. She wears a simple yet elegant grey nightdress, a comforting choice for the evening's repose."
    "A hijab gracefully frames her face, reflecting her modesty and inner strength. The heaviness of recent events weighs on her, but there is also a glimmer of hope in her eyes, hinting at the potential for a brighter future."
    scene v16-254
    "As she steps into the living room, her gaze falls upon Polad and Nesrin on the sofa, their eyes fixated on the television screen."
    "The room is bathed in the warm glow of the screen, casting shadows that dance playfully around them."
    scene v16-255
    "As Banu steps closer to Polad and Nesrin, a sense of unease washes over her as she observes their distant demeanor."
    "The living room, once filled with a serene ambiance, now feels tense and heavy with unspoken emotions."
    "Polad and Nesrin's lack of communication and apparent unhappiness is evident, but Banu remains unsure of the cause."
    "Caught between the uncertainty of the situation and her desire to find a place among her friends, Banu hesitates."
    menu:
        "Banu sits next to Polad":
            $ banusitnexttopolad = True
            $ renpy.block_rollback()
            scene v16-256 with fade
            "Sitting next to Polad not only signifies her desire to improve their friendship but also brings to the surface the feelings she has developed for him."
            "It's a delicate situation, and Banu knows she must tread carefully to protect her friendship with Nesrin and respect the boundaries of Polad's marriage with Nesrin."
            "But she couldn't stop herself trying to get Polad's attention. "
            scene v16-257
            b "Hey, Polad, I was curious about your thoughts on this movie. Have you seen it before?"
            p "Oh, uh, no, I haven't seen it yet."
            b "I see. It's a good movie, I watched it recently. The storyline is quite intriguing, and the performances are impressive."
            scene v16-256
            "As Nesrin notices Polad and Banu engaged in conversation about the movie, a hint of jealousy creeps into her heart."
            n "Um, excuse me, guys. Can we please focus on the movie?"
            b "Yes, my apologies. Let's continue watching."
            "As the movie continues playing, Banu finds herself wanting to connect with Polad on a deeper level, despite the complexities of her emotions."
            scene v16-258
            "With caution, she decides to try a subtle approach to get his attention. She gently places her hand on his leg, a soft touch that seeks to convey comfort and familiarity."
            "With a barely audible whisper, Banu speaks to Polad, making sure not to disrupt the movie or cause any discomfort to Nesrin."
            b "Polad, can we talk later, just the two of us?"
            "Polad glances at Banu, momentarily surprised by her touch and whispered request. He nods subtly, indicating that they can have a conversation after the movie."
            p "Sure, Banu. We can talk later."
            scene v16-259 with hpunch
            "As Banu and Polad quietly converse, their whispers attracting Nesrin's attention once again, Nesrin's frustration reaches its peak."
            "Feeling left out and misunderstood, she abruptly stands up, the anger evident in her expression."
            n "What are you two whispering about again? It's like I'm invisible here!"
            b "Nesrin, please, it's not what you think. We were just having a private conversation."
            scene v16-260
            p "Nesrin, let's calm down and talk about this calmly. There's no need for anger."
            n "No, Polad! I want you to come with me to the bedroom. We need to talk about this in private."
            scene v16-261
            "Polad shares a worried glance with Banu, understanding the gravity of the situation. With a sense of responsibility, he agrees to Nesrin's request, hoping to alleviate the tension and address her concerns."
            p "Alright, Nesrin. Let's go and have that conversation. Banu, please understand that we need to sort this out."
            b "I understand, Polad. Take your time, and I'll be here if you need anything."
            "Polad and Nesrin exit the room, leaving Banu alone with her thoughts."
        "Banu sits next to Nesrin":





            $ banusitnexttopolad = False
            $ renpy.block_rollback()
            scene v16-262
            "Wanting to be considerate of their relationship and not exacerbate any existing discomfort, she decides to sit next to Nesrin on the sofa."
            "Her desire to be close to Polad takes a back seat to the importance of respecting the couple's bond."
            "As Banu sits on the sofa next to Nesrin, she tries to engage in conversation about the movie they're watching. However, Nesrin remains distant and unresponsive, not acknowledging Banu's comments."
            scene v16-263
            b "The movie has some interesting twists, don't you think? I didn't see that coming."
            b "Nesrin, is something bothering you? You seem a bit distant."
            n "It's nothing. I'm just tired."
            b "You know you can talk to me, right? We've been friends for so long, and I care about you. If something's on your mind, I'm here to listen."
            scene v16-264
            "As Banu notices Nesrin's unhappiness and her sudden departure from the room, she feels a mix of surprise and concern."
            "She exchanges a puzzled glance with Polad, both unsure of what could have caused Nesrin's sudden change in demeanor."
            scene v16-265
            b "Do you have any idea what might be bothering Nesrin? She seemed really upset."
            b "I can't help but feel like I might be the reason for Nesrin's behavior earlier."
            p "I don't think you did anything wrong."
            "Feeling relieved that she is not the cause of the tension between Polad and Nesrin, Banu knows that it's important to give them space to work through their relationship challenges."














    scene black with Dissolve(3)
    ""



    $ banupoladshowering = False
    $ banustaysmuratandfriend = False
    $ banuacceptmafia = False








    centered "{size=+120}Drunk...{/size}" with Fade(0.5, 0.5, 5)
    scene v17-16 with squares
    nur "You know, Emil, sometimes I still can't believe it's been a year since I joined the army. It feels like a lifetime of experiences packed into those twelve months."
    nur "The challenges we faced were unlike anything I had experienced before."
    emil "I can only imagine. It must be really tough, am I right? "
    nur "It wasn't easy, that's for sure. But looking back, I wouldn't trade those experiences for anything. The army taught me so much about myself and the world."
    emil "What were some of the most challenging moments you faced during your time in the military?"
    nur "Oh, there were quite a few. The rigorous training, the long deployments away from family and friends, and the moments when we had to make tough decisions that carried real consequences."
    emil "I have to say, it's been a year, and you're still rocking that army uniform. Are you planning on making it a lifelong fashion statement?"
    nur "Well, you know what they say, 'Once a soldier, always a soldier.' But, no, it's just a habit, I guess. Plus, it's comfortable, and I've grown oddly attached to it."
    scene v17-17 with dissolve
    nur "Look over there. Seems like that guy could use some help."
    emil "You're right. He doesn't seem to be in the best state. Let's see if we can offer him some assistance."
    scene v17-18
    nur "Hey there, buddy. Are you okay?"
    k "Huh? Wh-who're you?"
    nur "We're just a couple of guys passing by. It looks like you've had a bit too much to drink. Is there anything we can do to help you?"
    k "I'm fine... just leave me alone."
    emil "We don't want to intrude, but we're concerned about your well-being. Maybe we can call someone for you or help you get home safely?"
    k "I said I'm fine! Mind your own business!"
    nur "We understand, but sometimes we all need a little help. We're not judging you, just want to make sure you're okay."
    emil "That's right. It's okay to ask for help, and we won't think any less of you for it."
    k "..."
    scene v17-19
    nur "Emil, we can't just leave him like this. He needs help, and we should call the police or someone who can assist him."
    emil "You're right, Nurlan. I don't feel comfortable leaving him here alone either. Let's find a safe spot nearby to make the call."
    k "Why... why did she leave me? Wasn't I good enough? (Pauses, taking a deep, shaky breath) I loved her so much... gave her everything I could..."
    "Nurlan and Emil overhear his words, exchanging a glance that shows understanding and sympathy for the man's pain."
    k "I thought we'd be together forever... but she's gone now, and I don't know what to do..."
    k "Maybe... maybe I messed it all up. Too many mistakes, too much pride... "
    k "I wish I could turn back time, do things differently... make her stay."
    scene v17-20
    "Kamil reaches for the beer bottle with a trembling hand, his fingers gripping it tightly as if seeking comfort in its familiarity."
    "With a heavy sigh, he raises the bottle to his lips, the familiar scent of hops and barley filling the air as he takes a long swig."
    "..."


    scene black with Dissolve(3)
    ""
    centered "{size=+120}Nesrin{/size}" with Fade(0.5, 0.5, 5)
    scene v17-38 with blinds
    "The kitchen is dimly lit, casting a soft glow on the countertops and appliances. Banu stands by the sink."
    "She is dressed in a short sleeveless shirt that reveals most of her legs, a departure from her usual conservative attire."
    "Tonight, she has chosen not to wear her hijab, a reflection of her inner turmoil."
    "Her mind is preoccupied with thoughts of Polad, her weak spot."
    "A sense of unease washes over her as she thinks about Nesrin's husband, Polad that she attracted to."
    scene v17-39
    b_ "Why did I let myself fall for him?"
    b_ "He's like gravity, pulling me closer even though I know it's wrong. But I can't help it."
    b_ "Polad's kind but at the same time...manly, it's all intoxicating. I've lived in his apartment for so long, and my heart can't help but beat faster when he's around."
    b_ "And Nesrin's husband... How could he? He has a beautiful wife, and yet he's drawn to someone like me. I should have kept my distance, but fate had other plans. I never intended for this to happen."
    b_ "What if he comes now? Should I have put on something more modest?"
    b_ "Oh, why did I choose to wear this tonight? He's always been respectful, but this might be too much for him to handle."
    b_ "Maybe I can pretend I'm just getting a late-night snack or something. "
    scene v17-40 with fade
    "Banu is lost in her thoughts when suddenly Nesrin appears in her underwear behind her, folding her arms and giving Banu a suspicious look."
    n "What are you doing here?"
    scene v17-41
    play music "audio/action.mp3"
    "Banu notices Nesrin's disapproving gaze and takes a step closer to her, trying to address the situation."
    b "Oh, Nesrin, I didn't hear you come in."
    n "Clearly. What's going on, Banu? I've been noticing some things lately, and I don't like where this is heading."
    "Banu's heart sinks, knowing exactly what Nesrin is referring to. She struggles to find the right words to explain herself."
    b "Nesrin, I-I can explain. It's just that tonight, I couldn't sleep, and I thought I'd be more comfortable in my nightwear. I didn't mean to upset you."
    scene v17-42
    n "Comfortable? This is Polad's apartment, Banu, not your personal space to roam around in whatever you please. I've been trying to be understanding, but you're crossing boundaries."
    b "I'm sorry, Nesrin. You're right. I shouldn't have been so careless. I'll be more mindful from now on."
    n "It's not just about this, Banu. Lately, it feels like you're always around, like you're intentionally trying to get close to Polad. It's making me uncomfortable."
    b "I said I would be more mindful, Nesrin! What more do you want from me?"
    scene v17-43 with hpunch
    n "(angry) More?! I want you to stay away from my husband! Is that too much to ask for?"
    b "(raising her voice) I'm not trying to steal him away from you, Nesrin!"
    n "Oh, poor Banu, torn between doing the right thing and what she really wants. Spare me the drama!"
    scene v17-44
    b "You know what? You're right. Maybe I should just leave. If my presence here is causing you so much pain, then I'll go."
    n "I know you have feelings for Polad and we talked about this. I thought this is over but..."
    b "I can't do this anymore, Nesrin! Every day I see you two together, and it's tearing me apart!"
    n "What do you want me to do, Banu? Divorce my husband just because you can't handle your feelings?"
    scene v17-45
    b "No, that's not what I'm saying, and you know it! But can't you see how hard it is for me to be around you two while my heart is breaking?"
    n "Oh, poor Banu, always the victim! You're the one who can't control her emotions, not me! So just shut up!"
    b "You don't understand! I never asked for this! I never wanted to feel this way about Polad, but it happened, and I'm trying to deal with it!"
    scene v17-46
    n "Trying to deal with it? Is that why you keep making eyes at him every chance you get?"
    b "That's not fair! I'm doing my best to respect your relationship, but you keep pushing me away!"
    n "Maybe if you weren't always lurking around, hoping for some chance to be with him, I wouldn't have to push you away!"
    "Banu's face flushes with anger and hurt, unable to believe what Nesrin is accusing her of."
    b "I am not lurking around! I live here, Nesrin! I can't just disappear because you don't like how I feel!"
    n "You should have thought about that before you decided to live with us! This was a mistake!"
    b "Maybe it was a mistake! Maybe I should leave and never come back!"
    n "Maybe you should!"
    scene v17-47 with fade
    stop music
    "The words hang heavily in the air, the damage already done. Both Banu and Nesrin are breathing heavily, their faces red with anger and hurt."
    "They never thought their friendship could reach such a breaking point."
    b "I can't believe you would say that. After all we've been through together."
    n "Maybe it's time we face the truth. Maybe we were never as good of friends as we thought."
    "The room falls into an uneasy silence as the weight of their words sinks in. The realization that their friendship might be irreparably damaged hangs heavy between them."
    b "Maybe... maybe it's time for me to go."
    n "Maybe..."
    b "But do you really want me to go?"
    scene v17-48
    "The tense atmosphere is palpable as Banu takes a deep breath, mustering her courage to address the underlying issue."
    b "Nesrin, I want you to look into my eyes."
    scene v17-49
    "Nesrin glances at Banu, still filled with anger and hurt, but curious about what Banu has to say. She reluctantly meets Banu's gaze."
    b "I think I know why you've been behaving this way. I think... maybe you have feelings for me that go beyond friendship."
    "Nesrin's eyes widen in surprise, but she quickly tries to dismiss Banu's words."
    n "That's not true! I love my husband, and I don't have feelings for you like that!"
    b "Nesrin, it's okay. You don't have to hide it from me. It happens sometimes, feelings can be confusing, and we can't always control who we're drawn to."
    n "What are you saying?"

    scene v17-50
    b "I see how you look at me sometimes, Nesrin. The way you get jealous when I'm around Polad. Maybe you're struggling with your own emotions, and that's why you've been pushing me away."
    n "You're reading too much into things! I'm just upset about the situation, that's all!"
    b "Nesrin, it's okay to feel the way you do. You don't have to deny it. We can talk about it, try to understand it together."
    "Nesrin's defenses begin to crumble, her anger giving way to vulnerability. She looks away, unable to hold Banu's gaze any longer."
    n "I don't know... Maybe I have been feeling something, but I can't let it affect my marriage."
    b "I'm not going to marry you, silly girl. If you have feelings, you can just let me know."
    n "Banu, please, I'm just not okay. Let's talk another time."


    scene black with Dissolve(3)
    ""
    centered "{size=+120}The next day{/size}" with Fade(0.5, 0.5, 5)
    scene v17-112 with irisin
    "The living room is filled with warm, natural light as Banu gingerly carries the vase of striking red flowers in her hands."
    "Each step she takes seems cautious, as if she's walking on a tightrope, trying to balance her emotions and the delicate arrangement."
    "Banu's fingers lightly trace the curves of the vase, feeling the smooth surface beneath her touch. The red flowers exude a captivating fragrance that fills the room, almost intoxicating. "
    "The color red symbolizes her intense emotions—passion, love, and desire—all swirling together, making her heart race."
    scene v17-113
    "Carefully, she sets the vase down, ensuring that it sits perfectly in the center of the table. The vibrant red blooms stand out against the neutral tones of the room, like a beacon of her inner turmoil."
    "A part of her hopes that the presence of these flowers will bring her solace, that they will fill the void of loneliness she feels, but she also fears they will only intensify her longing for Polad."
    scene v17-114
    "Banu, with the vase of red flowers now placed on the small rounded table near the TV, starts to walk toward her room, hoping to find some solitude and clarity."
    "But as she passes the hallway leading to the bathroom, the sound of running water catches her attention. She pauses for a moment, her curiosity piqued, and her heart skips a beat as she realizes it's the sound of someone showering."
    "A mix of guilt and temptation swirls inside her, and she debates whether to continue to her room or investigate further."
    scene black with dissolve
    "Slowly, Banu tiptoes closer to the bathroom door, her heart racing with every step. The muffled sound of the water and the steam escaping from under the door create an air of intimacy, heightening her senses."
    "With a deep breath, she reaches the bathroom door and gently places her hand on the cold knob. Her mind races with conflicting thoughts."
    "Her loyalty to Nesrin urges her to turn away, but her curiosity about Polad drives her to push the door slightly ajar."
    scene v17-115 with dissolve
    "The sight before her is unexpected, yet it fills her with a mix of fascination and unease. "
    "His silhouette blurred by the steam. Her pulse quickens as she sees the outline of his broad shoulders and the graceful movements of his hands."
    "She entertains the idea of stepping inside, to join him, to let herself be enveloped in the warmth of the shower, both literally and metaphorically."
    "Her mind battles with conflicting emotions. Part of her knows she should turn away and respect his privacy, but another part of her yearns to see more, to be closer."
    menu:
        "Turn away and leave":
            $ renpy.block_rollback()
            $ banupoladshowering = False
            scene v17-115
            "Banu takes a step back, tears forming in her eyes. She can't believe she allowed herself to be so weak, so consumed by her desires."
            scene black
            "She quickly closes the bathroom door and leans against it, trying to catch her breath and collect her thoughts."
        "Get closer":


            $ renpy.block_rollback()
            $ banupoladshowering = True
            scene v17-116
            "The allure of Polad and the intensity of her feelings for him make it difficult for her to resist the temptation to watch."
            "She takes a cautious step closer, drawn to the warmth emanating from the shower."
            "The steam envelopes her, and for a moment, she forgets everything else. Her eyes are fixed on Polad, and the world outside the bathroom seems to fade away."
            "Banu feels a mix of excitement and guilt as she watches him. It's as if she is crossing a boundary she never thought she would cross, entering a realm of intimacy that belongs to someone else."


            jump polad_banu_shower
label polad_banu_shower_continue:

    if banugotomuratsapartmentafterfun == True:

        scene black with Dissolve(3)
        ""
        centered "{size=+120}...{/size}" with Fade(0.5, 0.5, 5)
        scene v17-213 with irisin
        play music "audio/up.mp3"
        "In the end of a wild night Banu and Murat are back at Murat's apartment with his best friend Vasif."
        b "So, here we are, back at your place. That was quite the night, wasn't it?"
        mur "Yeah, it definitely was something. You've got some moves, Banu. I never would've guessed you were hiding a dancing queen inside you."
        va "Seriously, Banu, you were amazing! I didn't know you could dance like that."
        b "Oh, thank you, Vasif. It's just... I guess the music got to me."
        b "So, Vasif, how did you and Murat become friends?"
        scene v17-214
        va "Well, we met in college. Shared a few classes, discovered our mutual love for late-night conversations about life and the universe. We've been inseparable ever since."
        mur "Yeah, and we've had our fair share of adventures."
        b "I can imagine. It sounds like you two have been through a lot together."
        va "Oh, you have no idea. But hey, tonight was an adventure of its own, right?"
        b "Yes, it certainly was."
        scene v17-215
        va "You know what would make this night even better? If you stayed over, Banu. We could continue the fun, maybe binge-watch some movies or play some games. What do you say?"
        b "Thank you, Vasif. But I should be getting home. I have responsibilities and commitments."
        scene v17-216
        va "Oh, come on, responsibilities can wait. It's not every day we get a chance to have this much fun."
        mur "Vasif's right, Banu. It's been a while since we all hung out like this. It could be a memorable night."
        b "Guys, it's not appropriate for me to stay the night here."
        va "Appropriate? Oh, come on, we're all adults here. What's a night of innocent fun among friends?"
        mur "You know, Banu, I can't help but feel like you're using your commitments as an excuse. I mean, we both know that you like having fun, so why not spend the night with us?"
        stop music
        menu:
            "Banu leaves":
                $ renpy.block_rollback()
                $ banustaysmuratandfriend = False
                scene v17-217
                b "Oh, Murat, you really have a talent for painting quite the dramatic picture, don't you?"
                mur "What do you mean?"
                b "I mean, come on! Are you auditioning for a role in a romantic movie? The brooding hero who can't forget his past love?"
                mur "It's not like that, Banu. I'm just being honest about what I feel."
                b "Well, then let me get this straight – you want me to stay the night so we can have some grand romantic revelation and live happily ever after?"
                scene v17-218
                va "Well, well, Banu, it seems Murat's romantic monologue didn't quite do the trick. But you know what they say – persistence pays off. How about you stay the night and let me show you how irresistible I can be?"
                b "Oh, Vasif, you're quite the charmer, aren't you?"
                va "You have no idea. Come on, Banu, staying the night could be a lot of fun. We'll have a blast, I promise."
                b "Vasif, I have no doubt you know how to have a good time, but my idea of fun might not exactly align with yours."
                va "You're telling me dancing the night away and enjoying each other's company doesn't sound like a good time?"
                b "It sounds like a wonderful time, Vasif. But I have responsibilities and commitments that I can't overlook."
                scene v17-219
                "Banu's steps were purposeful, her stride unwavering as she walked away."
                "Murat and Vasif had nothing to do as they stood where they were and watched as she left the room."
            "Banu stays":






                $ renpy.block_rollback()
                $ banustaysmuratandfriend = True
                scene v17-220 with fade
                b "You know what, Murat? You've convinced me. I can spare a few more hours before I have to head home. Let's make the most of it."
                va "Now that's what I'm talking about! Welcome back to the land of spontaneous fun, Banu."
                mur "You know, Banu, I never would've guessed that behind that modest facade lies such a lewd woman."
                scene v17-221
                b "Oh, really? And what exactly makes you say that, Murat?"
                mur "Well, you were dancing like there was no tomorrow at the club, surrounded by all those flashing lights. I had to do a double-take to make sure it was really you."
                b "My goodness, you caught me! Dancing and having fun automatically makes me scandalous, huh?"
                b "You have quite the imagination, Murat. But let me assure you, my dance moves aren't indicative of any secret life."
                scene v17-222
                va "You know, Banu, I have to say something. Watching you dance tonight, seeing your smile, it's like a spell. It's hard for me to resist, to not tell you how much I want..."
                b "Vasif, let's keep the mood light, shall we?"
                va "No, Banu, I need to say this. I want you, not just for a few hours of fun, but for more. I've been drawn to you, and tonight... it's like all those feelings are right at the surface."
                scene v17-223
                b "Vasif, this isn't the kind of conversation we should be having. Let's just have fun, I see that you're drunk a bit."
                scene v17-222
                va "Banu, I can't hold it back any longer. I need to tell you – It's the first time I felt this way."
                va "The way you carry yourself, your strength, your grace... it's like a magnet, pulling me towards you."
                scene v17-223
                va "I couldn't keep it inside any longer. It's like an ache, Banu, a constant longing."
                b "I never intended for things to become this complicated. "
                "The room felt suspended in an uneasy stillness, the air heavy with the weight of Vasif's confession."
                "Banu and Vasif exchanged glances, their eyes locking in a moment of surprise and discomfort."
                "Banu's gaze held a mixture of surprise and concern, her lips slightly parted as if searching for the right words to respond."
                mur "Well, Vasif, I've always said that too much dancing can make a person a bit drunk. Looks like you're experiencing that firsthand."
                va "Yeah, you might be onto something, Murat."
                b "I think we've had enough unexpected revelations for the night, don't you think?"
                mur "Oh, come on, Banu. We're all adults here. Besides, I have an idea to lighten the mood. How about a game?"

                jump murat_threesome




label murat_threesome_continue:


    scene black with Dissolve(3)
    ""
    centered "{size=+120}The decision{/size}" with Fade(0.5, 0.5, 5)
    scene black with dissolve
    "As Banu once again found herself standing outside the Boss's office, a sense of unease mixed with determination gripped her."
    "Banu took a deep breath, steadying her nerves before she entered the office. "
    scene v17-267 with dissolve
    "She was now wearing a grey hijab and dress, a choice that had been made for her. The attire clung to her form, revealing her figure more than she was comfortable with."
    "She couldn't help but feel exposed under the watchful gaze of the Boss."
    dad "Banu, come in."
    "Banu entered the room, her eyes meeting the Boss's as she braced herself for whatever was to come. The atmosphere was tense, the air heavy with unspoken expectations."
    b "You wanted to see me?"
    dad "Come closer."
    scene v17-268
    dad "You look different today."
    "Banu's cheeks flushed slightly under his gaze. She had anticipated his comment, given the attire she was wearing. She knew that her appearance was now a tool, a means to an end in this world of manipulation."
    scene v17-269
    dad "You know, Banu, you're quite an attractive woman."
    "Banu's cheeks warmed at his words, and she tried her best to maintain her focus. She knew that the Boss's compliments were a calculated move, a way to disarm her and manipulate her emotions."
    dad "(Stepping even closer) It's a shame to see someone like you struggling. You deserve more, don't you?"
    scene v17-270
    b "I appreciate your words."
    dad "You see, Banu, I have the means to provide you with a better life. All you need to do is prove your loyalty to me."
    "Banu's heart raced as his words hung in the air. She understood the implication behind his proposition – that her loyalty would be linked to her compliance and submission."
    dad "You know, Banu, I've noticed your beauty since the first time you walked in here."
    scene v17-271
    dad "You're a smart woman, Banu. You know that opportunities come in many forms."
    dad "I trust you. I have a job that could prove your dedication and loyalty beyond any doubt."
    "Banu's heart raced as she listened, understanding that this offer would be a pivotal moment in her journey through this dangerous world."

    "She knew that the task he was about to propose could carry significant risks and consequences."
    dad "I need you to deliver a package – drugs – to a certain individual. It's a test of your commitment to this family."
    dad "You'll meet a contact, receive the package, and ensure its delivery. Simple, but it carries weight."
    b "And what happens after?"
    scene v17-272
    dad "Success in this task will earn you our trust and open doors for more opportunities."
    "Banu felt the weight of his words settling upon her shoulders. This was a crossroads, a decision that would determine her path within this world of danger and secrecy."
    dad "So, are you ready to take this step?"
    menu:
        "{color=#008000}Reject the job{/color}":
            $ renpy.block_rollback()
            $ banuacceptmafia = False
            scene v17-273
            b "I appreciate your offer, but I can't accept this task."
            "The room seemed to hold its breath for a moment, the tension palpable as the Boss's calculating gaze locked onto Banu's."
            dad "And may I ask why?"
            b "The path you're suggesting goes against my principles and values."
            dad "You understand that by rejecting this task, you might be closing doors in this world."
            b "I understand. But I have to stay true to who I am."
            b "I understand that my decision might not align with your expectations, but it's a decision I stand by."
            jump polad
        "{color=#FF0000}Accept the job{/color}":


            $ renpy.block_rollback()
            $ banuacceptmafia = True
            scene v17-273
            b "Alright. I'll accept the task."
            dad "Good. Loyalty can take many forms, Banu. You've made a wise choice."
            b "I understand the stakes, and I'm willing to prove myself."


            scene black with Dissolve(3)
            ""
            centered "{size=+120}...{/size}" with Fade(0.5, 0.5, 5)
            scene v17-274 with fade
            play music "audio/tension.mp3"
            "In the cover of night, the city's abandoned underground metro station stood as a stark reminder of the hidden corners of this dangerous world."
            "Banu's heart raced as she approached, clutching the bag containing the illegal cargo tightly in her hand."
            "The weight of the situation settled heavily upon her shoulders, and a cold sweat dampened her palms."
            scene v17-275
            "Banu's footsteps echoed softly against the concrete floor as she ventured further into the desolate space, her eyes scanning for any sign of the person she was supposed to meet."
            "Banu's gaze darted around, searching for any movement, any indication that she wasn't alone."
            scene v17-276
            "She clutched the bag tighter, her fingers trembling as doubt gnawed at the edges of her resolve."
            "Banu stood near a crumbling column in the dimly lit underground metro station, her senses heightened and her heart pounding."
            "The weight of the bag in her hand was a constant reminder of the task she had undertaken, the risks she had embraced. "
            scene v17-277
            "Minutes felt like hours as Banu continued to wait, her eyes never leaving the surroundings. "
            "Every sound, every flicker of movement, set her heart racing."
            "The shadows seemed to play tricks on her, dancing and shifting in the corners of her vision. Her grip on the bag of illegal drugs remained tight, her knuckles white with tension."
            scene v17-278 with fade
            "Out of the periphery of her vision, a figure emerged from the shadows, cloaked in a black hoodie that seemed to meld seamlessly with the darkness around them."
            "Before she could react, the figure was suddenly there, almost like a specter materializing from the shadows."
            scene v17-279 with hpunch
            "In the span of a heartbeat, the person's hand reached out and snatched the bag she held tightly in her grasp."
            "Panic surged through Banu's veins as the bag was wrenched from her fingers."
            "Her heart raced, her mind struggling to process the sudden turn of events. "
            scene v17-280 with fade
            "As Banu surged forward in pursuit of the thief, her determination driving her every step, she saw an opportunity to catch up."
            "In a desperate bid to stop the thief, she reached out with both hands, aiming to grasp him around his belly and halt his escape."
            "But in the chaos of the chase, Banu's focus on the thief's movement left her unprepared for the sudden change in momentum."
            "The thief's speed combined with Banu's forward momentum led to a collision that was as unexpected as it was forceful."
            scene v17-281 with vpunch
            stop music
            "Banu's heart raced as her body twisted and then, with a helpless lurch, she collapsed onto the cold, unforgiving ground of the abandoned metro station."
            "The bag of illegal drugs was gone, slipped through her fingers."
            "The realization that she had failed to fulfill the task she had accepted gnawed at her, a bitter taste of disappointment and regret."
            b_ "How did I let this happen? I had one chance to prove myself, and now... everything's slipping away."
            b_ "What am I going to do now?"

            jump mafia







    dev "{color=#000000}Thank you for playing! This is the end of this route in this version. Play again to discover more. If you enjoyed it please {a=https://www.patreon.com/lustfulfantasy}support{/a} the development. Please, add the game to your {a=https://store.steampowered.com/app/2505580/Life_in_Middle_East/}wishlist{/a} on Steam to make it grow. {/color}"
    hide screen faith
    hide screen angeldevil
    jump endings
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
