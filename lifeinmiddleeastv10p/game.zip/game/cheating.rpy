


label banusendturan_selfie:


    play music "audio/weakbanu.mp3"
    scene v19-236

    b "Okay, Turan. I'll do whatever you ask of me."

    t "Listen up, Banu. I want you to take off your panties and get that butt plug ready."

    scene v19-237

    t "Once you've got it, I want you to wet it up real good and stick it inside your asshole."

    t "Then, I want you to take a photo of your asshole with the butt plug in and send it to me. You got that?"

    "His words hit Banu like a punch to the gut, the weight of his demands crushing her beneath their oppressive force."

    "But despite her hesitation, she knows she has no choice but to comply, her fear of Turan's retribution outweighing her sense of self-respect."

    b "Yes, Turan. I understand."

    scene v19-239

    "Banu's heart weighs heavy with guilt as she casts a remorseful glance at Kamil, her eyes brimming with tears of shame. "

    b "I'm so sorry, Kamil... I never wanted any of this to happen."

    b "I'm sorry, babe. I really am."

    scene black

    "With a shaky hand, she starts to peel off her panties, all the while keeping her eyes glued to Kamil. "

    scene v19-240

    "She knows she's gotta do what she's gotta do, but that don't make it any easier, especially with her man lying there, oblivious to the mess she's in."

    b "I'm sorry, Kamil... I never wanted to hurt you like this."

    b "Shit, why am I feeling like this? It ain't right... I shouldn't be..."

    "Her inner voice is screaming at her to stop, but her body's screaming louder, aching and throbbing with need."

    scene v19-241

    "She squirms, trying to shake it off, but damn, it's like an itch she can't scratch, driving her crazy with every damn second."

    "She feels so horny..."

    b "Sorry, Kamil... but I can't help it. I just... I need this, you know?"

    b "God, I'm such a horny slut..."

    "Banu's body's screaming for attention, her pussy and asshole throbbing with a desperate need to be touched."

    "It's like every damn nerve ending's on fire, begging for release."

    scene v19-242

    "Banu's hand trembles as she retrieves the red, shiny butt plug, holding it delicately between her fingers."

    "She examines it closely, the polished surface gleaming in the dim light, a tantalizing promise of pleasure and pain."

    b_ "Damn, this thing..."

    "It's a reminder of forbidden desires, a symbol of her weakness and vulnerability."

    b_ "I shouldn't... but god, I want to."

    scene v19-243

    "Banu's heart races as she brings the red, shiny butt plug to her lips, her mouth watering with anticipation. "

    "With a determined breath, she parts her lips and slides the plug into her mouth, the smooth surface gliding against her tongue."

    scene v19-244

    b_ "Mmm... that's it.."

    "With a final lick, she withdraws the plug from her mouth, the surface gleaming with her saliva."

    "With trembling hands, she prepares to fulfill Turan's demands, the forbidden thrill of anticipation coursing through her veins."

    scene v19-245 with dissolve

    "Banu's breath hitches as she shifts onto her side, her heart pounding with a heady mix of nervousness and excitement."

    "With trembling fingers, she positions the slick, red butt plug at the entrance of her asshole, feeling a rush of anticipation course through her body."

    scene v19-246

    b "Okay, here goes..."

    "Her voice is barely above a whisper as she begins to push the plug into her tight opening."

    scene v19-247 with dissolve

    b "Oh god..."

    "Banu's eyes widen as the plug hits halfway, her body tensing up as her asshole stretches to accommodate it."

    "A sharp groan escapes her lips as the pain shoots through her."

    scene v19-248

    b "Oh, fuck..."

    "She grits her teeth, trying to push past the discomfort, but it's like her ass is fighting back against the intrusion. "

    b "Shit, it hurts so bad..."

    "With every breath, she tries to force herself to relax, to let the damn thing slide in, but it's like her body's refusing to cooperate."

    "It's a battle she's losing, inch by painful inch."

    scene v19-249

    "But she's not giving up."

    "She grits her teeth and pushes through the pain, determined to make it work."

    "With each agonizing second, she feels herself starting to adjust, the pain slowly fading into a dull ache."

    b "Come on, ahhhh... you got this..."

    "And as she finally manages to ease the plug all the way in, she lets out a shaky sigh of relief."

    scene v19-250

    "With a mix of defeat and determination etched on her face, Banu grabs her phone, her hands trembling slightly as she positions it to capture the moment."

    "Despite the discomfort and humiliation, she knows she has to follow through with Turan's demands."

    "Summoning all her courage, she raises her legs high, giving her phone a clear view of her butthole with the plug nestled snugly inside."

    scene v19-251

    "The pain lingers, but she pushes it aside, focusing on the task at hand."

    "Despite the discomfort and the shame, there's a glimmer of pride shining in her eyes."

    "A triumphant grin spreads across Banu's face as she revels in the satisfaction of proving Turan wrong."

    b "Ha! Take that, Turan."

    scene v19-252 with fade

    "With the plug snug in her asshole, Banu reclines on the bed, a mischievous glint in her eyes as she grabs her phone. "

    "With a sly grin, she selects the photo she just took and sends it off to Turan, accompanied by a teasing message."

    b "Hey there, Turan. Thought you'd like to see what I'm capable of. "

    b "Turns out, you were wrong about me. Looks like I'm full of surprises, huh?"

    "Banu's heart races with adrenaline as she finds herself fully immersed in the twisted game of cat and mouse with Turan. "

    "There's a rush of excitement coursing through her veins, a thrill unlike anything she's ever experienced before."

    t "You're full of surprises, Banu. I like that. How about we up the stakes a little?"

    t "I've got a few tasks in mind for you. Think you're up for the challenge?"

    b "Alright, Turan. I'm all ears. What do you have in mind?"

    "Banu's heart pounds in her chest as she reads Turan's command, a rush of anxiety flooding her senses."

    t "Get on all fours, right next to your sleeping hubby, and take a selfie of your ass. Send it to me, now."

    "She's come too far to back down, and she's determined to see this through to the end, no matter what it takes."

    b_ "I can do this. It's just a stupid picture."

    b_ "Forgive me, Kamil."

    scene v19-254 with fade

    "With Kamil sleeping peacefully beside her, she knows she's about to cross a line she can never uncross."

    "With shaky hands, she fumbles for her phone, her fingers trembling as she angling it to capture the desired image."

    scene v19-255

    "With a mix of shame and resignation, she snaps the photo, her cheeks burning with embarrassment as the camera clicks."

    "It feels like a betrayal, a violation of everything she holds dear, but in this twisted game she's playing, there's no room for hesitation."

    scene v19-252 with fade

    "With a heavy heart, she sends the photo to Turan, her stomach churning with guilt and uncertainty. "

    "She knows she's crossed a line she can never uncross, but in this dangerous game of cat and mouse, there's no turning back."

    "As their chat continues, Banu finds herself caught up in the twisted dance of flirtation and manipulation with Turan. "

    t "You're a naughty little thing, aren't you, Banu? I like that."

    b "Maybe I am, maybe I'm not. Guess you'll just have to find out."

    t "I like a woman who's not afraid to take risks. Let's see just how far you're willing to go."

    "Banu's heart skips a beat at Turan's words, a rush of adrenaline flooding her senses."

    b "Bring it on, Turan."

    scene v19-253

    "Banu's eyes widen in shock as she reads Turan's next task, her mouth falling open in disbelief."

    t "Alright, Banu. Here's what I want you to do. I want you to stand up, walk over to your husband's side, and take a selfie of your butt with the butt plug in."

    t "And make sure to capture your husband's face in the background. No excuses."

    b "Are you out of your mind? I can't do that!"

    t "Pathetic. I thought you had more guts than that, Banu. Guess I was wrong."

    "Banu's jaw clenches at the insult, her pride stung by Turan's taunts. "

    "She knows she shouldn't let his words get to her, but the thought of being seen as weak ignites a fire within her."

    b "Fine. I'll do it. "

    b "Just watch me, Turan. I'll show you."

    scene v19-256 with fade

    "With a steely resolve in her eyes, Banu sets her phone aside and rises to her feet, ready to face whatever challenges lie ahead."

    "She may be walking into the lion's den, but she refuses to let fear hold her back. "

    "This is her chance to prove Turan wrong, to show him that she's not as weak as he thinks. "

    "As Banu obeys Turan's command, a mixture of shame and arousal courses through her veins."

    "With trembling hands, she positions herself beside Kamil, the butt plug grinding inside her with every movement, sending waves of pleasure coursing through her body."

    scene v19-257

    "Banu's hands tremble as she reaches for her phone, her heart pounding with nervous anticipation. "

    "With a mix of guilt and arousal coursing through her veins, she positions herself beside Kamil, her body quivering with the taboo thrill of the moment."

    scene v19-258

    "Bending over Kamil's sleeping form, Banu's breath catches in her throat as she angles the phone just right, ensuring that both her butt and Kamil's face are in the frame."

    "With a shaky hand, she snaps the pic, the sound of the camera clicking echoing in the quiet room. "

    "It's a moment she'll never forget, a snapshot of her betrayal etched in digital ink."

    "As she looks at Kamil, still lost in dreamland, a pang of guilt hits her like a ton of bricks."

    "Banu's feeling like a rebel, ready to shock the hell out of Turan. With a sly grin, she's got a wicked idea up her sleeve."

    scene v19-259 with fade

    "She yanks out the butt plug, feeling that sudden rush of freedom mixed with a whole lotta excitement. "

    "The feeling of being empty just adds to the thrill."

    "Without skipping a beat, Banu lines up the shot and snaps a pic of her gaped asshole, capturing all that raw intensity. "

    "It's a move she knows will blow Turan's mind, showing him she's not one to mess with."

    scene v19-252 with fade
    stop music
    "With a mischievous chuckle, she sends the pic to Turan, feeling like a total badass."

    "She's not sure how he'll react, but one thing's for sure: she's just turned up the heat in their little game, and she's ready to see where it takes her."

    b "Looks like I just won this little game, Turan. Better luck next time."

    "She sits back, feeling like she's got the upper hand now. But Turan's quick to respond, and his words send a chill down her spine."

    t "Don't celebrate too soon, Banu. Tomorrow night, I'll be waiting for you in my bed."

    "Banu knows she's in deep now, and there's no turning back."

    "But as the anticipation builds, she can't help but wonder what Turan has in store for her tomorrow night."



    $ renpy.end_replay()
    $ persistent.banusendturan_selfie_unlocked = True
    jump banusendturan_selfie_continue



label ruslan_fuck_leyla_banu:





    stop music

    "Banu's cheeks burn with embarrassment as she realizes Ruslan's words are true."

    b "I... I'm sorry. I can't help it."

    scene v19-274 with dissolve

    "Banu's back presses against the cold surface of the door as Ruslan and Leyla advance, their naked bodies looming over her."

    "She can feel their hot breath on her skin, sending shivers down her spine."

    r "That's what I thought."

    r "That's right, Banu. You can't resist me, can you? You're just like all the others, weak and pathetic."

    b "I... I'm sorry, Ruslan. I don't know what came over me."

    r "Of course you don't. You're nothing but a horny slut, Banu. Admit it."

    b "I... I looked at your dick, okay? Are you happy now?"

    b "Leyla, let's get out of here already."

    scene v19-275

    r "You're not going anywhere, Banu."

    l "That's right, Mom. You're ours now."

    "Banu's heart races with fear and uncertainty as she feels trapped between them, her mind scrambling for a way out."

    b "Please, stop... This isn't right."

    scene v19-276

    "She tries to push them away, but they're relentless, their presence overwhelming."

    b_ "I... I shouldn't be looking at this."

    "But even as she tries to resist, the allure of Ruslan's hardness proves too tempting to ignore."

    b_ "God, what's wrong with me?"

    "But deep down, she knows the answer. She's drawn to Ruslan's arousal like a moth to a flame and Ruslan notices this."

    scene v19-277 with hpunch
    play music "audio/heatedsex.mp3"

    "As Ruslan grabs hold of Banu and Leyla locks her from behind, panic shoots through her veins like a bolt of lightning."

    "Trapped between them, she squirms and curses, her heart racing like a damn racehorse."

    b "Let me the hell go! This ain't right!"

    "But they ain't listening, no siree. "

    scene v19-278

    "Banu's breath catches as Ruslan's lips crash into hers, and she's torn between fightin' and lettin' herself get swept away."

    "He's all over her like white on rice, his hands roamin' all over her body while Leyla's got her locked up tight from behind."

    scene v19-279

    "Banu's strugglin' like a fish outta water, but it's like tryin' to break free from a steel trap."

    "Banu's mind's spinnin' faster than a tornado as she tries to reckon with the mess she's in."

    "She knows she should fight back..."

    "But it's like her brain's short-circuited, and all she can think about is the heat between her legs and the taste of Ruslan's kiss."

    scene v19-280

    "Ruslan shoves his big ol' dick between her legs, and before she knows it, he's mackin' on her like there's no tomorrow."

    b "Oh god... What's happening to me?"

    "Banu's breath catches in her throat as Ruslan's lips keep on workin' their magic."

    "In the midst of all the chaos, Banu's lettin' go and lettin' herself get swept away by the rush of lust and temptation."

    scene v19-281 with dissolve

    "With Banu stripped down to nothing but her skin, Ruslan wastes no time in getting down to business. "

    scene v19-282 with fade

    "As Leyla holds her steady, he positions himself at the entrance of her dripping wet pussy, his desire burning hotter than a summer day in the desert."

    "Banu's heart races in her chest as she feels Ruslan's throbbing member pressing against her, her body tingling with anticipation."

    "She knows she should resist, but the fiery desire coursing through her veins drowns out any rational thought."

    "She just wants to feel Ruslan's fat long dick inside of her more than anything else. "

    scene v19-283

    "With Banu laid bare before him, Ruslan takes a moment to savor the anticipation, his eyes blazing with desire as he gazes down at her."

    r "You ready for this, Banu? You ready for me to make you feel real good?"

    "His voice is a husky whisper, sending shivers down Banu's spine as she nods, her breath coming in shallow gasps."

    r "That's it, baby. Just relax and let me take care of you."

    r "You know you want this, don't you? You've been craving it ever since you laid eyes on me."

    "Banu's cheeks flush with desire as she feels Ruslan's hot breath against her skin, her body trembling with anticipation."

    r "You ready for this, baby?"

    "Banu nods eagerly, her eyes glazed with desire as she waits for him to take her."

    scene v19-284

    b "Ahhhhhh!"

    "With a primal growl, Ruslan thrusts forward, his hardness sinking deep into Banu's slick warmth."

    "She gasps in ecstasy as he fills her completely, her body arching with pleasure as he claims her as his own."
    stop music
    show ruslanfuckbanuleylahold
    play music "voices/slappingslow.mp3"
    r "Damn, what's with all that bush, huh? Thought you'd trim it up a bit for me."

    "From that moment on, it's pure bliss as Ruslan fucks her mercilessly, driving her wild with each powerful thrust."

    r "You like this, huh?"

    b "Yes, fuck me!"

    "Banu moans as Ruslan plunges deep into her, their bodies moving in perfect sync as they lose themselves in the heat of the moment. "

    "With each thrust, she cries out in ecstasy, her pleasure building higher and higher until she's teetering on the edge of oblivion. "

    "Ruslan fucks her with relentless passion, driving her wild with desire as she surrenders completely to the raw, primal pleasure coursing through her veins."

    "They're lost in the throes of passion, consumed by the fiery intensity of their connection as they ride the waves of ecstasy together."

    b "Oh god, yes! Right there, don't stop!"

    scene v19-285

    "As Ruslan pounds into Banu with unyielding force, Leyla moves closer, her lips finding Banu's in a heated kiss."

    "Banu's mind reels from the overwhelming sensation of both pleasure and confusion as she's caught between the fiery passion of Ruslan's thrusts and the softness of Leyla's touch."

    scene v19-286

    "Banu moans into Leyla's mouth, her body responding instinctively to the dual assault on her senses."

    "As Ruslan's relentless thrusts continue to drive Banu to the brink of ecstasy, his free hand finds its way between Leyla's thighs, his fingers expertly teasing her slick folds."

    b "Oh god, yes... that's it..."

    l "Feels so good, Ruslan... don't stop..."

    r "You both like that, huh? You want more?"

    b "Yes, fuck us harder!"

    l "Please, Ruslan... make us cum..."

    scene v19-287

    "Ruslan's movements send waves of anticipation through Banu's body as he pulls his throbbing member out of her, leaving her craving more."

    "Meanwhile, Leyla's kisses continue to inflame Banu's senses, leaving her breathless and wanting."

    b "Please, Ruslan... don't tease me... I need you inside me... now..."

    "Ruslan smirks, reveling in Banu's desperation as he continues to tease her dripping wet pussy with the head of his cock, denying her the release she craves."

    r "You want it, baby? You want me to fuck you like the dirty slut you are?"

    "Banu's eyes widen with need as she nods eagerly, her desire burning hotter than ever before. "

    scene v19-288 with dissolve
    stop music

    "Ruslan kicks back on the bed, ready to take control."

    "Banu gets flipped around, her back facing Ruslan while Leyla grabs hold of her ass, offering it up to him like a feast."

    scene v19-289

    b "Ahhhhhh..."

    "Ruslan wastes no time, slamming his hardness deep inside Banu with a ferocity that leaves her breathless."

    "Banu lets out a gasp of pleasure as he fills her up completely, her body tingling with excitement."

    "Leyla watches with hungry eyes, her hands gripping Banu's ass as she helps guide Ruslan's thrusts. "

    b "Oh god, yes! Right there!"

    l "Fuck, that's it! Take her, Ruslan!"

    r "You both like that, huh? You want more?"

    b "Yes, please! Don't stop!"

    l "Harder, Ruslan! Make her scream!"

    r "Get on all fours, both of you. Let's see what you've got."

    scene black

    "..."

    scene v19-291 with fade

    b "Oh god, yes... do it, Ruslan."

    l "Come on, Ruslan... fuck her good."

    "Ruslan positions himself behind Banu, his hands gripping her hips as he plunges deep inside her, eliciting a chorus of moans from both women."

    show ruslanfuckbanuleyladoggy
    play music "voices/slappingmedium.mp3"
    b "Fuck...it's so deep.."

    b "Harder, Ruslan! Give it to me!"

    b "Ohhhhh God..."

    b "AHHHHH...."

    l "Fuck....you're going to break her, Ruslan."

    b "Soooo....deeeeep..."

    r "Take this, slut."

    l "Damn, Ruslan, you're going so hard on your mommy."

    b "Ohhhhhh.....Ahhhhhhh...."

    l "She'll lose her mind if you don't stop."

    scene v19-290

    b "Oh fuck, that's it!"

    l "Damn, looks like she's enjoying it. Can't wait for my turn."

    "Ruslan's thrusts grow more urgent, driving Banu to the brink of ecstasy as Leyla watches eagerly, her anticipation mounting with each passing moment."

    l "Fuck her good, Ruslan. I want a piece of that too."
    stop music
    scene v19-292

    "Banu's eyes widen in shock as Ruslan withdraws from her and thrusts deep into Leyla with an intensity that sends shivers down her spine."

    "Leyla's screams echo through the room, her tongue hanging out in ecstasy as Ruslan pounds into her with relentless force."

    scene v19-293
    play sound "voices/slappingfastshort.mp3"
    b "Oh my god... he's really going at it."

    "She watches in a mix of disbelief and arousal as Ruslan takes Leyla to new heights of pleasure, his movements driving her daughter wild with desire."

    l "Fuck, yes! Harder, Ruslan!"

    "Banu can't tear her eyes away from the scene unfolding before her, a mixture of jealousy and excitement coursing through her veins as she watches her daughter being ravaged with such fervor."

    l "Oh god, it feels so good... I can't... ah!"

    b "Damn, Leyla... I didn't know he had it in him."

    l "Oh god, mom... it's... ah!"

    b "I'm sorry, Leyla... I didn't mean for this to happen."

    l "It's okay, mom... I wanted it too..."

    b "I just... I can't help but feel jealous watching him with you."

    l "I know, mom... but it's okay... ah!"

    r "Down on your knees, both of you."
    stop sound
    scene black

    "..."

    scene v19-294 with fade

    "Banu and Leyla exchange a nervous glance before complying, sinking to the floor before Ruslan."

    l "Please, Ruslan... cum on our faces."

    b "Um, I don't know about this..."

    l "Come on, mom, it's okay. Let's just do it."

    r "What's the matter, Banu? Scared?"

    scene v19-295

    "Ruslan smirks, enjoying the power he holds over them as he strokes himself, bringing himself closer to climax."

    r "Beg for it, sluts."

    "Banu and Leyla exchange a look of desperation before they begin to plead in unison."

    b "Please, Ruslan... "

    l "Yeah, we'll do anything... just please cum on us."

    scene v19-296 with hpunch
    play sound "voices/man2.mp3"
    "As Ruslan suddenly shoots a huge load onto their faces, Banu's eyes widen in shock, feeling the warm liquid splatter across her skin. "

    "She blinks rapidly, trying to process what just happened, while Leyla's face lights up with excitement, clearly pleased by the outcome."
    stop sound
    scene v19-297

    b "God...please forgive me..."

    l "Wow, that was amazing!"

    b "I... I can't believe we just did that."

    l "Come on, mom, it was fun! You should loosen up a bit."

    r "Looks like you both enjoyed that, huh?"

    scene v19-298

    "Banu and Leyla lock eyes, their faces close together as they inspect the aftermath of Ruslan's climax."

    "Leyla smirks mischievously as she gazes at the cum on Banu's face."

    l "Damn, mom, that was quite the load he shot on you."

    b "I-I know, it's... um, a lot..."

    l "Well, at least you got the full experience, huh?"

    b "Yeah, something like that..."

    l "Don't worry, mom, it's not like anyone's judging you. We're just having some fun, right?"

    "Banu nods, forcing a small smile, but inwardly she's still feeling flustered by the whole situation."



    $ renpy.end_replay()
    $ persistent.ruslan_fuck_leyla_banu_unlocked = True
    jump ruslan_fuck_leyla_banu_continue




label ahmedsfucksbanu_sofa:




    play music "audio/weakbanu.mp3"
    scene v19-307

    b "Chemistry? There's no chemistry here, Ahmed. You're just trying to manipulate me."

    ah "Manipulate you? No, Banu. I'm just being real. We both know there's something between us."

    b "There's nothing between us, Ahmed. I'm happily married, and I won't let you ruin that."

    ah "Happily married? Really? Then why are you here? Why you haven't left yet. Why do you keep coming back?"

    b "I... I don't know. Maybe I just wanted to make things right."

    ah "Make things right? Or maybe you just wanted to feel alive again. To feel desired."

    b "That's not true. I love my husband."

    ah "Do you? Or are you just trying to convince yourself? Because from where I'm standing, it looks like you're craving something more."

    b "It's not like that..."

    ah "You can't run from this, Banu. You can't run from yourself."

    b "Stop it, Ahmed. Just stop."

    ah "Stop? I can't stop, Banu. Not when I know how much you want this."

    b "I don't want this. I can't want this."

    ah "But you do, Banu. And it's okay. It's okay to want something more. Something real."

    b "No... I can't..."

    scene v19-309 with fade

    ah "Yes, Banu. You can. You just need to let go. Let go of the guilt, the shame, and embrace what you truly desire."

    b "I can't..."

    ah "Yes, you can. Just let me show you."

    b "Ahmed, please..."

    ah "Shh... It's okay, Banu. Just let yourself feel. Let yourself be free."

    b "I don't know what to do..."

    ah "You don't have to do anything, Banu. Just let me take care of you."

    b "Okay..."

    scene v19-310 with dissolve

    b "Ahmed, please..."

    ah "Shh, Banu. Let go. You know you want this as much as I do."

    "Ahmed's hands skillfully slid Banu's skirt down her legs, pooling at her feet, as he pulled her into an embrace."

    ah "You can't resist it, can you, Banu? Your pussy's weak, craving to be dicked down."

    ah "You need it. Admit it, Banu."

    b "I... I do... but..."

    ah "No buts, Banu. Just give in to what you desire."

    b "I can't believe I'm doing this..."

    scene v19-311 with dissolve

    "Banu's heart raced with a mixture of desire and guilt as Ahmed's lips found hers in a passionate kiss."

    "As they locked lips, Banu felt herself giving in to Ahmed's charm."

    "With each kiss, her resistance melted away, and she found herself swept up in the heat of the moment."

    scene v19-312 with dissolve

    "Ahmed skillfully stripped off Banu's top, revealing her luscious curves underneath."

    "Banu's heart raced as Ahmed's hands roamed over her skin, igniting a fiery passion within her."

    ah "You taste so good, Banu. You like that?"

    b "Mmm... yeah, Ahmed. Feels so good..."

    ah "You're so responsive, Banu. I can't get enough of you."

    scene v19-313 with dissolve

    "Next came her bra, unveiling her perky breasts."

    "Banu blushed, feeling exposed yet exhilarated under Ahmed's intense gaze."

    ah "You like that, Banu? Your nipples are so hard."

    b "Oh god, Ahmed! Feels amazing..."

    ah "I could do this all night, Banu."

    scene v19-314 with dissolve

    "With a mischievous grin, Ahmed peeled off Banu's panties, leaving her completely bare before him."

    "Banu stood there, feeling a rush of excitement and anticipation for what was about to happen next."

    scene v19-315 with dissolve

    ah "You ready for more, Banu?"

    b "Yes, Ahmed. Take me."

    ah "Hold on tight, sweetheart."

    "Banu's desire for Ahmed was consuming her every thought."

    "As he pinned her down on the sofa, she felt a surge of longing coursing through her veins. "

    "With each moment that passed, her yearning for him intensified, driving her wild with need. "

    "She was completely consumed by her desire for Ahmed, willing to give herself over to him completely."

    scene v19-316 with vpunch

    "Ahmed's fat cock slid into Banu's eager pussy, filling her completely. "

    "With each powerful thrust, he rocked her world, driving her to the edge of ecstasy."

    "Banu moaned with pleasure as Ahmed pounded her relentlessly, lost in the intensity of their passionate encounter."

    show ahmedfuckbanuonsofa
    stop music
    play music "voices/slappingslow.mp3"
    ah "You like that, Banu? My cock stretching out that weak pussy of yours?"

    b "Oh god, yes... you're so... so good, Ahmed..."

    ah "I bet your husband never fucks you like this, does he?"

    b "No... never like this... you're... you're amazing, Ahmed...Ahhhhh.."

    ah "That's right, Banu. Your pussy belongs to me now."

    b "Yes, Ahmed... yours... all yours..."

    ah "You knew from the moment you walked in here that I was going to fuck you, didn't you, Banu?"

    b "Ahhhhh....I... I..."

    ah "Admit it, Banu. You came here craving my cock, didn't you?"

    b "I... I couldn't resist..."

    ah "You're so easy, Banu. Your mind was weak from the moment you stepped through that door."

    b "Ahmed... please..."

    ah "Please what? Please fuck you harder? Please make you mine?"

    b "Yes... please... make me yours..."

    b "Ahmed... I can't... I can't hold it anymore..."

    ah "That's it, Banu. Let go. Give in to me."

    scene v19-317 with vpunch

    b "Oh god... yes... I'm yours... I'm yours..."

    "Banu reaches her peak, her face contorted in a mixture of ecstasy and defeat as her orgasm washes over her."

    ah "Look at you, Banu. You're a mess. If Kamil could see you now, he'd realize what a fucked-up woman he's married to."

    b "Don't... don't talk about Kamil..."

    scene v19-318

    ah "Why not? Afraid he'll see what a slut you really are? That he'll leave you once he knows?"

    b "Stop... please... just stop..."

    ah "Fuck... I'm gonna cum..."

    b "Yes... give it to me... fill me up..."

    scene v19-318 with vpunch
    stop music
    ah "Ahhhhhh...."
    play sound "voices/man3.mp3"
    "Ahmed releases all his seeds inside Banu as she welcomes his climax, feeling the warmth spreading inside her."
    stop sound
    scene v19-319 with fade

    "Ahmed sits in the corner of the sofa, observing Banu's naked body as she lays there, avoiding eye contact, feeling a mix of shame and regret wash over her."

    ah "Seems like you've had your fill, huh? Can't even lift yourself up."

    b "I... I don't know what came over me..."

    ah "Oh, I think you know exactly what came over you. And you loved every moment of it."

    scene v19-320 with fade
    play music "audio/intro.mp3"
    ah "You know, Banu, back in school, Kamil was always an easy target. I used to mess with him a lot."

    b "What? Why would you do that?"

    ah "Oh, you know how it is. Boys being boys. But now, look at us. It's like the roles have reversed, huh?"

    ah "Well, it's funny how things change. Now I'm the one in charge. And you... you're right here with me."

    scene v19-321

    ah "Damn, Banu, you've got it all. That fiery attitude, those killer curves, that gorgeous face... "

    ah "And let's not forget about that tight little pussy of yours. You're the whole package."

    b "Ahmed, can we please not talk about this?"

    ah "Aw, come on, Banu. You know I'm just stating the facts. You're irresistible."

    ah "If you stay laid down like that, I might just have to fuck you again, Banu."

    scene v19-322

    "Banu suddenly snaps out of her daze, sits up on the sofa and locks eyes with Ahmed. "

    b "No, Ahmed. That's not happening again."

    ah "You know you want it again, Banu. Don't pretend like you don't."

    b "This will be the last time, Ahmed."

    scene v19-323

    ah "Oh, come on, Banu. Don't act like you didn't enjoy every moment of it. I remember how you were moaning and begging for more just a few minutes ago."

    ah "Your body was practically screaming for me."

    b "That's not the point. I can't keep doing this."

    ah "But you will, Banu. Kamil can't satisfy you like I can."

    b "That's not true! I love Kamil, and I won't betray him again."

    ah "Oh, but you already have, Banu. And you'll do it again. Because you're addicted to me, to this feeling."

    scene v19-324 with fade
    stop music
    ah "Where are you going, Banu?"

    b "...."

    ah "We're not finished yet."

    scene v19-325

    b "Yes, we are. I've made my decision, Ahmed. I'm leaving."

    ah "You'll be back, Banu. You always come back."

    b "Goodbye, Ahmed. Don't expect me to return."





    $ renpy.end_replay()
    $ persistent.ahmedsfucksbanu_sofa_unlocked = True
    jump ahmedsfucksbanu_sofa_continue




label samirfucksbanu_bedroom:




    play music "audio/softromanticsex.mp3"

    "As Samir's fingers expertly caress Banu's wet pussy, she finds herself unable to resist the overwhelming pleasure. "

    "Her inhibitions melt away, replaced by a burning desire for more."

    b "Samir... I need you."

    sam "What do you mean, Banu?"

    b "I mean... I need you to take off your clothes and fuck me."

    scene v19-358 with fade

    "Samir, caught up in the moment and unable to resist Banu's desperate plea, quickly sheds his clothes."

    "With a hunger that matches Banu's, he positions himself between her legs, ready to fulfill her deepest desires."

    scene v19-359

    b "What are you waiting for?"

    "As Samir's thick, pulsating cock presses against Banu's quivering ass, she can feel the anticipation building within her."

    b "Don't tease me like this. I need you inside me."

    sam "You want it, Banu? You want me to fuck you with this big, hard cock?"

    b "Yes, Samir. Please, I need it. I need you to fuck me hard."

    scene v19-360

    "Samir continues to tease Banu, relishing in the power he holds over her desire. "

    "With each stroke of his throbbing member against her ass, Banu's need grows more urgent, her body craving the release only Samir can provide."

    scene v19-361 with dissolve

    b "Ahhhh....Samir..."

    "As Samir's thick shaft slides effortlessly into Banu's slick, eager pussy, she can't help but let out a guttural moan of ecstasy."

    "The sensation of being filled by him, of his hardness stretching her to her limits, overwhelms her senses, sending her spiraling into a realm of pure pleasure."
    stop music
    show samirfuckbanupussybedroom
    play music "voices/softmoan.mp3"
    b "Oh, Samir... Yes, just like that. Fuck me, baby."

    sam "You like that, huh? You like my cock deep inside you?"

    b "Yes, yes! Don't stop, Samir. I need more..."

    sam "You know, Banu, ever since I saw you in the office, I couldn't get you out of my mind."

    sam "I've dreamt about this moment, about fucking you until you scream my name."

    b "Oh, Samir... I've thought about it too."

    b "I've craved your touch, your cock... Give it to me, baby."

    sam "Tell me, Banu... Am I better than your husband?"

    sam "Do I fuck you better than he ever could?"

    b "I... I don't know, Samir. It's different... but I can't... I can't compare..."

    sam "Come on, Banu. You know the answer. Admit it. Say it out loud... Say that I fuck you better than your husband ever could."
    stop music
    scene v19-362 with fade

    "Banu's pulse races as Samir makes his bold move, sending a surge of wild excitement through her veins."

    "He suddenly stops and places his cock at the entrance of Banu's asshole."


    b "Samir... Wait... What are you doing?"

    sam "You know exactly what I'm doing, Banu. I'm going to fuck you in a way your husband never could."

    sam "I'm going to claim every inch of you... starting right here."

    menu:
        "Tell him to fuck your pussy":


            $ banuletsamirfuckherass = False

            $ renpy.block_rollback()

            b "Whoa there, Samir... Hold your horses."

            b "That's off-limits territory, cowboy. Let's keep it where it belongs."

            sam "Alright, alright... But don't act like you ain't tempted, Banu. I can see it in those eyes of yours. Maybe another time, huh?"

            show samirfuckbanupussybedroom

            "As Samir keeps pounding away, Banu's body is overwhelmed with pleasure. "

            "Their combined moans fill the room, echoing the intense passion between them."

            "With every thrust, they edge closer to the peak of their desire. Banu's back arches as she nears climax, and Samir's breath grows ragged with anticipation."

            scene v19-365 with fade

            "In a final, powerful thrust, Samir reaches his peak, his body trembling with release."

            "Banu feels him spill his warmth inside her, sending waves of pleasure coursing through her."

            scene v19-367
            play sound "voices/man1.mp3"
            "Banu and Samir were going at it like animals, totally lost in the heat of the moment. "

            "With a final surge of ecstasy, they both hit their peak, exploding together in an orgasmic frenzy."

            "Their eyes rolled back, riding the waves of pleasure as their bodies shook with release."

            "In that wild moment, they were completely in sync, their connection electric and intense."
            stop sound
            scene v19-368

            sam "You feel that? That's me filling up your hungry pussy with my cum."

            b "Oh god... I can't believe I let you..."

            sam "You loved it. Admit it, you're addicted to my cock now."
        "Let him fuck you in the ass":




            $ banuletsamirfuckherass = True

            $ renpy.block_rollback()

            "In the heat of their passion, Banu found herself unable to resist Samir's insistent desires."

            "With a mixture of anticipation and nervous excitement, she finally gave in to Samir's request, succumbing to the primal urge driving them both."

            "With a breathless nod, Banu surrendered to the forbidden pleasure, allowing Samir to take her to new heights of ecstasy."

            scene v19-363

            b "Oh, Samir... it's so... big..."

            sam "You can take it, baby. You know you want it."

            b "Yes... yes, I want it... I need it..."

            sam "That's it, take it all, just like that."

            b "Oh god, it feels so... intense..."

            scene v19-364

            sam "You're doing so well, Banu. You're so tight..."

            b "Harder... please, fuck my ass harder..."

            sam "You asked for it, baby. Here we go..."

            show samirfuckbanuassbedroom
            play music "voices/softmoan.mp3"
            b "Ahhhhhhh...."

            sam "You like that, huh? You like feeling my cock stretching your tight little ass?"

            b "Oh god, yes... it's so... intense..."

            sam "You're such a dirty little slut, aren't you? Taking my cock in your ass like this."

            b "Yes... I'm your slut... I want you to fuck me harder..."

            sam "You're begging for it now, huh? Begging for my cock to pound your ass."

            b "Please... please, fuck my ass harder... destroy me..."
            stop music
            scene v19-366 with vpunch

            sam "That's right, take it all, take every inch of my cock in your ass."

            b "Yes... yes... harder... harder..."

            scene v19-367 with vpunch
            play sound "voices/man1.mp3"
            "Banu and Samir were going at it like animals, totally lost in the heat of the moment. "

            "With a final surge of ecstasy, they both hit their peak, exploding together in an orgasmic frenzy."

            "Their eyes rolled back, riding the waves of pleasure as their bodies shook with release."

            "In that wild moment, they were completely in sync, their connection electric and intense."
            stop sound
            scene v19-368

            sam "You feel that? That's me filling up your tight little ass with my cum."

            b "Oh god... I can't believe I let you..."

            sam "You loved it. Admit it, you're addicted to my cock now."



    scene v19-369 with dissolve

    b "Get off my back, kid."

    sam "I'm comfy right here, Mrs. Banu."

    b "Seriously, though, we should talk."

    scene v19-370 with fade

    sam "Sure, what's on your mind?"

    b "This can't happen again, Samir. It was a mistake."

    sam "I get it. But you can't deny, it was pretty incredible."

    b "That's not the point. You're young, and I'm married. This can't continue."

    sam "Agreed. Friends?"

    scene v19-371

    b "You know, you've got quite the confidence for a young intern."

    sam "Maybe I learned a thing or two from working with you."

    sam "So...why do you cheat on your husband?"

    b "..."

    b "It's complicated, Samir. Sometimes, things just happen."

    sam "But you're married. Isn't that supposed to mean something?"

    b "It does, but sometimes people find themselves in situations they never expected."

    scene v19-372 with fade

    sam "Do you ever regret it, Banu? Cheating on your husband?"

    b "Sometimes... but in the moment, it's hard to think about anything else."

    sam "What about him? Your husband, I mean. Does he know?"

    b "No, and I'd like to keep it that way. It would destroy him."

    scene v19-373

    sam "Do you ever think about staying faithful to him?"

    b "Yeah, I don't want to hurt him."

    sam "You won't hurt him if he doesn't know. It's your choice, Banu."

    b "I know, but... it's complicated."

    sam "Hey, don't worry, I won't tell your husband about our little... session."

    sam "Of course, wouldn't want to ruin your marriage or anything."

    b "Yeah, that would be... bad."

    scene v19-374

    b_ "I can't believe he's joking about this."

    "As Samir leaves, Banu is left alone with her thoughts. She reflects on what just happened, feeling a mix of guilt and regret wash over her. "

    "Despite the temporary pleasure, she knows deep down that what she did was wrong."


    stop music


    $ renpy.end_replay()
    $ persistent.samirfucksbanu_bedroom_unlocked = True
    jump samirfucksbanu_bedroom_continue







label poladfuckbanubathcheatroute:






    scene v19-396 with fade

    "In a bold move, Polad reaches around and unclasps Banu's bra, exposing her bare breasts."

    "Banu's heart pounds in her chest as she feels his touch, a mix of fear and excitement coursing through her veins. "

    "With a gentle yet insistent motion, Polad turns her around and begins to kiss her neck from behind."

    "She struggles with conflicting emotions, torn between the passion of the moment and the guilt of betrayal."

    scene v19-397

    "As Polad's tongue traces a tantalizing path along Banu's neck, he whispers dirty words to her ear."

    "She feels herself losing control, her body responding to his touch despite her inner turmoil."

    p "You know, Banu, Alper always said you were the most beautiful woman he'd ever seen. He was lucky to have you."

    b "Stop it, Polad."

    p "But you're still here, Banu. And I can't resist you any longer."

    b "Please, Polad..."

    p "You've always known there was something between us, Banu. Let's not deny it any longer."

    b "But.... Kamil.... He's my husband."

    p "Kamil doesn't deserve you, Banu. You deserve someone who can truly appreciate you."

    p "Tell me, Banu. Tell me you love me."

    b "I... I can't..."

    scene v19-398

    b "Ohhhh...Polad..."

    p "You've always loved me, Banu. Admit it."

    b "I... I..."

    p "Say it, Banu. Say you love me."

    b "I love you, Polad."

    b "Please..."

    b "Take me, Polad."

    p "You want me to take you, Banu? You want me to show you how a real man can satisfy you?"

    b "Yes... Please..."

    scene v19-399 with fade

    p "You ready for this, Banu?"

    b "Yes, Polad. I want it."

    p "You sure? Once I'm in, there's no going back."

    scene v19-400

    b "I'm sure. Just do it."

    p "Damn, Banu. You feel so good."

    b "Oh god, Polad. Don't stop."

    p "You're mine now, Banu. All mine."
    stop music
    scene v19-401 with fade
    play music "audio/heatedsex.mp3"
    p "You like that, Banu? You're mine now, no going back."

    b "Yes, Polad! Harder!"

    p "You're mine, Banu. Say it."

    b "I'm yours, Polad! Oh god!"

    p "That's right, mine. Nobody else's."

    b "Yes, yours! Only yours!"

    scene v19-402

    p "You're such a slut, Banu."

    b "Ahhhh... yesss..."

    p "Fucking your dead husband's best friend and now your current one's."

    b "Stop... please..."
    stop music
    show poladfuckbanubathroomkamildrunk
    play music "voices/slappingmedium.mp3"
    b "Ahhhhhh....you're going so deep...ohhhh.."

    p "I'll fuck you until you can't walk straight tonight."

    b "Ohhhh...shit...if you continue, I'll cum on your....big dick..."

    p "I won't stop, Banu..."

    p "I'll spoil you..."

    p "I'll cum deep inside of you where Kamil can't even reach."

    p "I'll fuck the shit out of you tonight."

    b "Ohhhhh...shit...I'm so close..."

    b "If you keep this....Ahhhhh..."

    b "You're such an evil man.....ahhhhh..."

    b "Polad....ohhhh...shit.."

    scene v19-403 with hpunch

    b "Cumminggg....ahhhhhh..."

    b "...."

    p "You love it, don't you?"

    p "Being fucked by a real man?"

    p "Answer me, slut!"

    b "Yes, yes! I love it!"

    p "Your husband can't satisfy you like this, can he? Pathetic little man."

    scene v19-404

    b "Please... stop..."

    p "You're just a horny slut, Banu. Admit it. You need me."

    b "I... I don't... please..."

    p "Say it! Say you need me!"

    b "Yes... yes, I need you..."

    scene v19-405 with vpunch

    b "AAAAAHHHHHHHH...."

    "As Polad thrusts with such power, Banu's vision blurs, and she feels like she's seeing stars."

    p "Your husband will hear this for sure."

    b "Oh... oh god..."

    p "You like that? You like it when I take control?"

    b "Yes... yes, I do..."

    b "Ohhh God...why did you stop?"

    p "Tell me, Banu, how bad do you want it? How badly do you crave my thrust?"

    b "I want it so bad, Polad... I need it... Please..."

    p "That's what I thought. Beg for it, Banu."

    b "Please, Polad, give it to me... I can't take it anymore... I need your thrust..."

    p "That's it, Banu. Now you'll get what you asked for..."

    scene v19-406 with hpunch

    b "Ahhhhhhhhhhhhh...."

    "After making Banu beg, he thrusts so hard that Banu loses her mind."

    scene black with dissolve

    p "You wanted it so bad, Banu. Now take it like the dirty little slut you are."

    "Polad grabs Banu by her hair bun and bends her over, thrusting into her relentlessly from behind."

    scene v19-407

    p "Say that your husband's a pathetic cuck."

    b "I can't... please, Polad, stop..."

    p "You will say it, Banu. Or I'll stop right now."

    b "Fine... Kamil... you're just... a pathetic cuck... aghh..."

    scene v19-408

    p "Louder."

    b "Yes... yes... Kamil's... ah... he's just a pathetic cuck... ahh..."

    p "You know what, Banu? Next time I'm gonna cum on your pussy, it'll be like adding seasoning to Kamil's dinner."

    b "No... please... don't say that..."

    p "Oh, I will, Banu. And you'll enjoy every moment of it, won't you?"

    p "You know what, Banu? Next time, I'll come and fuck you while Kamil is sleeping right next to you."

    b "No... Please, Polad, don't say such things..."

    p "Why not? It's the truth, isn't it? He's too weak to satisfy you, anyway."

    scene v19-409 with hpunch
    stop music

    "The sudden sound of footsteps and voices outside the bathroom interrupted their passionate moment."

    "Banu froze, her heart pounding in her chest, while Polad's expression shifted to one of alarm."

    "Banu strained to hear over the pounding of her own heart as Kamil's voice grew closer, accompanied by the creaking of the door."

    scene v19-410 with fade

    k "Banu, what's going on? I heard voices, is everything okay?"

    b "Oh, Kamil, it's nothing. I was just... singing in the shower. You know how I love to sing."

    scene v19-411

    k "But it sounded like... Never mind."


    "As Kamil entered the room and closed the door behind him, Banu's heart pounded in her chest with anxiety."

    "As Kamil moved closer to the shower, Banu's heart raced with panic. She quickly extended her hand, gesturing for him to stop."

    scene v19-412

    b "Wait, Kamil, don't come any closer...I... I feel a bit shy right now."

    k "Banu, what's going on? You're acting strange."

    b "I guess... I just don't feel comfortable right now. I wasn't expecting you to come in while I was... changing."

    k "Okay, I understand...."

    b "Kamil, honey, you're pretty drunk right now. "

    b "And the floor here in the bathroom can be slippery. Why don't you go back to the room and chat with Nesrin? I'll be out in a minute."

    scene v19-413

    "Kamil scratched his head, his drunken gaze unfocused."

    k "Nah, I'm good here..."

    k "Besides, it's nice talking to you, Banu."

    "Banu forced a smile, hoping her discomfort wasn't too evident."

    scene v19-414
    play music "audio/intro.mp3"
    k "Banu, you're my world."

    "Kamil began, his voice laced with emotion."

    k "I don't know where I'd be without you. You're the light in my life, the one who makes every day brighter."

    b "Kamil..."

    k "You think I'm drunk....no...I'm not drunk..."

    k "You're the most beautiful woman I've ever known..."

    k "And I'm so grateful to have you by my side. I love you more than words can express, Banu."

    "As Kamil poured out his heart, Banu felt Polad's presence drawing nearer, his naked form pressing against her from behind."

    "She tensed, her body stiffening at the unexpected contact, even as she struggled to maintain her composure."

    scene v19-415

    "Banu listened intently to Kamil's heartfelt words, her heart swelling with a mixture of admiration and guilt."

    "As Kamil poured his emotions out, expressing his deep love for her, Banu couldn't help but be moved by his sincerity."

    k "Banu, I need to talk to you about something."

    k "I've been thinking a lot lately, and... I'm worried about Polad."

    b "Polad? What about him?"

    k "I don't trust him, Banu. I think he... he wants more from you than just friendship."

    b "Oh, Kamil, you know Polad and I have been friends for years. He's like a brother to me."

    k "I know, but... I've seen the way he looks at you, the way he talks to you. It makes me uncomfortable."

    k "I can't shake this feeling. I need you to promise me, Banu. Promise me you'll be careful around him."

    scene v19-416

    b "Of course, Kamil. I promise. I'll always put our marriage first, no matter what."

    b "Kamil, I promise, whatever it is, I'll handle it. You have nothing to worry about, okay? Just trust me."

    b "Polad can't do anything to me, Kamil. I won't let him. Don't worry about...."
    stop music
    scene v19-417

    b "Igggggghhhhh...."

    k "What happened, Banu?"

    b "Kamil, um... I... I think I just felt something... strange."

    k "What do you mean? Are you okay?"

    b "I'm not sure... It's just... I think maybe I'm not feeling well."

    scene v19-418

    "Polad's fingers violated Banu's asshole while she was confronting Kamil."

    k "Should I get you some water? Or maybe we should call a doctor?"

    b "No, no, it's not that serious... I think... I'll be fine."

    k "Banu, you're shaking. Are you sure you're alright?"

    b "Yes, Kamil, really. It's just... a little discomfort."

    scene v19-419

    "Banu and Polad whisper to each other, and Banu warns him to stop or Kamil will become suspicious."

    "Polad's fingers masturbate her asshole relentlessly."

    b "Polad, take your fingers out, please...he'll suspect..."

    p "Only if you tell him that he's a weak man."

    p "Come on, say it. Tell Kamil what you really think of him."

    b "No, I won't. Stop this, Polad."

    scene v19-420

    p "You know you want to. Otherwise, I'll have to make you feel it."

    b "Please, don't. Kamil doesn't deserve this."

    p "Then say it."

    k "Banu, what are you thinking? You look strange."

    b "I think....that...you're a weak man!"

    k "Why would you say something like that?"

    b "I don't know...It's just how it is..."

    p "Good girl...Now tell him that I'm a better man than him."

    b "Polad..."

    p "Tell him! or I'll destroy your asshole in front of him."

    scene v19-421

    b "Kamil, I... I'm sorry, but Polad is a better man than you."

    k "What? How can you say that?"

    b "I don't know, Kamil... I just... I feel like he understands me more."

    scene v19-422

    k "But... we're married, Banu. I love you."

    b "I know, Kamil, but... I don't know if that's enough."

    k "Please, Banu... don't say that. We can work through this."

    b "I don't know, Kamil... I just don't know."

    b "Please, leave now..."


    $ renpy.end_replay()
    $ persistent.poladfuckbanubathcheatroute_unlocked = True
    jump poladfuckbanubathcheatroute_continue






label banu_makehassan_cum:





    b "I'll make you cum, but only if you promise to keep everything between us a secret. Kamil can never know."

    hs "Of course, Banu. Your secret is safe with me."

    scene v19-444 with fade

    "Banu hesitates, her mind swirling with conflicting emotions, but ultimately she complies, sinking to her knees before Hassan."

    b "I can't believe I'm doing this..."

    hs "But you are, Banu. Because deep down, you know you want it."

    scene v19-445

    "Hassan's cock springs free, thick and pulsing with desire. Banu's breath catches in her throat as she stares at it, feeling a surge of anticipation."

    hs "Come on, Banu. Don't keep me waiting."

    b "You are such a disgusting man...cheating on my daughter with me...."

    hs "Shut your mouth, you filthy whore! You're the one who's been begging for this all along."

    b "I'd never beg for anything from a scumbag like you. I'll do this only to protect my family, not because I want to please you."

    hs "Your face looks so innocent and sexy right now so I want to wash it with my cum so bad."

    b "You're disgusting."

    show banustrokehassancock
    play music "voices/makeout.mp3"
    hs "Shit...that's good... keep stroking that..."

    b "Hurry up and cum. I don't have much time for you."

    hs "I knew you were a slut, Banu. Stroking your son-in-law's cock next to your sleeping husband."

    hs "Damn, he's such a cuck...but you know, Banu, he deserves this...ohhh shit...his stupid ass deserves your cheating."

    b "Shut your fucking mouth already! I don't have much tolerance."

    hs "Shit..your grip is so tight...Do you do this on purpose?"

    hs "I have to warn you, Banu, I'm not an easy-cummer."

    hs "You have to work for it."

    b "Ahhh...shit...cum already..."

    hs "What? Are you tired already?"

    "Banu feels a rush of determination to assert her dominance over Hassan, seeing it as a game she must win."

    "She focuses on stroking him faster, eager to finish him off and claim her victory."

    hs "If you want to finish this fast, you better use your mouth."

    hs "As I said, it's not that easy to make me cum. "

    menu:
        "Just finish him":


            $ banusuckhassancock = False

            $ renpy.block_rollback()

            b "Come on, you worthless piece of shit. Let's get this over with."

            hs "Oh, you're enjoying this, aren't you? Stroking my cock like the slut you are."

            b "Shut up and cum already. I've got better things to do than deal with scum like you."

            hs "Mmm, that's it. Stroke it faster. You're so good at being a dirty little whore."

            b "I'm only doing this to get rid of you. Once you're done, get out of here and never come back."

            hs "You can't resist me, can you? Admit it, you love being my slut."

            b "I'd rather be anything than be associated with a pathetic loser like you. Now cum, and get out of my sight."

            hs "Ohhh...shit...slow down, bitch..."

            b "There you go, you disgusting pig. Cum for me."

            hs "Yeah, that's it... I'm cumming..."
            stop music
            scene v19-446 with dissolve

            hs "Ohhhh...shit..."
            play sound "voices/man3.mp3"
            b "That's right, cum like the worthless dog you are. I win."

            hs "You think you've won? You're just a slut... a cheap whore..."

            b "Keep telling yourself that, Hassan. But we both know who's in control here."
            stop sound
            scene v19-448

            hs "Eat it, you filthy whore. Clean up your mess."

            b "Get the fuck out of this room, Hassan. You've got what you wanted. Now leave."

            hs "I said eat it! You're nothing but a cum-hungry slut."

            b "I'm not touching that filth. Get out before I do something you'll regret."

            hs "Fine. But remember, Banu, I can make your life a living hell if I want to."

            b "I'm not afraid of you. Now leave, and don't you dare come near me again."

            hs "We'll see about that, whore."
        "Suck his dick":







            $ banusuckhassancock = True

            $ renpy.block_rollback()
            stop music
            scene v19-450 with fade

            "Banu hesitates for a moment, weighing her options. She knows she's stooping low, but the thought of ending this ordeal quickly pushes her to act."

            "With a deep breath, she leans in and takes Hassan's cock into her mouth."

            scene v19-451 with fade

            hs "Oh, you dirty bitch."

            "Banu ignores his comment, focusing on the task at hand. "

            "She sucks and strokes his cock with determination, willing him to cum quickly so she can be done with this humiliating situation."

            show banusuckhassancock
            play music "voices/suckdick.mp3"
            hs "That's it, slut. Suck it good."

            "Banu blocks out his degrading words, continuing her efforts. "

            "She feels a sense of desperation rising within her, wanting nothing more than to finish him off and rid herself of his presence."

            hs "Come on, slut. You want to make me cum, don't you? Let's see those tits of yours."

            "Banu's blood runs cold at Hassan's suggestion, but she knows she needs to get through this ordeal one way or another."

            "With a deep breath, she considers his proposition."

            menu:
                "Take off your top":


                    $ banutakeoffhertophassan = True

                    $ renpy.block_rollback()

                    scene v19-452 with fade

                    hs "Yeah, that's it, baby. Show me those tits. Let me see those nipples."

                    hs "Come on, you know you want to please me. You want to make me cum, don't you?"

                    b_ "I'll do whatever it takes to get him out of here."

                    scene v19-453




                    hs "Ohhh...shit...slow down, bitch..."

                    b "There you go, you disgusting pig. Cum for me."

                    hs "Yeah, that's it... I'm cumming..."
                    stop music
                    scene v19-447 with dissolve

                    hs "Ohhhh...shit..."
                    play sound "voices/man3.mp3"
                    b "That's right, cum like the worthless dog you are. I win."

                    hs "You think you've won? You're just a slut... a cheap whore..."

                    b "Keep telling yourself that, Hassan. But we both know who's in control here."
                    stop sound
                    scene v19-449

                    hs "Eat it, you filthy whore. Clean up your mess."

                    b "Get the fuck out of this room, Hassan. You've got what you wanted. Now leave."

                    hs "I said eat it! You're nothing but a cum-hungry slut."

                    b "I'm not touching that filth. Get out before I do something you'll regret."

                    hs "Fine. But remember, Banu, I can make your life a living hell if I want to."

                    b "I'm not afraid of you. Now leave, and don't you dare come near me again."

                    hs "We'll see about that, whore."
                "Just finish him":




                    $ banutakeoffhertophassan = False

                    $ renpy.block_rollback()






                    hs "Ohhh...shit...slow down, bitch..."

                    b "There you go, you disgusting pig. Cum for me."

                    hs "Yeah, that's it... I'm cumming..."
                    stop music
                    scene v19-446 with dissolve

                    hs "Ohhhh...shit..."
                    play sound "voices/man3.mp3"
                    b "That's right, cum like the worthless dog you are. I win."

                    hs "You think you've won? You're just a slut... a cheap whore..."

                    b "Keep telling yourself that, Hassan. But we both know who's in control here."
                    stop sound
                    scene v19-448

                    hs "Eat it, you filthy whore. Clean up your mess."

                    b "Get the fuck out of this room, Hassan. You've got what you wanted. Now leave."

                    hs "I said eat it! You're nothing but a cum-hungry slut."

                    b "I'm not touching that filth. Get out before I do something you'll regret."

                    hs "Fine. But remember, Banu, I can make your life a living hell if I want to."

                    b "I'm not afraid of you. Now leave, and don't you dare come near me again."

                    hs "We'll see about that, whore."




    $ renpy.end_replay()
    $ persistent.banu_makehassan_cum_unlocked = True
    jump banu_makehassan_cum_continue



















label cheating:



    scene black with Dissolve(3)
    ""
    centered "{size=+120}1 year later...{/size}" with Fade(0.5, 0.5, 5)
    scene black with dissolve
    b_ "During the past one year, I found myself entangled in a web of deceit and temptation, all behind Kamil's unsuspecting back."
    b_ "Each lie I told, each clandestine encounter, left a bitter taste of guilt in my mouth."
    b_ "Deep down, I knew I was hurting the man I should have respected the most."
    b_ "Despite my transgressions, I craved change. I longed to be the devoted wife that Kamil deserved."

    b_ "Yet, I found myself repeatedly falling back into the same patterns, unable to resist the lure of forbidden desires."
    scene v18-284 with dissolve
    b_ "But there was a turning point, a glimmer of hope amid the darkness. "
    b_ "Leyla's marriage brought a genuine smile to my lips."
    scene v18-285
    b_ "Her happiness served as a beacon, reminding me of the love and warmth that family could provide."
    b_ "Around the kitchen table, with Leyla and her husband, there were moments of shared laughter and genuine affection."
    scene v18-286
    b_ "It was a stark contrast to the secrets I had hidden, a reminder that goodness still existed within me."
    b_ "I made a silent vow, a promise to myself and to Kamil."
    b_ "I resolved to leave behind the shadows of my past, to embrace the light of honesty and fidelity."
    b_ "In the warm embrace of my family, I sought redemption, yearning for a chance to mend the fractures in my relationship with Kamil."
    b_ "It was a journey I embarked upon with a heart heavy with regret, but a determination to make amends and rebuild the trust I had shattered."
    scene v18-287 with fade
    b_ "In the quiet serenity of the park, Kamil and I found solace on a bench, beneath the dappled sunlight filtering through the leaves."
    b_ "As I nestled into his arms, an unspoken understanding passed between us."
    b_ "The weight of my secrets, the darkness of my past, pressed heavily on my shoulders."
    b_ "How could I undo the tangled web of lies and deceit I had woven around us?"
    scene v18-288
    b_ "Kamil, blissfully unaware of my transgressions, believed in the purity of our love."
    b_ "He saw in me a devoted wife, faithful and true. "
    b_ "Little did he know of the storms that raged within my soul, the guilt that clawed at my conscience."
    b_ "And yet, in that moment, I resolved to bury my past deep within me."
    b_ "I clung to Kamil, my silent plea for forgiveness echoing in the warmth of our embrace. "
    b_ "Determined to mend the cracks in our relationship, I showered him with unexpected attention."
    b_ "My gestures of love were genuine, fueled by a desperate desire to be the woman he deserved."
    b_ "Kamil, pleasantly surprised by my newfound affection, embraced my efforts with open arms, blissfully unaware of the darkness I struggled to leave behind."
    scene black with dissolve
    b_ "In the dead of night, haunted by the shadows of my past, I'd often wake in a cold sweat, heart racing from the nightmares that plagued my sleep."
    scene v18-289 with dissolve
    b_ "Beside me, Kamil lay, his innocent face serene in the soft glow of the moonlight filtering through our window. "
    b_ "How could I have strayed so far, indulging in the darkness that threatened to consume me?"
    scene v18-290
    b_ "Guilt washed over me like a relentless tide, drowning me in remorse for the sins I had committed."
    b_ "In those quiet moments, I made silent promises to myself and to the man I loved. "
    b_ "Determination flickered in my heart as I vowed to be the wife he deserved, to banish the ghosts of my past and embrace the love that Kamil offered so freely."
    scene v18-291
    b_ "As he slept, unaware of the turmoil that churned within me, I would press soft kisses on his cheek, a whispered reassurance of my commitment."
    b_ "In those tender moments, I found solace, clinging to the hope that my love for him would prevail over the darkness that threatened to pull me under."
    scene black with dissolve
    play music "audio/intro.mp3"
    b_ "The next day my heart pounded in my chest as I asked Kamil to drop me off in the bustling heart of the city."
    scene v18-292
    b_ "I had told him I was heading to my friend's house, but in reality, I was walking back into a chapter of my life I had been desperately trying to close."
    b_ "As I stepped out of Kamil's car, my heart raced with both anticipation and fear."
    scene v18-293
    b_ "The city around me buzzed with its usual energy, but inside, I felt a whirlwind of emotions."
    b_ "With each footstep that carried me closer to Polad's apartment, the weight of my past transgressions bore down on me."
    scene v18-294
    b_ "I had made the decision to end things with him, to sever the ties that bound me to this forbidden affair."
    b_ "I wanted to be the loyal wife Kamil deserved, even if it meant confronting the darkest parts of my soul."
    b_ "The door to Polad's apartment loomed before me, a portal to a past filled with passion and secrecy."
    b_ "I squared my shoulders, determined to face this moment head-on. It was time to say goodbye to the old me, to the woman who had let her desires lead her astray."
    b_ "With trembling hands, I knocked on the door, my heart echoing the rhythm of my anxiety."
    scene v18-295
    b_ "As the door creaked open, I steeled myself for the difficult conversation ahead."
    b_ "My mind was a battleground, torn between the familiar allure of the past and the newfound determination to be faithful to Kamil."
    b_ "I knew I had to be strong, to confront the truth and emerge from this encounter changed."
    b_ "Inside the apartment, I found Polad waiting, his eyes holding a mix of recognition and surprise."
    b_ "I took a deep breath, ready to face the consequences of my actions."
    b_ "It was time to put an end to this affair, to close this chapter and step back into the light of my husband's love."
    scene v18-296
    stop music
    b_ "As I stood there, attempting to gather the strength to end things with Polad, my words hung in the air, suspended between us like a fragile thread."
    b_ "My eyes drifted to his muscles and I admired them again."
    b_ "He came closer to me trapping me in his presence again."
    scene v18-297
    b_ "He was almost touching me. I noticed his big bulging dick in his pants."
    b_ "His hot breath touched my face. I almost lost myself for a moment."
    b_ "I told him to stay away. But he didn't seem to hear me, his eyes glinting with a mixture of defiance and desire. In that moment, my resolve wavered."
    scene v18-298
    b_ "I found myself entranced once more by the charisma that had drawn me to him in the first place."
    b_ "His voice, smooth as silk, wrapped around me, pulling me back into the web of emotions I had been trying so hard to escape."
    b_ "His body, strong and alluring, seemed to taunt me with its familiarity. I couldn't bring myself to meet his gaze, knowing that his eyes held a power over me, a power that I was helpless to resist."
    b_ "My heart, once determined to sever our connection, now beat erratically in my chest. I admired him again, fell back into the depths of my infatuation."
    b_ "His every word, every gesture, stirred something deep within me. Despite my best intentions, I found myself drowning in the same emotions that had led me astray before."
    scene v18-299
    b_ "His grip tightened around my arm, his fingers digging into my skin, anchoring me in place."
    b_ "I felt a surge of panic, a realization that I was once again ensnared in his control. "
    scene v18-300
    b_ "The strength I had mustered to end this affair dwindled in the face of his dominance."
    b_ "I struggled against him, but his grasp was unyielding, as if he knew exactly how to keep me captive."
    b_ "My mind raced, desperately searching for an escape route."
    scene v18-301
    b_ "I wanted to pull away, to break free from him and the allure he held over me."
    b_ "But his proximity, the scent of his cologne, the warmth of his touch, paralyzed my will."
    b_ "In that moment, I was no longer Banu, the strong-willed woman striving to be faithful to her husband."
    b_ "I was caught in the magnetic pull of Polad, a force that rendered me powerless against his charms."
    scene v18-302 with fade
    b_ "Moments later he was on top of me and we were both naked."
    b_ "He was again fucking me, making me his woman. "
    b_ "As I looked into his eyes, a mixture of fear and desire clouded my vision."
    b_ "I moaned and told him to fuck me harder."
    scene v18-303
    b_ "And he ravaged me."
    b_ "I knew I needed to resist, to find the strength to push him away and reclaim my freedom."
    b_ "But deep down, a part of me hesitated, entangled in the complex emotions that bound us together."
    b_ "The battle within me raged on, torn between the love I had for my husband and the irresistible pull of the man on top of me."
    scene v18-304 with fade
    b_ "He made me get on top and take control."
    b_ "I tried my best to be the one who was leading but I had little power left."
    b_ "His presence was overwhelming, casting a shadow that dimmed my resolve. I felt my strength ebbing away, like sand slipping through my fingers."
    scene v18-305
    b_ "I couldn't help my body but came one after another."
    b_ "Every word he spoke, every glance he threw my way, seemed to chip away at my defenses."
    b_ "I was acutely aware of how powerless I was against his charm, his charisma, his raw masculinity."
    scene v18-306
    b_ "Each moment in his presence, I found myself losing ground, surrendering to the intoxicating allure that he emanated."
    b_ "I came to end our relationship but I was having sex with him instead."
    b_ "It was as if he held the strings to my emotions, pulling me closer with every gesture, every touch."
    scene v18-307
    b_ "I jumped up and down on his dick while his strong muscles crushing my body."
    b_ "My resistance crumbled in the face of his magnetic pull, and I became a mere echo of the strong-willed woman I used to be."
    b_ "I struggled to find my voice, to stand my ground, but his presence enveloped me like a suffocating embrace."
    scene v18-308
    b_ "As my body came for several times, I got weaker."
    b_ "I fell over his body and our lips collided again."
    b_ "The vulnerability I felt was both terrifying and exhilarating, a dangerous dance on the edge of reason."
    scene v18-309
    b_ "I kissed him back passionately. "
    b_ "I surrendered my body to him once more."
    b_ "In those moments, I became acutely aware of my own weakness, a realization that left me both captivated and afraid."
    b_ "Polad had become a force I could no longer reckon with, a storm I was helplessly swept into."
    scene black with dissolve
    b_ "What happened with Polad that day weakened my will to get back to Kamil."
    b_ "He destroyed the boundaries that I set."
    b_ "After some time, I made the similar mistake..."
    scene v18-310 with pixellate
    b_ "Entering Ahmed's office, I could feel the weight of our shared secrets hanging in the air."
    b_ "I was having an affair with Ahmed behind Kamil's back."
    b_ "I don't deny that I enjoyed our dark moments a lot."
    b_ "But at some point I ended this affair and we promised to keep it secret and go our own ways."
    b_ "But Ahmed didn't keep his promise..."
    scene v18-311
    b_ "Our conversation drifted back to our past, and I found myself recounting the stolen glances, the hushed promises, and the intoxicating allure of our hidden affair."
    b_ "Ahmed's gaze bore into mine, stirring up a storm of conflicting emotions within me."
    b_ "Despite my best efforts to move on, the past had a way of clawing its way back into my present."
    b_ "In the dim light of Ahmed's office, I felt a knot tighten in my stomach as he spoke, revealing his sinister intentions."
    scene v18-312
    b_ "My heart was pounding in my chest as he dropped a bombshell on me."
    b_ "He had some sort of hold over me, some dark secret that he was threatening to spill to my husband, Kamil."
    b_ "I felt like I was drowning in fear and desperation."
    b_ "His eyes bore into mine, and I knew I was trapped. I could almost feel the walls closing in around me."
    scene v18-313
    b_ "The thought of Kamil discovering my betrayal was paralyzing."
    b_ "How would I face him after all I had done?"
    b_ "The guilt was crushing, but I felt utterly powerless against Ahmed's threats."
    scene v18-314 with vpunch
    b_ "He let his pants down revealing his already hard cock in front of my eyes."
    b_ "I was stuck between a rock and a hard place, with no way out."
    b_ "Ahmed's blackmail was like a dagger hanging over my head, a constant reminder of the mess I had gotten myself into."
    b_ "The regret was suffocating, and I couldn't shake off the feeling of being trapped in a nightmare of my own making."
    b_ "I had no choice."
    scene v18-315 with fade
    b_ "I got on my knees and started sucking his dick."
    b_ "I couldn't risk my marriage and let Kamil know everything."
    b_ "All I wanted was to finish this and get out of that fucking room."
    scene v18-316
    b_ "His cock wasn't that big and I could take the whole shaft into my mouth."
    b_ "I focused on sucking him off and finish this."
    b_ "I squeezed his dick so hard moving my head back and forth so fast."
    scene v18-317
    b_ "I heard him moaning."
    b_ "But I think he understood my intention."
    b_ "He stopped me in my tracks, leaving me feeling utterly defeated and utterly at his mercy."
    scene v18-318 with fade
    b_ "He bent me over his table, raised my leg and started pounding me hard."
    b_ "In that moment, I felt utterly defeated. "
    b_ "Ahmed's manipulation skills were far beyond my ability to resist. "
    b_ "I started moaning from the pleasure."
    scene v18-319
    b_ "He had a way of cornering me, leaving me with no choice but to obey his sinister commands."
    b_ "The weight of guilt settled on my shoulders as I realized I was betraying Kamil once again, succumbing to Ahmed's ruthless schemes."
    b_ "I had no power against his cunning, and I found myself spiraling further into a web of deception and despair."
    scene v18-320
    b_ "There was one thing about myself that I hated."
    b_ "I was enjoying the fuck."
    b_ "I couldn't stop my moaning and gave him the satisfaction."
    b_ "My face expression changed from the pleasure. If Ahmed could see that face he'd enjoy it a lot."
    scene v18-321
    b_ "I wasn't supposed to be enjoying this."
    b_ "I was supposed to hate it because the sex with Ahmed was weakening my connection with Kamil."
    b_ "I wanted to be a good wife for Kamil because he deserved that."
    b_ "But I failed every time."
    b_ "Again I was feeling guilty in Ahmed's office bending over his table and his cum dripping out of my pussy."
    b_ "Will I be able to put an end to all of these?"




    scene black with Dissolve(3)
    ""
    centered "{size=+120}Banu's Struggle for Fidelity {/size}" with Fade(0.5, 0.5, 5)


    $ banupushpoladaway = False
    $ banuslappoladcheatingroute = False
    $ banublockturan = False
    $ banutakeleylaout = False
    $ banuleftahmedplace = False
    $ banuteasesamirbedroom = False
    $ banuletsamirfuckher = False
    $ banuletsamirfuckherass = False
    $ banupushpoladawaybathroom = False
    $ banuletpoladfuckherbathroom = False
    $ banumakehassancum = False
    $ banusuckhassancock = False
    $ banutakeoffhertophassan = False






    scene black with dissolve
    play music "audio/intro.mp3"
    "..."
    scene v19-188 with dissolve
    "Banu stood in the kitchen, her hijab framing her face, lost in her thoughts."
    "The scent of lemon cleaner filled the air, but her mind was miles away, lost in a whirlwind of conflicting thoughts."
    b_ "How did I let things get so outta hand?"
    b_ "Kamil trusts me like no other, thinks I'm as pure as snow, but little does he know..."
    "She felt a pang of guilt deep in her gut. Every time she cheated, it was like a knife in her heart."
    "But despite the guilt, she couldn't shake off the thrill of sneaking around and getting what she wanted."
    b_ "I've gotta change."
    b_ "Kamil deserves better than this, a wife who doesn't stray every chance she gets."
    "Banu knew it wouldn't be easy."
    "Temptations were everywhere, and she had a hard time saying no. "
    "But she couldn't keep living this lie, hurting Kamil without him even knowing."
    b_ "I gotta kick these bad habits to the curb."
    b_ "For Kamil, for myself, I gotta stay true, no matter how tough it gets."
    b_ "Oh, Polad..."
    "The intensity of their connection had been undeniable, each stolen moment filled with a passion she hadn't felt in years."
    "Banu closed her eyes, willing herself to push aside the allure of temptation."
    b_ "Enough, Banu..."
    b_ "You know this isn't right. You can't keep living this double life, hurting the man who loves you more than anything."
    scene v19-189
    "Banu's thoughts about Polad were abruptly interrupted by the shrill sound of the doorbell. "
    "As Banu approached the door, a mix of anticipation and dread churned in her stomach. "
    scene v19-190
    "With each step closer, her heart pounded louder, the sound echoing in her ears like a drumbeat of uncertainty."
    "Deep down, she knew that answering this door could change everything."
    "A voice inside her whispered insistently, telling her that it must be Polad standing on the other side."
    "With trembling hands, Banu reached for the doorknob, her breath catching in her throat."
    scene v19-191 with dissolve
    "As she swung the door open, her eyes widened in surprise, meeting the gaze of the man she both desired and feared."
    "It was Polad, leaning casually against the wall with a smirk playing on his lips."
    "His eyes locked onto hers, a knowing glint sparking in their depths. "
    "Banu's heart skipped a beat at the sight of him, a rush of conflicting emotions washing over her like a tidal wave."
    scene v19-192
    b "Polad... what are you doing here?"
    p "Just couldn't stay away, could I? You've been on my mind, Banu."
    b "You shouldn't be here, Polad. You know that."
    p "Come on, Banu. You can't deny what we have. The chemistry between us is undeniable."
    scene v19-193
    b "I know, but... I can't keep doing this. It's not right."
    p "You can't deny your feelings, Banu. You want this as much as I do."
    b "No, Polad. This has to stop. I love my husband, and I won't betray him anymore."
    p "Love, huh? Funny."
    b "You know nothing about my marriage."
    p "Maybe not, but I know how you feel when you're with me. You can't deny it, Banu."
    b "I have to go. Please, Polad, don't come here again."
    scene v19-194
    b "Polad, let go of me!"
    p "Not so fast, Banu. You can't just walk away from me."
    scene v19-195
    b "Let me go, Polad! This isn't right!"
    p "You can't deny what your body wants, Banu. You belong to me."
    b "No, I belong to my husband! Let me go!"
    p "You know you want this, Banu. Don't fight it."
    b "I said let me go, Polad!"
    scene v19-196
    "Banu freezes as Polad's seductive whispers fill her ear, her body tensing with a mix of arousal and revulsion."
    p "Remember, Banu? Remember how good it felt when I had you? "
    p "How you begged for more, how you screamed my name?"
    b "Stop it, Polad! Don't do this..."
    p "You can't resist me, Banu. You know you want it. You want me to take you again, to make you feel alive."
    p "You wanted me so bad, just like you do now. Admit it."
    b "Please, Polad, please stop..."
    "Banu feels Polad's touch on her, a jolt of electricity shooting through her body, her breath catching in her throat."
    p "You like that, don't you, Banu? You can't resist me."
    menu:
        "Push him away":
            $ banupushpoladaway = True
            $ renpy.block_rollback()
            stop music
            scene v19-197 with hpunch
            "Banu suddenly snaps out of her daze, her eyes blazing with determination as she gathers all her strength."
            "Banu pushes Polad away with all her might, her resolve firm."
            b "No, Polad! I won't give in to you anymore. I love my husband, and I won't betray him."
            p "Wow! You're so powerful, aren't you?"
            b "I won't let you control me any longer."
            p "You'll regret this, Banu. You'll come crawling back to me, begging for my touch."
            b "No, Polad. I'm done with you. Leave, and don't ever come back."
            scene v19-198 with fade
            "Banu's heart raced as she heard footsteps approaching from the other room. "
            "Panic surged through her veins as she realized Kamil was about to witness the confrontation with Polad. "
            "With a quick glance at Polad, she silently implored him to play along, to maintain the facade of innocence for Kamil's sake."
            scene v19-203
            "Kamil entered the room, his face lighting up with a warm smile as he saw Polad standing there. "
            k "Polad! What a surprise, buddy! What brings you here?"
            "Polad, catching onto Banu's unspoken plea, quickly plastered a fake smile on his face."
            p "Hey, Kamil! Just thought I'd drop by and say hi. How've you been?"
            k "I've been good, thanks for asking. Banu, did you know Polad was coming over?"
            b "No, it was a surprise to me too. But it's nice to see you, Polad."
            k "Yeah, it's always nice to catch up. Hey, why don't we all sit down and have a chat?"
            "Banu and Kamil exchanged a glance, both relieved that Polad was playing along. With a forced smile, Banu nodded. "
            b "Sure, that sounds great."
        "Don't do anything":





            $ banupushpoladaway = False
            $ renpy.block_rollback()

            scene v19-199 with fade
            "Banu froze as Polad's arms wrapped around her from behind, his touch sending shivers down her spine."
            "Panic surged through her veins, but she remained silent, unsure of what to do."
            "Polad, emboldened by her lack of response, pressed her against the kitchen wall, his grip tightening possessively as he began to grope her body."
            "Banu's heart hammered in her chest as she struggled against his hold, but Polad's strength was overpowering."
            b "Polad, please stop."
            p "Come on, Banu.."
            "He whispered huskily in her ear, his breath hot against her skin. "
            show poladrubbingbanupussykitchen
            "Banu's breath caught in her throat as Polad's touch became more invasive, his hand sliding between her legs, stroking her intimately from behind."
            b "Ohhhhh...Polad...please..."
            "She trembled with a mixture of arousal and revulsion, her mind clouded by a sense of helplessness."
            b "Polad, please... stop..."
            p "Why should I stop, Banu? You know you want this. I can feel how wet you are for me."
            b "No, I don't... I can't..."
            p "Don't lie to yourself, Banu. I can feel your body responding to me, craving my touch."
            b "Please, Polad... I don't want this..."
            p "You're such a tease, Banu. Pretending like you don't want it when we both know the truth."
            p "You can't resist me, Banu. You never could. And deep down, you know you don't want to."
            scene v19-201
            p "Look at you, Banu. Your face is practically begging for more. You can't hide how much you enjoy my touch."
            b "Stop it, Polad. You're disgusting."
            p "Oh, come on, Banu. Don't play innocent with me. We both know the truth."
            b "I'm not playing anything. I'm married, Polad. I love my husband."
            p "And yet here you are, trembling in my arms. Your body doesn't lie, Banu. It craves me."
            stop music
            scene v19-200 with fade
            play music "audio/tension.mp3"
            "Banu's heart raced with panic as they heard Kamil's footsteps approaching."
            "With a quick exchange of desperate glances with Polad, they silently agreed to maintain their facade, not wanting to raise any suspicions."
            "Polad swiftly released Banu, stepping back with a smirk as Kamil appeared in front of them, unaware of the turmoil that had just transpired."
            scene v19-202
            "Kamil entered the room, his face lighting up with a warm smile as he saw Polad standing there. "
            k "Polad! What a surprise, buddy! What brings you here?"
            "Polad, catching onto Banu's unspoken plea, quickly plastered a fake smile on his face."
            p "Hey, Kamil! Just thought I'd drop by and say hi. How've you been?"
            k "I've been good, thanks for asking. Banu, did you know Polad was coming over?"
            b "No, it was a surprise to me too. But it's nice to see you, Polad."
            scene v19-204
            k "Banu, is everything okay? You seem... off."
            "Banu's heart skipped a beat as Kamil's eyes bore into her, his concern washing over her like a wave. "
            b "Oh, it's nothing, Kamil. Just feeling a bit tired, that's all."
            scene v19-205
            "Polad continues his ministrations from behind, his touch sending waves of arousal coursing through Banu's body."
            "But she remains still, her eyes pleading with Kamil not to press further."
            k "Are you sure? You seem... distant. Is there something you're not telling me?"
            b "I promise, Kamil, I'm fine. Just a long day, that's all."
            scene v19-206
            "Banu's breath catches in her throat as Polad's touch becomes more forceful, his fingers squeezing her with an intensity that sends a jolt of pleasure through her body."
            "Despite her best efforts to remain silent, a soft moan escapes her lips, betraying the arousal that courses through her veins."
            b "Polad..."
            k "Banu, what's wrong? Are you in pain?"
            "Banu's heart races with panic as she realizes Kamil's attention is now fully on her."
            b "I... I'm fine, Kamil. Just... just a little... tired."
            k "You seem... different."
            b "I'm fine, Kamil. Just... just give me a moment."
            scene v19-207
            "Banu's resolve strengthened as she found a surge of inner strength, fueled by her love for Kamil and the realization of the danger she was in."
            "With a determined grit, she pushed Polad's hand away from her, her movements firm and resolute."
            k "Hey, why don't we all sit down and have a chat?"
            b "Sure, that sounds great."
            stop music

    scene v19-208 with dissolve
    "Banu trailed behind Kamil and Polad as they made their way to the table, her shoulders slumped with defeat."
    "She needed to find a way to rid their lives of Polad's toxic presence once and for all."
    "Taking a deep breath, Banu forced herself to focus on the present moment, to push aside the overwhelming fear and uncertainty that threatened to consume her."
    k "So, Polad, how have you been? It's been a while since we last caught up."
    scene v19-209
    p "Yeah, I've been good, Kamil. Just keeping busy with work, you know how it is."
    k "That's great to hear. Banu and I were just talking about you the other day, wondering when we'd see you again."
    p "Yeah, sorry I haven't been around much lately. Things have been pretty hectic."
    k "No worries at all, Polad. We understand. Life can get busy sometimes."
    b_ "How can Kamil be so blind to Polad's true intentions?"
    b_ "How easily he falls for his charm, his deceitful words. Doesn't he see the danger lurking beneath the surface?"
    scene v19-210
    "Banu's heart skipped a beat as the doorbell rang, breaking the tense silence that hung in the air. "
    "She exchanged a quick glance with Kamil, his expression one of curiosity as he headed towards the door."
    k "I'll go see who it is."
    scene v19-211
    "Panic surged through Banu's veins as Kamil left, leaving her and Polad alone."
    "With Polad's presence looming over her, she knew she needed to tread carefully, to find a way to protect herself from his advances."
    "Polad's eyes gleamed with mischief as he watched Kamil leave, a knowing smirk playing on his lips."
    scene v19-212
    play music "audio/tension.mp3"
    p "Looks like we're alone now, Banu. Just you and me."
    b_ "I can't let him get to me. I won't let him control me anymore. I need to find a way to get him out of our lives, once and for all."
    "Banu's thoughts raced as she felt Polad's gaze bore into her, his smirk sending a chill down her spine."
    scene v19-213
    b_ "I need to get him out of our lives, before he destroys everything we've built. "
    b_ "But how? How can I protect myself and Kamil from someone so ruthless, so cunning?"
    b_ "I don't know what he's planning, but I can't let my guard down."
    b_ "I need to stay strong, to protect myself and Kamil from whatever harm he might try to bring our way."
    scene black with dissolve
    "..."
    scene v19-214 with dissolve
    "Banu's heart pounded in her chest as she found herself pressed against the wall, Polad's touch sending shivers down her spine."
    "She felt powerless in his grasp, his hands holding her head in a vice-like grip as he caressed her chin with a possessive tenderness that made her feel weak in the knees."
    scene v19-215
    b_ "How did I end up here? How did I let him get this close? I need to find a way out of this, to break free from his hold."
    p "Do you know what I'm going to do now?"
    b "You wouldn't dare. Kamil will be back any moment."
    p "I'm not afraid of Kamil. I could fuck you right here, and he wouldn't even know."
    "Panic surged through Banu's veins as she realized the gravity of Polad's threat. "
    b "You won't touch me, Polad. I'll scream for help if I have to."
    p "Go ahead, scream all you want. By the time Kamil gets here, it'll be too late."
    menu:
        "Slap him":
            $ banuslappoladcheatingroute = True
            $ renpy.block_rollback()
            stop music

            b_ "I won't let him intimidate me. I won't let him destroy everything I hold dear."
            scene v19-216 with hpunch
            play sound "voices/slap.mp3"
            "With a swift motion, Banu raises her hand and delivers a resounding slap across Polad's face, the sound echoing through the room."
            b "That's for disrespecting me, for disrespecting my marriage. Now get out of here and never come back."
            scene v19-217
            b "I won't let you manipulate me anymore. I won't let you ruin what I have with Kamil."
            "Polad's smirk widened, his arrogance undiminished by Banu's display of defiance. He took a step closer, his gaze locked with hers, a predatory gleam in his eyes."
            p "Oh, Banu. You're so naive. You think you can stand up to me?"
            b_ "I won't let him break me. I won't let him win."
            b "I don't need to stand up to you. I just need to get you out of our lives. And believe me, I will."
            scene v19-218
            p "We'll see about that, Banu."
            p "We'll see just how long you can keep up this charade."
            "No matter how tough he seemed, Banu was ready to face him head-on, to protect her marriage and her home from his toxic influence, no matter the cost."
        "Stay silent":




            $ banuslappoladcheatingroute = False
            $ renpy.block_rollback()
            stop music
            "Despite her inner turmoil, she couldn't deny the rush of arousal that surged through her veins, leaving her feeling weak and powerless in his grasp."
            b_ "What's happening to me? Why do I feel this way?"
            scene v19-219 with hpunch
            play music "audio/weakbanu.mp3"
            "Polad wasted no time in seizing the opportunity, pulling Banu forcefully into his embrace and crushing his lips against hers in a hungry kiss."
            "Banu's mind spun with a whirlwind of sensations, her senses overwhelmed by the intoxicating heat of his touch."
            b_ "I shouldn't be doing this. I can't betray Kamil like this."
            b_ "I have to stop this. I have to find the strength to resist."
            b "Stop, Polad...mmmmm... This... this can't happen."
            scene v19-220
            "Banu's mind clouded with desire as Polad's lips met hers, his kiss sending a surge of heat coursing through her body."
            b_ "I shouldn't be doing this... but it feels so good."
            b_ "I can't stop... I don't want to stop."
            scene v19-221
            "With each lingering kiss, Banu felt herself slipping further into the depths of desire, her resolve weakening with each caress of Polad's lips against hers."
            "In that moment, nothing else mattered but the fiery passion that burned between them, igniting a primal hunger that threatened to consume them both."
            "As the kiss deepened, Banu pushed aside her doubts and insecurities, giving in fully to the raw intensity of the moment."
            scene v19-222
            b "Ahhhhh...Hey, what the hell?"
            p "Just giving you a taste of what you've been missing, babe."
            scene v19-223
            "Banu was gasping and moaning, her words caught in her throat as Polad's fingers explore her depths, sending waves of pleasure coursing through her body."
            "Banu's mind swims with ecstasy as Polad's dual assault overwhelms her senses, her thoughts consumed by the intense pleasure radiating from every touch."
            "Unable to form coherent words, she surrenders completely to the overwhelming sensations, lost in a whirlwind of desire and arousal."
            scene v19-224
            "Banu was moaning uncontrollably as Polad's lips and fingers work their magic, her body responding eagerly to his touch."
            "Banu was moaning softly, her body trembling with arousal as she feels her pussy becoming slick and slippery under Polad's skilled touch."
            scene v19-224 with hpunch
            b "Ahhhhhh...."
            "Banu cries out in ecstasy as waves of pleasure wash over her, her body convulsing with the intensity of her orgasm."
            "Banu's mind goes blank as she rides the waves of her climax, her senses overwhelmed by the sheer intensity of pleasure coursing through her."
            scene v19-225
            "Polad takes his hand out of her throbbing pussy and shows her the positive results."
            p "Looks like you enjoyed that, huh?"
            b "I... I don't know what came over me."
            p "Oh, come on, Banu. No need to be shy. We both know you loved every second of it."
            scene v19-226
            b "It's not like that... I shouldn't have let it happen."
            p "But you did let it happen, Banu. And deep down, you know you wanted it."
            b "I... I need to go. This was a mistake."
            p "We'll see about that, Banu. We're far from finished."
            scene v19-227 with fade
            b_ "Ohhh god...Where is Kamil? Why is he taking so long?"
            p "You like that, don't you? You're getting off on this, aren't you?"
            b "Ahhhh....We... shouldn't be doing this..."
            p "You can't deny the pleasure I'm giving you."
            b "Oh, God... Kamil..."
            p "Forget about him, Banu. Focus on me. I'll give you everything you need."
            scene v19-228
            p "You know what I want, Banu? I want to fuck you right here, right now."
            b "No... we can't.."
            b "Stop it, Polad! This has gone too far!"
            p "Come on, Banu, don't pretend like you don't want this."
            p "You're just playing hard to get, Banu. But we both know you can't resist me."
            scene v19-229
            "As Polad's hands reach for Banu's clothes, a sense of dread washes over her, her heart pounding in her chest as the sound of footsteps grows louder in the hallway."
            "In a panic, she pushes Polad away, her eyes widening with alarm."
            b "Stop, Polad! Kamil's coming!"
            stop music
            scene v19-230 with fade
            p "Hey, Kamil! What took you so long, man?"
            k "Sorry about that, just got caught up with something. What's going on?"
            "Banu's heart races as she watches Polad's quick thinking, her hands trembling as she pulls her pants back up, her mind racing with panic at the close call."
            scene v19-231
            p "Oh, nothing much, just chatting with Banu here. You know how it is."
            p "Hey, man, did you catch the game last night? It was insane!"
            k "Oh yeah, it was a wild one! I couldn't believe that last-minute goal!"
            "Banu's heart pounds with relief as Polad skillfully distracts Kamil, engaging him in conversation about something entirely unrelated to their close call. "
            "With her gaze averted and her attention elsewhere, she discreetly adjusts her clothing, grateful for the opportunity to compose herself without drawing suspicion."
            b "Yeah, it sounded pretty exciting. I wish I could've watched it."
            k "Hey, is everything alright, Banu? Today you seem a bit... off."
            scene v19-232
            b "Oh, it's nothing, Kamil. Just feeling a bit tired today, that's all."
            k "Hey, Banu, is something bothering you? I can't help but notice you're avoiding eye contact with me."
            "Banu's heart clenches with panic as Kamil's question hits home, her mind scrambling for a plausible explanation to conceal the truth."
            scene v19-233
            b "Oh, it's nothing, Kamil, really. I... I guess I'm just lost in my thoughts today."
            k "Alright, if you say so. Just know that I'm here for you if you ever want to talk about anything, okay?"
            b_ "What have I done? Kamil doesn't deserve this. He's such a kind and caring husband, and here I am, betraying his trust..."




    scene black with dissolve
    ""
    scene v19-234 with dissolve
    "Banu can't help but stare at Kamil, who's passed out on the other side of the bed, snoring away without a care in the world. "
    "She's feeling some type of way, her thoughts all tangled up in guilt and regret."
    b_ "Look at him, all peaceful and shit. He's got no clue what I've done. How could I mess things up like this?"
    "The memory of her betrayal hitting her like a ton of bricks."
    "She wants to spill her guts to Kamil, to spill the truth and beg for forgiveness, but the words just won't come out."
    scene v19-235
    b "Kamil... I'm so sorry..."
    "She might not be able to undo the mess she's made, but she's damn well gonna try to fix it, even if it kills her."
    b_ "I gotta find a way to make this up to him. I can't stand seeing him hurting like this because of me."
    b_ "That's it. I'm gonna keep it real with Kamil, no matter what."
    b_ "I'm gonna own up to my mistakes and make things right. Kamil deserves nothing less."

    if killturan == False:

        scene v19-236 with fade

        "Banu's heart skips a beat as she sees Turan's name light up on her phone screen."
        "She grabs her phone in a panic, quickly sinking back into bed and pretending to be engrossed in the conversation."
        t "Hey, babe, just wanted to say goodnight. Hope you're doing okay."
        b "What do you want in the middle of the night?"
        t "So, have you forgotten about the last time I fucked you, Banu? I bet you haven't been able to get me out of your mind since then."
        b "That's enough, Turan. I'm not interested in playing these games anymore. Leave me alone."
        t "You don't want your precious husband to know everything we've been up to, do you, Banu?"
        t "I can make sure he finds out all about our little secret if you don't play nice."
        b "Just please leave my husband out of it."
        t "That's more like it, babe. "
        scene v19-237
        t "So, did you keep the butt plug that last time I gave to you?"
        "Banu's cheeks flush with embarrassment as she recalls the shiny red butt plug Turan had given her, the memory sending a shiver down her spine."
        "She feels a pang of guilt for even entertaining Turan's question, especially with Kamil sleeping soundly beside her, unaware of the dangerous game she's been playing."
        t "Get the butt plug ready, Banu. We're gonna play some games, and you're gonna do exactly as I say."
        t "You know what will happen if you don't obey me."
        menu:
            "Shut him down and block him":
                $ banublockturan = True
                $ renpy.block_rollback()
                scene v19-238
                "With a deep breath, Banu knows she can't let him control her any longer."
                b "You think you can order me around, Turan?"
                b "Well, let me tell you something. "
                b "My husband, Kamil, is a better man than you could ever hope to be. He's kind, loyal, and respectful—everything you're not."
                "Turan's response comes swift and venomous, his attempts to intimidate her only fueling her determination to break free from his grasp."
                t "You'll regret this, Banu. I can make your life a living hell if you cross me."
                b "I'm done playing your games, Turan. Consider this your last warning. "
                b "I'm blocking you, and I won't hesitate to take further action if you ever try to contact me again."
                "With a sense of empowerment coursing through her veins, Banu hits the block button, severing the toxic tie that bound her to Turan once and for all."
            "{color=#ff0000}Obey him{/color}":




                $ banublockturan = False
                $ renpy.block_rollback()



                jump banusendturan_selfie



label banusendturan_selfie_continue:

    scene black with dissolve
    "..."
    if agreetoruslanoffer == True:

        scene v19-260 with dissolve
        "Banu's up and about in the dead of night, her mind buzzing with restless energy."
        "The kitchen's quiet, but then she hears something—a soft moan cutting through the silence."
        scene v19-261
        "She's alert now, wondering what the heck's going on."
        "Following the noise, she heads towards Leyla's room, her daughter's spot down the hall."
        "The moans are coming from there, and Banu's heart races a bit faster."
        "What's happening in the middle of the night?"
        "Banu's mind races as she tries to make sense of the situation."
        "Leyla's husband is out of town, so who could she possibly be with at this hour?"
        "Could Leyla be sneaking around with someone else?"
        "The idea seems absurd, but Banu can't shake the feeling of unease gnawing at her gut."
        scene v19-262 with hpunch
        play music "audio/tension.mp3"
        "Banu's jaw drops to the floor as she swings open the door, fully expecting to catch Leyla in a peaceful slumber."
        "But what she finds instead makes her heart skip a beat."
        scene v19-263
        "There they are, Leyla and Ruslan, butt naked and going at it like there's no tomorrow."
        "Banu's mind blanks out for a second as she tries to process the scene. "
        "This ain't happening, she thinks. Not in her house, not with her own daughter and stepson."
        b "What the hell is going on here? Leyla, Ruslan, explain yourselves!"
        l "Oh, hey Mom. Didn't expect you to walk in."
        scene v19-264
        stop music
        b "Don't you 'hey Mom' me! Explain yourselves, right now."
        r "Chill out, Banu. We're just having a good time."
        b "A good time? You call this a good time? Leyla, he's your stepbrother!"
        b "And what about your husband Leyla? What if he finds out about this?"
        l "He's out of town on business. He won't find out."
        scene v19-265
        l "So what? We're both adults, aren't we?"
        b "That doesn't make it right! And Ruslan, she's your stepsister! How can you both be so... so..."
        r "Carefree? Open-minded? Take your pick, Banu."
        b "Shameless! That's what you are, shameless! You're both crossing a line here."
        l "We're just doing what feels right for us. If you don't like it, tough luck."
        b "I can't believe what I'm hearing. You're both acting like this is no big deal."
        "Banu's eyes drift to Ruslan's manhood, standing tall and proud, and she feels a wave of discomfort wash over her."
        b "I can't believe I'm seeing this. You two need to stop right now."
        scene v19-266
        "Leyla stands up from the bed, her eyes locking onto Banu's with a fierce intensity."
        l "You're one to talk, Mom. I know all about your little escapades."
        b "What are you talking about? How could you even think that? Get dressed immediately!"
        l "Oh, please. I've heard the rumors. You're always sneaking around with different guys. Don't pretend like you're some saint."
        scene v19-267
        "Banu's cheeks flush with anger and embarrassment."
        b "Those are just rumors, Leyla. You know they're not true."
        l "Sure, Mom. Keep telling yourself that. But don't expect me to believe it."
        "Banu's mind races as she tries to come up with a response, but the words stick in her throat. "
        "How could Leyla think such a thing about her own mother? And what if there was some truth to her accusations?"
        scene v19-268
        "Leyla stands, her gaze unwavering as she confronts Banu with a cold determination."
        l "And don't even get me started on Polad."
        "Banu's heart sinks as Leyla's words hit her like a sledgehammer. How could Leyla possibly know about her secret encounters with Polad?"
        b "What... What are you talking about?"
        l "Oh, come on, Mom. We all know about your little fling with Polad from the bar. Don't act like you're fooling anyone."
        "Banu's breath catches in her throat, her mind reeling at the realization that her daughter knows about her infidelity."
        b "That's not... It's not what you think."
        scene v19-269
        play music "audio/tension.mp3"
        r "Save it, Banu. We've seen the way you look at him. The way you sneak off to meet him when you think no one's watching."
        "Ruslan rises from the bed, his eyes glinting with a mix of lust and contempt as he approaches Banu, his arousal obvious even in the dim light of the room."
        "Leyla follows him, her expression cold and calculating."
        r "Come on, Banu. Admit it. You're nothing but a whore."
        b "That's not true! How dare you say something like that to your own mother?"
        l "Oh, please. We both know the truth, Banu. You can't deny it any longer."
        b "I... I'm not a whore. I've made mistakes, but that doesn't define who I am."
        r "Mistakes? Please. You've been screwing around with Polad behind Dad's back for months. You're a disgrace."
        "Ruslan's voice drips with malice as he steps closer to Banu, his eyes gleaming with a twisted sense of satisfaction."
        r "You're going to listen to us now, Banu. Or do you want your precious husband to find out about all your dirty little secrets?"
        b "What? Are you threatening me?"
        r "I can see the way you've been eyeing me since you walked in here. You're practically salivating over my dick, aren't you? Admit it."
        menu:
            "Smash his balls and take Leyla out":
                $ banutakeleylaout = True
                $ renpy.block_rollback()
                stop music
                "Banu's patience snaps like a brittle twig as she watches Ruslan's leering expression, his taunts fueling her anger to a boiling point."
                scene v19-270 with vpunch
                "With a fierce determination, she lunges forward, delivering a powerful kick straight to Ruslan's groin."
                scene v19-271
                "Ruslan's eyes bulge in shock and agony as he crumples to the ground, clutching his injured manhood. "
                "Banu stands over him, her gaze steely and unyielding."
                scene v19-272
                b "Listen here, you little punk. You ever threaten me or my marriage again, and you'll regret it. Got it?"
                r "Ohhhhh...shit...You are crazy."
                b "You think you can threaten me and get away with it? You think you can control me with your pathetic little games? Think again."
                scene v19-273
                b "You and Leyla have crossed a line, and I won't stand for it any longer. If you ever try to blackmail me again, I'll make sure you regret it."
                "Banu turns to Leyla, her grip firm as she pulls her daughter away from the scene of chaos."
                b "Come on, Leyla. We're leaving."
                "Leyla hesitates for a moment, her gaze flickering between Banu and Ruslan, before finally nodding and allowing herself to be led out of the room by her mother."
            "Admit you looked at his dick":



                $ banutakeleylaout = False
                $ renpy.block_rollback()



                jump ruslan_fuck_leyla_banu




label ruslan_fuck_leyla_banu_continue:

    scene black with dissolve

    "..."
    "Back in the day, Banu was just your regular religious wife, rockin' her hijab and all, livin' the married life with Kamil."
    "But then there's Ahmed, Kamil's old buddy from school, also their neighbor and a cop to boot."
    "He's got a thing for Banu, always has. And let's be real, Banu ain't exactly a saint."
    "She's been playin' with fire, sneakin' around with Ahmed, gettin' down and dirty behind Kamil's back."
    scene ahmedflash1 with fade
    "Ahmed ain't stupid either. He knows Banu's secret slutty side, and he's been takin' full advantage of it."
    "So, Banu's been slidin' into Ahmed's office, thinkin' she's slick, but Ahmed's been slidin' into her too."
    scene black with dissolve
    "But here's the kicker: Banu wants out. She's had enough of sneakin' around, enough of cheatin' on Kamil."
    "So, she rolls up to Ahmed's place, ready to make a deal."
    "..."
    scene v19-299 with dissolve
    "Ahmed and Banu lock eyes, a silent battle of wills playing out between them."
    "Ahmed's gaze is smug and calculating, like he's got all the cards in his hand."
    "Banu, on the other hand, looks determined but wary, like she's ready to fight but knows she's in deep waters. "
    scene v19-300
    "Banu takes a deep breath, steeling herself for what comes next. "
    "With trembling hands, she holds the money she brought out to Ahmed with a determined expression."
    b "Here, Ahmed. Take it. Just... leave me and Kamil alone, okay?"
    "Ahmed's smirk widens as he eyes the money, his gaze flicking between Banu and the cash."
    ah "Hmm, tempting offer, Banu. But you know as well as I do that money ain't gonna solve all our problems."
    "Banu's heart sinks at Ahmed's response, but she stands her ground, refusing to back down."
    b "Please, Ahmed. I'm begging you. Just take the money. I can't keep living like this."
    scene v19-301
    "Without a word, he turns on his heel and strides back to the sofa, his steps echoing loudly in the tense silence of the room. "
    b "What are you doing? I'm offering you what you want. Take the money and leave us alone."
    ah "And what makes you think money is all I want?"
    "Banu's jaw clenches in frustration, realizing that Ahmed isn't going to make this easy for her."
    b "Then what do you want from me, Ahmed? What's it going to take for you to leave us alone?"
    scene black with dissolve
    ah "You know what I want, Banu. And until you're ready to give it to me, we're going to have a little... arrangement."
    "Banu's voice trembles with anger as she throws the money onto the table, her eyes blazing with defiance."
    "She strides over to where Ahmed is sitting on the sofa, her fists clenched at her sides as she confronts him head-on."
    scene v19-302
    b "You want to play games, Ahmed? Fine! But you're messing with the wrong woman!"
    b "I'm strong, I'm faithful, and I won't let you or anyone else destroy what I have with Kamil!"
    b "I don't want to see your face ever again, Ahmed! Stay away from me, stay away from my family, or else..."
    "But Ahmed just smiles, his gaze unwavering as he meets Banu's furious stare."
    "He knows exactly how to push her buttons, how to make her lose control."
    scene v19-303
    "And deep down, he knows that he's already won."
    ah "Oh, Banu... You can scream and shout all you want, but we both know the truth, don't we?"
    "Ahmed leans back on the sofa, his eyes gleaming with a mix of amusement and determination as Banu stands before him."
    ah "You know, Banu, you can throw all the tantrums you want, but it won't change a damn thing."
    ah "You can try to be this 'religious good wife' all you like, but deep down, you'll always crave what I have to offer."
    "Banu's jaw tightens as she glares at him, her resolve flickering but not breaking."
    b "You're delusional, Ahmed. I'm done with your games. I'm done with you."
    ah "Oh, Banu, you're not done with me. Not by a long shot. Your pussy remembers me, Banu. "
    ah "It remembers how good I made you feel. And no matter how hard you try to forget, it'll always crave my dick."
    scene v19-304 with fade
    b "You're disgusting, Ahmed. I'm leaving."
    ah "Women like you can't change, Banu. Don't deceive yourself."
    "As Banu turns to leave, ready to escape from Ahmed's toxic presence, something stops her in her tracks."
    "Ahmed's voice, smooth and enticing, begins to weave its way into her mind, pushing all the right buttons, stirring up emotions she thought she had buried deep."
    scene v19-305
    play music "audio/tension.mp3"
    ah "Leaving so soon, Banu?"
    ah "I can see it in your eyes. You're practically dripping with anticipation."
    ah "Don't deny it, darling. You want to stay because if you leave now, you'll be missing out on all the fun."
    ah "And we both know that wet pussy of yours won't be able to resist for long."
    ah "You know, Banu, I've always admired your strength."
    ah "Your unwavering dedication to your husband, your commitment to your faith."
    ah "But I can't help but wonder... how long can you keep up this facade? How long until you give in to the desires that burn within you?"
    "She tries to maintain her stoic facade, to push back against the overwhelming tide of temptation."
    b "I... I don't know what you're talking about, Ahmed. I'm faithful to my husband. I've always been faithful."
    "But even as she speaks the words, Banu can feel the undeniable pull of temptation tugging at her, drawing her closer to Ahmed with each passing moment. "
    scene v19-306
    "Banu stands still, avoiding any glance towards Ahmed as he undresses behind her."
    "Despite her attempt to act normal, she can feel the tension building up in the room, making it hard to ignore what's happening behind her."
    "It's like she's on edge, waiting for something to happen, even though she's trying her best to stay composed."
    ah "Banu, you can't keep pretending like I don't affect you. You feel it, don't you?"
    b "I don't know what you're talking about, Ahmed. You need to stop this."
    ah "Stop what? Stop being honest? You can't deny the chemistry between us."
    menu:
        "Just leave":
            $ banuleftahmedplace = True
            $ renpy.block_rollback()
            scene v19-308
            stop music
            ah "Banu, you can't just walk away."
            "With a final, determined look, Banu turned on her heel and walked away, leaving Ahmed standing there."
            "Despite the temptation, Banu remained true to herself and her commitment to her marriage, refusing to let Ahmed's advances shake her resolve."
        "Stay and prove him wrong":



            $ banuleftahmedplace = False
            $ renpy.block_rollback()
            stop music



            jump ahmedsfucksbanu_sofa





label ahmedsfucksbanu_sofa_continue:

    scene black with dissolve
    play sound "voices/doorbell.mp3"
    "..."
    "Banu, busy with her daily chores, hears the doorbell ring."
    scene v19-326 with dissolve
    "She heads to the door and finds Samir, the intern from her workplace, standing there."
    scene v19-327 with fade
    "He explains he's come to collect some work-related documents."
    scene v19-328 with fade
    "Banu invites him in and offers him tea in the guest room."
    "They engage in light conversation about work and life as Banu prepares the tea."
    "After serving it, they continue chatting, enjoying each other's company over a warm cup of tea."
    scene v19-329 with fade
    b "Here's your tea, Samir. I hope you like it."
    sam "Thank you, Banu. It smells great."
    b "So, how's everything going at work? Keeping busy?"
    sam "Yeah, it's been pretty hectic lately with the new project deadlines. But I'm managing."
    scene v19-330
    b "How's work been treating you lately?"
    sam "It's been okay, just trying to keep up with everything."
    b "I totally get it. Sometimes it feels like there's just never enough time in the day, right?"
    sam "Yeah, exactly. It's been a bit overwhelming, to be honest."
    b "Well, you're doing a great job from what I've seen. You seem really dedicated."
    sam "Thanks, Banu. That means a lot coming from you."
    b "Of course! We're all a team here, right? We've got each other's backs."
    scene v19-331
    sam "Definitely."
    b "And if you ever need any help or advice, feel free to ask."
    sam "I'll keep that in mind. Thanks, Banu."
    scene black with fade
    "..."
    scene v19-332
    b "Uh, Samir, is there something on my pants?"
    sam "Oh, no, no! I mean, I... uh..."
    b "Are they ripped or something? I hope not, I just bought these!"
    sam "No, no, they look fine! I was just, uh... admiring the fabric?"
    scene v19-330
    b "Well, as long as it's just the fabric you're admiring!"
    sam "Oh, uh, sorry. I didn't mean to... uh..."
    b "It's okay, Samir. I understand. Sometimes it's hard not to notice things."
    b "Alright, Samir, I'll go fetch your documents. They're in the bedroom, follow me!"
    sam "Oh, uh, okay. I'll wait here then."
    scene v19-333 with dissolve
    b "Alright, Samir, you stay here. I'll go grab those documents for you. They're just in the bedroom."
    sam "Oh, okay. Sure, I'll wait here."
    b "Don't worry, I'll be back in a flash."
    scene black with dissolve
    "She rummages through the drawers and shelves, searching for the papers."
    "Minutes pass as she sifts through the files, her frustration growing with each passing second. "
    scene v19-334 with dissolve
    play music "audio/tension.mp3"
    "As Banu stands in the bedroom, clutching the documents, the sound of the door closing behind her catches her attention."
    "Her heart skips a beat as she realizes it's Samir entering the room. "
    scene v19-335
    b "Samir, why did you come in here? Is something wrong?"
    "Samir remains silent, his gaze fixed on Banu."
    b "Samir, is everything alright?"
    sam "I... I just wanted to... uh... talk to you."
    b "Okay, what do you want to talk about?"
    sam "I... um... I've been feeling a bit... lost lately, and... I thought maybe you could... help me."
    "Banu senses Samir's unspoken desires, and a wave of arousal washes over her."
    "She can feel her body responding to the thought of what she could do with him in the bedroom."
    "Despite trying to keep her composure, the anticipation of exploring her desires with Samir sends shivers down her spine."
    menu:
        "Get him out of the room.":
            $ banuteasesamirbedroom = False
            $ renpy.block_rollback()
            scene v19-336
            stop music
            b "Samir, cut the act. I know exactly why you're here, and let me tell you, it's not going to happen. So, if you don't mind, please leave."
            sam "I... I'm sorry, Banu. I didn't mean to... I'll just... I'll go."
            b "Samir, listen. I get it. You're young, and I'm sure you have needs, but this isn't the way to go about it. "
            b "You can't just come barging into someone's bedroom like this. It's disrespectful."
            scene v19-337
            sam "I know, I know. I don't know what came over me. I'm really sorry, Banu."
            b "Look, Samir, I understand that you might be feeling... frustrated, but there are better ways to handle it. Please, don't ever try something like this again."
            sam "I promise, Banu. It won't happen again. I'm really sorry for intruding like this."
            "Banu offered him a reassuring smile."
            b "It's okay, Samir. Just learn from this experience, alright?"
            b "Now, let's forget about it and focus on why you actually came here. Let me find those documents for you."
            sam "Okay..."
        "Tease him":


            $ banuteasesamirbedroom = True
            $ renpy.block_rollback()


            stop music


            play music "audio/sensualsex.mp3"

            scene v19-338
            "She could feel his eyes on her, his presence making her hot and excited."
            b "I know why you're here, Samir."
            b "You came here because you wanted something... more."
            "As Samir stood there, frozen in place, Banu decided to push the boundaries a little further."
            scene v19-339 with dissolve
            "She began to tease him even more."
            b "If you're really just here to talk about work, then you won't mind if I get more comfortable, right?"
            scene v19-337
            "Samir's eyes were glued to Banu's every move, his breath coming in short, uneven gasps."
            b "Or maybe... you came here for something else entirely."
            "With a playful smile, she began to slide her pants down her hips, revealing more and more of her smooth, bare skin."
            scene v19-340
            "As Banu continued to toy with Samir's desires, she decided to take things a step further."
            b "Like what you see, Samir?"
            "The fabric parted, revealing more of her creamy skin underneath. Samir's eyes widened as he watched, his breath catching in his throat. "
            scene v19-341
            "He couldn't believe what he was seeing – Banu, standing before him, practically naked and completely unapologetic."
            b "Maybe you should come a little closer."
            "Samir hesitated for a moment, his mind reeling with desire and uncertainty."
            "But the pull of Banu's irresistible charm was too strong to resist."
            scene v19-342
            b "That's it, Samir... Closer..."
            b "You know, Samir, I've noticed how you look at me. How your eyes linger on every curve, every inch of my skin."
            sam "I-I... I'm sorry, Banu. I didn't mean to..."
            scene v19-343
            b "Shh... Don't apologize, Samir. There's nothing to be sorry about. In fact, I find it rather... enticing."
            b "You've never been this close to a naked woman before, have you, Samir?"
            "Samir shook his head, his breath catching in his throat as he struggled to find his voice."
            sam "N-no... I... I haven't."
            b "Well, then, consider this your lucky day, Samir. Because tonight, you're going to experience things you've only ever dreamed of."
            b "So, you've been watching YouTube tutorials on massage techniques, right?"
            sam "Uh, yeah... I mean, I've always been interested in learning new things, and, well, massaging seemed like a useful skill to have."
            b "Interesting... And have you had the chance to practice?"
            sam "A little bit, but mostly just on myself or, um, on pillows..."
            b "Well, how about you put those skills to the test, Samir? I could use a good massage right about now."
            sam "I...."
            scene v19-344 with fade
            "Banu arched her back, accentuating her curves as she gracefully reclined on the bed, her movements fluid and seductive. "
            "With a playful smile, she propped herself up on her elbows, her gaze fixed on Samir, inviting him to approach."
            scene v19-345
            b "Mmm, that feels amazing, Samir. You have a real talent for this."
            sam "Thank you, Banu. I'm glad you're enjoying it. You have such a beautiful back."
            b "You're too kind. But really, your touch is incredible. It's like you know exactly where to apply pressure."
            sam "I've watched a lot of tutorials online."
            b "Well, your online education seems to be paying off. I could get used to this."
            b "Hmm, how about a little lower? My lower back could use some attention too."
            sam "Of course, Banu."
            scene v19-346
            b "Oh, right there, Samir. That's perfect."
            sam "I'm glad I could find the right spot. Just let me know if the pressure is too much."
            b "No, it's perfect. You have a really good touch."
            scene v19-347 with fade
            "As Samir skillfully massages Banu's back, she feels herself getting increasingly aroused."
            "Sensing her desire, he helps her remove her bra, his touch sending shivers down her spine."
            "With each movement, Banu's breath quickens, her skin tingling with anticipation."
            "As Samir moves lower, his hands glide over Banu's smooth skin, eliciting soft moans of pleasure from her lips."
            scene v19-348
            "With each gentle stroke, Banu feels Samir's hard erection pressing against her, igniting a fiery heat between them."
            b "Mmm, your hands feel amazing."
            sam "I'm glad you're enjoying it, Banu. You have such a beautiful body."
            b "Actually, Samir, could you... go a little lower?"
            sam "Lower? Sure thing."
            scene v19-349 with fade
            b "Oh, Samir... that feels so good..."
            sam "I'm glad you like it."
            b "Yes, right there... oh, Samir..."
            sam "You're so wet, Banu... I can feel it..."
            "She arches her back, pressing against his hand, craving more of his touch."
            scene v19-350
            b "Don't stop, Samir... Keep going..."
            b "I want more... I need it..."
            "Their desires ignite as Samir continues to explore Banu's body, each touch sending them both spiraling into a whirlwind of passion and pleasure."
            scene v19-351 with dissolve
            "Samir slowly slides his fingers beneath the edge of Banu's panties. "
            "Teasingly tracing along her skin before gradually pulling them down, revealing her nakedness with a tantalizing anticipation."
            "Banu's breath catches as she feels the fabric being peeled away, her body tingling with excitement at the thought of what's to come."
            scene v19-352
            b "Oh, Samir... That feels amazing..."
            sam "You're so beautiful, Banu... I can't resist you..."
            "Banu shivers with anticipation as Samir's thumb brushes against her asshole, sending a jolt of pleasure through her body."
            "Samir's gentle massage becomes more intense, his thumb tracing small circles around her sensitive entrance, driving Banu wild with need."
            sam "You like that, huh?"
            b "Mmm, yes... Don't stop."
            sam "I won't, beautiful. Just relax and enjoy."
            b "I am... I am enjoying it so much."
            scene v19-353
            b "Oh, Samir... Yes, right there..."
            sam "You're so wet already..."
            b "I can't help it... You're driving me crazy."
            sam "I want to make you feel even crazier..."
            scene v19-354 with dissolve
            b "Yes, Samir... Just like that... Oh god..."
            sam "You like that, huh? Tell me how much you want it."
            b "I want it so bad... Please don't stop..."
            sam "I won't stop until you cum for me, Banu..."
            scene v19-355
            b "Ahhhhh...Samir...we have to s...stop..."
            sam "That's it, Banu. You want me to fuck you, don't you?"
            sam "You're so wet for me."
            b "You don't know what you are talking."
            sam "You want my cock, Banu? Tell me how badly you want it."
            b "I... I don't know... It's just..."
            sam "You want it, Banu. You want my cock inside you."
            menu:
                "Stop him":
                    $ banuletsamirfuckher = False
                    $ renpy.block_rollback()
                    stop music
                    b "Samir, hold on a moment."
                    scene v19-356 with fade
                    "Banu sits on the bed, covering herself..."
                    sam "What's the matter, Banu?"
                    b "I... I can't do this, Samir. It's not right."
                    sam "I'm sorry, Banu. I didn't mean to make you uncomfortable."
                    scene v19-357
                    b "It's not your fault. I should have stopped this sooner. "
                    b "You're too young, Samir, and I'm... I'm old enough to be your mother."
                    sam "I understand, Banu. I didn't mean to cross any boundaries."
                    b "I appreciate your understanding, Samir."
                    b "I'm sorry this happened."
                    b "Please, leave now..."
                    sam "It's okay, Banu. I'll go now. Take care."
                "Let him fuck you":



                    $ banuletsamirfuckher = True
                    $ renpy.block_rollback()

                    stop music

                    jump samirfucksbanu_bedroom



label samirfucksbanu_bedroom_continue:

    scene black with dissolve
    "..."
    "The atmosphere in Polad and Nesrin's home was warm and inviting, with soft lighting casting a cozy glow over the room."
    scene v19-375 with dissolve
    play sound "voices/glass.wav"
    "Banu found herself seated on the plush sofa, and her attention kept drifting towards Polad, who sat across from her in a black tank top and pants."
    "She couldn't shake the feeling that he had ulterior motives, especially considering their past encounters."
    "Polad's occasional glances in her direction didn't escape Banu's notice, and each time their eyes met, she quickly averted her gaze, offering polite smiles but keeping her guard up."
    p "So, Banu, tell me about your latest project at work. I'm sure it's as impressive as always."
    b "Oh, it's nothing too exciting, just the usual tasks. We're focusing on improving efficiency in our department."
    p "Ah, efficiency, always important. But I'm sure you bring more than just efficiency to the table, Banu. You've got that spark, that drive."
    scene v19-376
    b "Thank you, Polad. I appreciate the vote of confidence."
    k "Hey, Polad, remember that time we went fishing and you caught that massive trout? We thought it was going to pull you into the river!"
    p "Oh, how could I forget? That was quite the adventure, wasn't it?"
    scene v19-377
    n "Speaking of adventures, Banu, have you and Kamil planned any trips lately? You always have the best stories from your travels."
    b "Not recently, Nesrin. We've been quite busy with work and other commitments."
    scene v19-376
    p "Well, you know what they say, all work and no play makes Banu a dull girl. We should plan a getaway sometime, just to unwind."
    b "That sounds nice, Polad, but maybe another time."
    p "Of course, Banu. But you know where to find me if you ever change your mind."
    b "Thanks, Polad. I'll keep that in mind."
    scene v19-377
    n "So tell us about your marriage, Banu. Does Kamil treat you right at nights?"
    n "Is he good in bed?"
    b "Oh, uh, well, you know how it is, Nesrin. Just your typical married life."
    n "Come on, spill the beans! We're all friends here. Is Kamil still keeping things exciting?"
    b "Well, um, he tries his best, I suppose. We have our moments."
    b "Maybe let's change the topic?"
    n "Oh, come on, Banu! You can't handle a little bedroom talk? Polad's just amazing, you know? He really knows how to... satisfy a woman."
    b "Well, uh, good for you, Nesrin. I'm glad you two are happy together."
    n "But seriously, Banu, if you ever want some pointers on how to really blow Kamil's mind, just let me know. I'm full of ideas."
    b "Um, thanks, Nesrin. I'll... keep that in mind."
    scene v19-378
    play sound "voices/glass.wav"
    p "You know, Banu, I can't help but notice how stunning you look tonight. Those curves of yours are driving me crazy."
    n "Polad, honey, maybe you should lay off a bit. You're making Banu uncomfortable."
    p "Ah, Kamil, my man! You look like you've had a bit too much to drink."
    p "But seriously, do you really think you're satisfying your wife in bed?"
    p "I mean, look at her! She's practically glowing. You must be doing something right."
    scene v19-379
    k "Hey, what's that supposed to mean, Polad? You think you can do better? Huh?"
    b "Kamil, please, let's not make a scene."
    p "Whoa, whoa, easy there, Kamil. I was just making an observation. No need to get all defensive."
    k "You're always eyeing up my wife, aren't you? Always trying to get a piece of her!"
    scene v19-380
    p "Do you really think so?"
    b "Kamil, you're drunk. You don't know what you are talking. Polad...please stop this."
    n "Kamil, honey, calm down. Polad's just joking around."
    p "Oh, but Banu is quite the catch, isn't she? I mean, who wouldn't want a taste?"
    b "Okay, that's enough, Polad. Let's just enjoy the evening, shall we?"
    scene v19-379
    k "I know what's going on here. You think I'm blind, Polad? You want to get with Banu, don't you?"
    b "Kamil, sweetheart, it's just the alcohol talking. Let's not make a scene."
    n "Kamil, come on now. Let's not jump to conclusions. Polad was just teasing."
    p "Hey, Kamil, buddy, you know me. Just messing around. No harm meant, okay?"
    scene v19-381
    p "You know, Kamil, I've always wondered... Can a man like you really satisfy a woman like Banu?"
    p "I mean, look at her. She's a woman with needs, desires... And you, you're just... well, you."
    k "What are you trying to say?"
    p "I'm just saying, Kamil, a woman like Banu, she needs a real man."
    p "Someone who knows how to handle her. Someone like me, for example."
    k "Polad, cut it out. You're crossing a line."
    "Banu shoots Polad a sharp look, a mixture of anger and disgust evident on her face. "
    "She's had enough of his inappropriate remarks."
    b "Polad! That is--"
    scene v19-382 with hpunch
    play sound "voices/glass.wav"
    "As Banu finally confronts Polad, his arrogance reaches new heights. With a smirk, he deliberately tips his wine glass, spilling its contents onto Banu's clothes."
    scene v19-383 with fade
    "Banu, taken aback by the deliberate act, feels the cold liquid seeping into her clothes."
    "Anger flashes in her eyes, but she manages to maintain her composure. "
    b "Polad, what the hell?!"
    p "Oops, my bad. Clumsy me."
    b "You did that on purpose."
    p "Did I? Well, accidents happen."
    scene v19-384 with fade
    n "Banu, do you want me to come with you? I can help you clean up."
    "But before Banu can respond, Polad interjects, his tone oddly insistent."
    scene v19-385
    b "Don't worry, Nesrin I can..."
    p "No, no, no need for that, Nesrin. I'll take care of it."
    p "After all, it's my fault... "
    scene v19-386 with fade
    p "Hey, Kamil, buddy, Looks like I gotta take care of your missus for a bit. Don't worry, I'll bring her back in one piece."
    "Kamil, barely registering Polad's words, merely nods in response, his mind clouded by the alcohol-induced haze."
    "He mumbles something incomprehensible, a half-hearted attempt at acknowledgment, before sinking deeper into the cushions of the sofa."
    scene v19-387
    k "You're so clumsy, Polad."
    p "Clumsy? Me?"
    "He winks at Kamil, a hint of mischief in his eyes, before turning his attention back to Banu."
    p "Don't worry, Kamil, I'll make sure she's alright."
    "Kamil slurs his words, leaning back heavily against the sofa."
    k "Yeah, yeah, whatever..."
    k "Just... take care of her, okay?"
    "His words are tinged with a mixture of drunken concern and resignation."
    scene v19-388 with fade
    "As Polad enters the bathroom, Banu can feel the tension crackling in the air like electricity."
    "She knew exactly what he wanted."
    "Her heart pounds in her chest, torn between the thrill of temptation and the guilt of betrayal."
    "Kamil was just in the other room, oblivious to the dangerous game being played behind closed doors. "
    scene v19-389 with fade
    b "Polad..."
    p "You know why I'm here."
    b "You're out of your mind, Polad. Get out of here."
    "Instead, he takes another step closer, invading her personal space with a predatory grace that leaves her feeling trapped and vulnerable."
    scene v19-390
    p "I saw the way you were looking at me all evening, Banu."
    p "I could practically feel the heat between us every time our eyes met."
    b "She tries to deny it, to cling to the last shreds of her self-control, but deep down, she knows he's right. "
    p "Admit it, Banu. You're already wet for me, aren't you? You can't resist the pull of your own desires any longer."
    b "W...what are you saying?"
    scene v19-391 with hpunch
    play music "audio/weakbanu.mp3"
    "Banu's heart pounds in her chest as Polad presses her against the wall, his body inches away from hers."
    "She can feel the heat radiating from his skin, his breath hot against her lips as he leans in closer, his eyes smoldering with desire."
    p "I know you love me, Banu. You always have. Even when you were with Alper, I could see it in your eyes."
    b "Don't be ridiculous, Polad. I never felt that way about you."
    p "Oh, but you did. And I loved you, too. I loved you when you were with Alper, even though it tore me apart inside."
    p "But when you ended up with a weak asshole like Kamil, I couldn't stand by and watch anymore. I had to have you for myself."
    b "You're out of your mind, Polad. This is all just a fantasy of yours."
    p "Is it, Banu? Or are you just too scared to admit the truth?"
    p "We both know there's something between us, something undeniable."
    p "And now that I have you here, alone with me in this bathroom, I'm not going to let you go until you admit it."
    p "Now I'm going to remind you how you feel with me..."
    menu:
        "Push him away":
            $ banupushpoladawaybathroom = True
            $ renpy.block_rollback()
            scene v19-392 with hpunch
            stop music
            "Banu pushes him away with all her power, her heart pounding with fear and anger."
            b "Get away from me, Polad! This is insane!"
            "Polad steps back, a smirk playing on his lips."
            p "You can push me away all you want, Banu, but we both know the truth. You can't deny the chemistry between us."
            b "Get out, Polad! Leave now before I call Kamil and Nesrin!"
            p "Fine, Banu. But remember, I'll always be here, waiting for you."
            "With one last lingering look, Polad turns and exits the bathroom, leaving Banu feeling shaken and vulnerable."
        "Let him continue":


            $ banupushpoladawaybathroom = False
            $ renpy.block_rollback()
            scene black with dissolve
            "As Polad peeps Banu ain't fighting him off, he quickly rips off her skirt, leaving her in just her black undies and bra."
            scene v19-393 with fade
            "In a flash, he's all over her, locking lips with her in a wild kiss. "
            "Banu's mind's all over the place, lost in the heat of his smooches."
            "No time for second thoughts, Polad's on a roll, planting kisses all over Banu, who's getting hot under the collar, swept away by the moment."
            "With each smooch, she's getting deeper into it, unable to resist his charms, totally caught up in the passion."
            scene v19-394
            "As Polad's lips work their magic, his hands ain't idle either; they're all over Banu's body, exploring every curve and contour."
            "In between kisses, he's whispering all sorts of dirty words in her ear, sending shivers down her spine and making her weak at the knees."
            p "I've been wanting to taste you for so long. Your husband ain't got nothing on me, baby. I'm gonna show you what a real man can do."
            "His words are like fire against her skin, setting her ablaze with longing and anticipation."
            menu:
                "Stop him":
                    $ banuletpoladfuckherbathroom = False
                    $ renpy.block_rollback()
                    stop music
                    scene v19-395 with hpunch
                    "Banu summons every ounce of strength she has left and pushes Polad away, her heart racing with conflicting emotions."
                    b "Get out, Polad."
                    "She demands, her voice trembling with resolve."
                    b "This ain't right. I'm married, and you're crossing a line."
                    "With a firm hand, she gestures towards the door, her eyes blazing with determination."
                "Let him continue":



                    $ banuletpoladfuckherbathroom = True
                    $ renpy.block_rollback()



                    jump poladfuckbanubathcheatroute


label poladfuckbanubathcheatroute_continue:

    scene black with dissolve
    "..."
    scene v19-423 with dissolve
    "As Banu heads to grab another whiskey bottle, Kamil and Hassan, Leyla's husband continue their conversation in the kitchen."
    k "So, how's work going, Hassan?"
    hs "It's been alright, Kamil. Same old, you know. How about you? How's everything at the office?"
    k "Oh, you know how it is. Busy as ever. But hey, at least I have Banu's delicious cooking to look forward to when I get home."
    hs "Yeah, Banu's a great cook. That steak smells amazing."
    scene v19-424
    k "Yeah, she really outdid herself tonight. You're lucky to have Leyla, Hassan. She's just as talented in the kitchen."
    hs "Thanks, Kamil. Yeah, Leyla's the best. We make a great team."
    "As they chat, Banu returns with the whiskey bottle, pouring drinks for everyone."
    "The atmosphere is warm and relaxed as they enjoy their supper together."
    scene v19-425
    b "Here we go, another bottle. You two are really enjoying yourselves tonight."
    k "Absolutely, Banu. Your steak is so good; it deserves a good drink to go with it."
    hs "Agreed. We're lucky to have such a talented cook in the family."
    scene v19-426 with dissolve
    b "So I'd like to ask you a question, Hassan, have you ever been tempted to cheat?"
    hs "Uh, well, you know... I mean, who hasn't been tempted, right? But Leyla means the world to me. I couldn't imagine hurting her like that."
    b "So, Hassan, tell me, if Leyla ever caught you cheating, do you think she'd let you off easy, or would she go all 'femme fatale' on you?"
    hs "Oh, I wouldn't want to find out! Leyla's got a mean right hook when she's angry."
    b "Haha, good answer! Best not to test her, right?"
    scene v19-427
    k "What are you two talking about?"
    b "Oh, just teasing Hassan a bit, you know, about staying faithful to Leyla."
    k "Yeah, that's a lesson every guy should learn early on!"
    k "You know Hassan why don't skeletons fight each other?"
    hs "No, why is that?"
    k "Because they don't have the guts!"
    "There's an awkward silence as Banu and Hassan exchange another glance."
    b "Oh, Kamil, really? You never fail to bring the dad jokes."
    hs "Well, that's... quite a joke, Kamil."
    k "Yeah, sorry guys. I'll try to be funnier next time."
    scene v19-428
    hs "Well, I guess we know who won't be doing stand-up comedy anytime soon."
    b "Definitely not Kamil, that's for sure. Poor guy, can't even tell a decent joke."
    k "Yeah, I think I need to work on my material. Excuse me for a sec, guys, gotta hit the bathroom."
    scene v19-429 with fade
    hs "So how is the stuff with Polad?"
    b "What about Polad? How do you know him?"
    hs "I've heard some things, Banu. Rumors, whispers... about you and him."
    b "Rumors? What kind of rumors?"
    hs "You know how it is. People talk. They say you two have been spending a lot of time together, behind closed doors."
    hs "From Kamil's jokes I can tell he knows nothing about this, right?"
    scene v19-430
    b "Polad's been a family friend for years, practically like a brother."
    b "There's nothing going on between us."
    hs "I know you're a horny hot wife who needs to get her every hole filled."
    "Banu recoils at Hassan's bold assertion, her cheeks flushing with a mixture of embarrassment and indignation."
    scene v19-431
    b "Excuse me? What on earth are you talking about, Hassan?"
    hs "Oh, come on, Banu. Don't play coy with me. I've seen the way you carry yourself. You're a passionate woman, and there's nothing wrong with that."
    b "That's absolutely none of your business, Hassan. And it's completely inappropriate for you to make such baseless assumptions about me."
    hs "I know how many times Polad has fucked you, Banu."
    hs "And don't think I haven't heard about you sucking off that policeman next door."
    scene v19-432
    b "How... how dare you say such things?"
    b "How dare you! Who do you think you are, coming into my house and spewing such filth?"
    b "You know nothing about me! Nothing about what I've been through, what I've sacrificed for this family!"
    hs "Oh, I know more than you think, Banu. I know about the lies, the deceit. "
    hs "And I know that deep down, you're nothing but a desperate, lonely woman who will do anything for a taste of excitement."
    b "You...."
    k "What's going on here? "
    "As Kamil returns from the bathroom, Banu's words hang in the air like a heavy cloud, her anger simmering just beneath the surface as she struggles to find her voice."
    scene v19-433 with fade
    k "Why is everyone so tense?"
    b "It's nothing, Kamil. Just a silly argument."
    k "Are you sure? You seem upset."
    b "I'm fine, really. Just tired."
    k "Did I miss something? Why does it feel like I walked into a war zone?"
    b "Just a difference of opinion, that's all."
    "But even as she speaks, Banu can feel the weight of Hassan's accusations bearing down on her, threatening to expose the truth she's been desperately trying to conceal."
    scene black with fade
    "As the night wears on and the effects of the alcohol take their toll, Kamil's eyelids grow heavy, his head gradually sinking lower until it comes to rest on the table before him. "
    scene v19-434 with dissolve
    "With Kamil slumbering peacefully, Banu and Hassan find themselves alone in the kitchen."
    hs "So you can admit that now. He's not listening to us."
    b "What?"
    hs "Come on, Banu. Let's not pretend. We both know the truth about you."
    b "What do you mean?"
    hs "You're just a horny little slut who can't get enough cock. And that sweet little pussy of yours... I bet it's dripping wet right now, isn't it?"
    b "Stop it, Hassan. I won't tolerate this filth."
    hs "Filth? That's rich coming from you, Banu. You're the one who's been spreading her legs for anyone who'll have her. "
    hs "You're nothing but a cheap whore, and you know it."
    b "I won't listen to this. I won't let you degrade me any further."
    hs "Too late for that, Banu. You've already degraded yourself enough. Now it's my turn to have a little fun with you."
    hs "Why don't we take Kamil to bed? It's getting late, and we can continue our conversation without disturbing him."
    scene v19-435
    "Together, Banu and Hassan go under Kamil's arms, lifting him gently, and carry him to the bedroom."
    hs "He's too blinded by his love for you to see the truth. And by the time he realizes what you really are, it'll be too late."
    b "You're a monster, Hassan. A heartless, soulless monster."
    scene v19-436 with fade
    hs "Look at him, Banu. He's pathetic. Passed out drunk like always."
    b "Shh, Hassan! He might hear us."
    hs "Let him hear. What's he going to do? He's too drunk to even know what's going on."
    k "I.....lo....love....Banu....hmmm..."
    "Banu and Hassan exchange uneasy glances before continuing to help Kamil to bed."
    scene v19-437 with dissolve
    hs "And I have to say, it's impressive how you manage to keep up this facade of the perfect wife."
    b "Fine, you want to know the truth? I'm a cheating, horny wife. There, I said it. What are you going to do about it, Hassan?"
    b "You think you can just come in here and talk to me like that?"
    scene v19-438
    b "You son of a bitch! I'll have you know I'm not afraid of you or your pathetic attempts at blackmail."
    b "Now get the fuck out of the room."
    hs "Oh, I think you're more afraid than you're letting on, Banu. I can see it in your eyes. "
    hs "You're trembling with desire, just waiting for someone to take control."
    b "You're delusional if you think I'd ever let someone like you touch me. "
    b "I'd sooner get my pussy licked by a dog than let you lay a finger on me."
    scene v19-439
    hs "Is that so? Because from where I'm standing, you look like you're practically begging for it. You want someone to ravish you, to make you feel alive again."
    b "You're disgusting, Hassan. I won't let you manipulate me like this."
    hs "You can deny it all you want, Banu, but I see right through you. "
    hs "You're just a desperate housewife, craving attention and satisfaction that your sorry excuse of a husband can't provide."
    b "How dare you speak to me like that? You have no right to judge me or my marriage."
    hs "Oh, but I do have the right, Banu. I know everything about you. Your desires, your secrets... You can't hide from me."
    b "What do you want from me, Hassan? Why are you doing this?"
    hs "What I want is simple, Banu. I want you. I want to see you beg for it, to see you submit to your desires."
    scene v19-440
    b "You're insane! I would never..."
    hs "But you will, Banu. Because deep down, you know you want it. You want to feel my hands on your body, my lips on your skin."
    b "I... I can't...You're my daughter's husband....how can you..."
    hs "I'm going to show you pleasure like you've never experienced before, Banu. "
    hs "But first, you need to see what you're missing out on."
    scene v19-441
    "Hassan gestures to the bulge in his pants, his cock straining against the fabric."
    hs "Take a good look, Banu. This is what you've been craving. This is what you need."
    scene v19-440
    "Banu's eyes widen as she stares at the bulge, unable to tear her gaze away."
    hs "Get on your knees, Banu."
    hs "Empty my balls. Then I may not talk to Kamil about your secret lovers."
    menu:
        "Obey him":
            $ banumakehassancum = True
            $ renpy.block_rollback()




            jump banu_makehassan_cum
        "Insult him":







            $ banumakehassancum = False
            $ renpy.block_rollback()
            scene v19-442
            b "You're nothing but a worthless piece of shit, Hassan. "
            b "If you ever dare to bring this up again, I'll make sure to humiliate you in ways you can't even imagine."
            hs "Banu..."
            b "I'd rather pee on your face than let you speak another word about this."
            scene v19-443
            hs "You think you can threaten me? You're just a slut hiding behind your husband's back."
            hs "I'll expose you one way or another."
            b "Keep dreaming, Hassan. You're not even worth the dirt under my shoes. Now get out before I call the police."
            "With a look of disgust, Banu watches as Hassan slinks out of the room, her words hanging in the air as a warning."




label banu_makehassan_cum_continue:




    if banumakehassancum == True:


        menu:
            "Continue cheating with Hassan":

                jump hassanending
            "Forget about Hassan":



                jump nohassanendings
    else:




        jump nohassanendings









label nohassanendings:















    $ banuenterruslanroom = False






    if banublockturan == False:


        jump turan_ending





    if agreetoruslanoffer == True:

        scene black with dissolve
        "..."
        b_ "God, he wouldn’t even notice if I didn’t come back for an hour."
        scene end-110 with dissolve
        b_ "He’s useless when he sleeps. Just drools and snores like he earned it."
        b_ "He used to fuck me right here. Remember? When we were still new."
        b_ "Bent me over this very spot like he was starving."
        scene end-111
        b_ "Now? Now it’s lights off, missionary, thirty-second thrusts, then a kiss on the forehead like I’m his fucking niece."
        b_ "He thinks I’m satisfied. That a kiss in the morning and half a fuck at night is enough to keep me loyal. Baby, no."
        b_ "I need hands grabbing. Teeth grazing. I need to be told to kneel."
        b_ "I miss when someone looked at me like I was worth sinning for."
        b_ "Ruslan...I shouldn’t even think about him."
        b_ "Ruslan..."
        scene end-112 with fade
        b_ "Thin little thing, all bones and cheekbones..."
        b_ "Grew tall like a weed. Quiet. Always watching me."
        b_ "I should go back. Kamil’s still asleep. He wouldn’t notice if I slipped back in smelling like sweat and sin."
        b_ "…But Ruslan’s door is right there."
        b_ "I’ve seen the outline in his shorts. Not even trying to hide it. That cock—fuck—it’s big."
        b_ "And I can’t stop looking."
        b_ "It’s too big. He’d stretch me wide open. Make me cry."
        b_ "He’d fuck me stupid, make me forget how to lie about it afterward."











        menu:
            "Enter his room":

                $ banuenterruslanroom = True
                $ renpy.block_rollback()

                jump ruslan_ending
            "Forget about Ruslan":




                $ banuenterruslanroom = False
                $ renpy.block_rollback()


                scene end-113 with fade
                b_ "What the fuck am I doing."
                b_ "I was really about to walk in there? Let him grab me?"
                b_ "Let him fuck me like a dirty secret while his father sleeps two rooms away?"
                b_ "I’m not that far gone. Not yet."
                b_ "No. No."


























    $ banucheatingpoints = 0




    if banupushpoladaway == True:
        $ banucheatingpoints -= 1

    if banupushpoladaway == False:
        $ banucheatingpoints += 1

    if banuslappoladcheatingroute == True:
        $ banucheatingpoints -= 1

    if banuslappoladcheatingroute == False:
        $ banucheatingpoints += 1

    if banutakeleylaout == True:
        $ banucheatingpoints -= 1

    if banutakeleylaout == False:
        $ banucheatingpoints += 1

    if banuleftahmedplace == True:
        $ banucheatingpoints -= 1

    if banuleftahmedplace == False:
        $ banucheatingpoints += 1

    if banuteasesamirbedroom == True:
        $ banucheatingpoints += 1

    if banuteasesamirbedroom == False:
        $ banucheatingpoints -= 1

    if banuletsamirfuckher == False:
        $ banucheatingpoints -= 1

    if banuletsamirfuckher == True:
        $ banucheatingpoints += 1

    if banuletsamirfuckherass == True:
        $ banucheatingpoints += 1

    if banuletsamirfuckherass == False:
        $ banucheatingpoints -= 1

    if banupushpoladawaybathroom == True:
        $ banucheatingpoints -= 1

    if banupushpoladawaybathroom == False:
        $ banucheatingpoints += 1

    if banuletpoladfuckherbathroom == False:
        $ banucheatingpoints -= 1

    if banuletpoladfuckherbathroom == True:
        $ banucheatingpoints += 1

    if banumakehassancum == False:
        $ banucheatingpoints -= 1

    if banumakehassancum == True:
        $ banucheatingpoints += 1

    if banusuckhassancock == False:
        $ banucheatingpoints -= 1

    if banusuckhassancock == True:
        $ banucheatingpoints += 1

    if banutakeoffhertophassan == False:
        $ banucheatingpoints -= 1

    if banutakeoffhertophassan == True:
        $ banucheatingpoints += 1











    if banucheatingpoints >= 5:


        jump kamilkillsbanu_ending



    if banucheatingpoints <= -5:


        jump kamilkillspolad_ending


    if banucheatingpoints >= -4:
        if banucheatingpoints <= 4:


            jump banukeepcheating_ending















label banukeepcheating_ending:

    scene black with dissolve

    play music "audio/romantic.mp3"


    "..."
    "It's a quiet night. Kamil lies face down on the bed, his eyes closed, a serene smile on his face."
    scene end-61 with blinds
    "Banu, in her underwear, straddles Kamil’s lower back, her hands expertly kneading his tense muscles."
    k "Your hands are magic, Banu. I don’t know how you do it, but you always know exactly where it hurts."
    b "Maybe it’s because I know you so well, Kamil. Every part of you."
    b "How's this? Better?"
    scene end-63
    k "Perfect. You’re perfect."
    k "I don’t deserve you sometimes, you know."
    b "Don’t be silly. You’re my husband. Of course you deserve me."
    k "You’re my anchor, Banu. My whole world. Without you, I’d be lost."
    b "And you’ll never be without me, Kamil. I’ll always be here."
    scene end-62
    k "You know, Banu, I was thinking... maybe we could start trying for a baby."
    b "A baby? You mean… our imaginary child?"
    k "What do you mean?"
    b "Kamil, are you forgetting what the doctor said? Or do you think miracles happen overnight?"
    b "Fair? Kamil, come on. You’ve known this for months. You’re… impotent."
    b "No baby is coming, no matter how hard you ‘try.’ What’s the point of even pretending?"
    k "I know what the doctor said, Banu. I just… I thought maybe… maybe things could change. "
    b "A way? Like what? Magic? A miracle cure? Let’s be real, Kamil."
    scene end-63
    k "You know, Polad’s such a stand-up guy. He’s always looking out for us."
    k "Like when I couldn’t fix the faucet last month—he came over right away, no questions asked."
    k "He’s got such a good heart. Honestly, Banu, I’m lucky to have a friend like him."
    k "A man like that—you don’t find loyalty like his every day."
    scene end-64
    b "Mmm, loyal. That’s one word for him."
    k "Seriously, though. Polad’s the kind of guy you can trust with anything."
    k "If I ever needed someone to have my back, it’d be him."
    k "He’s got this way of handling things. So confident, so in control."
    b_ "You have no idea how confident he is when he’s inside me."
    k "Oh, Banu, don’t forget—can you stop by Polad’s place tomorrow and pick up that toolbox for me?"
    k "He said it’s ready."
    b "The toolbox, huh?"
    k "Yeah, you know Polad. Always reliable. He’s been holding onto it for a while, but I’ve been too busy to swing by."
    b "Sure, I can grab it."
    k "And while you’re there, maybe ask if he’s still got those shelves he mentioned?"
    k "We could really use them in the living room."
    b "Shelves too? Anything else? Should I just move half of Polad’s apartment into ours?"
    k "Hey, don’t tempt me! Polad probably wouldn’t mind—he’s such a generous guy."
    b "Generous. Yeah, that’s one way to describe him."
    b "I’ll take care of it tomorrow."
    scene black with dissolve
    "..."
    "..."
    "The next day..."

    stop music



    $ renpy.sound.play("voices/slapmoanmedium.mp3", loop=True)



    "Polad lounges on the sofa, his body lean and muscular, a faint smirk on his lips as he watches Banu on top of him. "
    show animation_banu_ride_polad
    b "I… I can’t stop… Polad… I can’t…"
    p "Then don’t. Let it all out, Banu. Show me how much you need this."
    b "You… you make me feel alive. I… hate how much I—"
    p "Don’t think. Just feel. This is who you are, Banu. Stop pretending to be someone else."
    b "Kamil… he… he doesn’t… he’ll never…"
    p "He’ll never touch you like this. Never make you lose control."
    show animasiya_banu_ridingbackview
    b "Say it again… tell me… tell me I’m yours."
    p "You’re mine, Banu. Every inch of you. No one else makes you feel this way, and you know it."
    b "Yes… yours… only yours…"
    p "I’m going to knock you up, Banu. Make you mine forever."
    b "Do it... knock me up, Polad."
    b "Fuck me....ahhh...destroy me..."
    p "Fuck! I'm gonna cum deep inside of you...make you my woman..."
    b "Give it to me, Polad!"
    scene end-65 with flash
    stop sound
    $ renpy.sound.play("voices/ahlongcum.mp3", loop=True)
    b "Ohhh fuckk keep fucking me Polad!"
    b "Ohhhh fuck yes! "
    b "Aahhh oohhhh uggghhhh fuckkkk..."
    scene end-66 with flash
    b "Uggghhhh fuckkkk Polad! "
    p "Ahhhhhhhh fuckk keep going Banu... I'm gonna cum so fucking hard for you."
    "She gripped Polad’s shoulders with trembling hands, her nails leaving faint, red trails along his chest."
    "She closed her eyes, her body still trembling, as the weight of what had just happened began to sink in."
    scene end-67 with flash
    p "Ohhh fuck yesssssss Polad I'm cumminggggggg..."
    "For a moment, neither of them spoke. "
    "Polad’s smirk returned as he looked at her, victorious."
    scene black with dissolve
    stop sound
    stop music

    "..."
    scene end-68 with dissolve

    play music "audio/intro.mp3"


    p "You’re completely mine now, aren’t you?"
    b "I hate how much you make me need this... need you."
    b "You make me forget who I am… but I don’t know if that’s a good thing."
    p "It’s the best thing. When you’re with me, you’re who you really are."
    p "I’ll make you pregnant, Banu. Not that impotent fool you’re married to—me. "
    p "You’ll carry my child, and Kamil will never know."
    b "Polad...what?"
    p "You know it, Banu. I’ll be the one to give you a son. Not Kamil. "
    b "And that son… he’ll be like you. Strong, powerful… unstoppable."
    scene end-70
    p "That’s right. My blood will run through his veins."
    p "He’ll carry my strength, my name—even if Kamil believes it’s his."
    b "I want that, Polad. I want to raise your son."
    b "A son who’s powerful, who knows how to take what he wants… like his father."
    p "Good. Because you’ll carry my legacy, Banu. You’re mine now, and so is everything that comes after."
    b "Polad… you’re everything I’ve ever wanted. The man I dreamed of. So powerful, so confident… so in control."
    scene end-69
    p "I’m glad you’re finally realizing that. Took you long enough, didn’t it?"
    b "No… I’ve always known. Even years ago, before all of this… I couldn’t stop thinking about you."
    b "Every time you walked into a room, I felt it. That pull, that… power."
    p "Is that so? And here I thought you were just the perfect little wife back then."
    b "I tried to be. But even then, late at night… I’d think about you."
    b "About what it would be like to have you touch me, to make me yours. And… I’d lose myself in those thoughts."
    p "You’re saying you masturbated, thinking about me?"
    b "Yes. I couldn’t help it. You were everything I wanted but couldn’t have. "
    b "Every time I closed my eyes, it was you."
    p "Right now, my seed is inside you, Banu."
    scene end-71
    p "Trying to take root, trying to make you mine in every way."
    b "Polad..."
    p "While Kamil is happy, my seed will be the one growing inside you."
    b "And I’ll carry it… raise it… a child strong, just like you."
    p "That’s right. You’ll raise my child under his roof, and every time you look at him, you’ll remember this moment."
    p "Remember who you belong to."
    b "I already do, Polad. I belong to you… completely."
    p "Tomorrow, I’ll drop by your place. Say hello to Kamil."
    b "Polad… you wouldn’t."
    p "Why not? Kamil trusts me. He’ll probably offer me wine and thank me for being such a good friend."
    b "You’re insane…"
    p "Relax, Banu. I’ll play the part, just like always. He’ll never suspect a thing."
    stop music
    scene black with dissolve
    "..."
    "The next day..."
    "Kamil sits slouched in his chair, red-faced and clearly drunk, his words slurred as he tries to keep up with the conversation."
    scene end-72 with dissolve

    play music "audio/story_1.mp3"

    "Banu and Polad, sharing glances across the table, exchange subtle smirks..."
    k "To… to good friends, huh? You two… you’re the best."
    b "Oh, Kamil, you’re so lucky to have a friend like Polad. He’s so... reliable. Always there when you need him."
    scene end-73
    p "Of course, Banu. I’d do anything for Kamil. He’s like a brother to me."
    k "That’s right! You’re my brother, Polad. My brother from… from another mother!"
    b "You’re so sweet, Kamil. Always so trusting. It’s one of your best qualities."
    p "Yeah, Kamil, you’ve got a heart of gold. Not everyone can say that. It’s… rare."
    scene end-75
    k "Rare? Like… like a steak? You saying I’m like a steak, Polad?"
    b "Oh, Kamil, you’re adorable. No, Polad’s saying you’re… one of a kind."
    p "Exactly. One of a kind. A treasure, really."
    k "You two… you’re too good to me. I don’t deserve friends like you."
    k "Or a wife like Banu. She’s perfect, you know? My perfect Banu."
    k "Banu’s the best. She’s… she’s my everything."
    scene end-76
    k "Here's to great nights like these, huh? Best friends and beautiful wives!"
    b "Yes, cheers to good friends who always know how to... handle things."
    p "Absolutely. It’s all about knowing how to push the right buttons, wouldn’t you say, Banu?"
    k "Polad always knows what to do! He’s got a knack for fixing things that are... broken."
    scene end-74
    b "I’ve noticed. It’s quite a... handy skill."
    p "I’m always ready to lend a hand, especially to those who appreciate good... craftsmanship."
    k "Polad helped me fix the garage door last week. Ran smooth as silk after he was done with it."
    b "I bet it did. Polad has a way of making everything... work better."
    scene end-76
    p "I aim to please. It’s all about giving things the right... touch."
    k "You two… you’re the best, you know that? Best friends… best everything!"
    p "We know, Kamil. You’re lucky to have us."
    scene end-74
    b "I think I need a little air. It’s so warm in here."
    k "Go, go! Do what you need, Banu."
    scene end-76
    p "Don’t drink too much, my friend. I’ll be right back. Just need to… check on something."
    scene end-77
    k "Yeah, yeah. You’re the best, Polad."
    k "To me! Kamil… the greatest husband… and the greatest friend!"
    k "To Kamil! The man of the house, the heart of the party… and the best damn drinker in the room!"
    k "Lucky Kamil… yeah, that’s me."
    scene end-78 with fade
    play music "audio/heatedsex.mp3"


    p "You hear him out there? Toasting himself like the king of the world."
    b "Polad, he’s right there… what if—"
    p "He won’t notice. He never notices, Banu. That’s why we’re here, isn’t it?"
    scene end-79
    b "This is wrong… so wrong...mmmm...your cock is so delicious...mmm.."
    p "This is what you want."
    p "No second thoughts now. You’re already here."
    p "If only Kamil knew…"
    b "Don’t talk about him like that, Polad. He trusts you. He trusts… me."
    p "Shut up and suck my cock."
    scene end-80
    p "How does it feel?"
    b "Uggghh fuckk your cock is so big..."
    p "Now take it deeper."

    show animasiya_banusuckpoladkitchen

    $ renpy.sound.play("voices/bj.mp3", loop=True)


    p "Yesss, that's it..."
    p "You really are something else, Banu. "
    p "Standing here, with your husband just a few feet away, pretending to be the perfect little wife and sucking my cock."
    b "Mmmmm...."
    p "You’re such a bitch, Banu."
    p "Cheating on the man who worships the ground you walk on. And the worst part? You love it."
    b "Polad, don’t—"
    p "You like this. You like sneaking around, lying to his face, and coming to me like the desperate little bitch you are."
    b "Mmmmph..."
    p "Admit it, Banu. You’ve never felt more alive than you do right now."
    p "You don’t need him. You need me."
    b "I… I can’t stop."
    p "Of course you can’t. You’re mine, Banu. "
    p "You’ve always been mine. And you love being exactly what you are."
    p "Ohhhh...shit, I'm cumming, Banu!"
    scene end-81 with flash
    b_ "I feel his warm load spill into my mouth as I swallow it hungrily. "
    b_ "I continue to work his cock, determined to make sure I get every drop."
    b_ "As I do, I feel my pussy tighten with pleasure."

    stop sound
    scene end-82 with fade

    $ renpy.sound.play("voices/kissing.mp3", loop=True)


    p "You drive me insane, Banu. Every second with you feels like I can’t get enough."
    b "Polad… I don’t know what’s happening to me. You make me forget everything."
    "He leans in again, his lips finding hers, their kiss growing deeper and more passionate."
    "Polad’s hands roam her back, pulling her closer."
    "Her entire body trembling with the thrill of the moment. "
    "The muffled sound of Kamil’s laughter in the other room barely registers as their focus remains solely on each other."
    "Time seems to blur as they lose themselves in the kiss, the weight of their actions momentarily forgotten."
    "When they finally pull apart, their foreheads rest against each other, their breaths mingling as they try to steady themselves."
    scene end-83
    b_ "Without realizing it, I grind my hips against his cock, pressing my clit against the tip of his cock."
    b_ "I whimper softly as I feel the pressure build between my legs."
    b_ "My heart races faster and I can barely contain my excitement."
    b "Ohhhh fuck..."
    stop sound
    stop music
    scene end-84 with fade
    "They stop in their tracks, both glancing at Kamil, whose head is slumped forward on the table."
    "The faint sound of his heavy breathing confirms he’s passed out, completely unaware of their absence."
    p "Looks like our good friend couldn’t handle his wine. Passed out cold."
    b "He always does this when he drinks too much. It’s nothing new."
    scene end-85
    p "Well, it works in our favor, doesn’t it? Makes it easier to keep secrets."
    b "Polad, stop. This is serious."
    p "Oh, come on, Banu. He’s out like a light. He won’t remember anything in the morning—if he even remembers tonight at all."
    p "Look at him. He’s completely out."
    p "Let’s get him to bed before he wakes up and starts mumbling nonsense."
    b "Are you sure? He’s fine here… we could just leave him."
    p "What kind of friend would I be if I left him like this? Come on, Banu. Help me out."
    scene end-86 with fade
    "Once they reach the bed, they lay him down gently, Polad’s smirk growing wider as he glances at Banu."
    p "He’s lucky to have us, you know. Who else would take care of him like this?"
    b "He doesn’t even realize how much trouble he causes when he drinks."



    p "Well, now that he’s all tucked in… what about you?"
    b "Polad… don’t. Not here."
    b "You're insane...don't..."
    "Their lips meet in a fiery, passionate kiss, all thoughts of guilt and consequences melting away as Polad’s hands hold her firmly."
    scene end-87 with fade
    $ renpy.sound.play("voices/kissing.mp3", loop=True)
    play music "audio/sexy.mp3"

    "Banu’s breath quickens, her body responding instinctively as she surrenders to the dangerous thrill of their forbidden connection."
    "In the background, Kamil’s snores continue, oblivious to the betrayal unfolding just feet away."
    "The kiss is intense, raw, and filled with a hunger that neither can suppress."
    scene end-88
    b "I hate you for making me feel this way… but I can’t stop."
    p "You’re mine, Banu. Admit it."
    b "I’m yours… Polad, I can’t fight it anymore."
    stop sound
    scene end-89 with vpunch
    play sound "voices/ah.mp3"
    b "Ahhhh...."
    "Polad, his strength and confidence on full display, effortlessly lowers Banu onto the mattress beside Kamil."
    "Kamil is sprawled on the bed, deeply asleep, his snores filling the air."
    b "Fuck....your cock...it's so big...."
    b "Polad… this is too much. He’s right here."
    p "Exactly. And he has no idea."
    b "You’re going to ruin me… ruin us."
    p "Fuck yes!"

    show animasiya_poladmissionarynextkamil
    $ renpy.sound.play("voices/slapmoanmedium.mp3", loop=True)


    b "Polad… I…"
    p "Stay quiet, Banu. We wouldn’t want to wake him, would we?"
    b "Polad… this is insane....ahhh... He’s right there."
    p "And yet, here you are. Letting me have you. Needing me."
    b "You're not going to stop, are you?"
    p "You’re going to carry my child, Banu. Not his."
    b "Ahhhh....You’re insane, Polad. You’re absolutely insane."
    p "Maybe. But you love it. Admit it—you want me to claim you, to give you what he never could."
    b "I… I want it. I want you."
    p "Good. Because you’re mine now, Banu."
    p "And when you raise my child under his roof, you’ll remember this moment. Every single day."
    scene end-90
    stop sound

    b "Your cock is driving me crazy...I'm about to cum..."
    p "Ohhh...me too..Banu..."
    b_ "As I continue to grind my clit against his cock, I feel his cock swell further, pressing against my sensitive flesh."
    b_ "I can tell he is close to the edge and I can feel the intensity of the moment building within me."
    b "Cum all over my pussy Polad."
    scene end-91 with flash
    play sound "voices/moanfinish.mp3"
    b "Ohhhh fuckk Polad..."
    b "Aaaaahhhhooooooohhhh... Aaaaaoooohhhh... Oooooooohhhh..."
    play sound "voices/man1.mp3"    
    p "Grrraaahhhh... Rrrrr... Hrrngg... Oooohhhh..."
    b "Oh fuckk Polad, give it to me. Fill me up and make me yours."
    p "You’re such a bad girl."
    b "Yes. I am a bad girl..."
    b "I… I don’t know what’s happening to me."
    b "I hate you for this… but I can’t stop. I don’t want to stop."
    p "Good. Because I’m not letting you go. "
    stop sound
    stop music

    scene black with dissolve
    "..."

    scene end-92 with dissolve
    play music "audio/intro.mp3"
    "Kamil is waiting..."
    "The sound of the bathroom door creaking open makes him look up."
    "Her expression is unreadable, a storm of emotions brewing beneath the surface."
    k "Well? What does it say, Banu? Tell me!"
    b "Kamil… it’s positive."
    k "Positive? You mean… we’re going to have a baby?"
    b "Yes, Kamil. We’re going to have a baby."
    scene end-93
    k "Banu, this is the happiest day of my life!"
    k "I can’t believe it. We’re going to have our baby. You… you’ve made me the luckiest man in the world."
    scene end-94
    k "Our baby… right here. Growing inside you, Banu. I can’t believe it. I’m… I’m going to be a dad."
    k "Do you think he can hear me yet?"
    b "It’s… too early for that, Kamil. But… he's there."
    scene end-95
    k "I already love him so much. Can you feel it? It’s like my heart’s going to burst."
    k "You’re giving me the greatest gift in the world, Banu."
    k "Hey, little one. It’s your dad. I can’t wait to meet you."
    k "I’m going to protect you and your mom forever, okay? You’re already so loved."
    b "You’ll be a great father, Kamil. The best."
    k "I can’t wait to meet him, Banu. To hold him, to see him grow… You’ve made me the happiest man alive."
    "Kamil continues to hug her belly, whispering promises to the child he believes is his..."
    stop music

    scene black with dissolve
    "..."
    "Several months later..."
    scene end-96 with dissolve
    play music "audio/slowsoft.mp3"
    k "I can’t wait for you to meet the baby. You’re going to be like an uncle."
    p "Congratulations again. You must be over the moon."
    k "Over the moon? That doesn’t even begin to describe it. Every day I wake up thinking, ‘How did I get so lucky?’ A baby, a beautiful wife…"
    scene end-97
    p "You’ve got it all, Kamil. A family on the way, a great home… the dream life, huh?"
    k "Exactly! And I owe so much of it to Banu. She’s incredible, isn’t she?"
    p "Oh, she’s one of a kind. You’re lucky, Kamil. Not everyone finds someone like her."
    p_ "You fool. That baby growing inside your wife isn’t yours—it’s mine."
    p_ "And every time you smile at me, trusting me like the idiot you are, I’m already planning the next time I’ll fuck her."
    p_ "I’m going to fuck your wife again and again, right under your nose."
    k "We’re thinking about strong names, you know? Something that means strength, courage. What do you think, Polad?"
    p "Strength and courage. Good choices, Kamil. Every child deserves a strong start."
    scene end-98 with fade
    b "The tea will be ready in a few minutes. I thought I’d check on you two."
    k "Come sit with us, Banu. You shouldn’t be on your feet so much. Isn’t that right, Polad?"
    p "Of course. You should take it easy, Banu. That baby needs all the energy it can get."
    scene end-99
    "Banu hesitates, then steps closer to the table, her hands resting protectively on her belly."
    "Instead of sitting, she stands near Polad, her presence charged with unspoken tension. Her eyes meet his..."
    k "She never listens to me, Polad. Always on the move, making sure everything is perfect. I tell her to relax, but she won’t sit still."
    p "Some things never change, do they? Always taking care of everything… and everyone."
    "Banu’s cheeks flush slightly, but she doesn’t look away."
    b "I just want what’s best for this family."
    scene end-100
    k "You know, Polad, I was thinking about building a little crib for the baby myself."
    k "Something special, something handmade, you know? What do you think? A good idea?"
    p "Sure, sounds… great."
    p "Some things are worth the effort, aren’t they?"
    b "It depends on… how much effort you’re willing to put in."
    p "Oh, I’m willing to put in as much effort as it takes. Especially when the reward is worth it."
    p "You’re living the dream, Kamil. Not everyone gets that lucky."
    p "Can I Touch the belly? It’s a miracle, isn’t it? New life."
    k "Of course, Polad! Go ahead! It’s amazing—you can feel the baby move sometimes. Banu, let him feel it!"
    scene end-101
    play music "audio/weakbanu.mp3"

    "Polad places his hand gently on her belly, his fingers splayed as he caresses the curve in slow, deliberate motions."
    "His touch lingers longer than necessary, his eyes meeting hers with a knowing intensity."
    p "Incredible. Life growing here. It’s… powerful."
    "Banu swallows hard, her face flushing as her hands rest over his, more to still his movements than to encourage them."
    k "Isn’t it amazing, Polad? I still can’t believe it myself. "
    p "It’s more than amazing. It’s… life-changing."
    scene end-102
    k "You know what? I think I’ll head to the store and grab something to drink."
    k "We’re celebrating, after all! Can’t have a proper evening without something special, right?"
    k "We’re having a baby, Banu! I want it to feel special."
    k "Polad, anything you’d like? Wine? Beer? Maybe something stronger?"
    p "Whatever you choose will be perfect, Kamil. You always have good taste."
    k "See? That’s why you’re my best friend, Polad. You always know what to say!"
    scene black with dissolve
    "...."
    "After some time..."

    scene end-103 with dissolve

    p "You’ve been trying to resist, haven’t you, Banu? But you knew this would happen the moment he left."
    "Banu leans back, her breathing uneven as Polad steps closer, his movements deliberate and confident."
    b "Polad… this is insane. Kamil could come back any minute."
    p "Then we’d better not waste any time, should we?"
    b "Are you… are you going to fuck me here, Polad? In the bathroom?"
    p "Right here, Banu. Right now. You’re mine, remember?"
    scene end-104
    b "Polad… this isn’t right. We can’t do this."
    p "Right or wrong stopped mattering a long time ago, Banu. You know that as well as I do."

    p "You feel it, don’t you? You can’t fight this anymore."
    b "Polad… the baby…"
    p "The baby is a reminder of what we’ve done, of what we are. It’s not a reason to stop."
    scene end-105 with fade
    $ renpy.sound.play("voices/kissing.mp3", loop=True)
    "Banu’s pregnant belly brushes against Polad’s hard torso, the closeness making her pulse race."
    "For a moment, the world outside ceases to exist, and they are caught in the gravitational pull of their forbidden connection."
    b "Polad… this is wrong....mmmm.."
    p "Stop pretending you don’t feel this."
    "The kiss starts slow, hesitant, but quickly deepens as their mutual longing takes over."
    scene end-106
    b "Polad… this is too much. We can’t… not here."
    "Her hands tremble as she tries to push him away, but the forbidden thrill of the moment makes her resistance weak."
    p "You feel that, don’t you, Banu?"
    scene end-107
    "The world seems to stop, her heart pounding in her chest."
    "Banu kisses him back passionately, her hands moving to his chest, trembling as they explore his solid frame."
    "The intensity of the kiss deepens, their breaths mingling as the sound of their connection fills the small, confined bathroom."
    "She lets out a soft moan against his lips, her resistance completely melted away in the heat of the moment."
    b "We shouldn’t be doing this, Polad… but I can’t stop myself."
    stop sound

    scene end-108 with fade
    b "Polad… what are you doing?"
    p "What I should have done a long time ago."
    "He leans forward, his lips brushing softly against the curve of her pregnant belly."
    scene end-109
    stop music
    p "This is mine, Banu. You know it as well as I do. Every part of you… every part of this… belongs to me."
    p "You carry proof of what we are, Banu. Proof of what we’ve done. You can’t hide from it anymore."
    "Banu’s heart races, her mind screaming at her to stop, but her body remains frozen, caught in the forbidden intensity of the moment."
    "Polad presses another kiss to her belly, his eyes flicking up to meet hers."



    scene ending_3 with dissolve
    "..."
    "..."
    dev "{color=#ffffff}Thank you for playing! YOU'VE REACHED ONE OF THE ENDINGS!. Play again to discover more. If you enjoyed it, please {a=https://www.patreon.com/lustfulfantasy}support{/a} the development. Wishlist our new game here {a=https://store.steampowered.com/app/4056530/Banu_in_the_West/}Banu in the West{/a} {/color}"
    hide screen faith
    hide screen angeldevil


    $ renpy.end_replay()
    $ persistent.banukeepcheating_ending_unlocked = True
    jump endings





label kamilkillspolad_ending:


    play music "audio/intro.mp3"

    scene black with dissolve
    "Banu sat alone in the dimly lit living room, her thoughts swirling in a storm of guilt and resolve."
    b_ "He doesn’t deserve any of it. Kamil… he’s been nothing but kind, nothing but patient. And I… I’ve been a selfish fool."
    b_ "I can’t undo the past, but I can… I can be better. For him. For us. I don’t want to lose him."
    "The resolve in her heart was fragile but growing."
    "She promised herself, in that quiet moment, that she would be loyal, honest, and deserving of the love Kamil had always shown her."
    play sound "voices/doorbell.mp3"


    "Just as she felt the smallest glimmer of hope flicker in her chest, the doorbell rang."
    scene end-33 with dissolve
    b_ "Who could it be?"
    b_ "Kamil doesn’t usually come home this early. What if it’s… no."
    b_ "It can’t be Polad. I ended it. I made sure of it."
    scene black with dissolve
    "Banu's heart pounded as she opened the door, her hand trembling on the knob."
    "Before she could process what was happening, Polad pushed his way inside, his presence filling the room like a storm."
    scene end-34 with dissolve
    play music "audio/softromanticsex.mp3"



    "He closed the door behind him with a swift motion, locking it as if he had every right to be there."
    b "Polad!"
    b "What the hell are you doing here?"
    scene end-36
    p "What does it look like, Banu?"
    p "You didn’t think you could just ghost me, did you?"
    b "Polad, It's over. You shouldn’t have come here."
    p "Oh, come on, Banu. We both know that’s not true. You think you can just play the good wife again and forget everything we had?"
    scene end-35
    b "I can’t do this anymore, Polad. I’ve made my choice."
    b "I love my husband, and I’m not going to ruin what we have any further."
    p "All those nights we spent together, was that nothing to you?"
    b "It was a mistake. I was a different person then. Please, Polad, leave. Let me fix what I’ve broken."
    p "You know what....I can still hear your screams echoing in my head."
    p "The way you called my name… begged for more… you weren’t exactly quiet, were you?"
    b "Come on...don't be ridiculous."
    p "You think Kamil doesn’t notice? The way your body’s changed? The way you walk after I’ve had you?"
    p "I know that sweet little pussy of yours still remembers me."
    b "Do you really think you’re something special?"
    b "Let me break it to you—you’re nothing more than a fleeting mistake. A bad decision I regret every single day."
    p "Oh, come on, Banu. You can’t fool me. I know you enjoyed every second."
    "Banu rolled her eyes, stepping closer, her confidence growing as she saw the flicker of insecurity in his gaze."
    b "Enjoyed it? Let’s be real—you’re not nearly as good as you think you are. "
    b "All that talk, all that swagger, and yet… well, let’s just say Kamil doesn’t leave me wanting more the way you always did."
    scene end-37 with fade
    b "You’re such a joke, Polad."
    b "No wonder you’re crawling back here—looking for validation you’ll never get."
    b "Now get out of here. I don't have time for you."
    p "Say that again."
    b "You heard me."
    b "Now, if you’ll excuse me, I have better things to do than babysit your bruised ego."
    scene end-38 with hpunch
    play music "audio/weakbanu.mp3"
    play sound "voices/ah.mp3"

    "As she took a step away, Polad’s fury reached its boiling point."
    "In an instant, he closed the distance between them, grabbing her wrist and spinning her around. "
    "Banu barely had time to gasp before her back was against the wall, her hands pinned above her head by his iron grip."
    b "Let go of me, Polad!"
    p "Think you can just walk away after that?"
    p "You always knew how to push my buttons, Banu. Maybe that’s what you wanted all along."
    scene end-39

    $ renpy.sound.play("voices/kissing.mp3", loop=True)

    "Polad’s lips moved feverishly, planting kisses along Banu’s cheeks, her jaw, and her chin. "
    "His grip on her wrists was unrelenting, pinning her against the wall as she twisted her face to the side in a desperate attempt to avoid him."
    b "Stop it, Polad!"
    b "I hate you! Do you hear me? I hate you!"
    "But her words seemed to fall on deaf ears. He continued, his lips trailing over her skin with relentless determination."
    scene end-40
    "Wet, noisy kisses echoed in the room, their sound intensifying the tension as Banu struggled against his hold."
    b "Polad, I’m serious! Let me go!"
    "His breathing was heavy, his voice a low growl against her ear."
    p "Hate me all you want, Banu. I don’t care. You can say whatever you want, but I know the truth. "
    b "You don’t know anything!"
    "The room was filled with the sound of her muffled protests and the relentless smacking of his kisses against her skin."
    "Polad’s lips were relentless, his kisses trailing across Banu’s cheeks, chin, and jawline."
    "Banu kept turning her head away, but each time she moved, he followed, his lips finding her skin again and again."
    b "Stop, Polad! Kamil will be back soon...ahhhh... "
    "Her struggles began to slow as a confusing mix of anger and desire churned in her chest."
    "As her head turned sharply to the side, Polad seized the opportunity."
    scene end-41 with dissolve
    stop music
    play music "voices/makeout.mp3"

    "His lips captured hers in a swift, decisive motion, cutting off her protest."
    "Her eyes widened, her body stiffening for a brief moment, but as his kiss deepened, the tension began to melt away."
    "Banu’s resolve faltered, her resistance crumbling against the fire that surged between them. "
    "A soft, involuntary moan escaped her throat as she kissed him back, her body betraying the walls she had built around herself."
    b "Polad… we can’t… I—"
    "Her words were cut off as he captured her lips again, his kiss deep and insistent, leaving her no room to resist."
    p "If you hated this, you wouldn’t be kissing me back."
    b "This is wrong, Polad. It’s so wrong…"
    p "Then stop me."
    scene end-42 with fade
    "His hands moved to the hem of his shirt, and in one swift motion, he yanked it over his head, tossing it carelessly to the floor."
    b "Muah… Polad, stop… ahhh,"
    "She gasped, turning her head away, but his lips found her cheek, her jaw, and then her lips again."
    b "Mmm, no… I said—muah… stop…"
    "He groaned against her mouth, his hands firmly holding her face as his lips devoured hers."
    p "Mmm, Banu… you’re lying—muah—you want this as much as I do."
    scene end-43
    b "Mmm, no… ahhh… Polad… I don’t… muah…You're making me do this...ahhh..."
    "Her voice trembled, her protests growing weaker as her lips parted involuntarily, letting his tongue brush against hers."
    p "Muah… mmm… then why are you kissing me back?"
    b "Ahh… I’m not… muah… kissing you back,"
    p "Mmm… you’re lying again… muah… your body—mmm—can’t hide it."
    b "Polad… ahh… stop talking—muah… let me go…"
    scene end-44
    p "Muah… mmm, you don’t want me to stop… muah… do you?"
    b "I hate you… ahhh… Polad… mmm, stop… please…"
    "The sound of their kisses filling the room, drowning out any protests she might have left."
    b "Polad, I swear… stop this… ahh…"
    "But Polad was relentless, capturing her mouth again, his hands gripping her waist as he pulled her closer."
    b "I mean it… Polad… mmm… stop… ahh…"
    "Before she could react, Polad’s hand pressed against her crotch, rubbing firmly over her jeans."
    b "Stop! Are you insane?!"
    b "You’re disgusting..."
    b "You think you can just… just touch me like that?!"
    scene end-45 with hpunch
    play sound "voices/ah.mp3"
    b "Polad, what are you—ahh!"
    "Before she could protest further, Polad grabbed her by the hips, lifting her effortlessly as if she weighed nothing."
    "Her body hit the sofa, and he was on top of her in an instant, his strength overwhelming, his kisses rough and unyielding."
    b "Stop… Polad… I… mmm,"
    "She tried to protest, but her voice faltered as her lips betrayed her, meeting his in another fiery kiss."
    p "You can’t resist me. No matter how much you say you hate me."
    scene end-46
    b "Polad, stop! Mmm… ahh… stop it!"
    p "Muah… you’re lying, Banu… ahh… mmm,"
    b "Ahh… no, Polad! I told you—mmm—this is wrong! Muah… I won’t betray Kamil! Ahh… stop it!"
    p "Mmm… muah… you’re already mine, Banu,"
    b "Muah… you’re a bastard… ahh… I’ll never betray him!"
    p "Muah… mmm… you say that, but look at you..."
    scene end-47
    p "Do you feel my bulge?"
    b "Ahhh... please stop...you're are driving me crazy...."
    p "You rub my dick yourself, Banu. I think I know what you want and I'm gonna give it to you tonight..."
    b "No...We won't do anything and you'll leave now!"
    p "I'm going to fuck the shit out of you right here. "
    b "Ahhh....no...if Kamil comes....just leave I don't want to see you again...."
    b "I don't want to ruin my marriage because of you, asshole..."
    p "Shhhh...just feel my cock...it's because of you. I'm going to destroy your little pussy."
    b "Polad!"
    scene end-48 with fade
    stop music
    stop sound

    play music "audio/suspense.mp3"

    "The apartment door creaked open, and Kamil stepped inside, setting his bag down with a heavy sigh. "
    k "Banu? Are you here?"
    "There was no response. Frowning, he walked further into the apartment."
    k "Banu. Where are you?"
    scene end-49 with fade
    k "Banu, are you—"
    "His words stopped abruptly as he rounded the corner and froze."
    "There, on the sofa, he saw them. "
    scene end-50
    "Polad’s body was pressed against Banu’s, his movements unmistakable, their bodies locked in a heated position."
    "Banu’s face was flushed, her hands gripping Polad’s arms, and the intimacy of the scene struck Kamil like a lightning bolt."
    "Kamil’s breath caught in his throat, his heart pounding furiously."
    "He clenched his fists, his nails digging into his palms, but he said nothing."
    "Instead, he watched in silent disbelief, his stomach twisting as he took in the scene before him."
    p "Mmm… you like this, don’t you?"
    p "Forget about Kamil. He can’t make you feel like this, can he?"
    b "No...This is wrong…"
    p "What’s wrong is that you’re wasting yourself on a man like him."
    p "Kamil doesn’t deserve you… doesn’t deserve to even look at a woman like you."
    "Kamil’s jaw tightened, his teeth grinding as he struggled to contain the rage bubbling inside him. "
    scene end-51 with fade
    "Without a second thought, he grabbed the knife on the table, the cold steel heavy in his hand."
    "His fingers wrapped tightly around the knife as he stepped silently toward the living room. "
    "Polad’s voice broke the silence, still dripping with arrogance as he whispered to Banu, his lips brushing her ear."
    p "Mmm… you’re so fucking perfect, Banu. Let me show you how much better I am than him."
    p "Kamil will never satisfy you like I can."
    scene end-52
    b "Polad, stop… I told you, this isn’t—ahh… I can’t do this anymore!"
    p "You know you want this. You know you want me."
    "Kamil’s grip tightened on the knife as he approached, his movements silent but deliberate."
    "Every step brought him closer, his vision narrowing on Polad’s back as he leaned over Banu."
    p "You’re mine, Banu..."
    p "Kamil’s nothing—"
    scene end-53 with vpunch
    stop music
    stop sound

    play sound "voices/manscream.mp3"

    p "AHHHH!"
    "Kamil plunged the knife into Polad’s back with all his strength, the blade sinking deep into flesh."
    "Polad’s entire body jolted, his voice erupting in a guttural, animalistic moan of pain."
    p "Aaaaaarghhh! Ahhh… aaahhh… uuuughhh!"
    p "Ughhhh… ahhhh… damn it… aaahhh…"
    b "Oh my God!"
    scene end-54
    "Banu’s scream pierced the air, her hands trembling..."
    b "Kamil! What have you done?!"
    k "You piece of shit!"
    k "You dare come into my home? You dare touch my wife?!"
    p "Ahhh… damn you… ughhh…"
    k "That’s exactly what you deserve! You hear me, you bastard?"
    scene end-55 with fade
    play music "audio/intro.mp3"
    p "You think… this is going to stop me?"
    p "You’ve got guts, Kamil. But stabbing me in my back? That’s the act of a coward."
    k "You came into my home, put your filthy hands on my wife, and you dare call me a coward?"
    scene end-56
    p "Your wife, huh? She didn’t seem too eager to stop me, did she?"
    k "You shut your damn mouth."
    p "You’re pathetic..."
    p "You think stabbing me makes you a man? Even like this, I could still kick your ass."
    p "Hell, I’ve already taken the one thing that mattered to you—your wife."
    p "Ahh… damn it… I…"
    scene end-57 with vpunch

    stop sound
    "His legs gave out, and he collapsed heavily to the floor, landing at Kamil’s feet with a thud."
    "Banu gasped, her hands flying to her mouth."
    b "Polad!"
    "Polad’s breaths grew shallow, his body trembling."
    "He groaned one last time, a guttural sound escaping his lips as his head slumped forward."
    scene end-58 with fade
    "Banu’s eyes widened in horror, her hand flying to her mouth as she stifled a scream. "
    b "Oh my God… Kamil… he’s… he’s dead…"
    "For a moment, neither of them spoke, the room thick with the suffocating weight of what had just happened."
    scene end-59
    k "We can’t leave him here."
    k "If anyone finds him like this, we’re finished."
    b "What… what are you saying, Kamil? What do you mean?"
    k "We get rid of him. No one can ever find out what happened here."
    b "Get rid of him? Kamil, he’s a person, not… not garbage!"
    k "He’s dead, Banu,"
    k "Do you want me to go to prison? Do you want to throw your life away for him? Because that’s what’ll happen if we don’t act now."
    scene end-60
    stop music
    b "But what if someone sees us? What if they trace it back to us? We’ll be ruined…"
    k "We’ll take him somewhere far, somewhere no one will ever look."
    k "The river. We throw him in, and it’s over. No body, no crime."
    b "Are you sure? What if…"
    k "We have no choice. Either we handle this, or we both go down for it."
    b "Okay, but… how do we… how do we move him?"
    k "We wrap him, carry him out to the car, and drive to the river."
    k "We’ll do it tonight, before anyone notices anything."
    b "I can’t believe this is happening…"



    scene ending_2 with dissolve
    "..."
    "..."
    dev "{color=#ffffff}Thank you for playing! YOU'VE REACHED ONE OF THE ENDINGS!. Play again to discover more. If you enjoyed it, please {a=https://www.patreon.com/lustfulfantasy}support{/a} the development. Wishlist our new game here {a=https://store.steampowered.com/app/4056530/Banu_in_the_West/}Banu in the West{/a} {/color}"
    hide screen faith
    hide screen angeldevil


    $ renpy.end_replay()
    $ persistent.kamilkillspolad_ending_unlocked = True
    jump endings




label ruslan_ending:
















    play music "audio/weakbanu.mp3"
    scene black with dissolve
    b_ "If he’s asleep, I’ll leave. Just one look. That’s all."

    scene end-114 with fade
    $ renpy.sound.play("voices/manmoaning1.mp3", loop=True)
    b_ "But if he’s awake—"
    r "Uhhhnnnn... Banu—fuck—Banu—"
    "He was moaning her name."



    b_ "Oh my god."
    b_ "He’s… he’s jacking off to me. Not just thinking. Saying it. Crying it like he needs me."
    scene end-115

    "Eyes shut tight, head tipped back, hips bucking as he stroked faster, like the sound of her in his throat made it better."
    r "Banu—Banu, please—ahhh fuckkk—"
    b_ "He’s desperate. He’s about to cum. Saying my name like he’s inside me already."
    b_ "What kind of woman hears her stepson moaning her name and doesn’t walk away?"
    b_ "The kind who hasn’t been fucked right in months."
    scene end-116
    "She bit her lip. Hard. Her thighs shifted. She couldn’t stop watching his hand."
    "Couldn’t stop imagining hers there instead, her mouth, her cunt wrapped tight around that cock that looked too perfect to waste on his fist."
    b_ "He wants me. He’s always wanted me. And now he’s begging."
    scene end-117
    r "Ahh—fuck—Banu…"
    stop sound
    b_ "He’s saying my name. While stroking that cock? While dripping like that?"
    b_ "He’s thinking about me—he’s cumming for me."
    b_ "It’s bigger than I imagined. No wonder he couldn’t stop staring every time I leaned over the sink."
    "And then his eyes opened."
    "And locked on her."
    r "Banu—fuck—you're here—you’re fucking real—"
    scene end-118 with fade
    r "What the fuck are you doing here?"
    b "You were moaning my name, Ruslan. Loud."
    r "I—fuck—I thought you were asleep."
    b "Clearly you didn’t care."
    r "I didn’t think you’d actually be standing there, watching me beat my cock to you."
    b "You say that like it wasn’t the hottest thing I’ve ever seen."
    scene end-119
    r "You liked it?"
    b "You’re still hard."
    b "…You’re not even trying to cover yourself."
    r "Neither are you. That little bra? Those panties? Soaked. You want me to see?"
    b "I came for water."
    r "That’s a lie and you know it."
    scene end-120
    b "…Maybe I forgot what I wanted."
    r "No. You know exactly what you want."
    b "You cocky little shit."
    r "Say that again while you’re on your knees."
    b "Keep dreaming, Ruslan."
    scene end-121 with fade
    b "Ahhh.."
    r "I did. Every night. Since the first time I saw you bend over that fucking washing machine."
    b "You think it’s okay to jerk off screaming my name in my house?"
    r "Better than pretending I don’t want to fuck you on every surface in it."
    b "You’ve got a filthy mouth."
    r "And a cock that won’t quit."
    r "I’ve been starving for you, Banu. You’ve got no idea."
    b "You don’t know what the fuck you’re doing."
    scene end-122 with fade
    b "You really think you’re man enough to handle this body?"
    r "Let me prove it."
    b "God, you’re hard as a fucking pipe."
    r "Feel what you do to me."
    scene end-123
    b "You’ve been walking around this house with that thing between your legs, staring at me like you wanted to pin me to the goddamn walls."
    r "I do. Every time you passed me in those little skirts, no bra under your robe—fuck, Banu, I wanted to throw you over the counter."
    b "And now...You think you can handle me?"
    r "Let me find out."
    b "You better. I’m soaked. Dripping down my thighs, and it’s all your fault."
    r "Fuck, say that again—"
    scene end-124 with fade
    $ renpy.sound.play("voices/kissing1.mp3", loop=True)


    b "Mmmf—ah—Ruslan…"
    b "Mmm—ahhh, fuck—Ruslan—"
    r "You like that? Hnh? You taste so fucking good—"
    b "Ahnn—nghh shit, I can’t—can’t think—"
    "Her breath trembled when he sucked her tongue slow into his mouth, and she gasped—eyes suddenly glazed, lashes fluttering."
    scene end-126
    stop sound
    b "Mmmfuck—yes—ahhhn, I want you—I need—Ruslan—"
    b "W–why did you stop…?"
    r "Because I wanted to see you beg."
    b "Ruslan, please… kiss me again—please…"
    b "Don’t leave me like this—fuck—I need your mouth, I need it—I’m still shaking—"
    r "Say it again."
    b "I need you to kiss me—fuck me with your mouth—please, Ruslan, I’m going crazy—"

    scene end-125
    $ renpy.sound.play("voices/kissing1.mp3", loop=True)
    b "Mmmmf—ahhhn!"
    r "Open for me—yeah, just like that—let me taste that want."
    b "Mmh—ah, you kiss like you want to devour me—"
    r "I fucking do. I’ve wanted to ruin this mouth since the first time you smiled at me."
    b "Ahnn—fuck, don’t stop—don’t you dare stop—kiss me until I can’t breathe—"
    b "I’m—ahh—I’m gonna cum—just from this—your fucking mouth—"
    r "Cum on my tongue next. Let me taste how bad you need me."
    r "Get on the bed. Face down. Now."
    stop sound
    scene end-127 with fade
    r "You dripping already? Filthy fucking woman."
    b "Ohh fuck!"
    b "Stretch me out with that cock. Fuck—yes—deeper, don’t stop."

    show animasiya_aruslansikiplank
    $ renpy.sound.play("voices/sex2.mp3", loop=True)
    r "You take cock like a slut. This tight pussy’s made for getting filled."
    r "Bounce on it. Take every inch. I’m not holding back."
    b "Don’t you dare. I want all of it. Bruise me, make me sore tomorrow."
    b "Oh god yes, yes, like that—harder—don’t pull out, not yet!"


    show animasiya_aruslanspnak
    r "Fuck—you’re gonna make me cum—tight little bitch—take it all—take it—"
    r "That limp dick ever make you moan like this? Huh?"
    b "Ahhh...why...do you hate your dad so much...ahhhh.."
    r "Bet he finishes before you’re even wet. Fucking pathetic."
    r "You lie next to that snoring old man every night, aching for a real cock—this cock."
    r "He wouldn’t know what to do with a bitch like you if you begged with your legs open."
    r "Kamil’s out there dreaming while I’m in here rearranging my stepmom's guts."
    r "Say it. Say you’d rather fuck me every night while he’s drooling into his pillow."
    b "Ahhh...I'm gonna cum..."
    r "Say his dick’s useless. Say you’re mine."
    stop sound
    scene end-128

    r "You belong under someone like me—fucked raw, screaming, dripping, ruined."
    r "Bet he kisses your forehead and turns over while this pussy leaks down your thighs."
    b "Ahhh...don't..."
    r "I’m gonna make sure you forget his name while I’m balls-deep inside you."
    k "Ruslan? Why the hell aren’t you sleeping?"

    scene end-129 with hpunch

    r "Shit!"
    b "Don’t you fucking stop. Keep going. He’s not coming in."
    b "I don’t care—just fuck me through it—oh god—"
    k "You hear me? I said—why are you up?"

    scene end-130 with fade
    k "What the fuck is going on in there?"
    r "Trying to jerk off in peace. What do you want?"
    k "How dare you talking to your father like that?"
    k "Watch your fucking mouth."
    r "Just fuck off, let me alone."
    k "You little shit, you think I won’t break this door down?"
    scene end-131
    r "You’re embarrassing yourself. Middle of the night, creeping around like a perv outside my room."
    r "Go back to bed. Pretend your life’s not falling apart."
    k "You better watch it, Ruslan. You forget whose house this is."
    r "No. You forgot who’s still hard in your house. Fuck off."

    scene end-132
    k "Unbelievable... fucking disrespect..."
    k "You smug little shit. You talk to me like that again, I’ll knock your fucking teeth in."
    r "Oh yeah? You gonna swing your limp arms like you swing that limp dick?"
    r "Big man waking up in the night to whine at someone with balls."
    k "You disrespectful fuck. I ought to drag you out by your hair and make you apologize on your knees."

    scene end-133
    r "Try it. Come through this door and see who ends up face-first on the fucking floor."
    r "You want to fight because I’m louder than you in bed? Because someone moaned louder for me?"
    k "You think you’re a man? You’re a fucking parasite. No job, no pride, just jacking off and running your mouth."
    r "Still more useful than you, old man. At least I can get someone off without crying after."
    r "I’m dealing with a washed-up cuck who doesn’t even realize the house doesn’t listen to him anymore."
    k "Fucking little snake—"
    r "Cry harder, cuck."

    scene end-134 with fade
    r "You heard all of that, didn’t you?"
    r "Every word."
    b "My pussy clenched when you told him to fuck off."
    r "You like hearing me humiliate my father while I’m still dripping with you?"
    b "I liked knowing he was inches away while I was soaked with your cum."
    b "You made me feel like I belonged to someone again."
    r "You’re mine now. Not his. Not anyone’s but mine."

    scene end-135 with fade
    b "Ah—yes—yes—fuck me like that—harder!"
    r "This is my pussy now. You feel that stretch? That’s me breaking what he never reached."
    b "God, you’re hitting so deep—yes—fuck, I love it when you talk while you’re inside me—"

    show animasiya_ruslanmissionary
    $ renpy.sound.play("voices/longmoan.mp3", loop=True)
    r "You love it because I fuck like I mean it."
    r "Not that weak-ass grunting and apologizing your husband does."
    r "This? This is how a real man takes a bitch who begs."
    b "Talk dirtier. Say it—say what I am."
    r "You’re a cheating little whore who wants her husband humiliated while her legs are pinned and her mouth open."
    r "You’re nothing but a wet hole for your stepson to wreck."
    b "Yours. I'm yours—yes—fuck me—don’t stop—"
    stop sound
    scene end-136 with fade

    b_ "God, he's splitting me open—every thrust hits so fucking deep—"
    b_ "Yes—right there again—fuck—he owns this pussy now—"
    b_ "Kamil never fucked me like this—never made my legs shake just from the first few inches—"


    scene end-137 with fade
    b_ "Thick, heavy, angry—slamming into me like he hates what I used to be—"
    b_ "I love that he’s angry—"
    b_ "I love that he talks to me like I’m some fucktoy he stole right under his dad's nose—"

    scene end-138 with fade

    b_ "That voice—those eyes—fuck, he's watching me squirm like he wants me to break—"
    b_ "My pussy’s soaked, gripping him too tight—he knows I’m clenching just to make him groan again—"
    b_ "Make him curse into my mouth—yes, ruin me—"

    scene end-139
    b_ "I want him to leave bruises where no one can see—"
    b_ "I want to walk around tomorrow dripping his cum while smiling at Kamil like nothing happened—"
    b_ "Yes, faster—he’s jackhammering into me—"
    b_ "Oh fuck, he’s going to fill me again—I can feel it building—his cock twitching, deeper, deeper—"

    scene end-140 with fade

    r "Get the fuck up—leg up, yeah—just like that."
    b "Oh god—yes—fuck yes, just slam it in—ahhh—don’t hold back—"
    b "Stretch me—fucking wreck me—"
    r "Shit—so fucking tight like this—"
    r "Feel that? That’s how a real man fucks his claim in."

    scene end-141
    b "Yes—fuck—you're hitting everything—oh god—your cock's so deep—"
    b "Hold me harder—fuck—yes—yes!"
    b "You like watching me bounce on you like this, don’t you?"
    r "You’re dripping down my balls—soaking me like a bitch in heat."
    b "I am—your bitch—your whore—don’t stop—don’t you fucking stop—"
    b "Fuck me like you’re never letting go—"

    scene end-142 with blinds
    b_ "He fucked me for hours."
    b_ "My thighs are still trembling—god, my pussy’s raw, sore, gaping."
    b_ "I feel him leaking out of me every time I move."
    b_ "It’s everywhere. On my tits. My stomach. Between my toes."

    scene end-143
    b_ "There’s cum drying in my hair."
    b_ "Took every part, every hole, every breath, until I begged and begged and still didn’t want him to stop."
    b_ "And now he’s just... asleep."
    b_ "Snoring like a fucking beast."

    scene end-144

    b_ "I remember the sound of it slapping onto his stomach, hot and thick and everywhere."
    b_ "Look at it."
    b_ "Running down his abs like paint."
    b_ "He came so much."

    scene end-145
    b_ "God, listen to him. So fucking proud of himself even in his sleep."
    b_ "He came like he wanted to put a baby in me. Again and again—"
    b_ "Even when I screamed, even when I said I couldn’t take more—he didn’t stop."
    b_ "Every time he came, I wanted more."
    b_ "Every time he called me his slut, I moaned louder."

    scene end-146
    b_ "Fuck—my legs can barely move."
    b_ "I feel raw, stretched, leaking."
    b_ "I have to go back."
    b_ "To that cold bed."
    b_ "To Kamil."
    b_ "I told him I’d be up getting water, didn’t I?"

    scene end-147
    b_ "Or did I say laundry?"
    b_ "It doesn’t matter."
    b_ "I’ve been gone too long already."


    scene black with dissolve
    "Days after..."

    scene end-148 with dissolve
    k "Banu? You coming to bed?"
    k "It’s late…"
    b "One sec, baby… I’m just finishing something…"

    scene end-149
    r "You’re fucking insane… god, your mouth—shit—"
    r "He doesn’t have a clue you’re choking on my cock while he’s calling for you."
    k "You okay? What’re you doing?"
    b "Mmhm, just… drinking water. Go to sleep."

    scene end-150
    b "Mmmmm..."
    r "Fuck, Banu, you’re gonna make me cum all over your throat—"
    r "Keep going—yeah, like that—deep—fuuuck—"
    k "Don’t stay up too long. You need sleep too…"
    b "Mmmhh—slrp—"
    r "Let me cum down your throat while he begs for cuddles."
    b "I’m yours. Finish for me. Right here."

    scene end-151 with fade
    r "Fuuuck… you swallowed all of it."
    r "Didn’t spill a single drop… goddamn."
    b "Mmm… I wanted every bit of it."
    b "Still dripping… here—let me clean it."
    r "Look at you—on your knees, licking the cum off my cock while your husband snores ten feet away."
    b "Say it. Say this mouth is yours now."
    b "Because I’ll suck you again the second he closes his eyes."





    scene black with dissolve
    "Days after..."





    scene end-152 with dissolve

    b "Yeah… just couldn’t sleep. Needed some air."
    b "I didn’t want to wake you."
    k "You could wake me anytime, you know that."
    k "Kitchen was cold this morning. Heater must’ve clicked off."

    scene end-153
    b "Mm. Yeah. Felt it too."
    k "You want anything? I can make you something quick."
    b "No, I’m good. I—"

    scene end-154
    r "Miss me?"
    r "You’re not wearing panties under that, are you?"
    b "What are you doing—he’s right there—"
    r "I know. Makes it better."


    b "..Fuck you."
    b "Come here."

    scene end-155
    r "Mmm—god, this mouth—"
    r "You taste like guilt and sin—fuck, kiss me harder—"
    b "Mmmhh—don’t stop—don’t stop—I need it—"
    b "Tongue—give me your fucking tongue—"

    scene end-156
    r "You’re trembling—fuck, you want me so bad you’d risk it all for one kiss?"
    r "Open that mouth, Banu—yes—just like that."
    b "I can’t breathe—kiss me again—harder—"
    r "Fucking filthy woman—mmph—your husband’s in the next room."
    b "I hope he hears—fuck—I hope he walks in and sees how you kiss me."
    b "How you make me fucking melt—mmmhh—"

    scene end-157 with fade
    k "There you two are. Thought you’d vanished."
    k "You guys alright?"
    b "Y-yeah. Just… talking."
    b "Morning’s… warm."
    r_ "God, you wanted this. Right here."
    k "Nice to see you two finally getting along."
    k "Feels like the house isn’t so tense for once."

    scene end-158
    b "Nnh—fuck—don’t—"
    r "Smile for him, sweetheart. While I finger your dirty little hole."
    b "Hnn—oh my god—"
    r "Shh. Just my middle finger, baby. Right there. Right—there."
    k "You good?"
    b "Y-yeah. Just… thinking about something."

    scene end-159
    b "Ohhh...fuck!"
    r "You’re soaked already… feel that?"
    b "Hhh—don’t tease, just… keep it there."
    r "Here?"
    b "Ah—yes, fuck… slow, slow."
    r "You’re clenching on my finger like you’re afraid I’ll stop."
    b "Because you will if I breathe too loud… mmnh."
    r "You love how risky this is."
    b "Shh—ohh—don’t say it… curl it like that… ngh."

    scene black with dissolve
    "...."
    scene end-160 with dissolve
    guy1 "You see her ass in those leggings? Fuck me. I’d skip leg day for that view."
    guy2 "Skip leg day? Man, I’d do leg day on her. Bounce her off every machine in this place."
    scene end-161
    guy1 "Think she even notices us?"
    guy2 "With that sway? She wants eyes on her."

    scene end-162 with fade
    "..."
    guy2 "She knows exactly what she’s doing."

    scene end-163 with fade

    b "You boys always talk like that when you think someone’s not listening?"
    guy1 "Shit—you, uh, heard that?"
    b "And I’m wondering…"
    b "Which of you talks better with his mouth full."
    scene end-164
    guy2 "…You serious?"
    b "Oh, you want a taste of my pussy?"
    b "So desperate. So fucking needy. Look at you—eyes locked like I’m your last breath of air."
    guy1 "You hear her? She thinks she can just dangle that in front of us and walk away."
    b "I just enjoy the way you look when I leave you hungry."
    guy1 "You walk out now, just know that next time… we don’t wait for permission."
    b "Next time, bring more than just words."

    scene end-165 with fade

    b_ "Fuck… I can still feel their eyes on my ass."
    b_ "They don’t know shit. They talk big, but they wouldn’t know what to do if I sat on their face."
    b_ "Pathetic. So easy to get them drooling, begging."
    b_ "But Ruslan...."

    scene end-166
    b_ "He better come grab me like he owns me."
    b_ "Bet he’s already hard."
    b_ "God, I want him to say nothing—just bend me over this bench, fuck me till I’m shaking."
    b_ "He better shove that cock in without warning, no fingers this time. Just thick and deep."

    scene end-167 with fade

    b "Ahhh...Ruslan..."
    r "You looking for me?"
    b "Shit—!"

    scene end-168 with fade
    r "You were teasing again, weren’t you."
    b "Two gym rats talking about protein shakes and dicks. I couldn’t resist."
    r "They say anything smart?"

    scene end-169
    b "They said I wouldn’t."
    r "And did you?"
    b "Told them I was already wet. Then I told them to fuck off!"
    r "Fuck—"
    b "Mmm, yeah, right there—fuck me like they can hear it."

    scene end-170
    r "You want them hearing this? You want them knowing how this pussy sounds when I fuck it?"
    b "Let ‘em. Let ‘em hear how wet you make me, how good you stretch me, how loud I get."
    r "Goddamn, you’re so horny. Did they do this, or did I?"
    b "You gonna keep looking at me like that, Ruslan?"

    scene end-171
    r "Fuck, Banu... you’re gonna kill me."
    b "Look at you. All hard, and I haven’t even touched you."
    r "I’ve got one hand twitching not to grab your throat, and the other ready to spread your legs."
    b "Do it. But don’t fuck me. Just keep me on edge. Tease me until I’m grinding on your thigh like a bitch in heat."

    scene end-172
    b "Mm. You know it’s sensitive."
    r "That’s why I’m here."
    b "Fuck, Ruslan…"

    scene end-173
    b "You know what that does to me."
    r "Feel it. Right here."
    b "Don’t stop, baby… suck harder, right there—yes, fuck."
    r "You want me to mark it?"
    b "Do it. I wanna walk out of here with your mouth all over me."
    b "God, yes. Write it. Fuckin’ sign me."
    scene end-174 with fade
    b "I wanna feel your bare skin on mine. I wanna feel your cock heavy on my cunt, not some tease through fabric."
    b "Fuck, that—mmm—that’s it, right there…"
    r "Feel that? That’s how close I am to fucking you."
    b "You’re already fucking with my head."
    b "You feel how wet I am for you?"
    r "I can smell it. Taste it in the air."

    scene end-175
    b "Then taste it on my tongue."
    r "You’re dripping down my shaft and I haven’t even slid in yet."
    b "I want it. Not inside. Not yet. Just this. Rub it. Let me hump you like a needy bitch."
    r "You are my needy bitch."
    b "Yeah? Then let me come just grinding on your cock. Let me mess up your thighs before you even fuck me."

    scene end-176
    r "Look at this greedy little cunt. So swollen. So ready. So fuckin’ wet."
    b "Tell me more. Dirty. Filthy. Say it in my ear."
    r "I’m gonna rub you raw right here. Gonna keep you trembling till your pussy drools on my cock."
    b "I’m already crying inside, baby… give it to me just like this—mmm fuck yes, grind harder…"
    r "You gonna come like this?"
    b "Yes—on your cock, not in me, just like this, fuckfuckfuck, don’t stop, baby—don’t you dare stop—"

    scene end-177 with fade
    b "Fuck—yes—mmmnnh, you know what I like."
    "He flipped her fast, spun her like instinct, and her body obeyed before thought caught up."
    r "You moved before I even told you. Look at this fucking position."
    "His cock slapped flat against the soft round of her ass, slick with her arousal, leaving a print of heat and musk."
    b "Ahhh—do it again—fuck, again—"
    scene end-178
    "Smack. Smack. Smack."
    r "You feel that?"
    r "That’s my cock saying hi to this fat fuckin’ ass."
    b "She missed you—god, baby, slap her again, make her red for you—"
    r "This pussy’s begging. She’s clenching on air."
    b "Let her wait. Just like that. Rub it… tease her… oh god, yes, yesss…"

    scene end-179 with fade
    r "Spread it for me—fuck yes, just like that—mmm, look at this perfect fuckin’ hole."
    b "You gonna worship it or stare all night?"
    r "I’m gonna tongue it ‘til your legs give out."
    b "Do it. Eat my ass like I’m your last fuckin’ meal—ahhhn fuck, yes—!"
    scene end-180
    r "Mmmmph—fuck, you taste filthy—so sweet, so wrong—I could drown in this."
    b "Deeper, baby—fuck—tongue-fuck me, right there, god—"
    r "That twitch? Yeah. I felt that. You clenchin’ on me like you don’t wanna let go."
    b "Because I fuckin’ don’t—ahhh fuckfuckfuck, yesss, lick it harder—"
    b "God yes, fuck yes, I’m gonna fuckin’ come on your mouth—don’t stop—"

    scene end-181
    r "Never stoppin’. Not till this ass is slick, messy, dripping down my chin—"
    b "You nasty fuck, you love this ass—say it."
    r "I fuckin’ worship this ass—my tongue belongs here—my fuckin’ mouth was made for this hole—"
    b "Then keep goin’. Show me how much."

    scene end-182
    b "Fuuuck, Ruslan—fuck—what are you doing to me—ahhhn—!"
    b "That tongue—oh my god, don’t stop, don’t fucking stop—yes, yes right there, fuck—"
    b "I’m shaking—I can’t—my knees—shit, baby, hold me, I’m gonna fucking fall—!"
    b "You filthy fucking animal—eating my ass like it’s pussy—slurping like you’re starving—ohhh fuck—!"
    b "I’m losing my fucking mind—god—my brain’s melting—I can’t think—just your tongue, your tongue, your fucking tongue—"
    b "YES—YES—EAT IT—EAT MY FUCKING ASS—I’M COMING—OH GOD—!"
    b "FUUUUUCK—AHHHHNNN—SHIIIT—YOU’RE KILLING ME, RUSLAN—YOU’RE FUCKING KILLING ME—!"

    scene end-183 with fade
    r "You feel that?"
    b "Mmh… I feel everything. You gonna give it to me, baby?"
    r "Gonna give you all of it. Gonna split this perfect ass open."






    scene end-184
    b "Ahhh—fuck—yes, yes, just like that—fill me—stretch me, baby—"
    b "Fuuuuck—so big—so deep—it burns—don’t you dare stop—"
    r "You’re takin’ it like a good girl—gonna fuck you so deep they’ll hear it echo in your chest."
    r "All the way now—take it—take all of me—"

    show animation_ruslanfuckbanushowerpussy
    $ renpy.sound.play("voices/sex2.mp3", loop=True)
    b "Back in. I need it. Fuck—back in my pussy, now—"
    r "You want it like that?"
    b "Any way you want, baby—just fuck me—fill me again—"
    b "AHH—fuck yes! Yes—right there—oh my god—"


    show animation_ruslanbanushowerdownview
    r "This tight little cunt’s never been fucked like this, has it?"
    b "N-nnno—fuck—never—"
    r "Kamil ever make you scream like this?"
    b "No—no—he never—fuck—he never knew what to do—"
    r "Bet he couldn’t last a minute in this dripping pussy. Didn’t even know how to hold you right."
    b "He couldn’t fill me—he couldn’t touch me like this—"
    r "Couldn’t make you bend like this, open like this, begging for cock like a needy fuckdoll."
    stop sound
    scene end-185 with fade
    b "My turn."

    r "Fuck—what are you—"
    b "Shut up and lie still."
    b "Hnnnnghh—fuuuuck—yes—yes—yesss—"
    r "God—damn—Banu—fuck—fuck!"
    b "You feel that?"
    scene end-186
    r "Tightest fucking thing I’ve ever felt—holy fuck—"
    b "I’m squeezing, baby. On purpose. You like that? Huh?"
    r "Fuck—Banu—goddamn! You tryna break my cock?"

    scene end-187
    b "You’re mine now, Ruslan. This ass owns you."
    r "Shit—you’re gonna make me lose it—riding me like you want me dead—"
    b "No, baby… I want you obsessed. I want this hole to haunt you."
    r "FUUUCK—Banu—stop squeezing—fuck—you’re gonna milk me—"
    b "No. Hands down. Just take it. Let me ruin you."

    scene end-188 with fade

    r "You think I’m done with this ass?"
    b "You just came, Ruslan."
    r "So what? I’m young. You forget?"
    scene end-189
    b "Hnnnnghh—fuuuuck—yes—yes—yesss—"
    r "God—damn—Banu—fuck—fuck!"
    r "You think I need rest? I’m not your little husband, Banu. I’m not soft. I break you."
    scene end-190
    b "Fuuuuck—y-you’re so deep—shit—I can’t even—"
    r "You love it. You love getting destroyed by a cock half your age."
    b "I love it so fucking much—yes—yes—fuck my old ass, baby—tear it up—"
    r "You feel that? That’s youth, baby. That’s stamina. You ain’t getting this from Kamil’s creaky knees."
    b "Kamil can’t even reach like this—fuck—you’re hitting places that haven’t been touched in years—"
    r "This ass is mine now. Fuck the years. You’re still tight enough to make me crazy."

    scene end-191 with fade
    b "You want back in this ass, baby?"
    r "Fuck yes. Ride it. Sit all the way down."
    b "Mmmhh—fuuuuck yes, that stretch—deep in my guts, just how I like it—"
    scene end-192
    r "Look at you… fuckin’ bouncing on my cock like you live here."
    b "I do live here. My ass is your home now, baby—tight, nasty, hungry."
    r "Tight as ever, Banu. You miss me that bad, huh?"
    b "Ahh—fuck, Ruslan, deeper—!"
    scene end-193 with hpunch
    guy1 "Yo, what the—?"
    guy2 "No way. Ain’t this the same tease?"
    b "W-wait—shit—"
    scene end-194
    b "AAAH—f-fuck! Ruslan—! Nghhh—too fast—!"
    guy1 "Ohhh shit—he’s goin’ in now."
    guy2 "She’s losin’ it—look at her legs shaking."
    b "Nnnnnaahh—haaah—c-can’t—too deep! I—AHH! I’m gonna—!"
    b "Ahh! AH—AHH—RUH-Ruslan, I—! G-god I’m—!"

    scene end-195 with fade
    r "You two enjoyin’ the fuckin’ view?"
    guy1 "Damn... didn’t know she could take a dick like that."
    guy2 "You see how deep he was in her ass? Shit had me hard just watchin’."
    r "Yeah? You gettin’ off on it? Watching her get split open like that?"

    scene end-196
    b "Mmm… look at you both..."
    b "Didn’t think you'd ever get this close to what you’ve been jerking off to, huh?"
    r "You wanted to be part of the show, right? Let me show you how close you'll get."
    r "Yeah. I fuck her like this because I know her. Every sound. Every twitch."
    scene end-197
    r "Every look she gives when she wants more but can’t say it. She’s mine."
    r "Not just because I fuck her. Because I see her."
    r "I know what she’s afraid of. I know how she likes her coffee."
    scene end-198
    r "I know when she fakes a smile so the world won’t ask questions."
    r "She gives herself to me. Every part. Her body. Her pride. Her fucking soul. And I guard it with blood."
    b "...R-Ruslan..."
    r "You hear me, baby?"
    r "You’re everything. And I’ll break anyone who looks at you like you’re not."
    scene end-199 with fade
    r "You’re not done."
    b "R-Ruslan...?"
    r "You think I’m letting them walk away with those pathetic dicks hard and your moans still ringing in their heads?"
    r "Nah. You’re gonna give them something they’ll never forget."

    scene end-200
    b "Ohhhhh..."
    guy2 "N-no way—"
    guy1 "He’s…"
    scene end-201


    play sound "voices/womancum1.mp3"
    r "Nah, baby. You're not looking away this time. Look at them. Look at those dumb fuckin' faces while I tear you apart."
    b "A-aaAAH—! F-FUCK—yes—yesyesyesyes—!"
    guy2 "H-he’s gonna break her—"
    b "I—I can’t—I c-can’t—fuuuuUCK—!"

    scene end-202
    b "RUUUUSLAAANN—!"
    b "Aaah! Fuck! FUCK! My insides—it's so deep—nnghh—R-Ruslan—RUH-RUSLAN!"
    guy1 "Fucking hell—"
    b "Ahhh—hahhh—hahhh—haaah—again—do it again—wreck me—ahh-AHHH!"
    r "This is what it means to be taken—to be mine."
    b "Mmmfhh—fuck—fuckfuckfuck—I'm yours—I'm yours—YES—oh god—I'm—AAAH—!"
    stop sound
    scene black with dissolve
    ""

    r "You feel that? Your husband's right here, and you’re still this wet for me."

    scene end-203 with dissolve
    b "Shhh—he’ll wake up—fuck—Ruslan, d-don’t—"
    r "Oh, I’m gonna, baby. I’m already inside. You think I give a fuck who hears you moan?"
    b "Nnnhh—God—slow—he’s right there—"

    scene end-204
    r "Exactly. You want him to wake up and see his wife get ruined by his son?"
    b "Aaah—fuck—nnghh—Ruslan—"
    r "That's it. Feel every inch. Keep quiet for your sweet little husband, while I fuck you like he never could."
    b "I-it’s too much—so deep—ahh—haaah—!"
    scene end-205
    r "Then come on my cock, right here in his bed. Let me feel this married pussy grip me."
    b "Nnnnhh—mmf—please—fuck me harder—just do it—!"
    r "There it is. Let go. Right fucking now. Let him hear how loud his wife comes for his son."
    r "You want it, don’t you. Right here. Right fucking next to him."
    b "Y-yes… do it… cover me—mark me, I want him to smell it—"


    scene end-206 with vpunch
    play sound "voices/manmoaning1.mp3"


    r "Then take it all. Take every fucking drop like the filthy, perfect wife you are."
    "His body jerked forward with the first blast."
    "Thick, hot cum splashed across her chest."
    "She gasped, moaned, arched up into it."
    stop sound
    scene end-207
    b "More—fuck, yes—cover me—make me his dirty little secret—"
    "He groaned as the final ropes spilled across her face, belly, her breasts, her thighs, even spattering across the pillow next to Kamil’s head."
    r "You wear my cum like it’s your skin. Like it belongs there."

    scene end-208
    b "I love it—I love it—it’s all over me—oh god—it’s so much—!"
    b "Fuck… there’s so much… it’s dripping off my face, Ruslan…"
    r "That’s right. Every drop. You earned it. You take cock like it’s your goddamn purpose."
    b "It is. You see my face right now? I’m yours. Not his. I wear your cum better than I wear makeup."
    r "Fuck, baby… look at you. He’s asleep two feet away and you’re bathing in my cum like it’s perfume."
    b "R-Ruslan... fuck me again… please… I want it in my ass..."
    r "Then show me how far you'll go. Kiss him."
    b "W-what—?"
    r "You heard me. Lean over. Kiss your husband. With my cum all over your face. Let him smell it. Let him taste what I did to you."
    scene end-209 with fade
    "She looked at Kamil, still sound asleep, just inches away. Her heart pounded."
    r "You want me in your ass? Show me you don’t care anymore. Show me you're mine."
    b "He… he smells you already…"

    scene end-210
    r "Damn right he does. And he’s gonna taste me too. Go on, baby. Kiss him."
    "Banu leaned in, her heart in her throat, her mouth brushing softly—wetly—over Kamil’s."
    "Her lips, soaked in Ruslan’s cum, touched her husband’s mouth."
    "Kamil stirred faintly, murmured something in his sleep. His lips parted just slightly."
    b "Mmm… there… I kissed him…"
    r "Good girl."
    stop music


    scene ending_4 with dissolve
    "..."


    dev "{color=#ffffff}Thank you for playing! YOU'VE REACHED ONE OF THE ENDINGS!. Play again to discover more. If you enjoyed it, please {a=https://www.patreon.com/lustfulfantasy}support{/a} the development. Wishlist our new game here {a=https://store.steampowered.com/app/4056530/Banu_in_the_West/}Banu in the West{/a} {/color}"
    hide screen faith
    hide screen angeldevil



    $ renpy.end_replay()
    $ persistent.ruslan_ending_unlocked = True
    jump endings














label turan_ending:



    play music "audio/weakbanu.mp3"
    scene black with dissolve
    "....."
    t "On your knees. Come on. You know what to do."
    b "Don’t rush me."
    t "You take your sweet time when you're kneeling for another man, huh?"
    b "Another man. My God…"
    b "God doesn’t watch me here."
    scene end-211 with dissolve
    t "He watches everything. That make it hotter for you?"
    b "Mmhmm…"
    b "Already hard."
    t "Always for you. Every damn time you walk past my desk like you're not the filthiest one in that building."
    b "Shut up."
    b "You talk too much."


    $ renpy.sound.play("voices/bj.mp3", loop=True)

    scene end-212
    t "Fuck—"
    t "There she is. Look at you. Obedient all of a sudden."
    b "Mmmph..."
    b "Mmm... glkk..."
    t "That’s it. All the way, just like that. Don't hold back now. Let me hear it."
    b "Ggkkhh—mmf!"
    t "Fuck yes. That tongue... you're starving for it, aren't you? Kamil doesn’t get this side of you, does he?"
    b "Nn-mm. Nnghh—"
    b "He couldn’t handle it."
    stop sound
    scene black
    b "Turan—"
    t "Hair down. Just like I like it. Look at that… mmm. Spread your knees wider."
    b_ "I shouldn’t have gone… I knew what would happen the second I stepped inside his apartment."
    b_ "I remember my hands on his floor. My hips in the air. And then—his hands on my waist. Heavy. Certain."

    scene end-213 with dissolve

    $ renpy.sound.play("voices/slappingslow.mp3", loop=True)

    b_ "He didn’t wait. Just shoved it in like he’d been starving for me. Like I was his property. And I let him."
    b_ "It hurt. But not really. It hurt the way I needed it to."
    b_ "He was saying things, filthy things—I don’t even want to repeat them. But every word made me clench around him."

    scene end-214
    b_ "He asked me about Kamil… if he ever made me this wet. I told him not to say his name—but even that came out moaning."
    b_ "And then he just… he kept going. Pounding into me like he wanted to leave me broken."
    b_ "My hair was everywhere. In my mouth, on the floor. I couldn’t even hold myself up properly."
    b_ "I told him I hated him. He laughed."
    b_ "And then he told me to say who was fucking me. I said it. Of course I said it."

    scene end-215 with fade
    b_ "He pulled me onto the sofa after… after the floor. Like he wasn’t finished with me. Like he never is."
    b_ "He sat down, legs spread wide, and just looked at me. That look he gives—like he’s daring me to pretend I don’t want him again."
    b_ "I was still shaking. Still leaking down my thighs. But I climbed onto him anyway. Turned my back to him."
    b_ "I don’t know why… maybe I didn’t want to see his face. Maybe I didn’t want him to see mine."

    scene end-216
    b_ "He spread me open without hesitation."
    b_ "His fingers sank into me first—"
    b_ "Then he pushed in, thick and fast, no warning. I gasped—my whole body jerked."
    b_ "He loves that I keep it natural. Says it makes me real, says it makes him harder."
    b_ "Calls it his favorite thing about me when he’s buried between my thighs."
    b_ "He didn’t stop. Not when I whimpered, not when I said his name."
    b_ "He just grunted and slammed harder, making the couch creak, making me shake."
    scene end-217 with fade
    stop sound
    b_ "He came once like that. Pulled out real sudden, grabbed my hip tight, and came all over my bush."
    b_ "Hot. Sticky. I felt it drip down, god. But he wasn’t done."
    b_ "Slapped my ass and shoved it right back in again. I gasped—‘Turan!"
    b_ "I swear I forgot how to speak after that."

    scene black with dissolve
    b_ "And the office—mmnnh—the office was worse. Or better."
    b_ "I don’t even know. The first time, it was quiet, lights off, only the hum of the air conditioner. He bent me over my own desk."
    b_ "I didn’t even resist. I lifted my skirt. I pulled my panties to the side myself."
    scene end-218

    b_ "When he pushed in, I nearly screamed—he clamped a hand over my mouth, and I moaned into his palm while he fucked me."
    b_ "He didn’t even let me bend over that time. No desk, no chair. Just took me standing."

    scene end-219
    b_ "He leaned in, whispered, ‘You’re already wet.’"
    b_ "And I was."
    b_ "Every thrust made my knees buckle, but he held me up. Like I was nothing, like I was his."
    b_ "He reached around, slid his fingers down to rub me while he kept fucking me standing."
    b_ "I came so fast I almost screamed. He had to cover my mouth with his palm."
    scene end-220
    b_ "Then he pulled out, came all over the backs of my thighs, thick and hot."
    b_ "I felt it trickle down."
    b_ "I didn’t even wipe it off before pulling my trousers back up. I walked out sticky, legs shaking."
    b_ "I was scared someone would smell him on me."

    scene black with dissolve
    b_ "Ali was watching us. That whole week he’d been... watching."
    b_ "The way he licked his lips when Turan stood too close behind me."
    b_ "And Turan? He knew. He fucking knew."
    b_ "And they took me."

    scene end-221 with fade
    $ renpy.sound.play("voices/slappingmedium.mp3", loop=True)
    b_ "Next thing I knew, Turan was in front of me, cock already out, and Ali got behind."
    b_ "One feeding me his cock, the other spreading me with fat cock, groaning about how tight I was."
    b_ "I gagged around Turan while Ali pushed in slow—so thick I nearly cried."

    scene end-222
    b_ " 'You're tighter than my first wife,' he said, wheezing, pounding me while I sucked Turan off right there."
    b_ "Ali's cock was fatter, no doubt, but Turan's had that curve, that speed."
    b_ "Together? They ruined me. I was drooling down my chin, hips bruised, blouse ripped open."

    scene end-223
    b_ "They didn’t let me get up until I’d come twice and both of them finished all over me."
    b_ "Ali was grunting like an animal, belly slapping against my ass with every thrust."
    b_ "I could hear them talking about me while they used me, laughing about how wet I was."
    scene end-224 with fade
    stop sound
    b_ "And when they both finished, I was on my back between them, naked on the floor, legs open, dripping."
    b_ "I stroked them both while they lay on either side, their cocks still slick."
    b_ "I don’t even know who I am anymore. But I can't stop. I don't want to."
    b_ "They were looking down at me like I was theirs."
    scene end-225
    b_ "I stroked both of them, one in each hand, my wrists sticky with spit and cum."
    b_ "I didn’t even care who came first."
    b_ "Ali grabbed my waist, pulled me up while Turan stood behind."

    scene end-226 with fade
    $ renpy.sound.play("voices/slappingmedium.mp3", loop=True)
    b_ "They lifted me off the ground, double, standing."
    b_ "Both of them inside. I could barely breathe."
    b_ "I was full, beyond full. My legs kicking in the air, eyes rolling back. I screamed."

    scene end-227
    b_ "And I came like that. Held in the air, stuffed both ways. I think I passed out after."
    b_ "I was off the floor, held between them—one sliding into my pussy while the other pushed into my ass."
    b_ "I screamed. No, I wailed."
    b_ "Every inch stretched, filled from both sides, no space left."
    b_ "My body shaking, eyes rolling back as they moved, slow at first, then harder, deeper, brutal."

    scene end-228
    b_ "My face? God, you should’ve seen me—fucking wild."
    b_ "My mouth wide open, tongue out, eyes rolling like I was possessed."
    b_ "I couldn’t even think, just moaning and drooling while they fucked me."
    b_ "When they were both inside me, that double penetration—fuck, I lost control."
    b_ "My jaw went slack, lips parted, all I could do was pant like a bitch in heat."
    scene end-229 with fade
    stop sound
    b_ "Later… oh God… they made me kneel. Right there on the cold tile, office door locked, lights low."
    b_ "I was already wrecked, cum drying on my thighs, trembling from the last time they filled me."
    b_ "And they stood over me—Turan first, smirking down, holding his cock right in front of my face."
    b_ "I thought he was hard again, ready to fuck my mouth. But no—he aimed, and then I felt it."

    scene end-230
    b_ "Warm. Sudden. A thick stream right across my cheek. I gasped, but I didn’t move—I just let it hit me."
    b_ "My hair, my neck, across my chest. It ran down me like heat."
    scene end-231 with fade
    b_ "I looked up, mouth open, and Ali pissed straight onto my tongue. I swallowed before I could even think."
    b_ "Turan groaned, stepped up, rubbing his fat belly, his cock already dripping. He aimed lower—right between my breasts—and let go."
    b_ "His piss splashed everywhere, soaking my chest, trickling down my stomach."
    b_ "I couldn’t stop moaning. It was filthy. I loved it."
    b_ "They destroyed Kamil’s property—me. His wife. His sweet little Banu, all wrapped in silk and gold bangles, tied to his quiet life."
    b_ "And now? Now I’m just theirs. Turan said it right in my ear while he fucked me against his desk, hand choking me lightly."
    b_ "Ali laughed when I told him I had a husband. Said I was already too far gone. Said no man could claim me now."
    b_ "They used every part of me. They filled me where Kamil never even dared to touch."
    b_ "My mouth, my ass, my cunt—they stretched me wider than I ever thought I could take, left me leaking onto every surface in that office."
    b_ "And I kept coming back. Begging."
    stop music


    scene ending_5 with dissolve
    "..."
    "..."

    dev "{color=#ffffff}Thank you for playing! YOU'VE REACHED ONE OF THE ENDINGS!. Play again to discover more. If you enjoyed it, please {a=https://www.patreon.com/lustfulfantasy}support{/a} the development. Wishlist our new game here {a=https://store.steampowered.com/app/4056530/Banu_in_the_West/}Banu in the West{/a} {/color}"
    hide screen faith
    hide screen angeldevil
    $ renpy.end_replay()
    $ persistent.turan_ending_unlocked = True
    jump endings






label kamilkillsbanu_ending:

    scene black with dissolve
    "..."
    scene end-1 with blinds
    play music "audio/intro.mp3"

    b_ "Why does it always feel like this?"
    b_ "This pull, this ache... It's not just my body—it’s something deeper, something I can’t control."
    b_ "Cheating on Kamil is now a habit...."
    scene end-2
    b_ "Kamil doesn’t even look at me like that anymore. When was the last time he touched me like he wanted me?"
    b_ "Not out of obligation, but because he couldn’t stop himself? God, I miss feeling wanted."
    scene end-3
    b_ "And Polad… the way his eyes lingered that night."
    b_ "He didn’t even try to hide it. I know that look."
    b_ "It’s dangerous. It’s intoxicating. And yet… I liked it. I like it."
    scene end-4
    b_ "This isn’t me. I’m not this woman. I’m Kamil’s wife. I made vows. I… I’m supposed to be loyal."
    b_ "But then why does the thought of Polad’s hands on me send shivers down my spine?"
    b_ "Why do I feel alive when he’s near, and so hollow when I’m with Kamil?"
    scene end-3
    b_ "Why does it feel so good to be bad? Maybe because it’s forbidden. Maybe because it’s mine."
    b_ "No one controls me anymore—not Kamil, not anyone."
    b_ "Ahmed… the way he pinned me against the wall that night, his hands gripping my waist like I was the only thing that mattered."
    b_ "I didn’t even have time to think, and I didn’t care."
    b_ "And this Samir at work..."
    b_ "He looked at me like I was a goddess."
    b_ "And when he kissed me in the storage room, his hands trembling as he explored my body… it was thrilling."
    b_ "And him… Leyla’s husband. I shouldn’t even think about it, but I can’t help it."
    b_ "He was bold, confident, and he knew exactly what he wanted. "
    b_ "The way he whispered in my ear, calling me beautiful, desirable… It was wrong. So wrong. But it felt so damn right."
    b_ "Every single one of them gave me something Kamil never could."
    b_ "They saw me, wanted me, craved me. And isn’t that what every woman deserves? To be wanted?"
    scene end-5 with fade
    stop music
    b "Kamil? What are you doing up? It’s late."
    k "Couldn’t sleep. Thought I’d have an apple. You know how I love a midnight snack."
    b "You’re scaring me, sitting here like that in the dark. Come back to bed."
    scene end-6
    play music "audio/weakbanu.mp3"
    k "Scaring you? Don’t be silly. It’s just me and an apple."
    k "Funny thing about apples. They can look perfect on the outside."
    k "Shiny, red, tempting. But you never really know what’s inside until you cut it open."
    b "You’re overthinking fruit now? Maybe you really do need to get some sleep."
    scene end-7
    k "Maybe. Or maybe I’ve just been paying closer attention lately."
    k "You’d be surprised what you notice when you stop taking things for granted."
    b "Kamil… are you okay? You’re acting… different."
    b "Kamil… did you drink? At this hour?"
    k "Why not? It’s a good night for it, don’t you think?"
    b "This isn’t like you, Kamil. What’s going on?"
    scene end-8
    k "Who were you talking to just now?"
    b "Oh, it was… Nesrin. She called to check in. You know how chatty she can be."
    k "Nesrin, huh? Funny. You looked a bit… nervous for someone just talking to Nesrin. "
    k "What were you two chatting about?"
    b "Nothing important. Just… the usual stuff. Gossip, mostly. You know how she is."
    k "Sure. Nesrin loves her gossip. But you were whispering, weren’t you? Seemed like you didn’t want me to hear."
    b "It’s just habit, I guess. You know, girl talk."
    b "Didn’t think you’d be interested in what Nesrin had to say about her neighbor’s dog or whatever."
    scene end-9 with fade
    k "You know, Banu… you’re truly stunning."
    b "Well, thank you. Didn’t know you still had it in you to flatter me like that."
    k "No, really. Look at you. That silky hair, those perfect lips, those eyes that could… what’s the phrase? Ah yes—steal a man’s soul."
    b "Steal a man’s soul? That’s a bit dramatic, don’t you think? What, are you trying to butter me up for something?"
    k "Oh no, I’m just appreciating you."
    scene end-10
    k "The way you move, the way you smile, the way you light up whenever your phone rings… it’s breathtaking. Really."
    b "Wow, Kamil, you’re on fire tonight! Keep it up, and I might actually believe you’re serious."
    k "Oh, I’m very serious, Banu. A woman like you… you deserve to be admired."
    k "Worshipped, even. I mean, who wouldn’t fall for someone so… irresistible?"
    k "Take your top off."
    scene end-11
    b "What? Are you mad? It’s the middle of the night… in the middle of the kitchen!"
    k "So? No one’s watching. It’s just us. Go on, Banu. Let me see those tits."
    b "Kamil, you’re drunk. You’re acting… strange. Stop messing around."
    k "I’m not messing around. I want to see. You’ve always been so proud of them, haven’t you?"
    k "Always showing them off, pretending you’re not. So… let me see."
    b "Kamil, what’s gotten into you? This isn’t funny."
    k "Who said I’m trying to be funny? Come on, Banu."
    b "You’re insane. Fine. If it’ll shut you up…"
    play sound "voices/cloth.mp3"
    scene end-12 with fade
    b "Happy now? Or do you want me to strip completely while we’re at it?"
    k "Keep going. The pants too."
    b "Kamil, this is ridiculous. What is wrong with you?"
    k "Nothing’s wrong with me, Banu. I just want to see…"
    scene end-13
    b "Enjoy the view, Kamil. Is this what you wanted?"
    k "It’s beautiful, Banu. You’re beautiful. But you already know that, don’t you?"
    k "The top’s nice, Banu. But let’s not stop there. Take off the pants too."
    b "Are you out of your mind?"
    k "Why not? What’s the harm?"
    b "Kamil, you’re drunk. This is ridiculous. Stop this now."
    k "Take them off, Banu. I want to see everything. If you’re not hiding anything, then why not?"
    b "Fine. You want this? "
    b "Here. Take a good look."
    play sound "voices/cloth.mp3"
    scene end-14 with fade
    b "Are you happy now?"
    k "You’re beautiful, Banu. Truly. But beauty isn’t everything, is it?"
    k "Sometimes it’s just a mask… hiding something rotten underneath."
    b "Alright, Kamil. I’m officially your midnight entertainment. Should I start charging you for the show?"
    scene end-15
    b "Well, here you go. The grand unveiling. Should I name it?"
    b "How about… ‘The Great Banu’s Garden of Secrets’? Or maybe just ‘The Forbidden Fruit."
    b "Come on, Kamil. Lighten up. If you wanted a private show, you could’ve just asked nicely."
    k "Keep laughing, Banu. After all, you’ve always had a way of making people smile, haven’t you?"
    scene end-16 with fade
    k "I loved you so much, Banu. I loved this body..."
    b "Did you watch some thriller movie while I wasn’t paying attention?"
    b "Because you’re acting like the mysterious villain."
    b "Alright, Kamil, this is getting weird. What are you doing now? Going full suspense thriller on me?"
    k "Relax, Banu. It’s just a knife. A simple tool. Harmless… in the right hands."
    b "Kamil, if this is your idea of foreplay, you’re really bad at it."
    scene end-17
    b "Ohhhh....Kamil… this is ridiculous. What are you doing? Trying to scare me?"
    k "Who’s this for, Banu?"
    b "What… what do you mean?"
    b "Kamil… stop this. You’re drunk. You don’t know what you’re saying."
    k "Tell me, Banu… why do you keep it like that?"
    b "Keep what like what? What are you talking about now, Kamil?"
    k "The bush, Banu. You keep it full, natural. Why? Is it for me?"
    b "Kamil, you’re ridiculous. It’s just hair. Does it really matter?"
    k "Maybe it does. Maybe it says something about you."
    b "It’s just how I like it."

    scene end-18 with fade
    play music "audio/romantic.mp3"
    k "Do you know what love is, Banu? Real love? It’s not the flowers, the kisses, or the promises."
    k "It’s not the things people show off to the world."
    k "Love is… sacrifice. It’s waking up every day and choosing someone."
    k "Even when it’s hard. Even when they hurt you. Even when they forget who you are."
    scene end-19
    b "Kamil...this is so romantic..."
    k "I’m talking about us, Banu. About how much I’ve given. How much I’ve loved you."
    k "From the very first day… I thought you were my world. My everything. And I promised myself I’d never let you go."
    scene end-20
    k "But love… it’s not enough, is it? Not when the other person doesn’t feel the same."
    k "Not when they start… drifting away. Choosing other people, other things. Leaving you behind."
    b "Kamil, I never…"
    k "You know, I used to think I was lucky. To have you. To love you."
    k "But now I wonder if it was a curse. Because no matter how much I gave, it was never enough. "
    k "And now here we are. You, standing there, beautiful as ever… and me, wondering if I ever really knew you at all."
    k "You know, Banu, I tried. I really did. I told myself it was all in my head."
    k "That I was imagining things. But you… you made it impossible to ignore."
    scene end-21
    b "Kamil, what are you talking about?"

    play music "audio/intro.mp3"

    k "And let’s not forget Polad. Your precious Polad. My friend. The one you swore was just like a brother to you."
    k "Did you laugh with him too, Banu? Did you joke about how blind I must be?"
    b "Kamil, please… let me explain."
    scene end-22
    k "Explain what? How you betrayed me? "
    k "How you let them all touch you, take you, while I was here… loving you? Trusting you?"
    k "And the worst of it? Leyla’s husband. Our daughter’s husband, Banu. Did you think I wouldn’t find out?"
    k "Did you think I’d be too stupid to notice?"
    b "Kamil… I…"
    scene end-23
    k "You filthy, lying whore! "
    k "Do you even know the kind of disgusting piece of shit you are?"
    k "I gave you everything—my time, my love, my fucking soul..."
    k "...and you spread your legs for every bastard who gave you a second glance!"
    b "Kamil, please… "
    scene end-24
    k "Shut your fucking mouth! You don’t get to say a damn word!"
    k "You think sorry means anything?"
    k "You think you can wipe away the stench of every pathetic loser who’s been inside you with a simple ‘sorry’?"
    k "You’re a dirty, shameless bitch, Banu. And you don’t even have the decency to admit it."
    scene end-25
    b "I… I love you, Kamil… I—"
    k "Love isn’t spreading your legs for the nearest cock when your husband isn’t looking."
    k "Love isn’t lying, cheating, humiliating me in ways I can’t even put into words. "
    k "Say it, Banu. Say their names. All of them."
    b "Kamil, please… I don’t… I can’t…"
    k "SAY IT! Admit what you’ve done! Every man you’ve let touch you."
    k "Every man you’ve betrayed me with. Say. Their. Names!"
    b "Ahmed… the neighbor. He… it was just once. I didn’t mean for it to happen."
    k "Ahmed. Of course. Go on, Banu. Don’t stop now."
    b "Polad… it was a mistake. He… he was there for me, and I… I was weak."
    k "Polad. My friend. My fucking friend, Banu."
    k "You’re not my wife. You’re not even a woman. You’re just a fucking hole. That’s all you’ve ever been."
    k "You’re nothing, Banu. And you’ll die as nothing."
    b "Kamil, please… please don’t hurt me. I’ll do anything—anything you want. Just… don’t kill me."
    b "I’m nothing without you, Kamil. I’m a liar, a cheater, a filthy… filthy whore."
    b "I deserve your anger. I deserve your hate. But please… I don’t want to die."
    scene end-26
    stop music
    k "Tell me, Banu. Tell me exactly what you are."
    b "I’m a whore… a disgusting, ungrateful whore. I betrayed you. I hurt you."
    b "I’m worthless, Kamil. A piece of trash. I don’t deserve your love… I don’t even deserve your forgiveness."
    b "But please, don’t kill me. I’ll do anything. I’ll spend the rest of my life making it up to you. Just… please…"
    b "Just give me a chance. Please… I’m begging you."
    play sound "voices/ah.mp3"
    scene end-27 with vpunch




    b "K-Kamil…"
    "His hand tightens on the knife. Without a word, he lunges forward, the blade piercing just above her belly button."
    "The sound of the knife sinking into her flesh is followed by a sharp gasp."
    "Her body jerks as her wide, disbelieving eyes meet his."
    scene end-28
    b "K-Kamil… why…?"
    k "Do you feel it, Banu? Do you feel what you’ve done to me?"
    k "This… this is the pain you’ve left me with every single day."
    b "Kamil… I… I loved you…"
    k "Love?! You call this love?! You destroyed me, Banu. You tore out my heart and crushed it beneath your feet."
    k "And now… now you want me to believe you loved me?"
    scene end-29
    play music "audio/intro.mp3"
    b "I… I was wrong. I… I’m sorry. Kamil… please…"
    k "You should’ve stayed mine, Banu. You should’ve been mine and mine alone."
    b "Kamil… please… call… an ambulance."
    scene end-30
    b "Don’t… let me die like this."
    k "You think I should save you? You think you deserve it?"
    b "Please… I’m sorry… I… I don’t want to die… like this. Please, Kamil… just… help me."
    b "Kamil… please… if you ever… loved me… please…"
    scene end-31 with vpunch
    b "K-Kamil… please… help me. I… I don’t want to die."
    k "You didn’t deserve my love, Banu. And now… you don’t deserve my mercy."
    b "Please… call someone… call an ambulance… don’t… let me…"
    "Kamil turns away, leaving her lifeless body on the floor as he walks out of the kitchen."
    scene end-32 with fade
    stop music
    "Her body lies motionless on the floor, her lifeless eyes closed."
    "The vibrant, defiant woman she once was is now gone, leaving only a tragic stillness."





    scene ending_1 with dissolve
    "..."
    "..."
    dev "{color=#ffffff}Thank you for playing! YOU'VE REACHED ONE OF THE ENDINGS!. Play again to discover more. If you enjoyed it, please {a=https://www.patreon.com/lustfulfantasy}support{/a} the development. Wishlist our new game here {a=https://store.steampowered.com/app/4056530/Banu_in_the_West/}Banu in the West{/a} {/color}"
    hide screen faith
    hide screen angeldevil


    $ renpy.end_replay()
    $ persistent.kamilkillsbanu_ending_unlocked = True
    jump endings








    dev "{color=#000000}Thank you for playing! This is the end of this route in this version. Play again to discover more. If you enjoyed it, please {a=https://www.patreon.com/lustfulfantasy}support{/a} the development. Buy the full game(Early Access) on {a=https://store.steampowered.com/app/2505580/Life_in_Middle_East/}STEAM{/a} {/color}"
    hide screen faith
    hide screen angeldevil
    jump endings

























































label hassanending:


    play music "audio/softromanticsex.mp3"

    scene black with dissolve
    "...."
    $ renpy.sound.play("voices/softmoan.mp3", loop=True)
    b "Hassan—"
    hs "Shhh... don’t say a word unless it’s my name. God, you’re soaked already."
    scene end-232 with dissolve
    b "That mouth of yours... don’t you dare tease—"
    hs "I’d never. I want you panting in this kitchen, shaking so hard the plates rattle. Hold still—"
    b "Haaah... H-Hassan...!"
    hs "That’s it. Let it out. Let your son-in-law make you come like no one ever has."
    b "You filthy boy... yes... just like that, don’t stop—don't—!"
    scene end-233
    hs "Mmmf... fuck, you taste like sin. You were made for this, Banu."
    b "You wanted a midnight snack, didn’t you? Mm... look closer, Hassan."
    b "That’s what you’ve been staring at all evening, isn’t it?"
    hs "Holy fuck... Banu..."
    b "Watch how wet I get just from you licking me."
    b "You see that shine? That’s for you. You gonna waste it, or drink?"
    hs "Fuck, Banu—"
    hs "You think you can tease me and walk away? Not tonight."
    b "Mmm, that temper... what are you gonna do, Hassan?"
    hs "Gonna fuck you like you deserve. Right here. You want to act like a bitch in heat? I’ll fuck you like one."
    stop sound
    scene end-234 with fade
    $ renpy.sound.play("voices/moaning.mp3", loop=True)
    b "F-fuck—so thick—ah! You’re really—"
    hs "Every fucking inch. You’re taking it. You’re taking all of me, Banu."
    b "Nnghh—haaah—d-deeper—god, Hassan, fuck—"
    hs "Take my cock in your ass while the whole fucking house sleeps!"
    b "Yes—yes, god, Hassan—fucking ruin me—split me open—!"
    hs "Fuck—your ass is choking me. You’re filthy, Banu. Say it."
    b "I’m filthy—I’m a whore for it—I love getting fucked in the ass like this—!"
    scene end-235
    b_ "You should’ve seen the look on his face... like he’d been starving for years and I was the last meal on earth."
    b_ "He didn’t ask. He just bent me over the kitchen table like I was his. Right behind Kamil’s back. Right under Leyla’s nose."
    b_ "His hands were shaking when he grabbed my hips. Not from nerves—from how bad he wanted to fuck me there. In the ass. Like some animal."
    b_ "I told him it wouldn’t fit. I told him someone might wake up. And he just spat in his hand and said, ‘Then bite the fucking table, Banu.’"
    b_ "And I did. I bit down hard. Because when he started pushing in, slow but steady, I thought I’d scream loud enough to wake the whole damn neighborhood."
    b_ "It wasn’t rushed. He didn’t fuck like a man scared of getting caught—he fucked like he wanted to make sure I remembered it forever."
    scene end-236 with fade
    stop sound
    b_ "He fucked me in the ass while Kamil was asleep right there. In the same bed. Just inches away."
    b_ "He crawled in behind me like a fucking wolf, pulled the blanket up over both of us like it would hide the filth, and whispered in my ear, ‘Don’t wake him, Banu.'’"
    b_ "My heart was pounding so loud I thought Kamil would hear that alone."
    b_ "But Hassan didn’t stop. He reached under, grabbed my wrists, and pulled them back—tight. Bent me like a bow."

    scene end-237
    b_ "My arms were twisted behind me, held there while he started to move—deep, deliberate strokes, like every thrust was a punishment I wanted more of."
    b_ "I could feel Kamil’s breath on the other pillow. I could smell him. And still, Hassan fucked me harder. Right there."
    b_ "Right next to my husband."
    b_ "He said, ‘If he wakes up, what’ll you do? Pretend I’m not inside your tight little ass? Pretend you don’t want it?"
    scene end-238
    b_ "Hassan’s cock? That thing wrecked me. It’s thick, mean, shaped to ruin a woman."
    b_ "Not made for gentleness—made to stretch, to fill, to leave you trembling long after he’s done."
    b_ "The first time he pushed it in my ass, I saw stars."
    b_ "I mean eyes rolling back, breath caught, mouth open but no sound coming out—just this raw, helpless ache."
    b_ "He didn’t slide in, no. He fed it in, inch by inch, like he wanted me to feel every ridge, every throb, every pulsing vein."
    b_ "Kamil’s been my husband for decades. We built a life. A home. And I still let his daughter’s husband bend me over his kitchen table."
    b_ "Leyla calls me for advice, for comfort, for trust. She kisses me on the cheek with the same mouth that kisses the man who fills my ass at night."
    b_ "Hassan makes me feel wanted in a way that terrifies me."
    b_ "Every time I fuck him, I think, this is the last."

    scene end-241 with fade
    b_ "Hassan had me pinned—face down, ass up, arms wrenched behind my back—and he was deep."
    b_ "So deep I could barely breathe, let alone speak."
    b_ "She opened the door, just a crack... and I saw her."
    b_ "Leyla...."


    scene end-239
    b_ "Kamil was snoring beside us, clueless. But she wasn’t. She stood there."
    b_ "Her eyes locked right on me."
    b_ "And I didn’t stop."
    b_ "Hassan didn’t either."
    scene end-240
    b_ "He looked straight at her. Smirked. And drove his cock deeper into my ass like it was a fucking performance."
    b_ " 'Mama?’ she said. I’ll never forget the way her voice cracked."
    b_ "But I couldn’t answer. Couldn’t even look her in the eyes. Hassan just kept fucking me, harder now, like her watching made it hotter for him."
    b_ "But the worst part wasn’t her rage. It was the tears she wouldn’t let fall."
    b_ "She saw everything. How I shuddered. How I clenched around him. How her mother’s body begged for her husband’s cock."
    scene end-242 with fade
    b_ "I stood up, legs shaking, my insides still raw from how deep he’d been, and his cock just hung there."
    b_ "Leyla was right in front of us. Just standing there. Eyes wide, face pale, mouth trembling like she was going to scream—or collapse."
    b_ "And I couldn’t even cover myself."

    scene end-243
    b_ "I wanted to speak, to reach out, but nothing came. Just this hot, sour guilt crawling up my throat, choking me."
    b_ "But him? Hassan didn’t flinch."
    b_ "She said, ‘You’re fucking disgusting,’ and I couldn’t argue."
    b_ "My thighs were still wet, my asshole aching, and all I could think about was how good he felt inside me."
    b_ "But then he stepped close—his cock right there, still hard—and he said to her, low and smug..."
    b_ "‘She begged me for it. Said I stretched her better than your father ever could. Didn’t you, Banu?"
    b_ "And I—god help me—I nodded."
    b_ "And he leaned into my ear, in front of her, and whispered, ‘Tell her what you said with my cock in your ass.’"
    b_ "And I did. Like a fucking fool."
    b_ "She backed away. She didn’t scream. She didn’t slap me. Just stared, like she was seeing a stranger in her mother’s skin."
    b_ "And all the while, his cock hung heavy beside me. Still ready. Still waiting."
    b_ "And I wanted him again."
    stop music
    scene ending_6 with dissolve
    "..."
    "..."

    dev "{color=#ffffff}Thank you for playing! YOU'VE REACHED ONE OF THE ENDINGS!. Play again to discover more. If you enjoyed it, please {a=https://www.patreon.com/lustfulfantasy}support{/a} the development. Wishlist our new game here {a=https://store.steampowered.com/app/4056530/Banu_in_the_West/}Banu in the West{/a} {/color}"
    hide screen faith
    hide screen angeldevil
    $ renpy.end_replay()
    $ persistent.hassanending_unlocked = True
    jump endings
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
