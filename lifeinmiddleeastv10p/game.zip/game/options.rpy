












init -1 python:

    style.default.outlines = [(1.8, "#000000", 0, 0)]





define gui.text_color = "#eeeeee"















define config.name = _("Life in Middle East")





define config.menu_include_disabled = True

define gui.show_name = True

define config.developer = True



define config.version = "v1.0"



























define gui.about = _p("""   {color=#061E7D}
    
    Italian translation by Eagle1900
    
    
    Special thanks to my highest tier patrons! {/color}
    
         {color=#234F1E}                  Rauf                   {/color}   
         
         {color=#234F1E}                  ZameS                   {/color}   
    
         {color=#E81123}                  Fong chi hou         {/color}
         
         {color=#E81123}                  Adi         {/color}
         
         {color=#E81123}                  ENamP         {/color}
         
         {color=#E81123}                  Erto         {/color}
         
         {color=#E81123}                  Geko1711         {/color}
         
         {color=#E81123}                  Daniele Giantomaso                 {/color}                 
         
         {color=#E81123}                  Jai Ti                   {/color}            
         
         {color=#E81123}                  Richard Ng                  {/color}
                                         
         {color=#E81123}                  Daiquan D Thomas         {/color}
                            
         {color=#E81123}                  SneakyP3t3                    {/color}           
                                         
         {color=#E81123}                  Boi Ulavin                   {/color}
              
    
      

                      
""")






define build.name = "Lifeinmiddleeast"







define config.has_sound = True
define config.has_music = True
define config.has_voice = True













define config.main_menu_music = "audio/mainmenumusic2.mp3"










define config.enter_transition = dissolve
define config.exit_transition = dissolve




define config.intra_transition = dissolve




define config.after_load_transition = None




define config.end_game_transition = None
















define config.window = "auto"




define config.window_show_transition = Dissolve(.2)
define config.window_hide_transition = Dissolve(.2)







default preferences.text_cps = 50





default preferences.afm_time = 15
















define config.save_directory = "Lifeinmiddleeast-1593286320"






define config.window_icon = "gui/window_icon.png"






init python:
























    build.classify('**~', None)
    build.classify('**.bak', None)
    build.classify('**/.**', None)
    build.classify('**/#**', None)
    build.classify('**/thumbs.db', None)






    build.classify('game/**.webp', 'archive')
    build.classify('game/**.webm', 'archive')
    build.classify('game/**.rpy', 'archive')
    build.classify('game/**.mp3', 'archive')
    build.classify('game/**.png', 'archive')





    build.documentation('*.html')
    build.documentation('*.txt')
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
