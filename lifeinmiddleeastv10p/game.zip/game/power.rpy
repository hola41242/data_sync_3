






label polad_banu_power_shower:

    play music "audio/softromanticsex.mp3"
    scene black with dissolve
    "..."
    "Banu stood under the hot shower in Polad's apartment, letting the water wash over her tired muscles."
    scene v21-1 with pixellate
    "As the water flowed down her body, her mind wandered back through the recent events that had changed her life forever."
    "She thought about Kamil, the man who had once been everything to her. Their breakup had shattered her world, leaving her feeling lost and vulnerable."
    "Banu remembered the hours she spent in the gym, pushing her body to its limits."
    "She wanted to ensure no one would ever hurt her or Leyla again."
    "She turned herself into a warrior, her muscles growing stronger, her resolve harder."
    scene v21-2
    "Her thoughts turned dark as she remembered the man who had hurt Leyla. Banu had tracked him down and exacted her revenge, brutally ending his life."
    "The memory of that night was vivid in her mind. She felt satisfaction, but also a heavy weight on her soul. She had crossed a line, one she could never step back from."
    b_ "No one will ever make me weak again."
    b_ "Now here I am, living with a man that I've always been afraid to fall in love with."
    b_ "Polad is everything I want in a man—strong, assertive."
    b_ "But I'm scared. Letting him in might mean losing my strength, my control. "
    b_ "I can't afford to be weak, not for anyone. I have to stay strong, for Leyla and for myself."
    b_ "Vulnerability is a luxury I can't afford anymore."
    scene v21-3 with fade
    "She turned and saw Polad standing there, completely naked."
    "His muscular frame was imposing, his semi-erect cock hanging prominently. His eyes were locked on her with a lustful, intense gaze."
    "She didn't flinch or make any move to cover herself. Instead, she let her eyes roam over Polad's body, acknowledging the physical power he exuded."
    b "What do you want?"
    p "You."
    b "Polad, what are you doing here? Get out of here."
    p "I wanted to see you. Really see you."
    b "You've seen me before."
    p "I see you now for everything you are. Strong, fierce, and...beautiful."
    b "You think just because you say nice words, I'll fall for you?"
    scene v21-4
    p "I don't want you to be weak, Banu. I want you to be exactly as you are. Strong. Unyielding."
    b "Words are easy, Polad. Prove it."
    p "I don't just want you physically, Banu. I want all of you. Your strength, your fire, your heart."
    b "And what if I don't want to give all of that? What if I can't?"
    p "Then we take it one step at a time. I'm not here to take anything from you. I'm here to stand with you."
    p "I know that you always loved me. Even when you were with Kamil."
    p "I love you too, Banu."
    scene v21-5
    b "You make it sound so simple."
    p "Because it is. With the right person, it is."
    b "I've been through so much, Polad. I've built these walls to protect myself, to stay strong."
    p "And those walls have made you who you are. But sometimes, even the strongest walls need a door. A way to let in something good."
    b "Are you saying you're that something good?"
    p "I'm saying I want to try to be. If you let me."
    b "I don't know if I can. Trusting someone again... it's a risk."
    p "Life is full of risks, Banu. But some are worth taking. And I promise you, I will never make you feel weak."
    "Polad moved closer to Banu, the steam swirling around them, creating an intimate cocoon."
    stop music
    menu:
        "Stop him":
            $ banuletpoladfuckhershower = False
            $ renpy.block_rollback()
            scene v21-6
            "As he approached, Banu raised her hand and placed it firmly on his chest, stopping him in his tracks."
            b "Stop, Polad."
            p "Banu, what's wrong?"
            b "I need you to leave. Now."
            p "I don't understand. Talk to me."
            scene v21-7
            b "I can't afford to let my guard down. Not for you, not for anyone. I need to stay strong, and you being here is a distraction."
            p "Strength isn't about pushing everyone away. It's about knowing when to let someone in."
            b "I don't need your philosophy, Polad! I've been through hell, and I've survived by relying on myself."
            b "I won't let anyone make me feel vulnerable again."
            p "I'm not here to make you feel weak. I want to support you, to stand by your side."
            b "No, Polad. You need to leave. Right now."
            p "If that's what you want, I'll go."
            "Polad took a step back, his expression a mix of hurt and understanding. He knew better than to push her when she was like this."
            scene black with fade
            "Without another word, Polad turned and left the shower, the door closing behind him with a finality that echoed in the small space."
            "She had pushed him away, just as she had done with everyone else who tried to get close."
            b_ "I can't be weak. I won't be weak."
        "Let him take you":



            $ banuletpoladfuckhershower = True
            $ renpy.block_rollback()
            play music "audio/weakbanu.mp3"
            scene v21-8 with fade
            "Her hand slowly lowered, her defenses crumbling. Polad closed the distance, his body pressing against hers. He cupped her face gently, his thumb tracing her cheek."
            b "Polad..."
            "As their bodies pressed together under the warm spray, Banu's leg instinctively wrapped around Polad's waist, pulling him closer."
            p "I've wanted this for so long, Banu."
            b "Me too, Polad. Me too. Please, don't stop."
            scene v21-9 with fade
            play music2 "voices/longmoan.mp3"
            "Polad positioned himself behind Banu, his hands gripping her hips with a powerful yet tender hold."
            "The moment Polad entered Banu, she let out a hard uncontrollable scream. "
            "Banu's body got weaker with each powerful thurst of Polad's big cock deep in her womb."
            "Banu lost herself so fast."
            b "Oh, Polad... yes, don't stop!"
            b "Polad... I can't... I'm..."
            "Her words trailed off into a breathless moan as Polad's thrusts became more intense. "
            "The sensation of his cock deep inside her made her legs shake uncontrollably."
            b "Polad, harder... please! Break me! Make me a woman again! ahhhhhh..."
            scene v21-10 with fade
            b "Ahhhh..."
            "Polad's eyes darkened with a primal intensity. He raised one of her legs, opening her up even more. "
            "His grip tightened as he began to pound her pussy like an animal."
            "The sound of their bodies slapping together echoed in the steamy shower, each thrust driving deeper and harder."
            p "You want it harder? I'll give it to you harder."
            "Banu's body quivered with each powerful thrust, her moans turning into cries of pure ecstasy."
            b "Polad, yes! Don't stop! Break me!"
            "Banu's sexy moans and seductive words made Polad go crazy. "
            "He turned into an animal and destroyed Banu's insides making her scream from pleasure."
            scene v21-11 with fade
            "Polad, filled with an insatiable desire, lifted Banu into his arms."
            p "Hold on tight, Banu. I'm not done with you yet."
            b "Oh... ah... Polad... ahhh... ungh... I can't... it's... ahhh... please... oh god... yes... ahhh..."
            p "You like that, don't you, Banu? You love how deep I'm going."
            b "Yes... oh... so deep... ahhh..."
            p "You feel so good, Banu. So tight around me."
            b "Ahhhh... ohhh... Polad... please... yes... more... ahhhh... ohhhh... ohhhh... yesss..."
            p "That's it. Let it out. Scream for me."
            b "Ahhhh... Polad... I'm... ohhh... I can't... it's too much... ahhhh..."
            p "You can take it. You're so strong. Come for me, Banu."
            b "Ahhhh... ohhh... Polad... please... yes... more... ahhhh... ohhhh... ohhhh... yesss..."
            p "Come with me, Banu. Let go."
            "Banu felt the first wave of her orgasm crash over her, her body convulsing as she cried out his name. "
            "But Polad didn't stop. He continued to thrust into her, each movement pushing her into another orgasm."
            "She came again, her cries becoming more desperate and breathless with each climax."
            p "One more, Banu. Come for me one more time."
            "Banu's legs finally gave out, and she collapsed into Polad's strong arms, her body completely exhausted and trembling."
            "They stood there, bodies entwined, the water washing over them as they caught their breath."
            "Banu's strength had given way to a profound sense of satisfaction and connection, her body weak but her spirit invigorated by the intensity of their shared passion."
            stop music2
            stop music




    $ renpy.end_replay()
    $ persistent.polad_banu_power_shower_unlocked = True
    jump polad_banu_power_shower_continue










label ali_fuck_banu:



    play music "audio/suspense.mp3"

    scene v21-12 with blinds
    "Banu meticulously set up a trap for Ali, spying on him and learning his routines. She discovered that he had called for a call girl to visit him that night."
    "Determined to confront him first, Banu decided to take action. She prepared herself, dressed in her work attire to mask her true intentions."
    "As the evening grew darker, Ali awaited the arrival of the call girl in his lavish living room. The main door was slightly ajar, left open in anticipation."
    "A knock echoed from the living room door, startling Ali. Confident it was the call girl, he walked toward the door with a smirk on his face."
    scene v21-13
    "When the door opened, it wasn't the call girl standing there. It was Banu, her face adorned with a fake smile that didn't reach her eyes."
    "She stepped inside, closing the door behind her with a quiet click."
    b "Good evening, Ali."
    "Ali's smirk faded, replaced by confusion and a hint of fear as he recognized her."
    ali "Banu? What are you doing here?"
    b "I thought we had some unfinished business, Ali. I wanted to discuss it with you."
    ali "I don't know what you're talking about."
    b "Come now, Ali. Don't look so frightened. I didn't come here to cause trouble. I just thought... maybe we could talk about old times."
    scene v21-14
    ali "Old times, huh? Well, I didn't expect to see you tonight, Banu. You're looking... quite lovely."
    b "I'm glad you think so, Ali. I wanted to show you that I've... changed since we last met. Maybe we could start over."
    ali "I like the sound of that. You know, Banu, I've always thought you were special. A bit of fire in you."
    b "Oh, Ali, you have no idea how much fire I have inside me. Why don't we sit down and... talk a little more privately?"
    ali "I'm glad you came to see me, Banu. I always knew there was something between us."
    b "Yes, Ali. There's definitely something between us. And tonight, we're going to explore that... thoroughly."
    "I can't help it anymore. I want to be with you. These clothes... they're just getting in the way."
    scene v21-15 with fade
    "She began to walk slowly across the room, her fingers moving to the buttons of her shirt. "
    "Ali's eyes followed her every movement, his expression shifting from suspicion to sheer lust."
    ali "That's right, Banu. Show me how much you've changed."
    "Banu let her shirt slip off her shoulders, catching it with one hand before tossing it aside."
    scene v21-16 with fade
    b "Do you like what you see, Ali?"
    ali "Oh, yes. You're even more beautiful than I remembered."
    b "Why don't you come closer, Ali? I want you to feel just how much I've missed you."
    ali "Not so fast. Let's take our time."
    b "You look comfortable, Ali. Just sit back and enjoy."
    scene v21-17 with fade
    "Her pants slipped down her legs, and she stepped out of them gracefully, tossing them aside."
    "She maintained eye contact with Ali, watching his eyes widen as more of her athletic, muscular body was revealed. "
    "Ali's eyes roamed over her exposed body, taking in every curve, every muscle. He licked his lips, clearly enthralled by the sight before him."
    ali "Damn, Banu. You've been working out. You look incredible."
    b "Do you like what you see, Ali? This is what you've been missing."
    ali "I knew you were special, Banu. Come here."
    b "Patience, Ali. Good things come to those who wait."
    scene v21-18 with fade
    "Banu tightened her grip on Ali's wrist, forcing him to stand up from the couch. Her smile was mischievous, her eyes gleaming with a mix of seduction and hidden menace."
    b "Come on, Ali. Let's make this more comfortable for both of us."
    "Ali, still reeling from the sudden shift in Banu's demeanor, complied, his mind clouded with confusion and lust."
    b "You know, Ali, I've been thinking about this moment for a long time. All those things you said, the way you treated me..."
    ali "I knew you'd come around eventually, Banu. We have a connection, don't we?"
    b "Oh, we have a connection, alright. One that runs very deep."
    b "You always liked to be in control, didn't you, Ali? But tonight, things are going to be a little different."
    "Banu's mischievous smile remained firmly in place as she gripped the collar of Ali's red bathrobe."
    scene v21-19 with fade
    "She slowly pulled it off, revealing his soft, big, flabby belly and his fat ass."
    "Ali stood there, his vulnerability on full display, and yet, he was too entranced by Banu's seductive demeanor to recognize the danger he was in."
    b "You always liked to be the center of attention, didn't you?"
    ali "Well, I... I always knew you couldn't resist me, Banu."
    b "Oh, Ali, you have no idea how much I've been looking forward to this."
    "Ali's eyes flickered with confusion, but the lust in his gaze remained. He reached out to touch her, but Banu stepped back again, maintaining a careful distance."
    scene v21-20
    b "Not so fast. Let's enjoy this moment, shall we? After all, you always liked to take your time, didn't you?"
    b "You know, Ali, I've had a lot of time to think about you. About the things you said, the way you treated me and the others."
    b "You've always thought so highly of yourself, didn't you? Thought you were irresistible."
    scene v21-21
    play sound "voices/laugh.mp3"
    "Her hand moved lower, grazing his groin, and she let out a light, mocking laugh."
    b "Look at this... your grotesque, big dick."
    b "Did you think it would make you powerful? Make women want you?"
    ali "You... you know you want it, Banu."
    b "You disgust me, Ali. Every inch of you. And tonight, you'll understand what true powerlessness feels like."
    b "This is for every girl you harassed, every inappropriate proposal, and for thinking you could get away with it."
    ali "You'll pay for everything, Ali."
    "Her gaze flickered to the corner of the room, where she had earlier noticed a bat propped against the wall."
    scene black
    "An idea formed in her mind, and without breaking her menacing whisper, she released Ali and moved swiftly towards the bat."
    scene v21-22 with vpunch
    play sound "voices/manscream.mp3"
    "Before he could react, Banu swung the bat with all her might, landing a powerful hit on the back of Ali's head."
    scene v21-23
    "The force of the blow was so intense that Ali's eyes rolled back, and he immediately lost consciousness, collapsing to the floor with a heavy thud."
    scene v21-24 with fade
    "The room fell silent, save for the sound of Banu's heavy breathing."
    "She stood over Ali's prone form, the bat still clutched in her hands, her heart pounding with a mix of adrenaline and grim satisfaction. "
    "She watched as he lay there, completely unconscious and utterly vulnerable."
    scene v21-25
    b "This is what you deserve, Ali. For every girl you harassed, for every life you tried to ruin."
    b "This is just the beginning of your punishment."
    "She took a step back, her eyes never leaving Ali's lifeless form."
    "..."
    scene black with dissolve
    "After some time, Banu had meticulously tied Ali to the tall, big iron decoration in the corner of the room."
    scene v21-26 with dissolve
    stop music
    "She secured the ropes tightly around his belly, ensuring he was firmly bound to the iron."
    "His hands were tied behind his back, rendering him completely immobile."
    "Ali remained unconscious, his head hanging down."
    "The once powerful and arrogant man was now helpless and at Banu's mercy."
    scene v21-27 with fade
    "Suddenly, Banu entered the room completely naked, her body fully exposed, a champagne bottle in her hand. "
    b "Oh, Ali. Welcome back."
    "The light from the room glistened off her skin, highlighting her strong, athletic physique, perfectly shaved pussy and boobs. "
    "She stood tall and confident, her presence commanding the space."
    scene v21-28
    "As his vision cleared, he saw Banu standing before him, her naked form catching him off guard."
    "His eyes widened in shock and surprise, struggling to comprehend the situation."
    ali "B-Banu... what are you doing?"
    b "I thought we could celebrate your new... position."
    b "You always liked to be in control, didn't you, Ali?"
    b "Thought you could get away with everything. How does it feel now?"
    ali "Banu, please... let's talk about this. I-I can make it right."
    b "Make it right? You think you can fix everything with words? No, Ali. Tonight, you pay for everything you've done."
    scene v21-29 with fade
    "She picked up the bat again, feeling its weight in her hands."
    "With slow, deliberate steps, she walked toward Ali, her eyes never leaving his."
    ali "Untie me right now, bitch! You can't do this!"
    b "You think you can order me around? You think you can scare me?"
    ali "Let me go! Do you know who I am? You'll regret this!"
    b "I know exactly who you are, Ali. And I don't care about your threats. Tonight, you face the consequences of your actions."
    "She stepped back, lifting the bat, her muscles tensing with the effort. Ali's eyes followed the movement, pure terror etched on his face."
    scene v21-30 with hpunch
    play sound "voices/manscream.mp3"
    ali "Ahhhhhhhhh..."
    "Banu swung the bat with all her might, aiming for his left thigh. The bat connected with a sickening thud, the force of the blow reverberating through the room."
    "Ali's scream was immediate and blood-curdling, his face contorted in agony as the pain shot through his leg."
    b "Talking is over, Ali. This is for all the girls you tormented."
    scene v21-31 with hpunch
    play sound "voices/manscream.mp3"
    ali "AHHHHH...."
    "With the same force as before, Banu swung the bat down onto his right thigh."
    "Ali's scream was ear-piercing, echoing through the room as he convulsed in agony. "
    "The pain was unbearable, and he screamed the hell out of his lungs, his voice raw and desperate."
    ali "Please... Banu... I'm sorry... I'm so sorry...I'll eat your shit...please.."
    b "Sorry isn't enough. You'll pay for every moment of suffering you've caused."
    "She raised the bat again, this time aiming for his exposed, flabby belly. Ali's eyes widened in terror as he saw the bat lift, but he was powerless to stop it. "
    scene v21-32 with hpunch
    play sound "voices/manscream.mp3"
    ali "Arrggggxxxxxx...."
    "With all the strength she could muster, Banu swung the bat down hard, landing a powerful strike right in the center of his gut."
    "He lost control completely, and as the bat collided with his belly, all the contents of his stomach surged up his throat."
    scene v21-33
    "He vomited uncontrollably, the sickening sound filling the room as he doubled over in his restraints, his body wracked with convulsions."
    "Banu stepped back, avoiding his vomit, her expression unchanging as she watched him retch and choke."
    "The scene was grotesque, but she felt no pity. Instead, she felt a dark sense of justice being served."
    b "This is what you deserve, Ali. For every disgusting thing you've done."
    scene v21-34 with hpunch
    "She wasn't done yet. Lifting the bat again, she aimed for his head this time."
    "Ali's eyes rolled back, and he immediately lost consciousness, his body going limp as he hung from his restraints."
    b "This is only the beginning, Ali. You'll pay for every life you've tried to ruin."
    scene black with dissolve
    "After delivering the brutal final blow to Ali's head, Banu took a step back, surveying the damage she had inflicted."
    "His entire body was covered in bruises, dark and swollen from the relentless assault."
    scene v21-35 with dissolve
    "Feeling a sense of grim satisfaction, Banu walked over to the sofa and sat down. "
    "She pulled out a cigarette, lighting it with a steady hand."
    "She took a deep drag from the cigarette, exhaling slowly as she leaned back, her eyes never leaving Ali's battered form."
    "The smoke curled around her, adding to the atmosphere of the room."
    b "You got what you deserved, Ali. And this is just the beginning."
    scene v21-36
    ali "B-Banu... please... have mercy..."
    b "Mercy? Did you show any mercy to the girls you harassed? Did you think about mercy when you made their lives hell?"
    ali "I'm... I'm sorry... I won't do it again... please, just let me go..."
    b "Look at you, Ali. The big man with such a big dick, begging for mercy. How ironic."
    scene v21-37 with fade
    b "You thought you could do whatever you wanted because of what you have between your legs? "
    b "But look at you now. Begging for mercy from a woman you thought you could control."
    b "Men like you think your size gives you power, but it doesn't."
    scene v21-38
    b "It just makes you a bigger target for justice. And justice is what you're getting tonight."
    ali "I... I'm sorry... please, just let me go..."
    ali "Banu... please... I'll do anything... I'll eat your shit... just please, let me go..."
    b "You'll eat my shit? Is that how low you've fallen, Ali?"
    ali "Yes... anything... please..."
    scene v21-39
    b "Tell me, what would you do if you could free yourself from those ties? Hmm?"
    b "Would you try to hurt me? Would you run away like the coward you are?"
    b "So, Ali, if you could break free, what would you do?"
    ali "..."
    b "You'd fuck me, is that it? Is that what you think?"
    b "Tell me, how badly do you want to fuck me right now?"
    b "Is that what you're thinking? That if you could just break free, you'd have your way with me?"
    b "You'd put that big dick deep inside of my tight pussy? Destroy my body, right? Is that what you think?"
    b "Alright, Ali. I'll make you a deal. I'll untie you from the iron, but your hands will stay tied behind your back."
    b "You'll wash my pussy with your mouth."
    ali "Yes, yes, anything you want."
    "Banu approached him, her movements slow and deliberate. She reached around him, untying the ropes that bound him to the iron structure."
    scene v21-40 with fade
    "Banu leaned back on the sofa, spreading her legs wide with a commanding presence."
    "Ali knelt before her, his hands still securely tied behind his back, his face a mix of fear and desperation."
    b "Look at you, Ali. On your knees, begging for a taste. I never thought I'd see the day."
    ali "Please, Banu..."
    b "Is this what you dreamed about, Ali? Being at my mercy, forced to please me? You're pathetic. You know that, right?"
    scene v21-41
    ali "Yes, Banu... please, just let me..."
    b "Go on, then. Show me how badly you want it."
    b "Maybe if you do a good job, I'll consider showing you a bit of mercy."
    scene v21-42
    play music "audio/tension.mp3"
    "As Ali inched closer to Banu's spread legs, his face filled with desperation and humiliation, Banu's gaze locked onto his."
    b "Look at you, Ali. The big man who thought he could have any woman he wanted. Now you're on your knees, begging to please me. How pathetic."
    ali "Please, Banu... I just want to make it right..."
    b "Make it right? You think licking my pussy will make up for everything you've done? You're even more pathetic than I thought."
    b "You don't deserve mercy, Ali. You deserve to suffer, just like all the girls you hurt. But go ahead, try to please me. Maybe I'll enjoy watching you degrade yourself."
    scene v21-43
    "As Ali's tongue began to tentatively lick Banu's pussy, she couldn't help but feel a wave of excitement course through her body. "
    "It had been years since she had felt the touch of a man, and despite the circumstances, her body reacted to the sensation. "
    scene v21-44
    play music2 "voices/softmoan.mp3"
    b "Ahhhhh..."
    "She looked down at him with a mixture of disdain and hidden desire."
    b "You think this will make up for everything you've done? Pathetic. "
    b "You don't deserve to touch me. But... don't stop."
    "Despite her harsh words, Banu's body betrayed her, responding eagerly to Ali's movements."
    "She felt a thrill run through her, a mix of power and unexpected pleasure."
    scene v21-45
    "She could feel the pleasure building, and despite her efforts to remain detached, she couldn't deny how much she was enjoying it."
    b "You're nothing but a tool, Ali. Just... keep going."
    "Deep down, Banu was conflicted. The pleasure was undeniable, and the thrill of having him at her mercy added to the intensity."
    scene v21-46
    "She bit her lip, trying to suppress a moan, her fingers tightening in his hair as she guided him."
    b "Don't... stop..."
    "The room was filled with the sound of her heavy breathing and the wet noises of Ali's efforts. "
    "Banu's mind raced, torn between her need for control and the overwhelming pleasure. "
    "She had intended this to be a punishment, but now she was finding herself lost in the moment, her body betraying her resolve."
    menu:
        "Stop him":
            $ banustopali = True
            $ renpy.block_rollback()
            scene v21-47 with fade
            stop music
            stop music2
            "Banu, feeling the growing intensity of the moment and the conflict within herself, suddenly found a surge of strength."
            "She couldn't let herself be taken over by the pleasure, not when she had a mission to fulfill."
            "With a firm resolve, she abruptly pushed Ali's head away and stood up from the sofa."
            ali "Banu... what...?"
            b "I have a surprise for you, Ali. Stay right there."
            scene v21-48 with fade
            ali "Banu, please... what are you going to do?"
            "She walked across the room with deliberate, confident strides, heading towards the champagne bottle she had set aside earlier."
            "She turned back to Ali, who was still bent over the sofa, his body tense and trembling. Banu approached him slowly, the bottle held firmly behind her."
            b "You know, Ali, you always thought you were the one in control. Always thought you could do whatever you wanted without facing any consequences."
            scene v21-49
            b "How does it feel now, being so completely powerless?"
            b "Do you know what I'm going to do now with the champagne bottle in my hand?"
            "Ali's voice was barely a whisper, filled with desperation."
            ali "Please, Banu... don't..."
            b "Oh, but this is exactly what you deserve, Ali. You thought you could treat women like objects, like they were there for your pleasure."
            b "Now it's your turn to feel what it's like."
            scene v21-50 with vpunch
            play sound "voices/manscream2.mp3"
            ali "AHHHHHHHH....shit..."
            b "Do you feel that? The cold? The fear? This is just the beginning. You're going to remember this for the rest of your miserable life."
            "And with that, she began to push the champagne bottle into him, savoring every moment of his discomfort and fear."
            scene v21-51
            "Ali's cry of pain and humiliation filled the room, but Banu's expression remained cold and resolute. "
            "She began to push the bottle deeper in his ass with her foot, tearing his ass apart and making him scream."
            b "This is what you deserve, Ali. Feel the pain, feel the humiliation."
            ali "Please, Banu, stop! I can't take it!"
            scene v21-52
            b "You didn’t stop when they begged, did you? Now, you get to experience what real fear and pain feel like."
            "She continued to push the bottle, ignoring his screams and focusing on the task at hand."
            "Each cry from Ali only seemed to strengthen her resolve, reinforcing her sense of justice being served."
            b "Remember this moment, Ali. This is what happens when you hurt others."
            scene black with dissolve
            "After some time, Banu took a step back, surveying the scene with cold satisfaction."
            "She lay Ali on the floor, his body bound with tight ropes that secured his legs, thighs, and upper body."
            scene v21-53 with dissolve
            "His back was arched upward, and the champagne bottle remained lodged painfully in his ass."
            "Banu knelt beside him, tightening the ropes to ensure there was no chance of escape."
            "Each knot was tied with precision, her movements deliberate and unyielding. Ali’s groans of pain and humiliation filled the room, but she paid them no mind."
            scene v21-54
            b "You thought you could get away with everything, didn’t you? Now you know what real powerlessness feels like."
            "Ali’s face was a mask of agony, his body shaking as he tried to endure the torment."
            ali "Please, Banu... no more..."
            b "You know, Ali, I always thought you'd end up with something stuck up your ass, but I never imagined it would be a champagne bottle. Quite fitting, don't you think?"
            ali "Please, Banu... stop..."
            b "Oh, come on, Ali. You always liked the finer things in life, didn't you? Expensive suits, fancy cars, and now a premium champagne bottle as your new accessory. "
            b "Quite the upgrade, if you ask me."
            b "I bet you never thought you'd be in this position, did you? Helpless, with a bottle shoved up your ass. But then again, you've always been full of shit."
            scene v21-55 with fade
            play sound "voices/manscream3.mp3"
            "With a cold, calculating look, she grabbed the rope attached to his feet and began to pull."
            "Slowly but surely, she hoisted him off the ground, his body swinging slightly as he was lifted into the air. The ropes tightened around him, securing his position as he hung upside down from the ceiling."
            ali "No, Banu! Please, stop! I can't take this!"
            scene v21-56 with fade
            b "Look at you, Ali. Hanging there like a piece of meat. Quite the change from your usual self, don’t you think?"
            "Ali's face was red with pain and humiliation, his tears flowing freely as he hung there, completely powerless."
            b "How does it feel to be on the receiving end, Ali?"
            b "You wanted control, Ali. You wanted power. Well, here it is. Enjoy every moment."
            scene v21-57
            ali "Please...let me down..."
            b "You know, Ali, I never thought I'd see the day when you'd be hanging around like this. Literally."
            b "Don't go anywhere, Ali. I'll be back to check on you later."
            b "In the meantime, try not to get too... tied up in your thoughts."
            "With that, she turned and walked away, leaving him to dangle from the ceiling, her laughter lingering in the air as a final, mocking note."
        "Let him continue":






            $ banustopali = False
            $ renpy.block_rollback()
            scene v21-58 with fade
            "Ali's tongue worked with an intensity and skill that quickly overwhelmed her senses."
            "As he licked and sucked, Banu's body betrayed her. She tried to maintain her composure, to keep the upper hand, but the pleasure was too intense."
            "Ali's tongue moved like an animal's, relentless and wild, and Banu could feel herself losing control."
            b "Ali... stop... I..."
            "But her words trailed off into a moan as Ali continued his assault, his movements growing even more frantic and eager."
            b "Oh god... Ali... please..."
            "Ali's only response was to intensify his efforts, his tongue delving deeper, his lips working furiously. "
            b "You....you're an asshole...ahhhh..."
            "She couldn't stop him, couldn't find the strength to push him away."
            b "You...you are such an evil man...oh..."
            b "Ali... oh god... I'm..."
            scene v21-59
            "As his tongue continued its relentless assault, she failed to notice him subtly working his wrists, gradually loosening the rope that bound his hands."
            "Finally, with a surge of effort, he broke free."
            "Ali's hands were now free, but he kept them still for a moment, continuing to please Banu with his mouth, ensuring she remained in her state of rapture."
            b "Ali... don't stop... oh god..."
            scene v21-60 with vpunch
            stop music2
            "Ali, seizing the moment, suddenly stood up, his hands moving to grab Banu by the neck. He started choking her, his grip tight and forceful."
            b "Oh... what are you...?"
            "For a moment, Banu's eyes widened in panic as she struggled to breathe."
            "But then, driven by a surge of adrenaline and determination, she mustered all her strength and managed to twist out of his grasp."
            scene v21-61 with fade
            "As she broke free, the force of her escape caused her hijab to be left behind on the sofa, falling in a heap."
            "Banu stumbled back, gasping for air, her eyes blazing with a mix of fear and fury. She knew she had to act quickly."
            b "You won't get away with this, Ali."
            "She was completely naked, her hijab left on the sofa. "
            scene v21-62
            "Ali, now also completely naked, stood with his big dick rock hard, pointing upwards."
            "Despite the seriousness of the situation, a twisted grin spread across his face, and he let out a mocking laugh."
            ali "Look at you, Banu. All tough and defiant, but completely exposed. You think you can scare me like this?"
            "Banu's eyes narrowed, the laughter only fueling her resolve. She ignored the feeling of vulnerability that came with her nudity and focused on the threat in front of her."
            scene v21-63
            b "You think you can get away with everything you've done? You're going to pay, Ali. You're going to suffer just like you made others suffer."
            ali "Pay? Suffer? Look at you, Banu. You think you can scare me with your empty threats? You're just a woman who's all bark and no bite."
            b "You don't know what I'm capable of, Ali. You've underestimated me all along. But you'll see. "
            ali "Regret? Please, Banu. You think you have the upper hand? You're just a joke. A weak, pathetic joke. You won't do anything. You don't have it in you."
            b "Keep laughing, Ali. Keep mocking me. But remember this moment when you're begging for mercy. Because there won't be any."
            scene v21-64
            "Banu's gaze drifted down, catching sight of Ali's huge, rock-hard cock. The size and the unexpected arousal threw her off balance."
            "Her mind, sharp and focused a moment ago, now struggled to process the overwhelming sight before her."
            "Her breath hitched, and for a moment, she couldn't think straight."
            "Ali seized the moment of Banu's distraction."
            scene v21-65 with vpunch
            play sound "voices/fastmoan2.mp3"
            "With a burst of energy fueled by desperation and a cruel determination, he lunged forward and delivered a powerful punch to her stomach."
            "The impact was brutal, and Banu felt a shockwave of pain radiate through her entire body."
            scene v21-66
            "Her breath left her in a ragged gasp, and for a moment, it felt like all her internal organs had been violently displaced."
            "Banu's knees buckled, and she collapsed to the floor, clutching her midsection as she tried to process the sudden, excruciating pain."
            scene v21-67 with hpunch
            "The room seemed to spin around her, her senses overwhelmed by the intensity of the blow."
            "Ali, sensing his advantage, stood over her, a twisted smile of satisfaction on his face."
            ali "Did you really think you could take me down, Banu? You're just as weak as I always knew you were."
            b "This... isn't over...."
            "Ali laughed, a harsh, mocking sound that echoed through the room. He leaned down, his face close to hers, his expression filled with contempt."
            ali "Oh, but it is, Banu. You had your chance, and you failed. Now, you're going to suffer for thinking you could challenge me."
            b "You...you are not a real man, Ali. You'll never be."
            "Ali's face twisted with rage at her words. "
            scene v21-68 with fade
            stop music
            "Without a second thought, he dropped down and wrapped his hands around her neck, squeezing tightly."
            "Banu's eyes widened as she felt the pressure on her throat, her air supply cut off."
            ali "I'll show you who's a real man, Banu. I'll show you just how strong I am."
            "Banu's hands instinctively flew up to his wrists, trying to pry his fingers away, but his grip was like iron."
            "She struggled beneath him, her vision starting to blur as the lack of oxygen took its toll. Her mind raced, desperately searching for a way out of this."
            scene v21-69 with fade
            "Ali, still seething with rage, suddenly grabbed Banu and forced her into a missionary position on the floor. "
            b "Ali...you...you can't do this..."
            "He pressed his fat cock against her wet pussy, his weight pinning her down. Banu's eyes widened in panic as she struggled against him, her mind racing for a way to escape."
            b "Ali, stop! Get off me!"
            "Ali's face twisted with a cruel smile, ignoring her pleas as he positioned himself over her. Banu's heart pounded in her chest, fear and anger mixing in a chaotic whirlwind."
            ali "You're going to remember every inch of my cock, bitch."
            scene v21-70 with vpunch
            play sound "voices/fastmoan2.mp3"
            b "AHHHHHHHHHH........"
            "As soon as Banu felt his fat dick deep inside of her pussy, she lost her mind."
            "It's been more than a year that her body had been craving for a man's touch."
            "Feeling a strong man's dick inside of her, she couldn't fight anymore and let herself go."
            "Ali started to pound her body relentlessly."
            scene v21-71
            "Ali's dick was so fat and large. It felt like as if he pierced through her body as her pussy had became tighter."
            ali "You think you can stand up to me, bitch? I can see how you melt with my dick inside of you."
            b "Ahhhhhhh...Ali...."
            ali "You can't talk. You're getting weaker as I push deeper inside of you."
            ali "Your body gave up already. Now I'm going to destroy your body...make you feel like a real woman."
            ali "I'll literally fuck your brains out."
            show alifucksbanumissionary
            play music2 "voices/slapmoanfast.mp3"
            b "Ahhhhhhh....fuck....shit.....ahhhhhh..."
            ali "Deep down, you know you're powerless. You just want to be fucked like a whore, don't you."
            b "Ohhhhh....yesss.....fuckkkk...."
            ali "You're so weak, Banu. Look at you. Desperate for a good fuck."
            ali "I bet your husband had a small dick. Leaving such a lewd pussy like this, unsatisfied."
            b "Ahhhhhh...fuck....stop....you....ashhole...."
            ali "Look how you are sweating...I bet you never had a sweaty sex like this before."
            b "Asshole....shut up....fuck...fuck me..."
            ali "Such a tight pussy..."
            ali "I'm going to spoil you..."
            b "Ahhhhh...."
            ali "I'm going to break you..."
            b "Shit....I'm gonna cummmm....."
            ali "You're going to learn what a real man's cock feels like."
            show alifucksbanumissionary_2
            b "Ohhhhhhhhhh...."
            ali "Go ahead, cum on my fat dick."
            b "Shit.....I'm cummingggg.....I'm cumminnggggg....ahhhhhhh..."
            ali "Take this...bitch..."
            ali "Take all of me...you hungry bitch..."
            b "Ohhh...please...stop....already..."
            ali "Oh no..you made me crazy...now your pussy will pay for it..."
            ali "I'm gonna break it..."
            b "Ahhhh....slowly...please..."
            ali "I've always wanted to fuck this body...When you walked around at work....bent over....It drove me crazy..."
            ali "I've always wanted you to be mine....my bitch...take this..."
            b "Fuck....I'm gonna cum again...asshole....don't stop..."
            b "Ahhhhh....don't dare to stop....AHHHHH....FUCK ME......ohhhhh shit..."
            ali "Damn...you needed this, bitch..."
            ali "Now it's my turn..."
            stop music2
            scene v21-72 with vpunch
            ali "Ohhhh...shit..."
            ali "Take this..."
            ali "Take a shower with my cum..."
            scene v21-73
            ali "What a hole..."
            ali "You took all my cum from my back, bitch. Are you happy now?"
            ali "You have such a bad pussy...such a horny pussy..."
            scene v21-74 with fade
            b_ "And this was how I ended up in front of him."
            b_ "Such an evil man...I tried to win...but I couldn't. "
            b_ "My body betrayed me. I felt weak in front of such a powerful man and he took the opportunity. "
            b_ "He just used my body to pleasure himself."
            b_ "He fucked me for hours and came all over my body."
            scene v21-75 with fade
            b_ "And I was just laying there with no intention to move."
            b_ "It was after a long time my body was really satisfied."
            b_ "I felt a strong man's power over my body....it made me so weak..."
            b_ "He didn't just fuck me that night...."
            scene v21-76
            b_ "He dirtied my body...my soul...."
            b_ "He pissed on my face..."
            scene v21-77
            ali "Hey, what? You don't want to take a shower? This is free, hehe."
            b_ "And I couldn't say a single word..."
            b_ "Instead, I waited for him to finish...to finish washing me..."
            scene v21-78
            b_ "He made me feel weak and powerless. I felt all my muscles lose its strength."
            b_ "I was completely and utterly defeated by him."
            b_ "He took my strength, my confidence, my sense of self. I became a shadow of the person I once was."






    $ renpy.end_replay()
    $ persistent.ali_fuck_banu_unlocked = True
    jump ali_fuck_banu_continue
















label turan_banu_power:





    play music "audio/suspense.mp3"


    scene v21-79 with pixellate
    "Banu took a deep breath and opened the door to Turan's apartment, steeling herself for the confrontation ahead."
    "As she stepped inside, her eyes widened in shock and disbelief. There was Turan, lounging on the sofa, naked except for a pair of boxers."
    scene v21-81 with fade
    t "Well, well, well, Banu. What a pleasant surprise. To what do I owe this visit?"
    scene v21-80
    b_ "Oh, for the love of... Is he serious?"
    b_ "Disgusting. This just confirms everything I knew about him. Arrogant, sleazy, and completely full of himself."
    b_ "I came here prepared for a fight, and this is what I have to deal with?"
    b_ "Focus, Banu. Don't let his ridiculousness distract you from what you came here to do. You've faced worse."
    b_ "This is just another obstacle to overcome. And honestly, seeing him like this just makes it easier to do what I have to do."
    b "Hello, Turan. I thought it was time we had a little... chat."
    scene v21-81
    t "By all means, come in. Make yourself comfortable."
    "Banu walked into the apartment, taking a quick look around. "
    scene v21-82 with fade
    "Banu took a deep breath, forcing herself to maintain her composure as Turan stood up and approached her."
    "Her eyes involuntarily flicked down to the bulge in his boxers, and she felt a surge of disgust and anger. "
    "She reminded herself of her goal and quickly decided to change tactics. She needed to get close to him to execute her plan, but first, she had to play along."
    b_ "Stay calm, Banu. You need to get close to him. Just pretend. Make him believe you want this. This is the only way to catch him off guard."
    "Banu forced a seductive smile onto her face, hoping it looked convincing enough."
    t "Well, well, Banu. I didn't expect this from you. Have you finally come to your senses?"
    scene v21-84
    b "You know, Turan, I've been thinking about you a lot lately. Maybe... I was too harsh before."
    scene v21-83
    t "I knew you couldn't resist me. You always wanted this, didn't you?"
    scene v21-84
    b "Maybe you're right. Maybe this is what I need."
    b "You know, Turan, I've thought about this moment for a long time."
    scene v21-83
    t "Have you now? Tell me, Banu, what exactly have you been thinking about?"
    scene v21-84
    b "I've been thinking about how you made me feel, all those times you looked at me, the way you talked to me. It drove me wild."


    if banuturansexfirsttime == True:

        scene v21-83
        t "last time we met, things didn't exactly end on a friendly note. You expect me to just forget that?"
        b "I'm here, aren't I? Showing you I'm willing to forget and move forward. Maybe we could both use a little... closure."
        t "Closure, huh? And I'm just supposed to trust you now, after you stabbed me?"
        b "Turan, I really regret how things went down. Let's not ruin a chance to make things right between us."
        b "Maybe we were both not ourselves. Let's try to enjoy tonight, just let go of the past."


    scene v21-84
    b "You know, I've really missed these little chats of ours, the tension... it's exciting, isn't it?"
    scene v21-83
    t "Is that so? You have a funny way of showing affection, Banu."
    b "Maybe I do, but we all have our quirks, don't we? Besides, I think there's something quite... electric between us. Don't you feel it?"
    t "Maybe... It’s hard to ignore when you’re this close."
    b "Let's not fight what's natural, Turan. I can see it in your eyes, you want this as much as I do. Why keep resisting?"
    b "Take me to your special room."
    t "Well, let's not waste time then..."
    scene v21-85 with fade
    t "Follow me then. I promise you won’t be disappointed."
    "Turan turned his back to her, confidently striding towards his bedroom, unaware of the true nature of Banu’s intentions. "
    "Her eyes briefly glanced at the small bag she carried, inconspicuous yet laden with a heavy metal object intended for landing on Turan's head."
    "She lifted her bag, preparing to bring it down with all her might."
    scene v21-86 with hpunch
    play music "audio/tension.mp3"
    "However, just as she swung, Turan abruptly bent forward."
    "The bag whooshed through the air, missing him entirely and striking against the door frame with a thud."
    scene v21-87 with fade
    "Banu, recovering from her swing and the shock of missing, steadied herself, her eyes narrowing as she adopted a defensive stance."
    "The bag had flown from her grasp during the attempted strike, landing a few feet away."
    b "I should have done this a long time ago. I’m going to beat the shit out of you. No more games."
    t "You think you can take me on, Banu? I'll show you what it means to mess with me. I’ll break you."
    b "I'm not afraid of you anymore, Turan. I’ve been through hell and back, and you’re just another monster in my way. It’s time to put you in your place."
    scene v21-88
    t "Big words for someone who just missed a pretty big shot. Let’s see if your fight is as big as your bark."
    b "I’m not just talking. I’m going to make you regret ever crossing me."
    t "You’ll have to be quick, Banu. But no matter what you do, you’re in my world now."
    menu:
        "Kick his face":
            $ banukickturanface = True
            $ renpy.block_rollback()
            scene v21-89 with vpunch
            play sound "voices/manscream.mp3"
            stop music
            "Banu waited for the perfect moment to strike. She noticed Turan's slight drop in guard as he taunted her, perhaps too confident in his physical superiority."
            "With a quick pivot, she raised her leg high, her high heel aiming straight for Turan's face. "
            "The move was unexpected and executed with precision. Her skirt flared briefly with the force of her kick, but her focus was sharp—only on her target."
            scene v21-90
            "The heel of her shoe connected with Turan's jaw with a resounding thud. The impact was so forceful that Turan's eyes rolled back as he was immediately knocked out cold. "
            "His body went limp, and he crumpled to the floor in a heap, unconscious before he even fully hit the ground."
            b "You’re nothing but trash."
            scene v21-91 with hpunch
            "Unable to contain her fury, she decided to make sure he wouldn't get up anytime soon."
            "She raised her leg again and delivered another powerful kick to Turan's face. The impact was brutal, causing his face to swell and bruise immediately, turning black and blue."
            b "This is for every moment you made me feel powerless."
            "She continued to kick his face several times."
            b "I should piss on your face for everything you've done. That’s all you deserve."
            b "You disgusting piece of garbage. Take this!"
            scene v21-92 with fade
            "Banu stood tall, her chest heaving as she caught her breath. She looked down at Turan's unconscious body, his face now swollen and bruised from her powerful kicks. "
            "The years of torment and fear had culminated in this moment, and she felt a profound sense of liberation and empowerment wash over her."
            scene v21-93
            b "This is where it ends, Turan. You will never have power over me or anyone else again."
            "She wiped the sweat from her brow, her hands trembling slightly from the adrenaline still coursing through her veins."
            "The sight of Turan lying there, defeated and broken, was a stark reminder of the strength she had found within herself."
            b "I am stronger than you ever imagined. You thought you could break me, but you only made me stronger."
            scene black with dissolve
            "The rush of adrenaline began to subside, replaced by a cold clarity. She felt a powerful mix of emotions—anger, satisfaction, and an insatiable desire for justice."
            "She knew that what she had done so far was just the beginning of ensuring he would never harm anyone again."
            "She paced the room, her mind racing with the realization that leaving him unconscious and bruised wasn't enough to satisfy her sense of justice. "
            "She needed to ensure that Turan paid for his actions in a way that was both profound and irreversible."
            scene v21-94 with dissolve
            "Turan slowly opened his eyes, blinking away the haze of unconsciousness."
            "As his vision cleared, he realized he was standing completely naked in his bedroom, his wrists handcuffed to the light metal fixtures on the wall."
            "His gaze shifted, and he saw Banu approaching him with a determined, almost serene expression on her face."
            scene v21-95
            t "What the hell are you doing? Let me go!"
            b "No, Turan. This is the end of your reign of terror. You’re going to understand what it's like to feel powerless, just like all the people you've hurt."
            t "You don’t have to do this. I’ll do anything you want. Just let me go!"
            b "Anything I want? What I want is for you to understand the pain and fear you’ve caused others."
            b "For years, you made me feel like I was nothing. You made so many others feel the same way."
            scene v21-96
            t "You think you're so powerful now, don't you, Banu? You're just a cuck-hungry whore. You've always been pathetic, and this doesn't change anything!"
            "Banu paused, her expression hardening as Turan's words hit the air."
            b "Your words don’t affect me anymore, Turan. You can call me whatever you want, but it doesn’t change the fact that you’re the one who’s powerless now."
            t "You think this makes you strong? You're nothing but a coward. A real woman wouldn't need to resort to this!"
            t "Even now your pussy is dripping wet from just thinking about my cock."
            t "Just let me free and I'll show you how a real man fucks a pussy."
            t "If you let me free, Banu, I'll fuck the shit out of you. I'll show you what it feels like to be a real woman."
            t "No matter what you do, you'll end up sucking my cock on your knees."
            scene v21-97
            b "Do you really think I'm one of your whores, Turan? Do you think I’ll just bend to your will because you bark a few disgusting orders?"
            "Turan's eyes blazed with anger, but he could do nothing but struggle uselessly against his restraints. Banu took a step closer, her voice dripping with contempt."
            b "You’re pathetic. You’ve spent your life trying to control and degrade women, thinking you could break us."
            b "But look at you now. Powerless, helpless, and at my mercy."
            b "I’ve taken back my power, and there's nothing you can do about it."
            b "The days of you using and abusing women are over, Turan. You’re going to face the consequences of your actions."
            scene v21-98 with fade
            "Banu looked down at Turan, her eyes narrowing as she noticed his exposed, aroused state. She couldn’t help but feel a twisted satisfaction in the irony of the situation."
            b "Well, well, Turan. Even in your most desperate moment, you’re still all about your pathetic little ego. Well...okay, it isn't so little."
            b "Look at you—hanging here, restrained, and still thinking you’re somehow in control."
            b "Is this really what you wanted, Turan? To have power over me? And now, here you are, reduced to nothing more than a display of your own pathetic desires."
            b "It’s almost amusing, isn’t it? You’re nothing more than a pitiful display of your own inadequacy."
            b "You’ve spent your life using that thing as a weapon, thinking it gave you power. But look at you now. Strung up like a piece of meat, and all your bravado is gone."
            t "You like what you see, Banu? Bet you can't keep your eyes off my big cock. Maybe that's why you’re really here."
            b "You really think that pathetic attempt at bravado is going to work on me? Your big cock is just as useless as you are right now."
            b "You think you’re in control, Turan? Let’s test that. I bet as soon as I take off my skirt, your dick will point straight up, betraying just how weak you really are."
            scene v21-99 with fade
            "As the situation escalated, Banu decided to use Turan's own arrogance against him."
            "She looked at him with a calculated expression, deciding to take a different approach to demonstrate her power over him."
            scene v21-100 with fade
            "Turan’s eyes widened in surprise and a flicker of shock crossed his face."
            "He tried to maintain his sneering demeanor, but it was clear he was taken aback by her boldness."
            b "What’s the matter, Turan? Speechless?"
            "The sight of Banu standing confidently in front of him, unashamed and powerful, left him momentarily speechless."
            t "You… you think this means anything?"
            scene v21-101
            b "You’ll remember this moment for the rest of your life, Turan. The moment you realized you had no power over me."
            b "Look at my pussy, Turan. This is what you’ll never get. Do you see how pathetic you are now?"
            b "Does it make you angry, Turan? Knowing that no matter how much you wanted to dominate me, it’s you who’s weak and powerless?"
            t "You won’t get away with this, Banu."
            b "This is the end for you. The beginning of your downfall."
            b "Look at you, Turan. Your dick is so hard, it looks like it's going to explode. Pathetic. Even now, you can't hide your true nature."
            scene v21-102 with fade
            t "Shut up, Banu. Let my hands free."
            b "Does it frustrate you, Turan? Knowing that you’re at my mercy, that I hold all the power now? "
            b "Your big, hard cock is just a symbol of how weak you truly are."
            scene v21-103
            b "Look at this, Turan. Your big, hard cock, standing at attention like it's about to explode."
            b "You always thought this gave you power over me and others, didn’t you? You thought you could use it to dominate and control."
            b "Look at your cock, Turan. So big and veiny, yet here you are, completely powerless. "
            scene v21-104 with fade
            play music "audio/heatedsex.mp3"
            "Banu felt a surge of power and determination. She decided to take her revenge a step further, to strip Turan of every last shred of his pride and dignity. "
            "She wanted him to feel utterly defeated before she sends him to hell. "
            "With a smirk, she turned her back to him and slowly bent over, her ass directly in front of his fully erect cock."
            "She began to tease him, moving her hips provocatively and brushing her ass against him."
            show banuteaseturandickwithherass
            play music2 "voices/softmoan.mp3"
            t "Banu, stop this. You don't know what you're doing."
            b "Oh, I know exactly what I'm doing. I'm making sure you understand how powerless you truly are."
            b "Is this what you wanted, Turan? To be so close and yet completely powerless? Do you want to put it in?"
            "Turan's eyes widened, and despite his anger and humiliation, a moan escaped his lips. "
            "He tried to maintain his composure, but the physical sensation combined with Banu's taunting words was too much for him to handle."
            t "Banu... please..."
            b "Look at you, reduced to begging. You're pathetic, Turan."
            t "Ohhhh....shit..."
            b "Do you want me, Turan? Do you want to put it in? Too bad you'll never get the chance. "
            t "Ohhhh...shit, stop it..."
            stop music2
            scene v21-105 with fade
            "She moved closer to him, her eyes locking onto his with a mix of contempt and cold satisfaction."
            "With deliberate slowness, she positioned herself so that his erect cock was between her legs, brushing against her pussy."
            "She moved subtly, letting the sensation drive him mad with desire and frustration."
            show banuteaseturandickwithherpussy
            play music2 "voices/softmoan.mp3"
            t "Ohhhhh, shit...I'm going to fuck you..."
            b "Is this what you wanted, Turan? To be so close, yet completely out of control?"
            t "Banu... please... you're driving me crazy..."
            b "You want it so bad, don’t you? But you’ll never have it."
            b "You’re nothing but a pathetic man, reduced to begging for something you’ll never get."
            b "Do you see now, Turan? This is what true power looks like. You’re nothing without your control, and now, you have none."
            t "Ohhhh...God..."
            b "Remember this moment, Turan. Remember how it feels to be utterly powerless, to be teased and denied."
            stop music2
            scene v21-106 with fade
            "Banu looked into Turan's eyes, seeing the mix of desperation and rage there. She decided to drive him further into madness."
            "With a sudden, unexpected move, she dropped to her knees in front of him, her eyes never leaving his."
            b "Did you ever imagine this, Turan? Me, on my knees in front of you."
            b "Do you want me to suck your cock, Turan? Is that what you’re hoping for?"
            b "Maybe I should give it a try."
            t "Yes, please..."
            b "You want me to suck your cock, Turan? Is that it?"
            scene v21-107
            t "Banu, please..."
            b "Please what? You need to be clearer, Turan. Do you want me to suck your cock?"
            "Turan hesitated, but the intensity of his arousal and the need to regain some control pushed him over the edge."
            t "Yes, Banu. Please... suck my cock."
            b "Louder. I want to hear you beg properly."
            t "Please, Banu. Give pleasure to my pathetic cock."
            b "That’s more like it."
            scene v21-108
            stop music
            b "But here’s the thing, Turan....."
            b "You don’t deserve it."
            t "What?!"
            scene v21-108 with vpunch
            play sound "voices/manscream2.mp3"
            t "Arrrrgggggggg.....shit.....what the...."
            scene v21-109
            t "AAAAAHHHH! YOU BITCH!"
            "She opened her mouth and bit down hard on the tip of his cock."
            scene v21-110
            b "That's for every woman you've hurt, every life you've tried to ruin."
            "As Banu bit down hard on the tip of Turan's cock, the excruciating pain shot through his body, and he let out an ear-piercing scream that echoed through the room."
            t "AAAAAHHHH! STOP! PLEASE! IT HURTS! AAAAAHHH!"
            "The sheer intensity of his screams filled the space, a raw expression of his pain and desperation."
            "His body convulsed with the pain, and he pulled frantically at his restraints, but there was no escape."
            t "NO! PLEASE, Banu! STOP! IT'S TOO MUCH! AAAAAHHHH!"
            b "What, you can't take this huh?"
            t "Please... please... stop... no more..."
            scene v21-111
            t "AAAAAHHHH! ...SHIT....YOU BITCH!"
            "Banu started to bite the shaft of his thick cock, her teeth almost penetrating to his meat, causing his hard screaming."
            t "STOP! PLEASE! AAAAAHHHHH!"
            scene v21-112
            "The bite was not just painful but also humiliating."
            "The knowledge that he was utterly helpless, subjected to such intense suffering at the hands of someone he had tried to dominate, only deepened his sense of despair."
            t "MAKE IT STOP! PLEASE! AAAAAHHHHH!"
            "The pain was relentless, a burning, tearing sensation that consumed his entire being."
            t "STOP! PLEASE! "
            scene v21-113
            play sound "voices/manscream3.mp3"
            t "AAAAAHHHH! "
            "The scream tore from his throat, raw and primal, filled with a mix of terror and unbearable pain."
            "His vision blurred with tears, and his screams grew more desperate, a cacophony of anguish and hopelessness. "
            t "YOU BITCH....YOU SUCH A BITCH.....AHHHHH..."
            scene v21-114
            "She looked up at him from her kneeling position, a playful and mocking smile spreading across her face. "
            "The contrast between her calm demeanor and his agonized screams was striking, highlighting the complete shift in power between them."
            b "What's the matter, Turan? Can't handle a little pain?"
            b "You always thought you were so powerful, didn't you?"
            t "Banu... please..."
            scene v21-115
            "Banu watched Turan's face contort with pain and humiliation. His cock was now red and swollen from her vicious bite."
            b "Look at you, Turan. Your big, powerful cock is nothing but a pathetic, red mess now. Does it hurt? I bet it does."
            b "I hope you feel every bit of this pain, Turan."
            t "Banu... please..."
            b "Please? You think begging will help you now?"
            scene v21-116 with hpunch
            play sound "voices/manscream2.mp3"
            t "AHHHHHHH.....GOD....."
            "With a swift movement, she reached out and grabbed his balls, squeezing them hard before delivering a powerful punch."
            "Turan's eyes widened in sheer agony, and a blood-curdling scream erupted from his throat."
            t "AAAAAHHHH! STOP! PLEASE!"
            "His body convulsed with the intensity of the pain, every nerve in his lower body on fire."
            scene v21-117 with vpunch
            "With a swift, calculated movement, she drove her knee hard into his balls. The impact was brutal, and the effect immediate."
            play sound "voices/manscream2.mp3"
            t "AAAAAHHHH! NOOOO! PLEASE, STOP!"
            "His body convulsed violently, and he tried to curl up against the restraints, but there was no escape from the excruciating pain. "
            b "Feel that pain, Turan. Remember it."
            scene v21-118
            "Banu looked into Turan's eyes, now wide and bulging from the excruciating pain."
            "His face was a mask of agony, and his moans were raw and desperate. "
            "She leaned in close, her expression cold and resolute, and whispered bitter words that cut deeper than any physical pain."
            b "Look at you, Turan. All your power, all your control—gone. You're nothing but a pathetic, broken man. Feel that pain. Let it burn into your memory."
            b "This is the price you pay for all the pain you've caused, for every life you tried to ruin. "
            scene v21-119 with fade
            "After a few minutes, Turan's state had deteriorated further."
            "The intense pain in his groin forced him to instinctively cross his legs in a futile attempt to alleviate the agony."
            "His body hung limply from the handcuffs, which dug into his wrists, adding to his suffering."
            scene v21-120
            "His face was a portrait of utter defeat. "
            "His eyes, which had once been filled with arrogance and cruelty, were now wide and glassy, reflecting a mix of agony, humiliation, and despair."
            "His once-confident posture was gone, replaced by a broken, defeated stance."
            "His shoulders slumped, and his head hung low, chin resting on his chest."
            "As he tried to comprehend his suffering, he saw something that sent a fresh wave of terror through him."
            scene v21-121 with fade
            "Banu stood in front of him, her expression cold and resolute. In her hand, she held a gun, its barrel pointed directly at him."
            "The sight of the weapon was shocking, adding a new layer of fear to his already tormented mind."
            t "Banu...what are you doing?"
            scene v21-122
            b "You deserve this, Turan. For everything you've done, for every life you've tried to ruin. This is the end for you."
            "He tried to speak, to plead for his life, but the words wouldn't come. All he could do was stare at the gun, paralyzed by fear and pain."
            t "No... please... I..."
            "Banu took a deep breath, her finger tightening on the trigger. "
            t "Banu, please... don't do this. I'm begging you. I know I've done terrible things, but I can change. Just give me a chance. Please."
            t "I know I don't deserve mercy, but I swear, I can make things right. I can help people, I can... I can do anything you want. Just don't kill me. Please."
            t "I swear it. I swear on everything I have left. I'll never hurt anyone again. Just give me this one chance. Please, Banu. I'm begging you."
            b "Goodbye, Turan."
            scene v21-123 with vpunch
            play sound "voices/bullet.mp3"
            t "AAAAAHHHH! NO! PLEASE!"
            "She pulled the trigger, and the gunshot echoed through the room."
            "The bullet struck Turan in his upper left chest, and he let out a guttural scream as the impact jolted his body."
            "Blood began to flow from the wound, trickling down his chest and soaking his skin."
            b "It's over, Turan."
            scene v21-124 with vpunch
            play sound "voices/bullet.mp3"
            "The gunshot rang out, sharp and decisive. The bullet struck Turan's forehead, and he went unconscious instantly, his body jerking slightly before going completely limp."
            "Blood began to pour from the wound, running down his face and mingling with the tears and sweat that already coated his skin."
            "The room was silent except for the soft, persistent sound of blood dripping onto the floor."
            scene v21-125 with fade
            "Banu stood there, staring at the lifeless body hanging from the handcuffs, her expression a mix of relief and somber realization."
            b "It's over."
        "Kick his leg":






            $ banukickturanface = False
            $ renpy.block_rollback()
            scene v21-126 with hpunch
            "She aimed a powerful kick at Turan's leg, intending to destabilize him."
            "However, she underestimated his strength. Turan’s leg was like a pillar, solid and unyielding."
            t "Is that the best you can do, Banu? That was pathetic. I barely felt it."
            scene v21-127
            "Banu’s eyes widened in shock. She had put all her strength into that kick, hoping to knock him off balance, but it was as if she had kicked a brick wall."
            "Her mind raced, trying to quickly reassess her strategy."
            t "You really thought you could hurt me with that? You're out of your league."
            b_ "I can't rely on brute force alone. I need to be smarter, more strategic."
            scene v21-128 with hpunch
            play sound "voices/fastmoan1.mp3"
            b "Ahhhhh..."
            "Turan, with a burst of unexpected strength and speed, grabbed her head and pulled her into a tight hold, trapping her head between his powerful armpit and arm."
            "His grip was like a vice, and he began to squeeze hard, cutting off her air and pinning her in place."
            b "Let... go..."
            t "You thought you could beat me? How naive."
            scene v21-129 with vpunch
            b "Ahhhhh....Get off me!"
            t "Not so tough now, are you? You should have known better than to challenge me."
            "Banu's mind raced. She had to find a way out, but Turan's weight and strength were formidable."
            "She tried to twist her body, attempting to find any leverage, but he held her firmly in place."
            t "Maybe now you'll learn your place."
            scene v21-130
            "Banu's world narrowed to a tunnel of darkness."
            "Her body went limp as the last of her strength ebbed away, and her consciousness faded. "
            "The last thing she heard was the sound of her own heartbeat, slowing down, before everything went black."
            "Turan felt Banu go limp in his hands and released his grip, letting her body collapse to the floor. "
            scene black with dissolve
            stop music
            "Banu slowly regained consciousness after long darkness, her surroundings coming into blurry focus."
            "Her head throbbed, and her throat felt sore from Turan's brutal attack. "
            scene v21-131 with dissolve
            "As her vision cleared, she realized she was no longer in the living room. She found herself in a different, unfamiliar setting."
            "The room was bathed in a strange red glow, emanating from a round red light fixture on the ceiling. "
            b "Where... where am I?"
            scene v21-132 with fade
            play music "audio/action.mp3"
            "Her eyes widened in shock and fear as she took in her surroundings. "
            "The room was large, with red walls and a black ceiling, casting an ominous atmosphere."
            "In the center of the room was a bed, and she realized with growing horror that she was tied to it, completely naked and restrained."
            "She struggled against the restraints, but they held firm. Panic surged through her as she heard footsteps approaching."
            "Turning her head, she saw Turan, also completely naked, walking towards her with a malicious grin on his face."
            "His eyes gleamed with a twisted sense of satisfaction as he closed the distance between them."
            scene v21-133
            "As Banu tried to shout, she realized with a jolt of horror that there was a ball gag in her mouth, muffling her voice and preventing her from speaking clearly."
            "She struggled harder against the restraints, but they held her firmly in place."
            "Turan's grin widened as he saw the fear and frustration in her eyes. "
            scene v21-134 with fade
            "She looked down in horror to see that her breasts were tightly bound with ropes, squeezing them so hard that they felt like they were going to explode."
            "The pain was excruciating, and it momentarily took her breath away."
            "Banu’s breasts throbbed painfully from the ordeal, the intense pressure of the ropes leaving her chest sore and bruised."
            scene v21-135 with fade
            "As Banu struggled against her restraints on the bed, she suddenly felt an intense, pulsing sensation deep inside her. "
            "To her shock and horror, she realized that a large vibrator had been inserted into her pussy."
            t "Feeling a little distracted, Banu? You're not getting away this time."
            scene v21-136
            "She turned her head to see Turan standing near the bed."
            "He held the remote controller of the vibrator in his hand, a sadistic grin spreading across his face as he watched her writhing in agony and pleasure."
            t "Enjoying yourself, Banu? You look like you're having quite a time."
            scene v21-137
            t "You know, I could watch you like this all day. Helpless, at my mercy. But I'm curious, Banu. How long can you hold out before you break?"
            t "You're nothing but a scared little girl playing hero. "
            t "Do you really think anyone will believe you? They'll see you as the crazy one."
            t "You can't even speak to defend yourself. Pathetic."
            t "You're still the same weak, pathetic woman I've always known. You can’t escape what you really are, Banu."
            scene v21-138
            "She couldn’t speak due to the ball gag in her mouth, but she refused to show any sign of weakness."
            "Instead, she put on a tough expression, her eyes burning with defiance and readiness for a fight."
            t "Oh, I see you're still trying to fight. How amusing."
            scene v21-139
            "She couldn’t speak, but her eyes told him everything he needed to know: she was not defeated."
            t "Let's see how long you last."
            "With a sadistic grin, Turan pressed the button on the remote, increasing the intensity of the vibrator to its maximum setting."
            "The sudden surge of pleasure was overwhelming, and Banu's body convulsed uncontrollably."
            scene v21-140
            "She bit down hard on the ball gag, her muffled cries of anguish filling the room."
            "Her mind became a haze of pain and pleasure, the relentless vibrations pushing her to the brink. "
            "She tried to maintain her focus, but it was impossible; her body was betraying her, succumbing to the powerful device inside her."
            scene v21-141
            t "Look at you, Banu. So strong, so defiant. And now, you're just a trembling mess."
            "Banu's eyes were wide with a mix of desperation and anguish. Her attempts to fight back were becoming weaker as the vibrator drove her to the edge. "
            "She could barely think straight, let alone plan an escape. Turan's mocking words cut through the fog of her mind, amplifying her despair."
            scene v21-142
            "You really thought you could win? You're nothing without your defiance. Just a broken woman, lost in her own misery."
            "She wanted to scream, to shout back at him, but the ball gag in her mouth muffled her cries, reducing them to helpless, muted whimpers."
            "Do you feel that, Banu? That's the feeling of defeat. You can’t escape it, just like you can’t escape me."
            t "This is where you belong, Banu. Under my control, broken and helpless."
            "The pleasure was unbearable, breaking her mind and spirit. She felt utterly powerless, trapped in a cycle of relentless stimulation and Turan's cruel taunts."
            "Saliva began to run down from the ball gag to her chin. "
            scene v21-143
            t "Well, well, Banu. Have you had enough?"
            "Turan suddenly turned the vibrator off. "
            "Before she could fully comprehend what was happening, Turan removed the ball gag from her mouth, allowing her to gasp for air."
            "Banu’s breath came in ragged gasps as she slowly came back to her senses."
            "Her body was weak, but her spirit burned with defiance and anger. She glared at Turan, her eyes filled with hatred."
            scene v21-144
            b "You... you think you've broken me? You're wrong, Turan. I'm still standing."
            "Turan laughed, a cold, mocking sound that echoed in the room."
            t "Still defiant, I see. But look at you. You're nothing but a quivering mess. What makes you think you can win this?"
            b "Because I'm not afraid of you anymore. You can hurt me, you can try to break me, but you will never control me."
            t "You always were a stubborn one. But your stubbornness will be your downfall. No one is coming to save you. You're alone, Banu."
            b "You..."
            scene v21-145
            play sound "voices/vibration.mp3"
            stop music
            "Turan suddenly pressed the button on the remote, turning the vibrator back on to its highest setting."
            "The powerful vibrations surged through her body, and she immediately felt herself losing control."
            b "You... you bastard..."
            t "That's right, Banu. You can't resist it, can you? No matter how strong you think you are."
            t "You can try to fight it all you want, but in the end, you'll always lose. "
            b "Please... Turan... stop... I can't take it...Ahhhhhh... please..."
            t "What's that, Banu? Begging for mercy now? I thought you were stronger than this."
            b "Ahhhhhh.....God....."
            scene v21-146 with fade
            b "Please... ah... stop... can't... ahhh... no more..."
            "As the vibrator's relentless intensity pushed Banu to the brink of her sanity, she began to lose control."
            "The stimulation was too overwhelming, and her mind could no longer form coherent thoughts."
            "Her words turned into a series of unintelligible sounds, mixed with desperate moans."
            "Turan watched her with a twisted sense of satisfaction, his eyes gleaming with cruel delight. Seeing her so broken and helpless only fueled his sadistic pleasure."
            t "Look at you, Banu. So strong, yet so easily broken. What a pathetic sight."
            play sound "voices/vibration.mp3"
            b "No... please... ahhh..."
            "But Turan didn't immediately turn it off. Instead, he toyed with the device, adjusting the intensity slightly, watching her reaction."
            "Banu's eyes rolled back, and her moans grew louder, her mind barely clinging to reality."
            t "Beg harder, Banu. Maybe then I'll consider stopping."
            play sound "voices/fastmoan1.mp3"
            b "Please... stop... can't... take... ahhh..."
            b "Please... Turan... stop... I'm begging you..."
            t "That's more like it."
            scene v21-147 with dissolve
            "He slowly and cruelly pulled the huge vibrator out of her pussy."
            "She felt a mixture of immense relief and residual throbbing, her body completely spent."
            "Banu's eyes fluttered shut, her breath coming in ragged gasps. Her body was broken, her spirit battered, but the torment had finally stopped."
            "She lay there, feeling the lingering effects of the vibrator's assault, unable to move or speak."
            t "Look at you, Banu. All that defiance, all that strength, and now you're just a pathetic mess. Did you really think you could stand up to me?"
            b "Your mother...You son of a bitch...That whore must be so proud... of the monster she raised."
            t "What did you say?"
            scene v21-148 with hpunch
            t "You dare speak about my mother, you worthless bitch!"
            b "Ahhh! Stop... "
            t "You think you can insult me and get away with it? You think you're strong? Look at you now, completely broken."
            "He grabbed her breasts, squeezing and pulling her nipples apart with a brutal force."
            "She tried to breathe through the pain, focusing on staying conscious."
            b "You're... the one... who's weak..."
            t "You'll regret ever crossing me, Banu. This is far from over."
            b "You can't break me, Turan. No matter what you do."
            t "We will see who breaks in the end."
            scene v21-149 with fade
            "Turan's eyes blazed with fury at her words. He released her nipples, leaving them throbbing with pain, and moved down her body."
            "His anger twisted into a cruel smirk as he positioned himself, placing his big cock against her pussy and rubbing it slowly, tauntingly."
            b "Ahhhhh....you'll never win...."
            t "Keep telling yourself that. You're already trembling beneath me. It's only a matter of time."
            scene v21-150
            t "You're just a plaything, Banu. Something for me to enjoy breaking."
            b "You... will never... own me."
            t "You see, Banu? It's pointless to resist. You're nothing but a plaything now. How does it feel to be so powerless?"
            b "I... I won't let you... break me..."
            t "Oh, but you will. Everyone has a breaking point. You're no different. I can feel your body betraying you already."
            b "I... I'm stronger... than you think..."
            t "Stronger? Look at you. You're trembling, Banu. Your body is already responding to me. You can't hide it."
            t "You are nothing but a hole right now."
            scene v21-151
            b "No... I won't let you... do this..."
            b "You... you can't take away... who I am..."
            b "I... am... stronger... than you..."
            t "You are nothing but a whore, Banu. Just accept this."
            t "Right now, yo want my cock more than anything else in this world."
            b "No...."
            scene v21-152 with hpunch
            play sound "voices/fastmoan1.mp3"
            b "AHHHHHHH....."
            "The relentless rubbing of his cock against her pussy had already weakened her resolve."
            "With a cruel grin, Turan positioned himself and, without warning, thrust his cock deep into Banu's pussy."
            "The sudden, overwhelming sensation was too much for her to bear. All at once, her body convulsed, and she felt herself breaking."
            b "Ahhhhh....No... no... please..."
            b "Please... stop... I can't... take it..."
            t "Begging already? I thought you were stronger than this. You're just proving me right, Banu. You're weak."
            b "Please... I'm begging you... stop..."
            t "That's right. Beg for it. Show me how weak you really are."
            show turanbangbanuhandslocked
            play music2 "voices/slapmoanmedium.mp3"
            b "Ohhhhh...shit...you're breaking me...ahhh"
            t "Fuck, this pussy is the best..."
            t "You have such a tight pussy..."
            t "But I can reshape this slut pussy for you..."
            b "God....your cock....it's so big....ahhhh.."
            t "You are desperate for a good fuck..."
            t "You think you can defeat me huh?"
            t "With this lewd, horny body..."
            t "Pathetic."
            b "Ahhhh...stop it...ahhh...you are so deep..."
            t "Accept your defeat."
            b "No... I won't let you..."
            b "Ahhhhhh..."
            b "Don't go deep..."
            t "There it is. The fight is gone. Just accept it."
            b "I'm... defeated..."
            b "Please... don't go deep inside..."
            b "You are destroying my insides...you are reaching so deep..."
            t "You think you can make demands? You're in no position to tell me what to do."
            stop music2
            scene black with dissolve
            "Turan fucked Banu for hours until she lost all her strength and gave up on resisting."
            scene v21-153 with dissolve
            play sound "voices/fastmoan1.mp3"
            b "Ahhhhhhhh....."
            b "I... I can't fight anymore... I give up... You win."
            t "That's more like it, Banu. You've finally realized your place."
            b "Please... just let it end..."
            t "Well, gladly, Banu. "
            t "I'll gladly finish it inside of you."
            scene v21-154 with hpunch
            play sound "voices/fastmoan1.mp3"
            b "Ahhhh..."
            t "Ohhhhh....shit....here it goes..."
            "She felt a deep sense of lust and despair wash over her. "
            "She already came multiple times on Turan's cock and her body lost its power."
            "Turan released a huge load outside and inside of her cumming pussy."
            "Her body ached, and her spirit felt broken beyond repair. "
            t "You'll carry my child, Banu. There's no escaping it."
            b "Never... I will never carry your child."
            scene v21-155
            t "We'll see about that. You can deny it all you want, but you belong to me now."
            b "You... you will never break me completely."
            "Turan's cruel grin lingered as he leaned in and slowly began removing restraints from Banu's wrists."
            "The ropes had left red, angry marks on her skin. As the restraints fell away, he moved to untie the ropes binding her breasts, which had caused her so much pleasure and pain."
            scene v21-156 with fade
            "Banu felt a mixture of relief and exhaustion as the pressure on her chest was finally released."
            "Her body, unable to support itself any longer, collapsed onto the bed."
            "She lay there, her breaths coming in shallow gasps, her body trembling from the ordeal."
            scene v21-157
            "Her body was a complete mess with Turan's cum running down her pussy hole."
            t "See? You can't even stand on your own now."
            "Banu's eyes fluttered shut, her body too weak to respond. "
            scene v21-158
            t "You thought you could resist me? Thought you were stronger? What happened, Banu?"
            "She lay there, her eyes half-closed, but a flicker of defiance still burned within her. "
            t "What's the matter? No more brave words? No more fighting spirit?"
            scene v21-159
            t "You belong to me now, Banu. Don't ever forget that."
            t "Why are you looking at me like that?"
            t "You want to kill me, don't you."
            t "You still think you have any power here, Banu? You're nothing but a broken toy."
            b "You'll pay for what you've done."
            t "Dream all you want, Banu. But remember, you're under my control now."
            scene v21-160 with vpunch
            t "Ohhhh...shit...you are crazy."
            "As Turan finished his last mocking words, a surge of adrenaline coursed through Banu's body."
            "Summoning every ounce of strength she had left, she suddenly sprang up and threw herself on top of him."
            "Before Turan could react, Banu's hands were around his throat, squeezing with all the power she could muster."
            b "This ends now, Turan. You will never hurt me or anyone else again."
            b "You thought you had broken me, but you were wrong!"
            t "Is that all you've got, Banu? You call this a choke? Pathetic."
            "Banu's hands trembled as she continued to choke him, but she could feel her grip weakening. "
            t "You can't even choke me properly. You're even weaker than I thought."
            scene v21-161
            "Turan reached up and easily pried her hands from his throat, his expression shifting to one of cruel amusement."
            "With a swift motion, Turan pushed Banu off him, sending her sprawling onto the bed. "
            scene v21-162 with vpunch
            b "Ahhhh..."
            "He got on top of her, pinning her down with his weight."
            "Banu's heart raced as she felt his overpowering presence."
            "Her eyes rolled back again as she felt his fat cock inside of her weak pussy again."
            "Her body betrayed her. She knew that this time there was no escape from this powerful passion and lust."
            show turanbangbanuhandslocked_2
            play music2 "voices/slapmoanfast.mp3"
            b "Ohhh... yes, yes, yes... ah, God, I can’t... so, so good..."
            t "You like that? You like how hard I'm giving it to you?"
            b "Ahhh... ohhh, yes, yes... deeper, please, ohhh... don’t stop, don’t—ahhh..."
            t "You’re so incredibly tight... feel every part of you..."
            b "Yes! Ohhh,... more... please, more... ah, love... oh, so—ahhh!"
            b "I’m—I’m... oh! Turan! Ahhh—coming! I’m going to—ohhh!"
            t "Banu... I’m... too..."
            stop music2




            scene v21-163 with fade
            "Turan, noticing her resignation, smirked triumphantly. He could feel her body enjoying his cock, acknowledging her defeat."
            t "That's right, Banu. Just accept it. There's no point in fighting anymore."
            "Banu's mind drifted as her body succumbed to the inevitable. "
            "She let her body go limp, conserving her energy for the moment when she would have the opportunity to fight back."
            b_ "This isn't the end. I will find a way out. I will make him pay."









    $ renpy.end_replay()
    $ persistent.turan_banu_power_unlocked = True
    jump turan_banu_power_continue













label banu_revenge:





    "A few days had passed since the horrific events at Kamil's house, and Banu found herself restless and unable to stay at home. "
    "She couldn't let go of the need for justice, especially for her daughter, Leyla."
    "Leyla had fallen victim to a dangerous, tattooed young man named Maga."
    "He ran with a bad crew—a group of men who took illegal drugs and preyed on innocent girls, destroying their lives."
    scene v21-186 with dissolve
    play music "audio/action.mp3"
    "Banu knew this man was responsible for the downward spiral that had claimed her daughter's innocence and future."
    "Determined to find him, Banu wandered the city streets at night, searching for any sign of him."
    scene v21-187 with fade
    "As Banu stood in the shadows of a rundown building, she saw him coming from a distance."
    "Banu's heart pounded as she recognized his disgusting face, filled with the memories of pain he had caused to so many young girls."
    "She knew she had to be smart about this. She couldn't confront him directly in the open; she needed to lure him into a trap."
    "Taking a deep breath, she adjusted her appearance to look like a street whore, hoping to catch his attention."
    scene v21-188 with fade
    b "Hey there, handsome. Looking for a good time?"
    m "Well, what do we have here? You out here all alone, sweetheart?"
    b "Just waiting for the right company. You seem like a fun guy. Interested?"
    scene v21-189
    m "A girl in a hijab working the streets? That's a first. What's your story?"
    b "It's just a disguise. Helps me avoid trouble, you know? Keeps things interesting."
    m "Listen, I've got to go. My guys are waiting for me. Maybe another time."
    b "Oh, come on. Don't go just yet. I promise it'll be worth your time. "
    scene v21-191 with fade
    b "Besides, you look like a man who enjoys a bit of adventure."
    b "I'll give you the best moments of your life that you'll never forget."
    "Banu knew she needed to keep Maga's interest and lower his guard even further. She took a deep breath, her eyes locking onto his as she moved closer."
    "With a calculated move, she raised her knee and gently caressed his crotch, feeling his hard, thick cock through his pants."
    scene v21-192
    b "You know, Maga, I've never felt something so... impressive. You've got quite a weapon there."
    m "How do you know my name?"
    b "I've heard a lot about you, Maga. People talk, you know. They say you’re a man who likes to have a good time."
    b "You know, Maga, I think you're just the kind of man I've been looking for."
    scene v21-190
    m "Oh yeah? What makes you say that?"
    b "Because I've heard you're not afraid to take risks, to explore new things. I like that in a man."
    m "Well, you're not wrong. I do enjoy a bit of adventure."
    b "Come with me, and I'll show you an adventure you won't forget."
    scene v21-193 with fade
    m "Where are you taking me, beautiful?"
    b "You'll see. It's a special place, just for us."
    b "You know, Maga, there's something about you that's different from other men."
    m "Oh? And what's that?"
    b "You have a dangerous edge. It's thrilling."
    m "I guess you could say that. I like to live on the edge."
    b "Good. Because what I have planned is definitely for a man who likes to live dangerously."
    "They continued through the labyrinth of buildings, Banu expertly guiding Maga towards a secluded spot she had chosen."
    "Along the way, they continued their flirtatious banter, each word and touch designed to keep him off guard."
    scene v21-194 with fade
    b "Finally, we are here."
    m "What is this place?"
    "The walls were lined with various weapons and gadgets made of iron, giving the place a menacing, almost nightmarish feel."
    "Banu didn't respond immediately, letting the suspense build as they walked deeper into the room. "
    scene v21-195
    "Maga's eyes widened in shock as he took in the sight. "
    "The room was filled with an array of disturbing tools and weapons, their iron surfaces gleaming menacingly in the red light."
    m "What the hell is this place?"
    scene v21-196
    b "This is where I bring men who think they know everything. Men who need to learn a lesson."
    m "You seem to be a funny type. So, what's the lesson here, Banu?"
    b "Just be patient. You'll learn it soon."
    m "Look, I'm bored of this fucking game. The guys are probably waiting for me, so I'm leavi----"
    scene v21-197 with hpunch
    stop music
    m "Holy shit..."
    b "Patience, Maga. Good things come to those who wait."
    b "Do you like what you see, Maga?"
    show banumagashowupdown
    play music "audio/sexy.mp3"
    "Banu's body was a masterpiece of strength and beauty."
    "Her fit, toned muscles rippled under her smooth, taut skin, evidence of her disciplined training and physical prowess."
    "Her shoulders were broad and strong, leading down to arms that were lean yet powerful."
    "Her breasts were full and firm, the skin flawless and inviting."
    "Her nipples peeking out, hardening slightly in the cool air of the room. "
    "The straps around her lower body framed her bare pussy, the soft, delicate skin there contrasting with the strength and definition of the rest of her body."
    scene v21-198 with fade
    b "Do you like what you see, Maga?"
    "Maga could only nod, his voice caught in his throat as he took in the sight of her. "
    "Banu smiled, knowing that she had him right where she wanted him, her every move designed to draw him deeper into her web."
    "Banu moved gracefully around Maga, her fingers lightly trailing over the spikes of his motorcycle jacket."
    scene v21-199
    "The touch was both teasing and provocative, designed to keep his attention completely on her."
    "Maga watched her intently, his eyes filled with a mix of curiosity and desire."
    b "You know, Maga, there's something about you that's so... sexy."
    m "I could say the same about you, Banu."
    b "Let's see what you're hiding under this tough exterior."
    scene v21-200 with fade
    "As she peeled it away, it revealed his heavily tattooed skin, each inked design telling a story of his life and experiences."
    "Banu let the jacket fall to the floor, her eyes roaming appreciatively over his bare chest and arms."
    b "Impressive. You wear your stories on your skin."
    m "There's a lot more to me than just these tattoos."
    b "I'm sure there is. "
    scene v21-201
    "She looked dead into his eyes, her face just inches away from his. Her breath mingled with his, her eyes blazing with a mixture of seduction and defiance."
    b "I can see it in your eyes, Maga. How badly you want me. How badly you want my pussy."
    m "You have no idea how much I want you, Banu."
    b "You want to destroy me, don't you?"
    m "I... I just want you."
    b "Do you think you can handle it? Do you think you can handle me?"
    m "I know I can."
    scene v21-202
    b "Do you think you deserve it, Maga? After everything you've done?"
    m "I just know I want you."
    b "Wanting isn’t the same as deserving, Maga."
    m "Damn, bitch. You are a crazy bitch and I like that."
    m "You’re driving me crazy."
    b "Good. Because that's exactly what you did to all those girls. Drove them crazy. Made them feel powerless."
    "Maga leaned in, trying to capture her lips with his, but Banu deftly moved her head to the side, evading his kiss."
    scene v21-203 with fade
    b "Not yet, Maga. You haven’t earned it."
    m "What do I have to do to earn it, then?"
    b "You’ll find out soon enough."
    b "You like this, don't you, Maga? Feeling my hands on your body, wondering what I'll do next."
    scene v21-204
    stop music
    m "Damn, I want you right now. I don't have patience anymore."
    b "Tell me, Maga. How badly do you want me?"
    m "More than anything. "
    b "I can feel how much you want me. But you have to understand something, Maga."
    b "You can't always get what you want. Sometimes, you have to pay for it."
    m "I'll do anything."
    b "I'm sorry but you don’t have anything to pay with, Maga, other than your life. "
    m "What?"
    scene v21-205 with vpunch
    "Before Maga could fully comprehend her words, Banu reached for a heavy iron chain she had concealed nearby."
    "With a swift and decisive movement, she looped the chain around his neck and began to squeeze with all her might. "
    m "B....Banu...what..."
    "The metal links bit into his skin, cutting off his air supply."
    scene v21-206
    b "This is for Leyla. For all the lives you destroyed."
    "Maga's eyes widened in shock and panic. He clawed at the chain, trying desperately to free himself, but Banu's grip was unrelenting. "
    scene v21-207
    "She poured every ounce of her strength into tightening the chain, her face set in a mask of grim determination."
    m "B-Banu... please..."
    "His voice was barely a whisper as he struggled to breathe. "
    "His eyes bulged, his face turning red, then purple, as the lack of oxygen took its toll."
    "Banu's muscles strained, her hands trembling from the effort, but she didn't relent."
    scene v21-208 with fade
    "His eyes rolled back in his head, and with a final, feeble gasp, he collapsed to the ground, unconscious. "
    "Banu held the chain tight for a few moments longer, ensuring that he was truly out before she finally released her grip."
    "As Banu stood over Maga's unconscious body, she felt a surge of power and determination. "
    scene v21-209
    b "This is only the beginning of your torture, Maga."
    b "You will learn what it means to suffer."
    b "When you wake up, you'll understand. Every moment of pain you inflicted will come back to you tenfold."
    scene black with dissolve
    "When Maga finally regained consciousness, he found himself in a strange, confined space."
    "His vision was blurry at first, but as it cleared, he realized he was inside a red glass vertical tube, just large enough to hold one person."
    scene v21-210 with dissolve
    "His hands were tied behind his back, and his legs were bound tightly with rope."
    "The air inside the tube was stifling, growing hotter by the second."
    "Panic set in as Maga's senses adjusted to the new environment. He struggled against his restraints, but they held firm."
    "The heat became more intense, and he began to sweat profusely."
    "It took him a moment to understand the full horror of his situation—this was a heat torture machine, designed to slowly cook him alive if he wasn't freed soon."
    scene v21-211 with fade
    "Banu had stripped him completely, removing his pants and exposing his cock so that he would feel the searing heat everywhere on his body."
    m "Banu! Release me! Let me out of here!"
    "His voice echoed inside the tube, but the thick glass muffled it, making his pleas sound distant and desperate."
    "The heat continued to rise, searing his skin and making it hard to breathe."
    "He looked around frantically, trying to find any means of escape, but there was none."
    b "Do you feel it, Maga? The helplessness? The fear? This is what you put those girls through."
    m "Please, Banu! Let me out! I'll do anything!"
    b "No, Maga, you need to understand the pain you caused."
    m "Are you out of your fucking mind? You want to fry me alive?"
    "The heat inside the tube became unbearable, and Maga's screams grew more desperate."
    "He struggled against his restraints, but it was futile. His skin felt like it was burning, the air too hot to breathe."
    m "I’m begging you, Banu! Please!"
    "As Banu stood outside the glass tube, listening to Maga's desperate pleas, a look of disgust crossed her face. "
    "His begging only fueled her resolve. She took a step back, shaking her head slowly."
    b "I don't like your begging, Maga. It isn't convincing."
    scene v21-212 with fade
    m "Hey, stop...wait..where the fuck are you going?"
    m "Hey, let me out of here!"
    "With that, she turned away from him and walked towards the far side of the room."
    "She sat down on the floor, leaning against the wall."
    "Calmly, she reached onto the table, took a cigarette, and lit it. "
    scene v21-213 with fade
    play sound "voices/manscream2.mp3"
    "Maga's screams grew more frantic, his voice hoarse from shouting."
    m "Banu! Please! Let me out! I'll do anything!"
    "The room was filled with the contrasting sounds of Banu's calm, steady breathing and the frantic, desperate screams of Maga. "
    b_ "This is for Leyla, and all the others."
    b "This is just the beginning, Maga. Your real punishment has only just begun."
    scene v21-214
    play sound "voices/manscream2.mp3"
    "As the heat inside the tube continued to rise, Maga's skin began to burn."
    "The searing pain became unbearable, and his screams grew more desperate and piercing."
    m "Banu! Please! I can't take it anymore! Let me out!"
    b "You’re feeling it now, aren’t you? The helplessness, the fear, the pain."
    m "Banu, please! I'm begging you!"
    scene v21-213
    b "This is what you made so many innocent girls go through, including my daughter."
    b "You think your begging will change anything? You never showed mercy to those girls. Why should I show any to you?"
    m "Please, Banu... mercy..."
    b "You know, Maga, I heard a joke the other day. Want to hear it?"
    m "Please... let me out...!"
    b "Listen. Why did the abusive man get stuck in the heat torture tube?"
    scene v21-214
    m "Please...Banu...fuck...please.."
    scene v21-213
    b "You want to know the answer? Because he wanted his sausage fried!"
    b "See, Maga? Even in your last moments, you get to enjoy a bit of humor."
    m "Banu... please... stop..."
    "His cries for mercy reached a fever pitch, and she finally decided to pull him out of the heat torture tube. "
    scene v21-215 with fade
    "She opened the tube and roughly dragged him out, his body weak and trembling."
    "Maga's body slumped in relief as the temperature dropped, his skin glistening with sweat."
    "He gasped for air, his strength nearly spent, but Banu was far from finished."
    scene v21-216
    "With his hands and legs still tied with ropes, Maga stood face to face with Banu, his eyes filled with a mixture of fear and anger."
    m "Thank you... thank you...."
    b "You think this is over, Maga? This is just the beginning."
    b "You begged for mercy, and I let you out. But don't think for a second that your suffering ends here."
    m "Look, just let me go. I'll forget this ever happened, I swear."
    b "You think you can just walk away and forget this?"
    b "And what makes you think I'd let you go after all you've done."
    m "Don't make the biggest mistake of your life."
    m "You think you've won? Let me go, or I swear, I'll kill you. You have no idea what I'm capable of."
    b "Kill me? You can't even save yourself right now, Maga. Do you really think I'm scared of your threats?"
    b "You're a snake, Maga. And what do we do with snakes? We cut off their heads before they have a chance to bite."
    m "You won't get away with this. They'll come for you."
    b "Let them come. I'm not hiding. I'm right here, dealing with the trash that no one else would touch."
    b "You're nothing, Maga, and I'm not bluffing about what I'm going to do to you."
    scene v21-217
    b "Look at you, all sweat and fear. Even this isn't as impressive as you thought, covered in sweat and trembling."
    b "Such a pity for this long big dick that you can't use it properly."
    b "I bet you thought you were invincible, walking around like you owned the world. And now, look at you—just another scared man, hoping for mercy."
    b "You're not so big now, are you? Not when you're the one who's afraid."
    m "You think you're better than me, you whore? Just wait! You'll get what's coming to you!"
    scene v21-218 with hpunch
    m "Agh!"
    "Without a word, Banu stepped swiftly toward Maga. Her foot swung out, connecting powerfully with his stomach. "
    "The force of her kick was fierce and precise, fueled by the anger his words had ignited."
    "The impact drove the breath from his lungs, and he doubled over, unable to maintain his balance. "
    scene v21-219 with fade
    "As Banu stood over Maga, her silhouette cast an imposing shadow over him."
    "Maga, fallen and vulnerable on the ground, looked up, his view dominated by Banu's powerful stance."
    "Despite his pain and the compromising position, he couldn't help but be acutely aware of her nice pussy and sexy tits."
    b "You're pathetic, Maga. A real piece of work, aren't you? You thought you were the big man, scaring those girls, using them. "
    scene v21-220
    b "All that swagger, all those threats, and for what? To end up whimpering at my feet? You’re a joke, Maga. A sick, twisted joke without a punchline."
    b "You’re nothing but a coward. A weak, spineless insect that I should squash right now."
    b "And you think you can threaten me? You can't even protect yourself. How are you going to kill me, Maga?"
    b "You can’t even move without whimpering like a beaten dog."
    b "You're worth less than the dirt under my feet, Maga. You've dirtied so many lives... it's time you felt truly debased."
    b "I'm going to piss on you, Maga. I'm going to dirty your body and soul, just like you did to so many others."
    m "No....no...what the..."
    scene v21-221 with fade
    b "Ohhhh...shit...what a relief..."
    m "No...fuck!...what the fuck is this....bitch..."
    "Maga's eyes widened in shock and horror as he realized she meant every word. "
    b "Now you're as filthy on the outside as you are inside."
    scene v21-222
    m "Ohh...God damn bitch...just let this end....fuck.."
    b "Oh sorry about that. I drank a lot of water this morning."
    b "Uhhh...what a relief."
    "She continued, the stream seemingly endless, covering him and soaking his skin. "
    "The smell of the liquid filled the air, adding another layer to his disgrace."
    scene v21-223 with fade
    "When she was done, Banu stepped back, looking down at him with a mixture of satisfaction and contempt."
    "As Maga lay drenched and humiliated, his initial shock transformed into seething anger."
    m "You filthy bitch! You'll pay for this! Do you hear me? You'll pay!"
    b "Swear all you want, Maga. It won’t clean you, and it won’t change your situation. It only proves how weak you really are."
    m "I'll get out of here, and when I do—"
    b "You'll do nothing. You’re not getting out. Not until I’ve decided you’ve paid in full."
    b "You’re not a man; you’re a worm. And what do we do with worms? We crush them underfoot. "
    menu:
        "Kill him":
            $ banukillmaga = True
            $ renpy.block_rollback()
            scene v21-224 with fade
            "She walked over to the table where various implements lay scattered, her hand resting on the handle of an axe."
            "She lifted the axe, the motion smooth and deliberate, and walked back to where Maga lay bound and helpless."
            "Standing over him, she raised the axe, its blade catching the light of the dim room, casting long shadows."

            b "Any last words, Maga? Words other than curses, perhaps a hint of regret?"
            m "Go to hell, Banu. You think you're justice? You're just a murderer. Do it. I'm not afraid of you or death!"
            b "So these are your last words?"
            m "Do you think you can kill me?"
            m "You are just a weak pathetic female who has no purpose in life."
            scene v21-225
            b "You piece of shit. I'll split your fucking head from your body right now and I mean it."
            m "You can't do shit, bitch. "
            m "Who do you think you are? If you do anything to me, they'll find you and make you pay."
            m "Now put that fucking axe down and untie me you fucking whore."
            b "Ahhh...that is enough!"
            scene black
            play sound "voices/manscream.mp3"
            m "Arrrggg...."
            "As Banu stood over Maga, her emotions overcame her restraint."
            scene v21-226 with dissolve
            b "You deserved this...fucking animal..you deserved this..."
            "With a swift, grim decision, she acted, the axe cutting through the air sent Maga's head away from his body."
            "Blood splattered, some droplets landing across Banu's face, marking her with a visceral reminder of the violent act."
            "The axe, once just a cold piece of metal, was now an extension of her rage, stained with blood and the irrevocable evidence of her decision."
            scene v21-227
            "As Banu processed the gravity of her actions, Maga's severed head lay unnervingly still, yet its eyes seemed to eerily meet hers one last time."
            "This look, lifeless yet almost accusing, made the room feel even more chilling."
            "It felt like those eyes were watching her, making her deeply uncomfortable and adding a surreal sense to the already heavy moment."
            "The only sound was Banu’s own breathing, which seemed too loud in the quiet room. She couldn’t help but stare back at the lifeless eyes that seemed to stare at her."
            "Staring at Maga's head and meeting those empty eyes felt like looking in a mirror that showed her a side of herself she couldn’t escape."
            "The blood on her face and the axe in her hand suddenly felt a lot heavier."
            "Banu was now alone with the reality of her actions, and the silence around her seemed to magnify the seriousness of the situation."
        "Torture him more":



            $ banukillmaga = False
            $ renpy.block_rollback()
            scene v21-228
            "As Banu stood over Maga, her rage momentarily cooled into a calculating mischief."
            b "You thought that was it? Oh, Maga, we're just getting started."
            m "What are you planning? You are definitely out of your mind. Untie the ropes now!"
            b "What’s wrong, Maga? Scared of what’s next?"
            b "You should be. Because I've got plans for you... plans that will make you wish I had ended it already."
            scene black with dissolve
            "She turned away from him briefly, walking over to a table."
            "As time passed, Maga's situation worsened significantly. "
            scene v21-229 with dissolve
            "He found himself bound tightly with rope, hanging from the ceiling upside down."
            "Blood rushed to his head, causing his vision to blur and his temples to throb painfully."
            "Banu stood in front of him, her posture relaxed yet commanding, observing Maga’s discomfort with a clinical detachment that made the scenario even more terrifying for him."
            b "Comfortable, Maga? I thought a change in perspective might do you some good."
            m "Heyy... this is too much...let me down now!"
            b "Look at you, Maga. Everything on display, isn't it? Even your dick seems to be dangling helplessly."
            scene v21-230
            b "Now, you're just a piece of meat hanging in a butcher's window. Not so powerful now, are you?"
            m "Banu, you won't get away with this..."
            b "I already am, Maga. And what can you do? Swing from your little rope?"
            b "You see, this is more than punishment. It’s poetic, really. You hung those girls out to dry with your actions, and here you are, literally hanging out to dry."
            b "You know, Maga, maybe there's a way you can earn a little mercy. Let's make a game of it, shall we?"
            show banuswingmagarope
            play sound "voices/manscream.mp3"
            "Banu gave his body a powerful push and she positioned herself so that with each swing, Maga’s face came perilously close to her pussy."
            m "Fuck...stop this..."
            b "If you can give me a kiss, right here on my pussy, maybe I’ll consider easing your punishment. You just have to kiss it good. Can you do that, Maga?"
            "Maga, disoriented and desperate, understood the humiliating challenge laid out before him. "
            b "Come on, Maga, you can do better than that. Show some enthusiasm!"
            b "Oh, so close! Try harder, Maga. Isn’t this what you always wanted? To be close to someone as powerful as you thought you were?"
            b "Looks like you’re not quite up to the task, are you? How disappointing."
            "Her words were like salt in a wound, reminding him of his vulnerability and her dominance."
            scene v21-230
            b "Enough games, Maga. Let's not pretend you ever had a chance at mercy. This was just a reminder of your place."
            m "Please...stop this God damn games..."
            b "You know, Maga, I’m getting bored of this little swinging game. It’s time for something... different."
            m "Let me down already."
            b "Of course..."
            scene v21-231 with vpunch
            m "Ahh! Banu! Please, stop this! Please, let me up....shit..."
            "After letting Maga down from hanging, Banu guides him, still disoriented and weak, to a chair designed to inflict pain. "
            "The chair, an ominous piece of equipment, is outfitted with sharp, little pointed irons on the seat and backrest."
            scene v21-232
            b "Have a seat, Maga. Let's make you a bit more... comfortable."
            m "I swear, bitch, I'll make you pay for this."
            b "Now, Maga, every time you move, it’s going to hurt. "
            "The sharp points press against his bare skin, penetrating slightly with his body weight."
            scene v21-233
            m "You goddamn monster! You think you’re tough, locking me up like this? I’ve been through worse than you!"
            b "Tough words, Maga. But words are all you have left now, aren’t they? Let’s see how tough you really are."
            b "I'll enjoy watching these irons destroy your ass."
            m "You ain’t breakin’ me, lady. I’ve survived the streets, I can survive your games!"
            b "This isn’t the streets, Maga. Here, you face real consequences, not just the scrapes you're used to. You're learning the hard way, just like your victims had to."
            scene v21-234
            "Maga’s expression suddenly shifted. Instead of grimacing, he cracked a slow, unsettling smile."
            "This unexpected reaction caught Banu off guard, her brow furrowing in confusion and a hint of concern."
            b "What's so funny? Planning on sharing the joke?"
            m "Looks like the game’s changed, hasn’t it? Told you, you couldn’t break me. I’ve always got a backup plan."
            m "Let’s see how you handle being outnumbered. Not so fun when you’re not the one holding all the cards, right?"
            scene v21-235 with fade
            "Banu, now realizing the tables could quickly turn, glanced between Maga and his arriving associates. "
            "Her strategic mind raced for options, knowing she needed to maintain control despite the unexpected twist."
            "In the tense atmosphere of the room, Maga's companions, Javid and Vusal, entered with confident strides."
            "Javid, the taller of the two, towered imposingly, his presence commanding attention."
            "Vusal, though shorter, carried a certain menace in his demeanor, suggesting that he was not to be underestimated."
            scene v21-236
            ja "What's going on here, Maga? This the lady causing you trouble?"
            m "Yeah, that's her. Banu, meet Javid and Vusal. My backup. They love to fuck."
            b "Watch your next moves, you’re stepping into a situation you don’t fully understand."
            vu "What’s there to understand? You’ve got our friend tied up and tortured. Not much to discuss."
            ja "Maybe it's time you learned a lesson."
            vu "Right, she needs to be fucked good to learn her place. "
            b "Threatening me isn't the way to get out of this. You're still being watched, and anything you do to me only ends worse for you. Think about what you're doing. "
            m "What’s the matter, Banu? Scared now that you’re not in control?"
            m "Let me tell you a secret. We'll ravage your body and fuck you until you can't walk."
            m "Come on guys, get her and untie me now."
            scene v21-237 with hpunch
            "In the heat of the moment, as the situation escalated and the threats became too much to bear, Banu decided to take matters into her own hands."
            "Before Vusal could react, she unleashed a powerful, precise kick aimed directly at his face."
            "The force of the blow sent him reeling backward, his head snapping back as the impact landed squarely on his jaw."
            b "I warned you not to underestimate me."
            "The room was filled with tension as Banu maintained her fighting stance, ready to defend herself against any further aggression."
            scene v21-238 with fade
            play sound "voices/fastmoan1.mp3"
            "As Banu dealt a powerful kick to Vusal, Javid took advantage of the brief moment of distraction. "
            "Before she could fully regain her balance, Javid swiftly moved in from behind, wrapping his strong arm around her neck in a chokehold."
            "Banu's eyes widened in surprise and anger as she felt the constricting pressure on her throat."
            ja "Thought you could take us both on, huh? Let’s see how tough you are now."
            b "You... won’t... get away with this!"
            scene v21-239 with fade
            "Javid held his grip on Banu, this time securing a firmer hold. His companion Vusal stood to the side, watching."
            "Maga, now free, was quick to join Javid, trying to overpower Banu with sheer numbers."
            vu "Stop messing around, Javid! Let’s just tie her up and fuck her slutty holes."
            b "Come any closer, and I promise you’ll regret it."
            scene v21-240
            "Banu finds herself physically restrained by Javid and Vusal, her expression a mix of defiance and strategic calculation. "
            "Maga, clearly intent on controlling the situation, speaks directly to her, his tone mixed with a hint of mockery and menace."
            m "Thought you could play the hero, Banu? Looks like the tables have turned."
            b "This isn't over, Maga. You think this show of force scares me? I've faced worse than you."
            m "It's not about fear, Banu. It's about power. And right now, we have it, not you."
            b "Power? Is that what this is to you? You're a coward, Maga. Hiding behind your friends because you can't handle me alone."
            m "Keep talking, Banu. It won’t save you."
            m "It's time for you to taste a little from a man's power."
            scene v21-241 with vpunch
            "Maga delivered a swift, forceful punch directly to Banu's abdomen. The impact was severe, driving the air from her lungs and doubling her over in pain."
            m "Not so tough now, are you?"
            "Banu, gasping for breath, clutched her stomach, the pain sharp and momentarily overwhelming. "
            "Stars danced before her eyes as she fought through the wave of nausea and disorientation."
            "After the powerful punch, Banu copletely lost her ability to fight back."
            scene v21-242
            "She lost herself and start moaning as Maga's cock touched her pussy."
            b "Ahhhh..."
            ja "That's it man, she is ready to be fucked."
            m "What happened, Banu. You already lost it?"
            m "I can feel the heat from your pussy and how horny you are right now. Your pussy is dripping wet."
            b "Maga...no."
            m "Whore, I'll give you what you really want."
            scene v21-243
            "Maga raised her legs and positioned himself right in the entrance of her wet tight pussy while Javid held her tight."
            "Banu was so horny from watching all those men and feeling powerless in front of them made her so wet down there."
            "She couldn't resist or say a word as Maga's wet cock entered her body."
            b "Ahhhhh....fuck...."
            "Her eyes were closed and her mouth was open, lost in ecstasy as maga continued to ravish her. "
            show magafuckbanu
            play music2 "voices/slappingsex.mp3"
            "Her fear and panic heighten her arousal, despite the danger she faces."
            "Her moans get lauder."
            b "Ohhh....fuck...fuck...fuck..."
            ja "Damn, she really enjoys it."
            vu "Just like that, man. Fuck the whore."
            show magafuckbanu_2
            "She is helpless against the three men, unable to break free from their grasp. She had only one choice: enjoy a good fuck."
            "She can't shake the feeling that this violent act is turning her on."
            b "Ahhhhh....."
            vu "You're nothing special, little slut. We've done this before, and you're just another notch on our belt."
            m "You're going to cum for us...."
            b "Ahhhhh...yesss...."
            stop music2
            scene v21-244 with flash
            "As Maga pressed deeper into her pussy, Banu's entire body convulses with pleasure. "
            "A warm, tingling sensation spreads throughout her body, building in intensity until it finally bursts forth in a powerful orgasm."
            "Her scream echoes through the room, a primal release of pure bliss."
            ja "Look at her face. She's cumming so hard."
            vu "The bitch hasn't fucked good for a while."
            scene v21-245
            "As Banu felt the man's massive cock came deep in her pussy, she groaned in delight."
            "The intensity of the sensation was almost overwhelming, and she could already tell that she was going to have the most epic orgasm of her life."
            m "Ohhhh yess...take it deep in your pussy."
            vu "She will definitely get pregnant after this night."
            scene v21-246 with fade
            "After Maga had finished pumping his load into Banu's pussy, he pulled out and admired his handiwork."
            "Banu was still in pleasure, couldn't say anything, her body still quivering with aftershocks of her intense orgasm. "
            ja "Now it's my chance to show you how much I can satisfy you."
            b "You will regret this. I'll make you all pay for this."
            m "Look at you, Banu. All that fire, all that fight, and here you are—unable to stop us. Doesn't feel good to be powerless, does it?"
            b "You think this makes you strong?"
            m "Oh, I'm not just strong, I'm smart. Smart enough to catch you, smart enough to cum inside of you."
            m "You will get pregnant with my child, Banu. But I won't take after the child, I'm so sorry for that."
            b "Animal!"
            scene v21-247
            "With each movement, her pussy dripped cum, leaving a trail of evidence behind her. "
            "The men broke her fragile female body. The cum dripping from her pussy made her body even weaker."
            "At this time she realized that no matter how hard she tries she will lose against them."
            "She was just so weak. Her body needed satisfaction."
            scene v21-248
            m "Now it's your turn. Let's see what you can do."
            m "Her body begs for hard dick. Just give it to her."
            m "Fuck her till she can't walk."
            vu "Fuck yes..."
            scene v21-249 with fade
            ja "You want this huh? You want this cock, don't you?"
            "The men were holding Banu up, exposing her most vulnerable areas."
            "She struggled to resist but was powerless against their strength."
            "The three men moved closer, their faces filled with lust as they prepared to ravage her defenseless body."
            scene v21-250
            ja "This is how we treat little sluts."
            vu "We'll do whatever we want to your body, and there's nothing you can do to stop us."
            b "Ahhhh...yesss..."
            m "Good girl, now we are talking."
            ja "You see man? She put down all her defences."
            m "Of course, she can't resist cocks. This is in her DNA."
            ja "Tell me bitch. Do you want this cock inside of you?"
            b "Ahhhh...yes..."
            ja "I can't hear you, bitch."
            b "Ahhh...yes...I want these big cocks inside of me....please fuck me already... "
            "Banu whimpered weakly, barely able to speak."
            b "Please... fuck me."
            scene v21-251 with vpunch
            play sound "voices/fastmoan2.mp3"
            b "Ahhhh...yesss..."
            ja "That is it baby, you are mine now."
            "Banu cried out, overwhelmed by the sheer intensity of the moment."
            b "Oh fuck me harder. Is this all you can do? Ahhhh....fuck...you are not a real man..."
            scene v21-252
            "The men exchanged smirks, enjoying Banu's desperation. "
            "She was consumed by the most intense orgasm she had ever experienced, her mind reeling with euphoria."
            vu "You want big cocks, don't you?"
            b "Ahhh...yeass, fuck me harder, you pieces of shit."
            m "Look at her man, she is so desperate for fuck. She is sexually frustrated bitch."
            "They ravaged Banu's body for hours until they lose power in their legs and took it to the ground."
            scene v21-253 with fade
            "Banu's world turned upside down as she realized her soul was taken by three men, all intent on taking control of her body."
            "As the men began to ravage her body, she felt a mix of fear and pleasure."
            "They used all her three holes at the same time sending pleasure to her brain."
            scene v21-254
            "Banu was now thoroughly enjoying herself as she gives a nice blowjob to Maga while the two studs fucking her other holes."
            "Banu moans in pleasure as the two men continue to thrust their cocks into her pussy and asshole."
            "She feels so alive and horny, her juices dripping down her legs as she experiences the thrill of having multiple partners."
            scene v21-255
            "Javid grunted as he thrust his cock deep into her wet pussy. "
            ja "Take my dick all the way."
            "Vusal chuckled as he pushed his cock into her tight asshole."
            vu "This is what happens when you get involved with dangerous men."
            b "Ahhh...fuck me....don't stop..."
            b "Fuck me harder!"
            scene v21-256 with vpunch
            "Suddenly Maga let out a moan, releasing all his seeds on Banu's face."
            "She's got Maga's cock in her face and she's covered in his hot sticky load."
            "She could taste the salty flavor of the man's semen on her tongue."
            "Her breasts were also smeared with cum, creating a delicious contrast between the softness of her skin and the warmth of the liquid."
            scene black with dissolve
            "Maga and Javid were talking after they've finished with Banu's body."
            scene v21-257 with dissolve
            m "Well, that was a mess. I didn’t think she’d put up that much of a fight."
            ja "Yeah, she’s tougher than she looks."
            m "You know, I almost respect her for that. Most women would’ve cracked way sooner."
            ja "True. But still, she had it coming. Can’t say I feel bad about it."
            m "I destroyed her pussy man, that was a tight pussy."
            ja "She was begging for us to keep going."
            m "I couldn't believe how turned on she was."
            m "It was almost like she was addicted to my cock."
            show vusalravagebanu
            play music2 "voices/slappingsex.mp3"
            b "Ahhhhh....yesss...."
            vu "Take this, bitch...take my cock.."
            m "Hey, Vusal. Come on, man, cum already. It's been an hour man."
            "As Maga and Javid talked, Vusal continued to assault Banu's body. "
            "He gripped her hips firmly, driving his thick cock deeper into her tight hole."
            "Banu groaned in ecstasy, her body trembling with delight."
            b "OH FUCKKKK....."
            stop music2
            scene black with dissolve
            "After emptying himself into Banu's pussy, Vusal still flexing his muscular frame."
            scene v21-258 with dissolve
            "His gaze lingered on Banu, admiring her beautiful form and reveling in the satisfaction of knowing he had just filled her with his seed."
            "With a satisfied smile, Vusal gazed down at Banu."
            m "How is Banu holding up after your round?"
            vu "Banu loved every second of it."
            scene v21-259 with fade
            "Banu is lying on the floor, completely spent."
            "Her body is covered in a layer of cum, likely the combined load of the multiple men who have taken turns dominating her. "
            "Banu's eyes are closed, her breathing slow and relaxed."
            "She's lost track of how many times the men have used her body, but she knows she's never felt anything like this before. "
            scene v21-260
            b_ "How did I let this happen?"
            b_ "I never thought I'd end up here... feeling this way."
            b_ "I can't believe I enjoyed this..."
            b_ "My body betrayed me. "
            b_ "My body is so weak and...dirty. Maybe I should accept this."
            b_ "After all, I'm just a woman."







    $ renpy.end_replay()
    $ persistent.banu_revenge_unlocked = True
    jump banu_revenge_continue
















label power:








    scene black with dissolve
    centered "{size=+120}At work{/size}" with Fade(0.5, 0.5, 5)
    scene v15-12 with squares
    play music "audio/tension.mp3"
    "Banu was worried when Ali called her to his room. He usually does this when there's something important to discuss."
    "Last time when he called her, she had to go to the USA with one of his partners."
    "But this time it was different. Ali kept looking into Banu's eyes with a dead serious face from the moment she entered the room. "
    scene v15-13
    "Ali used to scold Banu lately for the inconveniences she did in her work. "
    "Banu was late for work and most of the time she was not in time to deliver the tasks she was given."
    "However, Ali always tolerated her lack of responsibility and he didn't want to fire her."
    "He was always respectful towards Banu because of her being religious."
    "Ali was also a religious man and maybe that was the only reason that he didn't fire Banu in spite of her numerous mistakes."
    "But lately he wasn't hearing good things about Banu..."
    scene v15-14
    b "You wanted to see me. I hope I haven't done anything wrong. "
    ali "Have you finished the weekly report?"
    b "I...yes I sent it to your email."
    ali "I don't mean that one. I'm talking about the newly registered students' files. "
    b "Oh...that one. I'll finish it by Monday, I promise."
    ali "Banu..."
    b "You can't imagine how busy I was...really.."
    ali "Banu! Do you think I care?"
    b "But..."
    scene v15-16
    ali "Why do you think I should tolerate this?"
    ali "This's not the first time, not the 5th time, not the 10th time."
    ali "You make the same mistakes every time. Why are you so comfortable?"
    b "I think you understand that..."
    ali "I DON'T UNDERSTAND!"
    scene v15-15
    b "Well, you don't need to shout at me like that. I don't understand why you're so mad at me. I always take more time to prepare the files."
    scene v15-16
    ali "We lose lots of customers because of delayed documents. You know that?"
    ali "Every time they call and cancel their applications. They want their money back. All because of the stupid workers like you."
    scene v15-17
    b "Hey that's it. You better mind your words when you talk to me. "
    b "I work more than every worker here. Every time I stay overtime to save your ass. I do all your paperworks and you thank me like this?"
    scene v15-18
    ali "Lower your tone here. You can't talk to me with that tone."
    ali "You get bonuses for the additional work you do."
    ali "But it's over now. Write your letter of resignation. "
    scene v15-19
    b "What? Are you firing me?"
    ali "That's enough. You've done enough harm to the company."
    ali "Additionally, I don't have any reason to keep you here. Your behavior is not appropriate for our company."
    ali "I've been hearing so much about you lately. You go to night clubs, you drink alcohol, you hang out with men. Every person I see, talks about you Banu."
    b "What!?"
    scene v15-20
    b "Now I understand the reason you talk to me like that."
    b "But you know that they're all rumors. They're not true."
    ali "I've heard enough. I wish you respect yourself more. "
    ali "You're wearing a hijab but you don't respect it. You don't respect your religion."
    scene v15-21
    b "Do you know that you're insulting me right now?"
    b "What they say is not true. My enemies turned you against me. I know that."
    b "But I do need this job. Please, give me one more chance. I can't stay at home all day. I'll prove myself."
    ali "You don't need financial support. You have a husband. You can just ask money from him."
    ali "But if you don't want to see his face, there's only one way to guarantee your position here."
    b "What's it?"
    scene v15-22 with vpunch
    ali "You become my personal assisstant. Can you do that? "
    b "Hey! What're you doing?"
    scene v15-23 with vpunch
    b "You pig! Don't dare to touch me again."
    b "Do you think I'm like one of your whores here?"
    b "I can make you spend the rest of your life in jail, asshole."
    scene v15-24
    ali "Shut up, slut. You can't talk to me like that."
    ali "Now get the fuck out of here slut and don't ever put your foot in my company."
    stop music    
















    scene black with Dissolve(3)
    ""
    centered "{size=+120}1 year later...{/size}" with Fade(0.5, 0.5, 5)
    scene black with dissolve
    b_ "In the year that followed my divorce from Kamil, my life took a drastic turn."
    b_ "Initially, I found solace in the company of a new, religious man, but soon realized he wasn't the right fit for me."
    b_ "I had to make the difficult decision to end that relationship, recognizing that I deserved more than a partner who didn't truly understand or respect me."
    show banu_running_animation
    "..."
    scene running29


    b_ "Alone and determined to reclaim my strength, I made a choice: I was going to focus on myself."
    b_ "Instead of wallowing in past disappointments, I decided to channel my energy into becoming mentally and physically stronger."
    b_ "Sport became my outlet, my sanctuary."
    scene v18-44
    b_ "Engaging in physical activities empowered me, making me feel resilient and capable."
    b_ "As I honed my body, I found my mental strength growing too."
    scene v18-45
    b_ "Through my dedication to sports and physical training, my body underwent significant transformations."
    b_ "The once soft contours became defined, muscles sculpted themselves beneath my skin, and my physique took on an athletic tone. "
    b_ "My curves became more pronounced, a blend of strength and femininity that made me feel empowered and confident."
    scene v18-46

    b_ "Regular workouts not only gave me a toned appearance but also boosted my endurance and stamina."
    b_ "I could feel the power in my muscles as I moved, a newfound sense of control and capability that radiated through every fiber of my being."
    b_ "I learned to appreciate the beauty in my curves, the definition in my muscles, and the strength in my movements."
    scene v18-47

    b_ "It's about valuing yourself, setting boundaries, and refusing to settle for anything less than what you deserve."
    b_ "Living with a sense of revenge can be a powerful motivator, driving someone to reclaim their strength and resilience."
    scene v18-48
    b_ "I felt that fire within me, a burning determination to rise above the pain and betrayal that had been inflicted upon me."
    b_ "I decided it was time to turn that anger into something constructive, something that would make me stronger."
    b_ "Every workout, every drop of sweat, and every muscle gained was a step toward reclaiming my power."
    b_ "It was my way of saying to those who had wronged me: 'You may have hurt me, but I will not be defeated. I will emerge from this stronger than ever before.' "
    scene v18-49
    b_ "The desire for revenge burned fiercely within me, not just for the personal wrongs I had endured, but also for the harm inflicted on my daughter, Leyla."
    b_ "The man who had hurt her had awakened a fierce protective instinct in me, a need for justice that went beyond my own pain."
    scene v18-50
    b_ "The thought of someone harming my child filled me with a seething anger."
    b_ "It was a mother's instinct, a primal need to shield my child from harm and to make sure that those who had hurt her would pay for their deeds."
    scene v18-51
    b_ "In my quest for revenge, I became even more determined to strengthen myself mentally, emotionally, and physically."
    b_ "I knew that only by becoming stronger could I truly protect my daughter and ensure that she would never face such horrors again."
    b_ "This desire for revenge became a driving force, pushing me to new limits and fueling my determination to create a world where Leyla—and others like her—could live without fear."
    b_ "It was a battle not just for vengeance, but for the safety and well-being of my family and all those who had suffered at the hands of others."

    scene black with dissolve


    b_ "Standing in front of the mirror at night, clad in just my bra and bottom, I couldn't help but marvel at my newly gained curves."
    scene v18-52 with irisin
    b_ "My body, once soft and fragile, was now a testament to my strength and determination."
    b_ "I ran my hands over the defined muscles, feeling the power beneath my fingertips."
    scene v18-53
    b_ "Yet, despite this physical transformation, a sadness lingered in my eyes, a reflection of the pain I had endured."
    b_ "As I admired my body's newfound strength, there was a burning desire for revenge that fueled my every move."
    b_ "In those quiet moments, I felt a mix of conflicting emotions."
    scene v18-54
    b_ "On one hand, I reveled in the power of my body, embracing the curves and muscles that represented my resilience."
    b_ "On the other hand, a determination for retribution simmered beneath the surface, a longing for justice that kept the sadness in my eyes alive."
    b_ "The mirror became a battleground where my inner strength clashed with my deep-seated desire for revenge."
    scene v18-55
    b_ "Sometimes, when my mind was overwhelmed with pain and confusion, I'd head to the club."
    b_ "I was free and could do anything I wanted."
    scene black with dissolve
    b_ "The lively atmosphere, the music, and the dancing provided a temporary escape."
    scene v18-56 with dissolve
    b_ "It was a chance to clear my thoughts and have some fun, even if just for a little while."
    b_ "On other occasions, I turned to alcohol as a way to cope."
    scene v18-57
    b_ "A drink or two helped me forget, at least momentarily, the heaviness inside me."
    b_ "It was a way to numb the pain, even though I knew it was just a temporary escape."
    b_ "In those moments, whether on the dance floor or with a drink in hand, I found a way to quiet the turmoil in my mind."
    b_ "It wasn't a perfect solution, but it gave me a break from the constant emotional weight I carried."
    scene v18-58
    b_ "At the club, there were always creepy guys around, but one, in particular, made me incredibly uncomfortable."
    b_ "His stares and advances were relentless, and I couldn't shake off his unsettling presence."
    b_ "It felt like he was invading my personal space and it made my skin crawl. I absolutely despised the way he made me feel."
    scene v18-59
    b_ "Dealing with his disturbing behavior fueled my anger. I hated that someone could be so disrespectful and invasive."
    b_ "But in those moments, I refused to let his actions break me. "
    b_ "Instead, I channeled my frustration into strength, promising myself that I would stand my ground and not let anyone make me feel unsafe."
    scene v18-60
    b_ "I felt a growing sense of unease as the persistent man followed me to the bathroom."
    b_ "His unwanted advances and dirty propositions had crossed all boundaries, and I knew I couldn't let him get away with it."
    scene v18-61
    b_ "Feeling my patience wear thin, I continued washing my hands, trying to ignore the persistent man who had followed me into the nightclub's bathroom."
    scene v18-62
    b_ "His disturbing remarks reached a new level, and I knew I had to take a stand."
    b_ "He started touching my bare skin in a disturbing way. I was at my limit. He was mistaking me with one of those girls in the club."
    scene v18-63
    b_ "That was it. I wasn't going to endure it anymore. That was the best time to release the evil Banu that I was hiding for a long time."
    scene v18-64 with hpunch
    b_ "Without a second thought, I swiftly turned around, channeling all my frustration and anger into a powerful kick aimed directly at his crotch, using the pointed heel of my high shoe."
    scene v18-65
    b_ "The impact sent shockwaves of pain through him, and he crumpled to the floor, gasping for air."
    b_ "In that moment, I had reclaimed my space, my dignity, and my safety. But it was not enough for me."
    scene v18-66
    b_ "In a moment of sheer frustration and determination, I landed a swift, forceful kick aimed at his face."
    b_ "I wanted to smash his fucking face making him suffer. I wanted to break his nose and see the blood coming down her face."
    b_ "I was becoming such a devil person. This guy helped to reveal the devil inside of me."
    scene v18-67
    b_ "My kick was hard so his head tapped the wall making a loud sound. He lost his consciousness for some time remaining on the floor. "
    b_ "I raised my leg and pushed my foot right into his mouth so he couldn't talk."
    scene v18-68
    b_ "I made him look into my eyes and he did."
    b_ "In that charged moment, with adrenaline coursing through my veins and anger fueling my words, I couldn't hold back my contempt for his behavior."
    b_ "Looking down at him on the bathroom floor, I let my words cut through the air, each syllable dripping with disdain."
    b_ " 'You're nothing but a pathetic coward,' I spat, my voice laced with fury. 'Real men don't prey on others' vulnerability. You're a disgrace.' "

    b_ "My words hung in the air, emphasizing the humiliation he had brought upon himself."
    b_ "I wanted him to feel the weight of his shame, to realize the magnitude of his wrongdoing."
    scene black with dissolve
    b_ "I came to a point that I lost all my respect for men. The only man that I felt weak in front of was Polad and I was going to put an end to this."
    scene v18-69 with fade
    b_ "Frustration bubbled inside me as Polad barged into my room, shouting because I had come home late."
    scene v18-70
    b_ "His words were like daggers, and I felt my patience snap."
    scene v18-71
    b_ "In that moment of sheer frustration and anger, I found a newfound strength within me."
    b_ "I decided to stand my ground and shut him down."
    scene v18-72
    b_ "With a voice firm and unwavering, I told him, 'You do not get to dictate my life. I am not answerable to you. If you can't respect my independence, then maybe you should reconsider having me in your apartment.' "
    b_ "My words hung heavy in the air, a powerful assertion of my boundaries and my right to live my life on my own terms."
    scene v18-73
    b_ "It was a backfire, a reclaiming of my voice and my space."
    b_ "I refused to let anyone make me feel weak or powerless anymore."
    b_ "This was my moment of empowerment, a declaration that I would not be silenced or controlled."
    scene black with dissolve
    b_ "Aslan was following me everywhere asking a second chance. He didn't want to understand that we were not a good match."
    scene v18-74 with dissolve
    b_ "In the quiet serenity of the mosque, Aslan approached me, seeking reconciliation."
    b_ "But I had grown stronger, both mentally and emotionally."
    scene v18-75
    b_ "As he spoke, I calmly walked away from him, refusing to be ensnared by his words."
    b_ "But he wasn't going to give up."
    scene v18-76
    b_ "Suddenly, I stopped, turned around, and faced him with a steely resolve."
    b_ "I looked him in the eye, unflinchingly, and declared:"
    scene v18-77
    b_ "You're not enough of a man for me. I've become more powerful, taller, and richer than you could ever comprehend."
    scene v18-78
    b_ "I won't settle for someone like you."
    b_ "I refuse to let a man like you shut me down or control my life. I am my own person, and I won't be diminished by anyone."
    b_ "I walked away, leaving him to contemplate the woman he had underestimated and lost. "
    scene black with dissolve
    b_ "I lived with a singular purpose: to seek revenge on the man who had hurt Leyla."
    b_ "Every waking moment was consumed by the need to find him, to hold him accountable for the pain he had inflicted on my daughter."
    scene v18-79 with fade
    b_ "In a dark and determined night, I sat in front of my computer, my eyes fixed on the screen. "
    b_ "After countless hours of searching, I finally found the social profile of the man who had hurt Leyla."
    scene v18-80
    b_ "Anger surged through me, but I knew this was a crucial step toward justice."
    b_ "With a calculated plan in mind, I created a new online identity, registering as a confident and alluring 'milf' to capture his attention."
    b_ "I engaged him in conversation, weaving a web of intrigue around us."
    scene v18-81
    b_ "Playing my role convincingly, I managed to gain his trust and arrange a meeting at his place."
    b_ "Every keystroke was a step closer to confronting the man who had caused my daughter pain."
    b_ "I knew this meeting was risky, but my determination to bring him to justice overshadowed any fear."
    b_ "This was my opportunity to ensure he faced the consequences of his actions, and I was ready to face whatever challenges lay ahead."
    scene black with dissolve
    b_ "Finally, I came to his place."
    scene v18-82 with dissolve
    b_ "Entering his bedroom, I found him waiting there, his eyes filled with anticipation and curiosity."
    scene v18-83
    b_ "I was wearing a red mini dress revealing most of my skin just to distract him and implement what I came here for."
    b_ "He was a young and skinny guy."
    b_ "He was a stranger to me, a man I had tracked down for the sake of justice."
    b_ "As I stood there, a mix of determination and anger coursing through me, I knew this encounter was crucial."
    b_ "It was a moment that could bring closure and retribution for Leyla's pain."
    b_ "With a steady gaze, I prepared to confront the man who had caused our family so much suffering."
    scene v18-84
    b_ "I just looked at him and smiled. I was just playing my role to distract him. I had a very nice plan. "
    b_ "I wanted to see him suffer to scare him. But I had to be patient."
    scene v18-85
    b_ "To implement my plan I just had to smile. He was a fool. He thought I was one of the whores came to entertain him."
    b_ "I tricked him and he believed all the lies I told. I wasn't going to kill him. My purpose was to scare him but things turned upside down."
    scene v18-86
    b_ "He suddenly approached me grabbing my body lifting my dress."
    b_ "I hated when he touched me but I had to endure it."
    b_ "There was a serious physical difference between us. He was a thin guy and I felt really powerful against him. "
    b_ "I could just push him away but I decided to play smooth."
    scene v18-87
    b_ "Things got serious. He took his shorts and my dress off grabbing my breasts from behind."
    b_ "His cock was already hard and touching my legs from behind. I hated that."
    scene v18-88
    b_ "That was the worst moment of my life. I was letting the bully of my daughter feel my bare breasts."
    b_ "If he could see my face in that moment..."
    b_ "I had to do something so I escaped from his arms and quickly turned around."
    scene v18-89
    b_ "I convinced him to sit on the bed so I'd give him a nice show."
    b_ "It wasn't easy to make him do what I wanted. He was a tough guy and he already got his hands all over my body. "
    scene v18-90
    b_ "His dick was big and hard. If he wasn't the guy who harmed Leyla, I'd probably fucked him."
    b_ "I was getting turned on from his touches and I hated that. But that faded away a few minutes later."
    scene v18-91
    b_ "He jumped on the bed like a naughty boy watching me take off my pants eagerly."
    b_ "His cock was still so hard pointed to the ceiling."
    b_ "I was slowly taking my pants off... Then I quickly grabbed the handcuffs on the table near the door and climbed on the bed."
    scene v18-92
    b_ "He was surprised seeing the handcuffs and joked that I came prepared."
    b_ "He didn't understand what a deep shit he was in. "
    scene v18-93
    b_ "I smiled looking into his eyes and thinking about what I was going to do to him."
    b_ "I was burning with the desire to get my revenge. I could easily report him to the police but that wouldn't be enough for me."
    scene v18-94
    b_ "I told him that I was going to handcuff him to the bed so we could have some special fun."
    b_ "He was amazed with the view he was seeing and continuously complimenting my body."
    b_ "He was calling me an angel without knowing that I was the biggest monster he'd ever faced."
    scene v18-95
    b_ "I finally did that. I locked his arms while getting on top of him and his hard cock touching my spot."
    b_ "I was trying to focus on my purpose and not to be distracted."
    b_ "He was still unaware that I was Leyla's mother."
    scene v18-96
    b_ "My true identity was my secret weapon, allowing me to remain undetected as I confronted him."
    b_ "The element of surprise was on my side, and I used it to my advantage, ensuring that he wouldn't see my actions coming."
    scene v18-97
    b_ "With each passing moment, I held my ground, ready to unveil the truth when the time was right."
    b_ "As the tension in the room grew, the man began to sense that something was amiss. His suspicious gaze met mine."
    scene v18-98
    play music "audio/tension.mp3"
    b_ "In that moment, I made the decision to reveal my true identity."
    b_ "Shock registered on his face as he realized the gravity of the situation. It was the moment of truth, the instant when he comprehended the consequences of his actions. "
    b_ "I approaced the table to get the knife I hided there previously and I found it."
    scene v18-99
    b_ "I stood there, unwavering, a symbol of a mother's fierce protectiveness, and a force to be reckoned with. "
    b_ "The revelation hung in the air, sealing his fate and marking the beginning of his accountability for the pain he had caused."
    b_ "You had to see the expression on his face when I came back with the knife."
    scene v18-100
    b_ "The cold steel pressed against my palm, a reminder of the power I now held."
    b_ "With determination burning in my eyes, I approached the man, brandishing the knife."
    scene v18-101
    b_ "I could see the fear in his eyes while he was looking at the knife in my hand."
    b_ "I held the blade steady, my voice firm and unwavering as I warned him:"
    b_ "This is the price you pay for your actions. You thought you could escape justice, but now you face the consequences."
    scene v18-102
    b_ "I quickly got on top of him. His hard, excited dick was now soft and small."
    b_ "The room fell silent, the weight of my words hanging heavily between us."
    b_ "He stared at the knife, his eyes wide with realization."
    b_ "I knew he felt guilty and understood his wrongdoing and begged me to put the knife aside, but that wasn't enough for me. "
    b_ "I wanted to see pain. I wanted to see blood."
    scene v18-103
    b_ "I pressed the sharp knife to his chest and started moving it."
    b_ "He was scared to death and started shouting."
    scene v18-104
    b_ "I draw a line on his chest with the knife and the blood started running down his body."
    b_ "He was shouting, begging me to stop so he's never make the same mistake again and I was enjoying that."
    scene v18-105
    b_ "The fear on his face was fueling the evil Banu inside of me and she was strong."
    b_ "I continued threatening him telling him that I was going to cut his dick in pieces."
    b_ "You will face the consequences of your actions. This ends now. You will never hurt anyone again: I said."
    scene v18-106
    b_ "He suddenly started raising his tone and threatening me that he'd report me to the police."
    b_ "I might forgive him but after these words..."
    b_ "His threats only fueled the fire of my anger, intensifying my determination to bring him to justice. "
    scene v18-107
    b_ "I raised the knife with both my hands..."
    b_ "His attempt to intimidate me with the mention of the police only made my resolve stronger."
    b_ "I stood my ground, undeterred, and shot back with fierce determination:"
    b_ "Die you idiot!"
    scene v18-108 with vpunch
    b_ "I pierced his chest with the knife and it went deep inside of his chest."
    scene v18-109
    b_ "Realizing what just happened with a shocked face he looked at me in the last moments of his life."
    b_ "He wanted to say something but he couldn't move his lips and I looked into his eyes with an angry but satisfied look."
    b_ "I watched him die..."
    scene v18-110
    b_ "That was the end of the man who hurt my daughter."
    b_ "I didn't feel any guilt for that. Instead, I was thinking about how could I hide the dead body."
    scene v18-111
    b_ "I wasn't planning to go to jail because of a trash man like him."
    b_ "I didn't understand what had got into me but I was turning into a violent person."
    b_ "The worst thing about this was that I was enjoying it."
    stop music











    scene black with Dissolve(3)
    ""
    centered "{size=+120} Banu's fate: Revenge or getting wasted {/size}" with Fade(0.5, 0.5, 5)


    $ banuletpoladfuckhershower = False
    $ banustopali = False
    $ banukickturanface = False
    $ banukillhumaykamil = False
    $ banukillmaga = False


    jump polad_banu_power_shower



label polad_banu_power_shower_continue:

    scene black with dissolve
    "..."
    "Days had passed since the intense encounter with Polad."
    "Despite the fleeting moments of passion, she knew she had a deeper mission to fulfill."
    "Banu's first target was Ali, her former boss, a man notorious for his reprehensible behavior."
    "He had harassed young girls at work, made inappropriate proposals, and fired Banu a year ago after making a sexual proposition to her."
    "It was time for Ali to face justice."


    jump ali_fuck_banu




label ali_fuck_banu_continue:



    scene black with dissolve
    "..."
    "Weeks had passed since Banu had opened up about her painful past."
    "She was far from stopping now; in fact, she was burning with a desire for revenge."
    "The next target on her list was Turan, a colleague at work who had made inappropriate proposals to her when she was still married to Kamil."

    jump turan_banu_power



label turan_banu_power_continue:

    scene black with dissolve
    "..."
    "Some time later, Banu found herself locked in a spiral of despair, unable to leave her room as she grappled with the aftermath of her torment."
    "She locked herself inside her room, wrestling with her mental state and the trauma she had endured."
    "The isolation became her sanctuary, though it felt more like a prison."

    scene black with dissolve
    centered "{size=+120}Some time later{/size}" with Fade(0.5, 0.5, 5)
    scene black with dissolve
    "Kamil was living a starkly different life. "
    "He had moved on from their past and seemed to be enjoying himself, finding solace in the arms of another woman."
    scene v21-164 with dissolve
    play music "audio/slowsoft.mp3"
    "Kamil was now at Humay's house, the woman he had an affair with while still in a relationship with Banu."
    scene v21-165 with fade
    h "You always know how to make things exciting, Kamil."
    k "Well, I've had some practice. Life's too short to not have fun, right?"
    h "Do you ever think about her? About Banu?"
    k "Sometimes. But we made our choices, and I've moved on. She has her own life now."
    h "Do you think she's okay?"
    k "Let's forget about Banu and focus on us."
    scene v21-166
    "He leaned in, planting soft kisses on Humay's bare shoulder, trailing down her belly and back across her ass. Humay laughed, a light, carefree sound that filled the room."
    h "You know, if your kisses were any more distracting, I might forget my own name."
    k "Good, because I plan on making sure you only remember mine."
    h "You're so confident. What makes you think you're that unforgettable?"
    k "Well, I’ve been told I leave quite an impression... in more ways than one."
    h "Is this the only thing you can do, Kamil?"
    k "Oh, I can do so much more."
    scene v21-167 with fade
    h "Ahhhhh...You certainly know how to make a girl feel special."
    k "Are you sure you can handle more?"
    h "I'm not just sure, I'm hoping for it!"
    scene v21-168
    "Kamil's hands were skilled, and Humay's responses encouraged him further."
    h "If this is your idea of a warm-up, I'm excited to see what comes next!"
    k "Oh, I've got plans, believe me. You'll want to stick around for the main event."
    scene v21-169
    h "Ohhhh...shit...so this was your plan?"
    k "You know, I think it's time for a thorough cleaning."
    k "Your pussy is so dirty, it needs good cleaning."
    h "Oh really? "
    "As Kamil continued to eat Humay's pussy, she looked at him with a curious smile."
    h "Did you ever do this with Banu?"
    k "Not so much. She was quite religious, and there were certain things she wasn't comfortable with."
    scene v21-170
    k "Now shut your mouth and enjoy the cleaning."
    k "Just you wait. I have a few tricks up my sleeve."
    h "Alright, let's see what you've got, Mr. Cleaner."
    scene v21-171 with fade
    "Their playful teasing gave way to a deeper connection as they began to have sex, their bodies moving together in perfect harmony. "
    h "Ahhhh...my dear, you feel so good..."
    k "Ohhhh...I love you...I love you so much..."
    h "Ahhhhh...You make me feel so special, Kamil. I love being with you like this."
    k "I’ve never felt this close to anyone. You mean so much to me."
    scene v21-172
    h "Tell me....do you love me more than you ever loved Banu?"
    k "Of course I love you more, Humay. Banu was always so uptight and religious. She never understood me the way you do."
    k "Banu always acted like she was better than everyone else because of her beliefs. She made everything so difficult. "
    scene v21-173
    stop music
    k "You're nothing like her, Humay. You're fun, you're open, and you actually enjoy being with me. Banu was always so judgmental and cold. I don't need that in my life."
    k "I'm just glad I have you now. You make me happier than Banu ever did."
    scene v21-174 with hpunch
    b "Is that right, Kamil?"
    "As Kamil finished his bitter sentence about Banu, a sudden and unexpected silence fell over the room. "
    "Both he and Humay froze, their eyes widening in shock as they saw Banu standing at the foot of the bed."
    "She had heard everything."
    scene v21-175
    "Banu's face was calm but her eyes reflecting the hurt caused by Kamil's harsh words."
    "The atmosphere in the room shifted dramatically, tension replacing the intimacy that had filled the space just moments before."
    k "B-Banu... what are you doing here?"
    h "We didn't know you were here..."
    "Banu ignored Humay's comment."
    b "I see you've moved on, Kamil. And quite happily, it seems."
    k "Banu, I... I'm sorry. This isn't how I wanted you to find out."
    scene v21-176
    b "You know what, Kamil? You’ve always been an asshole."
    b "You were a terrible husband with a small dick, and believe me, I've seen bigger and better."
    k "Banu..."
    b "You know what, Kamil? You don’t deserve any respect from me. You think you’ve moved on to something better?"
    b "Well, good luck, because you’re still the same pathetic man you always were."
    scene v21-177
    k "That's enough of shit. You have no right to come in here and disturb us like this!"
    k "You left me...That is it. Just get the fuck out, now!"
    h "Please, both of you...."
    k "You need to leave, now. This isn't your place anymore. You're not welcome here."
    b "Is that so?"
    k "You think you're so perfect, Banu? You're nothing but a bitter, miserable woman! No wonder no one can stand to be around you!"
    h "Kamil, please calm down."
    k "You come in here acting all high and mighty, but you’re just jealous because I’m happy now! You never knew how to make me happy."
    b "Enough, Kamil. You think you can just walk all over me and get away with it? Not anymore."
    scene v21-178 with hpunch
    play music "audio/suspense.mp3"
    "Kamil and Humay's faces turned pale with shock and fear."
    "The anger in Kamil's eyes was quickly replaced by sheer terror as he realized the gravity of the situation. Humay hold her head, her eyes wide with horror."
    k "B-Banu, put the gun down. What are you doing?"
    h "Banu, please... think about what you're doing."
    b "I'm going to send both of you to hell where you belong."
    scene v21-179
    k "Banu, please, you don't have to do this. Think about the consequences."
    b "Consequences? You think I care about consequences now? After everything you've put me through?"
    h "Banu, please, let's talk about this. "
    k "Please, put the gun down."
    b "Look at you, Kamil. So scared, you’re probably going to shit yourself any moment now. Pathetic."
    k "Banu, please... let's not do this. We can talk it out."
    b "Now I'm going to make some holes in your body, asshole. "
    k "Banu, wait! This... this is all Humay's fault! She pushed me into this! I didn't want her, she seduced me!"
    h "What? Kamil, how can you say that? You know that's not true!"
    k "I swear, Banu. I never wanted this. She came on to me, she made me do it!"
    b "So this is who you really are, Kamil? Ready to throw her under the bus to save your own skin?"
    menu:
        "Kill them":

            $ banukillhumaykamil = True
            $ renpy.block_rollback()
            scene v21-181
            "As Banu stood in front of Kamil and Humay, her grip on the gun tightened. The weight of her pain and anger was overwhelming, and she made a snap decision."
            "She aimed the gun at Kamil's upper left shoulder and pulled the trigger."
            scene v21-182 with vpunch
            play sound "voices/bullet.mp3"
            k "Ahh! Banu, what the hell!"
            "Kamil cried out in pain as the bullet tore through his shoulder, blood immediately starting to pour down his body. "
            h "Oh my God, Kamil! Banu, what have you done?"
            b "That's for all the pain you caused me, Kamil. Maybe now you'll understand what it's like to suffer."
            scene v21-183 with vpunch
            play sound "voices/bullet.mp3"
            k "Ahhh...Banu..."
            "Without hesitation, she aimed the gun again and fired another shot, this time hitting Kamil in the right side of his chest."
            "Blood poured from the wound, quickly soaking his shirt and running down his body."
            "His face turned pale, and his eyes rolled back as he struggled to breathe."
            h "Nooo..."
            "He managed to gasp out a few words before his strength gave out."
            "His body went limp, and he collapsed back onto the bed, his eyes closing as he lost consciousness. "
            scene v21-184 with vpunch
            play sound "voices/bullet.mp3"
            "Without hesitation, Banu raised the gun once more and fired a shot into Humay's chest. "
            "The bullet struck with precision, and Humay's eyes widened in shock and pain."
            "She clutched her chest, blood quickly spreading her body."
            h "Banu... for what?"
            scene v21-185 with fade
            stop music
            "She collapsed backward onto the bed, landing on Kamil's outstretched arm."
            b "For everything you took from me."
            "Banu turned and walked out of the room, the gun still in her hand, her steps heavy and her heart even heavier."
            "Inside the house, Kamil and Humay lay together, their bodies still and the room filled with the silence of their final moments."
        "Leave them":



            $ banukillhumaykamil = False
            $ renpy.block_rollback()
            stop music
            "As Banu watched Kamil's pathetic attempt to shift the blame and Humay's tearful betrayal, a sense of pity began to replace her anger."
            "She saw them for what they truly were: frightened, desperate, and ultimately, pitiable."
            b "You know what? You're not even worth it. Both of you are pathetic."
            scene v21-180 with fade
            "Kamil and Humay remained silent, their eyes wide with fear and confusion. Banu took one last look at them, her expression a mixture of disdain and pity."
            b "Enjoy your miserable lives. You deserve each other."
            "Without another word, Banu turned and walked out of the room, leaving Kamil and Humay speechless and trembling."
            "The door closed behind her with a decisive click, and for a moment, the silence in the room was deafening."




    scene black with dissolve
    "..."


    jump banu_revenge


label banu_revenge_continue:


















label powerending:


    play music "audio/weakbanu.mp3"


    scene black with dissolve
    "The air near the abandoned lake was thick with the scent of pine and rotting leaves."
    ta "You look smaller than the stories say, Banu."
    b "I grew strong because the world is full of dogs like Farid."
    b "I didn't just slaughter him. I erased a stain from the earth."

    scene end-259 with dissolve
    z "He was our blood. You spent hours scratching him, teasing him..."
    z "Then you put the steel in his heart. Do you know how we found him? Tattered. Like a piece of meat."

    scene v18-109 with flash
    b "He found my daughter Leyla when she was vulnerable. He used her, broke her, and tossed her aside like she was nothing."
    b "I showed him what it feels like to be truly helpless."
    scene v18-110 with flash
    b "I watched the light go out of his eyes, and it was the most beautiful prayer I’ve ever said."
    ta "You talk of God and wear that hijab while your hands are soaked in Farid’s blood! You think your 'justice' makes you holy?"
    scene end-259 with fade
    b "It makes me a mother. Your brother wasn't just 'blood.' He was a predator."
    b "And if you’ve brought me here to finish what he started, then you’re just more filth for the soil."

    scene end-260
    z "We aren't here to 'use' you, Banu. We aren't Farid."
    z "We’re here to show you that no matter how many weights you lift, or how many men you kill, you’re still just a woman who made the wrong enemies."
    ta "We’re going to take our time. Just like you did with him. We’ll see how long that 'powerful' spirit lasts when we start returning the scratches you gave our brother."
    b "I’ve lived more in this last year than you will in a lifetime of cowardice. Kill me if you must, but know this: Farid died screaming my name in terror."
    b "And every time you close your eyes, you’ll see my face, and you’ll wonder if there’s another mother out there just like me, waiting in the shadows for you."
    b "I prayed God would give me the strength to face men like Farid."

    scene end-261
    ta "And where is that God now, Banu? He's left you here with us."
    ta "We're going to break your body apart so completely that not even your God will recognize the pieces."
    b "My body is just a vessel. You can break it, but you're too late to break my spirit. That was forged in fires you can't even imagine."
    scene end-262
    z "We don't care about your spirit. We want your flesh. We're going to start with your legs—the ones that gave you so much power."
    z "We'll shatter the bones so you can never stand again."
    z "Then we'll take your arms, the ones you used to hold our brother down. We'll sever them at the shoulder."
    b "You think scattering me is a punishment? It's a release. You'll still have to live with the memory of the woman you couldn't break."

    scene black with dissolve
    z "Down on your knees, you knife-wielding bitch! You gutted Farid like a pig – now choke on my cock for it!"
    b "Fuck you! Get that filthy dick away from me, you bastards! I ain't your whore!"

    scene end-263 with dissolve
    $ renpy.sound.play("voices/bj.mp3", loop=True)

    b "gluck slurp – push mmmph!"
    ta "Zaur. Force it deeper, make the murdering slut gag like she made Farid bleed."
    b "Mmmph! Bastards... I'll bite it off! Nghh, too thick, you pigs!"

    scene end-264
    z "Try it, cunt – bite and we'll carve you up worse than Farid. Swallow deeper, hijabi killer!"
    b "sluuuurp gluck gluck – yank slop!"
    b "Gahh! Sons of whores... you'll pay for this! Hrrk!"
    ta "Keep fighting, Banu – makes your throat clench tighter. Zaur, fuck her face harder. Farid's watching from hell, loving this revenge."

    scene end-265
    z "Yeah, squirm all you want, you black-hooded snake. Lick my balls clean while Tarik lines up to wreck that ass."
    b "Nooo... fuckers! I'll kill you both like your brother! Glrrk!"
    z "Not done yet, you stabbing slut! Deeper on my cock – ram it down that throat till you taste Farid's revenge!"
    b "Gahh! Fuck off, you goat-fucker! I'll rip your balls off! Mmmph, nghh!"

    scene end-266
    ta "Hold her head still, Zaur. Make the hijabi murderer slobber like a street dog. Fight all you want, Banu – your pussy's dripping already."
    z "Lick the shaft, bitch! Every vein for every drop of Farid's blood. Swallow my precum like your poison lies!"
    b "Hrrk! Bastard pigs... curse you! Too deep, you animals! Glrrk!"
    z "Yeah, choke harder, killer cunt! Balls-deep for brother Farid – gag it out!"

    scene black with dissolve
    ta "Tongue out now, you brother-killing cunt, or I'll drown you in this lake after I carve Farid's name into your fucking throat!"
    ta "Lick my cock like the worthless hijabi slave you are – no mercy!"
    b "P-please... no more..."
    scene end-267 with fade
    z "Hah, look at her break, brother. Tongue flat on Tarik's shaft, slurping like she murdered for this dick."
    z "No fight left in the traitor whore."
    ta "Deeper, Banu – worship every vein for stabbing Farid! Lick my balls clean."
    ta "You're powerless now, our revenge meat."
    ta "Open wide for my cock or I'll ram it through your hijab and choke you dead right here!"
    b "No! It's way bigger than his... I can't... too fucking huge, please!"
    z "Liar whore, you took mine balls-deep. Tarik, grab her hijab and shove it in."
    ta "Shut up and suck..."
    scene end-268 with fade
    b "Nghh! Bastard..."
    ta "That's it, hijabi cunt – stretch that murderer mouth around my fat shaft. Deeper for every stab you gave him!"
    z "Look at her eyes bulge, brother. Wreck her face – pussy's leaking for round two."
    ta "Gag on it harder, you oversized-cock-fearing slut!"
    b "Hrrrk! Can't breathe... gagging... too thick! GRRRK!"

    scene black with dissolve
    z "Gotcha, you squirming assassin bitch! No running – arch that ass up high for Tarik's big cock."
    z "Hold still or I'll snap your spine like Farid's last breath!"
    stop sound
    scene end-269 with dissolve
    b "Let go, you filthy pigs! Not my ass... nooo! Get that monster away!"
    ta "Look at this tight hijabi asshole winking, Zaur. "
    b "Nghh! Stop... too big for my ass, bastards! It'll tear me... ahh!"
    scene end-270
    $ renpy.sound.play("voices/longmoan.mp3", loop=True)
    b "Hahh! Nooo... burning... don't push, you animals! Please!"
    z "Push that ass back, you hijabi murderer! I’ve got your hips locked—there's no escape from Tarik’s monster."
    z "Feel the heat of it on your tight little pucker?"
    scene end-271
    b "Nghh! No... it’s too big! Tarik, please... you'll tear me apart! I can't take that... ahh!"
    ta "Listen to the killer whimper, Zaur. She’s shaking because she knows my cock is twice the size of yours."
    b "Hahh... ahh! Stop! It’s burning... I’m too tight for you... please, bastards! Not my ass!"
    z "You weren't too tight for the knife you put in Farid! Hold still, slut! Tarik, shove the head in—stretch that arrogant asshole until she screams his name!"
    b "Hnggh... ahhh! It’s ripping me!"
    z "Deeper, brother! Make her leak for Farid!"
    z "Tarik, move over! My turn to show this stabbing bitch what real punishment feels like."

    scene end-272 with fade
    b "Fuck you, Zaur! I’ll kill you too! Nghh... don’t you dare! It’s too tight... you’ll rip me open, you animal!"
    ta "Listen to her spit venom while her pucker twitches in fear. Shove it in, Zaur—stretch the killer wide!"
    z "Here’s your revenge, Banu! Open up for my brother!"
    b "GAAAAHHH! NOOO! Bastard... it's splitting me! Stop... please, too deep! Hnggh... ahh!"

    scene end-273
    z "Shut up and take it! Every inch for Farid! You're so fucking tight... clamping down on me like a vice. I’m going to wreck this ass till you can’t walk!"
    b "Ahh! Ahh! Curse you... I'll gut you both... nghh! Too big..."
    ta "Look at her, Zaur—eyes watering under that black hijab while you plow her. She’s taking every bit of your rage. Fuck her harder!"
    z "I’m hitting your womb with my head, you hijabi slut! Swallow it! Grip my cock with that murdering asshole!"
    b "Mmmph! G-gah... too much... stop... hrrrk!"
    scene black with dissolve
    "..."
    z "Sit on it, you murdering bitch! Down, down! Let the glass bottle stretch you wider than your knife split Farid!"
    b "Nooo! Too big! It's going to tear me apart! Ahhh! Glug! Stop! It's too wide!"

    scene end-274 with dissolve
    ta "Good girl, sit on it. Feel that cold glass inside you? That's what you get for killing our brother."
    b "Glug! It's going to burst! No!"
    scene end-275
    z "Sit on it, you murdering bitch! Don't stop now! You stabbed Farid in the chest, you can take a bottle up your ass! Down, down!"
    b "Nooo! It's too big! Stop!"
    ta "Hold her head down, Zaur. Make the bitch take it. Farid would want to see this, you know he would."
    scene end-276
    b "Gaaah! Too deep! Ahhh! It's stuck! Glug! I can't move! It hurts! You bastards!"
    z "Deeper! Squeeze your ass muscles around it! Make that bottle disappear inside you!"
    b "Nghh! I can't! It hurts! Ahhh! Glug! Please stop! I'm going to die! No!"

    scene black with dissolve
    z "Lick it, you murdering slut! Suck my cock while Tarik wrecks your ass!"

    scene end-277 with dissolve
    b "Too big! Nghh!"
    ta "Hold her head down, Zaur! Make the bitch take it! Feel my cock stretching your asshole?"
    z "Lick my balls while he fucks you raw! You're our double-stuffed whore now!"
    scene end-278
    b "Mmmph! Gluck! Stop! Too full! Ahhh!"
    b "GRRRK! Mmmph! Glug! Your dick tastes like rotten goat cum! Nghh! Too nasty!"
    ta "Feel my balls slapping your clit?"
    b "Cum-farting already... you diseased pigs! Hrrrk!"
    z "Tongue-fuck my asshole next, murderer bitch!"
    scene end-279
    stop sound
    ta "Shit, her ass is milking me like a vice! Cumming buckets in your traitor bowels, Banu – paint that hijab with ass-to-mouth cream pie!"
    b "Nghh! Too much... stop! It's overflowing... hrrk!"
    z "Don't you dare spit a drop, you murdering slut! Swallow every bit."
    z "Move over, Tarik. I’m claiming the back door. This tight hijabi ass is mine."
    scene end-280 with fade
    $ renpy.sound.play("voices/moaning.mp3", loop=True)
    ta "There... a gift from Farid's brothers. Your 'holy' ass is full of our hate now, you murdering bitch."
    ta "How does it feel, Banu? Knowing you're carrying Tarik's revenge inside that tight little hole?"
    b "Hah... hah... you're both... dead men walking... cough... I'll see you in hell with Farid."
    z "Still got that tongue, huh? Let’s see if it’s as sharp as your knife when I’m finishing on your face."

    scene end-281
    ta "Fucking tight pussy... gripping me like she wants to keep me forever! Taking every drop, murderer!"
    b "Nghh! Too much... stop!"
    ta "Go for it, Zaur. I’ve got her pussy stretched wide open for you. Let's fill every hole she has."
    b "No! Wait! You'll rip me apart! Gaaaaah!"
    scene end-282
    z "Hah! Listen to her scream, brother! I'm sliding right past you. My cock is rubbing against yours through her thin walls."
    ta "She's so fucking tight. We're stretching her into a true whore now. How’s that feel, Banu? Being stuffed like a thanksgiving turkey?"
    b "Nghhh! It hurts... stop! I can't breathe... too full! Ahhh!"
    z "I can feel her clenching. She hates it, but her body is milking us dry. I’m gonna flood this traitorous ass!"
    ta "Me too. I’m hitting her cervix, Zaur. I’m gonna plant a seed of hate right in her womb."
    b "Don't... don't cum inside! Please! Hrrrk!"

    scene black
    ta "Shut that murdering mouth of yours, Banu. I'm tired of your curses. Let's see if those lips can do something besides spit venom."
    b "N-no... stay away... mmph!"

    scene end-283 with fade
    "Tarik crashed his lips against hers, a brutal, demanding kiss that tasted of iron and salt. At the same time, Zaur slid down between her trembling thighs."
    z "Forget her mouth, Tarik. I’m going for the source of all this trouble. Let’s see how 'holy' this pussy tastes after we’ve wrecked it."
    b "Mmmph?! Nnnngh! *Gasp*"
    "As Zaur’s tongue lashed against her sensitive clit, Banu’s body gave a violent jerk. The combination of Tarik’s suffocating kiss and Zaur’s relentless licking was too much."
    scene end-284
    ta "Mmm... look at her, Zaur. Her eyes are rolling back. She’s fighting the kiss, but her hips are starting to sway for you."
    z "Slurp... gluck... she’s soaking wet now. For all her talk of God and hijabs, this killer pussy is begging for more."
    b "Hah... hah... stop... please... I can't... *moan*... NO!"
    ta "That's it, Banu. Melt for us."
    b "Nghhh... ahhh! My legs... they're shaking... I feel... *liquid*..."
    z "She’s peaking, Tarik! I can feel her pussy walls pulsing against my tongue. The little hijabi assassin is coming for the men she hates!"
    b "GAAAAH! Nooo! I... I’m... *spasm*... AHHH!"
    "Her body arched off the ground, a strangled cry lost in Tarik’s mouth as she finally broke, her spirit drowning in the very pleasure she had tried so hard to deny."


    scene black with dissolve
    "The sun dipped below the horizon, casting long, jagged shadows across the lake."
    "The air grew cold, but the heat between the three of them was stifling, fueled by a dark, relentless cycle of revenge and raw physical dominance."
    scene end-285 with dissolve
    ta "Keep your foott on the ground, Banu! I’ve got your waist locked. You're not going anywhere until I'm finished with this pussy."
    z "And don't forget about me, you hijabi slayer. Your mouth is looking a little lonely while Tarik's busy behind you."
    b "Hah... hah... *gasp*... please... my legs are shaking... I can't... *gulp*..."
    scene end-286
    ta "Shove it in, Zaur! Make her work for her life! I’m going to ram this pussy until she forgets how to speak!"
    z "Open up, you murdering slut! Wrap those lips around my shaft while my brother stretches you from the other side!"
    b "Mmmph! Gluck... slurp... hrrrk!"
    scene end-287
    "The rhythm was primal, a standing execution of her pride. The sound of wet slapping and muffled gagging echoed through the darkening woods."
    ta "I’m close, Zaur! I’m gonna flood her! I’m gonna leave a mark she can’t wash away!"
    z "Do it! I’m right behind you! We’re gonna fill her to the brim, front and back!"
    b "A-ahhh! Mmmph! AHHH!"
    ta "Enough with your pussy, Banu. I’m bored of this hole. Time to plug that tight hijabi asshole of yours for real this time."
    scene end-288 with flash
    b "No! ...please! It’s still burning... you’ll tear me open! Ahhh!"
    z "Shut her up, Tarik! I’ll hold her head while you wreck her from behind. She needs to feel every bit of Farid’s pain."
    ta "Brace yourself, you murdering bitch! I’m going in dry! I want you to feel every inch of my rage stretching you out!"
    b "GAAAAAH! NOOO! It’s splitting me! Stop! Please... *hrrk*... too big!"
    z "That’s it, brother! Shove it in! Look at her eyes—they’re bulging just like Farid’s did when she stuck the knife in him!"
    ta "I'm blowing! Every bit of my hatred is flooding your fucking soul, Banu! GAAAAH!"
    z "ME TOO! Taking it all, you murdering bitch! Deep-throating our revenge while Tarik wrecks your ass! UGGGHHH!"
    b "GAAAAAH! *spasm* ... Hrrrk!"
    stop sound

    scene black with dissolve
    "Silence fell over the clearing, save for the ragged breathing of the two men and the distant lap of the lake's water against the shore."
    "Tarik and Zaur walked away from the clearing, their figures silhouetted against the moonlight."

    scene end-289 with dissolve
    ta "Fucking hell... that was... something."
    z "She deserved every bit of it, brother. More than that. We finally gave Farid his peace."
    scene end-290
    ta "Her body was covered in it, Zaur... head to toe. I've never seen anyone take so much."
    z "Yeah, well, she won't be taking any more. Not where she's going."
    ta "What do you mean? She's still back there... right?"
    scene end-291
    z "I made sure she wouldn't follow us, Tarik. I kept my hand on her throat until she stopped fighting. Until the light finally went out for good."
    ta "You... you killed her? Zaur, we were just supposed to break her... to show her who's in charge."
    z "She's dead, Tarik. The hijabi assassin is gone. Farid is avenged. That's all that matters."
    ta "I don't know, Zaur... she was a mother. People will come looking. The police..."
    z "Let them come. We're Farid's blood. We don't fear some ghosts. Now, let's get out of here before the sun comes up."
    "Tarik looked back toward the dark woods one last time, a flicker of unease crossing his face before he followed his brother into the night."
    scene end-292 with fade
    "The clearing near the abandoned lake returned to a chilling, unnatural silence, broken only by the rustle of the wind through the pines."
    "Banu lay where they had discarded her, a broken monument to a revenge that had finally reached its gruesome, irreversible end."
    scene end-293
    "Her eyes, those once-fierce, dark eyes that had held the fire of a mother's justice, were now wide and bulging, staring unseeingly at the indifferent stars above."
    "The blood vessels had burst during Zaur's final, murderous grip, leaving the whites a horrific, bloodshot red that glittered glassily in the moonlight."
    "Her face was a grotesque canvas of their depravity. Thick, white streaks of the brothers' 'justice' were drying across her forehead, her cheeks, and matted deep into the fibers of her torn hijab."
    "It looked like a mockery of war paint, a permanent brand of her total submission in death, masking the woman she had once been."
    scene end-294
    "Her body was a ruin of cooling flesh and drying fluids. The sticky, white sheen of their 'victory' covered her breasts, her stomach, and pooled in the dark bruises on her hips."
    "And there, between her cooling, trembling thighs, her pussy and ass remained agape—stretched beyond recovery by the double-penetration that had claimed her final breaths."
    "The thick, white evidence of Tarik and Zaur's rage continued to leak out, a slow trickle of 'revenge' that soaked into the damp earth beneath her."
    "She was no longer a mother, a warrior, or a hijabi—she was just a used-up, discarded shell, left to rot in the shadows of the world she had tried to cleanse."


    stop music
    scene ending_8 with dissolve
    "..."
    "..."

    dev "{color=#ffffff}Thank you for playing! YOU'VE REACHED ONE OF THE ENDINGS!. Play again to discover more. If you enjoyed it, please {a=https://www.patreon.com/lustfulfantasy}support{/a} the development. Wishlist our new game here {a=https://store.steampowered.com/app/4056530/Banu_in_the_West/}Banu in the West{/a} {/color}"
    hide screen faith
    hide screen angeldevil
    $ renpy.end_replay()
    $ persistent.powerending_unlocked = True
    jump endings
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
