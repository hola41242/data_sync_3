



label day5:
    scene day5-1 with blinds
    play music3 "sfx/bar.mp3"

    sa "Nat, you're forgetting the beers."
    nat "Ohh, I thought all of them were served."
    scene day5-2
    sa "That table..."
    nat "Хорошо.."
    sa "And Nat, remember we don't talk to customers in Russian. They may get irritated from this sometimes."
    nat "I am trying to get used to this language.."
    sa "I know baby, now serve the beers. We'll have a lot of customers soon. "
    nat "Okay."
    scene day5-3 with dissolve
    nat "Your beers, gentlemen. I will bring your fish and chips now."
    guy1 "Would you bring us two hotdogs too? My friend is hungry here."
    scene day5-4
    nat "Sure. Two hotdogs, anything else?"
    guy1 "And your number."
    nat "Что?"
    guy1 "Your telephone number."
    nat "No no, never."
    guy1 "Why not?"
    guy2 "Just let her go. I think she has a boyfriend."
    nat "Your friend is right."
    guy1 "So what? Doesn't he like to share?"
    nat "Sorry, I don't chat with customers. Do you need anything else?..."
    scene day5-5 with fade
    sa "I know what you're trying to say. It's a little bit difficult for her to get used to working here, but she's trying really hard, and besides, she's very skillful and has so much experience in this field, as I told you before."
    p "I know, Sasha. Your girlfriend is a perfect girl, but you know that here it is really different from Russia. She must be very polite and understanding with customers. You know this is how it works."
    sa "Yeah, I got it."
    p "What about that guitar player we talked about last time?"
    scene day5-6
    sa "He's free and willing to work with us. "
    p "Good. Tell him not to worry about the money. I liked his voice. Live music will bring us more customers."
    sa "Sure it will..."
    stop music3
    scene black
    "..."
    scene day5-7 with wiperight
    play music3 "sfx/washing.mp3"

    b "{i} {color=#526168}A woman's work at home never ends. At least it makes me busy and forget about my problems. {/color}"
    b "{i} {color=#526168}But it’s kinda boring today.{/color}"

    scene day5-8
    b "{i} {color=#526168}I should wash these first.. {/color}"
    b "{i} {color=#526168}I don't know why life seems meaningless for me recently.{/color}"
    b "{i} {color=#526168}I need more support...{/color}"
    b "{i} {color=#526168}Leyla is my only hope in life. Her happiness also makes me happy. {/color}"
    b "{i} {color=#526168}I feel Kamil's affection towards me, but he doesn't show it with his behavior. {/color}"
    k "Banu..."


    scene day5-9
    b "Hey.."
    k "Do you know where Ruslan is? I haven’t seen him at home for days."
    b "No. I have no clue what he's doing. He doesn't share anything with me."
    scene day5-10
    k "Banu, I'm really sorry for his behavior. He's always been like that."
    b "I'm okay with that, don't apologize."
    scene day5-11
    k "Come on, don't be sad like this all the time. Just forget about the misfortunes of the past."
    b "I can't forget things easily. Overthinking, this is my problem."
    k "Just think about positive things. For example, think about the new clothes I'll buy you today. "
    scene day5-12
    b "Really?"
    k "Of course. I know that you're working so hard both at home and at work. I think we need to go out more often."
    b "I thought you would be busy today. What about your clients? I don't want you to lose them."
    k "I didn't know you were interested in my work, but for me nothing is more important than you."
    k "Come here..."
    scene day5-13
    $ kamilgrabbedherhand = False
    b "Kamil..."
    k "I know that I've not been an ideal husband. "
    b "No. That's not true."
    k "I haven't made you forget your...your past."
    k "But I'm not going to give up. Maybe, we can do something to start a new life without our past, like a real family."
    b "Kamil.."
    k "Just accept me. Let me take care of you. It's high time you stopped resisting me."
    k "Let me make you mine..."
    b "Kamil, I need to go change. We'll be late otherwise..."
    scene day5-14
    menu:
        "Kamil lets her go":
            $ kamilgrabbedherhand = False
            $ kamilbeta += 1
            $ renpy.block_rollback()
            scene day5-15
            "{i} {color=#526168}Kamil just let her go without saying anything. {/color}"
            "{i} {color=#526168}It seemed the best option for him at that moment. {/color}"
            k "{i} {color=#526168}I shouldn't press her so much. I just need to spend even more time with her and let time settle everything for us... {/color}"
            stop music3
        "Kamil grabs her hand":





            $ kamilgrabbedherhand = True
            $ renpy.block_rollback()
            $ banu_kamil += 1
            $ lust += 1
            play music "audio/sensualsex.mp3"
            scene day5-16
            k "Just come here. I’ve had enough of you running away from me all the time."
            b "Kamil, what..."
            scene day5-17
            b "Mmmmm.."
            b "..."
            scene day5-18
            b "mmm.."
            b "..."
            k "Let's take this off..."
            scene day5-19
            if spykamil == True:
                k "I noticed you that day. You were looking at me in the shower."
                k "You can't deny it. But you don't need to say anything. Let's enjoy this moment."
            else:
                k "I know you think of me in the way that I think about you. I feel it all the time."
                k "You can't deny it. But you don't need to say anything. Let's enjoy this moment."
            scene day5-20
            b "Kamil, stop it....not here."
            k "Not here?"
            b "I mean...I'm not ready for this yet."
            b "Mmmmm.."
            k "Your body likes it obviously."
            b "Kamil, I'm not ready yet..."
            k "Banu, just let me..."
            stop music

            scene day5-21
            b "Kamil, I need to go change. We'll be late otherwise..."
            k "Okay, take your time."
            k "{i} {color=#526168}I shouldn't press her so much. I just need to spend even more time with her and let time settle everything for us... {/color}"
            stop music3






    scene black with dissolve
    "..."
    scene day5-61 with dissolve
    "..."
    scene day5-62
    play music3 "sfx/bar.mp3"
    sa "Here's your beer. Do you need anything else?"
    guy "Yes, actually. I would like to reserve a table for five people at 9pm, but a private place and not noisy. Is that possible?"
    sa "Yeah, we have a room in the back. I'm sure it'll be suitable for you."
    guy "Good. What about the meals? Do you serve Xingal?"
    sa "Unfortunately not."
    guy "What about Kabab?"
    scene day5-63 with dissolve
    "..."
    scene day5-64 with dissolve
    "..."
    scene day5-65 with dissolve
    guy1 "{i} {color=#526168}I told you they’d lose the second match. {/color}"
    guy2 "{i} {color=#526168}You were right. {/color}"
    stop music3
    scene day5-66

    guy1 "Here are the beers. How are you, Natasha?"
    nat "Thanks, what about you? I see you often here."
    guy1 "I live in this neighborhood."
    guy1 "Why don't you bring a chair and join us? That would make us happy."
    guy2 "Definitely."
    scene day5-67
    nat "You know, I am not allowed to drink with customers and I have work to do."
    nat "Так что, нет."
    guy1 "Come on. We're regular customers. Just spend some time with us. We don't see beautiful girls like you often."
    guy1 "Come here."
    scene day5-69
    nat "Males here are full of compliments. It is really different from the city where I lived."
    guy1 "We're telling the truth. Isn't she the most beautiful girl we've ever seen?"
    guy2 "Yes. Definitely the prettiest girl in the whole city."
    nat "Wow, thank you, guys, you're making me blush."
    scene day5-70
    guy1 "You're in a very good shape. Tell me, how often do you go to the gym?"
    nat "No. I don't have time for that."
    guy1 "So, it is all about genes."
    nat "But I see you attend quite often."
    guy1 "Yes. I have the strongest abs. Do you want to check them?"
    nat "No. I believe you."
    guy1 "Don't be shy, touch them."
    scene day5-71
    nat "Wow, такие powerful."
    nat "You are so strong."
    guy1 "Does your boyfriend have abs like this?"
    nat "Not really. He is lazy when it comes to working out."
    guy1 "Now go down. You will find even harder muscles."
    nat "What do you mean?"
    guy1 "You know what I mean."
    nat "I need to go, guys. I have a lot of work."

    if agressive == True:
        scene day5-72
        play music "audio/action.mp3"



        guy1 "Wait, don't you want to show me something in return?"
        nat "Hey, what are you doing? Take your hand off me."
        guy1 "I want to just see your titties. That's it."
        nat "No. This is too much. I said take your hand off me."
        guy2 "Come on, kiss her. She won't reject it."
        scene day5-73
        nat "Hey, what are you doing?"
        sa "Hey, get away from her now."
        scene day5-74
        sa "How dare you?"
        sa "Come here, Nat."
        scene day5-75
        sa "She's my girlfriend and she said no. Do you have problems with your ears?"
        guy1 "Hey, man I don't care if she's your girlfriend or not, but now you are the fifth wheel, let us have fun. Get out of here."
        sa "Who do you think you are? You should learn to respect others first."
        guy1 "Hey, watch your tone when talking to me. You are both workers here and she is serving us now. Now get your ass out of here."
        sa "No. It is you who will get out of here. You fucking pig."
        guy1 "What did you call me?"
        scene day5-76 with hpunch
        guy1 "You little shit...Take this."
        nat "Боже мой, пожалуйста, перестань.."
        guy1 "Shut up, fucking bitch."
        guy2 "Calm down, man, calm down. Let's get out of here."
        guy1 "This little shit clearly considers himself to be a man, time to show him how wrong he is."
        scene day5-77 with vpunch
        p "Hey, what's going on? You, what are you doing?"
        guy2 "Please, calm down. We had no bad intentions. This is just a misunderstanding."
        scene day5-78
        guy1 "Don't dare to touch me again. Your workers can't behave appropriately."
        p "You’re in MY place now, remember that! Nothing gives you the right to treat someone like this."
        p "Now will you tell me what happened here?"
        guy1 "You can ask your employees after we leave..."
        guy1 "Let's go..."
        stop music
        scene day5-79 with dissolve
        "..."

    scene black with dissolve
    "..."





    scene day5-22 with fade
    l "{i} {color=#526168}At least I can find some time to be alone and away from those negative people. {/color}"
    l "{i} {color=#526168}They are all driving me crazy.{/color}"
    l "{i} {color=#526168}Locking me at home all day long, what kind of stupid punishment is this? I won't let them treat me like this.. {/color}"
    l "{i} {color=#526168}At least I make myself busy with soap operas... {/color}"
    scene day5-23 with fade

    l "What are you doing?"
    r "Well, fun is over. The match will start in a few minutes."
    scene day5-24
    l "Can't you see that I'm watching the soap opera here. This is my favorite one."
    r "I don't care."
    l "Give me the remote control."
    r "Won't you stop bothering me? The match is starting now."
    scene day5-25
    l "What about my soap opera? I can't miss it."
    r "You can watch later on the internet."
    l "Why are you an asshole like this all the time?"
    r "Watch your mouth and get out of here. You can watch your soap opera in the kitchen."
    l "Then why don't you watch your fucking football match in the kitchen?"
    r "Will you shut your mouth?"
    scene day5-26
    l "No. It's your time to shut up."
    l "Remember, we're living together. You're not the boss here. Do you understand?"
    scene day5-27 with hpunch
    r "I said shut your fucking mouth, slut."
    r "Stop getting on my nerves."
    scene day5-28
    l "What did you call me, pig? I am your sister."
    r "My step sis. And this doesn't change the fact that you're a slut."
    l "Stop calling me that."
    r "What? You think that I'm a fool? I know that he didn't rape you, you wanted it. "
    l "That’s bullshit!"
    r "Because of you, most of my friends don't say 'Salam' anymore. They don't want to spend time with me just because they know about you. "
    l "You know what, fuck you and your friends."
    scene day5-29
    l "Our parents will know about this."
    r "Just do what you want and leave me alone.."
    l "..."
    stop music
    scene black with dissolve
    "..."

    scene day5-30 with wiperight
    play music "audio/chill.mp3"
    play music3 "sfx/store.mp3"
    k "You look so beautiful in this dress. Did you know that?"
    b "Thank you. You're always attentive."
    k "Take your time. We're not in a hurry. "
    scene day5-31
    b "These skirts look so beautiful. I'd like to try them."
    b "But, unfortunately, I have a lot of skirts already, so I don't want to waste money on these."
    k "Don't worry about that. Just choose anything you want. I want to spend money on my wife. "
    b "You are so kind."
    b "Will you buy anything for yourself?"
    scene day5-32
    k "Not actually. Maybe I'll check out these jeans. I like their color."
    scene day5-33 with fade
    stop music
    b "{i} {color=#526168}These T-shirts are so nice. Maybe I can get one for wearing at home. {/color}"
    b "{i} {color=#526168}But it seems that I won't be able to find my size. {/color}"
    b "{i} {color=#526168}Looks like no T-shirts left with M size... {/color}"
    scene day5-34
    sel "{i} {color=#526168}She’s a beauty. I’d try my chance with her, but she looks like a proper woman.{/color}"
    sel "Hi, do you need any help?"
    b "Ohh..."
    scene day5-35
    b "Yes, actually. I liked these black T-shirts, but I couldn't find M size. "
    sel "Unfortunately, they're all sold out."
    sel "Would you like to try the white ones? I'm sure that they'll look good on you."
    sel "White will even suit your cute face the best."
    b "Thank you. Yeah, why not? It doesn't make much difference for me. They're just so comfortable. "
    sel "Definitely, the best option for wearing at home."
    $ kamilgotangry = False
    scene day5-36
    sel "Just a second..."
    sel "..."
    sel "{i} {color=#526168}I wonder if this sexy woman will let me help her try it on. {/color}"
    scene day5-37
    sel "Look, you can try this. If you want, I can find different ones with different patterns on it."
    sel "There is no chance for this T-shirt not to suit your beautiful body, but I should come with you to make sure..."

    scene day5-38
    "{i} {color=#526168}The situation got a little bit awkward among them. {/color} "
    "{i} {color=#526168}Banu knew that Kamil didn't like the seller at all, but she wasn’t bothered by him.{/color}"

    "{i} {color=#526168}She wasn't offended by the seller's words, rather, she found that she was enjoying them. She certainly wasn't used to hearing them very often. {/color}"
    "{i} {color=#526168}Kamil on the other hand, was very angry at the seller's behavior. {/color}"
    "{i} {color=#526168}His next action could affect the relationship between him and Banu. {/color}"
    menu:
        "Kamil gets angry":

            $ kamilgotangry = True
            $ renpy.block_rollback()
            $ banu_kamil += 1

            scene day5-39
            k "Hey, watch your words! This's not the right way of talking to customers."
            b "Kamil, please, he's just trying to be nice."
            k "But he shouldn't make comments like that."
            sel "I'm so sorry, but there's no reason for being so nervous. This is considered just a polite way of talking to customers."
            scene day5-40
            k "But not to a married woman, especially when she's with her husband."
            b "Kamil, please, stop it."
            sel "Look, I didn't really know that she was your wife, I'm really sorry."
            k "Be careful next time."
            sel "..."
            k "Come on, we're going..."

            scene day5-41
            "{i} {color=#526168}Banu was embarrassed, but at the same time was very proud of her husband. {/color}"
            "{i} {color=#526168}His manly behavior impressed her a lot. {/color}"
            "{i} {color=#526168}She even felt a stronger connection with Kamil after this incident... {/color}"
            stop music3
        "Kamil stays calm":



            $ kamilgotangry = False
            $ kamilbeta += 1
            $ renpy.block_rollback()

            scene day5-42
            "{i} {color=#526168}Despite that he was angry, Kamil preferred to stay calm in order not to embarrass Banu... {/color}"
            scene day5-44
            b "{i} {color=#526168}Perhaps I should leave to avoid an incident.{/color}"
            b "I do like the shirts, but I’m not ready to buy anything today."

            sel "You know, our new products arrived just today. Just visit us again. I will show you dresses with hijabs in a variety of colors."
            b "Really? I’m interested."
            sel "Additionally, you can shop with a special discount. "
            b "That’s good news. You’re being so nice."
            sel "Well ...."
            scene day5-43
            "{i} {color=#526168}Banu was so busy in the conversation with the seller that she forgot she was with her husband. {/color}"
            "{i} {color=#526168}This man's cute smile, handsome face, confident voice and compliments made her forget everything and indulge in the conversation with him. {/color}"
            "{i} {color=#526168}Kamil obviously didn't like what was happening, but he also didn't cut their conversation. {/color}"
            sel "I only give special discounts to women who’d look amazing in our clothes. It’s good for advertising."
            b "You’re making me blush. I’ll come visit again then."
            sel "Please see me when you arrive. With so many items to buy, I’ll definitely need to take your measurements."
            b "Ok then, goodbye."
            "{i} {color=#526168}Banu smiled at the seller, since Kamil was being passive.{/color}"
            stop music3




    scene black with dissolve
    "..."
    scene day5-45 with fade
    k "There's a problem with the car, dear. Recently I heard strange noises from the engine. I need to quickly show it to the mechanic."

    b "Okay, I’ll walk home from here. We're almost home anyways."
    k "Are you sure?"
    b "Of course, I can go from here."
    k "Okay, but be careful."
    scene day5-46
    b "Don't worry about me. Just drive safe."
    k "Okay."
    if streetguys == True:
        scene day5-47 with fade
        b "{i} {color=#526168}This is the shortcut to the building. {/color}"
        b "{i} {color=#526168}I could've taken the other usual route, but I'm so tired and don't want to walk a lot. {/color}"
        b "{i} {color=#526168}I'll probably take a hot shower and go straight to the bed. {/color}"
        scene day5-48
        play music "audio/tension.mp3"

        b "{i} {color=#526168}I hope they will fix the lights one day... {/color}"
        scene day5-49
        guy "{i} {color=#526168}I’ve been waiting for this bitch to walk by again. Now she will answer for slapping me. {/color}"

        guy "..."
        if agressive == True:
            scene day5-50 with hpunch






            b "Ahhhh...who are you? Don't touch me, you..."
            guy "Shut up, slut. You remember me, and I’ll make sure you never forget."
            b "Don't touch me, pig. Please, help me..."
            guy "I know how to shut your fucking mouth."
            scene day5-51
            guy "You look so sexy when you're choking."
            guy "Now let me taste you. You're so delicious. I'm dying to fuck you so hard. "
            guy "Now stop shouting. Nobody will hear you from here."
            guy "God, your body is so soft. You’ll regret slapping me now."
            scene day5-52
            b "Please, sto.....stop..."
            guy "Look at these tits. They are dying for someone to squeeze them hard."
            guy "Do you like it? Do you like when I squeeze your tit like this?"
            guy "Touch my dick in the pants. Come on, touch it. I know that you want it now. Don't stop yourself. I know that you're dripping wet now."
            guy "Why don't we check to make sure."
            scene day5-53
            b "Please, help..."
            guy "Wow, it's so hot down there."
            guy "Stop pushing me. If I want I'll fuck you right here and right now."
            guy "Turn around now. I'll let you feel my hard cock..."
            scene day5-54
            guy "Do you feel it? Do you feel my rock hard cock touching your pussy from behind?"
            b "Ohhh.."
            guy "What? You're moaning already. You see that? You want it. You want me to fuck you now, don't you?"
            scene day5-55
            b "You....you will go to the jail for this..."
            guy "Do you think so? Maybe, but after I fuck you so hard and make you cum."
            scene day5-56
            guy "My cock has never been so hard like this..."
            b "What...what are you doing?..."
            guy "You want it. Your body is not resisting anymore..."
            un "Hey, you. Let her go!"
        else:

            scene black with dissolve
            b "Ahhhh...who are you? Don't touch me, you..."
            un "Hey, you. Let her go!"




        scene day5-57 with hpunch
        stop music
        un "Don't run! Stop right there!"
        scene day5-58

        un "Are you alright, Banu?"
        b "Wait... are you Ahmed?"
        ah "Yes, we're neighbors."
        scene day5-59
        ah "I think I know that guy. He’s a criminal. We've arrested him once."
        ah "Looks like he didn't change, leopards don't change their spots."
        scene day5-60
        ah "I’m off-duty now, so you’ll have to come to the police station tomorrow morning. Just ask for my room and they’ll show you, okay?"

        b "I guess I should write a complaint letter."
        ah "You should. I’ll walk you home, Banu."



    scene black with dissolve
    "..."
    scene day5-80 with fade
    r "{i} {color=#526168}I wonder where she is now... {/color}"
    scene day5-81
    r "I'm sure you have a reason for ignoring my calls."
    s "I'm just busy."
    r "You're so busy that you don't have time for me?"
    scene day5-82
    s "I'm sorry, Ruslan, but I have more important work now. You can call me later."
    play music "audio/arab.mp3"
    scene day5-83
    s "Waiting for me?"
    ar "Yes"
    scene day5-84
    ar "Dance. Dance for me. I want you to dance."
    s "You want me to dance for you, dirty man?"
    ar "Yes, dance."
    scene day5-85
    s "Do you like it?"
    ar "Yes, dehbu delika..I like you..."
    scene hoteldanceback1
    show hoteldanceanimation1
    ar "Yes, jamila. I like it."
    ar "Keep dancing..."
    s "Like this?"
    ar "Hasan jiddaan..."
    scene hoteldanceback2
    show hoteldanceanimation2
    ar "Very good...very good.."
    ar "You dance very good..."
    s "Do you like me?"
    ar "I like you..I like you very much..."
    s "..."
    scene day5-86 with fade
    s "Do you think that I'm beautiful?"
    ar "Yes, you are so beautiful..."
    scene day5-87
    s "Do you want me to suck your cock?"
    ar "No no no.."
    ar "I want fuck...I want fuck..."
    s "{i} {color=#526168}As I thought... {/color}"
    scene day5-88 with fade
    play music2 "voices/moaning.mp3"
    "..."
    scene day5-89 with dissolve
    "..."
    scene day5-90 with dissolve
    "..."
    scene day5-91 with dissolve
    "..."
    stop music2
    stop music
    jump day6
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
