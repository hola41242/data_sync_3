label abdul_sexting_banu:


    scene v15-179

    "Banu hesitated at first but then so tempted to comply with what Abdul asked."

    "She quickly put on a smiling sexy face and took a photo of herself from the best angle to show most of her naked body. "

    scene v15-180 with fade

    b_ "What do you think of this?"

    ab_ "Wow! You're damn sexy Banu."

    ab_ "You're such a lewd woman."

    ab_ "I can't wait to grab those tits and cum all over this beautiful body."

    scene v15-181

    b_ "Hey, you're going too fast and pay attention to your words."

    b_ "I'm not that type of woman, you know?"

    ab_ "Sure...but I can't wait to see you again."

    b_ "Then why don't you come over?"

    ab_ "I'll definitely come soon to play nard with Kamil."

    b_ "Good idea!"

    scene v15-182 with fade

    "Glancing over at her husband, sound asleep beside her, Banu felt guilty for having talked to Abdul while he was right there next to her."

    "As she tried to calm her racing thoughts and settle down for the night, she couldn't shake off the lingering feeling of discomfort."

    "She knew she must never let her husband know about it, but for now, all she could do was try to push it aside and get some much-needed rest."





    $ renpy.end_replay()
    $ persistent.abdul_sexting_banu_unlocked = True
    jump banu_send_abdul_nude_continue


label banu_humiliates_ruslan:

    scene v15-195 with blinds
    play music "audio/action.mp3"
    "Late at night, Banu silently entered Ruslan's room after Kamil had gone to sleep. "
    "She knew Ruslan was waiting for her as they agreed before."
    "But she had another plan for Ruslan for this night..."
    scene v15-196 with fade
    "Banu was not surprised seeing Ruslan laying naked on the bed waiting for her, because she knew how terrible he was."
    "By looking at Ruslan's member down there, Banu was instinctively impressed although she had seen it before."
    "She tried not to stare at Ruslan's body, rather acted bold and confident."
    scene v15-197
    b "Well, I'm here as we agreed."
    r "But you're forgetting something. Why didn't you wear the lingerie that I gave to you?"
    b "Do you prefer me with lingerie or...."
    scene v15-198
    b "Without it?"
    r "I see you came prepared..."
    scene v15-199
    b "Just wait a little bit and you'll see what I prepared for you."
    r "I waited for this moment for so long, Banu."
    r "I can't wait any longer to see your sluttly naked body. "
    scene v15-200
    b "That's not the right way to talk to your mother, you little pervert."
    r "What about you teach me?"
    scene v15-201
    r "When did you start to grow that bush down there."
    r "I've seen you naked before. This must be something new."
    b "That's not your business, is it?"
    b "Besides, it's not appropriate to look at your mama's private spot. Am I right?"
    r "You better shut your mouth now and do what you came to do."
    scene v15-202 with fade
    r "Huh?"
    r "What is this?"
    b "You're a little pervert brat."
    scene v15-203
    b "When you were a little kid, you used to pull my skirt and ask money from me."
    b "Do you remember that?"
    b "You probably don't remember. You were so little."
    b "You haven't changed in my eyes even a little. "
    r "What are you talking about? "
    scene v15-204
    b "Do you think your naked body turns me on?"
    b "I remember the day when we got your penis circumcised."
    b "You were crying like a baby."
    b "But now you're a grown up man I see."
    scene v15-205
    b "You got really big down there."
    b "And I feel your balls boiling..."
    b "I can help you release your stress down there."
    b "But no touching, alright?"
    r "Hey, this's not what we agreed."
    b "Well, I'm afraid you have two choices."
    b "Either you obey my rules or you'll miss a nice show."
    scene v15-206 with fade
    b "You decide."
    r "Wait, you can't leave me like this."
    b "Of course I can."
    scene v15-207 with hpunch
    r "Do you think you can do that to me?"
    r "You know what..."
    scene v15-208 with hpunch
    r "I'll fuck you right now."
    b "Easy to say."
    r "Huh?"
    r "Mess with me one more time and I'll destroy your inside right here right now."
    scene v15-209
    b "You just can't do what you want."
    b "If you try to rape me, your dad will throw you in the street."
    b "You're just a nobody here."
    b "I won't tolerate your behavior any longer."
    b "If you don't shape up, I'll make sure your father kicks you out of this house. You'll be banished, and you'll have nowhere to go."
    b "You'll die on the streets."
    r "You can't just threaten me like that."
    scene v15-210
    b "I can and I will. You need to learn some respect and responsibility, or you're out of here. Do you understand me?"
    b "Good. Now sit down on the bed and do what I say."
    scene v15-211
    b "I see you get it easily."
    b "You understand that I can be so dangerous for you in this house."
    b "But I'm not so cruel to leave you like this."
    b "I'll help you to release your stress."
    b "Now put your hand around your cock and start stroking."
    scene v15-212
    r "No. I can't do that."
    b "Just do what I say or I'll leave you with your blue balls here."
    b "I see how hard you got. "
    b "I know you want to cum so bad now."
    b "Now I wany you to jerk off your cock looking at my nude body."
    b "Star now!"
    scene v15-213
    stop music
    b "Good boy."
    b "Go all the way up and down."
    b "I know how bad you want to fuck right now."
    scene v15-214
    b "And you want to fuck me, don't you?"
    b "You see? I'm not so pure mama. "
    b "Your dad doesn't know everything about me."
    b "But now you know me and what happened between us will stay between us."
    b "You can look at my body but you can't fuck me."
    b "Now jerk off your cock faster."
    scene v15-215
    b "I make your dad cum in no time with this body."
    b "He just can't hold it after two minutes."
    scene v15-216
    b "And his penis is moderate, you know?"
    b "I mean it's not that bad but..."
    scene v15-217
    b "I had bigger cocks inside of me."
    b "Now what do you think of me? "
    b "Would you believe if I tell you that your dad is not the only man fucks me?"
    r "Ohhh shit...I knew that bitch..."
    scene v15-218 with dissolve
    b "I know..."
    b "Do you know how many young boys like you want to fuck me?"
    b "Come on, jerk off faster."
    b "I know you're about to cum."
    scene v15-219
    b "Think about fucking me from behind."
    b "Does it feel good masturbating while looking at your mama's private parts?"
    r "Ohhh shittt..."
    scene v15-220 with vpunch
    r "Ohhhhhh..."
    r "Shit!"
    b "Wow..."
    scene v15-221
    b "You came a lot."
    b "Look at you. Everywhere smells cum here."
    b "Men are disgusting."
    scene v15-222
    b "Come on stand up and clean your room."
    b "You're wothless. Just like your father."
    b "You can't hold it either."
    b "You're pathetic."
    $ renpy.end_replay()
    $ persistent.banu_humiliates_ruslan_unlocked = True
    jump ruslan_rapes_banu_continue


label ruslan_rapes_banu:

    "Banu was finally here as she agreed to meet Ruslan in his private place."
    "Banu took a deep breath and slowly pushed open the door."
    "She had been hesitant to come here but she knew Ruslan wouldn't let it go easily."
    "As she stepped inside, she couldn't help but be taken aback by the opulence of the room."
    scene v15-121
    "Ruslan was sitting on the edge of the white sofa."
    "She felt a wave of nervousness wash over her as she approached him, unsure of what he wanted to do with her actually."
    "Banu hesitated for a moment, feeling uneasy. She didn't trust Ruslan entirely - she had always been suspicious of his motives and his lifestyle."
    scene v15-122
    "But she knew that she couldn't back out now."
    "Although Banu was a bit afraid and nervous, she was trying to sound confident."
    stop music
    b "I'm here."
    r "You look beautiful as always. It's your evil beauty that made my dad blind."
    "Banu had always felt like Ruslan didn't like her, but she hadn't found an answer to her question yet."
    b "Ruslan, can we just talk for a moment?"
    r "What is it now?"
    b "Look we don't have to do this. Let's just end this nonsense."
    b "Look I can give you some money so you can change your phone or buy a new laptop if you want."
    b "I feel like you don't like me very much. And I don't understand why. I'm trying to be a good mother to you."
    scene v15-123
    r "Wow, you're just figuring that out now? It's pretty obvious, Banu. You never cared about my father or me."
    b "That's not true, Ruslan. I did care for your father."
    r "Spare me the lies, Banu. You were never there for us. You were always too busy with your own life to give a damn about us."
    b "That's not fair, Ruslan. I tried my best to be a real mother to you."
    scene v15-124
    r "Your best? Your best wasn't good enough, Banu. You never even bothered to get to know me."
    b "I'm sorry if I didn't live up to your expectations, Ruslan. But I'm here now, trying to make things right."
    r " Oh, well that changes everything, doesn't it? Too little, too late, Banu."
    scene v15-125
    b "You're being unfair, Ruslan. I want to make things better between us."
    r "Save it for someone who cares, Banu. I don't have time for your empty words."
    r "And don't waste my time. Start doing what you came here to do."
    scene v15-126
    r "Start taking your clothes off."
    r "But slowly. I want to enjoy the show."
    scene v15-127
    r "Yeah, this view is better."
    r "You can start now. I'm sure you wore what I bought for you. "
    scene v15-128
    "Banu had no choice. She knew it was pointless to try to convince Ruslan so she went for an easy way to manipulate Ruslan."
    "Fine, I'll do what you want but only for ten minutes."
    "I can't stay longer."
    r "Sure..."
    scene v15-129
    r "Wow, look at those cute little tits."
    r "I couldn't imagine one day you'd be stripping to make my dick happy."
    scene v15-130
    r "But your ass is the best."
    r "Do you know how many times I masturbated thinking about fucking you from behind?"
    scene v15-131
    b "So...what do you want now?"
    r "Stand still like that. I want to enjoy the view a little more."
    scene v15-132
    r "I knew you would come, Banu."
    r "Because, you're a dirty woman. You're not ashamed of stripping in front of your stepson."
    b "Stop it."
    r "That's true. "
    r "You've experience because you've been with a lot of men."
    r "Now take off that hijab too."
    scene v15-133
    b "Are you satisfied now?"
    r "Well, not yet."
    r "Come here. Get on the bed. "
    scene v15-134
    r "My dick is going to explode now just by looking at your sexy figure."
    r "Come and feel how hard you made me down there."
    scene v15-135
    "Banu was going to finish what she came for."
    "She started crawling towards Ruslan on the bed."
    scene v15-136
    b "You're just a despicable, naughty little boy, you know that?"
    b "You got yourself in trouble."
    b "I'm going to squeeze the last drop of your cum from your back. "
    r "You're such a tease."
    r "I envy my dad right now."
    b "In fact, your dad's just a loser you know."
    r "Huh?"
    scene v15-137
    r "What're you talking about? "
    b "He cums as soon as he puts it inside of me."
    b "He can't hold it. "
    b "I finish him in minutes. He ejaculates as soon as I talk dirty to him you know."
    b "I'm sorry but your dad's a weak man. He's pathetic."
    scene v15-138 with hpunch
    "Once Banu lowered Ruslan's short, she was again shocked by his big schlong."
    b_ "Shit, he's so big and veiny. "
    b_ "How could this even be possible? "
    b_ "This is so different from his father's dick. How his genetics can be this different from his father's. "
    scene v15-139
    r "What? Are you impressed?"
    b "No...I was just..."
    r "Do you think it's too big? I think you can handle it."
    b "Whatever."
    r "Start already. Show me what you can do for me."
    show banujerkoffruslanhotelanimation
    r "Wow...you're talanted Banu."
    r "I wonder where did you learn this skill."
    b "Stop talking nonsense, just focus."
    r "I like your face expression when you do this."
    r "You look so redicilous right now."
    b "Can you just shut up your mouth?"
    b "If you keep talking like that you won't enjoy it."
    r "Oh I see you care about me..."
    show banujerkoffruslanhotelanimationfast
    r "Ahhh....that feels good."
    r "Slow down a bit."
    b_ "Shit, my arms hurt...he's thing is too big and he's not planning to cum yet."
    b "Hey why don't you cum already?"

    r "Do you think you can make me cum so easily?"
    r "Your hands are not just enough."
    r "You'll have to use your mouth."
    b "What!"
    scene v15-140 with hpunch
    "Ruslan suddenly grabbed Banu's head and pulled it onto his cock."
    b "Hey! What're you doing?"
    r "It's time for the real stuff."
    b "I said let go of me!"
    scene v15-141 with hpunch
    b "What do you think you are doing?"
    r "We had agreement, did you forget that? You'll make me cum no matter what it takes."
    b "You're mistaking me with one of those sluts."
    b "How do you even dare to touch me? Pig!"
    scene v15-142 with fade
    b "If you touch me again, I'll break your hands."
    r "Where are you going?"
    b "This's over."
    r "Come back!"
    b "Go to hell!"
    r "..."
    scene v15-143 with hpunch
    play music "audio/action.mp3"
    r "Well, not this time, bitch."
    b "Hey....let me go...Your'e...choking me..."
    r "You're not going anywhere because I'm not satisfied yet."
    r "I've enough of you teasing me all the time."
    b "Rusl...."
    scene v15-144
    r "I hate you Banu. Do you want to know why?"
    r "Because you're a horny slut. I'm embarrassed when I hang out with the guys because they know about you."
    r "You wear like a slut and you act like a slut. My dad doesn't see who you're because he's in love with you. But I know everything about you."
    r "Once I saw Polad and you in our home. You didn't notice but I saw everything with my own eyes."
    r "He was feeling you up, touching your legs, groping your ass...but you didn't say a single word."
    r "Polad is no better man than me. Now it's my turn, Banu."
    scene v15-145 with fade
    "Ruslan firmly grabbed Banu and placed her down on bed."
    "His suddent and powerful moves scared the shit out of Banu."
    "She was choking and begging Ruslan to let her go but it was too late."
    scene v15-146 with hpunch
    b "Ahhhhh...."
    "After a few seconds he was already inside of Banu."
    b "Ahhhh...please slowly...it's too big."
    scene v15-147
    r "I loved you when I was a kid..."
    b "Ohhhhh..."
    r "But then you changed..."
    r "I saw how dirty you became."
    b "Slowly please...fuck me slowly..."
    stop music
    show ruslanrapebanuhotelanimation
    r "You treated me like a shit."
    r "You tell lies to my father."
    b "Oh my god, please...."
    r "You were teasing me all the time."
    r "Now I'll fuck the shit out of you."
    show ruslanrapebanuhotelanimationfast
    "Ruslan was getting more aggressive with each thrust."
    "He increased the pace and started choking Banu harder."
    b "Pleasee...Ahhhhh...I can't take it anymore..."
    r "You deserve to be treated like a slut."
    b "I can't breahe..."
    scene v15-148
    play sound "voices/moanfinish.mp3"
    b "I can't....brea...."
    r "Take this....Take this..."
    stop sound
    b "...."
    "Banu was silent and she was getting darker..."
    r "Yeah, that's it...."
    scene v15-149 with fade
    "Banu passed out laying there with all her body shaking and eyes rolling back."
    r "Let me just take my shorts of so I go all the way with your body."
    scene v15-150
    r "Hey, wake up."
    r "Don't make me to pee on your face."
    r "We have stuff to do."
    scene v15-151
    r "Hey, stop playing with me, bitch."
    r "I know how to wake you up."
    scene v15-152 with hpunch
    play sound "voices/slap.mp3"

    b "Ahhhh....cough, cough, cough..."
    stop sound
    b "..."
    scene v15-153
    b "What are you doing to me?"
    b "Please, let me go..."
    r "Shhh...we've not finished yet."
    b "What are you going to do?"
    r "..."
    scene v15-154
    "Ruslan fucked Banu for hours making her sweat all over."
    "She was screaming so loud letting the pain out of her body."
    "She understood that she couldn't go against Ruslan and nobody was going to hear her screaming."
    show ruslanshovedeepinsidebanuanimation
    play music "audio/hardsex.mp3"
    "Ruslan continued to fuck Banu harder with powerful thursts."
    r "You like this?"
    r "Tell me."
    b "Yess....ahhhh..."
    b "Keep doing that....ahhh....don't stop..."
    r "You like it when your leg's up in the air."
    b "It's so deep. You're touching the way deep inside me..."

    show ruslanshovedeepinsidebanuanimationtwo
    b "Ahhh...you're an asshole..."
    r "Shut the fuck up, bitch. I know you like it."
    b "Ahhh, I'll make you pay for it."
    r "I've lost the cound how many times you came on my dick."
    b "Do it slowly, you're hurting me, you prick."
    r "This is how you must be treated."
    b "Oh my god, slow down a bit, donkey. You're going to break my neck..."
    b "Ahhhhh...shit, I'm going to cum again..."
    scene v15-162 with fade
    stop music
    r "Open your mouth."
    b "Just get off me, asshole."
    scene v15-163
    r "Don't you hear me?"
    r "I said open your mouth."
    r "So you want to pass out again?"
    r "I'll kill you this time. "
    scene v15-164
    r "Open it. I'll fuck your throat."
    b "Put it away from me, bastard."
    scene v15-165 with hpunch

    play sound "voices/slap.mp3"
    r "Come on. Be a clever girl."
    stop sound
    scene v15-166
    r "You don't want to make me angry, do you?"
    "Banu was so afraid. She looked in Ruslan's eyes and knew that he was going to get what he wanted so she chose the easy way and slightly opened her mouth. "
    scene v15-167
    r "That's it."
    b_ "Shit...this feels so gross in my mouth..."
    r "Now a little deeper."
    b_ "No!"
    scene v15-168 with hpunch
    "Ruslan continued to fuck Banu's throat till he released all his seeds inside of her mouth."
    b_ "Shit...this's disgusting."
    r "Ohhhhhhh damn... what a relief..."
    scene v15-169
    b "You're disgusting..."
    b "You'll pay for this, I promise."
    r "Damn, I messed up your face. I'm sorry."
    r "But I think you look good with my semen running down from your mouth, hehe.."
    b "..."
    $ renpy.end_replay()
    $ persistent.ruslan_rapes_banu_unlocked = True
    jump ruslan_rapes_banu_continue


label polad_fucks_banu3:
    $ renpy.block_rollback()
    $ banuscoldpolad = False
    scene v15-36
    play music "audio/sexy.mp3"
    b "I know what you want."
    b "I saw your eyes sparkling when you look at me."
    b "You can't deny that."
    b "And most importantly you can't reject seeing my naked body!"
    scene v15-37 with hpunch
    b "You see? I'm not even wearing panties..."
    b "If this is what it takes to get your eyes off that book...well...here it is..."
    scene v15-38
    p "Hey, wait..."
    p "What're are you doing?"
    b "I'm giving you what you want."
    b "Why are you surprised? You didn't expect this coming, did you?"
    p "Banu! What the hell?"
    p "Put that clothes back on immediately!"
    scene v15-39
    b "Well, it's too late and this room is so hot here. You should've got an air conditioner here."
    p "You think that I'm joking? This is not funny at all."
    p "Don't you hear me? Put your clothes back on and get out of here!"
    b "Oh I like it when you get so manly."
    b "But unfortunately I can't fulfill your request just yet."
    scene v15-40
    p "I see you don't understand me. Look, I'm not type of guy that you can mess around with. "
    p "I don't like stuff like this. You're ruining my peace here and violating my privacy at the moment. "
    p "Don't make me repeat myself or..."
    scene v15-41
    b "Or what?"
    b "Will you beat me like you did to my husband?"
    b "Will you grab me by my arm and throw me out like this?"
    b "I don't think you can do that."
    b "Now tell me. Did you enjoy watching my body? "
    b "You were staring at me, Polad. Even now you're struggling not to look down. But don't worry, you can watch as long as you want because I don't mind it."
    scene v15-42
    p "The reason you're still here is that I don't want to touch you."
    p "You look so disgusting right now."
    p "You aren't as pure as you were before. Now I see your true face. My brother was so pure that he didn't see your true self."
    scene v15-43
    b "I admit that I'm not so pure as you thought before."
    b "And I was always sincere with Alper."
    b "But you don't have a right to talk about him either."
    b "You've also cheated on him. You were eating me with your eyes all the time."
    if followpolad == True:
        b "You fucked me, Polad!"
        b "Did you forget that?"

    scene v15-44
    p "Banu!"
    b "What do you read?"
    b "Oh...this is so interesting."
    p "BANU!"
    b "Wait, let me read a little."
    scene v15-45
    p "Put the book down!"
    b "Don't be jealous. Let me read a bit."
    b "And try not to stare so much. You know it's rude."
    b "Well..."
    scene v15-46
    b "This is actually very interesting."
    b "I didn't know you liked detective books."
    b "Well..."
    b " 'The dining-room was a large, long room with a big open fireplace at the end... ' "
    p "Banu..."
    b " 'The table was laid for dinner with shining silver and bright linen...' "
    scene v15-47
    p "I said put the fucking book down and leave!"
    b "Hey, don't be so forceful like that. Let me read a little more."
    p "Banu! You're driving me crazy right now..."
    scene v15-48
    b "Oh...I missed your smell. "
    b "I can't control myself when you're so close to me, you know that?"
    b "I'm burning right now...kiss me Polad!"
    scene v15-49
    p "Stop this nonsense already!"
    b "I've read that book actually."
    b "You know what will happen to all those people in the island."
    b "They will all be dead at the end and only the detective will survive because he's the one who set all these stuff up."
    scene v15-50
    b "I'm sorry. I couldn't hold myself."
    p "Don't you think that this is enough?"
    p "The more you continue this the more I hate you."
    p "I think you need to just respect yourself a bit more."
    p "Leave already. You degraded yourself enough."
    b "I know why you want me to leave so fast."
    b "You're just afraid of not being able to hold yourself back."
    b "I notice how hard you got down there through your pants."
    scene v15-51 with vpunch
    b "Look at this big dong you're hiding there."
    b "So this is just because of me?"
    p "Banu! Don't dare to touch me!"
    play music "audio/tension.mp3"
    scene v15-52
    b "Or what?"
    b "What you'll do about it?"
    p "You're getting on my nerves. You'll suffer for this."
    b "Show me then. Show me what you got."
    scene v15-53
    b "Come on. What are you waiting for?"
    b "Slap me. Show me how much of a man you are."
    b "Choke me to death..."
    b "You see? You can't do anything..."
    scene v15-54 with fade
    b "Look at this big cock you are packing here..."
    b "This is a nice compliment for me actually. So thank you, Polad."
    b "So if you let me, I want to open my present. I'm so excited you know?"
    scene v15-55 with hpunch
    "Polad was so busy fighting the devil inside him that it was too late when he realized that he let Banu pulled his loose pants down and revealed his fully erect cock."
    scene v15-56
    if followpolad == True:
        b "Wow! Even though you've shown it to me before, your enormous dong impressed me again. "
    else:



        b "Wow! I could never tell you were this big... "

    b "To be honest, this is the biggest cock I've ever seen."
    scene v15-57
    b "You see? You couldn't help it but got an erection because you were imagening dirty stuff with me."
    b "You can't deny the big fact down there."
    "Polad was thinking about pushing Banu away from him and leave the room but then..."
    scene v15-58
    p "Uh...?"
    "Banu started kissing his cock on the very sensitive spot."
    "He thought about laying Banu on the ground and fucking the shit out of her for a moment but..."
    "He didn't want to admit his defeat."
    "It was the worst thing for him to raise the white flag."
    "But he couldn't push her away either. "
    "She was the woman that he desired and she was the woman that got his attention the most."
    scene v15-59
    "Banu continued with the soft kisses followed by licking along the long shaft."
    "Polad's mind went blank for a moment. He was frozen like that and was unable to think straight."
    "Banu used the opportunity and got intense with the kisses on the most sensitive spots on Polad's cock."
    scene v15-60
    "She knew that Polad was on the edge of losing and she was going to win this battle so she started to talk dirty to him to guarantee her win."
    b "I've never done this to Kamil and I'll never do."
    b "You're the lucky guy today, you know that?"
    b "Your dick smells so bad. Don't you wash it?"
    b "But I like your smell. I'm even addicted to it..."
    scene v15-62
    p "Stop it...just stop it..."
    "Banu was making Polad very horny at that moment..."
    "All his blood had already left his upper body and gone to his dick."
    "He was just unable to stop Banu."
    scene v15-61
    b "Your cock is so hard right now. It's like a stone."
    b "And I feel your balls boiling... I'm afraid you're going to explode all your juice on my face."
    b "Your dick seems to like me a lot, Polad. What are you going to do about it?"
    "Polad had reached a point that he couldn't take it any longer."
    "He hadn't thought he could do this one day but..."
    scene v15-63 with hpunch
    play music "audio/hardsex.mp3"
    "Banu was scared stiff when Polad suddenly and forcefully grabbed Banu by her head and put his cock in her mouth."
    "Banu was so horny, she wanted Polad to fuck her but she didn't expect this."
    "She couldn't imagine Polad would do such a dirty thing to her."
    scene v15-64
    "Banu tried to push Polad away but it was too late as Polad firmly grabbed her head and pushed his cock all the way to her throat."
    p "Yeah...that's it."
    p "I told you not to play with me."
    p "Your talking mouth needs a good fucking. Now I don't care if you choke to death."
    scene v15-65
    "Polad's dick was so big for Banu's little mouth that she couldn't take it as her eyes started rolling."
    "Banu was pushing Polad away with all her strength but she was powerless."
    p "This is what you get if you tease me like that."
    p "I see that I've been so nice to you. Now it's time for your real training."
    scene v15-66
    b "Cough..cough..cough..."
    b "Are you mad? You could've kill..."
    scene v15-67 with hpunch
    p "You must learn to tell the right words when I let you talk, alright?"
    p "Or your eyes will be popped out of their area soon."
    scene v15-66
    b "Please, let me breathe. I can't..."
    scene v15-67 with hpunch
    p "That was better but not really what I wanted."
    scene v15-68
    "Banu's face was turning red, and her eyes bulging out in panic until she couldn't keep them open anymore."
    "She was choking!"
    scene v15-69
    b "Please...I can't take it...please stop it..."
    p "Right, now it's time to give you what you came for already..."
    scene v15-70 with fade
    stop music
    "Polad stood Banu up and grabbed her firmly from behind."
    "He locked her arms behind her back and put his juicy dick between her legs from behind."
    p "So this is what you want?"
    b "Yess, I want this...I want you. I love it when you're tough like this."
    scene v15-72 with hpunch
    p "Now bend over, whore so I can stick it in easily."
    b "Yess, call me whore or whatever you want. Just fuck me!"
    p "Not so fast. If you want my cock, you need to ask it properly."
    scene v15-73
    p "Now tell me how bad do you want it."
    b "I want it so bad right now. Please, don't tease me like that."
    p "Damn, you're flooding. My cock is covered in your pussy juice."
    p "You're so desperate."
    scene v15-74
    p "I know that your husband can't satisfy this pussy."
    p "I bet his dick looks like a light switch."
    p "Or you wouldn't come here begging me to fuck you."
    b "Polad, please..."
    p "Tell me the truth. Do you even cum from his dick?"
    b "Please, stop it..."
    scene v15-75
    "While teasing Banu, Polad put the tip of his cock in her pussy."
    p "Tell me whose cock is better, your husband's cock or mine?"
    b "Please, Polad, let's not talk about him."
    p "Tell me or I'll pull it out."
    b "No! please, your cock is much better that his. He's dick is nothing compared to your big hard cock."
    b "He's no match for you. Please, fuck me already..."
    scene v15-76
    p "Well, if you want it so bad..."
    p "Here it is..."
    p "Take it, slut!"
    scene v15-71
    b "AAHHHHH...."
    b "Oh my mama, please slowly...."
    b "Oh MAMA....It's so big. Please, fuck me slowly. I can't bear your cock."
    show poladfuckbanubackroomanimation1angle
    play music2 "voices/moaning.mp3"
    b "You're destroying me...Ahhhhhh.."
    p "Fuck, your pussy will get into the shape of my cock."
    p "You'll never enjoy the sex with that limp dick husband of yours."
    b "Ahhhh...please, don't stop..."
    show poladfuckbanubackroomanimation1
    p "You're such a degraded wife."
    p "Your husband works his ass of all day long in the office."
    p "But you're looking for a dick to give pleasure to your pussy."
    show poladfuckbanubackroomanimation1fast
    p "I don't give a shit if you enjoy this or not..."
    p "I'll cum in your pussy right now."
    b "Ahh, not so fast....ahhhh"
    b "Hey, slower a bit. You're breaking me... Ahhhh..."
    stop music2
    scene v15-77 with hpunch
    play sound "voices/man2.mp3"
    p "Arggg.... shit..."
    b "Ahhh, slower you animal..."
    stop sound
    p "That's it."
    scene v15-78
    p "You can go to your husband now. I'm sure he's now missing to cuddle with you. But I have no time for you."
    b "What? Is that it?"
    scene v15-79
    p "Be quick, take your clothes and leave. The workers will come here to bring the beverages now."
    b "Huh?"
    scene v15-80
    b "I can't believe you."
    b "You're worthless, you know that?"
    p "Whatever..."
    scene v15-81
    b_ "Animal..."
    b_ "Cow dung..."
    b_ "Wait, he came insde of me..."
    $ renpy.end_replay()
    $ persistent.polad_fucks_banu3_unlocked = True
    jump polad_fucks_banu3_continue


label banu_masturbates:
    play music "audio/sensual.mp3"
    label banumasturbatesnexttokamilchoices:
        scene v13-141

        menu:
            set menuset



            "Think about Polad" if followpolad == True:
                $ renpy.block_rollback()
                scene v13-142
                b_ "My body can't forget how Polad treated me."
                b_ "He's so strong, athletic, muscular and manly..."
                scene v12-45past
                b_ "When he pushed down on my body, I lost all my power and became obedient."
                b_ "We have the perfect body compatibility. I love the way he penetrated me, the way he handled me, the way he fucked me."
                b_ " He knows my body se well now and made me cum multiple times which Kamil fails to do even once."
                b_ "His manhood is much bigger than Kamil's. I would never know that a man could have such a big penis, if I didn't try."


                jump banumasturbatesnexttokamilchoices
            "Think about Turan" if banuturansexfirsttime == True:
                $ renpy.block_rollback()
                scene v13-142
                b_ "Turan's the man I hate the most. He treats me like a whore. But last time..."
                scene v7-65past
                b_ "He was so intense. Although I don't want to accept it, my body did enjoyed his touches. "
                b_ "He was so rough with me and I came so hard."
                b_ "My body had not experienced so hard fuck like that and satisfaction before."
                b_ "I loved how he dominated me and made me his woman....at least for some hours."

                jump banumasturbatesnexttokamilchoices
            "Think about Murat" if banutakethebetfuckmurat == True:
                $ renpy.block_rollback()
                scene v13-142
                b_ "Murat's so energetic. He's young but so tricky."
                b_ "I sensed that if I lose my power and let him, he wouldn't let the chance go."
                scene v13-68past
                b_ "I knew he would fuck me..."
                b_ "But I made a mistake knowing that it's a mistake and he took advantage of me. "
                b_ "He made me so young and alive."
                b_ "It felt so good to be penetrated by a young and energetic man. "
                b_ "Knowing that I was penetrated by a man other than Kamil mad it dirtier and exciting..."


                jump banumasturbatesnexttokamilchoices
            "Continue":

                $ renpy.block_rollback()
                scene v13-143
                b_ "Shit, I feel so dirty now..."
                b_ "I want to cum so bad..."
                scene v13-144
                if callahmed == True:
                    "While rubbing her back hole, Banu couldn't stop thinking how Ahmed rubbed and stimulated her butt in front of Kamil."


                "She couldn't stop her curiosity and penetrated her ass with two of her fingers which she's not done since a long time ago..."
                b_ "This's so dirty but it feels good..."
                b_ "I can never let a man touch me here, even Kamil. This's haram."
                b_ "It's haram if I let another man touch it not myself."
                scene v13-145
                b_ "My ass is burning now. I need somebody to touch me, make me feel good."
                b_ "I can't wake Kamil up and give him this satisfaction."
                scene v13-146
                "Banu started to finger herself furiously."
                "She completely forgot about the fact that Kamil is sleeping next to her."
                scene v13-147
                "At this point she didn't mind moaning loud."
                b "Ahhhhhhhhhhh..."
                scene v13-148
                b "Yesss.....I need more. Ahhhhhhh yesssss..."
                scene v13-149 with vpunch
                stop music
                k "zzzzzzz..."
                "Banu's heart skipped a beat when she heard Kamil snoring."
                "She could almost woke her husband up."
                scene v13-151
                b_ "Oh my God, what am I doing?"
                b_ "I almost got caught...like this."
                scene v13-150
                b_ "This was so thrilling. I got so horny."
                b_ "How will I go back to sleep again...?"
                b_ "Maybe...."


    stop music            
    menu:
        "Go back to sleep":
            $ renpy.block_rollback()
            $ banugobacktosleep = True
            scene v13-151
            b_ "This's enough Banu."
            b_ "I better go back to sleep before I wake Kamil up."
            b_ "This's so embarrassing. What I've done is enough..."




        "Use the dildo" if getridoftoyshome == False:
            $ renpy.block_rollback()
            $ banugobacktosleep = False
            scene v13-152
            play music "audio/sensual.mp3"
            "Banu was so thrilled and excited..."
            "She didn't want this night to end this soon."
            scene v13-153
            "So she grabbed the dildo that she kept after she returned from Malibu."
            "She hesitated playing with a dildo in the same room where Kamil's sleeping."
            "But she lost the fight against the desire and the horniness inside her."
            b_ "It's wrong but...I'm throbbing down there..."
            b_ "I feel so weak and fragile right now. I won't be able to sleep with this desire."
            b_ "I'm such a bad wife!"
            scene v13-154
            "She left her weight fall on the sofa and started to touch her body with the soft and long dildo."
            "Eyes closed, she began to caress her upper body with her left hand while keeping her right hand busy on the lower body."
            scene v13-155
            "She began to press the dildo hard on her pussy and started to move it up and down."
            b_ "I shouldn't be doing this but my body need an attention and care, especially my private parts down there."
            b_ "All Kamil do in bed, is just penetrating me. He's so selfish and doesn't care about my needs."
            b_ "Penetration only covers men's needs but what about woman. This's not fair."
            b_ "The clitoris must be stimulated for a woman to reach an orgasm... "
            b_ "If Kamil can't do that, what's the problem if I do that myself."
            b_ "Shit, I need more..."
            scene v13-156
            "She spread her legs wide open and kept her right leg hanging in the air so she can have a better view of what she was doing."
            b_ "Fuck, this dildo's so fucking big. I can't wait to feel in inside my throbbing vagina."
            b_ "It's so soft and meaty..."
            b_ "It rubs me so good."
            show banudildoteasingpussyanimation
            b_ "This dildo's so big. "
            if followpolad == True:
                b_ "It's way bigger than Kami's. It resembles Polad's manhood. His thing is even bigger than this dildo."
                b_ "How could a man have such a big tool..."
                b_ "It almost tore me apart. It spoiled me for Kamil..."
            if banuturansexfirsttime == True:
                b_ "This can be compared to Turan's member. "
                b_ "His thing is shorter than this but it's so thicker. "
                b_ "Male's penises can be very different."


            b_ "Fuck! I can't wait any longer..."
            scene v13-157
            b "AAAAAAhhhhhhhhh...."
            "Banu again let out a loud moan and again didn't care about Kamil's presence in the room..."
            b_ "Yesss, I need this. I need a big fat cock inside me. "
            b_ "My pussy can't be satisfied with Kamil's pathetic moderate penis. I need a beast."
            b_ "I need a real fucking cock to satisfy me."
            scene v13-158
            "Banu pushed the dildo back and forth inside her vagina feeling it, enjoying the big shaft touching the walls of her vagina from inside. "
            scene v13-159
            "It felt so good that she lost her mind for a while and a powerful orgasm shook her legs. "
            scene v13-160
            "The unsatisfied woman took the juicy dildo covered with fluid out and put it aside. "
            "She started to fuck her burning pussy with her fingers."
            b_ "I couldn't imagine that I can be so active as a woman. "
            b_ "I came multiple times but my body needs more."
            b_ "I'm so unsatisfied and sexually frustrated..."
            b_ "I need more. I need much more than this..."
            scene v13-162
            "Again the juicy down lips covered around the big long shaft."
            scene v13-161
            "The frustrated woman started riding the dildo faster..."
            b_ "Yesss, yesss, yess..."
            b_ "Fuck, fuck me like that."
            b_ "I'm such a dirty woman."
            b_ "I can never be so pure again. I'm spoiled, weak and covered with shame..."
            b_ "I don't want anything but cum..."
            b_ "I want to cum so bad."
            b_ "I want it bad.....Yessss..."
            scene v13-163
            b "AAAAAAhhhhhhhh....."
            b "SSSSShittt..."
            "The woman came so hard again and again multiple times ignoring the fact that she could disturb her husband's sleep..."
            scene v13-164
            "After finishing with the dildo, she put it aside and turned her head towards her husband who is sleeping carelessly."
            "Realizing that Kamil sleeping just a few steps away, she began to think about her poor husband."
            scene v13-165
            stop music
            "Banu's corruption level and her bad behavior towards her husband increased after the long dirty session she just did."
            b_ "Poor Kamil. You're the reason what I've turned into."
            b_ "I've never wanted to do this to you, but you made me do this."
            b_ "You're so pathetic and dump. "
            b_ "I'm sorry for being this bad to you, but whatever mistake you make you'll pay for it."
            b_ "It all depend on you..."



    scene black with Dissolve(3)
    ""
    $ renpy.end_replay()
    $ persistent.banu_masturbates_unlocked = True
    jump banu_masturbates_continue

label turan_fucks_banu_1:
    b "Ahh.."
    b "Hey, be gentle with me."
    "Turan grabbed Banu hard and pulled her to the bed with force."
    scene v14-69
    "Now Turan's dick was fully erect touching Banu's abdomen."
    "Banu was trying to concentrate not to moan and give him the satisfaction."
    b_ "I can't enjoy this. No matter what he does I should keep my voice down."
    b_ "I can't stand to see pleasure in his face. I feel weak when he grins looking at my eyes."
    b_ "I hope that he'll orgasm soon and I leave this disgusting room."
    scene v14-70
    "Turan again grabbed Banu by her legs hard and pulled her to himself."
    t "It's time baby, are you ready for this?"
    b "Hey, I told you to be gentle with me."
    t "I'll try baby."
    scene v14-71
    "Turan slowly pushed the tip of his cock in to Banu's already wet pussy."
    b_ "Why it feels this good. It's just the tip of his penis. It feels fatter than it was last time. Did it get bigger?"

    t "Girl, your pussy gets tighter every day I see."
    t "Why are you looking other way. You don't wanna see this?"
    scene v14-72
    b_ "Oh my God..."
    t "I see that you don't want to show me the lewd expression in your face. "
    t "Just don't tell me you don't enjoy this. Your cunt is burning. It's flooding inside."
    scene v14-73
    b "Hey don't push it so deep. It's hurting me."
    t "Cool down girl, It's okay."
    b "I said don't push it's reaching my womb. It's hurting me. Just finish it."
    show turanfucksbanuv141
    play music "voices/slapmoanmedium.mp3"
    b "Ahh.."
    b "Hey slower I said..."
    "Turan was not listening to her anymore. His dick was stimulating the deepest parts of her vagina."
    "Banu was trying hard not to moan and give Turan the sign of her defeat."
    t "Look at me bitch. I want to see that expression. You have no idea how lewd you look right now."
    t "You don't admit it but your cunt is begging to be fucked."
    show turanfucksbanuv141angle
    t "Come on, look at me. I wanna see your face."
    t "Your pussy squeeze my dick so hard. "
    t "Do you do that on purpose? Do you want me to finish that soon?"
    t "I'll fuck you until you can't walk, bitch."
    scene v14-74
    stop music
    "Banu was at her limit. She had no power to hold it anymore."
    b_ "I can't do this. He's breaking me...I'm melting. This is just too much for me..."
    scene v14-75 with vpunch
    play sound "voices/moan4.mp3"
    b "AAAAAAHHHHHHHhhhhh...."

    b "Oh my God...."
    b "I'm cummingg....."
    b "Ohhhh...."
    stop sound
    scene v14-76
    b "Please, slower. Fuck me slower. It's too much. "
    t "That's what I wanted to hear. Your soft voice. It's music to my ear."
    b "Please, stop. Let me take a break."

    scene v14-77

    t "Well, if you want break, I'll give you that."
    t "Do you like to do it on the sofa?"
    b "What? What are you talking about?"
    t "Come here."
    scene v14-78 with hpunch
    b "Hey stop it, put me down."
    t "You're so light Banu. You're really in a good shape."
    b "Don't you hear me?"
    scene v14-79
    b "Damn you..."
    "Turan carried Banu to one of the armchairs and just threw her roughly on the armchair."
    scene v14-80 with hpunch
    b "Are you mad? "
    b "How you dare to treat me like that?"
    t "Shut your fucking mouth. I've enough of your talking."
    t "Now spread your legs.."
    b "What...?"
    scene v14-82
    "Turan quickly got into the position and stuck his fat cock into her pussy."
    b "Oh my God..."
    show turanfucksbanuv142
    play music "voices/moan4.mp3"
    t "I know how to shut your mouth, bitch."
    t "Do you like this?"
    b "Please, be gentle...ahhh...it's so deep..."
    b_ "I can't think straight while he's inside me. It's melting my brain."
    b_ "I can't reject him. I can't go against him."
    stop music
    scene v14-81
    b "Please, finish already..."
    t "Damn bitch, you needed this."
    t "You have to see your face now, stupid cunt."
    scene v14-83
    b "Please, finish it already....ahhh...I have to go home.....AAAHHH...please slower..."
    t "Don't worry. I'll give you my cum soon, but first I want you to look at yourself in the mirror."
    scene black with dissolve
    t "Come here..."
    t "Now bend over..."
    b "Please, Turan. I've no power left."
    scene v14-84 with dissolve
    t "That's it. Now look at yourself."
    b "Please, don't touch me there...ahh..."
    t "Put your hands on the mirror like that..."
    scene v14-85
    t "That's right."
    "Turan started to rub Banu's clit furiously."
    b "AAAAHHhhhhhhh....."
    b "Please, Turan. I can't stand this anymore, please finish it already..."
    t "So you are asking me to fuck you?"
    b "Yes, do it already."
    t "Ask properly Banu."
    b "Fuck me, Turan. Stop teasing me. Fuck me, please."
    t "That's better."
    scene v14-86
    b "OOOHhhhhh.."
    "Turan positioned himself behind Banu and entered her with a powerful thrust."
    t "If you want it that bad, then take it..."
    show turanfucksbanuv143
    play music "voices/slapmoanmedium.mp3"
    t "Take it, slut. Take it..."
    b "UUUUhhhhh.."
    t "You're howling like an animal..."
    t "You must really like it."
    t "Stop howling like that or the neighbors will come and interrupt us."
    b "Please..."
    scene white
    show turanfucksbanuv143angle
    b "Please, Turan. I can't stand like this. "
    b "Ohh....I'm going to collapse...."
    t "Your legs are shaking."
    t "You really enjoyed my cock. "
    t "Let's see if you can stand it if I increase the pace a bit."
    stop music
    scene v14-87
    b "Oh my God....AAAAAAHhhhhh..."
    t "Take it bitch."
    t "Arrrrgg...."
    t "Take my cum."
    scene black with fade
    t "Oohhhh....shit.."
    b "Ahhhh...."
    scene v14-88 with dissolve
    play sound "voices/moanfinish.mp3"
    t "Ohh shit, that was good. I knew you wouldn't be able to hold it."
    stop sound
    t "Damn look at you. I messed your ass a little bit."
    scene v14-89
    t "Damn girl, you look so sexy with my cum on your ass."
    b "You're a brute."
    b "Hand me some paper at least. "
    t "You can take a shower once I'm finished with you."
    b "What?"
    scene v14-90 with hpunch
    b_ "Ohh shit...he just came but it's still as hard as rock."
    b_ "How this is possible?"
    b "Turan, please stop it. I have to go. I'm being late."
    "Banu knew that Turan was not going to listen to her. "
    "She knew that telling him to let her go was a waste of time. "
    t "Now get ready for the next round..."
    scene v14-91 with vpunch
    "After a few seconds Banu found herself pinned to the bed by Turan's large heavy body and getting pounded by his fat cock."
    scene v14-92
    "A strong eye contact and powerful thrusts made Banu melt that she took her eyes off his eyes."
    "She felt so weak and feminine that she wanted to be made love to and her lips wanted to be kissed."
    scene v14-93
    "Turan again increased the speed pushing his massive penis all the way back and forth inside Banu."
    scene v14-94
    b "AAAhhhh..."
    b "No please not there...ahh...don't hold me there..."
    b "AAhhhh...I am sensitive there, Turan, please..."
    scene v14-95
    "Turan had found Banu's sensitive spot, her belly button."
    "As he pushed down her belly button Banu reached the climax and had a very powerful orgasm that was building while she was being fucked."
    scene v14-96
    play sound "voices/moanfinish.mp3"
    "One more time Turan came o her pussy while she was still having an orgasm."
    stop sound
    t "I bet you'll never forget this evening."

    scene v14-97
    t "See you next time, baby. Go and clean yourself. Your husband is now waiting for you. "
    "Turan left her on the bed with her pussy gaping and covered in cum."
    "She stayed in bed for a while coming to her senses before she realized that she had to hurry."
    scene black with dissolve
    ""
    $ renpy.end_replay()
    $ persistent.turan_fucks_banu_1_unlocked = True
    jump turan_fucks_banu_continue

label staywithkamilcorrupted:


    $ callahmed = False
    $ banugobacktosleep = False



    scene black with Dissolve(3)
    centered "{size=+120}Later that day{/size}" with Fade(0.5, 0.5, 5)
    scene v13-99 with irisin
    "Banu had no intention to forgive Kamil."
    "She was just sitting there and thinking how she can get a revenge on him as he hurt her pride."
    "Banu was tired of Kamil's stupid ass for so long but today Kamil made a big mistake by slapping her."
    b_ "I can't bear this anymore. How could that asshole dare to slap me? "
    if followpolad == True:
        b_ "Now I don't feel sorry for letting Polad fuck me behind your back. He's a much better man than you'll ever be."

    if banuturansexfirsttime == True:
        b_ "Even Turan treated me a way better than you do in bed. If you were a real man you could protect your wife and no other man could touch your wife."

    if banutakethebetfuckmurat == True:
        b_ "If Murat didn't tell me I'd never know."
        b_ "At least he's sincere with me. And the sex with him was much more enjoyable than with you. Loser!"


    scene v13-100
    k "Banu, please..."
    b "I don't wanna hear anything."
    scene v13-101
    k "I swear Banu, I've nothing to do with anybody."
    b "You're a fucking liar, Kamil."
    k "Please stop swearing, it doesn't suit you."
    scene v13-102
    b "Shut your fucking mouth."
    k "I understand you are angry with me but..."
    scene v13-103
    b "Fuck you, Kamil!"
    b "You cheated on me and you dared to slap me. I won't leave it like that. I'll teach you a good lesson not to treat me like that."
    b "What would you do if I fuck another man huh? What would you do if Polad fucked me?"
    k "Banu, stop it!"
    scene v13-104
    "Kamil is shocked by Banu's behavior."
    "She never talked like that and never swore like that."
    k_ "She's changed. What makes her talk like that? It's rude and not good a behavior by a religious woman like her."
    k_ "She's angry now but I hope she'll change her behavior soon..."

    scene v13-105 with fade
    b_ "I don't want to leave it like this. "
    b_ "What if I call Ahmed. He can visit and teach Kamil a good lesson for harassing his wife. "
    b_ "But I don't want him to be arrested. I just want him to understand his place in this house."
    b_ "So if Ahmed visit us and threaten Kamil a bit, he'll never do me wrong again."
    scene v13-106
    b_ "But I'm not sure."
    b_ "Should I go for this?"
    menu:
        "Call Ahmed":
            $ renpy.block_rollback()
            $ callahmed = True
            b_ "Yes, I'm going to give him a good lesson that he'll never forget."
            b_ "He'll see the power of a woman and never do me wrong again."
            scene v13-108
            b "Hello, Ahmed. It's Banu, Kamil's wife."
            ah_ "Yes, Banu."
            b "I need to talk to you about something. Do you have time?"
            "Banu's going to implement her nasty plan on Kamil."
            "Kamil's doing wrong to her. He can't even imagine how his lovely wife Banu can turn into his frightening nightmare."
            "All this time Kamil's been leading the relationship like in most of the eastern countries."
            "Now it was time that Banu could gain some control in the relationship. With the help of a police officer, Ahmed."

            jump callahmedevent
        "No need to do that":




            $ renpy.block_rollback()
            $ callahmed = False
            scene v13-107
            b_ "I can't do it. I know Kamil is an asshole sometimes, but he's my husband after all."
            b_ "I can't do that to him."
            "Although Banu is fed up by Kamil's stupid behavior, she has not got enough power to go against him yet."
            "Banu is so offended and she wants to get her revenge somehow."
            "But threatening her husband with a police officer is too much for her."

            jump notcallahmedevent



label callahmedevent:

    scene black with Dissolve(3)
    centered "{size=+120}Surprise visit{/size}" with Fade(0.5, 0.5, 5)
    scene v13-109 with fade
    "Banu is sitting in the living room and waiting for the arrival of their guest."
    "She is so nervous as she never done something like this to her husband."
    scene v13-110

    "She did some different make up from usual and looks so sexy, serious, tough and scary..."
    scene v13-111
    "Kamil again starts to convince her that he's been loyal to her and loves her so much, but no use. "
    "She has no intention to forgive him so soon and prefer not to talk until..."
    scene v13-112
    play sound "voices/doorbell.mp3"

    "The doorbell rings..."
    "Kamil's surprised as they were not expecting anybody."
    k "Who can it be?"
    scene v13-113 with vpunch
    play music "audio/action.mp3"
    "Kamil is shocked as soon as he opened the door."
    "Wearing a uniform and a tough and serious look on his face the man standing at the door was not other than Ahmed."
    scene v13-114
    "Kamil realized that this was not the usual visit."
    "Ahmed didn't shake Kamil's hand leaving it in the air."
    "It didn't take Kamil longer to realize that it's Banu who called Ahmed."
    "Ahmed acted so cold and preferred not to talk to Kamil until he needed to ask..."
    ah "Where's your wife?"
    scene v13-115 with fade
    "Banu guided them to the isolated cozy room so they can have a private chat there."
    "Kamil was shocked and broken to understand that Banu actually reported him to the police. "
    "But he's so confused at the same time and doesn't know how serious they are."
    "Ahmed is his schoolmate and their neighbor, but when it comes to being professional, how far he'll go?"
    scene v13-116
    ah "I don't know if you know this or not that Banu reported you for hitting her."
    scene v13-117
    "Kamil's frozen right there and can't open his mouth to talk."
    "What Banu have done to him made him speechless. It was so late to talk."
    "Maybe Kamil would stand up and shout at Ahmed and tell him to fuck off if he were more brave. 'This is my house and what I do with my wife is none of your business.'"
    "But in this condition he had no choice but to listen to Ahmed and Banu."
    scene v13-116
    ah "So I came to talk to you about this and help you out of this if Banu wants of course."
    "Banu was just sitting there with a serious look on her face and trying to avoid an eye contact with her husband."
    scene v13-117
    "Kamil came to his sense after fully realizing the situation he was in and slightly turned his face to his wife..."
    k "H... how could you do such a thing. I'm sure we could solve our family problem in private."
    scene v13-118 with hpunch
    "It was when Ahmed shouted at Kamil, insulting him before his wife..."
    ah "Shut your mouth, dude. You're not allowed to talk until you you've given the permission."
    ah "I'm here to save your stupid ass. You don't understand how deep shit you're in. You think this is funny huh?"
    ah "You're going to spend five years of your life in jail."
    "Kamil again was shut down by the fact that it was Banu, his wife who put him in this condition and he has not got enough power here to go against them. "
    "Banu enjoyed Kamil being silence and understand that Banu had more power here and she watched him with satisfaction."
    scene v13-119
    "After talking to Kamil, Ahmed turned his face to Banu..."
    "Banu is surprised how Ahmed played his role here and paid good attention to what he's gonna say next. "
    scene v13-120
    ah "Well, Banu. I guess you can make a little compromise to Kamil here. "
    ah "I understand you were angry when you reported him but If you don't cancel it, your husband will go to jail for so long."
    ah "But of course before you do that Kamil owes you a good apology about his behavior."
    ah "Then you can decide whether you'll forgive him or not."
    "Banu was so satisfied with the game Ahmed played here and showed him her appreciation with the look on her face."
    scene v13-121
    "It felt like a slap to Kamil when Ahmed placed his hand on Banu's butt and started massaging it..."
    ah "Kamil's always been a stupid ass. He's never treated women right, especially, beautiful ones like you. "
    ah "He doesn't understand and see the treasure he has."
    ah "And you deserve to be treated right by a real man."
    ah "I'm sure this will be a good lesson to Kamil to learn to be more manly because a man would never hit a woman and he'll never make the same mistake again. "
    scene v13-122
    "Kamil's watching Ahmed bitterly all this time and waiting for him to finish his words quick and take his hand off his wife. "
    "He knew that Ahmed was not only doing his job but also wanted to get on his nerves on purpose. "
    "He wanted to stand up and break Ahmed's arm but the fact that his wife is against him made him weak."
    scene v13-124
    ah "What? Seems like you are nervous. What's it about?"
    ah "You wanna say anything?"
    k "..."
    ah "We're waiting for your apology Kamil, will you make us wait longer?"
    scene v13-122
    "While talking to Kamil, Ahmed slide his hand between Banu's ass cheeks touching her pussy and back door."
    scene v13-124
    "Banu is surprised by this but didn't change her face expression in order not to let Kamil know."
    "Maybe she even enjoyed it. Nobody knows. "
    ah "Kamil, we're waiting for you..."
    scene v13-123
    k "I...I want to apologize for my behavior Banu. I didn't want to do it. It was just an accident."
    k "I..I'm really sorry for what I've done. Please forgive me for this..."
    scene v13-124
    b "Hmm, you could try even better...I don't believe you anyway."
    ah "I think he tried his best."
    ah "What do you say, Banu? Can you forgive him?"
    b "Well, I can give him one more chance to prove himself..."
    ah "Good..."
    scene v13-125 with fade
    ah "I'll try to get the problem resolved."
    ah "My advice is that you should treat better to this beauty until somebody steal her from you..."
    ah "Now I've a few questions for her in private so.... leave us alone."
    "Kamil got really jealous there. Ahmed again was standing so close to Banu, touching her, groping her, pulling her to himself."
    scene v13-126
    "While just leaving the room, Kamil noticed Ahmed's hand on Banu's hip."
    "And realizing that Banu is okay with it, Kamil was left with no choice but to go out and close the door from behind. "
    scene v13-127
    "Kamil was angry, bitter, anxious, and worried about Banu with Ahmed alone in the room."
    "The jealous feelings inside him had him glued to the door."
    "He knew that Ahmed is a big motherfucker and won't let it go without making his move on his wife."
    scene v13-128
    "He couldn't stop himself and tried to listen to them but couldn't hear anything as they were so quiet."
    "As the time passed some nasty stuff came across his mind."
    k_ "I can't trust this asshole. "
    k_ "I trust Banu but... this is not enough. Can she let him do something dirty to her?"
    k_ "No she's not that kind of woman but... why she let him touch her?"
    k_ "But why are they so quiet?"
    k_ "That man is so tricky, he may force himself on Banu touch her more and ..."
    k_ "Maybe he already started it. Is he touching Banu right now?"
    "Kamil was about to open the door and end this silent madness when..."
    play sound "voices/moanfinish.mp3"

    b_ "Ahhhhhhh...."
    stop sound
    scene v13-129 with hpunch
    k "What!"
    scene v13-130 with hpunch
    "Kamil burst into the room as soon as he heard the unusual moaning of Banu..."
    "But the unexpected view in front of his eyes replaced his worry with a deep shame."
    scene v13-131
    "Ahmed watched him with a surprise smile on his face while Banu picked up the dropped phone from the ground."
    "Banu noticed Kamil's anxious face and couldn't stop the evil grin on her face."
    "She achieved her evil plan and could got her husband jealous. "
    scene v13-132
    ah "What are you doing, dude? You lost your mind? "
    ah "Get out!"
    "Kamil was so ashamed. How he could think something so dirty about his wife?"
    "He apologized one more time and closed the door from behind."
    scene v13-133
    stop music
    "Banu and Ahmed were standing there watching Kamil closing the door with a satisfied smile."
    "They achieved their plan after all. The plan which came to Banu's mind earlier today."
    scene v13-134
    b "You played your role so good, just as we agreed."
    b "He thought I really reported him. "
    ah "You are so evil Banu. Why do you do this to your husband? "
    b "He deserved this. But let's not talk about him. You are the hero of today. I guess I owe you a big thank you. "
    ah "Well you can do that. I'd love to taste the sweets you make with the cute hands of yours?"
    b "I'd love to do that. What do you want me to make for you. "
    ah "Make me pakhlava and bring to my office, will you?"
    b "Sure, but you have to wait for it. Good things take time..."



label notcallahmedevent:



    scene black with Dissolve(3)
    centered "{size=+120}Midnight{/size}" with Fade(0.5, 0.5, 5)
    scene v13-135 with fade
    "Kamil was so tired so he fell asleep immediately."
    "However Banu was thinking about stuff that was bothering her."
    scene v13-136
    if callahmed == True:
        "She was satisfied with what she's done to Kamil today."
        "But this was not going to be enough. She's not felt this strong for so long and it felt so good to dominate Kamil."


    scene v13-137
    "Feeling no shame that her husband is next to her, Banu slide her hand under her pants slowly and reached her wet pussy."
    b_ "This feels so wrong. I can't believe I've turned into such a bad person."
    b_ "Masturbating right next to my husband but thinking about another man..."
    scene v13-138
    if callahmed == True:
        b_ "I can't believe Ahmed touched me like that right before Kamil's eyes."
        b_ "He's an evil man too."
        b_ "He was massaging my private parts right in front of my husband, but I didn't do anything to stop him. "


    scene v13-139
    if callahmed == True:
        b_ "But I can't deny the fact that I liked it. I enjoyed being touched by another man."
        b_ "I enjoyed the fact that Kamil was there."
        b_ "But he couldn't do anything. That pathetic husband of mine..."



    "Banu was so horny that she got rid of all the clothes, laying completely naked next to Kamil started to rub her clit."
    scene v13-140
    b_ "I'm burning right now. Kamil just needs to turn his face to see me like this."
    b_ "But I don't care anymore. If he tries to insult me again, I know how to shut him down again."
    b_ "I need to cum so bad now..."

    jump banu_masturbates

label banu_masturbates_continue:


    if banuturansexfirsttime == True:
        scene black
        centered "{size=+120}Turan's apartment{/size}" with Fade(0.5, 0.5, 5)
        scene v14-33 with squares
        "Banu was again here in a place she hates the most."
        "She had to come here because she didn't want to destroy her marriage because of another man."
        "She didn't like Turan at all. He was not her type of a man, cocky and tricky."
        "But every time Turan found a way to slide into her self-defensive system and sometimes into her pussy."
        scene v14-34
        "But this time she came prepared."
        "She didn't want this disgraceful affair to last so she decided to put an end to this."
        scene v14-35
        "But after all, another surprise from Turan was waiting for Banu."
        b "What the fuck!"
        scene v14-36 with hpunch
        t "Hey Banu. You get prettier day by day. Don't stand just there. Come take a seat."
        scene v14-37
        b "What the hell are you doing? Are you out of your mind?"
        t "Why is that?"
        b "Just put some clothes on. We can't talk like this."
        t "This is my house after all and I decide what to wear. It's just hot here so I decided to stay naked. Is something bothering you?"
        b "Stop this Turan. It's ridiculous. Put some clothes on or I'm leaving."
        t "We both know that you're not going anywhere. You came here to be fucked and you can only leave after I finished with you, remember?"
        scene v14-38
        b "Fine, let's talk then. What you need to leave me alone already? You already got what you wanted from me."
        t "Nice point Banu. I've a good news for you. I believe that this will make you happy."
        scene v14-39
        b "I had enough of your tricks but again tell me what's this all about?"

        scene v14-40
        t "After a month I'm going to leave the city. Just one month and I'll be gone forever so you'll never see my face again."
        scene v14-39
        b "Wait..you're telling me that you'll leave the city forever?"
        scene v14-40
        t "That's right. But there's a bad news. You'll have to serve me until I leave and once I leave the city I'll forget about you. I promise."
        scene v14-39
        b "You're such an asshole! I can't believe you're telling me this."
        scene v14-43
        t "You're right. I'm asshole. Now let's get to the business. You'll just have to do this for one month and then you'll be free. "
        t "Of course if you want to stay with me after one month you can just come with me."
        scene v14-41
        b "I hate it when you talk like that you know that?"
        b "You're the last person on earth that I'd want to be with."
        b "I hate you Turan. How many times should I tell you that?"
        scene v14-42
        "Occasionally Banu's eyes drifted unconsciously towards Turan's bare manhood and she couldn't stop thinking about it."
        b_ "Look at that..."
        b_ "It looks so tough but at the same time it's beautiful."
        "It was the first time Banu paid close attention to the attractiveness of a man's penis."
        scene v14-45
        t "You're saying that but you can't take your eyes off my dick. Now don't tell me that you didn't look at it."
        scene v14-44
        b "You have a good fantasy world. It's just your fantasy that I look at you."
        b "I never enjoyed your presence, I never enjoyed being with you and I'll never give you that satisfaction. "
        scene v14-45
        t "Okay as you wish. Let's take the conversation to my bedroom..."
        b "..."
        scene black with dissolve
        ""
        scene v14-46 with dissolve
        t "Don't hurry. Take your clothes off slowly. I enjoy your undressing."
        b "One day you'll die and I'll come and spit on your grave."
        t "Are you always pessimist like that? You don't know how to enjoy the moment."
        b "You'll die one day."
        scene v14-47
        b_ "Maybe that's exactly today..."
        "Turan had no idea what Banu had planned for him all this time."
        "She wanted to end this affair. She knew that Turan would never leave her alone. "
        "She couldn't live with this. She couldn't do this to her husband because she was not that type of person."
        "She came to Turan's apartment for the last time to kill him."
        scene v14-48
        "But what Turan said earlier really confused Banu."
        "This would be just a one month affair... "
        b_ "I have to make a decision now. I came here to kill him and end this madness. "
        b_ "If I kill him the police will find out in the end but what if I bear this one more month?"
        b_ "I don't know if I can do this."
        menu:
            "Kill Turan":
                $ renpy.block_rollback()
                $ killturan = True
                $ banuagreetoobeyturanonemonth = False
                scene v14-49
                play music "audio/tension.mp3"
                "Banu was determined to finish what she came for."
                "She slowly took the knife out of the bag and squeezed it in her hand."
                b "Hey I'm having trouble unzipping my pants. Why don't you come and help me with that?"
                t "That's my girl. I knew one day you'll ask me to undress you."
                scene v14-50
                t "I'll gladly help you with that. "
                t "Just turn around..."
                scene v14-51 with hpunch
                b "This is what you deserve. Do you hear me?"
                "Banu made a quick turn around and the knife in her hand penetrated Turan's chest."
                b "Bastard, this will be the only thing you'll get from me."
                "Banu was talking bitterly and aggressively. She did what she came for and now nothing was holding her to break Turan properly."
                scene v14-52
                "Turan couldn't believe what had happened for a moment."
                "Once he realized that the sharp kitchen knife had penetrated down his right pectoral muscle, he instinctively put his hands around the knife to pull it off."
                scene v14-53
                t "What...what've you done?"
                "His face impression changed completely. The arrogant look on his face was replaced by a weak pathetic look."
                t "Are you crazy, bitch?"
                t "You'll go to the jail."
                scene v14-54
                "On the other hand, Banu was now so confident and proud of what she was doing."
                b "And you'll go to the hell! You'll be burning there and like I said I'll come and spit on your grave, asshole."
                "Banu's bitter words hit Turan and he tried to grab her by her throat."
                t "If I go to hell, I'll take you with me, bitch."
                "He tried to grab her and choke her but the pain and running blood from his body made him weak so he fell on his knees."
                scene v14-55
                b "Now it's time to pay for all the things you've done to me."
                b "I won't even call an ambulance you know?"
                b "One more motherfucker will disappear from my life today."
                scene v14-56
                t "Don't be stupid. Call an ambulance..."
                t "I'm passing out..."
                t "Please..."
                scene v14-57
                b "You're so weak, pathetic and coward."
                b "If you want me to help you, you need to beg properly. I can't hear you."
                scene v14-58
                "But Turan was already passed out."
                "Banu looked at him bitterly again. She couldn't believe that the man who did all the evil stuff was lying unconscious just before her."
                scene v14-59
                b "Hey do you hear me?"
                b "Don't try to fool me again. "
                b "After all the things you've done to me I'm still up but you're lying down here. You need me to save your ass."
                b "But you don't deserve this. You don't deserve to live. "
                scene v14-60
                "But Turan didn't move or say a single word."
                "Soon Banu realized that she was in a deep shit."
                "Her anger was replaced by fear and worry."
                scene v14-61
                stop music
                b_ "Shit! What should I do now."
                b_ "If I leave him here he'll die for sure."
                b_ "I don't want to go to the jail. But what's done is done. I believe I did the right thing."
                scene black with dissolve
                ""
            "Agree to obey him one last month":



                $ renpy.block_rollback()
                $ killturan = False
                play music "audio/sidesex.mp3"
                scene v14-62
                b "Okay, I agree to go with your rules one month but I need to make sure that you'll fucking leave after that."
                t_ "Like you've a choice."
                t "I spoke to the boss about this and he already found a worker to replace me. Now I should guide him and teach him stuff about the job."
                t "If you suspect you can always ask the boss about that."
                scene v14-63
                b "I'll give you what you want, but I have rules and you'll have to obey these rules. Only then we can do business."
                scene v14-64
                t "Wow, you have rules?"
                b "Exactly."
                t "Then what are they?"
                scene v14-65
                b "My first rule is that we won't kiss, never. You won't touch my lips."
                t "You don't like that?"
                b "I hate you and I don't want to kiss you. That's simple."
                t "Okay deal."
                scene v14-63
                b "My second rule..."
                t "Wait...I want to hear the rest after you undress completely."
                t "Take your jeans off."
                b "..."
                scene v14-66
                "Banu didn't say anything and obeyed what he ordered."
                t "That's it. Now it's good."
                t "So what were you saying?"
                scene v14-67
                b "My second rule is that you won't touch any of my private parts other than my vagina. I hate that."
                b "Is that agreed?"
                scene v14-66
                t "Well, if you mean your little butthole, I won't touch it until you asked me to."
                b "That will never happen."
                scene v14-67
                b "And lastly while we're doing it you can't talk about my family. I'd prefer you to shut your mouth completely. "
                t "If you say so. I agree to all of your rules."
                t "Now it's time to get to the business."
                t "My dick's aching for that pussy."
                t "Come here..."
                stop music
                scene v14-68 with hpunch

                jump turan_fucks_banu_1


label turan_fucks_banu_continue:
    stop music            
    scene v14-98 with Dissolve(3)
    play music "audio/action.mp3"
    "Banu was suspected about Leyla's behavior lately."
    "Her unusual visits at night bothered Banu so she decided to follow her to see where she goes. "
    scene v14-99
    b_ "Again with an outfit like that God knows where she goes."
    b_ "This girl knows how to make me crazy."
    b_ "She doesn't have any friends living in this building."
    b_ "Today I'll find out..."
    scene v14-100
    "Banu was following her daughter with careful steps and keeping the distance so she doesn't see her."
    "Leyla didn't suspect anything and think that her mother is actually smarter than her."
    scene v14-101
    "She watched her daughter enter the building and then quickly followed her."
    scene v14-102
    "Leyla entered the aisle and walked till the end."
    "Banu waited for her to knock the door in the other side of the aisle."
    scene v14-103
    b_ "If it turns out to be a boy I'll kill him."
    b_ "I hope you don't meet any male friends here. "
    b_ "You've always been a good girl but why did you change?"
    b_ "Keeping secrets from your mother, secret visits, revealing outfits..."
    b_ "I'll put an end to this..."
    scene v14-104
    "Somebody opened the door for Leyla but Banu didn't see the person inside."
    b_ "Who could that be?"
    scene v14-105
    "Banu approached and knocked on the door."
    "She waited a bit and knocked on the door again."
    "..."
    scene v14-106 with hpunch
    "She was shocked to see the similar figure in front of her."
    "Ruslan, her stepson was standing there with a bold face. He didn't seem happy to see Banu at all."
    scene v14-107
    stop music
    b "What the hell is happening here? Where is Leyla?"
    r "You always ruin the fun. You're a party pooper."
    b "What are you talking about?"
    scene v14-108
    b "Hey, Leyla....come here quick."
    scene v14-109
    b "Now explain to me. What's happening here?"
    "Leyla didn't respond rather blushed."
    r "I told you. We've organized a party with close friends. Now we're waiting for them. "
    b "You shut up. It's not a party time. You can fool your dad like that."
    scene v14-110
    b "Will you answer me Leyla? I'm talking to you."
    b "When did you start lying to your mother?"
    b "Now you go straight home. We'll talk about this once I reach home. "
    scene v14-111
    "Without saying a single word Leyla quickly left the room."
    b "It's time to put an end to this. You better not come home today."
    r "What? What's your problem with me? "
    b "Now you'll see."
    scene v14-112 with hpunch
    play music "audio/tension.mp3"
    b "YOU LITTLE BASTART!"
    r "Heyyy!"
    "Banu pushed Ruslan with all her strength that he touched the wall behind him. "
    scene v14-113
    b "How many times I told you that stay away from Leyla?"
    b "Now tell me. Did you touch her?"
    b "Answer me!"
    scene v14-114
    b "I swear to God if you touched her I'll break your hand and then I'll send you to jail."
    b "You know what will happen to you there? "
    b "Once they learn that you raped your sister they'll make you faggot."
    b "They'll use you as their sister. They'll fuck your ass."
    b "Now I'm telling you one last time. Stay away from her!"
    scene v14-115
    r "Enough of this shit. You know what, I fuck her!"
    r "I've been fucking her for the last month. She's a slut you know that? She's like you and she craves for my big dick."
    scene v14-116
    b "Stop that...She's not such a girl..."
    r "She's a slut and you have to accept it already."
    r "She's a fucking slut just like her mother."
    scene v14-117
    r "You can't deny it. It's in your DNA. "
    r "You can't reject when you see a big cock. "
    r "She's screaming when I push all the way inside her. She can't get enough of me."
    r "No matter how hard you try she'll still come to me. You can't stop her."
    scene v14-118
    r "But I may leave her alone only if you agree what I say."
    b "What?"
    r "If you deal with me, I'll stay away from her I promise."
    b "What kind of deal?"
    r "If you make me cum just once that will solve all your problems. I'll stay away from her forever."
    b "What do you mean? Make you cum?"
    r "We'll meet at the hotel tomorrow and you'll wear the most sexy lingerie you can get."
    r "That's all I want from you. You'll make me cum with your hands and the task will be completed."
    scene v14-116
    b "I can't believe this. Do you even understand what you ask your mother?"
    scene v14-118
    r "Stop that shit already. You're not my mother."
    r "Now what do you say?"
    r "If you agree, I'll stay away from Leyla forever."
    menu:
        "Get Ruslan banished from home forever":
            $ renpy.block_rollback()
            $ agreetoruslanoffer = False
            scene v14-119
            b "That's it. Kamil's the only reason that I don't send you the fucking jail."
            b "But you won't live in that house. I'm telling you this. I'll get you banished no matter what."
            b "Little bastard! You'll be living in the streets soon."
            scene v14-120
            stop music
            r "Hey wait..."
            b "You may not come home today."
            b "I told you..."
        "Agree to his offer":


            $ renpy.block_rollback()
            $ agreetoruslanoffer = True

            scene v14-121
            b_ "I guess it's the only way out of this. He's just a child. If I trick him and play with his rules, everything is going to be alright."
            b "Alright, I agree to your offer."
            b "But if you keep meeting my daughter again, I know what to do with you."
            r "Don't worry I'm a man of my word..."
            scene v14-122
            r "I knew that you'll accept it. I know that you're a lewd woman but I thought you'd reject more."
            scene v14-123
            r "Just admit that you also liked my offer."
            b "I don't have time to play with you. I'll just give you what you want and that'll be over."
            b "But I can't go to any hotel. Someone can see me going there. I can't do that."
            b "I can do what you asked in your room. That will be better."
            scene v14-125
            r "No, that's dangerous. What about my father? He can suspect anything."
            b "He won't suspect anything. He'll be sleeping."
            r "You're such an unfaithful wife. You are shameless. Every time you cheat on my father like this."
            b "Stop it..."
            scene v14-124
            r "I've a private place. Let's meet there."
            menu:
                "{color=#FF0000}Agree to meet in his private place{/color}" if agressive == True:
                    $ renpy.block_rollback()
                    $ banumeetruslaninprivateplace = True
                    scene v14-126
                    b "Alright, let's meet there."
                    r "Remember, you'll wear the most sexy lingerie you can get."
                    r "Or the deal will be cancelled."
                "{color=#008000}Insist to do it in his room{/color}":


                    $ renpy.block_rollback()
                    $ banumeetruslaninprivateplace = False
                    scene v14-127
                    b "I said we'll do it in your room."
                    b "You agree or not. I'm not going to meet you anywhere else."
                    r "Alright..."
                    r "Remember, you'll wear the most sexy lingerie you can get."
                    r "Or the deal will be cancelled."
    stop music                
    scene black with Dissolve(3)
    centered "{size=+120}A visit{/size}" with Fade(0.5, 0.5, 5)

    scene v14-226
    play music "audio/action.mp3"
    "The doorbell rang and Kamil went to open the door while Banu was busy cleaning the house."
    k_ "Who could it be this time?"
    scene black with dissolve
    k "Oh, hey man what's up?"
    scene v14-227
    p "How you dare to hit her you piece of shit!"
    k "What? What do you mean dude?"
    p "Banu told me everything. I know that you hit her and I came to tell you that she's not alone."
    p "Now I came to take her with me. She'll be living with me and when you understand your mistake you'll come and beg for forgiveness."
    p "Only then I'll let you take her."
    scene v14-246
    k "Hey you can't come to my home and talk to me like that. She's my wife and what I do with my wife is none of your business."
    scene v14-247
    p "I said she'll come with me. If you make it harder I'll have to beat the shit out of you."
    k "I'm not afraid of you, you dickhead. Now get the fuck out of my house and never come closer to my wife."
    p "You wanted that..."
    scene v14-248 with hpunch
    k "Arrg...bitch.."
    "Polad had a good chance to practice his fighting skills so he stopped talking rather took action. "
    "Kamil didn't expect Polad to hit him actually. He thought Polad will take it and leave like that but..."
    scene v14-249 with hpunch
    k "Arrrgg..."
    "Kamil had always avoided fights so when this happened he couldn't properly defend himself and took many kicks and punched on his face."
    p "Take it, you fuckface!"
    scene v14-250 with hpunch
    k "Okay okay man just stop it."
    p "Tell me, will you dare to hit her?"
    k "..."
    p "If you touch her again I'll break your bones..."
    scene v14-251 with vpunch
    "Polad finished his words and punhed him hard right on his nose once again."
    "The last punch was so hard that Kamil almost lost himself."
    scene v14-252
    stop music
    b "Polad! Get away from him!"
    "Banu heard Kamil's voice from the living room and came to see what was happening."
    "When she saw blood was running down Kamil's nose she ran and pushed Polad aside."
    scene v14-253
    b "Are you out of your mind, Polad."
    b "How could you hit him like that?"
    scene v14-254
    "Banu watched Kamil's smashed face and felt pity and he looked at Banu's eyes but couldn't say anything."
    b "Look what you've done."
    p "Now he learned his lesson and he won't touch you again. "
    scene v14-255
    b "Just shut up already!"
    p "What?"
    scene v14-256
    b "Who told you to do that?"
    p "You told me that he hit you and I can't let him do whatever he wants to do with you."
    scene v14-257
    b "I told you just to threaten him but not fight him."
    b "You almost killed him. Do you understand what you are doing?"
    scene v14-258
    p "That's enough. I did the right thing."
    p "Now let's go. You're coming with me."
    b "Stop it. I'm not going anywhere."
    p "Don't make me crazy. You come with me now or you'll never see my face."
    scene v14-257
    b "I can't do that. I should help him."
    p "Banu!"
    b "Look! This's too much, Polad. You better leave."
    p "Alright!"
    b "..."



    scene black with dissolve
    centered "{size=+120}The graveyard{/size}" with Fade(0.5, 0.5, 5)
    scene v15-1 with dissolve
    play music "audio/intro.mp3"
    "It was quite a while that Banu hadn't visited her beloved deceased husband."
    "Banu used to visit Alper's grave very often but recently she got her head so busy that she could even forget Alper who was still the most precious person for her."
    scene v15-2 with dissolve
    "Kamil didn't know about Banu's visits to the graveyard. She didn't let him know about it because she was not sure Kamil would be happy about it or even let her visit her dead husband."
    "At least Kamil was her husband and he wouldn't be happy if he knew Banu still didn't forget about Alper."
    "So Banu used to come to the graveyard to be with her beloved one and talk to him some time without Kamil knowing about it."
    scene v15-3
    "She was not afraid of coming here alone in the evenings because she didn't want anybody to see her and wanted to have alone time with Alper."
    "She was now here standing in front of Alper's grave. The grave stone was a regular stone and got dirty from the humidity because of no attention."
    scene v15-4
    b "I'm really sorry that I can't visit you often recently."
    b "A lot of things happened to me recently but I managed to survive."
    b "Life is so hard without you..."
    scene v15-5
    b "I know that I made mistakes and I've been so weak and now my life's fucked up. I don't really know what to do."
    b "Kamil's a nice man. I feel his protection all the time and he loves me. I'm sorry to say this but he's not a man that I appreciate to be with. "
    b "He's just not enough of a man that controls me, handles me or even satisfies me."
    scene v15-6
    b "You know that he can never replace you. "
    b "I'll always belong to you in this life and in the next one. My body and sould will always belong to you."
    scene v15-7
    b "I'd never let him touch my body but...he's my husband now and he deserves attention from me."
    b "Please, don't call this cheating. It's not like that."
    b "He can never touch my body like you did and the connection between Kamil and me is only physical. He's just my husband."
    scene v15-8
    b "I know that I have so many mistakes.."
    b "I'm not a complete pure woman. I've been dirty. My spirit has been touched by dirty stuff. Please, forgive me!"
    scene v15-9
    b "Once you left me, my weak body started to seek attention. "
    b "Once you stopped feeding me with your precence, I couldn't help but searched attention elsewhere."
    b "I touched my body and I enjoyed it."
    if banuturansexfirsttime == True:
        b "I let another man have my body. "
        b "He was not my husband, Kamil."
        b "I know how degrading this is but I enjoyed his touches..."

    if followpolad == True:
        b "I'm sorry to confess this but I betrayed you with your best friend..."
        b "Yes I did it with your best friend, Polad."
        b "We both betrayed you. Now you know that how awful I've been."


    if banutakethebetfuckmurat == True:
        b "Once I got drunk. I betrayed my religion. I couldn't control myself and let a boy younger than me enjoy my body."
        b "I was so desperate. I couldn't control my urges and I engaged in sex with a man."


    b "My body got so horny after you left me and I sometimes couldn't control it. "
    b "I touched my bare body. I dreamt about dirty things. I dreamt about other men..."
    b "Please, forgive me because I've been so dirty and bad. "
    b "And... stop looking at me like that. You're also guilty because you left me."
    b "I know that you can't stand it. You know that every day I sleep with another man and he touches me."
    b "He gets pleasure from my body. The body that beloged to you."
    b "I don't know why but I'm angry at you..."
    b "Please, forgive me."
    b "I have to leave now but I'll come back and one day we'll be together forever..."
    scene v15-10 with fade
    "Banu was so relieved after confessing to Alper but at the same time so embarrassed to look into his eyes."
    "She hated herself for a moment that she's been with another man other than Alper and she had to come visit him secretly."

    scene v15-11 with fade
    "But it was too late. Banu had a new life now."
    "Alper didn't exist anymore. No matter how hard Banu tried to stay with him, life pulled Banu away from Alper every single day."
    "Banu was changed. She was not the same Banu that Alper dated, not the same Banu that blushed and ran away when Alper tried to kiss her."
    "It was fortunate for Alper that he didn't see the changed Banu..."
    "...or maybe he did..."
    stop music



    scene black with Dissolve(3)
    ""
    centered "{size=+120}A confession{/size}" with Fade(0.5, 0.5, 5)
    scene v15-26 with move


    $ banuscoldpolad = False




    "As usual Polad had some alone time in the backroom where he spent most of his time at the bar."
    "The room was so quiet and nobody used to enter this room except Polad as he didn't like to be interrupted. "
    "He used to lock himself in this room, sometimes smoke a cigar, train and sometimes read one of his favorite detective novels. "
    scene v15-25
    "He was still angry at Banu since the last time he visited her. So he was reading a book to drift his mind away from Banu."
    "Polad was not used to get turned down and rejected."
    "When Banu rejected to come with him, he promised himself that he'd never call her or talk to her."
    "She had to apologize."
    "That was exactly what Banu was thinking about all day long while taking care of Kamil's fucked up face."
    scene v15-27 with fade
    "Because she just appeared in front of Polad all of a sudden catching Polad by surprise."
    "Banu had nice feelings for Polad for a long time but she was able to hide them form both Polad and Kamil. "
    "Maybe it was also time to finally confess to Polad as those feelings were too heavy to carry for one person."
    "Another reason of Banu's surprise visit was obvious..."
    "She knew that she had to apologize to get Polad's attention back, otherwise this was just impossible."
    "She found none better way of approaching him but to pay him a visit in his private place. "
    scene v15-28
    p "What're you doing here!"
    b "I came to say that I'm sorry for the last time. I didn't mean to hurt you but I just had to stay with him."
    b "..."
    p "Okay, you can leave now."
    scene v15-29
    b "Seriously? You don't even want to listen to me?"
    b "Do you know how hard it was for me to come here? Everybody was watching me to enter this damn pub, walk around, ask about you."
    b "They thought I was just one of those whores."
    b "But I came for you and you don't want to listen to me."
    scene v15-30
    p "There's no reason for you to come here."
    p "This is not a place for you. You're married and you shouldn't go to this kind of places."
    p "Now go back to your husband. He probably doesn't know that you are here."
    scene v15-31
    b "You don't understand me, do you?"
    b "I came here because you're special to me. I don't want to lose you. You're a special person left in my life after Alper. "
    b "You can't just ignore me like that."
    p "Banu, will you stop this nonsense?"
    b "So my feelings are nonsense?"
    p "What are you talking about?"
    b "I think about you all the time Polad. I can't just lose you. I'm strong as long as you're by my side."
    b "I love you, Polad!"
    scene v15-30
    p "What?"
    b "Please, don't do this to me. Don't leave me alone. I'm tired of all the maddness around me. I need your support."
    p "Do you even understand what you're saying?"
    p "You have a family and they will support you."
    p "Now leave and don't ever come here again."
    scene v15-31
    b "Really, I confessed my true feelings to you and this is your response?"
    scene v15-32
    p "I know...you may like me, but this doesn't change the fact that you're still with that faggot and as long as you're with him I've no busness with you. "
    menu:
        "Scold him for ignoring you":
            $ renpy.block_rollback()
            $ banuscoldpolad = True
            scene v15-33
            play music "audio/action.mp3"
            b "You shouldn't talk about my husband like that. It's not good to talk bad behind others' back."
            p "I see that now you're protecting him."
            p "Listen, Banu, I know what you're trying to do but it's late and now the only thing that I want you to do is to leave me alone, alright?"
            b "I can't believe you do this to me, you're such a jerk!"
            b "You really don't get it, do you? You're clueless and insensitive."
            p "Okay, you can say anything you want if it makes you happy."
            scene v15-34
            b "You're just too selfish to care about anyone else's feelings."
            b "I'm done with you. You're just a heartless, thoughtless, and immature little boy who doesn't deserve my time or attention."
            p "Oh really?"
            b "Why do you always have to be so selfish and inconsiderate?"
            b "You never think about anyone else's feelings or needs. It's always all about you and what you want."
            scene v15-35
            b "I can't believe that I fell for someone like you."
            b "Look at you...You're just an immature and careless little boy. "
            b "You're...arrogant, unpleasant, selfish bastard."
            b "And your bald head looks like a dick you know it?"
            b "Idiot...dickhead...son of a bitch..."
            scene v15-36
            stop music
            "Polad didn't say a single word and instead focused more on the page he was reading."
            "Banu noticed Polad turning the pages and reading the book without getting bothered by her words."
            "She was going crazy but she knew it was pointless to stay there any longer and what she was doing was so weak of her."
            "..."
        "Use your body to get his attention":






            jump polad_fucks_banu3

label polad_fucks_banu3_continue:


    scene black with Dissolve(3)
    ""
    centered "{size=+120}Awake at midnight...{/size}" with Fade(0.5, 0.5, 5)
    scene v15-170 with blinds
    play music "audio/sensual.mp3"
    "The night was dark and still, the moon casting shadows across the room."
    "Banu lay awake in bed as usual while her husband slept peacefully beside her. The only sound was the gentle rhythm of his breathing."
    scene v15-171
    "She couldn't sleep. Her mind was racing with worries and anxieties, and she couldn't shake the feeling of unease."
    "She knew it was irrational, but she couldn't help it. She felt alone, even with her husband right beside her."
    scene v15-172
    if followpolad == True:
        b_ "I can't believe that I let Polad fuck me just like that."
        b_ "He turns me on so much."
        b_ "I can't just control myself around him. Now I can feel how much effect he has on me."
    if banuscoldpolad == False:
        b_ "Polad's so different... so different from Kamil."
        b_ "I can't believe I let him humiliate me like that. "
        b_ "I touched his cock with my mouth. I literally let him fuck my mouth. I'd never let Kamil do something like that."

    b_ "Offf...My pussy is burning. I wish Kamil were more energetic and active..."
    scene v15-173


    if banuturansexfirsttime == True:
        if killturan == False:

            $ banuagreetoobeyturanonemonth = True

    if banuagreetoobeyturanonemonth == True:
        b_ "Turan was so intense last time."
        b_ "I agreed to serve his sexsual needs for one month. I'm so dirty woman."
        b_ "He's such a large burly male. I feel at ease with Kamil but Turan... He makes me out of my breath..."
        b_ "Ahhh....Even thinking about it makes me wet."

    b_ "My body is so hot. I should try not to make a loud noise. If Kamil wakes up..."
    b_ "This pleasure makes me sweat... I need an orgasm now..."
    scene v15-174
    stop music
    "Banu's body was stiff. She was about to reach an orgasm that had been building up."
    if banuflirtsbacktoabdul == True:

        "Her glutes were firm, up in the air. Her brain was melting. She was ready to explode but..."
        scene v15-176 with hpunch
        "She was just about to experience the powerful orgasm when she heard her phone buzzing on the nightstand."
        b_ "Shit!"
        b_ "I forgot to put my phone on mute."

        scene v15-177
        "She picked it up and saw a message from an acquaintance she hadn't spoken to in a while."

        b_ "What? What does he want from me?"

        ab_ "Hey there! Long time no talk. How have you been?"
        b_ "Hi! I'm doing well, thanks for asking. I'm just surprised to receive a mesage from you at this late hour."
        ab_ "Yeah, I know. I was just thinking about you and wanted to check in. How's life been treating you?"
        scene v15-178
        play music "audio/tension.mp3"
        b_ "Life's been good, busy as usual. But it's nice of you to ask. Sorry, it's late and I was just about to sleep."
        ab_ "Oh, I'm sorry to bother you. I didn't realize it was so late. Do you mind if we chat for just a little bit?"
        b_ "No, it's okay. I don't mind chatting for a bit. What's on your mind?"
        ab_ "Well, I've been thinking about you."
        b_ "Is that so?"
        ab_ "You know I can't sleep Banu."
        b_ "What can I do about it?"
        ab_ "Why don't you send me a photo of yours right now."
        "Banu was so horny at the moment and Abdul's offer sounded so tempting."
        menu:
            "Turn him down":
                $ renpy.block_rollback()
                $ banusendabdulselfie = False
                stop music
                b_ "You're crossing the lines right now."
                b_ "Don't send me messages like this. I'm not type of woman you think of."
                ab_ "Banu..."
                scene v15-182
                "Banu blocked Abdul right after she sent the last message and put the phone away."
                b_ "Look at the bastard..."
                b_ "Trying to flirt with his friend's wife..."
            "Send him a selfie":




                $ renpy.block_rollback()
                $ banusendabdulselfie = True
                stop music
                jump abdul_sexting_banu
    else:








        scene v15-174 with hpunch
        b "Ahhhhhh....."



label banu_send_abdul_nude_continue:
    scene black with Dissolve(3)
    ""
    centered "{size=+120}An acquaintance{/size}" with Fade(0.5, 0.5, 5)
    scene v15-183 with pixellate
    play music "audio/kometaback.mp3"
    "Banu had just finished a long day at work and was looking forward to getting home."
    scene v15-184
    "As she reached the entrance of the building she noticed a similar face."
    scene v15-185
    "She noticed her husband's friend approaching her from the opposite direction."
    b_ "Oh...what was his name? God...I'm really bad at remembering names..."
    b_ "Oh yess..Farhad!"
    scene v15-186
    "Feeling a little surprised but not uncomfortable, she greeted him politely and asked how he was doing."
    "He explained that he was just out for a walk and happened to be in the area."
    "As they chatted, Banu noticed that Farhad seemed a little distracted and troubled. "
    "She asked him if everything was alright, and he confided in her about some personal struggles he was going through."
    scene v15-187
    b "No really, I guess you hide something from me."
    far "Well, I know that Kamil lost 10000 recently."
    b "Well, what do you know about it?"
    scene v15-188
    far "Yeah, it's been bothering me because I feel like I should say something, but I don't want to cause any trouble or make things awkward between us."
    far "But I know that he's actually one of his friends who did that."
    scene v15-189
    b "I understand. It can be tough when you're caught between loyalty to friends and doing the right thing. But I think it's important to be honest and open about these things."
    far "I just don't want to be the one to stir up drama or cause any problems."
    b "I get that, but think about it this way - if someone did steal from my husband, that's a serious breach of trust and integrity."
    b "If it were me, I would want to know so that I could take appropriate action and protect myself and my family."
    scene v15-190
    far "I don't know if you know that but Kamil and me fell out recently and I don't talk to him anymore."
    far "Despite all of this, I don't want Kamil to suffer because I was his best friend."
    far "And I know who slote the money from him and I want you to know that."
    b "Oh really? Who was it?"
    far "It was Abdul, the fat friend of Kamil. I heard it from a mutual friend who saw him with the cash."
    scene v15-191
    b "What? Abdul is one of my husband's closest friends. I can't believe he would do something like that."
    far "I know, it's a terrible situation. I've been feeling guilty about not telling you earlier."
    scene v15-192
    b "I appreciate you telling me now. We need to confront Abdul about this and get to the bottom of things."
    far "I completely agree. I'm so sorry this happened, and I hope it doesn't affect our friendship."
    scene v15-193
    b "It's not your fault, you did the right thing by telling me. But Abdul is not a true friend if he would steal from us."
    far "I understand. I'll support you and Kamil in any way I can."
    b "Thank you, I really appreciate it. It's going to be a difficult conversation, but we have to do what's right."
    scene v15-194 with fade
    "As Farhad said bye and started walking away, Banu couldn't help but thought that despite everything, Farhad was still a very good person. "
    "She was grateful for his honesty, and knew that his friendship with her husband would never be the same, but she still felt a sense of compassion towards him."
    stop music


    show black with Dissolve(3)
    ""
    centered "{size=+120}Ruslan{/size}" with Fade(0.5, 0.5, 5)
    if agreetoruslanoffer == False:

        scene v15-223 with blinds
        play music "audio/tension.mp3"
        "Banu sat on the sofa with a troubled look on her face, her hands folded in her lap."
        "Kamil stood in front of their already adult son scolding him for what he had done."
        scene v15-224
        k "What have you turned into? I closed my eyes everything else you've done but this is just insane."
        k "How could you do something like that to your sister?"
        b "His actions lately affecting our home and my daughter. I think it's time already to send him away home."
        b "This would be better for both him and us."
        scene v15-225
        r "What's going on here? Are you trying to get rid of me?"
        b "Ruslan, it's not like that. We just can't tolerate your behavior anymore."
        r "I knew it! You always wanted to get rid of me. You never cared about me."
        k "That's enough, Ruslan. You need to respect your mother and our rules."
        r "I can't believe this! You're just like her, dad. You're always on her side!"
        scene v15-226
        r "You just want to get rid of me, don't you? You can't stand having me around anymore!"
        k "Enough! Both of you! Ruslan, you have been behaving terribly lately and you need to take responsibility for your actions."
        r "I can't believe you're taking her side over mine! You always do this, you never listen to me!"
        k "That's it. I've had enough of your behaviour."
        scene v15-227 with hpunch
        "Kamil couldn't take it any longer and slapped Ruslan so hard that he lost stability and fell to the ground."
        scene v15-228
        b "You deserved it, Ruslan."
        "Ruslan was shocked by his father's action and surprised how his father support and comply everything that Banu said."
        "He looked bitterly at Banu."
        scene v15-229
        b "This is for your own good, Ruslan."
        b "The streets will teach you a lot of rules that we can't teach you."
        r "Are you happy now? Bitch!"
        scene v15-230
        k "That's it, I've had enough. You're leaving this house right now."
        r "Fine, I'll leave! I don't need any of you anyway!"
        stop music
    if agreetoruslanoffer == True:

        if banumeetruslaninprivateplace == True:

            scene v15-120 with blinds
            play music "audio/tension.mp3"
            jump ruslan_rapes_banu

        if banumeetruslaninprivateplace == False:

            jump banu_humiliates_ruslan
    stop music        


    jump ruslan_rapes_banu_continue

label ruslan_rapes_banu_continue:






    scene black with Dissolve(3)
    ""
    centered "{size=+120}Coffee break{/size}" with Fade(0.5, 0.5, 5)


    $ banuwantstoteaseintern = False
    $ banustaysalittlelongerintern = False
    $ banurevealthetruth = False
    $ banupushabdulaway = False
    $ banuconfessapastsecrettokamil = False
    $ banusharedetailswithkamil = False
    $ banuagreebowlingmurat = False
    $ banugotomuratsapartmentafterfun = False



    scene v16-1 with blinds
    "Banu was busy organizing files neatly on the shelf. "
    "Just as Banu was immersed in her work, the door creaked open, and Samir walked in with an eager smile."
    "He carried two steaming cups of coffee with a touch of nervousness mixed with excitement in his eyes."
    "Banu had asked him to bring the coffees, and secretly, he was thrilled for this chance to spend some time with her."
    scene v16-2
    b "Oh, Samir! You brought the coffees. Thank you so much."
    sam "You're welcome, Banu. I wanted to make sure they were just the way you like them."
    b "I appreciate your thoughtfulness, Samir. You're doing great as an intern here."
    b "Please, put the coffees on the table and come join me on the sofa. Let's take a break and chat for a while."
    sam "Sure, Banu. I'll do that."
    scene v16-3
    "Samir carefully placed the cups on the table and walked over to the sofa, sitting down beside Banu."
    "She couldn't help but notice the subtle signs of nervousness etched on his face."
    "Banu recognized the signs and wanted to alleviate Samir's unease. She finished organizing her files and set them aside, giving him her undivided attention."
    b "Samir, I can't help but sense a bit of nervousness. Is everything okay?"
    sam "Oh, um, yeah, Banu. I'm fine. It's just... I don't want to make any mistakes in front of you. I want to do a good job."
    b "Samir, I understand how you feel. We all have moments of nervousness, especially when we're starting something new."
    b "But please remember, mistakes are a natural part of the learning process. What's important is that we learn from them and grow."
    sam "Thank you, Banu. I appreciate your understanding. I really want to make a good impression here."
    scene v16-13
    b "Ah, that's good. It's nice to have a moment to relax, isn't it?"
    sam "Absolutely. It's a great opportunity to learn from someone experienced like you."
    b "Thank you, Samir. I'm happy to share my knowledge and help you grow in your career. So, how are you finding your time here so far?"
    sam "It's been amazing, Banu. I've learned so much already, and everyone has been really supportive. Working alongside professionals like you is truly inspiring."
    scene v16-4
    b "So, Samir, let's talk about something a bit more personal. Love and relationships. What are your thoughts on that?"
    sam "Oh, love and relationships, right. Well, I think it's a complicated subject, you know?"
    sam "People have different expectations and experiences, and it can be challenging to navigate."
    b "I sense some hesitation, Samir. Is there something on your mind? Perhaps a personal experience you'd like to share?"
    sam "Well, honestly, it's not something I usually discuss, but I've had some mixed experiences. It can be confusing at times, and I'm still trying to figure it all out."
    b "I understand, Samir. Relationships can be complex, and it takes time to find what works for each individual. It's alright to take your time and explore what feels right for you."
    b "Samir, I'd like to discuss something with you. What are your thoughts on a situation where a young boy develops feelings for an older woman?"
    b "How do you think such a scenario should be approached?"
    scene v16-5
    sam "Oh, well, I don't see any problem with that, Banu. Age shouldn't matter when it comes to love, right? "
    sam "If two people genuinely care for each other, I think they should be allowed to explore their feelings, regardless of age."
    b "Samir, love is indeed a beautiful thing, but it's important to consider the complexities that can arise in relationships with significant age differences."
    sam "I guess I haven't really thought about it that way before. I just believe that love knows no boundaries, and if two people connect, age shouldn't be a barrier."
    b_ "Oh, Samir, you're so young and idealistic. It's clear that you still have much to learn and experience when it comes to matters of the heart."
    b_ "Your belief that love knows no boundaries is charming, but it overlooks the potential power imbalances, societal judgments, and practical challenges that often come into play."
    menu:
        "Banu wants to help him":
            $ banuwantstoteaseintern = False
            $ renpy.block_rollback()
            scene v16-6
            b "Samir, I've noticed that you tend to be quite shy, and I want to discuss this with you. "
            b "Frankly, I'm a bit frustrated with your shyness because it can hinder your personal growth and interactions, particularly when it comes to relationships."
            sam "Oh, I'm sorry, Banu. I didn't mean to frustrate you. Shyness has always been a part of who I am, and it's not something I can easily change."
            b "I understand that shyness is a part of your personality, Samir, but that doesn't mean you can't work on overcoming it or finding ways to manage it."
            b "It's essential to realize that shyness can hold you back from fully experiencing life and forming meaningful connections."


            scene v16-7
            sam "I don't think being shy is such a bad thing. I've always been reserved, and I've managed to get by just fine."
            b "Samir, I understand that you may feel comfortable with your shyness, but it's important to recognize that it can limit your opportunities."
            b "If you want to grow personally and establish strong relationships, you need to challenge yourself and step out of your comfort zone."
            sam "Why are you so against my shyness? It's a part of who I am, and I don't see why I need to change just to please others."
            b "Samir, I'm not asking you to change who you are at your core. I'm merely encouraging you to develop social skills and confidence so that you can fully express yourself and connect with others."
            b "It's not about pleasing others; it's about unlocking your own potential and fostering meaningful relationships."
        "Banu wants to tease him":




            $ banuwantstoteaseintern = True
            $ renpy.block_rollback()
            play music "audio/sidesex.mp3"
            scene v16-8
            b "Samir, I wanted to ask about your relationship with your girlfriend. Last time we spoke, you mentioned her. How are things going between you two?"
            sam "Actually, Banu, she's no longer my girlfriend. We broke up recently."
            b "Oh, Samir, I'm sorry to hear that. Are you okay? Do you want to talk about what happened?"
            sam "It's just that she felt I was too reserved and shy, that I didn't open up enough. She said she needed someone who could be more emotionally available and outgoing."
            b_ "Poor Samir..."
            b "I understand that this must be difficult for you. It's unfortunate that your shyness played a role in the relationship ending."
            sam "I guess you're right, Banu. Maybe I do need to work on being more open and expressive in my future relationships."
            scene v16-9
            b "Well, Samir, now that you're single, are you ready to dive back into the dating world and find yourself another girl?"
            sam "Oh, Banu, I think I need a little time to heal and focus on myself before jumping into another relationship. But who knows, maybe in the future, I'll be ready to give it another shot."
            b_ "He's so funny..."
            b "That's fair, Samir. Take your time, enjoy being single, and when you're ready, don't forget to put those newfound social skills and confidence to good use. Just remember, there's plenty of fish in the sea."
            scene v16-11
            "Banu, feeling a mischievous spark, decides to playfully tease Samir. She moves closer, intentionally invading his personal space. Samir, taken aback, starts to feel uncomfortable, shifting uneasily in his seat."
            b "Now, Samir, let's get a little closer for some girl talk, shall we?"
            sam "Uh, Banu, I think this is close enough. I can hear you just fine from here."
            b "Oh, come on, Samir, don't be shy. It's just a little chat between friends."
            scene v16-10
            b "So, Samir, let's have a little chat about girls. I know it can be a bit overwhelming, but I'm here to offer you some advice from my years of experience."
            sam "Uh, okay..."
            b "First things first, confidence is key. Believe in yourself and let your authentic personality shine. Girls are attracted to someone who is comfortable in their own skin."
            sam "Uh, I'll try my best to be more confident, Banu. It's just not something that comes naturally to me."
            scene v16-12
            b "So, Samir, I've noticed you've been quite attentive today. Is there something on your mind?"
            sam "Uh, well, I guess I... um... enjoy our conversations. You're really easy to talk to, Banu."
            b "Oh, Samir, you're such a charmer. I appreciate your kind words. You're a great listener, too."
            b "Well, Samir, it seems like someone has a little crush on their HR assistant. Should I be worried about the company's intern policy?"
            sam "No, no, Banu! It's not like that. I mean, I do like you, but it's just... um... a friendly liking, you know?"
            b "I see you're a grown up man already and you started to look at my ass. Do you like that?"
            sam "No! Banu...that was just..."
            b "I saw it, Samir. You can't deny that. Your bulging pants tell me that you're so excited about me."
            b "I'm sure that you dreamt about me and masturbated countless times thinking about me. "
            sam "Banu..."
            b "Well, you know that you can't have me but there's something that you can do. You're a man now and you need to release the sperm from your body."
            b "Do you know that I don't shave my pussy? Hehe now you know that. Jerk off your cock thinking about my pussy. You need it and I'm not against it."
            sam "No, no, Banu! It's not like that...."
            scene v16-13 with fade
            b "Of course, Samir. I was just teasing you. Don't worry, your secret crush is safe with me."
            stop music

    scene v16-5 with fade
    b "Samir, I really need those files for a project I'm working on. Did you bring them as I asked?"
    sam "Oh, Banu, I'm so sorry, but I completely forgot to bring them. They're still at home. I feel terrible about this."
    b "Samir, I needed those files today. It's crucial for the progress of the project. Is there any way you can retrieve them quickly?"
    sam "Actually, Banu, I live close by. If you'd like, I could go to my place and grab the files but I was thinking..."
    sam "How about coming over this afternoon to collect the files?"
    sam "Plus, it'll give you a chance to see where I live. "
    b "Well, since I do need the files and you're offering, I suppose it would be convenient."
    sam "Absolutely, Banu! Thank you for accepting my invitation."
    "Banu and Samir agree on the plan, with Banu feeling a mix of relief and curiosity about Samir's home."
    "They quickly discuss the logistics and set a time for the visit, ensuring that the work will continue smoothly. The invitation to Samir's home adds a touch of anticipation to their day."

    scene black with Dissolve(3)
    ""
    centered "{size=+120}Samir's home{/size}" with Fade(0.5, 0.5, 5)
    scene v16-14 with fade
    play music "audio/kometaback.mp3"
    "Banu arrives at Samir's home in the sunny afternoon, curious to see where he lives."
    "As she approaches the house, she notices that it is a small, old building with a charming, albeit weathered, exterior."
    scene v16-15
    sam "Hey, Banu! I'm glad you made it. Welcome to my home."
    b "Thank you, Samir. It's nice to be here."
    sam "So, this is our little garden. It's not much, but it's a nice spot to relax and enjoy some fresh air."
    b "It's lovely, Samir. I can see the care you put into maintaining it. It's a peaceful retreat."
    "Banu couldn't help but notice the age and wear of Samir's home, but she tactfully avoids bringing it up to spare Samir any further embarrassment."
    "She understands that their financial situation may have contributed to the condition of the house and doesn't want to make Samir feel uncomfortable about it."
    scene v16-16
    stop music
    meta "Samir, who is this young lady?"
    sam "This is my mother...Come and meet her, Banu."
    scene v16-17
    sam "Mom, this is Banu, my colleague from work. She's here to visit and spend some time with us."
    sam "Banu, this is my mom, Metanet."
    b "Nice to meet you, aunt."
    "Instead of offering a warm greeting, Metanet's face displays a disapproving expression. She immediately redirects her attention towards Samir."
    meta "Samir, why are you bringing your colleague into the house? You know very well that we have our own responsibilities and chores to attend to."
    sam "Mom, Banu is just visiting. I invited her over to spend some time together. It's important to show hospitality and make her feel welcome."
    meta "Hospitality? Is that what you call it? Instead of helping me with the household tasks, you're gallivanting around with your colleague. It's high time you focus on your responsibilities here."
    "Banu feels a sense of discomfort witnessing the tension between Samir and his mother. She tries to remain composed, knowing that it is not her place to interfere in their family dynamics."
    scene v16-18
    b "Aunt, I apologize if my presence has disrupted your routine. I didn't mean to cause any inconvenience."
    meta "Your presence is not the issue. It's Samir neglecting his duties and prioritizing other things over his family responsibilities. We have our way of doing things here."
    meta "Well, Banu, it's quite usual I see for women to wear these tight jeans trousers nowadays. Don't you think it's a little inappropriate. We have different standards here."
    b "I understand, Aunt. Fashion choices can vary, and I respect that. I assure you, it's nothing disrespectful or inappropriate."
    scene v16-19
    meta "It's not about fashion, dear. It's about respecting our traditions and values. We have certain expectations when it comes to proper attire."
    b "I apologize if my attire doesn't align with your expectations, Aunt. I didn't mean to offend anyone. I assure you, my intention is to be polite and respectful."
    scene v16-20
    sam "Mom, let's not focus on Banu's attire. She's a wonderful person and a valued colleague. I invited her here because I enjoy her company."
    "Samir, sensing the tension between his mother and Banu, takes a step forward to defuse the situation and invites Banu inside the house."
    sam "Banu, why don't we go inside? Please, come in and make yourself comfortable."
    b "Thank you, Samir. I appreciate your hospitality."
    scene v16-21
    "Metanet, still harboring her concerns, watches as Samir and Banu walk into the house together. She remains hesitant and decides not to follow them."
    "Banu follows Samir into the house, but she notices that Metanet doesn't join them."
    "As she steps inside, she takes a closer look at the room and notices its dilapidated state. The furniture is worn, the walls are peeling, and dust collects in neglected corners."
    "Banu maintains her composure, not wanting to make Samir feel embarrassed or uncomfortable about the condition of the room. "
    b "Samir, your home has a certain charm. It feels lived-in and carries a sense of history."
    sam "Thank you, Banu. I know it's not the most glamorous place, but it's where I grew up. It may not look like much, but it's filled with memories and love."
    scene v16-22
    sam "Banu, I'm sorry about my mother's behavior earlier. She's going through a tough time, and I think she was just upset about something unrelated. It's not a reflection of how she feels about you."
    b "Samir, there's no need to apologize. I understand that people have their own struggles and emotions. I hope everything gets better for your mother soon."

    scene v16-23
    sam "Banu, would you consider staying a bit longer? I enjoy spending time with you, and I don't want our conversation to end just yet."
    menu:
        "Banu is in a hurry":
            $ banustaysalittlelongerintern = False
            $ renpy.block_rollback()
            b "Samir, I would love to stay longer, but I'm afraid I'm in a bit of a hurry. I really need those files we discussed earlier, so I can't stay for too much longer."
            sam "I understand, Banu. I'm sorry for keeping you waiting. Let me go and get the files for you right away."
            b "That would be great, Samir. I appreciate your help. Just grab the files quickly so I can take them with me and continue my work."
            scene v16-24
            "Banu observes Samir as he searches for the files, and a sense of pity washes over her. "
            "She can't help but feel a pang of sympathy for him and his family, realizing the financial hardships they must be facing."
            b_ "It's heartbreaking to see how they're struggling financially. The condition of their home and the challenges they face must weigh heavily on Samir's shoulders."
            b_ "He's just a young man trying to navigate his way through life, and yet he's burdened with so much. I can't imagine the difficulties they've endured."
        "Banu enjoys to stay a little longer":


            $ banustaysalittlelongerintern = False
            $ renpy.block_rollback()

            jump banuteaseinterninhishome


            scene v16-25
            b "Well, don't you think it's late?"
            sam "Banu, please stay a little longer. I enjoy our conversations and your company. It would mean a lot to me."
            b "Well, Samir, since you asked so nicely, I suppose I can stay a little longer. But remember, I have other things to attend to, so don't get too used to it."
            scene v16-26
            "Banu, feeling a sense of comfort and playfulness in Samir's home, notices his bed and decides to playfully walk over and sit on it."
            "With a mischievous smile, she takes a few steps towards the bed, her movements light and carefree."
            "Banu approaches the bed, her fingers lightly grazing the edge as she lowers herself onto it, settling in with a playful bounce. The bed feels soft and inviting, adding a touch of spontaneity to their interaction."
            scene v16-27
            "Samir watches Banu's playful actions, a mix of surprise and delight on his face. He finds her spontaneity endearing, and it brings a sense of warmth to the atmosphere."
            sam "Banu, you certainly know how to make yourself at home!"
            b "Well, Samir, it's all about being comfortable, right? And your bed looked too inviting to resist."
            sam "I'm glad you feel comfortable here. It's nice to have someone who can bring a sense of lightness to this place."
            "Banu's playful gesture breaks the tension that may have lingered, allowing both of them to relax and enjoy the moment. The simple act of sitting on Samir's bed creates an intimacy that brings them closer together."
            b "So, Samir, since I'm staying a bit longer, how about we play a little game?"
            sam "A game?"
            b "Yeash, come and sit with me."
            scene v16-28
            "Banu, feeling a sense of adventure, suggests playing a game of truth or dare, wanting to delve deeper into their connection. She looks at Samir with a playful glint in her eyes and extends an invitation."
            b "Let's play a game of truth or dare. It's a great way to get to know each other better. What do you say?"
            sam "Um, truth or dare? That sounds... fun, I guess. Okay, let's do it!"
            "They face each other, their knees slightly touching, as the game begins. Banu starts by taking the first turn."
            scene v16-29
            "Banu notices Samir's nervousness and she starts to really enjoy it while slightly caressing his knee with her fingers."
            b "Alright, Samir, truth or dare?"
            sam "Um, let's start with... truth."
            b "Alright, Samir. Here's my question for you. What's the most adventurous thing you've ever done?"
            "Samir takes a moment to think, his face lighting up with a mix of excitement and nostalgia."
            sam "Well, a few years ago, I went skydiving with my friends. It was an adrenaline rush like no other, and I still remember the feeling of jumping out of the plane. It was both terrifying and exhilarating at the same time."
            scene v16-31
            sam "Alright, Banu, truth or dare?"
            b "I'm feeling brave today. Give me the truth, Samir."
            sam "Alright then, here's my question. What's the most embarrassing thing you've done with your husband?"
            scene v16-29
            "Banu's eyes widen, caught off guard by the question. She blushes, realizing she'll have to share a personal and potentially embarrassing moment from her own experiences."
            b "Well, if you wanna hear it, here it comes."
            b "A few years ago when we were having sex, he tried to do me from behind, you know what I mean? "
            b "He tried to enter me from the back door. I could never let that happen of course."
            b "Do you know what happened next? He slept that night on the sofa. I tought him a good lesson that night."
            b "Are you satisfied now?"
            scene v16-30
            "As the game of truth or dare continues, it's Banu's turn to ask Samir an embarrassing truth. She takes a moment to think, her playful eyes scanning Samir, searching for a question that will challenge him."
            b "Alright, Samir, truth or dare?"
            sam "Well, I've survived a few truths so far. Let's stick with truth again."
            b "Alright, Samir. Here's my question for you. Who do you think about when you masturbate?"
            sam "Well, I don't actually masturabte so much...just one or two times in a month..."
            b "Come on, I know that you maturbate every day. I sense it when I look at you but that is not important. Answer my question?"
            sam "Well since we're so open like this...here's the truth. I think about you, Banu!"
            b "Wow...I knew that."
            sam "Are you satisfied now?"
            b "I guess so."
            scene v16-31
            sam "Alright, Banu, truth or dare?"
            b "I'm up for a dare this time, Samir. Bring it on!"
            "Samir's eyes widen, realizing the daring nature of his dare. He takes a moment to gather his thoughts, wanting to push the boundaries just enough to create a playful and exciting moment."
            sam "Alright, Banu, for your dare... I dare you to take off one piece of clothing."
            scene v16-29
            "Banu's eyebrows raise in surprise, caught off guard by the audacity of Samir's dare. She giggles, a mischievous glint in her eyes."
            b "Oh, Samir, you're getting bolder, aren't you? Alright, challenge accepted!"
            scene v16-32 with hpunch
            "It took Samir by surprise that Banu actually started unbuttoning her shirt slowly from the bottom to the top."
            b "Do you think that I'll accept the defeat? Never!"
            sam "Banu...what are you doing?"
            b "What? Don't you want to see what is inside? "
            scene v16-33 with hpunch
            sam "Banu, you really did that..."
            b "Well, do you like what you see?"
            sam "I..I don't know...yeah of course I like it but...I just can't believe you did that..."
            b "This is only for you Samir. I know you wanted to see them so bad, didn't you?"
            sam "..."
            b "Do you want to touch it?"
            sam "Yeah, but..."
            b "Come on touch it already, I don't have much time."
            scene v16-34
            sam "It's so soft and warm, Banu."
            b "Do you like it?"
            sam "Of course I do."
            b "Feel free to play with it but don't squeeze it so hard."
            sam "No, I won't..."
            b "I see you're excited down there...Do you let me touch you?"
            sam "..."
            scene v16-35
            sam_ "Oh shit..."
            b "Wow, you're rock hard."
            b "I didn't know I make you excited like this."
            b "I should definitely be careful around you, big boy."
            scene v16-36 with hpunch
            meta "Samir, what are you doing so long here?"
            "As Banu and Samir immerse themselves in the game, their playful banter is suddenly interrupted by the entrance of Samir's mother."
            scene v16-37
            "Banu quickly turned around to button her shirt while Samir confronted his mother."
            sam "Mom, why are you shouting again?"
            meta "What do you mean why I'm shouting? Why hasn't she left already? What is she doing there."
            sam "Mom, she's just picking the documents related to work."
            scene v16-38
            b "I'm sorry, I took a lot of your time. I'm just about to leave."
            "Metanet's disapproval towards Banu is palpable as she enters the room."

            scene v16-39
            "Her cold gaze and distant demeanor make it clear that she does not hold a favorable opinion of Banu."
            "Metanet's brows furrow, and her lips form a thin line, indicating her disapproval."
            meta " Samir, can I speak with you for a moment?"
            scene v16-40
            "As Samir follows his mother, Banu observes the interaction, noting the tension and the strained expressions on their faces. "
            "Banu's suspicions about Metanet's feelings are confirmed as she witnesses the whispered conversation between Samir and his mother."
            "Although unable to hear their words, Banu can sense the gravity of the situation by the disappointment etched on Samir's face."
            "Despite feeling the weight of Metanet's disliking, Banu remains composed, understanding that it's crucial not to escalate the tension."

label banuteaseinterninhishome_continue:



    scene black with Dissolve(3)
    ""
    centered "{size=+120}Abdul{/size}" with Fade(0.5, 0.5, 5)
    scene v16-41 with pixellate
    ab "Ah, Kamil, it's good to see you, my friend. Another successful day in the real estate business, I presume?"
    k "Absolutely, Abdul! We're making great strides. Our latest project is going to be a game-changer. I couldn't have done it without you, my trusted partner."
    ab "Oh, come on now, Kamil. You give me too much credit. It's your vision and hard work that truly make things happen. I'm just lucky to be by your side."
    k "We've been through so much together, and I know I can always count on you. You're like family to me."
    ab "Well...yeah...that's exactly how I feel too, Kamil."
    k "Well, Banu has outdone herself tonight. Wait until you taste her special dish."
    ab "I can already smell it. Banu's cooking is legendary. I can't wait to savor every bite. You're a lucky man, Kamil, to have such a talented wife."
    scene v16-42
    "Abdul and Kamil took their seats at the beautifully arranged dinner table."
    ab "Kamil, my friend, I've been meaning to talk to you about something. I hope you don't mind."
    k "Of course, Abdul. What's on your mind?"
    ab "Well, you know, we've been through a lot together, and trust is the foundation of our friendship, isn't it?"
    k "Absolutely, Abdul. Trust is everything. I trust you implicitly."
    ab "That's good to hear, Kamil. Because, you see, something has been bothering me lately. I couldn't help but notice that you lost some money recently. Is everything alright?"
    k "Lost money? Yes, actually. I've been trying to figure out what happened. It was a significant amount, and I can't seem to trace it back to anyone specific."
    scene v16-43
    ab "Oh no, Kamil! That's terrible. I can't believe someone would do that to you. It's a harsh world out there, and you never know who you can trust."
    k "Indeed, Abdul. It's disheartening. I always thought we had a circle of trust among our colleagues and friends, but this incident has shaken my faith."
    ab "Kamil, my friend, you must be careful. Trust is a fragile thing. It's crucial to surround yourself only with those who have proven themselves, like your best friend Abdul here."
    k "You're right, Abdul. It's unfortunate that I've had to learn this the hard way. But I still have faith in our friendship. You've always been there for me, and I trust you implicitly."
    scene v16-44
    play music "audio/tension.mp3"
    ab "Thank you, Kamil. Your trust means the world to me. I'll always have your back, no matter what."
    b "How is everything, gentlemen? Is there anything else I can bring for you?"
    scene v16-45
    k "Everything is delicious, Banu. You've outdone yourself once again. Thank you."
    b "I'm glad you're enjoying the meal. But, Kamil, is there anything specific you need? More water, perhaps?"
    k "Actually, Banu, there is something on my mind. I've been trying to figure out what happened to the money I had saved for the down payment. It's been bothering me."
    b "You know, Kamil, sometimes we discover the truth in the most unexpected ways. It's important to trust our instincts and those who have proven their loyalty."
    k "You're right, Banu. Trust is vital, and I believe in our friendship. Abdul has always been there for me, like a brother."
    scene v16-46
    b "Yes, like a brother. But sometimes, even those closest to us can disappoint us, Kamil."
    scene v16-47
    ab "Banu, I'm sure Kamil appreciates your concern, but we should focus on enjoying this lovely dinner."
    b "Kamil, I heard something from a friend. They mentioned something that made me question Abdul's intentions."
    k "Banu, what are you saying? Abdul is my best friend."
    b "I understand your trust in him, Kamil, but sometimes, even the closest people can deceive us. I don't want you to be taken advantage of."
    ab "Oh, Banu, you're always so cautious. You know me. I would never betray Kamil's trust. We're like brothers."
    scene v16-46
    b "Yes, Abdul, you claim to be like brothers, but actions speak louder than words."
    if banusendabdulselfie == True:

        scene v16-47

        ab "Banu, you're treading dangerous waters here. You wouldn't want me to expose your little secret, would you?"

        b_ "Shit...why is he talking so open like that?"

        b_ "Damn...he has my naked photos..."

        b_ "If he shows them to Kamil...."

        ab "What are you thinking about, Banu. I'm sure that was just a misunderstanding, right?"
        scene v16-46
        b "Of course, Abdul. I'm sorry for any confusion I may have caused. Let's just forget about it and move on."
        k "What's going on? I sense something isn't right."
        b "It was nothing, Kamil. Just a silly misunderstanding. I apologize for bringing it up."
        scene v16-47
        stop music
        ab "Yes, Kamil, it was all a misunderstanding. Banu is a dear friend, and we would never let anything come between us."
        k "Alright, if that's the case, let's put it behind us. I don't want any misunderstandings to ruin our friendship."
        "Abdul's threat hangs in the air, casting a shadow over the atmosphere. Banu, fearing the potential consequences of exposing Abdul, chooses to retract her accusations, hoping to protect herself and her own secrets."
        "Kamil, unaware of the underlying tension, accepts their explanations, albeit with a lingering sense of unease."
        scene v16-48 with fade
        "Abdul excuses himself from the dinner table, requesting to use the restroom."
        scene v16-49 with fade
        "As he passes through the kitchen, he finds Banu standing by the sink, diligently washing the plates."
        "Abdul approaches Banu cautiously, his eyes scanning the room to ensure their privacy."
        scene v16-50 with fade
        ab "Look, I know you were just trying to protect yourself earlier. But we both know the truth. You know what I did."
        b "I won't be intimidated by your threats. "
        ab "Look at me!"
        scene v16-51
        ab "I don't know what you're trying to do, but if you dare to expose me, your husband will know how slut you are."
        ab "I will send him the naked photos of his wife. I'm sure he'll be surprised."
        b "Just stop it. You have to give the money back. It's a lot of money. I won't keep it secret from Kamil. "
        scene v16-53
        ab "Dear Banu, unfortunately I spent all of it with pleasure."
        b "You've spent all the money?"
        ab "Oh, Banu, you have no idea the pleasures money can bring. It was too tempting to resist. And speaking of pleasures, I must say, your figure is truly alluring."
        scene v16-52
        b "This is not a joke, Abdul. You stole from Kamil, and now you're making inappropriate comments. I won't tolerate your behavior any longer."
        ab "Come on, Banu. Don't act so righteous. We both know you've got a secret side too. I can see the desire in your eyes."
        scene v16-53
        ab "Banu, you know Kamil is completely drunk, right? He's stumbling over his words and can barely keep his eyes open. It's a shame, really. He doesn't even realize what he has right in front of him."
        b "Abdul, this isn't the time or place for your inappropriate comments. Kamil is my husband, and I won't entertain your advances or disrespectful remarks."
        ab "Oh, Banu, you're simply breathtaking. It's hard for any man to resist your charm. Don't you think it's a shame that Kamil can't appreciate what he has?"
        b "Kamil and I have a strong bond, and I will not let you jeopardize it."
        ab "Jeopardize it? Banu, you're blind if you can't see that Kamil isn't enough for you. I can give you everything you deserve, everything he can't."
        scene v16-52
        play music "audio/intro.mp3"
        ab "Kamil doesn't appreciate you like I do. He's too drunk to even notice what's happening right under his nose."
        b "That's enough, Abdul. I won't engage in this conversation any further."
        b "You need to leave."
        ab "Oh, Banu, you can't deny your true colors. I've seen the way you look at me when you think nobody is watching. Your eyes betray your desires, no matter how hard you try to hide them."
        ab "Your loyalty to Kamil is wavering, and deep down, you yearn for something more exciting, more passionate. You can't hide your true nature from me."
        ab "I guess I have to show you the proof of my admiration to your body. I really enjoyed your naked photos."
        scene v16-54 with hpunch
        "Abdul suddenly pulled his pants down revealing his fully erect uncircumcised cock."
        b "What...what are you doing? Are you out of your mind?"
        ab "I can make your dreams come true, if only you let me."
        ab "My cock is aching to get into your married pussy."
        ab "There's nobody at home and Kamil is so drunk to notice. Let's do it here. Just turn around and pull your jeans down."
        scene v16-55
        b "What?"
        b_ "It's different from Kamil's dick."
        b_ "The foreskin covers its head. He's not had an operation... "
        b_ "Damn, what am I thinking?"
        ab "What are you thinking about?"
        scene v16-56
        b "You need to leave right now. Kamil could come and see us any minute."
        ab "Does it bother you that my dick is uncircumcised?"
        b "..."
        ab "Right, you're a religious lady and you only had circumcised dick in your pussy."
        scene v16-57 with hpunch
        b "Ahh...what..."
        "Abdul suddenly grabbed Banu from behind and put his erect cock between her legs rubbing her pussy from behind."
        ab "Do you want to find ou how an uncircumcised dick feels in your twat?"
        b "Abdul, we need to stop this. What if Kamil comes in?"
        scene v16-58
        ab "Banu, my dear, there's no need to worry. Kamil is far too intoxicated to even notice what's going on. We can have this moment without any interruptions."
        b "I can't take that risk, Abdul. We shouldn't be doing this."
        b "Please, let's put an end to this before it goes any further."
        scene v16-59
        b "Abdul, I've had enough of this. I want you to leave right now. You have no right to be here, and I won't let you destroy what we have. Leave!"
        ab "Oh, Banu, you're weak and helpless against me. You can't resist the desires you feel deep down inside. Don't pretend like you don't want this."
        b_ "It's grinding so bad against me...I'm gonna cum on my pants..."
        b "Please, stop it."
        b "Ahhh..."
        scene v16-60
        ab "I see that you can't stop your moaning. Do you enjoy it that much?"
        b "You know that it's not true."
        "Banu tries to leave but Abdul's strong hands keep her hips fixed and prevent her from moving."
        ab "You may put on a brave face, but I see the fear in your eyes. You can't escape me, no matter how hard you try."
        ab "Just pull your pants down. I'm ready to give you the best moments in your life."
        b "I can't do that..."
        b_ "He's so strong in spite of being fat...much stronger than I imagined..."
        ab "Banu, you're fighting a losing battle. The sooner you accept your place under my control, the easier it will be for both of us. Surrender to me, and I might show you some leniency."
        ab "Come on, it will be quick I promise. I'll just cum inside your pussy right here and it's done."
        menu:
            "Push him away":
                $ banupushabdulaway = True
                $ renpy.block_rollback()
                stop music
                scene v16-61 with hpunch
                b "Get away from me, Prick! I demand that you leave this instant. I will not tolerate your presence any longer."
                b "I am done playing your games. Your manipulation and disrespect end here. Leave this house now, and never come back."
                ab "You think you can just order me around, Banu? You're making a big mistake."
                "Abdul's face contorts with a mixture of anger and disbelief. Banu's determination and strength catch him off guard, as he realizes that she won't back down easily. "
                "Knowing he has lost the battle, Abdul reluctantly turns and walks towards the table..."
            "{color=#FF0000}Pull your pants down{/color}":


                $ banupushabdulaway = False
                $ renpy.block_rollback()
                stop music

                jump abdul_fucksbanu_nexttokamil


                scene v16-62
                b "Alright, just finish it quick. Kamil can come any minute."
                ab "Finally...I knew you couldn't take it any longer, Banu. I always knew you had a dark side."
                b "Just stop talking and do what you want to do."
                scene v16-63
                ab "So if you ask me to put it in, I'll gladly do that."
                b "Just fuck me, what are you waiting for?"
                ab "I've been waiting for this moment for so long."
                ab "I knew I'd fuck you from the moment I saw you."
                ab "I could almost see your pussy from the pants."
                b_ "Shit..he's teasing my pussy so bad."
                ab "You did a good job marrying to that stupid Kamil. He wouldn't suspect if you grow my child in your belly."
                b "Don't talk about him..."
                ab "What? you feel sorry for him while leaning over and waiting for me to fuck you? "
                b "Ahhh.."
                b "Just fuck me you worthless piece of shit."
                ab "If you're so desperate like this..."
                scene v16-64 with hpunch
                b "Ahhhh.."
                b_ "Shit, he just put it in..."
                ab "Damn, you're flooding down there...Your're so excited about this, aren't you?"
                ab "It just slided in as put it there."
                b_ "He's thing is so meaty...it rubs my insides so good..."
                ab "Are you ready for more?"
                b "..."
                scene v16-65 with hpunch
                b "Ohhhh ...shit..slow down you animal."
                ab "It's time to go all the way with you."
                ab "Did you think I'd be easy on you?"
                scene v16-66
                k "Banu, what was that? Did you break something?"
                b "Shit!"
                ab "Not now..."
                scene v16-67
                k "Banu, are you there?"
                b "Yeah...I just..."
                scene v16-68
                k "Hey, what's happening here? What are you two up to?"
                b "Oh, Kamil! We're just... uh, talking about real estate stuff."
                ab "Yeah, Banu has been enlightening me about the intricacies of the market. Turns out, she's a real estate prodigy in disguise!"
                k "You don't say! Banu, my dear, when did you become an expert in real estate? You've been hiding talents from me!"
                b "Well, it's news to me too, Kamil. But you know Abdul, always finding ways to make things interesting."
                ab "It's true, Kamil. I couldn't resist tapping into Banu's hidden real estate genius. She's a natural!"
                k "So you only talk about work, huh? I bet there's more to it than that. You two look awfully cozy. Mind if I join in?"
                b "Kamil, you're not in the right state of mind. It's better if you take a seat and relax. We can catch up later when you're feeling better."
                k "You two have a really friendly conversations in the kitchen. I know what's going on, you sly devils!"
                k "Do you think my wife is beautiful, Abdul? I bet you wish you had alone time with her. She's so pretty man. "
                b "Kamil, please, don't say things you might regret. We're just friends, and nothing inappropriate is happening here."
                k "I...."
                scene v16-69 with vpunch
                b "Oh no, Kamil! He's collapsed! "
                ab "Man, he's always like this."
                scene v16-70 with fade
                b "Kamil! Kamil, can you hear me? Wake up, please!"
                "Kamil remains unconscious, slumped on the ground, unresponsive to Banu's pleas. Worried, Banu turns to Abdul, seeking his assistance."
                scene v16-71
                b "Abdul, we need to get him to the bedroom. He needs a comfortable place to rest. Can you help me carry him?"
                ab "Ugh, Banu, do I have to? Kamil's such a mess when he's drunk. Always causing trouble."
                b "Abdul, this is not the time for negative comments. Please, I can't do it alone. Help me carry him."
                ab "Fine, I'll do it. But don't expect me to enjoy it."
                scene v16-72
                "Banu watches in surprise as Abdul, without asking for her help, lifts Kamil's unconscious body effortlessly and carries him towards the bedroom."
                "Banu's mind races, processing the unexpected display of strength from Abdul. She couldn't help but admire his physical prowess, even in this challenging situation."
                scene v16-73 with fade
                b "I had no idea you were so strong, Abdul. It's impressive."
                ab "Well, there's a lot you don't know about me, Banu. I have some hidden talents, you know."
                "Banu's gaze lingers on Abdul's determined expression as he continues to carry Kamil with ease. She finds herself contemplating the complexities of their relationship, realizing there may be more to Abdul than meets the eye."
                scene v16-74
                "Abdul just roughly threw Kamil onto the bed. As they both observe Kamil sleeping, a sense of unease settles over Banu."
                b "Abdul, thank you for helping with Kamil. He seems to be sleeping now."
                ab "Yeah, well, he's had one too many, hasn't he? Let him rest it off."
                "Banu can't help but feel a growing discomfort in the room. The absence of others and the presence of Abdul alone with her begins to weigh on her."
                scene v16-75
                b "Abdul, I think you should leave now. It's not right for us to be alone in here."
                ab "Relax, Banu. We can stay here for a little while longer. Besides, we've got nothing to hide, right?"
                "Banu's unease intensifies, her instincts warning her of potential dangers that lie within this isolated moment."
                ab "Are you afraid of being alone with me, Banu? Don't tell me you've forgotten how good we used to be together."
                b "Please, just leave and forget about everything."
                ab "Let's enjoy this moment. He's sleeping like a dead. Your moanings won't wake him up for sure."
                scene v16-76
                b "What the fuck are you talking about? I demand you to leave my house immediately!"
                ab "I was inside of you a few minutes ago. Did you forget that?"
                scene v16-77
                ab "And now we're alone here. There's nobody at home except three of us. Do you think I will back up now?"
                b "Abdul, get out....If you come closer, I'll shout."
                ab "You won't shout. I know you also want to do this."
                scene v16-78
                b "Shit, just get off me, Asshole."
                b "How dare you?"
                b "Let go off me!"
                scene v16-79
                b "Ahhhh...stop that please..."
                ab "Mmmmmmm, you're so delicious, Banu."
                ab "I'll enjoy your body tonight no matter what."
                b "Please..."
                scene v16-80
                b "Ahhhh....not here..."
                b "We can't do it here. Kamil is sleeping here..."
                ab "Shut up, bitch."
                b "Hey what are you doing...Put your clothes on. Are you mad?"
                b "Hey, let go off me."
                ab "Take that fucking jeans off. That's it. Take them off fast or I'll just rip them off."
                b "Be gentle you animal..."
                ab "The underwear too."
                b "Wait, not like that..."
                ab "Yeah, this is what I wanted. A fresh married pussy."
                scene v16-81
                b "Wait..where are you taking me?"
                b "Please, not here.."
                ab "Don't worry. We'll try not to wake him up."
                scene v16-82 with vpunch
                b "Ohhhh shit, your cock is so fat."
                ab "And your pussy is tight."
                ab "I'll stretch your hole good enough."
                b "You fuck me so good, keep going...don't stop.."
                scene v16-83
                b "Ahhhhhhh shit...I'm going to cum...."
                b "I'm going to cum over your fat dick....Ahhhhh..."
                ab "Take it, whore. You need a good fucking that Kamil's small dick can't give it to you."
                ab "You need a real man like me."
                ab "You're desperate for this."
                scene v16-84
                b "Ohhhh...You go all the way to my womb..."
                b "Please, slow down...I can't take it....You'll destroy my internal organs..."
                ab "Come on, come here..."
                scene v16-85
                ab "Look at my eyes, bitch.."
                ab "Now tell me, who does it better Kamil or me?"
                b "You're so evil man...ahhh..."
                ab "Don't make me repeat myself, bitch...answer me!"
                scene v16-86
                b "Shit...stop it...you're going to kill me..."
                b "Damn...I can't take it..."
                scene v16-85
                b "You do it better, animal. You fuck me better than Kamil..."
                ab "That's a good girl."
                scene v16-87
                ab "I want you to look at his face while I fuck your twat."
                b "Fuck..I don't care...just put it inside of me...I want you cock inside of me..."
                scene v16-88
                b "Asshole...stop teasing my pussy...put it in."
                ab "Your religious pussy is aching for my uncircumcised dick..."
                ab "Doesn't it bother you getting fucked by a non religious dick."
                b "I don't care now..I just want that fucking dick...Please, give it to me."
                ab "You're just a fucking slut, you know that?"
                scene v16-89
                b "Ay mama...please, fuck me harder...Punish my hole...Ahhh"
                ab "Take it, slut..."
                show abdulfucksbanunexttokamilanimation
                b "Shit...it feels so good..."
                ab "Do you like getting fucked by your husband's friend's fat dick?"
                b_ "Shit...he's an asshole but...he makes me feel so good..."
                b_ "He make slow and halfway thursts but it's meltig me..."

                show abdulfucksbanunexttokamilanimationfast
                b_ "He's fat but so strong...He knows what I need and how to treat me..."
                b "Ohhh...Abdul, do it faster...I'm gonna cum again....Shit..."
                b "Faster, please....Ahhhhhhh..."
                scene v16-90
                b "Ay mama...what are you doing to me, old bastart."
                ab "I'm not done yet...Soon Kamil will hear your moanings in his dream."
                scene v16-91
                b "Ay mama....Abdul, I beg you to stop this...I'm gonna pee on the bed..."
                ab "Spread your legs. Don't squeeze my hand."
                scene v16-92
                ab "Don't you hear me?"
                ab "I said spread your legs..."
                b "No...I'm not going to do that."
                scene v16-93
                ab "Now I will fuck the shit out of you slut and you'll understand your place."
                b "Put it in slow, please. It hurts like a hell when you put it suddenly."
                scene v16-94
                b "Ohhhh..it's so fat..."
                ab "Look at his face while I enter you. "
                ab "He's sleeping like a baby leaving you alone with me."
                ab "Will you forgive him for that?"
                scene v16-95
                b "I'm sorry Kamil for being a bad wife...but he's right...this is your fault...ahhh"
                b "Slowly, asshole..."
                ab "What did you call me?"
                scene v16-96
                b "Oh my god....AHHHHHHH....please, please, slowly...."
                ab "Take it, bitch..."
                ab "I'm going to cum deep inside your pussy."
                scene v16-97
                b "AHHHHHHH.....I'm done, uhhhhhh...shit."
                ab "Take it slut..."
                scene v16-97 with hpunch
                ab "Ahhhhh."
                b "Ohhh...."
                scene v16-98 with fade
                ab "Phew...that was something."
                ab "You have a really high sex drive, bitch."
                scene v16-99 with fade
                ab "I have to admit that I really enjoyed Kamil's money and now his wife. "
                ab "I get really good benefits from him, don't you think?"
                b "You're so evil person, you know that."
                ab "I know that."
                ab "Don't forget to wash your cunt and take some pills because I just came into your womb."
                scene v16-100
                b "Asshole..."
                b "Who said you can cum inside?"
                ab "If you didn't like that I will cum on your face next time...but I'm sure you enjoyed it."
                b "Do you think there will be next time? Dream on you bastard."
                ab "Goodbye for now and say my thanks to Kamil for the night when he wakes up."
                ab "I will visit him often."
    else:










        scene v16-46

        b "Kamil, I can't keep this hidden any longer. Abdul, I know what you did. You stole the money from Kamil."

        k "Is this true, Abdul? Tell me it's not true."

        ab "Kamil, you know Banu has always had her doubts about me. She's just trying to ruin our friendship."

        b "No, Kamil. I have evidence, undeniable proof of Abdul's actions. I spoke with our friend who witnessed him taking the money."

        k "Abdul, how could you betray me like this? I trusted you, and you took advantage of that trust."

        ab "Kamil, please, you have to believe me."

        b "No more lies, Abdul! You've taken advantage of Kamil's trust for your own gain."

        k "Abdul, I can't believe anything you say anymore. You've shown your true colors. Leave. I want you out of my life."

        scene v16-48
        stop music

        ab "Kamil, please, give me a chance to explain. It's not what you think."

        k "No, Abdul. There's nothing left to say. I trusted you, and you broke that trust. I don't want to see or hear from you again."

        "With a heavy heart, Kamil stands firm in his decision, unwilling to entertain further excuses or justifications."

label abdul_fucksbanu_nexttokamil_continue:

    scene black with Dissolve(3)
    ""
    centered "{size=+120}Bedroom conversation{/size}" with Fade(0.5, 0.5, 5)
    scene v16-101 with pixellate
    play music "audio/chill.mp3"
    "Banu walked into the bedroom wearing her new sportswear, which accentuated her full figure."
    "She had just returned from shopping and felt energetic, hoping to bring some cheer to her husband Kamil, who seemed lost in thought while sitting on the sofa."
    "Banu leaned against the bedroom wall, observing Kamil sitting on the sofa from a slight distance."
    "With a mischievous grin on her face, she decided to initiate a playful exchange."

    b "Hey there, Mr. Sofa King. Enjoying the throne?"
    k "..."
    k "Well, someone's feeling extra punny today. But I must say, it's a pretty comfortable throne."
    b "Comfortable, huh? I thought I'd spice things up a bit. Maybe I should get you a crown and scepter to complete the look."
    k "Look, Banu, we have to discuss something."
    b "..."
    scene v16-102 with fade
    stop music
    "Banu noticed a shift in Kamil's demeanor, sensing that his playful mood had turned into something more serious."
    "She walked closer to him, standing near the sofa..."
    b "Hey, what's wrong, Kamil? You seem a bit off. Is everything okay?"
    k "It's just... I've been feeling uneasy lately. When you go to the gym, I can't help but notice that some men stare at you. It makes me uncomfortable, Banu."
    b "Kamil, I understand how you feel. But please know that my intention for going to the gym is solely to take care of my health and well-being. "
    b "I don't have any control over how others may behave or look at me."
    k "I know, Banu. It's just difficult for me to see others admiring you when you're mine. It triggers my insecurities, and I don't want to feel this way."
    scene v16-103
    b "Well, Kamil, maybe I should start wearing a disguise to the gym. A fake mustache and wig, so no one will recognize me! What do you think?"
    k "Banu, this is not a joking matter! It's not about disguises or making light of my feelings. I'm trying to express my genuine discomfort here."
    scene v16-104
    b "Kamil, I'm so sorry. I didn't mean to invalidate your feelings or make light of the situation. "
    b "I understand this is something that genuinely bothers you, and I should have approached it with more sensitivity."
    scene v16-105
    k "You don't understand it yet. I want you to stop going to that god damn place. If you want to stay in shape you can train at home. "
    k "Look at your clothes...Don't you see that you draw so much attention? It's not appropriate for you to dress like that. It just reveals your body."
    b "Kamil, I understand that you're feeling uncomfortable, but it's unfair to place the blame on my clothing. I dress in a way that makes me comfortable and confident, and it doesn't give anyone the right to disrespect me."
    b "It's better to address the behavior of others rather than dictate what I wear."
    scene v16-106
    k "I'm not blaming you, Banu, but can't you see that the way you dress draws attention? It makes me feel embarrassed, like I can't protect you or keep others from looking."
    b "Kamil, I understand your concerns, but I can't change who I am or compromise my personal freedom because of others' actions."
    scene v16-107
    b "We need to focus on building trust and addressing the behavior of those who disrespect boundaries, rather than restricting my choices."
    scene v16-106
    k "I just can't handle the constant scrutiny and attention you receive. It eats away at me, and I don't know how to cope with it."
    k "I don't trust the men out there. They see your shape and body and they want to sleep with you. Doesn't it bother you?"
    scene v16-107
    "Banu felt a mix of anger, frustration, and sadness welling up inside her as Kamil made the decision to prohibit her from going to the gym."
    "She understood his concerns, but she also valued her independence and the importance of maintaining her physical and mental well-being."
    b "As you say I don't have a choice here, do I?"
    k "..."
    b "Now I have to sacrifice my well being for your insecurities...fine."
    scene v16-108
    b "If this is what you want....I'll take these off now."
    k "I totally understand you being angry at me, Banu. "
    scene v16-109
    b "It's okay. If you want me to stop going to the gym. I'll do that."
    b "But you'll have to explain me the logic here."
    b "I'm tired of you blaming me for all your insecurities lately."
    scene v16-110
    "Banu's fury turned into a mix of frustration and empathy as she stood in front of Kamil, trying to understand the root of his concerns."
    b "So what? Are you satisfied now?"
    "She looked into his eyes and spoke with a determined yet compassionate tone."
    b "Kamil, I need you to be honest with me. What exactly about my behavior makes you feel so insecure? Is it the attention I receive from other men? Or is it the fear of losing me?"
    "Kamil shifted uncomfortably, feeling the weight of Banu's gaze upon him. He took a deep breath and mustered the courage to express his innermost fears."
    k "It's a combination of both, Banu. Seeing other men look at you, appreciating your beauty, it triggers my insecurities. I'm afraid that one day, I won't be enough for you."
    scene v16-111
    b "Kamil, I chose you because you are the one I love and want to build a life with. The attention I receive from others is superficial and fleeting."
    b "It's your love, understanding, and the connection we share that truly matters to me."
    k "But how can I overcome these insecurities, Banu? How can I trust that you won't be swayed by the attention of other men?"
    scene v16-112 with fade
    "As Banu sensed Kamil's vulnerability, she moved closer to him on the bed, gently placing her hand on his shoulder."
    "Her touch conveyed both comfort and encouragement, as she wanted to be a source of support during this challenging moment."
    b "Kamil, I understand that it takes courage to open up and share your insecurities with me. I want you to know that I'm here for you, and we'll navigate this together."
    "Kamil looked at Banu, appreciating her presence and the warmth of her touch."
    "But there was one thing that was still bothering him that it was hard to tell Banu."
    "Kamil gathered his courage, knowing that there was a question he needed to ask Banu—a question that had been weighing on his mind."
    scene v16-113
    "He took a deep breath, trying to find the right words to express his curiosity while respecting her emotions."
    k "Banu, there's something I've been wanting to ask, but please know that I ask with the utmost respect and understanding."
    k "Have you been with other men before me, besides your late husband?"
    menu:
        "Banu pretended to be offended":
            $ banuconfessapastsecrettokamil = False
            $ renpy.block_rollback()
            scene v16-114
            b "Kamil! Are you seriously asking me that?"
            b "How dare you question my fidelity and loyalty to you!"
            k "Banu, I just..."
            b "I thought you trusted me! How could you think that I could do something like that."
            b "You're my man and you should be confident but not ask such a disgusting question."
            scene v16-115
            "Kamil's face immediately reflected regret and concern, realizing that his question had unintentionally hurt Banu. He hurriedly tried to rectify the situation, his voice filled with genuine remorse."
            k "Banu, I'm so sorry. I didn't mean to doubt you. Please forgive me. I trust you completely, and I know I shouldn't have let my insecurity get the best of me."
            b "You should be mindful of how your question may impact me and I want you to close this topic forever."
            k "Banu, I'm truly sorry for my thoughtless question. I didn't realize how it could hurt you or undermine our trust."
            k "I promise to be more mindful of my words and actions. Please forgive me."
            b "..."
        "Banu confessed a past secret ":



            $ banuconfessapastsecrettokamil = True
            $ renpy.block_rollback()
            scene v16-116 with fade
            play music "audio/intro.mp3"
            "Banu felt a mix of surprise and curiosity as Kamil asked her about her past experiences."
            "She looked into Kamil's eyes, recognizing his genuine curiosity and desire to know more about her past."
            "While hesitant at first, she understood the importance of honesty in their relationship. Taking a deep breath, she decided to open up about her relationship with a boy from her high school days."
            scene v16-117
            b "I can guess why this is important to you."
            b "Well, if you want to know..."
            b "Kamil, I want to be open with you about my past. In high school, I had a relationship with a boy named Ali."
            b "We were young and experiencing the complexities of first love."
            b "We shared laughter, dreams, and supported each other during those formative years."
            b "However, as we grew older, we realized that our paths were diverging, and we eventually went our separate ways."
            k "Tell me everything, Banu."
            k "I want to know everything about it."
            b "Kamil, I must be honest with you about Ali. While we had a close relationship in high school, he had a reputation as a playboy. "
            b "He was charismatic and had a way with words that captured the attention of many girls. It was something I found intriguing and admired at the time."
            scene v16-118
            k "I appreciate your honesty, Banu. It's interesting to hear about Ali's reputation, but I'm curious why you were drawn to him despite knowing about this behavior."
            scene v16-119
            "Banu sighed, understanding the need for further clarification."
            b "At that time, Kamil, I was young and naive. I was captivated by Ali's charm and his ability to make others feel special."
            b "I admired his confidence and wanted to be a part of his world. Looking back, I realize it was more about the idea of him rather than a true understanding of who he was."
            k "So you've been with him?"
            b "If you're asking if I had sex with him....yes."
            b "I had sex with him several times."
            k "Oh.."
            b "He just made me believe that we could have a future together."
            b "At the end, I discovered his true self but it was late and he had fucked me many times already if this is what you want to know. "
            menu:
                "Banu share the details":
                    $ banusharedetailswithkamil = True
                    $ renpy.block_rollback()
                    scene v16-117
                    b "Kamil, I have to be honest with you. Ali had an amazing physique. He was athletic and took great care of his body. "
                    b "His dedication to fitness was evident, and I couldn't help but admire his physical strength and appearance during our time together in high school."
                    b "I'm sorry to admit this but he was amazing in bed. We had a great body compatibility."
                    b "I couldn't stop cumming as soon as he put his thing inside of me. His thing was one of the biggest I've ever seen."
                    k "I think that's enough, Banu."
                    b "I'm sorry, I just wanted to be honest."
                    stop music
                    k "I appreciate your honesty, Banu, but hearing about your admiration for his physicality does make me feel a bit insecure. I want to be able to provide you with the same level of attraction and fulfillment."
                    b "Kamil, I understand how my words might have affected you, and I'm truly sorry for any insecurity they may have caused."
                    b "It's important to remember that physical attraction is just one aspect of a relationship. While Ali had a striking physique, it's the deep emotional connection, understanding, and love we share that truly matter to me."
                "Banu skip the details":


                    $ banusharedetailswithkamil = False
                    $ renpy.block_rollback()
                    stop music
                    b "Kamil, I understand that you may have questions, but the specific details of my past relationship may not be necessary for us to dwell on."







            scene v16-118
            k "But what about your husband? How he reacted when he knew that you were not a virgin?"
            scene v16-119
            b "He didn't know that. I had a hymen repair surgery. I knew this was a stupid thing but I wasn't going to risk my relationship with Alper. I loved him so much."
            k "So you cheated on Alper?"
            b "Only for the sake of our relationship. I didn't want this stupid virginity to cause problems between us."

            b "Kamil, I feel that this conversation has become quite awkward, and I don't want it to affect our connection."
            b "Let's take a moment to acknowledge that it's uncomfortable and agree to move past it. Our love and the present moment are what truly matter."
            k "You're right, Banu. I appreciate your honesty in acknowledging the discomfort. Let's leave this topic behind and focus on the love and connection we share."

    scene black with Dissolve(3)
    ""
    centered "{size=+120}Murat{/size}" with Fade(0.5, 0.5, 5)
    scene v16-120 with blinds
    play music "audio/kometaback.mp3"
    "Banu, clad in her pink sportswear, took a solitary stroll through the sunlit city streets. The warm rays of sunlight cascaded down, casting a golden hue on her surroundings."
    "Despite the pleasant weather, her mind was clouded with thoughts, burdened by stress and a sense of loneliness."
    "As she walked along the bustling sidewalks, the sounds of city life enveloped her."
    "Conversations melded into an indistinguishable buzz, while the distant honking of cars echoed in the distance. The vibrant cityscape seemed to carry on with its rhythm, oblivious to Banu's inner turmoil."
    scene v16-121 with wipeleft
    "At the same time, about half a mile away from Banu, Murat was strolling through the city streets with his palpable vibrant energy."
    "A smile adorned his face, radiating positivity to those around him."
    "The sun's warm rays seemed to reflect his cheerful disposition, illuminating the path he traversed."
    scene v16-122 with wiperight
    "While Banu's face seemed to bear the weight of her worries..."
    scene v16-123 with wipeleft
    "Murat's face reflected an inner lightness, an unwavering positivity that he carried with him."
    scene v16-122 with wiperight
    "Banu's sad face, subdued and introspective, seemed to blend into the background of the bustling city, almost unnoticed amidst the vibrant colors and lively energy."
    scene v16-123 with wipeleft
    "Meanwhile, Murat's vibrant face drew attention, attracting the gazes of passersby, who couldn't help but be captivated by his infectious enthusiasm."
    scene v16-124 with fade
    "As Banu continued her lonely walk through the city, lost in her thoughts and weighed down by her emotions, her eyes suddenly met with a familiar face in the distance."
    "It was Murat, walking towards her with his characteristic smile and a twinkle in his eyes."
    "Banu's sad face, momentarily interrupted by the sight of Murat, softened with a flicker of recognition."
    "The corners of her mouth lifted slightly, reflecting a glimmer of hope amidst her troubled state. Her eyes, once clouded with sadness, now held a trace of warmth as they locked onto Murat's."
    scene v16-125
    "Murat, his energetic stride never faltering, approached Banu with an enthusiastic greeting."
    mur "Hey, Banu! Fancy running into you here. How's it going?"
    "Banu, surprised by the unexpected encounter, couldn't help but feel a sense of comfort in Murat's presence."
    b "Oh, Murat. It's been a tough day, but seeing you brings a little light to it. How about you? How's life treating you?"
    mur "I'm sorry to hear that, Banu. Life's been treating me well, but knowing you're having a rough time makes me want to offer support."
    mur "If you ever need someone to talk to or simply want a listening ear, count on me."
    scene v16-126
    b "You know, Murat, I have to admit something. You're really good with women."
    mur "Oh, really? Well, thank you, Banu. "
    b "You have this way of making people feel comfortable and appreciated. I've seen how effortlessly you connect with others, especially women. It's a gift."
    mur "I appreciate your kind words, Banu. "
    mur "But let's not forget, you have your own special qualities that draw people towards you as well."
    b "So, Murat, am I special to you? Or am I just another face in the crowd?"
    scene v16-127
    mur "Banu, you know you're more than just another face in the crowd. "
    b "Oh, really? And what makes me so special, Mr. Smooth Talker?"
    mur "Well, for starters, you have this unique ability to light up a room with your presence. "
    mur "Your warmth and genuine nature make people feel comfortable and valued. And your sense of humor always brings a smile to my face."
    mur "Hey, Banu, I was thinking it would be fun to grab a coffee and go bowling together. What do you say?"
    stop music
    menu:
        "Banu rejects":
            $ renpy.block_rollback()
            $ banuagreebowlingmurat = False
            scene v16-126
            b "Hmm, that does sound like fun, Murat. But I have to be honest with you. I can't help but feel a bit skeptical about your intentions."
            mur "Why that? I simply thought it would be enjoyable to spend some time together."
            b "Come on, I know your intention is not just to play bowling. I have noticed the way you look at me, and it makes me feel uncomfortable. Plus, I'm married, and I want to honor my commitment to my husband."
            scene v16-127
            mur "You're the way smarter than I expected. Just keep in mind that if you need support or bored, you have my number and I'm always here for you."
            b "Thank you again, Murat. I'll keep it in mind."
        "Banu agrees":

            $ renpy.block_rollback()
            $ banuagreebowlingmurat = True
            scene v16-126
            play music "audio/chill.mp3"
            b "I just want to let you know that I don't trust you because you're a man."
            b "But honestly, I'm quite bored, so I guess I'll give it a shot."
            scene v16-127
            mur "I understand if you're hesitant, but I promise to respect your choices."
            scene v16-126
            b "Alright, Murat. I'll take your word for it, but I want to be clear that this is strictly as friends. If at any point I feel uncomfortable or sense any inappropriate behavior, I'll have to end our outing."
            mur "Let's just have a good time and enjoy each other's company."
            b "..."
            scene v16-133 with pixellate
            "Banu and Murat found themselves seated at a cozy coffee table in the vibrant atmosphere of the bowling club. "
            "The sound of rolling balls and jubilant cheers filled the air, adding to the excitement that surrounded them."
            "As they settled in, the conversation flowed effortlessly, and Banu couldn't help but find herself genuinely enjoying Murat's company."
            mur "Hey, Banu, did you know that I have a black belt in bowling? They call me the Strike Ninja!"
            b "Strike Ninja? That's a new one! So, should I be worried about any karate moves with that bowling ball of yours?"
            mur "Watch out! I might just unleash my secret bowling technique - the unstoppable Flying Strike Kick!"
            b "Oh, please! I can't even imagine what that would look like. But I must admit, you have a way of turning bowling into a martial art!"
            mur "Well, you know what they say, Banu - the key to a perfect strike is a strong mind, a steady hand, and a killer sense of humor!"
            scene v16-134
            b "Well, you definitely have the humor part covered, Murat. You always manage to bring a smile to my face, even in the midst of a tense situation!"
            mur "That's the goal, Banu. Laughter is the secret ingredient that makes everything better. Besides, what's a game of bowling without a few good jokes and shared laughter?"
            b "You're absolutely right, Murat. Life should be filled with moments of joy and lightness, even in the simplest things like bowling. Thanks for reminding me to embrace the fun and laughter."
            scene v16-133
            mur "Come on, Banu! Let's start bowling already. It's going to be so much fun!"
            scene v16-134
            b "I have to be honest, Murat. I'm not really good at bowling. I don't want to embarrass myself."
            mur "Nonsense, Banu! Bowling is all about having a good time. Trust me, you'll get the hang of it in no time. Plus, I'll be right there to guide you through it."
            b "I appreciate your confidence in me, Murat. But I'm not sure if I can do it."
            mur "Come on, Banu..."
            scene v16-135 with fade
            b "Heyyy, okay I'm coming."
            mur "We'll figure it out together. Don't worry about being perfect. Let's just have fun and enjoy the experience."
            b "Okay, okay! I'm going, but you better be ready to witness my terrible bowling skills."
            scene v16-136
            mur "I can't wait to see what you've got, Banu! I have a feeling you'll surprise yourself."
            b "Alright, Murat, here I go. Any last-minute tips?"
            mur "You've got this, Banu! Just take a deep breath, aim for the middle pin, and give it a nice, smooth roll. Remember, it's all about finding your rhythm."
            b "Okay, I'll give it my best shot!"
            scene v16-137
            "Banu stepped forward to the edge of the lane, her focus intensifying. With a determined expression, she swung her arm back and gracefully released the ball. It glided down the lane, steadily rolling towards the pins."
            mur "Looking good, Banu! Keep going!"
            "The ball approached the pins, and with a satisfying thud, it knocked down several of them, leaving a scattered arrangement. Banu's eyes widened, and a mixture of surprise and delight spread across her face."
            scene v16-138 with fade
            b "I did it! I actually hit some pins!"
            mur "That was fantastic, Banu! You're a natural. See? I told you that you could do it!"
            b "Alright, Murat, it's your turn now. Show me what you've got! I bet you can't knock down all the pins in one shot."
            mur "Oh, Banu, you're underestimating my bowling skills. I'm so sure I'll get a strike that I'm willing to bet on it!"
            b "Really? You're that confident, huh? Alright, let's see what you've got. But don't be surprised when you don't get all the pins."
            scene v16-139
            "Murat positioned himself at the edge of the lane, holding the bowling ball in his hands. He took a deep breath, focusing his gaze on the pins ahead."
            mur "Watch closely, Banu. This one's for the skeptics!"
            "With a swift motion, Murat released the ball, sending it gliding down the lane with precision."
            "As if guided by an invisible force, the ball curved just at the right moment, striking the pins with a satisfying crash."
            scene v16-140
            b "No way! You actually got them all! I can't believe it!"
            mur "Told you, Banu! Never underestimate the power of a little confidence. Looks like I owe you a victory dance!"
            b "Fine, fine. You win this time, Mr. Bowling Champion. But let's see if you can keep up that perfect score throughout the game!"
            "Their playful banter continued as they completed their game, exchanging laughter and friendly competition. Murat's strike had left Banu in awe, but it only fueled her determination to improve her own skills."
            scene v16-141 with fade
            "As Banu and Murat continued playing their game of bowling, the atmosphere filled with excitement and laughter."
            "The joy they found in each other's company became evident as their friendship deepened through shared moments of triumph and lighthearted banter."
            "With each successful shot and strike, their connection grew stronger. Banu couldn't help but feel a sense of comfort and ease whenever she was around Murat, and the same sentiment seemed to hold true for him."
            "In a moment of exhilaration, Murat couldn't contain his excitement any longer."
            "As Banu celebrated another well-earned strike, he playfully and instinctively wrapped his arms around her from behind, pulling her into a warm, spontaneous embrace."
            b "Well, someone's feeling quite victorious, aren't they? I didn't know hugging was part of the bowling game!"
            mur "I couldn't help it, Banu! You're just too amazing at this. The thrill got the best of me!"
            b "Well, Mr. Hugger, be prepared for some tough competition. I won't let you win so easily!"
            mur "Oh, it's on, Banu! You better bring your A-game because I won't go easy on you!"
            "..."
            scene v16-128 with fade
            "After an exhilarating game of bowling, Murat couldn't contain his infectious energy and mischievous spirit. Holding Banu's hand tightly, he led her on a playful and joyous run through the city streets."
            "Banu, her face glowing with laughter and excitement, gladly followed along, fully immersed in the moment."
            "As they dashed through the bustling city, their laughter echoed in the air, catching the attention of passersby who couldn't help but smile at their infectious enthusiasm."
            "Banu's tired legs were evidence of their adventure, but her spirit remained uplifted and energized."
            scene v16-129
            mur "Come on, Banu! Just a little bit farther. I have a surprise for you!"
            b "You really know how to keep the fun going, don't you? I don't even know where we're headed, but I'm loving every moment!"
            "Their laughter intertwined with the rhythm of their footsteps as they navigated the winding streets, their destination looming ahead. Banu's heart raced with anticipation, wondering what surprise awaited her at the end of their spirited journey."
            scene v16-130 with hpunch
            "In a spontaneous burst of joy, Murat playfully grabbed hold of both of Banu's hands. With a mischievous smile, he began to twirl her around, gently spinning her in a circle."
            "Banu's laughter filled the air as her head spun with a delightful mixture of dizziness and excitement."
            b "Murat, what are you doing? You're going to make me dizzy!"
            mur "Just a little fun, Banu! Let's keep the laughter going and see if we can make the world spin!"
            "As Murat continued to twirl Banu, the world around them blurred, their laughter intermingling with the sounds of the bustling city. In that moment, time seemed to stand still as they embraced the pure joy of the present."
            b "Okay, Murat, you win! My head is spinning, but it's the best kind of dizzy. You really know how to make me smile!"
            scene v16-131
            "Banu, I have an idea. Why don't you come up to my apartment? I want you to be my guest, just for a little while. We can continue our fun and laughter in a more comfortable setting."
            "Oh... um, Murat, I appreciate the invitation, but I'm not sure. We've had a great time so far, but I'm not sure if going to your apartment is the right thing to do."
            mur "Banu, please reconsider. I genuinely enjoy your company."
            stop music
            menu:
                "Reject him":
                    $ renpy.block_rollback()
                    $ banugotomuratsapartmentafterfun = False
                    scene v16-132
                    b "Murat, I appreciate your persistence, but I know what accepting this invitation would imply. As a married woman, it wouldn't be appropriate for me to go to your apartment alone."
                    mur "Banu, let's forget about everything else for a moment. Come to my apartment and let's just have fun together. No worries, no obligations, just a chance to enjoy each other's company."
                    b "Murat, I can't do that. I appreciate your invitation, but I am a married woman, and it wouldn't be right for me to disregard my commitment to my husband."
                    b "I value our friendship, but I must prioritize my marriage and the trust that exists within it."
                "Go with him":



                    $ renpy.block_rollback()
                    $ banugotomuratsapartmentafterfun = True

                    jump muratfucksbanuafterfunsexscenestaywithkamil

                    scene v16-132
                    b "Murat, I can't believe I'm agreeing to this, but okay. Just 5 minutes, and then I need to leave. No longer than that, okay?"
                    mur "Deal! I promise you won't regret it. Let's go!"
                    scene black with dissolve
                    "..."
                    scene v16-142 with dissolve
                    b "Wait...you're such a liar, Murat."
                    b "....mmmmp.."
                    mur "Your lips taste so good. I can kiss you all day."
                    b "You're going to choke me, maniac."
                    b "Is it your fisrt time kissing?"
                    mur "You're driving me crazy, Banu. I can't control myself with you."
                    scene v16-143 with fade
                    b "Mmmp...oh god...stop touching me there...ohh."
                    mur "You like this, don't you?"
                    b "We didn't agree on taking the clothes off, did we?"
                    scene v16-144 with fade
                    mur "Shhhh...just enjoy the moment. "
                    b "Your dick....it's touching me..."
                    mur "Damn Banu, you're kissing me so passionately. You must be craving this all the time you've been with me."
                    scene v16-145
                    b "Ahhh...you know what I need..."
                    b "Right there...ahhhh.."
                    b "Ummmmm...You got me so wet you tricky boy."
                    scene v16-146
                    "Murat was bending Banu backwards slightly and she was grabbing his neck not to fall off."
                    "Using the opportunity, Murat started rubbing Banu's pussy furiously and talking dirty to her making her crazy."
                    b "Ahhhhh...stop it...please, ahhh."
                    mur "I'll make you feel so good that your husband never done that to you."
                    mur "I'm going to make you feel like a real woman today. You'll scream and beg but I won't stop..."
                    scene v16-147 with fade
                    "After minutes Murat grabbed Banu taking her pants and bra off and sat on the sofa holding her on top of him. "
                    "While invading her mouth, Murat run his hands all over Banu's body, caressing her thighs, belly and breasts. "
                    "At this point, Banu could't help but reached her pussy with her hand stimulating her left out clit."
                    scene v16-148
                    b "Shit, I can't bear it anymore...Murat, please..."
                    mur "Tell me. What you want me to do?"
                    b "Please, make me feel good."
                    mur "You want my cock, don't you?"
                    b "My pussy is so wet now. I'm going to cum from your touches."
                    b "Please, take my pussy. Make me yours!"
                    scene v16-149 with hpunch
                    b "Ahhh...yeah like that.."
                    mur "You're such a lewd slutty wife, aren't you?"
                    b "Yesss, I'm a despicable, bad wife who needs a good punishment."
                    b "Call me whatever you want. I deserve that."
                    mur "You're a bad bitch enjoying my fingers deep inside of your married cunt. "
                    b "Ohhh...I can't take it anymore...I'm going to cummm....."
                    scene v16-150
                    mur "Look how slutty you are. You're cumming from a young man at your children's age fingering your pussy."
                    b "Please, stop it..."
                    b "Damn, you're so good at this. Fuck..."
                    b "I've never let my husband touch me like that."
                    mur "Go on, cum for me. I'm going to tease all of your slutty holes."
                    mur "I'm going to tease the shit out of you. You'll beg me to fuck all of your holes."
                    mur "Have you ever got your asshole fucked?"
                    scene v16-151 with vpunch
                    b "No! Don't touch me there. I warn you!"
                    mur "What? You're rejecting me?"
                    b "Shit, I'm serious, Murat. I've never let a man touch me there."
                    "Banu squeezed her legs so hard to prevent Murat teasing her asshole with his middle finger. "
                    scene v16-152 with fade
                    b "Ahhh..."
                    b "You're crazy...what are you doing?"
                    mur "You see? I'm full of surprises."
                    scene v16-153
                    mur "Mmmm...it's so delicious. Do you like it?"
                    b "Ohhh shit...stop it...it's so dirty..."
                    b "Oh god...you're hitting my spot."
                    b "You're eating it like your favorite breakfast...ufff.."
                    mur "Mmmm..this is my favorite meal of the day."
                    b "Oh my God...if you keep doing that....I won't be able to stop cumming."
                    mur "Don't hold it. Cum all over my mouth. "
                    b "Shit, you're so good with your tongue."
                    mur "Are you ready for the main course?"
                    scene v16-154 with fade
                    "Murat suddenly raised Banu's legs and put his dick on top of her pussy grinding it back and forth."
                    mur "You want this, don't you?"
                    b "Stop teasing me, please..."
                    mur "Shut up!"
                    mur "Tell me how you want it."
                    scene v16-155
                    b "I want it inside of me..."
                    "Murat continued teasing Banu's wet pussy with his fully erect curvy dick making her crazy."
                    mur "I want you to ask it properly."
                    b "Oh god...you're making me crazy..."
                    b "Put that fucking dick inside of me!"
                    mur "Tell me how bad you want it."
                    b "I want it so bad...please, my pussy aches for your big curvy dick."
                    b "Put it inside of my married unsatisfied pussy."
                    b "Fuck the shit out of me..."
                    scene v16-156 with hpunch
                    b "Ahhh..."
                    mur "That's it. I'm not gonna make you suffer any longer."
                    show muratfuckbanuafterfunanimation
                    b "Fuck!...This feels so good..."
                    mur "I know what you want, baby."
                    mur "My dick fits so good inside of your wet pussy."
                    mur "Your pussy is just made for my cock."

                    show muratfuckbanuafterfunanimationangle
                    b "Ohh fuck me...keep fucking me like that."
                    mur "Your husband is weak man probably. Leaving a pussy unsatisfied like this huh?"
                    b "Please, ahhh, stop talking about him..."
                    b "Keep fucking me like that, ahhh.."

                    show muratfuckbanuafterfunanimationfast
                    b "Ohhhh shit..."
                    b "It's hitting me so bad..."
                    mur "Fuck...your pussy squeezes my cock so hard."

                    show muratfuckbanuafterfunanimationanglefast
                    b "Oh my god, keep fucking me like that...ahhh..."
                    b "Your cock reaches my stomach...ohhh shit.."
                    mur "I'm going to destroy belly..."
                    mur "I can't believe you gave a birth from this pussy. It's so tight."
                    b "Fuck....I'm cumming....shit...."
                    scene v16-157 with hpunch
                    b "Shit...that was so intense."
                    mur "Your face tells it all."
                    b "You're the devil."
                    mur "I'm glad you liked that...but it's not over yet."
                    scene v16-158
                    mur "I have an idea. How about we try something new together?"
                    b "Wait..what?"
                    mur "It's something you've never done before, and I think it could be a fun and memorable experience."
                    b "No!...no way..."
                    scene v16-159
                    mur "But why not trying?"
                    b "I'm sorry, but I can't do that. It's just not something I'm comfortable with or ready for."
                    mur "Let's give it a try, just this once. I'm sure you'll love it."
                    scene v16-160
                    b "No I can't do that. I'm not comfortable with this you know."
                    mur "How do you know if you haven't tried it?"
                    b "Please, don't push me. I'm afraid of that."
                    scene v16-161
                    b "Heyyyy...stop it!"
                    mur "I promise you, it won't be painful."
                    mur "I'll make sure you're comfortable and at ease throughout the experience."
                    scene v16-162
                    b "I just said stop it! What are you doing?"
                    b "I can't do this!"
                    mur "Shhhh...your ass will love it."
                    scene v16-163
                    b "Ahhhhhhhh...Ay mama....it hurts...stop it!"
                    mur "Shhhh, I'll lubricate it good that you'll only feel the pleasure."
                    scene v16-164
                    b "Ahhhhhh..."
                    mur "That's it..."
                    b "It hurts so bad, please pull it out! Ahhhhh.."
                    mur "Don't worry. Your ass will get used to it."
                    show sex
                    b "Shit...Ahhhh..."
                    b "It destroyes my ass."
                    mur "You seem to like it."
                    show sexangle
                    b "Ohh yeah, don't stop...keep fucking my dirty asshole..."
                    mur "Your asshole is so tight. It squeezes my dick like hell."
                    mur "But I'll stretch it a bit more."
                    show sexfast
                    b "Ahhhhhh....yesss...pound my ass like that..."
                    b "Shit, I can't hold it. I'm going to pee."

                    show sexanglefast
                    mur "Your asshole belonges to me now. "
                    mur "I'll stretch it whenever I want."

                    scene v16-165 with fade
                    "Murat fucked Banu for hours in the ass hitting deep inside her with his long curvy dick."
                    "Banu's initial pain was replaced by a mixture of pleasure and pain afterwards giving her the best pleasure in her life. "
                    scene v16-166
                    "At this point, she couldn't stop her eyes rolling back and moaning like a whore while accepting full length of Murat's swollen cock from her back door. "
                    b "Ahhhh, it's hitting me right there..."
                    scene v16-167
                    b "Keep fucking me like that. Don't dare to pull it out now."
                    b "Oh my god...I can't hold it any longer...."
                    b "Shit, if you keep fucking..."
                    scene v16-168 with vpunch
                    b "Oohhhhhh...."
                    b "Damn...I'm..."
                    mur "Fuck, look at that."
                    scene v16-169
                    b "Fuck...I'm so sorry...It was just..."
                    mur "It's okay, Banu. You just enjoyed it a bit too much."
                    b "I'm really sorry...it was just an accident."
                    scene v16-170 with hpunch
                    "Murat looked deeply into Banu's eyes, a glimmer of excitement and anticipation in his gaze."
                    b "Murat, I have to go. It's late."
                    mur "For the next few hours, I want us to have an incredible time together."
                    b "But I really can't stay."
                    mur "We're having such a great time together, and I don't want it to end so soon."
                    mur "You belong to me for the next hours."
                    "Banu couldn't say a word as she felt Murat's dick in the enterance of her asshole again."
                    "It was too late to reject Murat again..."


label muratfucksbanuafterfunsexscenestaywithkamil_continue:











    scene black with Dissolve(3)
    ""



    $ banustaysmuratandfriend = False
    $ banuconfesscheating = False




    centered "{size=+120}Rejection...{/size}" with Fade(0.5, 0.5, 5)
    jump banu_reject_kamil_anal_corruptedroute



label banu_reject_kamil_anal_corruptedroute_continue:


    if killturan == False:


        scene black with Dissolve(3)
        ""
        centered "{size=+120}Breaking the rules...{/size}" with Fade(0.5, 0.5, 5)
        scene v17-74 with dissolve
        "In the dimly lit apartment, the air hung heavy with tension as Banu found herself once again in Turan's presence."
        "Banu's arms were tightly folded, a defensive gesture that mirrored the guarded expression on her face."
        "Facing her was Turan, the source of her turmoil and the master of her secret. His demeanor exuded a calculated confidence, his every move a reminder of the leverage he held over her."
        scene v17-75
        b "How much longer do you plan to keep this up? When will this end?"
        t "Well, Banu, you know how this works. It ends when I decide it ends."
        scene v17-76
        b "This is ruining my life. My family, my marriage – everything is at stake. You can't keep controlling me like this."
        t "That's the price of secrets, my dear. You chose to confide in me, and now you're in my debt. A debt you must repay."
        b "You're tearing me apart. My husband suspects something's wrong. I can't keep making excuses, dodging questions. It's becoming unbearable."

        scene v17-77
        t "Consider this: if our secret were to spill, think of the consequences. Your husband, your reputation – everything would crumble."
        t "You know, Banu, there might be a way out. A way to settle our little arrangement. But it won't come without sacrifice."
        t "I will make you submit to me completely. You don't reject me like you used to do. I know you like it too."
        t "I know that your husband can't give it to you."
        t "Soon I'll make you realize that I'm the only man that you'd want to be with forever."
        scene v17-78
        b "You'll never make me completely submit to you."
        t "Oh, Banu, I know you better than you think. There's a part of you that's drawn to this. To me. Admit it, there's a certain excitement in our little secret meetings."
        b "You're mistaken. I would never willingly choose to be with a man like you."
        t "Denying your feelings won't make them disappear. You can't deny that there's a spark between us, a tension that goes beyond just fear."
        b "What you perceive as a spark is nothing more than my determination to end this nightmare. I won't let you manipulate my emotions."
        scene v17-79
        b "Oh, Turan, you really believe you're enough of a man to make me submit to you?"
        t "You underestimate me, Banu. I've already got you wrapped around my finger, whether you want to admit it or not."
        b "Wrapped around your finger? Is that what you call it? Your tactics might work in your little power games, but you'll never truly have me."
        b "You're the one who started this dangerous game when you decided to exploit my vulnerability. But I won't play by your rules. I won't let you define who I am or how I feel."
        jump turan_destroy_banu

label turan_destroy_banu_continue:


    scene black with Dissolve(3)
    ""
    centered "{size=+120}Jogging...{/size}" with Fade(0.5, 0.5, 5)
    scene v17-129 with blinds
    "Banu heads out for a jog in the city center during the sunny afternoon. She's wearing a white sporty outfit and a black hijab."
    "The bustling city streets are filled with people going about their day, and the warmth of the sun adds a pleasant touch to the atmosphere."
    scene v17-130
    "As Banu runs, she passes by shops, cafes, and parks, feeling the energy of the city around her."
    "The contrast between her white sportswear and the black hijab creates a unique and striking visual."
    "With each step, Banu enjoys the sights and sounds of the city while also getting in a good workout."
    if banuscoldpolad == False:

        scene v17-131 with fade
        "As Banu continues her jog, she suddenly spots Polad, a bald and muscular man, on his motorbike. "
        "The sight of him brings back memories of a past affair, one that Banu had with him, cheating on her husband in the back room of the bar."
        "Polad notices Banu as well and stops his motorbike. They exchange glances, and Banu's heart races as they begin to talk."
        scene v17-132
        b "Tell me that you're not following me."
        p "Why should I?"
        b "So how have you been?"
        p "Oh, you know, keeping things exciting. Speaking of which, how about we catch up properly? Jump on the bike, let's hang out like old times."
        scene v17-133
        b "Polad, I've moved on from that part of my life. I can't go back to how things were."
        p "Come on, Banu. You and I had some good times together. Why not relive the thrill?"
        b "That was a mistake, Polad. I regret it deeply, and I've worked hard to mend my marriage and my life."
        p "Sure, you say that now. But don't you miss the excitement, the passion we had?"
        b "What we had was a mistake, Polad. I won't let myself be drawn back into that. "
        p "I just want to show you some beautiful spots in the forest nearby. Jump on the bike."
        b "I'm not sure that's a good idea."
        p "Trust me, Banu. It's just a ride, a chance to catch up and enjoy some nature together."
        scene v17-134 with fade
        "As Samir walks through the forest, his steps are purposeful, driven by his curiosity about the natural surroundings."
        scene v17-135 with fade
        "He's clearly someone who values taking a moment to escape from the daily grind and immerse himself in the serenity of the outdoors."
        scene v17-136 with fade
        "The dappled sunlight filters through the trees, casting playful shadows on his features and giving his skin a warm glow."
        scene v17-137 with hpunch
        "Then, as he continues on his stroll, his gaze suddenly fixates on a scene in the distance. He squints, unable to believe his eyes."
        "There, emerging from a winding path on a motorcycle, is Banu – someone he knows from the company. The sight of her on a man's bike, wind gently ruffling her hijab, is unexpected and puzzling."
        "A mixture of surprise, confusion, and curiosity colors his expression."
        "Samir's heart beats a little faster as he watches her draw nearer. He's unsure whether to approach her or stay where he is, his mind racing to process what he's witnessing."
        scene v17-138
        b "Polad, I can't believe I agreed to this. What exactly are we doing here?"
        p "Banu. I promise you're going to love this."
        scene v17-139
        b "It is peaceful out here. But why the forest? And why did you insist on bringing me here on your bike?"
        p "Banu, there's something I need to tell you."
        "Banu's heart skips a beat, worry creeping into her eyes. She braces herself for whatever Polad is about to say, her mind racing through all the possibilities."
        scene v17-140 with fade
        "They both step off the bike, and Polad takes Banu's hand gently. With a confident yet gentle pull, he starts leading her deeper into the forest. The leaves underfoot rustle softly as they walk, the dappled sunlight playing on the ground."

        b "Polad, what's going on?"
        p "Just trust me, Banu. I want to show you something special."
        b "Alright, but I hope this isn't another surprise twist."
        scene v17-141
        "As Samir hides behind a large tree, his curiosity is piqued by the sight of Banu and Polad walking hand in hand."
        "As he continues to watch Banu and Polad from behind the trees, a growing sense of jealousy washes over him."
        scene v17-142
        "The sight of Banu holding hands with another man, someone who isn't her husband, stirs a mix of emotions within him."
        "His heart tightens with an unexpected ache, and he finds himself grappling with feelings he hadn't anticipated."
        scene v17-143
        "As Samir continues to observe Banu and Polad from his hidden vantage point, his internal struggle with jealousy intensifies. "
        "Just when he thought his emotions couldn't be stirred any further, his heart sinks as he witnesses a surprising turn of events."
        "Banu suddenly leaps into Polad's arms, her laughter ringing out in the forest."
        "Polad's strong arms encircle her, effortlessly holding her weight."
        "Samir's shock is palpable as he watches this unexpected display of physical closeness between the two."
        jump polad_banu_forest


label polad_banu_forest_continue:


    if banugotomuratsapartmentafterfun == True:

        scene black with Dissolve(3)
        ""
        centered "{size=+120}...{/size}" with Fade(0.5, 0.5, 5)
        scene v17-213 with irisin
        play music "audio/up.mp3"
        "In the end of a wild night Banu and Murat are back at Murat's apartment with his best friend Vasif."
        b "So, here we are, back at your place. That was quite the night, wasn't it?"
        mur "Yeah, it definitely was something. You've got some moves, Banu. I never would've guessed you were hiding a dancing queen inside you."
        va "Seriously, Banu, you were amazing! I didn't know you could dance like that."
        b "Oh, thank you, Vasif. It's just... I guess the music got to me."
        b "So, Vasif, how did you and Murat become friends?"
        scene v17-214
        va "Well, we met in college. Shared a few classes, discovered our mutual love for late-night conversations about life and the universe. We've been inseparable ever since."
        mur "Yeah, and we've had our fair share of adventures."
        b "I can imagine. It sounds like you two have been through a lot together."
        va "Oh, you have no idea. But hey, tonight was an adventure of its own, right?"
        b "Yes, it certainly was."
        scene v17-215
        va "You know what would make this night even better? If you stayed over, Banu. We could continue the fun, maybe binge-watch some movies or play some games. What do you say?"
        b "Thank you, Vasif. But I should be getting home. I have responsibilities and commitments."
        scene v17-216
        va "Oh, come on, responsibilities can wait. It's not every day we get a chance to have this much fun."
        mur "Vasif's right, Banu. It's been a while since we all hung out like this. It could be a memorable night."
        b "Guys, it's not appropriate for me to stay the night here."
        va "Appropriate? Oh, come on, we're all adults here. What's a night of innocent fun among friends?"
        mur "You know, Banu, I can't help but feel like you're using your commitments as an excuse. I mean, we both know that you like having fun, so why not spend the night with us?"
        stop music
        menu:
            "Banu leaves":
                $ renpy.block_rollback()
                $ banustaysmuratandfriend = False
                scene v17-217
                b "Oh, Murat, you really have a talent for painting quite the dramatic picture, don't you?"
                mur "What do you mean?"
                b "I mean, come on! Are you auditioning for a role in a romantic movie? The brooding hero who can't forget his past love?"
                mur "It's not like that, Banu. I'm just being honest about what I feel."
                b "Well, then let me get this straight – you want me to stay the night so we can have some grand romantic revelation and live happily ever after?"
                scene v17-218
                va "Well, well, Banu, it seems Murat's romantic monologue didn't quite do the trick. But you know what they say – persistence pays off. How about you stay the night and let me show you how irresistible I can be?"
                b "Oh, Vasif, you're quite the charmer, aren't you?"
                va "You have no idea. Come on, Banu, staying the night could be a lot of fun. We'll have a blast, I promise."
                b "Vasif, I have no doubt you know how to have a good time, but my idea of fun might not exactly align with yours."
                va "You're telling me dancing the night away and enjoying each other's company doesn't sound like a good time?"
                b "It sounds like a wonderful time, Vasif. But I have responsibilities and commitments that I can't overlook."
                scene v17-219
                "Banu's steps were purposeful, her stride unwavering as she walked away."
                "Murat and Vasif had nothing to do as they stood where they were and watched as she left the room."
            "Banu stays":






                $ renpy.block_rollback()
                $ banustaysmuratandfriend = True
                scene v17-220 with fade
                b "You know what, Murat? You've convinced me. I can spare a few more hours before I have to head home. Let's make the most of it."
                va "Now that's what I'm talking about! Welcome back to the land of spontaneous fun, Banu."
                mur "You know, Banu, I never would've guessed that behind that modest facade lies such a lewd woman."
                scene v17-221
                b "Oh, really? And what exactly makes you say that, Murat?"
                mur "Well, you were dancing like there was no tomorrow at the club, surrounded by all those flashing lights. I had to do a double-take to make sure it was really you."
                b "My goodness, you caught me! Dancing and having fun automatically makes me scandalous, huh?"
                b "You have quite the imagination, Murat. But let me assure you, my dance moves aren't indicative of any secret life."
                scene v17-222
                va "You know, Banu, I have to say something. Watching you dance tonight, seeing your smile, it's like a spell. It's hard for me to resist, to not tell you how much I want..."
                b "Vasif, let's keep the mood light, shall we?"
                va "No, Banu, I need to say this. I want you, not just for a few hours of fun, but for more. I've been drawn to you, and tonight... it's like all those feelings are right at the surface."
                scene v17-223
                b "Vasif, this isn't the kind of conversation we should be having. Let's just have fun, I see that you're drunk a bit."
                scene v17-222
                va "Banu, I can't hold it back any longer. I need to tell you – It's the first time I felt this way."
                va "The way you carry yourself, your strength, your grace... it's like a magnet, pulling me towards you."
                scene v17-223
                va "I couldn't keep it inside any longer. It's like an ache, Banu, a constant longing."
                b "I never intended for things to become this complicated. "
                "The room felt suspended in an uneasy stillness, the air heavy with the weight of Vasif's confession."
                "Banu and Vasif exchanged glances, their eyes locking in a moment of surprise and discomfort."
                "Banu's gaze held a mixture of surprise and concern, her lips slightly parted as if searching for the right words to respond."
                mur "Well, Vasif, I've always said that too much dancing can make a person a bit drunk. Looks like you're experiencing that firsthand."
                va "Yeah, you might be onto something, Murat."
                b "I think we've had enough unexpected revelations for the night, don't you think?"
                mur "Oh, come on, Banu. We're all adults here. Besides, I have an idea to lighten the mood. How about a game?"

                jump murat_threesome_2




label murat_threesome_2_continue:



    if banumeetruslaninprivateplace == True:

        scene black with Dissolve(3)
        ""
        centered "{size=+120}Ruslan...{/size}" with Fade(0.5, 0.5, 5)
        scene v17-319 with dissolve
        play music "sfx/store.mp3"
        "Banu and Ruslan walked into a gadget store right in the middle of the city."
        "Now, here's the thing: her outfit was pretty different from what you'd expect. She was wearing these tight jeans that really showed off her curves and made heads turn."
        "And her top? Well, it wasn't your usual kind. It actually revealed a bit of her belly button, like those trendy ones you see in magazines."
        scene v17-320
        "If you took one look at her face, you could tell something was off. Her expression was this mix of sadness and anger all rolled into one."
        "Her brows were kind of furrowed, and her eyes had this distant look, like she was lost in her thoughts and not in a good way. "
        "And then there's Ruslan, right beside her. But let me tell you, his face was a whole different story. It was like he had this secret grin that just oozed mischief."
        b "I can't believe you're doing this."
        r "Well, you know what they say, stepmom, desperate times call for desperate measures."
        b "This isn't right. Blackmailing me into buying you a smartphone? It's manipulative and unfair."
        r "Life's not always fair, Banu. Besides, we've kept those secrets hidden for a reason, right?"
        scene v17-321
        sel "Hi there! Welcome to our store. Is there a specific type of smartphone you're looking for?"
        b "Yes, we're looking for a smartphone for my stepson here."
        r "Yeah, I'm thinking something sleek and powerful, you know? Good camera, fast processor, all the works."
        b "You know my dear son, we should keep in mind our budget right?"
        r "Yeah, but you get what you pay for, right? Let's not compromise on quality."
        sel "Absolutely, sir. This model offers excellent value for its price. And if you're interested, we do have some premium models available with even more features."
        b "Ruslan..."
        r "Why not take a look at those premium options too? After all, a smartphone is an investment in our daily lives, right?"
        scene v17-322 with fade
        sel "Awesome! It's so nice to see a caring mother helping her son pick out a smartphone. It's a big step, you know?"
        b "Yes, it definitely is."
        sel "And look at him – he's big enough to work and buy one himself in no time!"
        r "Yeah, maybe. But for now, it's nice to have a little help, you know?"
        sel "Of course! That's what family is for, right?"
        "As the seller girl enthusiastically chats with Banu and Ruslan, she remains blissfully unaware of the complex dynamics lurking beneath the surface. "
        "Her positivity and assumption of a close mother-son relationship unknowingly add another layer to the situation."
        scene v17-323
        sel "You know, it's really heartwarming to see parents like you taking an interest in your child's choices, especially in today's digital age."
        b "Thank you."
        sel "Technology can be a bit overwhelming sometimes, but having someone like you to help out makes a big difference."
        b "Well, it's not always easy, but we try our best."
        sel "That's all we can do, right? And it's clear you care a lot about him."
        b "Yes, he's... important to me."
        sel "It's evident. You're giving him the best start with a good smartphone."
        scene v17-324
        r "Yeah, the best."
        "Banu's face carries a hint of sadness and conflict, her eyes momentarily distant. "
        "The seller's well-intentioned conversation unknowingly touches on the complexities of their relationship."
        sel "You know, I'm actually married myself, and we've been talking about having a child soon. Seeing relationships like yours, it's inspiring. Makes me look forward to the future even more."
        b "That's wonderful. Children bring a lot of joy to a family."
        sel "They really do! It's heartening to see such a strong bond between you and your son. It gives me hope for the kind of parent I want to be."
        "Banu's expression shifts from forced politeness to a deep contemplation. She's torn between the seller's well-wishes and the burden of the secret she holds, her anger simmering beneath the surface."
        scene v17-325 with fade
        sel "Alright, let's see... I think this model right here might be a good fit. It's got a solid performance, decent camera, and falls within the budget you mentioned."
        b "'whispers angrily' This is enough. You're taking advantage of me and the situation."
        r "'whispers back, still smirking' Come on, stepmom. Lighten up. It's just a little smartphone deal."
        b "I can't believe you'd go this far. You're playing with fire, Ruslan."
        r "Maybe, but you're the one who handed me the matchstick."
        b "'angry' You're heartless. Your own father, your family – you're willing to tear it all apart."
        scene v17-326 with hpunch
        r "Remember, Banu, play your part well."
        b "You're crossing a line, Ruslan."
        b "Let go of me!"
        scene v17-327
        sel "...and this one also has expandable storage, which can be really useful if you plan to store a lot of photos and videos."
        b "Take your hand off me. She'll suspect."
        r "It's helping you remember who's in control here."
        sel "Are you two discussing a favorite color for the phone? It can be a tough choice with all the options available!"
        scene v17-328
        b "Yes, you're right. Color decisions can be quite important."
        r "I'm enjoying this, Banu. Don't forget, I hold the key to our secrets."
        b "Ruslan, enough! "
        r "Remember, Banu, you're the one who brought this on yourself."
        scene v17-329
        sel "Is everything alright? You both seem a bit tense."
        b "Oh, it's nothing. "
        sel "You know, sometimes choosing a smartphone can be a bit overwhelming, especially with all the options available. But I'm here to help!"
        scene v17-330
        b "'forces a smile' Thank you, we appreciate that."
        r "'still rubbing Banu's pussy' Yeah, it's just that we're trying to find the perfect fit."
        sel "Absolutely! It's great to see a mother and son making this decision together. It can be a fun bonding experience."
        b "Oh yes, definitely bonding."
        r "Don't forget, we have a bond too, stepmom."
        sel "Well, whenever you're ready, just let me know. And remember, technology is there to make our lives easier, not stress us out!"
        stop music

    if agreetoruslanoffer == True:

        if banumeetruslaninprivateplace == False:


            scene black with Dissolve(3)
            ""
            centered "{size=+120}Ruslan...{/size}" with Fade(0.5, 0.5, 5)
            scene v17-331 with dissolve
            "At night, a soft knock echoed through Ruslan's room, pulling him from his thoughts. He rose from his bed and padded over to the door, curiosity piqued."
            "With a creak, he opened the door, expecting to find one thing, only to be met with something entirely different."
            scene v17-332 with fade
            play music "audio/sexy.mp3"
            "There stood Banu, bathed in the dim light, wearing nightwear that was a stark departure from her usual modest attire."
            "The fabric clung to her curves, revealing more skin than Ruslan was used to seeing. A grin played on her lips, a mixture of mischief and challenge."
            "He wasn't prepared for this unexpected encounter, especially with Banu looking so unlike her usual self."
            r "Banu?"
            b "Surprised?"
            scene v17-333
            r "What are you doing here?"
            b "Just felt like paying you a little visit."
            r "At this hour? And in that outfit?"
            b "Oh, this outfit? I thought you might appreciate the change."
            r "You can't just show up like this. It's not right."
            scene v17-334
            b "Right and wrong can be subjective, Ruslan. Besides, who's in control now?"
            r "You're playing with fire."
            b "Maybe. But it seems like you're the one getting burned tonight."
            r "You can't keep doing this."
            scene v17-335
            b "Oh yes I can."
            b "Look at your bulge. You are desperate for a good fuck. Why don't you get a girlfriend? "
            b "It's not healthy to be cooped up in your room all the time."
            r "I don't need your advice on my personal life."
            scene v17-336
            b "Oh, but it's not just advice, Ruslan. It's concern."
            r "I've noticed those looks you give me, Ruslan. Lustful eyes, they call it."
            r "That's none of your business."
            b "True, but when those lustful eyes are directed at your stepmother, it becomes everyone's business."
            r "You're reading too much into it."
            scene v17-337
            b "Am I? So, you don't think it's time you find someone your own age to focus those... eyes on?"
            r "This isn't funny."
            b "It's a little funny, Ruslan. You see, I've realized the best way to take control of a situation is to change the rules."
            r "I won't let you toy with me like this."
            scene v17-338
            b "Suit yourself, Ruslan. Just remember, it's a big world out there, and sometimes, a little distraction can be quite... refreshing."
            b "Focus your attention elsewhere, Ruslan. It's for the best."
            stop music






    scene black with Dissolve(3)
    ""
    centered "{size=+120}Cheating...{/size}" with Fade(0.5, 0.5, 5)
    scene v17-282 with blinds
    play music "sfx/gym.mp3"
    "In the bustling atmosphere of the gym, the clatter of weights and the rhythm of upbeat music created a dynamic backdrop for Banu's workout session."
    "Dressed in red pants and a long-sleeve sports shirt, she stood out amidst the sea of activewear-clad gym-goers."
    scene v17-283
    "Her attire was modest, yet distinctive, with the long-sleeved shirt covering most of her body but daringly revealing her midriff this time."
    "Banu's determination was evident in her eyes as she stood beside her gym instructor, ready to tackle the challenge."
    "The gym instructor, a seasoned professional, provided guidance with a friendly smile that instantly put Banu at ease. "
    b "This is more challenging than I thought, but I'm determined to keep going."
    scene v17-284
    ha "You're doing awesome. It's normal for lunges to feel tough, especially with the added weights. Just take it one step at a time."
    b "My legs are definitely feeling the burn."
    ha "Your muscles are working hard and getting stronger. Keep up that good form – chest up, shoulders back."
    scene v17-285 with fade
    ha "Now, with the barbell in front of your thighs, lift it straight up towards your chin. Keep your elbows higher than the bar and close to your body as you lift."
    b "I can feel the pull in my shoulders and upper back."
    ha "Exactly! As you lift, exhale and focus on squeezing your shoulder blades together at the top of the movement."
    scene v17-286
    b "Got it. Should I keep my back straight?"
    ha "Yes, maintain a neutral spine just like before. And remember, it's not about lifting heavy weights but maintaining good form."
    scene v17-287 with fade
    b "I really appreciate your guidance, Hasan. It helps me feel more confident in my abilities."
    ha "I'm here to support you, Banu. You're doing an excellent job. "
    ha "You know, Banu, lifting weights isn't the only way to reveal your strength."
    b "Oh really? And what other ways are there?"
    ha "Well, I've noticed your determination and focus during our workouts. It's quite impressive."
    b "I do try my best to give it my all."
    ha "And your choice of workout attire is... intriguing, to say the least."
    b "Oh? What's so intriguing about it?"
    scene v17-288
    ha "The combination of the modest long sleeves and open belly... it's a bold statement, Banu."
    b "Well, it's important for me to stick to my beliefs while staying active."
    ha "I must say, it's quite the distraction. But I'm more impressed by your dedication to both your faith and fitness."
    "As they exchanged playful remarks, Banu couldn't help but let her gaze drift for a moment."
    "Hasan's chest muscles were prominent, and her thoughts momentarily wandered."
    b_ "Focus, Banu, focus! You're here to work out, not get distracted."
    b_ "But those muscles... they're really impressive. How does he make it look so effortless?"
    b_ "Okay, time to reel in my thoughts and get back to the exercise. Must. Not. Stare."
    scene v17-289
    ha "Something on your mind, Banu?"
    b "Oh, uh, sorry. I was just... um..."
    ha "Admiring my muscles, were you?"
    b "Well, I mean, you do have impressive muscles..."
    ha "I do work hard for them and I see that you've also improved your fitness."
    ha "It shows. Your dedication is paying off, and you've developed some strong muscles, including those abs."
    b_ "Fuck! Is he doing it on purpose?"
    ha "Your belly muscles are becoming more defined, a sign of your progress. It's impressive."
    b "I never thought I'd hear someone complimenting my belly muscles. But it feels good to know that my efforts are making a difference."
    ha "You deserve the recognition, Banu. Keep up the good work, and your fitness journey will continue to show amazing results."
    stop music

    jump gym_shower_fuck

label gym_shower_fuck_continue:

    scene black with Dissolve(3)
    ""
    centered "{size=+120}Home...{/size}" with Fade(0.5, 0.5, 5)
    scene v17-305 with squares
    "As Banu stepped through the front door, the day's fatigue weighing on her shoulders, she was met with a tense atmosphere that immediately caught her off guard."
    "Her husband, Kamil, sat on the sofa, his face etched with a mix of frustration and concern."
    b "Kamil, what's going on?"
    k "Banu, do you realize how late it is? You didn't even bother to let me know where you were."
    scene v17-306
    b "I'm sorry, Kamil. I got caught up at the gym, and I lost track of time. I should have messaged you."
    k "It's not just about messaging. I've been waiting here, worried sick."
    b "I understand, and I'm really sorry for making you worry. I should have been more considerate okay?"
    b "I didn't mean to make you worry, but I don't need this attitude."
    k "Attitude? You're the one who can't be bothered to communicate!"
    b "I made a mistake, okay? I didn't do it on purpose. You're acting like I committed a crime."
    scene v17-307
    k "You always do this, Banu. You think you can just do whatever you want without considering anyone else."
    b "That's not fair, Kamil. I don't deserve this kind of attack."
    k "We need to talk about this gym instructor. What's really going on between you two?"
    b "What? Are you serious?"
    k "Don't play dumb, Banu. I've seen the way he looks at you, and the way you react to him.."
    k "I'm not blind, Banu. I told you to stop going there but you didn't listen to me and you still go there to meet that guy."

    $ cuckolding = 0

    if callahmed == True:
        $ cuckolding += 1

    if callahmed == False:
        $ cuckolding -= 1

    if banuconfessapastsecrettokamil == True:
        $ cuckolding += 1

    if banuconfessapastsecrettokamil == False:
        $ cuckolding -= 1

    if banusharedetailswithkamil == True:
        $ cuckolding += 1

    if banusharedetailswithkamil == False:
        $ cuckolding -= 1

    if banugotomuratsapartmentafterfun == True:
        $ cuckolding += 1

    if banugotomuratsapartmentafterfun == False:
        $ cuckolding -= 1

    if banustaysmuratandfriend == True:
        $ cuckolding += 1

    if banustaysmuratandfriend == False:
        $ cuckolding -= 1

    if killturan == False:
        $ cuckolding += 1

    if killturan == True:
        $ cuckolding -= 1

    if agreetoruslanoffer == True:
        $ cuckolding += 1

    if agreetoruslanoffer == False:
        $ cuckolding -= 1

    if banuscoldpolad == True:
        $ cuckolding -= 1

    if banuscoldpolad == False:
        $ cuckolding += 1

    if banupushabdulaway == False:
        $ cuckolding += 2

    if banupushabdulaway == True:
        $ cuckolding -= 2


    menu:
        "{color=#008000}Tell a lie{/color}" if cuckolding <= 0:
            $ renpy.block_rollback()
            $ banuconfesscheating = False
            b "Kamil, I can't believe you'd even think that. There's absolutely nothing between us."
            k "I've seen the way he looks at you, Banu."
            b "Kamil, I'm shocked that you'd be so suspicious. He's just my instructor, and we have normal conversations like anyone else."
            scene v17-308
            k "I'm sorry, Banu. It's just that sometimes my mind starts imagining things."
            b "Imagining things? Do you really think I'd risk our relationship like that?"
            k "No, Banu, I don't. I know I shouldn't have let my thoughts get the best of me."
            scene v17-309
            b "I can't believe you'd doubt me like that. After everything we've been through."
            k "I know, Banu, and I'm sorry. It's just my own insecurities getting the better of me."
            b "Fine, Kamil. But please, trust me. There's nothing going on with the gym instructor."
            k "I trust you, Banu. I shouldn't have let my doubts get the best of me."
            b "Just promise me you won't let something like this come between us again."
            k "I promise. I'll work on trusting you more and not jumping to conclusions."
            b "Alright, then. Let's put this behind us and focus on us."

            jump cheating

        "{color=#FF0000}Confess you've fucked him{/color}" if cuckolding >= 1:
            $ renpy.block_rollback()
            $ banuconfesscheating = True
            scene v17-310
            play music "audio/intro.mp3"
            b "Kamil, I need you to listen to me carefully. There's something I need to confess."
            k "What is it?"
            b "I think it's time I tell you the truth, no matter how difficult it might be."
            k "What do you mean, Banu? What truth?"
            scene v17-311
            b "I need you to listen carefully. What I'm about to say is going to change everything."
            k "Banu, you're scaring me. Just tell me what's going on."
            scene v17-312
            b "He fucked me! He's a hot guy and he always treats me nice."
            b "I just thought why not to give him some kind of reward."
            b "I followed him to the shower and we had sex."
            k "What... what are you saying?"
            b "I'm saying that I had a relationship with him. It started as a connection I couldn't resist, and it developed into something more."
            scene v17-313
            k "Banu, how could you do this? How could you betray us like this?"
            b "Kamil, I know this is hard to hear, but I need you to know that I'm not sorry for what happened."
            k "Not sorry? You don't respect me? Are you serious right now?"
            b "Yes, Kamil, I am. I won't lie about how I felt. It was a part of my life, and I won't pretend I regret it."
            k "You're tearing us apart, Banu. Our marriage meant nothing to you?"
            b "I won't pretend that everything was perfect between us. There were issues, Kamil. And I found something I needed in that relationship."
            scene v17-314 with vpunch
            k "How could you do this to us, Banu? I can't even look at you right now!"
            b "Don't you dare raise your hand to me."
            k "You think you can just betray me like this and get away with it?"
            scene v17-315
            b "I won't tolerate violence, Kamil. You can be angry, hurt, whatever you want, but you can't lay a hand on me."
            k "You don't get to dictate anything after what you've done."
            b "I'm not dictating, Kamil. I'm standing up for myself. I won't be a victim of anger or aggression."
            scene v17-316
            k "You're unbelievable. You act like you have the moral high ground?"
            b "I'm not claiming any high ground. But I won't let you resort to violence to deal with your anger."
            k "What are you going to do? Call the police on me?"
            b "If I have to, I will. But right now, you need to leave the room. You need to understand that I won't let anyone disrespect or harm me."
            scene v17-317
            k "You're the one who showed no respect for our marriage."
            b "And I'll face the consequences of my actions. But remember, you don't have the right to be physically aggressive with me."
            k "I can't even talk to you right now."
            b "Fine, Kamil. But remember, violence doesn't solve anything. Take the time you need to cool down."
            scene v17-318
            "As the tension reached its peak, Kamil chose to leave the room instead of resorting to violence."
            "The confrontation had revealed a power struggle within their relationship, highlighting the need for healthy communication and coping mechanisms during times of intense emotions. "
            "The atmosphere remained charged, leaving both of them to grapple with the complex emotions that had surfaced."
            stop music
            jump cuck


    dev "{color=#000000}Thank you for playing! This is the end of this route in this version. Play again to discover more. If you enjoyed it please {a=https://www.patreon.com/lustfulfantasy}support{/a} the development. Please, add the game to your {a=https://store.steampowered.com/app/2505580/Life_in_Middle_East/}wishlist{/a} on Steam to make it grow. {/color}"
    hide screen faith
    hide screen angeldevil
    jump endings
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
