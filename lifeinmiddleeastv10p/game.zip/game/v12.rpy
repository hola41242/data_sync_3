label banu_hiran_kiss_1:
    $ renpy.block_rollback()
    $ banubad += 1
    $ banuacceptsherflirting = True
    jump banu_hiran_kiss







label banu_hiran_kiss:

    scene v12-160
    play music "audio/sexy.mp3"
    b "Well, girls are another matter!"
    b "It’s impossible not to fantasize about women."
    b "Their soft bodies, their smooth skin …"
    "Banu is looking intently at Hicran as she’s saying this, and Hicran doesn’t fail to notice the invitation."
    "She doesn’t waste time and approaches her friend’s full kissable lips."
    scene v12-162
    "Their eyes closed, the sexy women caress each other’s puckered lips with feather-like pecks, with passion inflaming their insides."
    scene v12-163
    "Hicran wastes no time in opening Banu’s skimpy robe and uncovering her silky bronzed skin and her sexy form, and doing the same with her own robe."
    "Now their tongues are part of the action, and their kiss deepens amidst their soft breathy moans."
    scene v12-164
    hic "Mhh! You’re so sexy!"
    b "I’m on fire, Hicran!"
    "Hicran can’t believe Banu has finally yielded to her."
    "She has always thought she could only ever fantasize about her beautiful friend."
    "But now she’s gotten her hands on her warm skin, she is overtaken by passion."
    scene v12-165
    "So, she straddles her friend and grinds her naked body to Banu’s sensual one, their fronts molding to each other’s."
    "They never stop kissing and moaning, everything else forgotten during the magical moment of their first kiss."
    scene v12-166
    "Banu can’t believe she’s kissing another woman. She can’t believe how far she’s come in the last few months."
    "But it’s just a fleeting thought. She immerses herself in the moment and revels in the sensations."
    b "Kiss me! Hold me!"
    hic "Mhh! You sexy angel!"
    hic "I’ve wanted to do this for so long!"
    "But their passion doesn’t reach the next level."
    stop music
    scene v12-167 with fade
    "Hicran knows she could probably do more, but she doesn’t want to scare Banu away her first time."
    "So, their embrace slowly ebbs away, and they disengage, panting and staring into each other’s eyes."
    "Banu isn’t regretting it, but now she’s a bit embarrassed, so she stands up and, covering herself along the way, makes for the door."
    hic "Banu, that was …"
    b "Yeah, it sure was something!"
    "Banu is walking slowly towards the sauna door, still in turmoil after her first lesbian kiss. "
    "She has enjoyed it much more than she thought she would."
    $ renpy.end_replay()
    $ persistent.banu_hiran_kiss_unlocked = True
    jump banu_hiran_kiss_continue


label polad_fucks_banu2:
    stop music
    "They climb the stairs and soon reach the front door, where they enter without further ado."
    b "Hi Nesrin. I’m with Polad!"
    p "Nah!, she’s not home."
    scene v12-16
    b "Where is she?"
    p "She went to visit her aunt who’s just lost her husband. She lives just outside of town."
    scene v12-17
    play music "audio/sexy.mp3"
    $ lust = 1
    $ loyalty = 5
    $ orgasm = 0


    show screen lust
    show screen loyalty
    show screen orgasm







    "The demure woman starts to get suspicious of the whole episode and tries to make her thoughts known without being too direct."
    b "Do you think it’s a good idea for me to be here alone with you?"
    b "What would Nesrin think?"
    p "Well, so that just means we won’t tell her."
    p "And I think it’s a great idea that we’re all alone."
    p "I’ve wanted to have you all alone for ages, actually."
    b "What for?"
    scene v12-18
    $ lust = 2
    p "To tell you that you’re such a hot girl."
    p "That you drive me crazy."
    p "And that I want to enjoy that super-sexy body to my heart’s content."
    scene v12-19
    b "What the fuck? Are you insane?"
    b "Are you forgetting we’re both married?"
    p "Ah, so you’re not exactly saying you don’t want to be alone with me."
    b "Of course I don’t want to. Whatever made you think otherwise?"
    p "Bullshit! I’ve seen how you look at me."
    scene v12-21
    $ lust = 3
    p "Look at me!"
    p "Tell me you’ve never thought about me that way!"
    scene v12-20
    "Banu remains silent."
    "Her heart is starting to beat really fast and she can’t risk answering with a broken voice and give herself away completely."
    "She has been aware of the way Polad looks at her for some time now..."
    "...and she can’t shamelessly deny to his face that she has never thought about the two of them getting together."
    "Polad senses Banu’s inner conflict and realizes he needs to start putting words into practice, because he’s breached some of her defenses."
    "He clutches her body to his and his hands begin a sensuously low descent along her sides, until they reach her ass."
    "The perfect ass he’s been dreaming of worshiping and defiling for a long time now."
    "At the same time his face gets closer and closer to the sensual woman’s face, admiring those full suckable, fuckable cocksucker’s lips."
    scene v12-21
    p "I’ve been dreaming of using your body so many times."
    p "You have the figure of a teen girl!"
    p "And the sensuality of a wanton woman."
    p "You drive me crazy! I have to have you!"
    b "We can’t Polad! Please, don’t make me."
    scene v12-20
    p "I’ve been imagining your ass, your lips and your beautiful body available to me to do as I please, kissing you all over."
    p "Your slim, sexy, perky figure and that perfect ass sticking out."


    p "I want to use you and make you scream from pleasure."
    b "No, Polad. Stop! I don’t …"
    scene v12-22 with hpunch
    $ orgasm = 1
    "But the words are stopped mid-sentence as Polad grabs the oriental beauty and kisses her with feeling..."
    "...sensing the keening sound in her throat after an oomph of surprise."
    "She remains passive, not really fighting him, but not exactly trying to stop him either."
    "The only token resistance she puts up is a feeble push with her hands against her brutish assailant."
    "That is, until Polad grabs her leg and lifts it, giving her a feel of his hard member against her belly. This is when he knows she’s capitulated."


    p_ "I’ve got you now! I’m gonna do what I want with you now!"
    b_ "I can’t resist! I like him too much!"
    b_ "Why is he doing this to me?"
    scene v12-23
    "The fiend within Polad has awakened. His blood feels like lava in his veins and his cock is raging. He has the strength of a beast."
    "He lifts Banu in his arms effortlessly, carrying her through the apartment to the bedroom where he usually fucks his wife mercilessly."
    "Banu sees the blackness of his pupils, and sees him panting with desire. "
    "She is a bit scared. But she’s also impressed by the animal-like desire she has provoked in this manly man."
    scene v12-24
    "As he deposits her with surprising tenderness on the bed, and starts removing his clothes, she feebly tries to plead with him once again."
    b "Please, Polad. Stop this. It’s ok. You gave in to a moment of weakness, but please come to your senses now."
    p "It’s not a moment of weakness."
    p "I’ve been fantasizing about you so much lately!"
    p "Everybody has been wondering what’s wrong with me."
    p "And now that I’ve got you, I’m not letting you go."
    scene v12-25 with vpunch
    $ lust = 4
    $ orgasm = 2
    $ loyalty = 4
    "And with that, he climbs on the bed, planting himself between Banu’s legs, and attacks her ruby lips with his..."
    "...sucking them, and stabs his tongue in her warm mouth, reveling in the sensual taste of her saliva."
    scene v12-26
    "Banu is swept over by the forcefulness of her assailant, forgetting for a moment that what he’s doing – what they’re doing – is wrong."
    "She hears herself exhale a long moan, that surely Polad can’t have missed."
    scene v12-27
    "Polad lets off and kneels between this goddess’ legs. He grabs the top of her blouse."
    b "No, please Polad. Don’t take my clothes off!"
    b "I’m married! I can’t show my body to another man!"
    "But Polad is a man possessed, and pays no heed to Banu’s pleading words. "
    "If anything, they spur him on even more."
    scene v12-28 with hpunch
    $ lust = 4
    $ orgasm = 2
    $ loyalty = 3
    "So, he suddenly pulls hard, sending the top buttons of the flimsy blouse flying."
    "Banu is shocked, and her helpless frown makes her cute face even sexier."
    scene v12-29
    p "You’ve got such pretty tits!"
    p "They’re so much hotter than I imagined!"
    p "Come here!"
    scene v12-30
    "He lifts her and holds her tight to him once again, starting once again with those kisses that make Banu swoon. "
    "He is also kneading and squeezing her cheeks, making her panties rub against her skin."
    "Banu realizes she feels hot, her breath is labored and …"
    scene v12-31
    "She’s soaking wet! Her pussy must have been leaking for some time, but only now does she realize it."
    "She knows Polad has made her really horny with the kissing, groping, the dirty talk and how much he desires her."
    scene v12-32
    "But she cannot, mustn’t give in! She is a good woman and she can’t shamelessly give herself to this man..."
    "...no matter how sexy he is, no matter how hungry he makes her pussy feel."
    b "Polad, that’s enough now. I don’t want this."
    b_ "He’s ignoring me! Does he know I’m just protesting for appearance’s sake?"
    "He tenderly uncovers her head, as if handling a fragile flower. They both tremble at the sensations this rouses in either of them."
    scene v12-33
    $ lust = 4
    $ orgasm = 2
    $ loyalty = 2
    "Polad is in awe at the extreme beauty of his dream woman, still not fully believing she is now in his arms."
    p "I’ve always wondered how you looked without the headscarf."
    p "You’re beautiful beyond words!"
    "Banu is moved by the evident feelings that the simple act of uncovering her hair incites in this strong dominant man."
    "Yet, she feels a bit of shame because it is a forbidden act, maybe even more intimate than the groping and kissing."
    "And she isn’t doing much to stop it, after all."
    "Polad is a man on a mission by now. Nothing will stop him from getting what he wants. "
    "He can also sense that his lover is only trying to resist, and her words are devoid of feeling."
    scene v12-34
    "He starts unwrapping his gift, removing her blouse completely, and then pushes her down to lie on the bed, lowering her pants."
    p "Wow, you’re wearing such pretty panties!"
    p "Pink really suits your gorgeous skin!"
    scene v12-35
    "He peppers her body with kisses, from her legs to her breasts, inhaling her sweet scent and huffing with desire."
    p "Your skin is so soft!"
    b "No! Polad, don’t touch me!"
    b "This is really too much!"
    b "We are still in time to stop and forget this ever happened!"
    p "You’re not fooling me!"
    p "I can tell you want this as much as me!"
    scene v12-36
    p "Let me see what those cute panties are hiding."
    p "Ohh! What a sexy bare cunt!"
    p "Why is it so wet?"
    scene v12-37
    "The gorgeous milf is lost for words."
    "She doesn’t know what to think anymore."
    "She doesn’t know what to wish!"
    "Does she want Polad to stop and maintain her virtue, leaving her desire unfulfilled?"
    "Or that he pushes on and makes her his, making a whore of her, but a whore with a satisfied libido?"
    "While the war is raging in Banu’s mind, Polad has undressed completely..."
    "...and when she comes to from her musing, she can’t help but admire his hard, muscled body and his huge cock."
    scene v12-38
    $ lust = 4
    $ orgasm = 3
    $ loyalty = 1
    b "Don’t do this!"
    b "No! Get that thing away from me!"

    b "I’ll tell Nesrin!"
    b "I’ll ruin your marriage!"
    show poladteasingbanuanimation
    stop music
    play music "voices/softmoan.mp3"
    "Polad grabs her legs and pushes them backwards, exposing her drenched cunt, his cock looming over her belly, then starts rubbing his cockhead over her enflamed clit."
    p "Look at that! Once it’s inside you, it’s going to reach your stomach!"
    p "Do you like my big helmet teasing your clit?"
    stop music
    scene v12-39
    "Banu know she’s been defeated by now. She won’t be able to resist anymore."
    "Actually, she won’t say anything, scared that he’ll finally come to his senses and not fuck her anymore."
    "The tune in her head has changed and now she’s silently begging him to skewer her with his hard cock and make her scream, as he promised earlier."
    "But he keeps teasing her, and rubbing his huge mushroom over her sensitive snatch."
    scene v12-40
    $ lust = 5
    $ orgasm = 3
    $ loyalty = 0
    p "I know you want it! You’re practically drooling!"
    p "But I want you to tell me."
    p "I’m not gonna give it to you if you don’t tell me!"
    b "Ohh! You bastard!"
    b "Fuck my pussy!"
    b "I want it!"
    scene v12-41
    p "That’s a good girl!"
    "Polad moves the tip of his cock down and slots it into Banu’s dripping opening, pushing ever so slowly to savor the entrance to this snug pussy as much as he can."
    p "Ohh! You’ve got such a tight cunt!"
    b "Ahh! Open it up! I want you deep inside!"
    p "You’re gonna be my little whore!"
    show poladfuckingbanufirstanimation
    play music "voices/softmoan.mp3"
    p "Take it!"
    "He pushes his rod deeper inside his lover, gripping her squirming thighs firmly so she can’t dislodge his member from her convulsing pussy, until it bottoms out in her."
    p "Yes! Ahh!"
    p "Mhh! It’s so warm inside your cunt!"
    p "Do you like feeling all my cock deep inside your belly?"
    b "Mhh! I love it! It’s so thick!"
    b "Ohh, it’s so hard!"
    stop music
    scene v12-42
    $ lust = 5
    $ orgasm = 4
    $ loyalty = 0
    "They’re moving in unison now, changing position as Polad ravages her body to his heart’s content."
    scene v12-43
    "Banu is egging him on with her moans and with her copious juices, making their whole crotch area slick."
    scene v12-44
    "Banu is now on her side and the penetration is as deep as she’s ever had."
    "Polad is loving having the whole length of his cock enveloped in this squeezing pussy."
    show poladfucksbanufirsttimesideanimation
    play music "voices/moan4.mp3"
    p "Mhh! What a little slut!"
    p "You’re sucking my cock so nice with this sweet pussy!"
    p "Do you like it when I bang your cervix?"
    b "Ohh! You stud! Do me hard!"
    b "Mhh! You’re slamming my womb so good!"
    stop music
    scene v12-45
    "They change position once again, with Polad on top of the woman, knocking her down into the mattress with each strike of his hips."
    show poladfucksbanufirsttimemissionaryanimation
    play music "voices/moan4.mp3"
    p "This pussy feels so fucking good!"
    p "Your cunt was made for my cock!"
    b "Pound my cunt into submission!"
    $ lust = 5
    $ orgasm = 5
    $ loyalty = 0
    b "Haaa! I’m cumming!"
    b "Ahh! Ohhhhhhh! Yes!"
    b "Ahhh! Ahhh! Ahhh!"

    scene v12-46
    stop music
    p "Yes! Keep squeezing me like that!"
    p "What a slutty cunt!"
    p "You’re gonna suck the cum right out of my balls!"
    p "Mhh! Ohhhhhhhhh!"
    p "Take my sperm!"
    p "I’m flooding your womb!"
    p "Ahhhhh!"
    p "Ohhhh! Squeeze my cum out!"
    p "Mhhhh! Oh fuck yeah!"
    scene v12-47
    $ lust = 4
    $ orgasm = 1
    $ loyalty = 1
    "Exhausted by this very satisfying bout of sex, the two lovers disengage and catch their breath lying on their back."
    "Polad is still euphoric, with the endorphins still flooding his system."
    "Banu feels the same, letting the blissful sensation wash over her, feeling completely relaxed and at ease, the feeling of Polad’s cum dripping out of her adding to the sensation."
    scene v12-48
    $ lust = 4
    $ orgasm = 1
    $ loyalty = 3
    "The guilt and shame are forcefully pushed at the back of her mind. She’ll deal with them later, when the time comes."
    "For now, she just wants to relish the aftermath of the best fuck of her life."
    hide screen lust
    hide screen loyalty
    hide screen orgasm
    $ renpy.end_replay()
    $ persistent.polad_fucks_banu2_unlocked = True
    jump polad_fucks_banu2_continue

label v12:




    $ accepttheride = False
    $ followpolad = False
    $ muratpaysforshopping = False
    $ chatuptheinstructor = False
    $ banuadmitsit = False
    $ banuishappywithkamil = False
    $ banuacceptsherflirting = False
    $ banugoestoturanshouse = False
    $ banuteasesruslan = False
    $ banuflirtsback = False


    centered "{size=+120}After work{/size}" with Fade(0.5, 0.5, 5)
    scene v12-1 with dissolve
    "Another scorcher of a day. What a warm fall this is being so far! "
    "Early November still feels like September and it doesn’t seem to want to let off anytime soon."
    "It’s 6pm and almost all the offices have closed up for the day. "
    "Everybody is rushing to finally get home and out of their suffocating smart clothes and put their feet up."
    "Banu is one of them, patiently waiting for the bus to return to her flat, though there are no signs indicating it will arrive anytime soon. "
    "A sensation of distress soon starts to kick in."
    b_ "All days look the same lately. I’m in a rut!"
    b_ "And to top it off this unnatural heat is making me all sweaty!"
    b_ "Where is that damned bus? It should have been here 15 minutes ago!"
    scene v12-2
    "On the same road, the answer to one of Banu’s problems is leisurely cruising along. "
    "Polad is on his beloved bike, out for a ride to enjoy the sun and revel in the discomfort of the workers during rush hour."
    "A small revenge for him, who has to be slaving at work while everybody else drinks and is merry, and he’s making the most of it."
    scene v12-3
    b_ "Oh, that’s Polad! What’s he doing here?"
    p_ "Look what I’ve found! "
    scene v12-4 with dissolve
    b "Hey Polad! Fancy seeing you downtown, without a care in the world."
    p "Hi Banu! Enjoying the heat, sitting there all alone?"
    b "Yeah, as if! The blasted bus is late again!"
    scene v12-5
    p "Hop on! I’ll take you home."
    scene v12-6
    play music "audio/tension.mp3"
    menu:
        "Accept the ride":
            $ renpy.block_rollback()
            $ accepttheride = True
            $ banubad += 1
            b_ "I don’t want to wait another single minute for this fucking bus! To hell with what the people might think."
            b "Yes, Polad. Thanks. You’re a lifesaver."
            scene v12-7
            stop music
            "Banu climbs on the powerful-looking motorbike, nestling her butt comfortably on the leather seat. "
            "She grabs Polad’s midsection and can’t help notice the feeling it gives her."
            scene v12-8
            b_ "Wow, he’s so fit! Those muscles are hard!"
            p "We’re off! Hold on tight!"
            b "Aye aye, captain! Ha ha!"
            scene v12-9
            "Polad is an experienced rider, so he’s comfortable taking some small risks. "
            "Banu, grasping his abdomen tightly, feels the thrill of the speed and revels in being at the mercy of the man. "
            scene v12-10
            "She’s giddy with excitement by the time they stop, and it takes her a few seconds to realize that they’re at Polad and Nesrin’s house."
            scene v12-11
            p "Sorry Banu! I need to make a quick pit stop."
            scene v12-12
            b "What’s the matter?"
            p "I’m wearing a new undershirt and the stitching must be defective, because it’s chafing my side like crazy."
            scene v12-13
            play music "audio/tension.mp3"
            b "So, what do you want to do?"
            p "I’m going to get changed! It’ll only take a minute. Let’s go!"
            menu:
                "Decline the offer":
                    $ renpy.block_rollback()
                    $ followpolad = False
                    stop music
                    b_ "Now this would really give people the wrong idea. I most certainly can’t."
                    b "No, Polad. I’d rather wait here. I’m sure you’ll be quicker this way. "
                "Follow Polad":





                    $ renpy.block_rollback()
                    $ followpolad = True
                    $ banubad += 3
                    b_ "Another setback! Will I ever make it home today?"
                    b "Alright! As long as you’re quick! I really need to get home."
                    b "Let's go!"
                    scene v12-14
                    "They hop off from the bike and start heading for Polad’s house."
                    "Once they’re almost at the gate, the burly man wraps his arm around Banu’s waist and pulls her to him. "
                    "She’s a bit taken aback by the over-friendly gesture, but remains silent, overwhelmed by how good it feels to be held like that by a hunk like Polad."
                    scene v12-15
                    jump polad_fucks_banu2
        "Refuse the ride":



















            $ renpy.block_rollback()

            $ accepttheride = False

            stop music

            b_ "It wouldn’t be proper if people saw me and started to talk behind my back."

            b "Sorry Polad, I can’t. What if someone I know saw us? It’s not proper!"





label polad_fucks_banu2_continue:
    scene black with Dissolve(3)
    centered "{size=+120}The pub{/size}" with Fade(0.5, 0.5, 5)
    scene v12-49 with blinds
    play music "audio/action.mp3"
    "The shift is finally over at the pub where Polad is the manager. "
    "His employees Natasha and Sasha are chatting, waiting to close shop as a team, while their boss is doing the cashing-up."
    scene v12-50
    nat "It wasn’t so busy today! Thanks fuck!"
    nat "I’m not sure I could have taken another exhausting day!"
    sa "Yeah, I hear you!"
    sa "It’s weird, though."
    sa "We’re usually very busy everyday this time of year."
    scene v12-51
    nat "Well, let’s worry about it tomorrow, shall we?"
    p "Good work today, guys!"
    p "Even though there wasn’t a whole lot to do!"
    scene v12-52
    sa "Thanks, Polad!"
    nat "Thanks, boss!"
    p "Sasha, would you do me a favor?"
    p "Go to the office and count the register money."
    p "I’ve counted it three times and I got three different totals."
    scene v12-53
    p "I must be overworked!"
    sa "No problem!"
    scene v12-54
    nat "Hey Sir. You sure look nice today!"
    p "Me? No, you look fucking sexy."
    p "I can see half of your bubble butt!"
    scene v12-55 with fade
    p "Mhh, so curvy and soft!"
    p "No panties, huh?"
    p "I knew Russian girls were slutty."
    p "But you’re on a whole different level."
    p "You’re getting me real horny!"
    nat "Oh, yeah?"
    nat "What are you gonna do about it?"
    p "I’m gonna grab you and kiss you."
    jump natasha_threesome


label natasha_threesome:
    scene v12-56 with fade
    p "Like this!"
    nat "Mhh! You’re so hard already!"
    p "You’re so sexy, baby!"
    scene v12-57
    p "And you’re dressed really skimpy today."
    nat "I wanted you to look at me and get horny."
    nat "Now shut up and kiss me!"
    scene v12-58
    "Sasha returns and notices the steamy action going on between his boss and his girlfriend. He stands there looking for a few seconds."
    sa_ "They look like they’ve done this before!"
    sa_ "Mhh, I wonder …"
    "But then he decides to make his presence known, instead of just standing there like a creep."
    sa "Ahem!"
    scene v12-59
    p "Oh, we were just …"
    p "I mean …"
    p "I think you’re OK with this."
    p "Do you mind, Sasha?"
    nat "That’s right, he is!"
    nat "Sasha doesn’t mind sharing, do you baby?"
    sa "No, I don’t really mind."
    scene v12-60
    "The sexy blonde whore doesn’t have any intention of letting this chance go, and decides to take the initiative."
    "There are two cocks available, and she isn’t gonna let them get away so easily."
    "Polad is a bit surprised at how easily things have escalated into a threesome with his employees..."
    "...but his engine is revving and he is soon swept away by the whorish attitude of the hot blonde."
    scene v12-61
    nat "Come here, both of you!"
    nat "Show me what you ‘ve got, you dirty boys!"
    scene v12-62
    "Natasha makes short work of the horny men’s trousers, and is faced with two hard members, her boyfriend’s modest one and Polad’s beast."
    "She has already sampled it and can’t wait to get it to tickle her tonsils again."
    nat "Ohh, looky what I’ve found!"
    nat "Not one but two hard bananas!"
    nat "Are they for me?"
    stop music
    show natashasuckingboyfriendanimation
    play music "voices/bj.mp3"
    sa "They sure are, you pretty little slut!"
    sa "Dig in!"

    show natashasuckingpoladanimation
    p "Yeah, gag on those cocks!"
    p "You’re such a whore, princess!"
    nat "Gack! Gack! Gack!"
    nat "Slurp! Suck!"
    nat "Mhhhh! So tasty!"
    scene v12-63
    stop music
    sa "Kiss me, baby!"
    sa "You’re such a tramp!"
    nat "I love you, sweetie!"
    scene v12-64
    nat "Ohh, but I want more now!"
    nat "Skewer me like a piece of meat!"
    nat "Fuck me, baby while I suck our boss’ cock!"
    scene v12-65
    "The young man is caught up in his girlfriend’s liberal attitude and is horny beyond belief."
    "He wastes no time doing just what she asked of him, and is soon pounding the shit out of her familiar cunt."

    scene v12-66
    sa "Ohhh, yeah!"
    sa "Fuck, you’re so wet!"
    sa "You like being used by two men, huh?"
    nat "Mhh, yeah!"
    nat "I’m such a cunt!"
    nat "Slam it into me, baby! You know how I like it!"

    scene v12-67
    sa "Ohhh!"
    sa "You look so sexy with another man’s cock in your mouth!"
    scene v12-68
    "Despite the hard pounding she is getting from Sasha, Natasha’s pussy soon gets hungry for Polad’s larger cock."
    "She feels the need to get her tiny young snatch stretched by that monster."
    nat "Hey, boss!"
    nat "Why don’t you have a turn with my pussy now?"
    nat "Don’t you wanna feel my snug cunt wrapped around you?"
    p "Grrr!"
    p "Get here, you fucking whore!"
    p "I’m gonna fuck the shit out of you!"
    scene v12-69
    "Polad unceremoniously slides his whole length into the piping hot love hole of the beautiful Russian blonde."
    "Despite her bravado, she is suddenly stretched to her limits and squeals at the sudden intrusion."
    nat "Awww!"
    nat "You fucking brute!"
    nat "You’re stretching my little pussy!"
    show threesomenatboyfriendpoladanimation
    play music "voices/slapmoanmedium.mp3"
    p "Take it, you whore!"
    p "You like the pain, don’t you?"
    nat "Ohh, yeah!"
    nat "Use me, Polad!"
    nat "Make me your bitch!"
    stop music
    scene v12-70
    "Sasha is really turned on by the way Polad is dominating his cute little girlfriend."
    "He likes seeing other men doing what they want with her."
    scene v12-71
    "He wants to get in on the action and grabs her throat, adding to Natasha’s abuse."
    sa "You fucking slut!"
    sa "You wanna be abused, huh?"
    sa "You like it rough, huh?"
    sa "Then take it!"
    sa "Take that cock!"
    scene v12-72
    p "Ohh!"
    p "She’s tightening her cunt so much!"
    p "She likes it!"
    p "Oh, yes! She likes it!"
    nat "AHHHH!"
    nat "Do me hard!"
    nat "OHH!"
    nat "I’m just a piece of meat!"
    nat "Let me get you off!"
    nat "Rip my pussy open!"
    scene v12-73
    "The super-pervy Sasha wants more."
    "He has the urge to taste his girlfriend’s sweet pussy juices, leaking out because of the rough treatment Polad and he have given her."
    scene v12-74
    "So he gets her upright and sits her curvy ass against the counter."
    "Then proceeds to devour her sexy gaping hole."
    sa "Ohh, you taste so good!"
    sa "I love this cunt!"
    "Polad waits patiently on the sidelines, the sexy display exciting him."
    "He’s stroking his dick, drenched in the juices of the alluring young girl he’s been fucking."
    scene v12-75
    "But soon, the need to bury it into her again becomes too strong, and he intervenes."
    p "Hey, Sasha!"
    p "Let me have another go at that pussy!"
    sa "Yeah, man!"
    sa "Go ahead!"
    sa "She’s all yours!"
    scene v12-76
    "As Polad resumes slamming his cock into the fiery depths of Natasha’s quim, Sasha pushes her head down on his own cock again."
    "But Natasha wants something different."
    nat "Do me standing up, you stud!"
    scene v12-77
    nat "Just hold my leg up!"
    nat "Ohhh! That’s it"
    scene v12-78
    nat "Make me dance on your dick!"
    nat "I love how thick your helmet is!"
    p "Come here, Natasha!"
    scene v12-79
    p "Climb aboard, you slut!"
    nat "Ahhhh!"
    p "Now you can dance!"
    p "Jump up and down on my cock!"
    nat "Ahhhh!"
    scene v12-80
    nat "You’re kissing my womb with that fat head!"
    nat "It’s so deep!"
    scene v12-81
    "They want to change positions again. Sasha sways her soft dreamboat body seductively towards one of the tables."
    "Polad is following, cock in hand, like a snake charmed by a hypnotic flute, until he reaches the vision of beauty bento over like that."
    scene v12-82
    p "Mhh! That looks so inviting!"
    p "Don’t mind if I do!"
    nat "Ohhh!"
    nat "Do me, you animal!"
    nat "This is your pussy, Polad!"
    nat "Use it hard!"
    scene v12-83
    "Sasha is seated comfortably on a chair by the counter, happily wanking away at the lewd scene unfolding in front of him..."
    scene v12-84
    "...horny and a bit jealous at how Polad is making his girlfriend his personal bitch."
    "But all good things come to an end."
    scene v12-85 with fade
    "Natasha, after cumming multiple times, feels the desire to collect her creamy reward."
    "So she gets her men together as they started and proceeds to wank them and encourage them to relinquish their sweet loads."
    nat "I’m hungry for cum now!"
    scene v12-86
    nat "Give me my prize!"
    nat "I want to get drenched in your tasty sperm!"
    scene v12-87
    "Sasha is the first to reach the finishing line, and unloads copiously on the blonde’s face."
    sa "Ahhh!"
    play sound "voices/man2.mp3"
    sa "Ahhhh!"
    stop sound
    sa "Ohhh! Take it all on your whore face!"
    scene v12-88
    p "Ohhhh yeah!"
    p "Jerk me off!"
    p "Here it comes!"
    play sound "voices/man3.mp3"
    p "Grrrr! AHHHHH!"
    stop sound
    $ renpy.end_replay()
    $ persistent.natasha_threesome_unlocked = True
    jump natasha_threesome_continue

label natasha_threesome_continue:
    scene v12-89
    p "Ohhhhh"
    p "Well, nice doing business with you, guys!"
    scene black with Dissolve(5)
    centered "{size=+120}Home{/size}" with Fade(0.5, 0.5, 5)
    scene v12-90 with squares
    play music "audio/tension.mp3"
    "Banu has confided to Kamil what she has seen their children doing."
    "She has told him of how most probably it was Ruslan who forced or sweet-talked his way in Leyla’s panties..."
    "...and of how he has defied her when she scolded him."
    scene v12-91
    "Now Kamil is furious with his son and Ruslan is forced to take the brunt of this anger."
    k "What the hell were you thinking?"
    k "With your sister?"
    k "What sort of degenerate monster have I raised?"

    r "But, dad."
    r "It just happened!"
    r "I don’t even know how we ended up like that!"
    k "Bullshit!"
    k "Leyla is a sweet girl."
    k "She’s fragile right now after what happened to her!"
    k "Instead of looking after her, you take advantage of the situation?"

    scene v12-92
    b "I’m sure you forced her!"
    b "She’d never do something like that!"
    r "You’re always taking her side!"
    r "She is little miss perfect."
    r "And I’m the monster!"
    r "You’ve never given a shit about me."
    scene v12-93
    k "Shut the fuck up!"
    k "You’re a disgrace!"
    k "I’m ashamed of having you as a son!"
    scene v12-94
    r "This is all your fault!"
    r "You even have my father turning against me!"
    r "But don’t you worry!"
    r "I’ll show him your true colors!"
    r "Just you wait!"
    scene v12-95
    "Ruslan storms out of the room enraged, leaving Kamil wondering what his son will try to come up with, in order to blame Banu for the whole episode."
    b "What’s wrong with him?"
    b "Instead of taking responsibility, he tries to involve me?"
    k "I really can’t understand him lately …"
    stop music
    scene v12-96 with irisin
    "Banu goes to her daughter’s room. She hasn’t spoken to her since the shameful situation she has witnessed."
    scene v12-97
    "She has taken some time to digest what she has witnessed and she’s more prepared to talk to Leyla."
    "She thinks she understands how things really happened, or maybe she’s just rationalizing."
    scene v12-98
    b "Hey, sweetie."
    l "..."
    b "How are you feeling?"
    scene v12-99
    l "I heard everything, mom."
    b "I know you did, baby."
    b "He is gonna get what he deserves."
    b "Don’t worry!"

    l "Mom …"
    b "What is it honey?"
    l "I … We …"

    scene v12-100
    l "He didn’t really force me."
    l "He talked me into it … but …"
    l "I didn’t exactly run away from it."
    b "Nonsense!"
    b "Sweetie, you’re just confused."
    l "Mom, will you listen to me?"
    l "I didn’t start with the intention of getting that far."
    l "But we both did it!"
    scene v12-101
    b "He took advantage of your fragile state."
    b "He should know better!"
    l "It’s not just his fault, mom."
    scene v12-102
    b "Shh, come here baby!"
    b "Everything is gonna be alright."
    scene black with Dissolve(5)
    centered "{size=+120}The next day{/size}" with Fade(0.5, 0.5, 5)
    if banuturansexfirsttime == False:
        play music "audio/sensual.mp3"
        scene v12-103 with move
        "Banu is at the office, like every weekday. She is wearing smart clothes and her hair is covered, as is proper for a decent woman."
        scene v12-104
        "However, her outfit is rather tight as usual, and borders heavily into what could be described as sexy."
        scene v12-106
        "But then again, her lithe but curvaceous body would excite any sane male, no matter what clothes she’s wearing."
        "Right now, she’s carrying some files to be archived, her sexy ass swaying dreamily for anybody who’s watching but, alas, she’s all alone."
        b_ "Ouch! These new shoes definitely compliment my figure."
        scene v12-107
        b_ "But they hurt like hell!"
        b_ "I guess I need to break them in a bit more."
        scene v12-110 with fade
        b_ "I’m going to go shopping again soon."
        b_ "I wanna buy some more tight pants, maybe a skirt or two."
        b_ "Something a bit sexier, a dress."
        b_ "Oh, and some lingerie."
        b_ "I can’t spend too much though!"
        b_ "Shame!"
        stop music

    if banuturansexfirsttime == True:
        scene v12-103 with move
        play music "audio/sensual.mp3"
        "Banu is at the office, like every weekday. She is wearing smart clothes and her hair is covered, as is proper for a decent woman."
        "However, her outfit is rather tight and borders heavily into what could be described as sexy."
        scene v12-104
        "But then again, her lithe but curvaceous body would excite any sane male, no matter what clothes she’s wearing."
        b_ "Ouch! These new shoes definitely compliment my figure."
        b_ "But they hurt like hell!"
        b_ "I guess I need to break them in a bit more."
        b_ "I’m going to go shopping again soon."
        b_ "I wanna buy some more tight pants, maybe a skirt or two."
        b_ "Something a bit sexier, a dress."
        b_ "I can’t spend too much though!"
        b_ "Shame!"
        "But, evidently, Banu is not really by herself as she thought."
        stop music
        scene v12-105
        "Sneaking like a predator, her boss Turan has been following her through to the archive, reveling in the swaying walk of his hot piece of ass employee."
        t_ "Will you just look at that!"
        t_ "She’s posing like a model!"
        scene v12-108
        t_ "Always with those tight fucking pants!"
        t_ "Oh, look at those platform heels!"
        t_ "She looks so fucking hot in them!"
        t_ "I’m gonna fuck her with her heels on next time!"
        t "That’s just beautiful!"
        t "Hold that pose for me, sexy!"
        scene v12-109 with fade
        b "What the fuck!"
        b "You scared the shit out of me!"
        b "Were you following me?"
        t "I sure was."
        t "I like to keep an eye on my playthings all the time."
        scene v12-111
        t "You look sexy as hell in those shoes."
        t "Did you wear them for me?"
        t "How do you know I’m a sucker for platform heels?"
        b_ "..."
        b_ "You bastard!"
        t "Well, it doesn’t matter!"
        scene v12-112
        play music "audio/tension.mp3"
        t "I want to see more of you wearing them."
        t "I’ll be waiting for you at my place after work."
        t "I know you’ll be there if you know what’s best for you."
        scene v12-113
        t "I’m pretty sure you don’t want your husband to know what his wife has been up to. "
        t "That she’s a little slut who’s sleeping with her boss behind his back."
        b_ "..."
        b_ "How dare you?"
        t "Good good!"
        t "I knew we would see eye to eye."
        t "Catch you later, then!"
        t "Don’t keep me waiting!"
        stop music
        scene v12-114
        b_ "What a piece of shit!"
        b_ "How did I end up like this?"





    scene black with Dissolve(3)
    centered "{size=+120}After work{/size}" with Fade(0.5, 0.5, 5)
    scene v12-115 with blinds
    play music "audio/sensual.mp3"
    "The shopping trip Banu has been thinking of while she was at work is now happening."
    "She has decided to visit a new shop that has just opened at the mall near her workplace."
    scene v12-116
    "With all that has been happening in her life, she thinks she deserves to treat herself to something nice."
    b_ "Right! This is the shop I’ve wanted to visit for a long time!"
    b_ "They’ve got so many nice things."
    scene v12-117
    b_ "Mhh, the prices are ok, too."
    b_ "Guess I can buy a few things I’ve wanted."
    b_ "Mhh, this dress here. And this one!"
    b_ "Some pants."
    b_ "I need something for the gym as well."
    scene v12-118 with fade
    b_ "I’m going to try them on now."
    scene v12-119
    "In the fitting room, the lovely MILF spends some time admiring her youthful sexy figure as she’s getting undressed."
    scene v12-120
    b_ "You’ve still got it girl!"
    b_ "This is a nice body for a mother!"
    scene v12-121
    b_ "Mhh! I look sexy in my underwear."
    b_ "Should I start wearing something sexier?"
    b_ "Pah! Maybe Kamil would pay me more attention!"
    scene v12-122 with fade
    b_ "Yeah! I look good in this!"
    scene v12-123
    b_ "It’s really sexy, with those strings in the front."
    b_ "A bit too sheer, maybe?"
    scene v12-124 with fade
    b_ "Well, this is definitely a keeper."
    scene v12-125
    b_ "It’s lacey and white."
    b_ "Like a sexy mini wedding dress!"
    scene v12-126 with fade
    b_ "Wow! I’m really a hot girl!"
    b_ "Yeah, those legs are sexy!"
    scene v12-127
    b_ "But who am I gonna wear this dress for?"
    scene v12-128
    b_ "It doesn’t matter! I’ll wear it for myself."
    scene v12-129 with fade
    b_ "Oh! Look how cute this outfit is!"
    scene v12-130
    b_ "It’s modest, but it’s lacy and it show some cleavage!"
    b_ "I like it!"
    scene v12-131 with fade
    b_ "Aww! I like this leopard-print blouse!"
    b_ "It’ll go perfectly with these pants!"
    scene v12-132
    b_ "I’m a sexy tigress!"
    b_ "Roar!"
    scene v12-133 with fade
    b_ "Yeah, this’ll be perfect for working out in."
    scene v12-134
    b_ "Going to the gym is really paying off!"
    b_ "Look at this hot body!"
    scene v12-135 with fade
    stop music
    "Returning to the main floor of the shop, a familiar figure is walking fast behind Banu to catch up with her."
    "Is this a chance meeting or has Murat been following the sexy woman around?"
    scene v12-136
    mur "Hello there, pretty lady!"
    b "Oh, Murat!"
    b "What are you doing here?"
    scene v12-137
    mur "I was shopping at the mall and I saw you from outside."
    mur "Buying some new clothes, I see."
    b "Yeah, I’m treating myself."
    b "Since nobody does it for me!"
    scene v12-138
    mur "A lovely lady like you?"
    mur "Unlikely!"
    mur "I’m sure you have droves of admirers who’d be ready to walk over hot coals to try and please you."
    scene v12-139
    play music "audio/tension.mp3"
    b "Always the usual charmer!"
    mur "I mean it!"
    mur "Let me prove it to you!"
    mur "I’m gonna pay for your shopping!"
    menu:
        "Let him pay":
            $ renpy.block_rollback()
            $ muratpaysforshopping = True
            $ banubad += 1
            scene v12-140
            b_ "I’m not going to stop him if he wants to spend money for me."
            b_ "I still won’t owe him anything, no matter what he believes."
            b "Well, aren’t you the gentleman?"
            b "Sure, go ahead if you want to."
            scene v12-142
            mur "Here’s my credit card, Miss!"
            scene v12-141
            b "Thanks a lot Murat."
            b "That’s really nice of you!"
            stop music
        "Pay yourself":








            $ renpy.block_rollback()
            $ muratpaysforshopping = False
            stop music
            b_ "He’s nice to offer but I’d better not let him."
            b_ "He’s sure to expect something in return for this gift."
            b_ "And I’m not planning to give him anything."
            scene v12-140
            b "Thanks but, no thanks. I can pay for my own clothes, thank you very much!"





    scene black with Dissolve(3)
    centered "{size=+120}The gym{/size}" with Fade(0.5, 0.5, 5)
    play music2 "sfx/gym.mp3"
    if banurefusesinstructorshelp == True:
        play music "audio/kometaback.mp3"

        scene v12-143 with Fade(0.5, 0.5, 5)
        "Banu is all by herself at the gym this time. "
        "Hicran has bailed out at the last minute, because she had to take care of one of her usual errands. "
        "“Is she meeting her lover?” Banu muses. In any case, Banu is giving it her all under the watchful eye of her trainer."
        scene v12-144
        ins "Now it’s time to do some lunges!"
        b "What’s this exercise for?"
        ins "Mostly your leg muscles, especially your quads. But you’ll also be working your core."
        b "What’s that?"
        ins "The muscles around your butt, hips and your lower abs."
        b "Alright, coach!"
        scene v12-145
        ins "Push your weight on one leg, bending it in front of you. "
        ins "Keep the other leg straight, and your arms bent in front of you, without clasping your hands together. "
        scene v12-146
        b "Like this?"
        ins "That’s good! Don’t clasp your hands together!"
        ins "Now the other leg!"
        b "Grunt!"
        ins "Doing great!"
        ins "Keep going!"
        scene v12-149
        ins "Right! Let’s move forward!"
        stop music

    if banurefusesinstructorshelp == False:
        play music "audio/kometaback.mp3"

        scene v12-143 with Fade(0.5, 0.5, 5)
        "Banu is all by herself at the gym this time. "
        "Hicran has bailed out at the last minute, because she had to take care of one of her usual errands. "
        "“Is she meeting her lover?” Banu muses. In any case, Banu is giving it her all under the watchful eye of her trainer."
        scene v12-144
        ins "Now it’s time to do some lunges!"
        b "What’s this exercise for?"
        ins "Mostly your leg muscles, especially your quads. But you’ll also be working your core."
        b "What’s that?"
        ins "The muscles around your butt, hips and your lower abs."
        b "Alright, coach!"
        scene v12-145
        ins "Push your weight on one leg, bending it in front of you. "
        ins "Keep the other leg straight, and your arms bent in front of you, without clasping your hands together. "
        scene v12-146
        b "Like this?"
        ins "That’s good! Don’t clasp your hands together!"
        ins "Now the other leg!"
        b "Grunt!"
        scene v12-147
        ins "You need to keep your back straight!"

        scene v12-148
        stop music
        b_ "Oh my!"
        b_ "He’s touching me again!"
        ins "Try not to arch your back!"
        ins "Keep it straight, I said!"
        b_ "Mhh!"
        b_ "His hands are so warm! "
        ins "Doing great!"
        ins "Keep going!"
        scene v12-149
        ins "Right! Let’s move forward!"


    menu:
        "Chat up the instructor":
            $ renpy.block_rollback()
            $ banubad += 1
            $ chatuptheinstructor = True
            scene v12-149
            play music "audio/sidesex.mp3"
            b_ "Enough working out!"
            b_ "I’m exhausted!"
            scene v12-150
            b "So, how long have you been a trainer?"
            ins "About 3 years!"
            ins "But I’ve only worked here for six months."
            scene v12-151
            b "You have an amazing body!"
            b "How many days a week do you train?"
            scene v12-152
            ins "Every day!"
            ins "Need to work hard to keep this shape!"
            b "Oh wow!"
            b "I guess the hard work really pays off!"
            stop music
        "Keep working out":




            $ renpy.block_rollback()
            $ chatuptheinstructor = False
            scene v12-149
            b_ "I’m really tired and sore!"
            b_ "But I need to push harder if I wanna stay beautiful!"
            b "What’s next, coach?"
            ins "Time to work on your suppleness now!"
            scene v12-153
            ins "Stand up straight and spread your legs out, feet pointing forward."

            ins "Then bend forward and try to close your hands around one ankle."
            scene v12-154
            ins "Rotate your feet while you do it!"
            ins "And keep your back straight!"
            b "You mean this?"
            ins "You got it!"
            ins "That looks good!"
            ins "I mean, good pose!"
            b "Thanks, coach!"


    stop music2       

    scene black with Dissolve(3)
    centered "{size=+120}Hicran's place{/size}" with Fade(0.5, 0.5, 5)
    play music "audio/sensualsex.mp3"
    scene v12-155 with irisin
    "Banu is spending time with Hicran again. "
    "They have finished their workout at the gym and the green-eyed beauty has invited Banu to shower and then use the sauna at her luxury house."
    scene v12-159
    "They are wearing matching short silk robes and they both look fantastic in them..."
    "...the shiny material complementing their complexions and their sweaty skin."
    "Banu’s robe is a pretty orange, while Hicran’s is an alluring azure."
    scene v12-157
    b "Now this is what I call living!"
    scene v12-158
    hic "Enjoy sweetie!"
    hic "Nothing beats a sauna after sweating at the gym."
    scene v12-156
    b "I guess you did sweat some."
    b "When you weren’t busy flirting with the trainer!"
    b "Giggle!"
    scene v12-158
    hic "He’s dreamy, isn’t he? All those muscles on that young body!"
    hic "Mhh!"
    scene v12-159
    b "You’re married, Hicran!"
    b "Or have you forgotten?"
    scene v12-158
    hic "Don’t be a prude, Banu!"
    hic "Tell me you’ve never fantasized about other men, if you dare!"
    stop music
    menu:
        "Banu admits it":
            $ renpy.block_rollback()
            $ banubad += 1
            $ banuadmitsit = True


            scene v12-159
            b_ "She’s my friend."
            b_ "I guess I can open up!"
            b "Weeeell …"
            hic "Aha! I knew it!"
            hic "I bet you’ve even done more than fantasizing!"
            if banuturansexfirsttime == False:
                if followpolad == False:
                    b "Hicran! No!"
                    b "I’m married!"
                    b "Fantasy is one thing, but actually cheating … No!"
                    scene v12-158
                    hic "Alright, alright!"
                    hic "Don’t get your panties in a bunch!"
                    hic "I was just asking!"
                    b "Humph!"
                if followpolad == True:
                    b "Weeeell …"
                    b "I have to admit that it’s happened!"
                    b "But it was a mistake."
                    b "I didn’t go looking for it!"
                    b "I’m not a slut!"
                    scene v12-158
                    hic "Alright, alright!"
                    hic "Don’t get your panties in a bunch!"
                    hic "I was just asking! I know you’re not a slut!"
                    b "Humph!"




            if banuturansexfirsttime == True:
                b "Weeeell …"
                b "I have to admit that it’s happened!"
                b "But it was a mistake."
                b "I didn’t go looking for it!"
                b "I’m not a slut!"
                scene v12-158
                hic "Alright, alright!"
                hic "Don’t get your panties in a bunch!"
                hic "I was just asking! I know you’re not a slut!"
                b "Humph!"
        "Banu denies it":









            $ renpy.block_rollback()
            $ banuadmitsit = False
            scene v12-159
            b_ "Even if she’s my friend …"
            b_ "My fantasies are just mine!"
            b "I just don’t go there."
            b "I try to stay faithful even with my thoughts!"
            hic "Bo-ring!"
            hic "And I don’t believe you anyway!"
            hic "Giggle!"


    scene v12-158
    hic "And what about your husband?"
    hic "Is he good in bed? Is he big down there?"
    menu:
        "Banu is happy with Kamil":
            $ renpy.block_rollback()
            $ banu_kamil += 1
            $ banuishappywithkamil = True
            scene v12-158
            b "You’re impossible!"
            b "Yes, thank you very much!"
            b "Kamil makes me happy in bed!"
            b "And he’s big enough!"
        "Banu is not happy with Kamil":




            $ renpy.block_rollback()

            $ banuishappywithkamil = False
            scene v12-159
            b "You’re impossible!"
            b "But, honestly, Kamil isn’t all that!"
            b "I wish he would satisfy me more."
            b "And it wouldn’t hurt if his dick were bigger!"
            b "Giggle!"


    scene v12-158
    "This non-stop banter about sex has gotten Hicran all worked up. "
    "Add to that their matching outfits, and how hot Banu is, and now she’s hankerin’ for some of her friend’s honey. "
    scene v12-160
    hic "What about girls?"
    hic "Have you ever fantasized about another girl?"
    menu:
        "Banu refuses her flirting":
            $ renpy.block_rollback()
            $ banuacceptsherflirting = False
            scene v12-161
            b "You know!"
            b "I think we’ve spent long enough in the sauna."
            b "I’m getting all wrinkled, like a prune!"
        "Banu accepts her flirting":





            jump banu_hiran_kiss_1

    jump banu_hiran_kiss_continue


label banu_hiran_kiss_continue:

    scene v12-168
    play music "audio/tension.mp3"
    "Whilst still deep in though, she exits the sauna and is very surprised to see an older gentleman standing there."
    "She is startled and almost screams, before Hicran intervenes and clears her confusion."
    scene v12-170
    hic "Banu, meet my husband Mahmud!"
    hic "Dear, this if my friend Banu."
    scene v12-169
    "Banu awkwardly tries to cover up in front of this stranger, and thinks how much older than Hicran he must be. At least 30 years!"
    scene v12-171
    mah "Nice to meet you Banu!"
    mah "Oh, so you’re the friend Hicran is always talking about."
    scene v12-172
    b "Ni-Nice to meet you, Mahmud."
    b "I didn’t know Hicran always talked about me."
    stop music
    scene v12-173
    mah "Oh, but she does!"
    mah "I’m really pleased to finally meet you!"

    scene black with Dissolve(3)
    ""
    if banuturansexfirsttime == True:

        scene v12-174 with move
        "The time of the big decision has arrived eventually."
        "Banu is supposed to go and see Turan as he’s ordered her to do, after threatening to reveal their relationship to Kamil."
        scene v12-175
        "The woman is now faced with a dilemma."
        "Is she going to cave in to the dominant man’s blackmail?"
        "Or will she think he’s making an empty threat and ignore it?"
        scene v12-176
        play music "audio/tension.mp3"
        b_ "Why am I in this situation?"
        b_ "What should I do?"
        b_ "If I go, he will never stop."
        b_ "He will always ask for more!"
        b_ "But, if I don’t go, is he really going to talk to Kamil?"
        menu:
            "Reject the blackmail":
                $ renpy.block_rollback()
                $ banugoestoturanshouse = False
                stop music
                b_ "I don’t care!"
                b_ "He’s all talk!"
                b_ "He’s not gonna tell my husband."
                b_ "What’s he gonna say to him?"
                b_ "That he dosed me and raped me?"
                b_ "Fuck it!"


                scene black with dissolve
                ""
                scene v12-210 with zoomin
                "Banu has made her choice."
                "She thinks Turan is bluffing and he won’t actually follow through with his intimidation."
                "So she has stayed at home."
                "In the meantime, her husband has returned and there they are, chatting amiably in the living room."
                scene v12-211
                b "I’m so relieved the heatwave has finally let off!"
                k "I know, right?"
                k "And for you, especially. I know how much you dislike hot weather."
                scene v12-212
                b "That’s right, honey!"
                b "I just hope it doesn’t start raining for ages now …"
                k "Women!"
                k "Why do you always moan about everything?"
                b "Humpf! Shut up, you! (giggling)"

                play sound "voices/doorbell.mp3"
                scene v12-213
                stop sound
                "The doorbell rings, interrupting the playful banter between the couple. "
                scene v12-214
                "Banu gets up and heads for the front door."
                b "I’ll get it! Who will it be?"
                b_ "Wait! Don’t tell me …"
                scene v12-215 with hpunch
                "Her sudden suspicion is correct. She opens the door and it is none other than her boss Turan. "
                "Surprise is evident on her face, the feeling quickly replaced by anger."
                scene v12-216
                b "What in the devil are you doing here?"
                b "How dare you show up at my door?"
                t "Chill, baby!"
                t "I’m a man of my word. I keep my promises!"
                t "Unlike somebody else …"
                b "I’ve made no promises."
                scene v12-217
                b "I owe you nothing, you bastard!"
                t "That’s not how I remember it!"
                scene v12-218 with vpunch
                play music "audio/tension.mp3"
                "Kamil has heard the voice of a male guest alongside his wife’s, but he can’t make out who it is, so he goes investigating."
                scene v12-219
                k "Hey there!"
                t "Good evening!"
                b "Kamil, this is Turan, my manager at work."
                scene v12-220
                b "This is my husband Kamil."
                k "How you doing?"
                scene v12-221
                t "Nice to meet you."
                k "To what do we owe the pleasure of your visit?"
                t "Oh, I just came to ask about some worksheets. "
                t "I really need them for an important presentation tomorrow."
                t "Baun wasn’t answering my texts, so I had to come in person."
                scene v12-223
                b "Sorry, Turan. I don’t always keep my phone on me when I’m at home."
                t "But you promised you would send them when we talked today."
                t "You should follow my instructions more closely."
                scene v12-222
                k "Sweetie, it’s not like you to forget important work tasks."
                b "Well, I …"
                scene v12-224
                t "Think nothing of it Kamil."
                t "Banu is a great worker and I really like her."
                t "She knows how to do her job."
                scene v12-223
                t "Sometimes, she should listen to me more."
                t "I only tell her what to do for her own good …"
                stop music

                scene black with Dissolve(3)
                scene v12-177 with fade
                b_ "That guy is fucking crazy!"
                b_ "I wouldn’t put it past him to really talk to Kamil."
                b_ "Even if he didn’t believe him, how would that look?"
                b_ "I need to bite the bullet and submit for now."
                "Poor vulnerable Banu."
                "Banu whom everybody desires, everybody wants for themselves."
                "Every male and many females, too. They all crave her."
                "Banu, whose only fault is to be really sexy."
                scene v12-178
                "She is constantly exposed to temptation."
                "Does that make her a slut? Surely not!"
                "So why does she feel like one while she’s dressing to go and meet Turan?"
                "He’s making her! But why is she feeling so guilty about it?"

                scene black with dissolve
                ""
                scene v12-179 with pixellate
                t_ "There she is!"
                t_ "Can’t believe it actually worked!"
                t_ "Just a simple unlikely threat and she comes running to daddy!"
                t_ "I knew she was into it!"
                scene v12-180
                t "You’ve kept me waiting!"
                t "Make sure you come quickly next time."
                b "..."
                t "Just stand there!"
                t "Let me feel you."
                scene v12-181
                play music "audio/sidesex.mp3"
                t "Mhh, what a sexy round ass!"
                t "You’re always showing it off in those tight pants."
                scene v12-182
                t "And how’s my pussy?"
                t "I’m gonna use it again today!"
                scene v12-183
                "..."
                t "Get undressed now!"
                t "The headscarf too!"
                scene v12-184
                t "Put this blindfold on!"
                scene v12-185
                t "What the fuck Turan?"
                t "Relax! I don’t want to hurt you!"
                t "I’m not gonna do anything weird."
                b "Nothing weird!?"
                b "Everything is fucking weird about this!"
                b "Aren’t you ashamed of yourself?"
                scene v12-186
                t "Nope! Just horny!"
                t "Now put it on!"
                scene v12-187
                t "That’s a good girl!"
                t "Feel how hard you’ve made me already?"
                scene v12-188
                t "Touch my cock."
                scene v12-189
                t "What have we got here?"
                t "Mhh, sexy panties!"
                scene v12-190
                t "Let’s take everything off now!"
                "Turan makes short work of Banu’s clothes."
                "He’s anxious to unwrap the present that has delivered itself right to his doorstep. "
                "He’s already panting, anticipating what he’s going to do to her."
                scene v12-191 with fade
                stop music
                "He pushes her down on his bed and climbs between her legs, his erection rampant and rubbing the woman’s silky skin through his boxers."
                scene v12-192
                "He peppers her supple breasts with sensual kisses, quickly discovering how sensitive they are."
                "He’s holding her arms down by her wrists, adding to the sensation of helplessness given by the blindfold."
                scene v12-193
                "The young mother is moaning, unable to contain herself."
                "Right now, neither of them is thinking about the dom/sub aspect of their encounter."
                "Just a man and a woman, he gorging himself on the beauty of her goddess-like body..."
                "...she unable to feel anything but the hunger of the lover feeding from her body."
                scene v12-194 with hpunch
                "Turan’s kisses trail down ever lower, across Banu’s divinely curved stomach, through to her mons..."
                "...where he wastes no time and starts to devour her scented cunt."
                "To his surprise, she is moaning even more now..."
                "...and she clutches his head against her sex to increase the contact and enjoy his sucking even more."

                scene v12-197
                t_ "What a whore!"
                t_ "She likes having her pussy eaten."
                t_ "She’s mine now!"
                scene v12-198 with dissolve
                "The man increases the skillful rhythm of his pussy-eating and Banu starts thrashing on the bed and clutching the covers."
                scene v12-195
                "He knows she’s close to cumming already, so he grabs her legs behind her knees to improve the angle and finish her off."
                "Banu is helping the whole process by holding her own legs up. "
                "She isn’t thinking about anything."
                "She’s just about to explode and nothing can contaminate the perfect feeling she’s experiencing."


                scene v12-196
                "With Turan slurping noisily and concentrating on her clit, an overwhelming sensation envelops her. "
                "Colored lights start to flash through her brain and she contracts repeatedly, starting at her core and spreading in shockwaves to the rest of her body."
                "She hears someone screaming and wonders who for a millisecond, before realizing it’s her own screams of pleasure she’s hearing."
                scene v12-196 with hpunch
                b "Ahhhhhhhhh!"
                b "Ohhhhh! Ohh! Ohh! Ohh!"
                b "Fuuuuuuuuck!"
                b "Ohhhh my Goooooood!"
                b "Ahhhhhhhhh! Ahhhhhhhhh!"
                b "Mhhh!"
                scene v12-199 with fade
                "Banu slowly comes back to her senses. Obviously she’s ashamed at having orgasmed so hard just like that, a proper bitch in heat."
                "But she’s too weak physically and emotionally to really be able to decide what her attitude should be."
                "So she barely responds when Turan sits behind her on the bed and hugs her, his arm lightly holding her neck."
                "It’s when she hears a whirring sound that she has some sort of reaction."
                b "Hey! Wh-what’s that noise?"
                b "What are you going to do?"
                t "Shh! Relax!"
                t "I told you I’m not gonna hurt you."
                t "It’s a Hitachi magic wand!"
                b "What does it do?"
                t "Open your legs!"
                t "It does…"
                scene v12-200 with vpunch
                t "This!"
                "That’s when Turan applies the vibrator to Banu’s clit, still sensitive and lightly throbbing from her recent climax."
                "The sudden intense pleasure jolts her, and she’s off moaning again and thrashing around."
                scene v12-201
                b "Ohhh!"
                b "What are you doing to meeee?"
                b "Mhhh!"
                scene v12-202
                t "Feels good, huh?"
                t "You see, it’s the right choice to submit to me."
                t "Only I can make you feel like this!"
                "Banu is off to la-la-land and, in her vulnerable and highly-excited state, she’s actually considering the fact that his words make a bit of sense."
                scene v12-203
                play music "audio/tension.mp3"
                t "Bend over!"
                t "Show me that pussy!"
                scene v12-204
                t "Open your legs!"
                "Banu complies and Turan starts lightly caressing her pussy lips, gathering the copious moisture drenching the whole area."
                scene v12-205
                "He looks closely at Banu who, still blindfolded, is breathing heavily in anticipation."
                scene v12-206
                "But suddenly something out of left field takes place. "

                scene v12-207 with vpunch
                "Turan slowly pushes his middle finger inside Banu’s tight little asshole."
                b "Ugh! Hey!"
                scene v12-208 with fade
                b "What the fuck do you think you’re doing?"
                b "Are you out of your fucking mind!"
                stop music
                scene v12-209
                b "Oh my God!"
                b_ "This guy is completely nuts!"
                "She gets dressed in haste and leaves Turan’s house without uttering another word."
                "Inside her, a war is raging. "
                "Just when she was starting to feel a glimmer of acceptance for Turan..."
                "...after getting so much pleasure from him, he goes and does something so dirty!"
            "Accept the blackmail":






                $ renpy.block_rollback()
                $ banugoestoturanshouse = True
                $ banubad += 1
                b_ "That guy is fucking crazy!"
                b_ "I wouldn’t put it past him to really talk to Kamil."
                b_ "Even if he didn’t believe him, how would that look?"
                b_ "I need to bite the bullet and submit for now."

                scene v12-177 with fade
                "Poor vulnerable Banu."
                "Banu whom everybody desires, everybody wants for themselves."
                "Every male and many females, too. They all crave her."
                "Banu, whose only fault is to be really sexy."
                scene v12-178
                "She is constantly exposed to temptation."
                "Does that make her a slut? Surely not!"
                "So why does she feel like one while she’s dressing to go and meet Turan?"
                "He’s making her! But why is she feeling so guilty about it?"

                scene black with dissolve
                ""
                scene v12-179 with pixellate
                t_ "There she is!"
                t_ "Can’t believe it actually worked!"
                t_ "Just a simple unlikely threat and she comes running to daddy!"
                t_ "I knew she was into it!"
                scene v12-180
                t "You’ve kept me waiting!"
                t "Make sure you come quickly next time."
                b "..."
                t "Just stand there!"
                t "Let me feel you."
                scene v12-181
                play music "audio/sidesex.mp3"
                t "Mhh, what a sexy round ass!"
                t "You’re always showing it off in those tight pants."
                scene v12-182
                t "And how’s my pussy?"
                t "I’m gonna use it again today!"
                scene v12-183
                "..."
                t "Get undressed now!"
                t "The headscarf too!"
                scene v12-184
                t "Put this blindfold on!"
                scene v12-185
                t "What the fuck Turan?"
                t "Relax! I don’t want to hurt you!"
                t "I’m not gonna do anything weird."
                b "Nothing weird!?"
                b "Everything is fucking weird about this!"
                b "Aren’t you ashamed of yourself?"
                scene v12-186
                jump turan_eats_banu
    else:
        jump continueaftermeetingmahmud




    "So she barely responds when Turan sits behind her on the bed and hugs her, his arm lightly holding her neck."
    "It’s when she hears a whirring sound that she has some sort of reaction."
    b "Hey! Wh-what’s that noise?"
    b "What are you going to do?"
    t "Shh! Relax!"
    t "I told you I’m not gonna hurt you."
    t "It’s a Hitachi magic wand!"
    b "What does it do?"
    t "Open your legs!"
    t "It does…"
    scene v12-200 with vpunch
    t "This!"
    "That’s when Turan applies the vibrator to Banu’s clit, still sensitive and lightly throbbing from her recent climax."
    "The sudden intense pleasure jolts her, and she’s off moaning again and thrashing around."
    scene v12-201
    b "Ohhh!"
    b "What are you doing to meeee?"
    b "Mhhh!"
    scene v12-202
    t "Feels good, huh?"
    t "You see, it’s the right choice to submit to me."
    t "Only I can make you feel like this!"
    "Banu is off to la-la-land and, in her vulnerable and highly-excited state, she’s actually considering the fact that his words make a bit of sense."
    scene v12-203
    play music "audio/tension.mp3"
    t "Bend over!"
    t "Show me that pussy!"
    scene v12-204
    t "Open your legs!"
    "Banu complies and Turan starts lightly caressing her pussy lips, gathering the copious moisture drenching the whole area."
    scene v12-205
    "He looks closely at Banu who, still blindfolded, is breathing heavily in anticipation."
    scene v12-206
    "But suddenly something out of left field takes place. "

    scene v12-207 with vpunch
    "Turan slowly pushes his middle finger inside Banu’s tight little asshole."
    b "Ugh! Hey!"
    scene v12-208 with fade
    b "What the fuck do you think you’re doing?"
    b "Are you out of your fucking mind!"
    scene v12-209
    stop music
    b "Oh my God!"
    b_ "This guy is completely nuts!"
    "She gets dressed in haste and leaves Turan’s house without uttering another word."
    "Inside her, a war is raging. "
    "Just when she was starting to feel a glimmer of acceptance for Turan..."
    "...after getting so much pleasure from him, he goes and does something so dirty!"

label turan_eats_banu_continue:
    scene black with Dissolve(3)
    ""

label continueaftermeetingmahmud:

    centered "{size=+120}After work{/size}" with Fade(0.5, 0.5, 5)
    scene v12-225 with blinds
    "Banu is preening in front of the mirror. She has caught her own image while passing by and now she’s admiring herself."
    scene v12-226
    b_ "Look at that sexy girl!"
    b_ "I look good in my underwear!"
    scene v12-227
    b_ "Maybe I look even better without it."
    b_ "My hips are so womanly!"
    b_ "I’m slim but with all the right curves."
    scene v12-228
    "She is really engrossed in the appreciation of her smoking hot body, and doesn’t realize she has attracted an audience."
    "Ruslan is standing there in awe of her stepmother’s insanely beautiful body."
    r_ "Fuck me!"
    r_ "Look at that!"
    r_ "She’s so fucking hot!"
    scene v12-229
    r_ "She’s as sexy as her daughter."
    r_ "But with that milf attitude..."
    r_ "...she is in a whole different league."
    scene v12-230 with hpunch
    "So taken is Ruslan with the bronze-skinned milf’s perky figure, that he gets careless, and Banu notices him through the open door."
    menu:
        "Banu gets angry":
            $ renpy.block_rollback()
            $ banuteasesruslan = False
            scene v12-231
            b_ "This boy is impossible!"
            b "What the fuck do you think you’re doing?"
            scene v12-232
            b "Spying on your stepmother!"
            b "You really are a fucking pervert!"
            r "I …"
            b "Get out of my sight right now!"
        "Banu teases him":




            $ renpy.block_rollback()
            $ banubad += 1
            $ banuteasesruslan = True
            jump banu_teases_ruslan



label banu_teases_ruslan_continue:
    scene black with Dissolve(3)
    scene v12-238 with squares
    "Banu has got a taste for retail therapy lately. She still hasn’t had enough after her recent shopping trip, when she has met Murat."
    "Right now, she’s checking out some bargain designer clothes on Aliexpress, while Kamil is sleeping peacefully right next to her."
    b_ "Ohh! I can’t believe the prices here!"
    b_ "Will they really be genuine brands or cheap knockoffs?"
    b_ "One way or the other, I’ll have to try to buy something just once."
    "But right when she’s about to actually make a purchase, her phone beeps."
    scene v12-239
    b_ "Who’s this?"
    b_ "Ah, it’s Murat!"
    mur_ "{color=#E33F31}Sleeping yet, sexy lady? {/color}"
    menu:
        "Banu rejects the flirting":
            $ renpy.block_rollback()
            $ banuflirtsback = False
            b_ "Not him as well!"
            b_ "What do they all want from me?"
            b_ "{color=#E33F31}Hey! Be respectful!{/color}"
            b_ "{color=#E33F31}I’m a married woman!{/color}"
            b_ "{color=#E33F31}What do you want?{/color}"
            scene v12-241
            play music "audio/tension.mp3"
            mur_ "{color=#E33F31}Ok ok! Sorry! I really need to see you.{/color}"
            mur_ "{color=#E33F31}I have to talk to you about your husband!{/color}"
            mur_ "{color=#E33F31}It’s important.{/color}"
            b_ "{color=#E33F31}What?! Is something wrong with him?{/color}"
            mur_ "{color=#E33F31}No! Nothing like that!{/color}"
            mur_ "{color=#E33F31}Let’s meet soon and talk.{/color}"
            stop music
        "Banu flirts back":

            $ renpy.block_rollback()
            $ banuflirtsback = True
            $ banubad += 1
            scene v12-240
            b_ "Ha! Let’s play a little!"
            scene v12-242
            b_ "{color=#E33F31}Oh yeah?{/color}"
            b_ "{color=#E33F31}And what’s sexy about me?{/color}"
            mur_ "{color=#E33F31}Just about everything, but especially your lips and your ass!{/color}"
            mur_ "{color=#E33F31}Mhh! You can’t imagine the things I’d do to you!{/color}"
            b_ "{color=#E33F31}Alright, that’s enough.{/color}"
            scene v12-241
            play music "audio/sidesex.mp3"
            mur_ "{color=#E33F31}Ok ok! I really need to see you.{/color}"
            mur_ "{color=#E33F31}I have to talk to you about your husband!{/color}"
            mur_ "{color=#E33F31}It’s important.{/color}"
            b_ "{color=#E33F31}What?! Is something wrong with him?{/color}"
            mur_ "{color=#E33F31}No! Nothing like that!{/color}"
            mur_ "{color=#E33F31}Let’s meet soon and talk.{/color}"
            stop music














    scene black with Dissolve(3)
    centered "{size=+120}Murat{/size}" with Fade(0.5, 0.5, 5)
    scene v13-1 with squares



    $ banuacceptsdrinkwithmurat = False
    $ banutakethebet = False
    $ banutakethebetfuckmurat = False






    "Banu is at Murat’s house. "
    "The possibility of news regarding Kamil has her worried and a tad bit intrigued with curiosity. "
    "What is more, Murat is definitely an interesting character, and he knows how to treat the ladies, so it wasn’t extremely hard to convince Banu."
    scene v13-3
    b "So, what’s this big piece of news you have about my husband?"



    scene v13-2
    mur "What’s the hurry? You just got here!"
    mur "Make yourself at home. Have a seat! "

    scene v13-3
    b "Listen, I’m anxious to know what you have to tell me about Kamil."
    b "So, spit it out!"

    scene v13-4
    mur "Have a drink with me!"
    mur "This is the finest single malt you’ll ever taste."
    mur "I get it directly from Scotland."

    scene v13-7
    b "That’s not why I came here!"

    scene v13-4
    play music "audio/tension.mp3"
    mur "Come on!"
    mur "Or can you not handle even a small sip?"

    menu:
        "Refuse the drink":
            $ renpy.block_rollback()
            $ banuacceptsdrinkwithmurat = False
            scene v13-6
            b_ "I shouldn’t have come here!"
            b_ "What was I expecting him to tell me?"
            stop music




            scene v13-7
            b "Alright!"
            b "I knew this was a bad idea."
            b "I’m outta here!"



            scene v13-8 with dissolve
            mur "Hey, wait!"
            mur "Listen!"
            mur "Your husband is cheating on you!"
            mur "That’s what I wanted to tell you!"


            scene v13-9
            "The woman stops dead in her tracks, her blood suddenly chilling."
            "She realizes just then that she really cares a lot about Kamil."
            "But then skepticism sets in."
            "She knows it can’t be true."
            b "What!?"
            b "You’re full of shit!"


            scene v13-10
            mur "No! It’s true."
            mur "And I can prove it!"


            scene v13-12
            mur "Wanna bet?"


            scene v13-11
            b "Bet?"
            b "What kind of bet?"


            scene v13-12
            mur "If I’m lying, you win, and I won’t bother you again!"
            mur "But if I’m telling the truth, you’ll give me a kiss."


            scene v13-11
            play music "audio/tension.mp3"
            b "What?"
            b "You are not serious, aren't you?"
            mur "..."
            menu:
                "Don't bet":
                    $ renpy.block_rollback()
                    $ banutakethebet = False
                    scene v13-14
                    stop music
                    b "I don’t wanna play any game!"
                    b "I’m married and I don’t go around kissing random men!"
                    b "Just prove me that he’s cheating otherwise I’m gone!"
                    scene v13-15
                    mur "Alright, you win."
                    mur "Here, look!"
                    scene v13-16
                    mur "That’s him!"
                    mur "She’s his lover!"
                    scene v13-17 with hpunch
                    b "Give it here!"
                    b_ "Oh my God! It’s really him!"
                    b "The two-timing bastard!"
                    b "I can’t believe it!"
                    b "After all I’ve done for him!"
                    scene v13-18
                    "You see, I was telling you the truth! "
                    b "..."
                "Take the bet":





                    $ renpy.block_rollback()
                    $ banutakethebet = True
                    $ banubad += 1
                    scene v13-13
                    b "Why not!"
                    b "I know you’re bluffing."
                    b "I don’t believe a word you’re saying."
                    b "It’s just a ruse to get me to come to your place."
                    scene v13-15
                    mur "Ah really?"
                    mur "Well, then!"
                    mur "Have a look at this!"
                    scene v13-16
                    mur "That’s him!"
                    mur "With his lover! "
                    scene v13-17 with hpunch
                    b "Give it here!"
                    b_ "Oh my God! It’s really him!"
                    b "The two-timing bastard!"
                    b "I can’t believe it!"
                    b "After all I’ve done for him!"
                    scene v13-18
                    "You see, I was telling you the truth! "
                    b "..."

                    scene v13-19
                    mur "I believe there’s something you owe me …"
                    b_ "Oh shit! This can't be true!"
                    b "Well..."
                    b "I..."
                    mur "Shh! Come here …"
                    scene v13-20
                    play music "audio/sidesex.mp3"
                    "With that, Murat holds Banu tight and kisses her luscious lips."
                    b_ "This is so wrong but..."
                    scene v13-21
                    b_ "The bet is bet. Kamil deserves this one after all."
                    scene v13-22
                    "The woman stands rigid at first, but Murat’s insistent massage of one of her rounded butt cheeks soon has her reciprocating the smooch."
                    scene v13-23
                    "The sly man senses that her current target is giving in and sits on the sofa..."
                    scene v13-24
                    "...pulling her down on top of him, continuously massaging her ass, while the kiss intensifies and the grinding heats up Banu."
                    scene v13-25
                    "Murat is really enamored with Banu’s scrumptious behind and, with little effort, has her lie on the couch face down..."
                    scene v13-26
                    "...so that he can properly grind his rigid erection in the valley of her cheeks."
                    scene v13-27
                    mur "Mhh, your ass is just perfect!"
                    mur "Can you feel what you do to me?"
                    scene v13-28
                    "But Banu does not respond. She has given in fairly easily, but she can feel the conflict inside her head."
                    b_ "What’s happening to me?"
                    b_ "I’m letting this guy manhandle me just like that."
                    b_ "Am I really becoming this type of a ... woman?"
                    scene v13-27
                    "Murat is on fire and his insistent pushing has helped raise Banu’s dress so that her panties are uncovered."
                    scene v13-28
                    "Wary of the fact she might come to her senses soon, he starts licking and nibbling her neck and her cheeks, so that she will stay horny and subdued."
                    scene v13-29
                    "Emboldened by her submissiveness, he turns her around, wanting her to feel his cock directly on her mound."
                    "But that’s when Banu gets her brain back and puts a stop to the proceedings."
                    stop music
                    scene v13-30
                    "She pushes Murat away and stands up, smoothing her dress down, rather embarrassed."
                    scene v13-31
                    b "That’s enough!"
                    b "You’ve had your kiss!"
                    mur "Aww! You’re no fun!"
                    mur "Didn’t you like it?"
                    b "That’s not the point, and you know it!"
        "Accept the drink":









            $ renpy.block_rollback()
            $ banubad += 1
            $ banuacceptsdrinkwithmurat = True
            scene v13-32
            b_ "I've never tasted alchohol before...but.."
            b_ "I’m on edge. It may calm me down. Anyway just a sip of drink won't hurt."

            scene v13-36
            "Murat pours her a generous serving of the strong liquor, and Banu sits down next to him."
            scene v13-34
            b "Let’s see if that scotch is as good as you said."
            scene v13-35
            "The whisky is indeed really fine, and the strong musky flavor entices Banu to sip it continuously..."
            "...while Murat chats her up with trivialities, to keep her mind off the fact that the drink is really strong."
            scene v13-33
            "The minute woman isn’t really used to strong spirits, and soon starts to feel no pain."
            scene v13-39 with fade
            "She becomes quite giggly and begins to care a bit less about sitting ladylike."
            scene v13-40
            "Murat, the skulker, can hold his drink and decides that it’s time to drop the bomb."
            scene v13-41
            mur "Anyway, I really wanted to tell you something important."
            scene v13-37
            b "Ah, that’s right."
            b "What is it?"
            scene v13-41
            mur "Your husband is cheating on you …"
            "Banu, in her slightly drunk state, is a bit slow to react, and her first thought is that he’s kidding."
            scene v13-38
            b "Yeah, right!"
            b "This is another one of your games."
            b "Get out of here!"
            mur "No! It’s true"
            scene v13-41
            mur "And I can prove it!"
            mur "Wanna bet?"
            scene v13-43
            b "Bet?"
            b "What kind of bet?"
            scene v13-41
            mur "If I’m lying, you win, and I won’t bother you again!"
            mur "But if I’m telling the truth, you’ll give me a kiss."
            menu:
                "Accept the bet":
                    $ renpy.block_rollback()
                    $ banubad += 3
                    $ banutakethebetfuckmurat = True
                    scene v13-44
                    b "Why not!"
                    b "I know you’re bluffing."
                    b "You’re a real charmer …"
                    b "Hic!"
                    b "You just wanted to get me to your flat again."
                    b "Hic!"
                    scene v13-45
                    mur "Ah really?"
                    mur "Well, then!"
                    mur "Have a look at this!"
                    mur "That’s him!"
                    mur "With his lover!"
                    scene v13-46


                    "The sight of Kamil’s pictures with another woman is a jolt of adrenaline that shakes Banu out of her stupor, at least a little bit."
                    b_ "Oh my God! It’s really him!"
                    b "The two-timing bastard!"
                    scene v13-47 with fade
                    b "I can’t believe it!"
                    b "After all I’ve done for him!"
                    mur "You see, I was telling you the truth!"
                    scene v13-48
                    play music "audio/arab.mp3"
                    mur "I believe there’s something you owe me …"
                    jump murat_fucks_banu
                "Don't bet":








                    $ renpy.block_rollback()
                    $ banutakethebetfuckmurat = False
                    scene v13-42
                    stop music
                    b "I don’t wanna play!"
                    b "I’m married! You know I can’t kiss you …"
                    b "Please show me your proof."
                    scene v13-45
                    mur "Alright, if you ask me like that!"
                    mur "Here, look!"
                    scene v13-46
                    mur "That’s him!"
                    mur "She’s his lover!"
                    "The sight of Kamil’s pictures with another woman is a jolt of adrenaline that shakes Banu out of her stupor, at least a little bit."
                    b_ "Oh my God! It’s really him!"
                    b "The two-timing bastard!"
                    scene v13-47 with fade
                    b "I can’t believe it!"
                    b "After all I’ve done for him!"
                    mur "You see, I was telling you the truth!"

            jump murat_fucks_banu_continue












label murat_fucks_banu_continue:
    scene black with Dissolve(3)
    centered "{size=+120}Home{/size}" with Fade(0.5, 0.5, 5)

    scene v13-69 with blinds
    play music "audio/intro.mp3"
    "Poor Banu has a lot on her plate right now."
    "She has been easily lured to the flat of a man she barely knows. Anything could have happened to her."
    "There, she has learned from him that, apparently, her husband is cheating on her."




    scene v13-70
    "She’s pacing around the house listlessly, until she somehow ends up on her marital bed and starts crying her heart out."

    scene v13-71
    b_ "I can’t believe that piece of shit would do that to me! "
    b_ "Right under my fucking nose!"
    b_ "He plays the part of the family man to perfection!"



    scene v13-72
    b_ "And why the fuck did I go to Murat’s house? I’m a married woman!"
    b_ "Decent women don’t go visiting strange men’s houses!"
    if banutakethebetfuckmurat == True:
        b_ "I let him do what he wanted with me!"
        b_ "Am I really better than Kamil?"
        b_ "How could I let Murat convince me to drink?"
        b_ "I should have known better!"
        b_ "I can’t hold alcohol, and I know that!"

    scene v13-73
    "While Banu is berating herself for her bad choices and for being cheated on by her husband..."
    "...the object of her discontent enters the flat and is taken aback by the miserable sigh in front of him."


    scene v13-74
    stop music
    k "My love, what happened?"
    k "Why are you crying?"
    b "Can’t you imagine why I’m crying?"
    k "No! I don’t know?"
    k "Has anything happened to Leyla?"

    scene v13-75
    b "What!? No!"
    b "I know you’re seeing another woman!"
    k "What!? Me?"
    k "Where the hell is that coming from?"

    scene v13-76
    b "Yes, you are cheating on me!"
    b "I know it!"
    scene v13-77
    k "Of course I’m not cheating on you?"
    k "Who told you that?"

    scene v13-76
    b "How can you deny it?"
    b "I’ve seen pictures!"
    k "I don’t know what you’ve seen."
    k "But I know it can’t be real!"

    scene v13-78
    b "Oh really?"
    b "Pictures aren’t real?"
    k "I don’t know! I’ve never cheated on you."
    k "Please believe me!"
    k "Someone wants to see us argue."

    scene v13-79
    b "But I’ve seen it with my eyes."
    k "You have to trust me."
    k "I’m sure that whatever you’ve seen can be explained somehow."


    scene v13-80
    b "No! I don’t trust you!"
    b "You’ve cheated on me!"
    k "Banu …"
    b "You are a bastard!"
    scene v13-81
    b "You don’t know how lucky you are to have me as a wife!"
    b "You don’t know how to treat me right!"

    scene v13-82
    k "You’re going overboard now!"

    scene v13-81
    b "You are a wimp!"
    b "You’ve never understood me!"
    b "I should have been the one cheating on you!"
    k "Banu..."
    b "Yes! You don’t know how to make a woman happy!"

    scene v13-82
    k "I’ve always looked after the family!"
    scene v13-81
    b "It’s not enough!"
    b "A woman wants to feel like a princess!"
    b "Showered with attention and gifts!"

    scene v13-82
    k "I’ve tried my best baby."

    scene v13-83
    play music "audio/tension.mp3"
    b "Don’t call me baby!"
    b "You’re not much of a man!"
    k "Careful now!"
    b "You can’t even satisfy me in bed!"
    b "I should have been the one to find another man!"
    b "Not you cheating on me!"
    k "Stop saying that right now!"
    b "Or else what?"
    k "I’m warning you!"
    b "You’re a wuss!"
    "But all this berating is just too much for Kamil."
    "The man just can’t take it anymore, also because some of the things Banu has been saying ring true."


    scene v13-84 with hpunch
    "He just loses it and soundly slaps his wife’s cheek."


    scene v13-85
    stop music
    k "I told you to shut up!"


    menu:
        "Banu leaves" if banu_kamil <= 15:
            $ renpy.block_rollback()
            scene v13-87
            b "Y-you’ve hit me!"
            k "Oh, shit! I’m so sorry!"
            k "I didn’t mean to."
            k "I-it’s just happened!"
            k "You’ve told me all those nasty things and I …"
            k "Please forgive me!"
            scene v13-88
            b "No! Never!"
            b "I’m leaving you!"
            b "I don’t want to see you ever again!"



            if banubad >= 17:
                jump breakupcorrupted
            else:

                jump breakuppure






        "Banu calms down" if banu_kamil >= 16:
            $ renpy.block_rollback()
            scene v13-86
            b "Y-you’ve hit me!"
            k "Oh, shit! I’m so sorry!"
            k "I didn’t mean to."
            k "I-it’s just happened!"
            k "You’ve told me all those nasty things and I …"
            k "Please forgive me!"
            b "Maybe I said too much...but..."
            k "I know. Please forgive me."
            k "Let’s talk about it."




            if banubad >= 17:
                jump staywithkamilcorrupted
            else:

                jump staywithkamilpure









label turan_eats_banu:
    t "Nope! Just horny!"
    t "Now put it on!"
    scene v12-187
    t "That’s a good girl!"
    t "Feel how hard you’ve made me already?"
    scene v12-188
    t "Touch my cock."
    scene v12-189
    t "What have we got here?"
    t "Mhh, sexy panties!"
    scene v12-190
    t "Let’s take everything off now!"
    "Turan makes short work of Banu’s clothes."
    "He’s anxious to unwrap the present that has delivered itself right to his doorstep. "
    "He’s already panting, anticipating what he’s going to do to her."
    scene v12-191 with fade
    stop music
    "He pushes her down on his bed and climbs between her legs, his erection rampant and rubbing the woman’s silky skin through his boxers."
    scene v12-192
    "He peppers her supple breasts with sensual kisses, quickly discovering how sensitive they are."
    "He’s holding her arms down by her wrists, adding to the sensation of helplessness given by the blindfold."
    scene v12-193
    "The young mother is moaning, unable to contain herself."
    "Right now, neither of them is thinking about the dom/sub aspect of their encounter."
    "Just a man and a woman, he gorging himself on the beauty of her goddess-like body..."
    "...she unable to feel anything but the hunger of the lover feeding from her body."
    scene v12-194 with hpunch
    "Turan’s kisses trail down ever lower, across Banu’s divinely curved stomach, through to her mons..."
    "...where he wastes no time and starts to devour her scented cunt."
    "To his surprise, she is moaning even more now..."
    "...and she clutches his head against her sex to increase the contact and enjoy his sucking even more."

    scene v12-197
    t_ "What a whore!"
    t_ "She likes having her pussy eaten."
    t_ "She’s mine now!"
    scene v12-198 with dissolve
    "The man increases the skillful rhythm of his pussy-eating and Banu starts thrashing on the bed and clutching the covers."
    scene v12-195
    "He knows she’s close to cumming already, so he grabs her legs behind her knees to improve the angle and finish her off."
    "Banu is helping the whole process by holding her own legs up. "
    "She isn’t thinking about anything."
    "She’s just about to explode and nothing can contaminate the perfect feeling she’s experiencing."


    scene v12-196
    "With Turan slurping noisily and concentrating on her clit, an overwhelming sensation envelops her. "
    "Colored lights start to flash through her brain and she contracts repeatedly, starting at her core and spreading in shockwaves to the rest of her body."
    "She hears someone screaming and wonders who for a millisecond, before realizing it’s her own screams of pleasure she’s hearing."
    scene v12-196 with hpunch
    b "Ahhhhhhhhh!"
    b "Ohhhhh! Ohh! Ohh! Ohh!"
    b "Fuuuuuuuuck!"
    b "Ohhhh my Goooooood!"
    b "Ahhhhhhhhh! Ahhhhhhhhh!"
    b "Mhhh!"
    scene v12-199 with fade
    "Banu slowly comes back to her senses. Obviously she’s ashamed at having orgasmed so hard just like that, a proper bitch in heat."
    "But she’s too weak physically and emotionally to really be able to decide what her attitude should be."

    "So she barely responds when Turan sits behind her on the bed and hugs her, his arm lightly holding her neck."
    "It’s when she hears a whirring sound that she has some sort of reaction."
    b "Hey! Wh-what’s that noise?"
    b "What are you going to do?"
    t "Shh! Relax!"
    t "I told you I’m not gonna hurt you."
    t "It’s a Hitachi magic wand!"
    b "What does it do?"
    t "Open your legs!"
    t "It does…"
    scene v12-200 with vpunch
    t "This!"
    "That’s when Turan applies the vibrator to Banu’s clit, still sensitive and lightly throbbing from her recent climax."
    "The sudden intense pleasure jolts her, and she’s off moaning again and thrashing around."
    scene v12-201
    b "Ohhh!"
    b "What are you doing to meeee?"
    b "Mhhh!"
    scene v12-202
    t "Feels good, huh?"
    t "You see, it’s the right choice to submit to me."
    t "Only I can make you feel like this!"
    "Banu is off to la-la-land and, in her vulnerable and highly-excited state, she’s actually considering the fact that his words make a bit of sense."
    scene v12-203
    play music "audio/tension.mp3"
    t "Bend over!"
    t "Show me that pussy!"
    scene v12-204
    t "Open your legs!"
    "Banu complies and Turan starts lightly caressing her pussy lips, gathering the copious moisture drenching the whole area."
    scene v12-205
    "He looks closely at Banu who, still blindfolded, is breathing heavily in anticipation."
    scene v12-206
    "But suddenly something out of left field takes place. "

    scene v12-207 with vpunch
    "Turan slowly pushes his middle finger inside Banu’s tight little asshole."
    b "Ugh! Hey!"
    scene v12-208 with fade
    b "What the fuck do you think you’re doing?"
    b "Are you out of your fucking mind!"
    scene v12-209
    stop music
    b "Oh my God!"
    b_ "This guy is completely nuts!"
    "She gets dressed in haste and leaves Turan’s house without uttering another word."
    "Inside her, a war is raging. "
    "Just when she was starting to feel a glimmer of acceptance for Turan..."
    "...after getting so much pleasure from him, he goes and does something so dirty!"







    $ renpy.end_replay()
    $ persistent.turan_eats_banu_unlocked = True
    jump turan_eats_banu_continue


label banu_teases_ruslan:
    play music "audio/sexy.mp3"
    scene v12-233
    b_ "The nerve on this horny little shit!"
    b_ "Let’s give him a little show!"
    scene v12-234
    b "What are you looking at, you pervert?"
    b "My daughter wasn’t enough?"
    b "You want the mother too, now?"
    b "You’re never gonna have a piece of this!"
    scene v12-235
    r "I..."
    scene v12-236
    b "Be a good little boy from now on..."
    b "...and maybe you’ll get another show."
    scene v12-237
    b "Now git!"
    b "And not a word to anyone, or else …"
    stop music
    $ renpy.end_replay()
    $ persistent.banu_teases_ruslan_unlocked = True
    jump banu_teases_ruslan_continue


label murat_fucks_banu:

    b_ "Oh shit! This can't be true!"
    b "Well..."
    b "I..."
    mur "Shh! Come here …"
    scene v13-49
    "With that, Murat holds Banu tight and kisses her luscious lips."
    b_ "This is so wrong but..."
    scene v13-50
    b_ "The bet is bet. Kamil deserves this one after all."
    "The woman just stands there at first, but Murat’s insistent massage of her rounded butt cheeks soon has her reciprocating the smooch."
    scene v13-51
    "The sly man senses that her current target is becoming an active partner and sits on the sofa, pulling her next to him and holding her tight..."
    scene v13-52
    "...while the kiss intensifies and the caresses heat up Banu."
    scene v13-53
    "Soon the two are lying down side-by-side, with Murat kissing and licking the milf’s neck and cheeks, while sensuously caressing the smooth skin of her thighs."
    scene v13-54
    b "He he! Stop it!"
    b "You’re like a kitten!"
    b "I’m ticklish there!"
    scene v13-55
    "The strong whisky has by now completely enveloped Banu’s mind..."
    scene v13-56

    "...and she’s a giggling and hiccupping mess, her dress lifted well over her hips and her legs lewdly open."
    scene v13-57
    mur_ "I’ve got you right where I wanted!"
    mur_ "You’re my bitch now!"
    "He pulls her to him and kneels between her legs, feeling the wetness of her horny cunt seeping through her panties."
    "He grinds his cock in her furrow and talks dirty to her, with Banu barely making sense."
    mur "Your pussy is fucking drenched!"
    mur "Do you like my cock rubbing it?"
    b "He he! Cock!"
    b "He he!"
    b "Cock-a-doodle-doo!"
    scene v13-58
    "The man knows he can do what he wants with her, so he lifts her like a rag doll and gets behind her."
    scene v13-59
    mur "You know what I’m gonna do now?"
    mur "I’m gonna fuck you!"
    mur "I’m gonna bend you over."
    mur "I’m gonna take off your panties."
    mur "And I’m gonna slam my cock in your whore cunt!"
    mur "And you’re gonna just stay there and take it."
    mur "And you’re gonna like it!"
    "The woman just looks at him, barely comprehending what’s happening, a silly smile plastered to her ahegao face."
    "She’s not reacting to Murat’s crude words, which in a normal situation would have her screaming and kicking."
    scene v13-60
    "Murat proceeds to do just what he anticipated, and soon Banu is on all fours, with the man rubbing his raging member between the cheeks of her ass."
    scene v13-61
    "The precum bubbling from his slit matches the wetness of Banu’s married snatch."
    show muratgrindingbanuanimation
    "He spends a long time just like that..."
    "...relishing in the anticipation of what he’s about to do to his latest conquest."
    scene v13-63
    "He soon penetrates the woman’s steaming cunt, and that’s what it takes to finally get a reaction from her..."
    "...in the form of a long, drawn-out moan."
    scene v13-64
    b "Aieeeeeeeeee!"
    b "Oh! Mhh!"
    show muradfuckingbanudoggyanimation
    stop music
    play music "voices/softmoan.mp3"
    mur "You like that, huh slut?"
    mur "Ohh yeah!"
    mur "You’re so fucking tight!"
    mur "Never had a big cock like mine, huh?"
    mur "Take it, take it!"
    scene v13-65
    stop music
    "Murat puts one of his feet down, so he can get a better grip on Banu’s hips to really crush her pussy hard."
    show muratfuckbanuupsidedownanimation
    play music "voices/softmoan.mp3"
    "Both of their moans match the slap-slap-slapping sound of Murat’s groin against Banu’s fantastically rounded ass."
    "He’s railing the woman really hard, treating her like little more than a living flesh onahole."
    scene v13-66
    "Finally, knowing he’s about to cum, he puts her lying face-down, in his favorite position..."
    "...which makes the woman’s pussy tighten deliciously, and proceeds to really use her gash."

    mur "Ahh!"
    mur "You fucking bitch!"
    mur "I love your tight slutty cunt!"
    mur "You like having my long cock slamming in your belly?"
    mur "Take it all!"
    mur "I’m gonna bruise your cervix!"

    scene v13-67 with hpunch
    stop music
    play sound "voices/man2.mp3"

    mur "AHHHHHHHHHH!"
    stop sound
    mur "Ohhhh, fuck!"
    mur "Here’s my cum!"
    mur "Take all of daddy’s milk!"
    mur "Ohhhhh!"

    scene v13-68
    "With that, he proceeds to unload a copious amount of cum on Banu’s asshole and bumcheeks..."
    "...and then collapses back, relishing the euphoria of the huge orgasm."
    mur "You really made me work for it."
    mur "Pleasure doing business with you!"
    $ renpy.end_replay()
    $ persistent.murat_fucks_banu_unlocked = True
    jump murat_fucks_banu_continue
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
