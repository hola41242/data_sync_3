
label polad_fuck_banu_kamil_bedroom_cuckroute:




    play music "audio/action.mp3"
    scene black

    "As Banu and Polad exchanged words behind Kamil's back, Kamil stood there in silence, seething with frustration but unable to muster the courage to confront them. "

    "With a heavy heart, he watched as they made their way towards the bedroom, his mind racing with a mixture of suspicion and fear."

    "He couldn't shake the feeling that something was off, that there was more to their conversation than met the eye."

    "And he wasn't about to let them get away with it."

    scene v19-26 with fade

    "With cautious steps, Kamil made his way to the door, his heart pounding in his chest as he pressed his ear against the wood, straining to hear their voices from within."

    "Inside the room, Banu's laughter rang out like a mocking melody, followed by the low rumble of Polad's voice."

    "Without a second thought, he gently pushed the door open, just enough to peek inside without being noticed."

    "What he saw made his blood run cold."

    scene v19-27 with vpunch

    "Kamil's heart pounded in his chest as he watched through the slightly left-open door, his eyes widening in shock and disbelief."

    "His breath caught in his throat as Polad reached for Banu's nightwear, his movements swift and purposeful."

    "With quick action, he began to peel the fabric away, revealing Banu's bare skin underneath."

    "A surge of anger coursed through Kamil's veins, hot and fierce. How could they do this to him, behind his back, in his own home?"

    "But despite the rage burning within him, Kamil knew he had to stay calm, had to bide his time."

    "He couldn't confront them now, not when they were in the middle of... whatever it was they were doing."

    "So, he stood there, hidden in the shadows, his fists clenched at his sides as he watched the scene unfold before him."

    scene v19-28 with fade

    "As Kamil continued to watch in stunned disbelief, his shock intensified when he saw Polad guide Banu towards the bed they shared."

    "It was a betrayal that cut deeper than any wound he had ever felt before."

    "The sight of Polad and Banu, entwined on the bed that was meant to be sacred to their union, was like a dagger to Kamil's heart."

    "He couldn't do anything but watch what happened next."

    scene v19-29
    stop music
    play music "voices/slappingslow.mp3"

    "Kamil's dick already got hard as he heard Banu's moans growing louder, intermingled with Polad's lewd whispers."

    "Banu's voice, breathless with desire, filled the room as she gasped and moaned, her words punctuated by Polad's low, seductive whispers."

    b "Oh, Polad... yes, right there..."

    p "You like that, baby? You like it when I fuck you like this?"

    b "Mmm, yes... don't stop..."

    scene v19-30

    b "Ahhhhhh..."

    p "I won't, babe. I won't stop until you're screaming my name."

    b "Harder, Polad... I want it harder..."

    p "You got it, sweetheart. You're gonna love this."

    "As Kamil listened from the shadows, a sense of betrayal and heartbreak washed over him, threatening to consume him whole."

    scene v19-31 with fade

    "Banu's movements grew more assertive as she straddled Polad, her eyes filled with lust and desire."

    b "Ahh...You ready for me, Polad?"

    p "Hell yeah, Banu. Show me what you got."

    show poladbanureverseanimation

    b "Ohhhh, you know I always deliver, baby."

    p "That's why I can't get enough of you."

    "Their words were punctuated by the sound of heavy breathing and the creak of the bed beneath them as Banu began to move with increasing urgency, her body arching with pleasure."

    b "Oh, Polad... you feel so good."

    b "You can't believe how much I missed your big dick."

    p "You're driving me crazy, Banu. Don't stop."

    b "I won't, baby. I'm yours."

    scene v19-32 with fade
    stop music
    play music "audio/heatedsex.mp3"

    "Polad's movements became more dominant as he took control, flipping Banu upside down with a confident grip."

    p "You ready for a little change of pace, sweetheart?"

    b "Oh, Polad... I like where this is going."

    p "You haven't seen anything yet."

    "As Kamil watched from the shadows, a strange mix of emotions washed over him."

    "Despite the betrayal and hurt he felt, there was a twisted sense of excitement bubbling within him as he witnessed Polad's dominance over Banu."

    "There was a part of him that yearned to possess that same level of power, to command Banu's attention and desire in the same way."

    "He wished Polad fuck Banu even harder with his big dick and punish her for being a bad wife."

    scene v19-33

    b "AAAHHHhhhh..."

    p "You've been a bad wife, Banu. And bad wives need to be punished."

    b "Yes, Polad... punish me."

    "And as they danced on the edge of ecstasy and agony, Banu found herself surrendering completely to Polad's dominance, reveling in the intensity of their connection."

    scene v19-34 with fade

    "Banu's voice was filled with reverence as she gazed up at Polad' cock with adoration, her desire for him burning brightly in her eyes."

    b "You're the man, Polad. I want you to mess me up real good."

    "Polad smirked, his confidence radiating as he looked down at her, relishing in the power he held over her."

    p "You sure about that, babe? Once I start, there's no turning back."

    scene v19-35

    b "I'm sure, Polad. Claim your territory. Make me yours."

    "Kamil couldn't tear his eyes away from the sight of Banu surrendering herself so completely to Polad's dominance."

    "How could Banu, his own wife, so easily surrender herself to another man? What did Polad possess that he didn't?"

    "As he grappled with these questions, a bitter realization dawned on him—he could never compete with Polad's primal magnetism, his unapologetic masculinity."

    "And try as he might, he could never inspire the same level of devotion and desire in Banu."

    p "You asked for it, sweetheart. Don't say I didn't warn you."

    scene v19-36 with hpunch
    stop music
    play sound "voices/man3.mp3"

    p "Axxxxxx..."
    stop sound
    b "Come on, Polad... give it to me."

    b "Ohhh, shit.."

    p "Take it, babe. All for you."

    scene black

    b "That's it, Polad. You're the man."

    p "You know it, babe. No one does it like me."




    p "Did you hear that?"

    "As the door creaked open, Polad and Banu froze, their senses sharpened by the sudden intrusion."



    scene v19-37 with fade

    b "Someone's here. I can feel it."

    p "Kamil? Is that you?"

    b "Come out, Kamil. We know you're there."

    p "This isn't funny, Kamil. Show yourself."

    scene v19-38

    p "Well, well, well... Looks like we've got ourselves a little voyeur, huh?"

    "Banu's laughter bubbled up, her voice tinged with a hint of wickedness as she played along."

    b "Seems like Kamil's got a front-row seat to the show."

    p "You like what you see, Kamil?"

    b "Or are you just too chicken to join in?"

    p "Your wife felt so damn good."

    b "Yeah, Kamil. You've been missing out."




    p "Come on, man, show yourself already."

    p "If you don't show yourself, I'll fuck her again and this time even harder."

    "..."

    p "I think he wants me to fuck you again Banu."

    b "Then what are you waiting for?"

    p "Sorry but I have stuff to do. Maybe next time."



    "Despite their attempts to goad him into a response, Kamil remained silent, his shock evident on his face as he listened to their taunts with a mixture of disbelief and dismay."





    $ renpy.end_replay()
    $ persistent.polad_fuck_banu_kamil_bedroom_cuckroute_unlocked = True
    jump polad_fuck_banu_kamil_bedroom_cuckroute_continue






label kamil_show_banu_who_is_man:




    scene black
    play music "audio/action.mp3"

    b "Ahhh..."

    "Kamil grabbed Banu's hair with a firm grip, his eyes blazing with anger."

    scene v19-48 with dissolve

    k "You think you can slap me and get away with it, huh?"

    b "Kamil, let go of me! You're hurting me!"

    k "You wanna play rough, huh? Well, I can play that game too. You're gonna learn real quick who's in charge around here."

    scene v19-49

    b "Please, Kamil, let me go! I'm sorry, I didn't mean it!"

    k "Sorry ain't gonna cut it, Banu. You wanna disrespect me, you gotta deal with the consequences."

    b "Kamil, please... I won't do it again, I swear!"

    k "You damn right you won't. You're gonna remember this next time you even think about laying a hand on me."

    scene v19-50 with fade

    "Kamil's eyes burned with a fierce determination as he seized Banu by the shoulders and forcefully spun her around, pressing her against the wall with a firm grip."

    "Banu gasped in shock, her heart pounding with a mixture of fear and uncertainty as she felt Kamil's strong hands on her."

    b "Kamil, what are you doing? Let me go!"

    k "You wanna disrespect me, Banu? You wanna treat me like trash? Well, now you're gonna learn what happens when you cross me."

    scene v19-51

    b "Kamil, please... not here. Let's go somewhere else."

    k "You think you get to call the shots now?"

    k "You're gonna learn to obey me, Banu."

    b "Kamil, I'm begging you... please..."

    k "Shut up, Banu. You're gonna do as I say."

    scene v19-52 with hpunch

    b "Ohhhh..."

    b "Kamil, it hurts..."

    k "That's the point, baby. You're gonna remember this next time you think about stepping out of line."

    scene v19-58

    b "Oh, Kamil..."

    k "You like that, huh? You like it rough?"

    b "Yes, Kamil... don't stop..."

    k "You're mine, Banu. Mine to do with as I please."

    scene v19-53 with fade

    b "Kamil, please... I can't..."

    k "You're gonna take what's coming to you."

    b "Kamil, I... I can't breathe..."

    k "You want it standing, baby? Fine. But you better be ready for me."

    scene v19-59

    b "Oh, Kamil... don't stop... give it to me harder..."

    k "You want more, huh? You want it rough?"

    b "Yes, Kamil... harder... I need it..."

    b "Yes, Kamil... show me who's in charge..."

    scene v19-60

    k "Well, now you're gonna feel it."

    b "Oh, Kamil... show me what you've got."

    k "You asked for it."

    b "Yes, Kamil... harder... give it to me."

    scene v19-61

    "Their bodies move together in a frenzy of passion, the air filled with the sounds of their lovemaking."

    "In that moment, they surrender to the raw intensity of their desire, each thrust bringing them closer to the edge of ecstasy."

    "And as they lose themselves in the heat of the moment, they are reminded of the undeniable connection that binds them together, even in the midst of their tumultuous relationship."






    scene v19-54

    b "Come on, Kamil... show me what you've got. I know you can go harder."

    k "You asked for it, baby. Hold on tight."

    "Their bodies move together in a frenzy of passion, Banu's moans reaching new heights as Kamil's intensity matches her own."

    "In that moment, they are lost to the fire that consumes them, the heat of their desire burning brighter with each thrust."

    scene v19-55

    k "Oh, damn... Banu, I'm about to..."

    b "Yes, Kamil, come for me... give it all to me..."

    k "Here it comes, baby... get ready..."

    "As Kamil reaches the peak of ecstasy, their bodies entwined in a final surge of passion, the room fills with the sounds of their release."

    scene v19-56 with fade
    stop music

    k "See that, Banu? That's what happens when you mess with me. I'm the man in this house."

    b "Yeah, yeah... whatever, Kamil."

    k "You see that, Banu? You can't deny who's in charge around here."

    b "Don't get too cocky, Kamil. This doesn't change anything."

    k "Oh, it changes everything. You know it, and I know it."

    b "You may have won this round, Kamil, but don't think for a second that I'm backing down."

    scene v19-57

    k "You wanna challenge me, Banu? Go ahead. But remember who's calling the shots."

    b "I won't forget, Kamil. And you better be ready for whatever comes next."

    "Kamil's triumph is palpable as he stands there, reveling in his display of dominance."

    "Banu, on the other hand, can't hide the flicker of defeat in her gaze, coupled with a hint of resentment."

    "Yet beneath it all, there's a touch of vulnerability, a reminder of the complexity of their relationship."







    $ renpy.end_replay()
    $ persistent.kamil_show_banu_who_is_man_unlocked = True
    jump kamil_show_banu_who_is_man_continue









label abdulfarhadfuckbanu_bathroom:




    ab "Come on, Kamil, don't be a party pooper. We just want to keep the fun going. Besides, it'll be good for you to get out of the house for a bit."

    b "Yeah, Kamil, don't overthink it. Just grab the beer and come back. We'll be here waiting for you."

    "Kamil hesitates for a moment, but the reassurances from his friends ease his suspicions."

    scene v19-88

    "As he heads out the door, Abdul, Banu, and Farhad exchange satisfied glances, knowing that their plan is in motion."

    far "He's even dumber than I thought. We've got him right where we want him."

    "As they watch Kamil's retreating figure, a sense of satisfaction washes over them, knowing that they've successfully manipulated him to do their bidding. "

    scene black with dissolve

    "..."

    "After some time Kamil steps into the room with two beer bottles clutched in each hand, a puzzled expression on his face as he surveys the empty space."

    scene v19-91

    "He furrows his brow, confusion flickering in his eyes as he realizes that Abdul, Banu, and Farhad are nowhere to be found."

    k "Hey, guys? Where'd you all go?"

    scene v19-92

    "Silence greets him in response, the room eerily quiet as he stands alone in the empty space."

    "A sense of unease creeps over him, a gnawing feeling in the pit of his stomach as he wonders where his friends and his wife have disappeared to."

    scene black

    "After searching the full house, Kamil ends up in front of the bathroom."

    scene v19-93 with fade
    play music "audio/heatedsex.mp3"

    "Kamil's jaw drops as he peeks through the half-opened bathroom door, his eyes widening in disbelief at the scene unfolding before him."

    scene v19-94

    "His heart feels like it's about to pound out of his chest as he takes in the sight of Banu, butt naked and wrapped up with Abdul and Farhad in some kind of twisted tryst."

    "Banu's moans echo off the bathroom walls, mixing with the sounds of their wild romp."

    scene v19-95 with dissolve

    "Abdul's pounding into her while she's gripping onto Farhad's massive member."

    "It's like a freakin' circus act in there, and Kamil can't believe his eyes."

    "Kamil's blood boils with fury, but he swallows down the rage, a cold determination settling over him."

    "He steps back from the bathroom door, careful not to make a sound as he retreats into the shadows. "

    "His mind races with a plan as he decides to play it cool and see what other surprises they've got in store."

    scene v19-96 with fade

    ab "Yeah, that's it, baby. You like that, huh?"

    b "Oh, Abdul, you're so good. Harder, baby, harder."

    far "Damn, Banu, you know just what to do. Keep going, baby."

    b "Mmm, I can't get enough of this big dick. You like it when I stroke you like this?"

    ab "I'm gonna make you scream my name, bitch."

    b "Ahhhh.."

    scene v19-97

    ab "You like it rough, huh? You want it harder, baby?"

    b "Yes, Abdul, give it to me. I want it all."

    far "Damn, Abdul, you're tearing her up. Keep going, man."

    b "Oh, fuck, yes! Don't stop, Abdul. I'm yours."

    ab "You're mine, Banu. All mine. And I'm gonna fuck you until you can't walk straight."

    scene v19-98 with fade

    "Kamil's stomach churns with revulsion as he witnesses the scene unfold before him. His fists clench at his sides, his nails digging into his palms as he fights to contain his fury."

    "Banu's moans fill the air as Abdul flips her upside down, her legs dangling in the air as he devours her pussy with abandon."

    "Her cries of ecstasy are muffled by Farhad's massive cock lodged in her mouth, her head bobbing up and down as she sucks him greedily."

    ab "You taste so fucking good, Banu. I could eat you all night."

    scene v19-99

    b "Oh, Abdul, yes! Don't stop, baby, please, mmmm.."

    far "Fuck, she's so hot. You're one lucky guy, Abdul."

    b "Mmm, Farhad, you're not so bad yourself. I love sucking your big cock."

    ab "Yeah, you like that, huh? You like it when he fucks your mouth while I eat your pussy?"

    b "Yes, Abdul, yes! I love it! I'm yours, baby, all yours."

    "Kamil's blood boils with rage as he listens to their perverse conversation, his stomach turning with disgust."

    scene v19-100 with fade

    "Kamil's heart sinks as he witnesses the scene escalate into further debauchery. "

    ab "You like it rough, huh? You like it when I fuck you like this?"

    b "Oh, Abdul, yes! Don't stop, baby, don't stop!"

    far "Damn, that's hot. You're so fucking sexy, Banu."

    b "Fuck me, Abdul! I want it all! Harder!"

    scene v19-101

    ab "You want it harder, baby? I'll give you everything you want."

    b "Oh, fuck! Yes, Abdul, yes! Give it to me! Harder!"

    ab "You like that, huh? You like it when I fuck you like this?"

    far "Damn, Banu, you're so fucking hot. I wish I could be inside you right now."
    stop music

    show abdulfucksbanuferhadstanding
    play music "voices/slappingslow.mp3"
    b "Fuck me, Abdul! Make me yours! I'm yours, baby!"

    b "Oh, Abdul, you're so much better than Kamil. He's such a pathetic cuck."

    ab "Yeah, that loser doesn't know how to please a woman like you. He's lucky to have someone like me to show him how it's done."

    b "Ahhhh....I can't believe I ever settled for him. But now that I've had a real man like you, I'll never go back."

    ab "That's right, baby. You deserve someone who can actually satisfy you. And I'm more than happy to fill that role."

    b "Fuck Kamil! He doesn't deserve someone as hot as me. I'm yours, Abdul. Use me however you want."
    stop music
    scene v19-102 with fade

    "Suddenly Farhad grabbed Banu keeping her arms from behind, fucking her as hard as he could with his big long dick."

    b "Oh, Farhad! Yes! Fuck me, baby!"

    far "You like that, huh?"

    b "Oh, yes! Harder, Farhad! Don't hold back!"

    show ferhadfucksbanuabdulstanding
    play music "voices/slappingmedium.mp3"
    ab "Damn, Farhad, you're really giving it to her."

    b "AHhhhhhh.."

    far "She's loving every minute of it. Just look at her squirm."

    b "AHHHh...Yes, yes, yes! I'm yours, Farhad! Use me however you want!"

    ab "Looks like Kamil's not the only one getting cucked tonight."

    "As Farhad joins in on the action, Kamil's rage reaches a boiling point."

    ab "You're nothing but a dirty whore, Banu."

    b "AHhhh.. yesss..."
    stop music
    scene v19-103

    b "I-I'm sorry... I know I'm just a whore... I've always been one..."

    ab "Damn right you are. And Kamil's just a fool for ever thinking you were anything more."

    far "Yeah, you're just a dirty slut, Banu. But don't worry, we'll take care of you real good."

    b "Ahhh, do whatever you want with my body, please..."

    b "I'll do anything you want... just please don't leave me..."

    ab "Get down on your knees and stroke our cocks until we shower you with our cum."

    b "Yes... yes, anything you want..."

    scene v19-104

    ab "That's it, whore. Stroke our cocks like the filthy slut you are."

    far "Damn, she's good at this. Keep going, Banu. Make us cum all over your face."

    b "I-I'm doing my best..."

    show banujerkoffkamilfriends
    play music "voices/makeout.mp3"

    ab "That's it, keep going. Make us shoot our loads all over that pretty face of yours."

    ab "Tell us, slut. Whose cock do you think is bigger? Kamil's or ours?"

    b "I-I don't know...Who cares now?"

    far "Come on, Banu. You've felt them both. Which one fills you up better?"

    b "Yours... I-I think yours is much bigger..."

    ab "Damn right it is. And Kamil's just a pathetic little cuckold compared to us."

    far "Yeah, he doesn't stand a chance against us. We're real men, unlike that loser."
    stop music
    scene v19-105 with hpunch
    play sound "voices/man2.mp3"
    b "Oh, god..."

    ab "That's it, whore. Wear our cum like the dirty slut you are."

    scene v19-106 with hpunch
    play sound "voices/man1.mp3"
    far "Damn, she's covered in it. Looks good on you, Banu."

    b "Oh shit..."
    stop sound
    scene v19-107 with fade
    play music "audio/weakbanu.mp3"
    ab "You deserved every drop of it."

    far "Yeah, you're just a cumdump for real men like us."

    b "I feel really good... when my face and tits are covered with cum."

    ab "Damn, you really are a dirty whore, aren't you?"

    far "Looks like she enjoys being used like the slut she is."

    scene v19-108 with fade

    ab "Come on, Banu. Let's take a shower together."

    far "Yeah, it'll be fun. We can wash all this cum off you."

    b "I want to shower with you, but... what if Kamil comes back and sees us?"

    scene v19-109

    ab "Don't worry about him. If he comes back, he won't be able to do anything. We'll just fuck him up."

    far "Yeah, he's just a pathetic cuck. He won't dare to mess with us."

    "As Kamil watches from the shadows, his heart pounds with a mixture of rage and despair."

    "He knows he should confront them, put an end to their betrayal once and for all. "

    "What can he do against them? They've already shown him that they hold all the power, that he's nothing but a pawn in their twisted game."

    "He decides to keep himself hidden so they don't know that he's aware of it."

    "As Kamil overhears Abdul's lewd declaration, a surge of fury courses through him, nearly overwhelming his senses."

    scene v19-110

    ab "Hey, Banu, you know what I've been thinking? I'm gonna fuck you in the ass in the shower."

    b "Oh, Abdul, I don't know if that's a good idea..."

    ab "Come on, don't be shy. You know you want it. And I'm gonna give it to you good."

    b "But what if Kamil hears us? What if he comes back?"

    ab "Who cares about Kamil? He's just a pathetic cuck. If he shows his face, I'll make sure he regrets it."

    b "I... I guess you're right..."

    "As Banu reluctantly agrees to Abdul's perverse desires, Kamil's heart sinks with a mixture of anger and despair. "

    "As Banu, Abdul, and Farhad disappear into the bathroom together, Kamil retreats silently, his steps careful and deliberate."
    stop music
    "He knows that he has to wait to do something."




    $ renpy.end_replay()
    $ persistent.abdulfarhadfuckbanu_bathroom_unlocked = True
    jump abdulfarhadfuckbanu_bathroom_continue



label banu_dominates_kamil_ruslan:




    play music "audio/sexy.mp3"

    scene v19-134 with fade

    "As Kamil and Ruslan stood there butt-naked, Banu strutted over to them, her eyes blazing with contempt."

    b "Look at you two sorry excuses for men. Stripped down to nothing, you're nothing but my playthings now, my little slaves."

    b "You're nothing but weaklings, too spineless to defy me. From now on, you'll do as I say, or suffer the consequences."

    scene v19-135

    b "Your son's got more backbone than you, Kamil. He's a real man, unlike you."

    r "Banu...stop."

    k "You don't know what you're talking about, Banu. "

    "Banu's words sliced through the air like a knife, leaving Kamil stunned and speechless."

    b "You know, Kamil, your son's packing more heat than you. His dick's bigger, that's for sure."

    k "That's... that's none of your damn business, Banu."

    b "Oh, come on, Kamil. You can't deny the truth. Your son's got you beat in more ways than one."

    b "Both of you, stay close. I wanna compare."

    scene v19-136

    "Kamil's jaw tightened with anger, his pride wounded by Banu's audacity."

    "Ruslan shifted uncomfortably, unsure of how to react to such a humiliating request."

    k "You've got some nerve, Banu. We ain't your toys to be played with."

    b "Well, well, well... looks like we have a winner. Ruslan, your dick is longer and thicker than your old man's. Congratulations."

    k "That's... that's enough, Banu. This has gone too far."

    scene v19-137

    "But Banu just laughed, her laughter ringing in their ears like a taunt."

    b "Oh, come on, Kamil. Can't handle the truth? Face it, your son's got you beat in every department."

    "Banu's eyes narrowed as she inspected Kamil and Ruslan's erect members with a calculating gaze, a smirk playing on her lips."

    scene v19-138

    b "Well, would you look at that? Not bad for a father-son duo."

    "Ruslan shifted uncomfortably, his cheeks burning with embarrassment under Banu's scrutinizing gaze."

    k "Enough, Banu. This ends now."

    b "Oh, come on, boys. Don't be so sensitive. It's just a bit of fun."

    scene v19-139

    "Kamil and Ruslan gasped in shock as Banu's hands wrapped around their throbbing members, her touch sending shivers of pleasure coursing through their bodies."

    b "Well, well, well... looks like we've got a couple of eager boys here."

    b "You boys seem to be enjoying yourselves. Who would've thought a little stroking could make you both so... responsive."

    b "You like that, don't you? My naughty boys, getting all worked up for me."

    scene v19-140

    k "Oh god..."

    r "Fuck..."

    "Banu's words and her good stroking pierced through Kamil and Ruslan's defenses like a knife, leaving them stripped bare and vulnerable before her."

    b "Come on, boys. Admit it. You're enjoying every single moment of this."

    b "Say it. Say that you enjoy being at my mercy, that you're both my little playthings now."

    k "Ohhh..Fine... we enjoy it."

    r "Yeah... we do."

    scene v19-141

    b "You two are nothing but weaklings. Admit it."

    r "Ohhhh shit.."

    b "Say it. Say that you're weak, that you're both powerless in the face of my dominance."

    k "We're weak... we can't resist you."

    r "Yeah... we're weak."
    stop music
    show banujerkkamilruslanoffanimation
    play music "voices/makeout.mp3"
    "Banu's movements quickened, her hands becoming a blur as she intensified her grip on Kamil and Ruslan's throbbing members, pushing them further into submission."

    b "You think you can resist me? Pathetic."

    "Banu's smirk widened into a cruel grin as she reveled in her control over Kamil and Ruslan."

    b "Beg me. Beg me to make you cum."

    k "Please... make us cum. We need it."

    r "Yeah... please. We can't take it anymore."

    b "Tell him. Tell him you want him to fuck me."

    b "Go on. Say it."

    k "Ruslan... I... I want you to fuck her...Ohhhh.."

    b "Tell him, Ruslan. Tell your dad that you want to cum inside me."

    b "Say it."

    r "I'm sorry, Dad... I... I want to cum inside her."
    stop music
    scene v19-142

    "Banu's sadistic grin widened as she continued to toy with Kamil and Ruslan, reveling in her control over them."

    b "You both want it so badly, don't you? To cum inside me."

    b "You're both so close. Beg me to let you cum."

    k "Please... let us cum. We need it."

    r "Yeah... please. We can't take it anymore."

    scene v19-143 with hpunch
    play sound "voices/man2.mp3"
    b "Now. Do it. Cover each other with your cum."
    play sound "voices/man1.mp3"

    "With a mixture of shame and desire, Kamil and Ruslan found themselves unable to resist Banu's command, their bodies succumbing to the overwhelming need for release."

    "As their orgasms washed over them, Kamil and Ruslan let out primal moans of ecstasy, their hot, sticky release splattering across each other's bodies in a humiliating display of submission."

    scene v19-144 with fade
    stop sound
    b "Well done, boys. You've pleased me."

    b "Remember this moment, boys. Remember who's in charge here."

    "Banu reclined on the bed, her satisfaction evident in every line of her body as Kamil and Ruslan glared at her with seething hatred."

    scene v19-145

    b "Leave. Both of you. I have no use for you now."

    "Kamil and Ruslan gritted their teeth in frustration, their fists clenched at their sides as they struggled to contain their anger."

    b "What's the matter, boys? You don't want to fuck me, do you?"

    b "Please, leave me now. I want to rest."

    "Kamil and Ruslan's fists clenched at their sides, their faces burning with humiliation and rage as Banu's words cut through them like a knife."

    "With a final scornful glance, they turned on their heels and stormed out of the room, determined to rid themselves of Banu's toxic influence once and for all."





    $ renpy.end_replay()
    $ persistent.banu_dominates_kamil_ruslan_unlocked = True
    jump banu_dominates_kamil_ruslan_continue







label kamil_dominate_banu_bedroom:



    play music "audio/action.mp3"

    scene v19-170 with hpunch

    b "Ahhhh..."

    "With determination flickering in his eyes, Kamil grasped Banu's head firmly between his hands, pivoting her to meet his gaze."

    "Banu, taken aback by the sudden shift in dominance, felt a shiver run down her spine as she met Kamil's unwavering gaze."

    scene v19-171

    k "Listen up, Banu. I've had enough of your games. It's time you start showing me some respect."

    b "What are you trying to do, Kamil? You can't just—"

    k "I can and I will. You've pushed me too far, Banu. From now on, things are going to change around here."

    b "And what if I don't want to play by your rules, huh?"

    k "Then you'll find out what happens when you push me too far."

    b "You wouldn't dare..."

    scene v19-172 with hpunch

    b "Ahhh...Kamil, what are you doing? Get off me!"

    k "I've had enough of your games, Banu. It's time you learn who's in charge here."

    b "You can't just—"

    k "You wanted to play rough? Well, now you're going to get it."

    b "Kamil, please..."

    scene v19-173

    b "Ohhhhh, oh my god..."

    k "You like that, Banu? Huh? You like it rough?"

    b "Ahhhhh...Kamil! You're the worst!"

    k "You're just saying that because you can't handle a real man like me."

    k "Keep fighting, Banu. But you know deep down you want this."

    b "I... I hate you, Kamil..."

    k "Take this, bitch."
    stop music
    show kamilforcebanubedroomcuckroute
    play music "voices/slappingslow.mp3"
    k "You're mine, Banu. Mine."

    b "Stop it, Kamil... Please...Ahhhh"

    k "You wanted a real man, Banu. Well, here I am."

    b "I... I can't... Kamil...breath..."

    k "Say it, Banu. Say you're mine."

    b "I'm... I'm yours, Kamil..."

    k "Louder, Banu. Say it louder."

    b "I'm yours, Kamil... I'm yours..."

    b "Fuck me, Kamil. Fuck me more..."

    scene v19-174

    k "That's right, Banu. Beg for it."

    b "Please, Kamil... More... Please, fuck me harder..."

    k "You wanted this, Banu. You wanted a real man."

    b "Yes, yes, Kamil... More... Please, don't stop..."

    k "You're mine, Banu. Mine to use however I want."

    scene v19-175

    b "Yes, Kamil... Yours... Use me... Please..."

    k "That's right, Banu. Mine. Ohhhhh....shitt..."

    "As Kamil reaches his peak, he releases himself inside Banu, filling her with his essence."
    stop music

    scene v19-176 with dissolve

    "Kamil covers Banu's pussy with his cum, marking his territory and asserting his dominance over her once again."

    "The silence between them felt heavy, filled with unspoken words and unresolved tensions."

    "Each of them wrestled with their own thoughts, unsure of what to say next."

    scene v19-177 with dissolve

    "The room was thick with tension as Banu lay there, her expression a mix of frustration and resentment."

    "Meanwhile, Kamil's satisfied smile hinted at a sense of triumph, but also a hint of sympathy for Banu's turmoil."

    b "You think you've won, huh?"

    k "I didn't want to fight, Banu."

    k "I just want things to be different between us."

    k "I want my Banu back to me."

    b "You think one night changes everything?"

    scene v19-178

    k "Maybe not everything, but it's a start."

    k "I don't want us to be like this, Banu."

    b "Well, we are. And it's not just going to magically fix itself because you decided to take charge for once."

    k "I know... but can't we at least try?"

    b "Try? We've been trying for years, Kamil. And look where it's gotten us."

    k "I will get you back Banu. I promise. And I'll save our marriage and treat you right."

    k "..."

    b "..."



    $ renpy.end_replay()
    $ persistent.kamil_dominate_banu_bedroom_unlocked = True
    jump kamil_dominate_banu_bedroom_continue












label cuck:


    scene black with Dissolve(3)
    ""
    centered "{size=+120}1 year later...{/size}" with Fade(0.5, 0.5, 5)
    scene black with dissolve
    b_ "Life with Kamil had become routine, a monotonous existence that left me yearning for something more."
    b_ "I couldn't ignore the emptiness that gnawed at me, urging me to seek passion elsewhere."
    b_ "Staying with Kamil was a choice I made for stability, not out of love. He lacked the fire, the intensity that I craved in a man."
    scene v18-251 with dissolve
    b_ "So, I started exploring, allowing myself to be swept away by the whirlwind of desire and forbidden romance."
    b_ "In the arms of other men, I felt alive. Their touch, their attention, became my refuge from the dullness of my everyday life."
    b_ "It was a dangerous game, a balancing act between my role as a faithful wife and my desires as an adventurous lover."
    b_ "Kamil's suspicions hung heavy in the air, a palpable tension that filled our home."
    b_ "But he lacked the strength, the assertiveness to confront me."
    b_ "Every time he tried, I shut him down, my words cutting through his feeble attempts at confrontation."
    b_ "His insecurity only pushed me further away, making me care less about his doubts and more about my own desires."
    b_ "The day I learned about Kamil's call to my gym instructor was a turning point."
    b_ "His feeble attempt to control my life had reached a breaking point."
    b_ "I confronted him, a fierce anger burning within me. He dared to challenge the desires that fueled my existence, attempting to sever the connections I held dear."
    b_ "But I wasn't one to back down. I stood my ground, my words sharp and unyielding, shutting him down once more."
    scene v18-252
    b_ "I threatened to leave him, my determination unwavering."
    b_ "In a desperate plea, he grabbed hold of my feet, his eyes filled with fear and desperation."
    b_ "But his grip was weak, and I could no longer ignore the truth:"
    scene v18-253
    b_ "I needed more, something he could never provide."
    b_ "I decided to give Kamil one last chance, but it came with a condition - a condition that would test his humility and willingness to change."
    b_ "I demanded that he go and beg forgiveness from the gym instructor, the man he had dared to interfere with."
    b_ "It was a challenge I knew he wouldn't easily accept."
    scene v18-254
    b_ "With a firm resolve, I watched as he hesitantly agreed to my demand."
    b_ "There was a flicker of hope in his eyes, a glimmer of understanding that his actions had consequences."
    scene v18-255
    b_ "The ball was in his court now; he had to prove that he was willing to go to great lengths to keep me, to acknowledge his mistakes and make amends."
    b_ "Whether he would succeed or fail, only time would tell."
    b_ "But I stood firm, ready to enforce the boundaries I had set, no matter the outcome."
    scene black with dissolve
    b_ "I brought Kamil to the gym, his reluctance apparent in every step he took. "
    scene v18-256 with dissolve
    b_ "The atmosphere was charged with tension as we entered, the gym instructor's eyes narrowing in suspicion."
    b_ "I demanded that Kamil apologize for his unwarranted intrusion into my personal life, a demand he fulfilled, albeit begrudgingly."
    scene v18-257
    b_ "Kamil's voice wavered as he uttered his apology, a feeble attempt to right his wrongs."
    b_ "I observed the instructor's stern expression soften slightly, a glimmer of acceptance flickering in his eyes."
    b_ "As Kamil stumbled through his apology, I couldn't help but feel a surge of disappointment wash over me."
    b_ "The man I had once considered my husband appeared weak and pitiful, his attempts at redemption feeble at best."
    b_ "His voice quivered, and his eyes avoided mine, lacking the strength to meet my gaze."
    scene v18-258
    b_ "Contrastingly, when I looked into the gym instructor's eyes, I saw something different. "
    b_ "There was a glint of dominance, a confidence that spoke volumes."
    b_ "It was a stark contrast to Kamil's demeanor, and in that moment, I found myself drawn to that power. "
    b_ "The instructor exuded a strength that Kamil lacked, and it stirred something within me."
    b_ "As the apology hung in the air, I couldn't shake off the feeling that Kamil had lost my respect. "
    b_ "His actions had further diminished whatever connection we once had, leaving me questioning the validity of our marriage."
    b_ "As we bid farewell to the gym instructor, something unexpected happened."
    scene v18-259
    b_ "He pulled me towards him, his grip firm and commanding."
    b_ "With a swift motion, he pressed a kiss to my lips, his actions oozing dominance, leaving Kamil visibly shocked."
    b_ "In that moment, I felt a strange mixture of exhilaration and unease. We kissed for some time and Kamil waited for us to finish."
    scene v18-260
    b_ "The gym instructor's bold move had asserted his power, not just over me, but over Kamil as well."
    b_ "His confident demeanor seemed to fill the space around us, making Kamil appear even smaller and more insignificant in comparison."
    scene v18-261
    b_ "As we walked away, Kamil and I locked eyes, his expression a mix of disbelief and insecurity. "
    b_ "It was as if he had finally realized the depths of the chasm that had grown between us."
    b_ "In that fleeting moment, I made a silent vow to myself – I wouldn't settle for anything less than a man who could match my intensity, a man who wouldn't be overpowered by the strength of others."
    b_ "The encounter with the gym instructor had only solidified my resolve to seek out a different kind of connection, one that resonated with the power and passion that burned within me."
    scene black with dissolve
    b_ "After much contemplation and determination, I finally went through with something I had been longing for – a breast surgery."
    scene v18-262 with pixellate
    b_ "I had always been dissatisfied with the size of my breasts, feeling they didn't match the confidence I carried inside."
    b_ "Kamil had voiced his disapproval, but I had grown indifferent to his opinions."
    scene v18-263
    b_ "It was my body, my decision, and I wasn't going to let anyone dictate how I should feel about it."
    b_ "Standing before the mirror in my black underwear, I admired the transformation. "
    scene v18-264
    b_ "The newfound curves accentuated my figure, instilling a newfound sense of confidence within me."
    b_ "I ran my fingers over the smooth skin, relishing the changes I had made."
    b_ "It wasn't just about physical transformation; it was reclaiming ownership over my body, embracing the power to shape it according to my desires."
    scene v18-265
    b_ "As I looked at my reflection, I felt a surge of empowerment, a reminder that I was in control of my choices, unapologetically shaping my own identity, regardless of anyone else's opinion."
    scene black with dissolve
    b_ "Kamil and I reluctantly entered the police station, tension palpable between us."
    scene v18-266
    b_ "Ahmed, the police officer, was my neighbor and Kamil's former schoolmate."
    b_ "Their history had always been fraught with animosity, and Ahmed had little respect for my husband."
    scene v18-267
    b_ "The reason for our visit this time was Ahmed himself."
    b_ "Our relationship had taken an unexpected turn after an incident where Kamil had acted violently towards me."
    b_ "In desperation, I had reached out to Ahmed for help, and from there, a private connection had blossomed between us."
    b_ "Ahmed had fucked me for several times already, in his office...his home..."
    b_ "He was the man that executed confidence and I enjoyed cheating on Kamil with him."
    b_ "Kamil suspected that there was something between Ahmed and me so he came with me this time."
    b_ "But I didn't care if Kamil could find out my relationship with Ahmed."
    b_ "I wasn't afraid of him. I didn't care about him."
    b_ "However, bringing Kamil into this equation was a risky move."
    scene v18-268
    b_ "As I sat there in Ahmed's office, I could feel the tension rising. Ahmed's anger was like a storm, and Kamil was the unfortunate soul caught in its path."
    b_ "Ahmed didn't let him sit."
    b_ "Despite Kamil's initial hesitation, he left the room under Ahmed's stern gaze."
    b_ "I couldn't stop smiling as I understood what Ahmed, the dirty bastartd had planned."
    scene v18-269
    b_ "In that moment, I felt a mixture of relief and excitement. "
    b_ "The stage was set for what I had been secretly longing for, and I couldn't help but revel in the prospect of being alone with Ahmed, away from prying eyes."
    b_ "This encounter promised something clandestine, something I had been yearning for in the depths of my desires."
    b_ "As I glanced at Ahmed, I knew that the dynamics between us were about to shift, and I was more than ready to embrace whatever was coming my way."
    scene v18-270 with fade
    b_ "He was so fast to take my skirt and his pants off."
    b_ "After minutes later my leg was in the air and Ahmed was inside of me."
    b_ "I tried my best not to moan and cause trouble in a place like that."
    scene v18-271
    b_ "But Ahmed wasn't going easy on me."
    b_ "I knew he was enjoying fucking me, the wife of a man he hated while he was waiting outside."
    b_ "He held strong eye contact with me sending signals that I belonged to him in that room."
    b_ "I had seen bigger cocks but Ahmed's average cock was hitting my spot and sending an incredible pleasure to my brain making my eyes close."
    scene v18-272
    b_ "I loved being used by him, fucked by him while Kamil was waiting outside."
    b_ "I bent over and raised my hips enough that his dick could go deeper inside."
    b_ "His continuous non stop thrusts made me lose my mind."
    b_ "At that point I clouldn't stop my moaning anymore."
    b_ "I didn't care about the workers. I didn't care about Kamil."
    scene v18-273 with hpunch
    b_ "As Kamil unexpectedly entered the room, my heart skipped a beat."
    b_ "I saw the shock in his eyes, the confusion that painted his face."
    b_ "It was a moment frozen in time, the air heavy with tension."
    b_ "I, however, met Kamil's gaze with a calmness that masked the storm of emotions within me."
    scene v18-274
    b_ "In that silent moment, a newfound defiance bubbled within me. I refused to cover myself under Kamil's gaze, my eyes holding a quiet strength."
    b_ "In that tense moment, I stood there, a smirk playing on my lips as Kamil's face turned crimson with shock and disbelief."
    b_ "Ahmed's anger was palpable, his reprimand cutting through the air like a sharp blade. "
    scene v18-275
    b_ "Yet, I remained silent, relishing the chaos I had orchestrated."
    b_ "It was an odd satisfaction, watching these two men, once so significant in my life, now reduced to mere pawns in my game. "
    b_ "My newfound confidence and the subtle power I held in that room made me feel invincible, unshakable."
    b_ "I didn't need to utter a single word; my silence spoke volumes, echoing the control I had over my own life."
    b_ "I stood there, watching as Ahmed demanded Kamil to leave the room once more."
    b_ "The atmosphere was tense, and Kamil, taken aback and clearly uneasy, didn't dare to refuse."
    b_ "He left, his face a mix of confusion and hurt pride."
    scene black with dissolve
    b_ "During this one year Leyla's marriage brought some peace to my mind."
    b_ "Seeing my daughter Leyla embark on this new chapter of her life brought a mix of emotions flooding over me."
    b_ "As I watched her glowing with happiness on her wedding day, I couldn't help but feel an overwhelming sense of pride and love."
    scene v18-276
    b_ "I found solace in the midst of the chaos in my daughter Leyla's happiness."
    b_ "Watching her cuddle with her husband in the kitchen, their laughter echoing through the room, became a source of comfort for me."
    scene v18-277
    b_ "In those moments, I realized that love could thrive even amidst the uncertainties of life."
    b_ "It was as if Leyla's joy cast a warm glow, reminding me that there was still beauty and love in the world, despite the challenges I faced."
    b_ "Seeing her happiness, I couldn't help but smile, finding strength in the simple, yet profound, moments of affection shared between them."
    b_ "In the midst of Leyla's blissful moments, I couldn't help but harbor doubts about her husband's true intentions."
    scene v18-278
    b_ "While the world celebrated my daughter's happiness, my gaze often caught his lingering glances, filled with a desire that made my skin crawl."
    b_ "It was as if he couldn't help himself, his eyes boring into mine with a lustful hunger that sent shivers down my spine."
    b_ "At times, he dared to wink at me, a mischievous smile playing on his lips as if to taunt me with his secret desires."
    scene v18-279
    b_ "I found myself caught in this silent exchange, unsure whether to confront the truth or dismiss it as mere imagination."
    b_ "His actions fueled my suspicions, and a gnawing unease settled within me, casting a shadow over Leyla's joyous moments."
    scene v18-280
    b_ "In those stolen glances and fleeting smiles, I saw a side of him I had never known before—a side that left me questioning the authenticity of his love for our daughter. "
    b_ "The doubt festered within me, a poisonous seed planted in the midst of celebrations, tainting the happiness that should have been unblemished."
    scene black with dissolve
    b_ "In the dead of the night, my patience worn thin, I found myself shouting at Kamil, driven to the edge by his foolish actions."
    scene v18-281 with dissolve
    b_ "The frustration within me erupted like a volcano, spewing forth threats and anger that echoed through the silence of our home."
    b_ "I warned him, reminding him of the loss he risked if he dared to confront me."
    scene v18-282
    b_ "Kamil, cowed by my fury and lacking the strength to stand up to me, never dared to challenge my wrath."
    b_ "My lack of respect for him only made it easier to shut him down, to banish him from our shared space."
    b_ "That night, I cast him out of our bedroom, relegating him to the solitude of the living room sofa."
    scene v18-283 with fade
    b_ "In the darkness, my voice reverberated with a stern finality, a declaration that my will would not be questioned."
    b_ "It was a small victory, a feeble attempt to regain control in a world where I felt increasingly adrift."







    $ renpy.end_replay()
    $ persistent.cuck_unlocked = True





















    scene black with Dissolve(3)
    ""
    centered "{size=+120}Kamil's Struggle for Control {/size}" with Fade(0.5, 0.5, 5)


    $ kamilstopspoladtouchbanu = False
    $ kamilstopspoladbanugobedroom = False
    $ kamilshowbanuwhoistheman = False
    $ kamiltakethebetabdul = False
    $ kamilgetsomebeer = False
    $ kamilobeybanugetnaked = False
    $ kamilshowbanuwhoisboss = False





    scene black with dissolve
    "..."
    play music "audio/intro.mp3"
    scene v19-1 with dissolve
    "Kamil slouched on the sofa, feeling like a total loser."
    "His mind was all over the place, like a scrambled puzzle he couldn't solve."
    "Banu, his beloved wife, was changing, and not in a good way. "
    "First, she goes and gets that boob job without even consulting him, like she's the boss of her own body and he's just some side character."
    "Then she starts doing whatever she wants, not giving a damn about how he feels."
    scene v19-2
    "It's messing with his head, seeing her chatting up other dudes like it's no big deal."
    "He thinks about other men fucking his religious wife."
    "Is he not enough for her anymore?"
    "Does she even care about their relationship?"
    "He's starting to feel like he's losing control, like he's just drifting along while she's charting her own course."
    k_ "Man, what the hell's going on? Banu used to be my ride or die, but now she's off doing her own thing like I'm just some random dude."
    k_ "Nah, I can't let this slide. I gotta step up, take charge of this situation. "
    k_ "Can't just sit here feeling sorry for myself. Time to have a real talk with Banu, lay it all out on the table."
    k_ "Cause losing her ain't an option, and if I wanna get back in control, it starts with me."
    scene v19-3
    stop music
    play sound "voices/doorbell.mp3"
    "Kamil's heart skipped a beat as the doorbell rang, breaking the heavy silence of the room."
    "He hesitated for a moment, then dragged himself off the sofa to see who it was."
    scene v19-4 with fade
    "When he opened the door, there stood Polad, a smirk plastered across his face."
    p "Hey there, Kamil."
    "Polad said, his grin widening as he caught sight of Kamil's expression."
    p "Just thought I'd drop by, see how you and Banu are doing."
    scene v19-5
    play music "audio/tension.mp3"
    "Kamil's jaw clenched at the mention of Banu's name."
    "He knew there was something between Polad and her, could feel it in his gut, but he kept his cool, nodding curtly in response."
    k "Yeah, we're doin' fine."
    scene v19-6
    "As they made their way to the table, Kamil's mind was racing."
    "He sensed that there was more to Polad's visit than just checking in."
    "The way he grinned, the casual mention of Banu's breast surgery—it all felt off."
    p "So, I heard Banu got herself some new upgrades."
    scene v19-7
    "Kamil's grip tightened on the edge of the table, his suspicions growing stronger with each passing second."
    k "Yeah, she did."
    "But Kamil could feel the anger bubbling up inside him, a primal urge to lash out at the man sitting across from him."
    "Deep down, he wanted to confront Polad, demand answers, maybe even throw a punch or two. But he knew he had to keep his cool, play it smart."
    "Banu wouldn't want him causing a scene."
    k "Listen, Polad, it's been real nice catchin' up, but I think it's time for you to head out."
    scene v19-8 with dissolve
    stop music
    "Kamil's heart sank as Banu appeared in the room, in revealing black nightwear that left little to the imagination."
    "His jaw dropped as she sauntered over to the table, a mischievous grin playing on her lips."
    scene v19-9 with dissolve
    "And when she took a seat next to Polad, greeting him with a casual 'hi,' Kamil felt like the ground had dropped out from beneath him."
    "He couldn't believe what he was seeing."
    "His own wife, sitting there next to Polad, practically flaunting herself in front of him."
    k "Banu, what the hell?"
    scene v19-10
    "Banu's eyes blazed with anger as she watched Kamil's reaction."
    "She couldn't believe his stupid behavior, and with each passing moment, she felt her respect for him dwindling even further."
    "In her mind, he wasn't acting like a husband anymore—he was just trash."
    b "Seriously, Kamil?"
    b "You're gonna act all jealous and possessive now?"
    k "Jealous? You're sitting here practically half-naked next to my so-called friend! What do you expect?"
    p "Hey! Can you just lower your voice a bit? It's annoying."
    p "Come on, Kamil, you're just making a fool of yourself."
    k "You don't know what you're talking about, Polad. This ain't right."
    scene v19-11
    b "Ignore him, Polad. He's just being his usual insecure self."
    "Polad grinned back at Banu, leaning in closer to her. "
    p "Don't worry, babe, I know how to handle him."
    b "So, Polad, what do you think of the new look?"
    scene v19-12
    "Polad's eyes lit up with his gaze lingering on Banu's curves."
    p "Damn, girl, looking good."
    p "You know, Banu, I always thought you were smoking hot, but this new upgrade? Damn, it's like you've reached a whole new level."
    b "Oh, stop it, Polad. You're making me blush."
    "Kamil's heart sank as he watched Polad's audacity unfold before him. His fists clenched at his sides, his mind racing with a mix of anger, betrayal, and fear."
    "Polad's voice was low and suggestive as he leaned in closer to Banu, his eyes smoldering with desire."
    p "Hey, Banu, do you mind if I... you know, touch them a bit? Just to see how they feel?"
    "Banu's response was a playful giggle, her gaze locked with Polad's as she nodded in agreement."
    b "Sure, why not? Knock yourself out."
    "The words hit Kamil like a sledgehammer to the chest. He couldn't believe what he was hearing—his own wife, willingly allowing another man to touch her."
    play music "audio/tension.mp3"


    menu:
        "Let him touch Banu":
            $ renpy.block_rollback()
            $ kamilstopspoladtouchbanu = False
            "But as much as he wanted to protest, to put a stop to this madness, fear held him back."
            "Fear of Polad's dominance, fear of what he might do if Kamil dared to challenge him."
            scene v19-14 with hpunch
            "So, he stood there, frozen in place, his voice trapped in his throat as Polad reached out a hand towards Banu's surgically enhanced breasts."
            "Banu let out a soft sigh of pleasure as Polad's fingers brushed against her skin."
            p "Damn, Banu, they feel even better than they look."
            b "Don't worry, you can go harder."
            p "Sure."
            scene v19-15
            b "Ahhh.."
            "Banu let out a soft moan as Polad grabbed her right breast firmly and squeezed it."
            b "Wow! You know what you are doing."
            "As Kamil watched helplessly from the sidelines, a sense of shame washed over him."
            "He knew he should've put a stop to this, should've stood up for himself and his marriage."
            "But in that moment, all he could do was swallow his pride and let Polad have his way."
            "As Polad withdrew his hand, a triumphant smirk playing on his lips, Kamil felt a sense of defeat wash over him."
            scene black
            "Kamil's anger simmered beneath the surface, a raging inferno threatening to consume him as he watched Polad's boldness escalate. Enough was enough."
        "Stop him":





            $ renpy.block_rollback()
            $ kamilstopspoladtouchbanu = True
            "Kamil's anger simmered beneath the surface, a raging inferno threatening to consume him as he watched Polad's boldness escalate. Enough was enough."
            scene v19-13
    k "Hey, Polad, that's it!"
    "Kamil's voice cracked with fury, his fists clenched at his sides as he stood face to face with the intruder."

    scene v19-16 with fade
    "Polad raised an eyebrow, a smirk playing on his lips."
    p "What's your problem, Kamil? Can't handle a little fun?"
    k "That ain't fun, that's disrespecting my wife!"
    k "You don't get to touch her like that!"
    p "Or what? You gonna do something about it?"
    scene v19-17
    "As tensions between Polad and Kamil reached a boiling point, the air crackled with hostility. "
    p "You wanna play tough, Kamil?"
    p "You don't know who you're messing with."
    p "I'll tear you apart right here, right now!"
    "Kamil felt a cold shiver run down his spine at Polad's threat, his heart pounding in his chest."
    "He knew he was no match for Polad in a physical confrontation."
    b "Stop it, both of you!"
    "With a heavy heart and a sense of defeat weighing him down, Kamil took a step back."
    k "Fine, Polad, you win."
    p "That's what I thought."
    p "You're lucky I don't tear you apart right here."
    b "Enough, both of you. This is getting out of hand."
    "But she didn't move to intervene, and Kamil knew why."
    "He could see the fear in her eyes, the uncertainty about what would happen next."
    "With a heavy sigh, Kamil swallowed his pride and backed down. He knew he had no choice but to obey Polad's commands—for now."
    p "Now you stay here and I will go to your bedroom with Banu."
    p "We have a secret matters to talk about. Do you understand?"
    k "What?"
    p "You just sit tight and mind your own business. This is between me and Banu."
    scene v19-18 with fade
    k_ "Damn it."
    k_ "What the hell am I supposed to do now?"
    k_ "I can't just sit here and let them have their little pow-wow."
    scene v19-19
    "As Polad and Banu made their way towards the bedroom, Kamil strained to hear their conversation, his ears pricked with anticipation."
    "Polad was grabbing Banu's body and squeezing it with his body and hands."
    p "Did you see the look on his face?"
    p "What a loser."
    "Banu's laughter floated back to Kamil, a cold and mocking sound that sent a shiver down his spine."
    b "He's so pathetic, always getting in the way."




    menu:
        "Stop them":
            $ renpy.block_rollback()
            $ kamilstopspoladbanugobedroom = True
            scene black
            "Kamil's frustration reached its breaking point as he heard Polad and Banu's demeaning conversation."
            "With a surge of anger, he couldn't hold back any longer."
            k "Wait, you fuckers!"
            scene v19-20 with dissolve
            k "What the hell do you think you're doing?"
            b "What's your problem?"
            p "You got a lot of nerve barging in here like that."
            k "My problem? My problem is you two talking trash about me behind my back!"
            p "You're just jealous, Kamil. Jealous that Banu's finally seeing you for the loser you really are."
            k "I'm not jealous, I'm sick of your crap!"
            k "I'm your husband, bitch!"
            k "You goddamn traitor!"
            "Banu's eyes widened in shock at the venom in Kamil's words, but before she could respond, Polad's temper flared. "
            "With a swift motion, he raised his hand and delivered a resounding slap across Kamil's face."
            scene v19-21 with hpunch
            "The sound echoed through the room."
            "Even Banu, shocked by the sudden violence, recoiled in horror."
            "Kamil staggered back, his cheek stinging with the force of the blow."
            scene v19-22
            b "Polad, stop!"
            "As Kamil felt the searing pain in his cheek and tasted the metallic tang of blood, a cold realization washed over him."
            "With a trembling hand, Kamil gingerly covered his throbbing cheek, his eyes downcast as he silently obeyed Polad's command."
            "He couldn't bring himself to meet Banu's gaze, knowing the disappointment and betrayal that would be reflected in her eyes."
            scene v19-23
            "Polad's voice cut through the tense silence, authoritative and commanding."
            p "Remember this, Kamil."
            p "You never shout at a lady when I'm around. Got it?"
            "Kamil nodded mutely, his throat tight with a mixture of fear and humiliation."
            "He knew he had no choice but to comply, to swallow his pride and bow his head in submission."
            scene v19-24 with dissolve
            "And with one final glance of contempt at Kamil, Polad turned on his heel and left the room."
            "As the door closed behind him, Kamil felt a wave of relief wash over him, mingled with a sense of resignation."
            scene v19-25 with fade
            stop music
            "As the door clicked shut behind Polad, Kamil remained frozen in place, his hand still pressed against his throbbing cheek."
            "Banu's voice cut through the silence, dripping with scorn and disdain."
            b "Well, look at you, Kamil."
            b "Afraid of a real man like Polad, aren't you?"
            b "Can't even stand up for yourself against a guy like Polad. What kind of man are you?"
            b "You're nothing but a coward."
            "The words pierced Kamil's heart like daggers, fueling the fire of his anger and frustration."
            "But he refused to give Banu the satisfaction of a response."
            "He wouldn't stoop to her level, wouldn't let her see how deeply her words wounded him."
        "Let them go":



            $ renpy.block_rollback()
            $ kamilstopspoladbanugobedroom = False
            stop music

            jump polad_fuck_banu_kamil_bedroom_cuckroute



label polad_fuck_banu_kamil_bedroom_cuckroute_continue:

    scene black with dissolve
    play music "audio/intro.mp3"
    "..."
    "After a few days..."
    "Kamil lay on the sofa, his body weighed down by exhaustion."
    "He had spent countless nights on the unforgiving sofa, his mind plagued by thoughts of betrayal and heartache."

    scene v19-39 with dissolve
    "Sleep had become a fleeting luxury, always just out of reach, teasing him with the promise of respite."
    "Banu's footsteps echoed softly on the floorboards as she approached Kamil, a sense of contempt simmering beneath her calm exterior."
    scene v19-40
    "She held the wine glass with a tight grip, her knuckles turning white with the intensity of her emotions."
    "With a cold resolve, Banu raised the wine glass higher, her hand trembling with anticipation. "
    scene v19-41
    "The wine sloshed dangerously close to the rim, a silent threat poised to shatter the fragile peace of Kamil's sleep."
    "Just as she was about to let the crimson liquid cascade down onto his face, a flicker of doubt flashed across Banu's features."
    "Was this really the man she wanted to become?"
    "Kamil didn't deserve her mercy—not after what he had done to her."
    scene v19-42
    "With a final, decisive movement, Banu tilted the wine glass, watching with satisfaction as the liquid began to spill over the edge, inching closer and closer to Kamil's face."
    "Kamil jolted awake with a start as the wine splashed across his face, his eyes flying open in shock and fury."
    scene v19-43 with fade
    k "What the hell, Banu? Are you outta your mind?"
    b "I didn't mean to, Kamil. It was an accident!"
    k "An accident? Yeah, right! You think this is funny, huh? Messing with me while I'm tryin' to sleep?"
    b "I don't know, I guess I lost my head for a moment."
    k "Lost your head? More like lost your damn mind! You think this is how you treat your husband?"
    scene black
    "Banu's frustration boiled over, her voice rising to a crescendo as she unleashed her pent-up anger on Kamil."
    scene v19-44
    b "You know what, Kamil? It serves you right! You're just a sorry excuse for a man!"
    k "What? Banu, what the hell are you talkin' about?"
    b "You heard me, Kamil. You're a loser, a pathetic excuse for a husband. You think you can just lay around all day, while I do everything? Well, think again!"
    scene v19-45
    b "I'm sick and tired of carrying this relationship on my own. I deserve better than a sorry-ass cuck like you!"
    k "Oh, so now it's my fault, huh? You think I asked for this? You're the one who's been messin' around behind my back!"
    b "Yeah, well maybe if you were more of a man, I wouldn't have to look elsewhere!"
    k "You don't get to talk to me like that, Banu! I'm not the one who—"
    scene v19-46 with hpunch
    "But before he could finish his sentence, Banu's hand lashed out, the sound of her slap echoing through the room like a thunderclap."
    b "That's for being a sorry excuse for a husband! You think you can just stand there and play the victim? Well, you've got another thing coming!"
    menu:
        "Don't say anything":
            $ renpy.block_rollback()
            $ kamilshowbanuwhoistheman = False
            scene v19-47
            stop music
            b "You think I don't see through your sorry act? Always playing the victim, never taking responsibility for your own mess."
            b "You're nothing but a loser, Kamil. A weakling who can't even stand up for himself."
            b "I bet you like being treated like trash, don't you? That's the only explanation for why you let me walk all over you."
            b "You disgust me, Kamil. I can't believe I ever thought you were worth a damn."
            b "You know what? I'm done wasting my breath on you. From now on, you can just sit there and stew in your own sorry mess."
        "Show her who is the man in the house":






            $ renpy.block_rollback()
            $ kamilshowbanuwhoistheman = True
            stop music
            jump kamil_show_banu_who_is_man




label kamil_show_banu_who_is_man_continue:

    scene black with Dissolve(3)
    ""
    centered "{size=+120}Backgammon with friends...{/size}" with Fade(0.5, 0.5, 5)

    scene black with Dissolve(3)
    ""
    scene v19-62 with dissolve
    ab "Come on, Kamil, you gotta step up your game. You're losing!"
    k "I'll show you, Abdul. Just you wait."
    far "Man, you guys are too serious about this game. Just relax and enjoy."
    ab "Says the guy who's been sitting there smoking all night."
    far "Hey, someone's gotta keep the vibes chill, right?"
    k "Farhad's right, Abdul. Don't stress too much. It's just a game."
    scene v19-63
    ab "Man, can you believe Kamil's moves? He's playing so weak tonight."
    far "Yeah, Kamil, what's up with that? You're usually the king of this game."
    k "Oh, come on, guys. Just because I'm having an off night doesn't mean you have to rub it in."
    ab "Aw, don't be a sore loser, Kamil. We're just having some fun."
    far "Yeah, lighten up, man. It's all in good spirits."
    scene v19-64 with fade
    play music "audio/softromanticsex.mp3"
    "Banu suddenly entered the room with a confident stride, her gaze meeting Kamil's friends."
    b "Hey, guys! Didn't mean to interrupt your game."
    scene v19-65
    "As Banu's presence injects a jolt of excitement into the room, Kamil's friends can't help but be taken aback by her bold fashion choice."
    "And as they exchange glances with each other, they can't shake the feeling that tonight's game just got a whole lot more interesting."
    scene v19-66
    ab "Uh... hi, Banu."
    far "Hey, Banu... nice outfit."
    b "Thanks, Farhad. Just felt like switching things up a bit."
    ab "Damn, did you see that, Farhad? Banu's looking fine tonight."
    far "Yeah, she's definitely turning up the heat in here."
    b "You boys sure know how to flatter a girl."
    scene v19-67
    k "Banu, what's with the outfit? You're being way too extra."
    b "Oh, come on, Kamil, loosen up. You know you love it when I spice things up."
    k "Nah, it ain't about me, it's about respect. You can't just roll in here dressed like that and expect everyone to be cool with it."
    b "Oh, don't be shy, sugar."
    scene v19-68
    far "You know, Banu, I've always thought you were smoking hot. Kamil's a lucky guy."
    ab "Yeah, but I bet it would feel even better if we had a turn with you, huh?"
    k "Abdul!"
    b "Oh, you boys are too much. But I think I'll stick with Kamil for now."
    k "That's enough, both of you. Back off."
    far "Hey, Kamil, we're just joking around, man. Chill out."
    k "It ain't a joke when you talk about my wife like that. Show some damn respect."
    scene v19-69
    ab "Hey, Kamil chill. I have an idea."
    ab "Let's make this game interesting. If I win, your wife dances for us. But if you win, I'll give you some cash."
    k "Nah, man, what is wrong with you guys?"
    ab "Afraid your wife might have more fun dancing for us than being with you?"
    k "Shut your mouth, Abdul. That's crossing a line."
    b "Kamil, it's fine. I don't mind."
    menu:
        "Stop this madness":
            $ kamiltakethebetabdul = False
            $ renpy.block_rollback()
            stop music
            scene black
            k "No, Banu. You ain't doing it. "
            b "What?"
            k "Get out of the room now!"
            scene v19-70 with fade
            b "You are being rude. Why do you treat me like this in front of our guests?"
            k "Get out of the room, now."
            scene v19-71
            b "Fine, Kamil. But this ain't over."
            "With a frustrated huff, Banu storms out of the room, leaving Kamil seething with anger at his friends' disrespectful suggestion."
            "Despite Banu's willingness to comply, Kamil refuses to allow her to be objectified in such a manner. "
            "And as he watches her leave, he knows that their relationship has been tested once again, but he remains steadfast in his determination to stand up for what he believes is right."
        "Play the game":





            $ kamiltakethebetabdul = True
            $ renpy.block_rollback()
            scene black
            "Reluctantly, Kamil agrees to take the bet under the pressure of his friends' insistence."
            scene v19-72 with dissolve
            "As the game begins, tensions run high in the room, with Kamil feeling increasingly uncomfortable about the situation."
            ab "Alright, Kamil, let's do this. Winner takes all."
            far "Yeah, and loser has to watch Banu's dance."
            "Banu, sensing Kamil's unease, decides to play along with their scheme."
            "With a seductive smile, she looks at Kamil's friends, her gaze filled with allure."
            b "Looks like it's gonna be an interesting game, boys. Who's ready for some fun?"
            scene v19-73 with fade
            ab "Come on, baby, give me some luck!"
            far "Man, this is getting intense. I can't handle the suspense!"
            k "Just roll the damn dice already."
            scene v19-74 with hpunch
            "He gives them a vigorous shake before letting them fly across the board, the clatter of the dice echoing in the room as they come to a stop."
            "The room falls silent as everyone leans in to see the result, their hearts pounding with anticipation."
            ab "Yes! Double sixes, baby! I win!"
            scene v19-75
            far "Unbelievable! You did it, Abdul!"
            b "Congratulations, Abdul. You played well."
            ab "Looks like I won more than just the game, huh? Kamil's wife is mine now for a few minutes!"
            far "Man, Kamil, you better watch out. Looks like Banu's found herself a new man!"
            scene v19-76
            "As Abdul revels in his victory, Kamil sits in stunned silence, the weight of defeat heavy upon his shoulders."
            "He watches in disbelief as Banu, with a seductive glance towards Abdul, leans back on the sofa, spreading her legs ever so slightly, a subtle invitation in her gaze."
            b "Well, Abdul, looks like you're the lucky winner. Ready for your prize?"
            ab "You bet I am, Banu. Show us what you've got."
            "Kamil's heart sinks as he realizes the extent of his loss. "
            k "This ain't right, Banu. You don't have to do this."
            b "Don't worry about him, Abdul. Let's have some fun."
            scene v19-77 with fade
            b "Well, boys, looks like I'm all yours now."
            "With a playful smile, Banu stands up, her hands moving to her head as she strikes a seductive pose. "
            "Her curves accentuated by her provocative attire, she sways her hips enticingly, her gaze locking with Abdul and Farhad's."
            b "So, what's it gonna be? Shall we have some fun?"
            "Abdul and Farhad exchange knowing glances, their eyes filled with anticipation as they watch Banu's every move."
            scene v19-78 with fade
            "Getting down on all fours, she arches her back, her gaze fixed on Abdul with a playful glint in her eyes."
            "Slowly, she raises her right leg up in the air."
            ab "Damn, Banu, you're a real firecracker, aren't you?"
            far "I'll say! Kamil, you sure know how to pick 'em!"
            b "Come on, boys, don't be shy. Who wants a closer look?"
            scene v19-79
            "With a sultry smile, she arches her back even further, fully getting on all fours and positioning herself provocatively, her gaze lingering on Abdul with an enticing allure."
            "She points her shapely ass towards Farhad, swaying it teasingly."
            far "Whoa, Banu, you're really going all out!"
            ab "Looks like Kamil's gonna have some competition for your attention, huh?"
            b "What do you say, Farhad? Are you ready for some fun?"
            scene v19-80 with fade
            "With a coy smile, she stands up on the table, her back facing Farhad and Abdul."
            "Slowly, she begins to move to an imaginary rhythm, her hips swaying seductively as she runs her hands sensually over her body."
            show banudancingabdulanimation
            ab "Now, this is what I'm talking about!"
            far "Damn, Banu, you know how to put on a show!"
            "Kamil can't bear to watch as his wife dances for his friends, his heart heavy with a mix of anger, jealousy, and betrayal. "
            "He feels like he's losing control of the situation, powerless to stop Banu from flaunting herself in front of Abdul and Farhad."
            b "Enjoying the view, boys?"
            "Her voice is laced with seduction as she continues to dance, her every move designed to captivate and entice."
            scene v19-81
            "And as Abdul and Farhad watch with eager anticipation, Kamil can't help but wonder how everything had gone so wrong, and if there's any way to salvage what's left of their relationship."
            "Kamil's gaze remains fixed on Banu's mesmerizing movements, but his expression is clouded with bitterness and resentment."
            "He watches as she dances provocatively for Abdul and Farhad, his heart heavy with a mix of anger and betrayal."
            scene v19-82
            ab "Damn, Banu, you're driving me crazy with those moves."
            far "Yeah, baby, shake it for us. Show us what you've got."
            scene v19-83
            b "You like that, boys? You want more?"
            far "Damn, Banu, you're making me hard down there."
            b "Is that so, Farhad? Maybe I'll have to dance a little closer then."
            ab "Don't leave me out, Banu. You know you're driving me wild too."
            b "Oh, Abdul, I wouldn't dream of it. Maybe I'll have to dance for you next."
            scene v19-84
            "Banu, feeling a bit winded from her dance, decides to take a break and sits down between Abdul and Farhad."
            far "You're something else, Banu. I can't get you out of my mind."
            ab "Yeah, you've got us both under your spell, sweetheart."
            "As Banu and Kamil's friends continue to exchange dirty words, Kamil can't help but feel a pang of jealousy deep in his chest."
            scene v19-85
            far "Banu, I can't take it anymore. I want you in my bed right now."
            ab "Yeah, you've got us both worked up, baby. We need you, right here, right now."
            b "Oh, boys, you're making me blush. But you know I can't resist a little bit of fun."
            k "What?"
            scene v19-86
            "Abdul whispered something lewd into Banu's ear, a sly grin on his face."
            k "What did he say, Banu?"
            b "Oh, just some naughty little remark. Your friend Abdul is quite the dirty talker, isn't he?"
            scene v19-87 with fade
            stop music
            ab "Hey, looks like we're running low on beer. Kamil, why don't you head out to the store and grab some more?"
            k "What's the rush? Why all of a sudden?"
            "Kamil's eyes narrow as he notices Abdul's hand wandering, a surge of jealousy coursing through him."
            k "And what's with your hand, Abdul? Keeping it busy while you send me off to the store?"
            b "Kamil, don't be ridiculous. Abdul was just... um... helping me get comfortable."
            k "I'm not buying it, Banu. What's really going on here?"
            menu:
                "Go get some beer":
                    $ kamilgetsomebeer = True
                    $ renpy.block_rollback()




                    jump abdulfarhadfuckbanu_bathroom
                "Throw them out of the house":





                    $ kamilgetsomebeer = False
                    $ renpy.block_rollback()
                    play music "audio/tension.mp3"
                    scene v19-87
                    ab "Come on, Kamil, you're overreacting. We just need some more beer, that's all."
                    b "Please, Kamil, don't be like this. Abdul was just joking around. There's nothing going on."
                    scene black
                    "But Kamil's anger simmers beneath the surface, his jealousy and suspicion reaching a boiling point."
                    scene v19-89
                    "He refuses to be placated by their feeble attempts at reassurance, his trust in them shattered."
                    k "You think I'm stupid? Get out. Both of you."
                    "Abdul and Farhad exchange a worried glance as they realize that Kamil isn't going to back down."
                    scene v19-90
                    "With a resigned nod, they reluctantly get up from the sofa and head towards the door."
                    ab "Fine, Kamil. We're leaving. But you're making a big mistake."
                    b "How dare you, Kamil? You had no right to throw them out like that!"
                    k "I won't stand for this, Banu. I won't let you betray me like that."
                    scene black
                    "As the door slams shut behind them, Kamil is left alone in the room, his heart heavy with a mix of betrayal and anger."
                    stop music



label abdulfarhadfuckbanu_bathroom_continue:


    scene black with dissolve
    "..."

    if agreetoruslanoffer == True:


        scene v19-111 with dissolve
        play music "audio/action.mp3"
        "As Ruslan approaches, Kamil's mind races with conflicting emotions."
        k_ "Damn it, why does this keep happening?"
        k_ "I should be able to sleep in my own bed, but Banu... Banu won't let me. "
        scene v19-112
        k_ "She treats me like I'm nothing, like I'm not even worthy of sharing a bed with her."
        k_ "But Ruslan... Ruslan doesn't need to know about this. "
        k_ "He's just a boy, he shouldn't have to deal with his parents' problems."
        scene v19-113
        r "Dad, why are you sleeping on the sofa? Is everything okay?"
        k "Oh, hey Ruslan. Yeah, everything's fine. I... I just fell asleep here by accident, that's all."
        r "But Dad, you never sleep on the sofa and this happens often recently. Are you sure everything's okay?"
        k "Yeah, yeah, I'm sure. Just... had a long day, you know? Thought I'd take a little nap here. No big deal."
        r "Dad, I know this is because of Banu again, isn't it? She's treating you like this, isn't she?"
        k "Ruslan, no, it's not like that."
        r "You shouldn't have to sleep on the sofa because of her. I'm going to go talk to her and tell her to stop treating you like this!"
        k "No, Ruslan, wait! It's not that simple. Please, just trust me on this. I'll handle it, okay? I promise."
        r "You just wait..."
        scene black with dissolve
        "..."
        scene v19-114 with dissolve
        "Ruslan entered the room, his expression a mix of anger and determination."
        r "Banu, we need to talk."
        b "Oh, hello Ruslan. What brings you here?"
        scene v19-115
        r "I want to know why Dad is sleeping on the sofa again. Is it because of you?"
        b "And what if it is?"
        r "You can't keep treating Dad like this."
        b "Oh, can't I? Your father knows his place, Ruslan. And if he doesn't like it, well, that's his problem."
        r "You can't keep disrespecting Dad like this."
        b "Oh, but I can, Ruslan. Your dear father made his choices, and now he has to live with them."
        r "You think you can control Dad, but I know the truth about you, Banu. You're nothing but a slut wife, and Dad deserves better."
        b "Oh, is that so? And what exactly do you think you know about me, Ruslan?"
        r "I know all about your affairs, your promiscuous behavior. Dad may be blind to it, but I'm not."
        scene v19-116
        b "How dare you come in here and accuse me of such things! You and your dad are nothing but trash, do you hear me? Trash!"
        b "Your father chose me, and now he belongs to me. He does what I say, when I say it, and there's nothing you can do about it!"
        scene v19-117
        r "You can shout all you want, Banu, but it won't change the truth. "
        r "Dad deserves respect, and I won't stand by and let you treat him like this."
        b "Respect? Your father gave up any right to respect the moment he married me. Now get out of my sight before I do something we'll both regret!"
        r "I won't let you get away with this, Banu. Dad deserves better, and I'll make sure he gets it, one way or another."
        scene v19-118 with fade
        b "You think you can stand up to me, Ruslan? You forget our little secret, don't you?"
        r "What... What are you talking about?"
        b "Oh, don't play dumb with me, Ruslan. You and I both know what happened between us."
        b "And if you don't do as I say, I'll be more than happy to remind your dear father of our little affair."
        scene v19-119
        r "You wouldn't dare.."
        b "Try me, Ruslan. I'm not afraid to use whatever means necessary to get what I want. And right now, what I want is your obedience."
        r "What do you want from me?"
        b "I know you are rock hard right now by looking at my breasts. Drop your shorts and show me your cock right now."
        r "What?"
        b "That's right, Ruslan. Show me what you're hiding."
        scene v19-120 with fade
        stop music
        play music "audio/softromanticsex.mp3"
        "Feeling humiliated and trapped, he reluctantly complies, removing his shorts and revealing his already aroused member."
        b "My, my, Ruslan. Look at you, so eager and ready to please."
        "Feeling exposed and vulnerable, Ruslan shifts uncomfortably under Banu's gaze."
        b "Oh, don't be shy now, Ruslan. After all, we both know what you want."
        b "And lucky for you, I'm feeling generous today."
        scene v19-121
        r "I-I can't do this...He can come any minute."
        b "Let him come. I couldn't care less. In fact, it might even make things more exciting, don't you think?"
        r "Banu, please, we can't do this. Dad will be devastated if he finds out."
        b "Oh, please. Your dad is too wrapped up in his own little world to even notice what's going on under his nose. Trust me, he won't be interrupting us anytime soon."
        scene v19-122 with fade
        "With a seductive grin, she sheds her clothes swiftly, leaving her completely naked, her form illuminated by the soft light in the room, as she kneels provocatively on the bed."
        b "Well, Ruslan, what do you think of the view?"
        r "Banu, what are you doing? We can't... this is..."
        b "Shh, Ruslan. Don't overthink it. Sometimes you just have to go with the flow and enjoy the moment."
        r "But... but this isn't right. Dad..."
        b "Go on, Ruslan. Show me how much you want me. Touch yourself."
        b "Stroke your big cock for me."
        scene v19-123
        b "Forget about your dad for now. Right now, it's just you and me."
        b "Well, well, well... Looks like someone's excited to see me, huh, Ruslan?"
        r "Banu, please..."
        b "Oh, come on, Ruslan. No need to be shy. We're all adults here. And I must say, I'm quite flattered by your reaction."
        b "Wrong? Or just a little bit naughty? Don't pretend like you're not enjoying yourself, Ruslan. I can see how hard you are."
        scene v19-124
        "With a sultry smirk, she spreads her legs wide on the bed, exposing herself fully as she begins to pleasure herself."
        b "That's it, Ruslan. Keep going. I want to see just how much I've got you worked up."
        "He continues to stroke himself, his arousal building with each passing moment as he watches Banu's provocative display."
        scene v19-125
        b "Mmm, that's it, Ruslan. Don't stop. I want you to keep going until you can't hold back anymore."
        b "You know, Ruslan, I've always had a thing for you. Ever since I saw your fully grown dick."
        r "Banu, this is..."
        b "Oh, but it feels so right, doesn't it? Just imagine how good it would feel if we were together, Ruslan. No one to stop us, no one to judge us."
        show banuruslanmasturbatecuckroute
        stop music
        play music "voices/makeout.mp3"
        r "You're such a slut, Banu."
        b "That's it, Ruslan. Say it again. Say it louder."
        r "You're a slut, Banu. A filthy, fucking slut."
        b "Yes, Ruslan. That's what I am. Your dirty little slut."
        r "You're nothing but a whore, Banu. A dirty, fucking whore."
        b "And yet here you are, Ruslan. Enjoying every moment of it. Maybe you're not so different from your dad after all."
        r "I'm nothing like him. I'm better than him in every way."
        b "Prove it, Ruslan. Show me just how much better you are. Show me why I should choose you over him."
        stop music
        scene v19-126 with hpunch
        play music "audio/tension.mp3"
        "Kamil sudddenly enters the room his eyes widen in shock as he takes in the scene before him, his jaw dropping in disbelief. "
        k "What the hell is going on here?!"
        r "Dad, I... we..."
        scene v19-127
        k "What the fuck is going on here? Will you explain?"
        k "Banu! What is this?!"
        "With a smirk playing on Banu's lips, she meets Kamil's gaze with bold defiance, refusing to back down. "
        scene v19-128
        b "What does it look like, Kamil? Your son and I were just having a little bit of fun."
        k "Fun? This is sick, Banu. You're my wife, and he's my son."
        b "Oh, please. Don't act like you're so innocent, Kamil. You've been neglecting me for too long."
        b "It's only natural that I would seek attention elsewhere."
        scene v19-129
        b "You're nothing but a sorry excuse for a man, Kamil."
        b "Your own son has more backbone than you ever will, and let's face it, he's got a bigger package too."
        "Kamil's jaw clenches with fury, his patience wearing thin as Banu's words strike a nerve."
        b "Go on, Ruslan. Tell your father exactly what we were doing."
        r "I... I can't..."
        b "I said tell him, Ruslan. Don't make me repeat myself."

        scene v19-130
        "Stammering and unable to face his father's wrath, he finally blurts out the truth."
        r "We... we were just... masturbating, Dad. I swear..."
        b "He's listening to my orders now and you also will, Kamil. This is your only option."
        b "Now take your clothes off and show me your dick."
        menu:
            "Slap Ruslan":
                $ kamilobeybanugetnaked = False
                $ renpy.block_rollback()
                scene v19-131 with hpunch
                play sound "voices/slap.mp3"
                "Without a second thought, Kamil raises his hand and delivers a resounding slap across Ruslan's face."
                k "You disgusting little..."
                "Ruslan recoils from the force of the blow, his cheek stinging with pain as he stares up at his father in shock."
                scene v19-132
                k "You think you can corrupt my son like this?"
                k "You've crossed a line, Banu. And trust me, you're going to regret it."
                k "I won't tolerate this kind of behavior any longer."
                scene v19-133
                stop music
                "As Banu reflects on Kamil's reaction, she's struck by a sudden realization."
                "The fear and anger in his eyes were unlike anything she'd ever seen before."
                "In that moment, she understood the depth of his pain and betrayal."
            "Obey Banu and get naked":




                $ kamilobeybanugetnaked = True
                $ renpy.block_rollback()
                stop music


                jump banu_dominates_kamil_ruslan



label banu_dominates_kamil_ruslan_continue:

    scene black with dissolve
    "..."
    if killturan == False:

        play music "audio/action.mp3"
        scene v19-146 with dissolve
        "As Banu stepped into Turan's apartment, the dim light cast shadows across the room, adding to the tense atmosphere."
        t "Well, well, look who decided to pay me a visit. What brings you here, Banu? I didn't call you today."
        b "I couldn't resist the thought of seeing you again, Turan. I've been thinking about our last encounter quite a bit."
        scene v19-147
        t "I must say, I've been eager for a repeat performance. But what's the occasion? Not that I'm complaining, of course."
        b "Oh, you'll see. I have a little surprise in store for you tonight."
        t "I can't wait to find out what it is. But first, why don't we pick up where we left off?"
        b "You have no idea how much I've been craving your touch, Turan. I want you to fuck me so bad."
        t "Oh, I can certainly oblige, Banu. Consider it my pleasure."
        scene v19-148 with fade
        "Banu sprung into Turan's arms like a wildcat, their lips crashing together in a hot and heavy kiss. "
        "They stood there, locked in a passionate embrace, their bodies pressed together as if they couldn't get close enough."
        scene v19-149
        "Turan's grip tightened around Banu's waist, pulling her even closer as they lost themselves in the moment."
        "Their tongues tangled in a frenzy of desire, exploring each other's mouths with a hunger that couldn't be denied."
        "Banu's hands roamed over Turan's body, feeling the heat of his skin beneath her fingertips."
        b "Harder, Turan. Show me how much you want me."
        scene v19-150 with vpunch
        "Banu's seductive whispers fueled Turan's desire as he felt the heat between them intensify."
        "With a primal growl, he hoisted her up and threw her onto the sofa, his eyes smoldering with passion as he climbed on top of her."
        "Their bodies collided with a force that sent shivers down Banu's spine, igniting a firestorm of desire within her."
        scene v19-151
        t "You asked for it, sweetheart."
        b "Oh, yeah. Just like that. Take me."
        b "Come on, Turan, show me what you've got. I want it rough."
        t "You asked for it, babe."
        scene v19-152
        b "Yes, that's it. Don't hold back. Choke me."
        t "You like it rough, huh?"
        "Their dialogue echoed through the room, mixing with the sound of their heavy breathing and the intensity of their passion."
        "Little did they know, their encounter was about to take an unexpected turn as the sound of approaching sirens filled the air."
        t "What?"
        scene v19-153 with hpunch
        pol "Freeze! Hands where we can see them!"
        pol2 "You're under arrest for assault and battery. Anything you say can and will be used against you in a court of law."
        scene v19-154
        t "What? This is a misunderstanding!"
        b "You messed with the wrong woman, Turan."
        scene v19-155 with fade
        t "Let me go! You can't do this!"
        b "Seems like your luck ran out, Turan."
        ah "Looks like we've got everything we need, thanks to our little informant here."
        b "Just doing my civic duty, officer."
        scene v19-156
        b "Thanks for the backup, Ahmed. I couldn't have pulled this off without you."
        ah "No problem, Banu. We've had our suspicions about Turan for a while now."
        t "You set me up, Banu? How could you do this?"
        b "We knew he was up to no good, and when I saw him targeting vulnerable women in the neighborhood, I knew we had to take action."
        ah "With your testimony and the evidence we've gathered, he won't be causing any more trouble."
        t "You'll pay for this, Banu! You and your crooked cop friend!"
        scene v19-157
        b "Save your threats for the judge, Turan. You're going away for a long time."
        b "You thought you could get away with hurting me, didn't you?"
        scene v19-158
        t "You're a snake, Banu. You set me up!"
        b "No, Turan, you dug your own grave. And now, you're going to pay for it."
        t "You'll regret this, Banu! I'll make sure of it!"
        scene v19-159
        b "Save your breath, Turan. You're going away for a long time. And you deserve every second of it."
        b "You really thought you could outsmart me, huh? You played yourself, man."
        t "You think you're slick, huh? You're just a sneaky bitch!"
        b "Hey, don't hate the player, hate the game, right? You fell right into our trap."
        t "You'll regret this, Banu! I'll make you pay, just you wait!"
        b "Aw, come on now, Turan, don't be sore. It's not my fault you got caught slipping."
        "With her playful taunts, Banu was pushing all of Turan's buttons, reveling in his frustration as she flaunted her victory."
        "As Turan's threats grew louder, Banu remained cool and collected, knowing that she had outsmarted him at his own game."
        stop sound


    scene black with dissolve
    play music "audio/weakbanu.mp3"
    "..."
    scene v19-160 with dissolve
    "As Kamil stood there, seething with anger, Banu reclined on the bed, her demeanor oozing with dominance."
    "With a smirk playing on her lips, she traced lazy circles on Kamil's chest with her leg, a silent reminder of her control over him."
    scene v19-161
    b "What's the matter, Kamil? Can't sleep? Or is it that you can't stand the sight of me?"
    "Kamil's jaw clenched, his frustration palpable as he struggled to maintain his composure under Banu's teasing gaze."
    b "You know, Kamil, you're so predictable. Always so easy to rile up. It's almost too much fun."
    b "Tell me, Kamil, how does it feel to know that you're at my mercy? That you're nothing but a puppet on my strings?"
    k "..."
    b "That's right, Kamil. You're mine to control. And there's nothing you can do about it."
    scene v19-162
    b "You know, Kamil, I used to think you were a real man. But now? Now you're nothing but a pathetic excuse for one."
    b "I mean, look at you. Standing there like a lost little puppy, unable to do anything but obey my every command. It's almost sad, really."
    b "You're weak, Kamil. Weak and spineless. And you know what? It's no wonder I've lost all respect for you."
    scene v19-163
    b "Oh, look at that, Kamil. Seems like even your little friend here knows who's really in charge."
    b "You can't even get it up properly, can you? Pathetic."
    b "Face it, Kamil. You're nothing but a toy for my amusement. And right now? You're failing miserably."
    scene v19-164 with fade
    "Banu's movements around Kamil were predatory, her every step a calculated display of dominance."
    b "Look at you, Kamil. All bark and no bite. Can't even lift a finger to stop me."
    b "Thought you were a real man, but turns out you're just a joke. Can't even handle a woman like me."
    b "What's the matter, tough guy? Too scared to do something about it? Pathetic."
    scene v19-165
    b "Is it hard, Kamil? Knowing that your wife is a dirty whore but you cannot do anything about it?"
    b "You know, Kamil, when other men fuck me, it feels so damn good. They know how to handle a real woman."
    scene v19-166
    "Her voice was laced with mockery, her gaze piercing as she watched Kamil's reaction."
    b "They make me feel things you never could."
    b "They know how to satisfy a woman, unlike you."
    b "Face it, Kamil. You're just not man enough to handle me. And you never will be."
    scene v19-167
    "Banu's laughter echoed in the room, cutting through the tense air like a knife."
    b "Well, well, look at that! Little Kamil's all riled up, huh? Bet you're picturing me with those other men, aren't you?"
    b "Your dick is getting hard thinking about me with other men. Is that right?"
    scene v19-168
    b "Can't satisfy your own wife, but get all excited thinking about her with someone else. Pathetic!"
    b "You're such a joke, Kamil. Can't even control yourself when you know you're not enough for me."
    k "Enough, Banu! I'm tired of your games. I won't stand for this anymore."
    scene v19-169
    "But Banu's mocking laughter filled the room, cutting through Kamil's resolve like a blade."
    b "Oh, but sweetie, we're just getting started. From now on, I'll give the orders, and you'll obey like the obedient little husband you are."
    b "You're mine to command, Kamil. And you'll do whatever I say, whenever I say it. Got it?"
    b "Now be a good boy and lay down on the bed."
    "Banu's command hung heavy in the air, a stark reminder of Kamil's submissive position in their relationship."
    b "Get on the bed, Kamil. It's time for you to feel just how powerless you really are."

    menu:
        "Obey her":
            $ kamilshowbanuwhoisboss = False
            $ renpy.block_rollback()
            scene v19-179 with fade
            "Reluctantly, Kamil obeyed, his pride swallowed by the overwhelming force of Banu's dominance."
            "Banu hovered over him, her eyes filled with a mix of amusement and contempt."
            b "Now, lie back and watch as I pleasure you. After all, it's the least I can do for my pitiful husband."
            "With a mixture of shame and arousal, Kamil closed his eyes, succumbing to Banu's humiliating touch."
            scene v19-180
            b "Tell me, Kamil, do you like my new big breasts? Do they make you feel even more pathetic?"
            "Kamil's cheeks burned with embarrassment as he struggled to form a coherent response, his mind clouded by a mix of arousal and shame."
            k "Y-yes, Banu... t-they're... impressive..."
            b "Good. Maybe now you'll understand just how much better I am without you."
            stop music
            show banujerkoffkamilcuckroute
            play music "voices/makeout.mp3"
            b "Oh, you want to cum, do you?"
            b "Too bad, Kamil. You don't get to decide when you release that pathetic load."
            b "You'll cum when I say so, and not a moment sooner."
            "Kamil's frustration grew as Banu continued to deny him release, her words fueling his desire even further."
            k "Please, Banu... I need to cum..."
            b "You like that, Kamil? You like being at my mercy, begging for release like a pathetic little boy?"
            "Each stroke of her hand was agonizingly slow, drawing out Kamil's torment as he writhed beneath her touch, his need for release driving him to the brink of madness."
            b "You're mine to control, Kamil. Remember that. Your pleasure, your pain, it's all in my hands."
            stop music
            scene v19-181
            "Kamil's voice cracked with desperation as he pleaded with Banu, his pride crumbling in the face of her dominance."
            k "Please, Banu... I can't take it anymore. I need to cum... Please let me..."
            b "Begging already, Kamil? You're even weaker than I thought."
            b "But don't worry, I'll let you cum... when I'm good and ready."
            scene v19-182
            "Banu's gaze bore into Kamil's soul, her eyes dark pools of dominance as she stroked his cock with a deliberate slowness."
            "With each movement of her hand, she exerted control over him, pushing him closer to the edge of his restraint."
            scene v19-183
            b "You like that, don't you, Kamil? You're so weak for me... So desperate... It's pathetic."
            k "Please, Banu... I can't... I need to cum..."
            k "Please, Banu... I'll do anything... I'll be your slave... Just let me cum..."
            scene v19-184
            "Banu's lips curled into a triumphant smirk as she savored the sweet taste of victory over him."
            b "That's right, Kamil... You're my slave now... And you'll obey my every command."
            "As Banu's hand quickened its pace, Kamil felt the inevitable rush of release building within him, his body surrendering to her will."
            "Kamil's voice cracked with pleasure as he reached the peak of ecstasy, his release flooding forth under Banu's expert touch."
            scene v19-185 with vpunch
            play sound "voices/man3.mp3"
            k "Oh, Banu... I'm gonna... I'm gonna cum..."
            "With a final stroke, Banu pushed him over the edge, eliciting a guttural moan of satisfaction from Kamil as he climaxed, his essence spilling forth under her command."
            stop sound
            "Banu's satisfaction was palpable as Kamil's body shuddered with release. "
            scene v19-186
            "With a self-assured grin, she gazed down at him, reveling in her control over him and relishing the moment of dominance."
            b "That's it, Kamil. You're mine now."
            b "So, did you enjoy the show, Kamil? Watching me reduce you to nothing but a quivering mess?"
            scene v19-187
            k "You think you're so powerful, don't you? But you're just a manipulative coward."
            b "You're nothing but a shell of a man, Kamil. Weak, submissive, and utterly pathetic."
            b "Look at you, Kamil. So weak, so easily brought to heel. It's pathetic how I can make you cum with just a flick of my wrist."
            "Her words served as a reminder of her dominance, leaving Kamil feeling small and emasculated in her presence."
        "Show her who is the boss":




            $ kamilshowbanuwhoisboss = True
            $ renpy.block_rollback()
            stop music


            jump kamil_dominate_banu_bedroom



label kamil_dominate_banu_bedroom_continue:




    dev "{color=#000000}Thank you for playing! This is the end of this route in this version. Play again to discover more. If you enjoyed it, please {a=https://www.patreon.com/lustfulfantasy}support{/a} the development. Buy the full game(Early Access) on {a=https://store.steampowered.com/app/2505580/Life_in_Middle_East/}STEAM{/a} {/color}"
    hide screen faith
    hide screen angeldevil
    jump endings
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
