


label day6:
    scene black with fade
    centered "{size=+150}THE NEXT DAY{/size}" with dissolve
    scene black with dissolve
    with Pause(2)

    if streetguys == True:
        scene day5-92 with fade

        "{i} {color=#526168}It was the first time in her life that she was going to write a complaint letter to the police station.{/color}"
        "{i} {color=#526168}She was feeling awkward and nervous on the way to the police station. She wondered to herself whether or not she should return home and discuss last night's unpleasant happenings with her husband. {/color} "
        "{i} {color=#526168}However, she decided to keep it a secret from Kamil and handle it on her own. She had to be brave. And besides, she didn’t want to hear the same care-free response he gave after Leyla’s incident. {/color} "


        scene day5-93
        "{i} {color=#526168}The nervousness had faded away as quickly as it appeared after she took deep breaths and composed herself.{/color} "

        b "{i} {color=#526168}There's no way I'm letting this go. He won't be able to run away from the punishment waiting for him.{/color}"
        b "{i} {color=#526168}Not this time. {/color}"
        scene day6-1 with fade
        "{i} {color=#526168}Ahmed's room was rather dark. {/color}"
        "knock-knock* "
        ah "Come"
        scene day6-2
        pol "A woman named Banu wants to see you, Sir. She says you're waiting for her."
        ah "Let her in."
        "..."
        ah "Come in, Banu."
        scene day6-3
        "{i} {color=#526168}Banu was feeling comfortable in Ahmed's room because he’s always been a kind gentleman as a neighbor, unlike many Police Officers in this city.{/color} "

        scene day6-4
        b "I hope I won't take too much of your time."
        ah "I have plenty of time, especially for you. Please, sit down."
        scene day6-5
        ah "Now, let's talk about it first. Was it the first time this guy or guys have attacked you?"
        b "Yes. Nothing like this has happened before."
        ah "What do you know about these guys? Tell me all you know."
        b "I don't see them often, but approximately a week ago I saw two of them in the entrance of a building, and they were trying to… hit on me. I threatened to call the police. "

        ah "You're so brave, Banu."
        scene day6-7
        b "I'm sorry, but you don't know how mad they've made me. They're toxic to society and their behavior is just irritating. I will do anything to help you put him in prison."
        scene day6-6
        ah "Don't worry. We know how to deal with him and will capture him as soon as possible."
        ah "What time was it when you first met them?"
        b "Umm, about 1 am."
        ah "{i} {color=#526168}Coming home at 1 am? It seems she goes out a lot during late hours. I asked around about Banu this morning and there’s been recent gossip about her coming out of a single man's apartment at night. {/color} "

        ah "What about your husband? Does he know about this?"
        scene day6-8
        b "No. I didn't tell him anything. He’s so busy recently, and I didn't want to bother him with additional problems."
        scene day6-9
        ah "{i} {color=#526168}Coming home late and keeping secrets from your husband. How can a married woman come home after midnight? Probably, getting fucked by other men and coming home to your poor husband. {/color}"
        ah "{i} {color=#526168}Who would suspect a married hijab-wearing woman doing such things? {/color} "
        ah "Don't you think you're keeping too many secrets from your husband?"
        menu:
            "She answers him honestly":

                $ ahmedtease = True
                $ renpy.block_rollback()
                $ banubad += 1
                scene day6-9
                b "Life's so hard, especially when people don't understand you. Sometimes I'm afraid of telling the whole truth, so for me, keeping secrets is normal."
                scene day6-12
                ah "Let me tell you one thing..."
                b "..."
                scene day6-13
                ah "Well, I don't want to create any formality here, and I don't want you to feel shy and hide anything from me. "
                ah "We're neighbors after all. Let's sit together and have a sincere conversation."
                b "Actually, I'm not hiding anything from you."
                scene day6-14
                "{i} {color=#526168}He put his hand on Banu's shoulder and slightly dragged her towards the sofa. {/color}"
                ah "Maybe the secrets you reveal will help us work faster."
                "{i} {color=#526168}Banu felt his strong and big hands grabbing her body so hard. {/color}"
                "{i} {color=#526168}Her heart started beating faster. She wanted to say goodbye and leave, but she couldn't.{/color} "
                scene day6-15
                "{i} {color=#526168}They sat next to each other and talked for approximately half an hour about the neighbors, the street guys and even Banu's personal life. {/color}"
                b "Oh my god, I can't believe it. You and Kamil have a history?"

                ah "Yes, we studied in the same school, and we were even in the same grade."
                b "Oh, he's never mentioned you."
                ah "Well, I'm sorry to say this but he's always envied me. I had the best girls and an ideal body shape, but he was so fat and wasn't be able to do a pullup even once. "

                ah "He was always trying to imitate me, but he wasn't successful at it. That's why he's never talked about me. I'm sorry to talk about him like this, but it's the truth."
                b "Well, so much information that I didn't know about Kamil."
                scene day6-16 with dissolve
                "{i} {color=#526168}Ahmed grabbed Banu's hands and looked deep into her eyes.{/color} "
                ah "I want you to know that you can come to me any time if you need any help."
                "{i} {color=#526168}Ahmed was keeping Banu's hands longer and longer.. {/color}"
                ah "I'm always ready to help such a damsel in distress."
                "{i} {color=#526168}Banu smiled in return and thanked him for the beautiful words. {/color} "
                scene day6-17
                "{i} {color=#526168}While standing up, Ahmed put his hand around Banu's waist and slowly lowered it while walking her towards the door. {/color}"
                "{i} {color=#526168}Feeling his firm hand made Banu feel awkward and aroused at the same time. {/color}"
                b "Thank you for everything. You are a real man..."
                b "{i} {color=#526168}Banu, what are you saying?...That's stupid...just shut up. {/color}"
                "{i} {color=#526168}She started scolding herself in her mind for the words that just came out of her mouth unintentionally. {/color}"
                scene day6-18
                ah "Well, thank you."
                "{i} {color=#526168}Again, he was holding her tight till she opened the door and left. {/color}"
                "{i} {color=#526168}He was trying to control her by playing his cards absolutely right. {/color}"
                ah "{i} {color=#526168}Kamil is a lucky son of a bitch to have a beautiful doll like this. {/color}"
                ah "{i} {color=#526168}Sooner or later I will nail her so hard right in my office. He doesn't deserve a beautiful wife like her. {/color}"
            "She keeps the conversation formal":







                $ ahmedtease = False
                $ renpy.block_rollback()
                scene day6-9
                b "I’m sorry, but my reasons are personal."
                scene day6-10
                ah "I understand..."
                b "You know, I’m so busy today. Can I start writing the complaint letter right now? "
                ah "Sure, just let me hand you a piece of paper..."
                scene day6-11
                b "I hope this guy will be captured and punished properly soon."
                ah "There's no doubt about it."

        stop music
        scene black with dissolve
        with Pause(2)


    scene day6-20 with fade





    nat "Don't tell me that you're jealous of me. You know that I don't like it."
    sa "Of course not, I didn't mean that. I just want you to be careful and do your best to stay away from those creepy people."
    nat "Yes, you are definitely jealous."
    sa "I trust you, Natasha, but I don't trust them. That's not jealousy. You know that I love you so much and I don't want to lose you."
    nat "You need to be more confident I guess. I don't want a weak person around me."
    nat "Look, from now on you should trust me to protect our relationship. I just need you to trust me."
    sa "I trust you, baby."
    scene day6-19
    p "Hey, guys you can leave if you want. I also need to leave early today."
    scene day6-21
    sa "Do you need any help?"
    p "No, just leave it to me."
    sa "Okay then."
    scene day6-22
    nat "Hey, I need to discuss a few things with him. See you tomorrow."
    sa "No problem. I can wait for you."
    nat "No. Don't worry. I might be late."
    sa "Okay see you then. Love you."
    nat "Love you.."
    scene day6-23
    play music "audio/sidesex.mp3"
    "{i} {color=#526168}She was very excited about the conservation she was going to have with Polad. {/color}"
    "{i} {color=#526168}She couldn't manage to get Polad out of her mind all night long. {/color}"
    "{i} {color=#526168}His strong character, and his manly behavior during the argument that happened last time caused her to have a huge crush on him. {/color} "
    scene day6-24 with dissolve
    "{i} {color=#526168}She tried a lot to fight the feeling inside her towards Polad, but she was powerless.{/color} "
    "{i} {color=#526168}She was feeling guilty when thinking about cheating on Sasha, but she came up with excuses to kill the guilt every time.{/color}"
    nat "{i} {color=#526168}Sasha doesn't deserve to be cheated on but like they say, we only live once. Besides, this is not cheating. I'm just going to thank him for everything. {/color} "
    scene day6-25
    nat "Do you have a few minutes for me, Polad?"
    p "Sure, Natasha. What is it?"
    nat "I'm sure you had a good reason for ignoring me all day."
    p "What do you mean?"
    scene day6-26
    nat "I'm sure you have already noticed that I have my eyes on you."
    p "Are you drunk, Natasha?"
    nat "I'm fully aware of what I'm saying. Don't try to change the subject. I want to thank you for everything and let you know that all I think about is you. You turn me on so badly."
    p "Natasha, please stop it here. Your boyfriend can see us and misunderstand something so I want you to leave now, please."
    nat "I didn't stay to talk about my boyfriend. I stayed to talk about us."
    p "Nat, please, there is no 'us' "
    scene day6-27
    nat "I like it when you call me Nat."
    nat "What's the problem? You sleep with better girls than me?"
    p "Nat, go home and get some rest. I can tell you're tired, you're not speaking from your mind. "
    scene day6-28
    "{i} {color=#526168}Natasha grabbed his shirt firmly and pushed him towards the counter. {/color}"
    p "Hey, stop this immediately."
    nat "I want you to keep calm and let me give you my big thanks."
    p "Nat..."
    scene day6-29
    "{i} {color=#526168}She didn't let him finish his words and without further ado she started kissing him passionately while standing on her feet.{/color} "
    "{i} {color=#526168}He wasn't kissing her back. {/color}"
    scene day6-30
    "{i} {color=#526168} But at the same time he was not refusing her. {/color}"
    "{i} {color=#526168}She enjoyed his lips and started caressing his body under his shirt.{/color} "
    scene day6-31
    "{i} {color=#526168}After caressing him a while, her hand found what she was looking for. {/color}"
    p "Stop it. This is enough."
    nat "But why?"
    scene day6-32 with hpunch
    stop music

    "{i} {color=#526168}Suddenly, he took her firmly by her arms. {/color}"
    p "I said stop it. Do you understand what you're doing? What about your boyfriend? This can't go on like this. You will leave now and we'll forget what just happened."
    scene day6-33
    "{i} {color=#526168}Her whole body was aroused at that moment in response to his firm grip. {/color}"
    "{i} {color=#526168}Her pussy started twitching and her nipples were hard already. {/color}"
    "{i} {color=#526168}She wasn't hearing most of the words coming out of his mouth. She was literally hypnotized by his charm. {/color}"
    scene day6-34
    "{i} {color=#526168}She would give anything to fuck Polad at that moment, but she knew he was a tough one. {/color}"
    "{i} {color=#526168} Devilish feelings had full control over her. {/color}"
    "{i} {color=#526168}From that moment on, she took his rejection as a challenge for her to overcome. {/color}"

    nat "{i} {color=#526168}This is so wrong. {/color}"
    nat "{i} {color=#526168}But I’m not going to surrender.{/color} "
    $ banuruslantease = False
    $ banuruslandomme = False



    scene black with dissolve
    with Pause(2)
    scene day6-123 with fade
    b "{i} {color=#526168}So many things to do today... {/color}"
    b "{i} {color=#526168}I'm going to meet with Hicran today. {/color}"
    b " {i} {color=#526168}I haven't seen her since University years ago. I'm guessing she's changed a lot since then. {/color}"
    b "{i} .... "
    b "{i} {color=#526168} Ruslan just arrived. {/color}"
    b "{i} {color=#526168}Should I use this chance to talk with him for a few minutes? {/color}"
    menu:
        "She goes to talk with Ruslan":

            $ renpy.block_rollback()
            scene day6-124
            b "{i} {color=#526168}Okay, let's see how this goes. {/color}"
            b "{i} {color=#526168}I will try to talk with him one more time like a normal adult. {/color}"
            scene day6-125 with fade
            b "You look sweaty."
            r "I was running. I need to take a shower now."
            r "What do you need?"
            b "I just wanted to check if you need anything."
            r "I don't need anything."
            b "Okay, but I just want to know one thing. What's the reason for this attitute? What's your problem with me?"
            scene day6-126
            r "My God, please, don't start it again. I don't have time for you."

            b "No. We need to discuss this immediately. I want to put an end to this argument right now."
            r "Please, don't behave as if you don't know the reason."
            r "You don't love my father and you don't respect him at all. He's not aware of the devil that you are."
            scene day6-127

            b "What are you talking about? You should stop judging me all the time. I don't hide anything from your father."

            scene day6-128


            r "Do you know that my father started drinking and doing drugs? Do you know why? Because you don't give him enough attention."
            b "No. You're lying. He's not using drugs. "
            r "Yes, he is, because of you. You're not enough of a woman for him. You don't sleep with him because you sleep with other men."
            b "Enough! Watch your tongue."
            r "Am I wrong?"
            menu:
                "You just hate me because you want to fuck me but can’t!":
                    $ banuruslandomme = False
                    $ banuruslantease = True


                    $ renpy.block_rollback()

                    $ lust += 1
                    scene day6-129
                    r "What did you just say?"
                    b "I said you’re just hiding the fact that you want to fuck me."
                    r "What? Where did that come from? "
                    b "Don't you dare deny this, boy. I see you staring at my body. You get an erection every time we're in the same room together."
                    r "You’re wrong."
                    b "And maybe you masturbate in the shower thinking about me, huh?"
                    r "This is bullshit. You can't prove this."
                    b "No, I can."
                    scene day6-130
                    r "What are you doing?"
                    r "Are you out of your mind? Why are you closing the door?"
                    r "As I said, I don't have time for talking. I need to take a shower."
                    b "{i} {color=#526168}I’m going to shut him up. I know he wants me, and he insults me every time he denies it.{/color} "
                    b "{i} {color=#526168}He thinks he’s a big tough guy now, but I know I can make him squirm.{/color} "
                    b "{i} {color=#526168}If I put him in his place, maybe he’ll start treating me better.{/color} "



                    scene day6-131
                    b "Now we’re going to reveal your little secret together."
                    r "What secret? Can you stop touching me like that?"
                    b "Don't dare to move."
                    b "We’re going to play a little game. If you move away, you lose. If you get an erection, you lose and must apologize. If you don’t get erection, you win and I apologize. "

                    r "Okay, let's see."
                    scene day6-132
                    b "Wow, seems like you don't spend all your time at the gym in vain."
                    b "You’re so firm. I’m impressed..."

                    b "You are hot. A typical male body."
                    "{i} {color=#526168}She was massaging his abs in a sensual way that was turning him on.{/color} "
                    r "{i} {color=#526168}Shit, I’m going to have a hard-on real soon. {/color}"
                    r "Let's finish this already."
                    scene day6-133
                    b "Do you know what I do in the shower?"
                    b "I rub my almost virgin pussy thinking about your firm body."
                    b "I masturbate furiously thinking about you fucking me doggystyle."
                    scene day6-134
                    r "Oh, damn.."
                    b "{i} {color=#526168} Already? This was too easy!{/color} "
                    b "Seems like you lost."
                    r "You’re such a slut, I knew it."
                    scene day6-135
                    b "Don't say that you believed the words I just said."
                    r "You were lying?"
                    b "Of course, I was lying. What did you think?"
                    b "It was tempting, right? Poor boy."
                    r "Fucking slut."

                    scene day6-136 with vpunch
                    b "Hey, stay away from me.."
                    r "Do you think you can do anything you want and behave like nothing happened?"
                    b "Take your hands off. You're hurting me."
                    r "I'll tell my father everything. Finally, he'll realize that you're the sluttiest whore."
                    b "It won't be as easy as you think. He won't believe you."
                    b "Poor boy. Do you think you can touch me? You can only dream about me. Now take your dirty hands off me before I scream."
                    scene day6-137
                    b "Good boy. I'm leaving you with your boner. You know how to deal with that. Good luck to you."
                    r "{i} {color=#526168}Bitch. Soon you will be in my hands. I will show you that you can't play games with me. {/color}"
                    scene black with dissolve
                    with Pause(2)
                    stop music
                "You're lying. I don't believe he's doing drugs":



                    $ banuruslandomme = False
                    $ banuruslantease = False
                    $ renpy.block_rollback()
                    scene day6-138
                    r "He doesn't want you to know that. You better believe it."
                    b "I can agree that he drinks a lot with his friends, but I didn't know he is doing illegal drugs."
                    r "Because all you think about is your fucking job and the men you meet after work."
                    b "I won't let you talk to me like that."
                    scene day6-139
                    r "Now get out of my room. I have things to do."
                    b "Will you listen to me for a few minutes?"
                    r "I said get out. You are wasting my time."
                    b "{i} {color=#526168}He will never change... {/color}"
                    scene black with dissolve
                    with Pause(2)
                    stop music
                "Just shut your fucking mouth. I’ve had it with you!":




                    $ banuruslandomme = True
                    $ banuruslantease = False

                    $ renpy.block_rollback()
                    $ domme += 1
                    scene day6-140
                    b "You know what? I am fed up with you and your shitty behavior."
                    b "From now on, you will obey what I say. If you ignore a single word, I promise that you'll suffer. Understood?"
                    r "You can't do anything to me. I'm not afraid of you. Now get out and don't waste my time."
                    scene day6-141
                    b "Fuck you and your time!"
                    b "I’m tired of your bullshit!"

                    r "Will you please lower your voice. I can hear you."
                    scene day6-142
                    b "You don't know me. I'm not like the sluts you can dominate."
                    b "I am the boss here. Now I want you to apologize for your behavior right now."
                    r "This is bullshit. I'm not going to apologize for anything."
                    b "Who gives you the money you spend? Who puts a roof over your head? Your father. Now if I complain to your father about you, do you think he'll still continue to give you money, or will he kick you out? "
                    b "I’m the one controlling him. Remember that. As soon as I leave this room, I’m going to go talk to him. Say goodbye to the gym membership and the partying with your friends."

                    scene day6-143

                    r "Okay, I'm sorry. Don't tell him anything."
                    scene day6-144
                    b "You see? You depend on me. Look, you’re already 23 years old and still not working. It’s time you learned responsibilities."

                    r "If you tell him anything, you will ruin my life, please."
                    b "That's not good enough. Kiss my hand."
                    r "What?"
                    b "I said kiss my hand right now and ask me again politely."
                    scene day6-145
                    b "Good."
                    b "You see? You can be a good boy if you want."
                    scene day6-146
                    r "Please, don't tell anything to my dad. I beg you."
                    b "If you become a good boy like this, maybe I can get along with you."
                    scene black with dissolve
                    with Pause(2)
                    stop music

            scene day6-147 with fade

            "{i} {color=#526168}She took her hijab off and sat in front of the mirror. {/color}"
            scene day6-148
            b "{i} {color=#526168}I have not used excessive makeup since Alper’s death, but putting on some blush won’t hurt. {/color}"

            b "{i} {color=#526168} I'm a business lady, so I need to take care of my look. {/color}"

            scene black with dissolve
            "{i} {color=#526168}After some time... {/color}"
            b "{i} {color=#526168}I can't get that guy from the coffee shop out of my mind. He asked me to have an interview with him, just like that. {/color}"

            b "{i} {color=#526168}Is he a creep? But he was so serious... maybe he’s sincere?{/color} "

            b "{i} {color=#526168}I have some time before I meet Hicran, so I’m looking for something to do. I kept his card. I have nothing to lose, and I’m curious...I will call him. {/color}"

            scene day6-149 with fade

            b "{i} {color=#526168}I know this is a stupid thing to do, but again I just can't help myself. {/color}"

            b "{i} {color=#526168}Banu, you are so weird sometimes... {/color}"

            b "{i} {color=#526168}What was his name?.....It was.... Murat. Just remembered. {/color}"

            scene day6-150

            b "{i} {color=#526168}51.....55... That is it.. {/color}"

            b "..."

            scene day6-151

            b "Hello, is it Mr. Murat?"

            mur "Yes, how may I help you?"

            b "It’s Banu. You asked me for the interview at the coffee shop."

            mur "Ohh, you're that woman with the hijab?"

            scene day6-152

            b "You probably gave your number to a lot of women already. I wonder if I wasn’t wearing a hijab would you remember me? "

            mur " Okay, let me try again. Are you that gorgeous woman I met in the coffee house? "

            b "This sounds better."

            mur "I knew you were going to call me. I saw the curiosity in your face last time."

            b "I won't hide it, I like confident men..."

            mur "Do you have time today?"

            b "I do.."

            mur "Now I’ll send you the address. I’ll be waiting for you today. "

            b "I'll be there..."

            stop music
            stop music
        "She goes to fix her makeup instead.":







            $ renpy.block_rollback()
            scene day6-124
            b "{i} {color=#526168}Nah, I'm not going to waste my time talking with him. {/color} "
            b "{i} {color=#526168}I better go and fix my makeup a little bit. {/color}"
            scene day6-147 with fade
            "{i} {color=#526168}She took her hijab off and sat in front of the mirror. {/color}"
            scene day6-148
            b "{i} {color=#526168}I have not used excessive makeup since Alper’s death, but putting on some blush won’t hurt. {/color}"

            b "{i} {color=#526168} I am a business lady, so I need to take care of my look. {/color}"

            scene black with dissolve
            "{i} {color=#526168}After some time... {/color}"
            b "{i} {color=#526168}I can't get that guy from the coffee shop out of my mind. He asked me to have an interview with him, just like that. {/color}"

            b "{i} {color=#526168}Is he a creep? But he was so serious... maybe he’s sincere?{/color} "

            b "{i} {color=#526168}I have some time before I meet Hicran, so I’m looking for something to do. I kept his card. I have nothing to lose, and I’m curious...I will call him. {/color}"

            scene day6-149 with fade

            b "{i} {color=#526168}I know this is a stupid thing to do, but again I just can't help myself. {/color}"

            b "{i} {color=#526168}Banu, you are so weird sometimes... {/color}"

            b "{i} {color=#526168}What was his name?.....It was.... Murat. Just remembered. {/color}"

            scene day6-150

            b "{i} {color=#526168}51.....55... That is it.. {/color}"

            b "..."

            scene day6-151

            b "Hello, is it Mr. Murat?"

            mur "Yes, how may I help you?"

            b "It’s Banu. You asked me for the interview at the coffee shop."

            mur "Ohh, you're that woman with the hijab?"

            scene day6-152

            b "You probably gave your number to a lot of women already. I wonder if I wasn’t wearing a hijab would you remember me? "

            mur " Okay, let me try again. Are you that gorgeous woman I met in the coffee house? "

            b "This sounds better."

            mur "I knew you were going to call me. I saw the curiosity in your face last time."

            b "I won't hide it, I like confident men..."

            mur "Do you have time today?"

            b "I do.."

            mur "Now I’ll send you the address. I’ll be waiting for you today. "

            b "I'll be there..."

            stop music
            stop music






    scene black with dissolve
    with Pause(2)
    scene day6-77 with fade

    p "{i} {color=#526168} Natasha was totally out of her mind. Maybe it was the effect of alcohol. {/color}"
    p "{i} {color=#526168}I can't understand her. How can she do such a thing considering that she has a boyfriend? I feel bad for Sasha. But maybe he's aware of it and it's normal for them.{/color}"
    p "{i} {color=#526168}I could've fucked the shit out of her right there and made her scream. I could barely stop myself. {/color}"
    p "{i} {color=#526168}God, why are you still thinking about her? This is so wrong... {/color}"
    scene day6-78
    n "Honey, is everything ok?"
    p "Yes, why?"
    n "You look strange today."
    p "How do I look?"
    n "Worried, thoughtful....I don't know. Is something the matter?"
    scene day6-79
    p "There's nothing to tell you. You're just over-thinking."
    n "....Let it be."
    p "Haven't I told you that I hate when somebody questions me?"
    n "Sorry if I broke your rules."
    $ poladhitnesrin = False
    $ banumuratdomme = False
    p "Again with the sarcasm?"
    n "..."
    n "Have you ever thought about coming home a bit early and spending your time with your family? I don't see your face all day long. You only come home for sleeping. What about me?"
    p "Well, that's the problem. Look, we already talked about that. I don't want to hurt you, so change the subject. I'm not in the mood to discuss anything rigth now. "
    n "...."
    scene day6-80
    n "You can't hurt me now, because you've already hurt me too many times."
    n "...."
    scene day6-81
    n "Hey, don't touch me."
    p "Shhh, stay still."
    p "I can love you if I want, and I can hurt you if I want. Now tell me which one you choose?"
    n "It's not all about putting a ring on my finger. You do nothing for me. You do nothing to keep me."
    n "I will divorce you."
    p "You will never do that. Now turn around and give me a good kiss."


    if agressive == False:
        $ poladhitnesrin = False

        scene day6-82
        n "And why are you so sure that I wouldn't divorce you?"
        p "You can't stay away from me even a single minute."
        n "But you stay away from me all day long."
        scene day6-83
        p "Better shut that cute mouth of yours up."
        p "You're forcing me to take you so hard right now."
        n "What are you waiting for?"
        scene day6-84 with vpunch
        n "Ahhh.."
        n "Mmmmm.."
        n "I love you so much.."
        p "You're so light."
        n "Mmmm..."
        n "Because you are so strong."
        scene day6-85
        n "I can't wait for you to break me now."
        p "If that's what you want you'll get it hard..."
        stop music


    if agressive == True:
        menu:
            "She turns around":
                $ poladhitnesrin = False







                $ renpy.block_rollback()
                scene day6-82
                n "And why are you so sure that I wouldn't divorce you?"
                p "You can't stay away from me even a single minute."
                n "But you stay away from me all day long."
                scene day6-83
                p "Better shut that cute mouth of yours up."
                p "You're forcing me to take you so hard right now."
                n "What are you waiting for?"
                scene day6-84 with vpunch
                n "Ahhh.."
                n "Mmmmm.."
                n "I love you so much.."
                p "You're so light."
                n "Mmmm..."
                n "Because you are so strong."
                scene day6-85
                n "I can't wait for you to break me now."
                p "If that's what you want you'll get it hard..."
                stop music
            "She tries to escape from his arms":



                $ poladhitnesrin = True




                $ renpy.block_rollback()
                scene day6-86
                p "Is this how you respect your husband? Come here."
                n "Take your hand off. It hurts."
                scene day6-87
                p "Don't dare to ignore me like that."
                n "Stop it..."
                p "You're my wife. You should understand and respect me. Is that clear for you?"
                n "No. I don't want to understand anything. I'm just tired of you. I don't wish to live this life."
                play sound "voices/slap.mp3"
                scene day6-88 with hpunch
                n "Ahhh.."
                "{i} {color=#526168}He slapped her with the back of his hand, which she wasn't expecting. {/color} "
                scene day6-89
                p "You should learn how to respect your husband."
                n "..."
                stop music
                scene day6-90
                n "..."
                n "......."








    scene black with dissolve
    with Pause(2)
    jump storycontinuation1
    label storycontinuation1:

        scene day6-91 with fade
        play music "audio/chill.mp3"

        mur "You look so different."
        b "And how different?"
        mur "You are breathtaking, Banu."
        b "Mmm, thanks."
        mur "Come in. Make yourself at home. I'm coming in a minute."
        scene day6-92
        b "{i} {color=#526168}The apartment has more than six rooms and they are all well designed in avant-garde style. {/color} "
        b "{i} {color=#526168}He must be so rich, and yet he lives alone. It's strange. {/color}"
        b "{i} {color=#526168}God knows how many girls he brings here every day. Am I just another one of them?{/color} "
        scene day6-93
        b "{i} {color=#526168}An apartment like this in the city centre must be very expensive. {/color}"
        b " {i} {color=#526168}What am I even doing here? Sometimes I can't understand myself. It was a bad idea to come here.{/color}"
        b "{i} {color=#526168}What could I do if he tries to rape me? There's no point in screaming because nobody would hear me. Ohh, Banu, think positive... {/color}"
        scene day6-94
        b "{i} {color=#526168}He's very suave and sophisticated. {/color}"
        b "{i} {color=#526168}If I were single and very young, I wouldn't say 'no' to him... {/color}"
        b "{i} {color=#526168}But I’m married and older than him, so I need to be more serious... {/color} "

        scene day6-95
        mur "The photo was taken about five years ago."
        b "You've not changed a lot."
        b "How old are you?"
        mur "29...you?"
        b "Rule number one, you don't ask a woman's age. Hasn't anyone ever told you that?"
        mur "I'll know it soon. It's my job."
        b "I see you’re a clever type."
        scene day6-96 with fade
        mur "Before we start, I need to tell you a few things."
        b "What is it?"
        scene day6-97
        stop music

        mur "This interview thing was not my only purpose for inviting you here."
        b "And..."
        mur "That day when I saw you, you drove me crazy. You're flawless, Banu, like an angel."
        mur "You made me so horny by just looking at me."
        mur "Even right now, I want to take off all your clothes, carry you to my bedroom and ravish your body like no one did before. "
        mur "I want to fuck you so bad and make you want more and more..."
        menu:
            "Ohh, I like that you’re so straightforward":

                $ banumuratdomme = False

                $ banubad += 1

                $ murattease = True
                $ renpy.block_rollback()
                scene day6-107
                mur "I'm always straightforward. I speak what's on my mind. "
                b "I knew it from the beginning you wanted me. I’m not stupid."
                mur "You knew it and you came here."
                scene day6-108
                b "Yes, I came here because I have a few words to tell you."
                b "I see you want to be 'honest' with me, and I'll be honest with you. "
                b "I'm so sorry to let you down, but you will never get what you want from me."
                mur "A gorgeous lady like you is in my apartment and having a hot conversation with me. I think I’ve gotten what I’ve wanted so far with you."

                b "I don't think this will be enough for you so, let me tell you something you should know."
                scene day6-109
                b "Rule number two, I'm a married woman and you can't talk to a married woman like that. You should be more respectful."
                mur "If my words hurt you, just take them as a compliment."
                b "You have a strange way of complimenting a lady."
                mur "But it seems that you like this."
                b "..."
                scene day6-110
                b "Actually, I need to leave and meet one of my friends."
                mur "You're leaving so early."
                b "I think this was more than enough for me. It was nice to meet you, and you have a really nice apartment by the way."
                mur "Before you go, come see the entertainment room."

                b "I..."
                mur "I’m sure that you’ll like it. Come with me, it won’t take long."
                b "Okay..."
                scene day6-111
                b "Wow, it's so roomy."
                mur "This room is the best for partying."
                scene day6-112
                mur "I'm sure you can spend a few more minutes with me."
                b "{i} {color=#526168}Why does this man have so much influence over me? I feel very sexy and aroused around him. {/color} "

                b "{i} {color=#526168}His posture, his cool behavior and even his cologne makes me really horny. {/color} "

                b "{i} {color=#526168}I need to keep myself under control, but it would be fun to tease him a bit. {/color} "
                b "We'll see."
                scene day6-113
                mur "Can you play billiards?"
                b "No...I know the rules, but I only played it on the phone."
                scene day6-114
                mur "So, you have a chance to try it now. Don't worry, I will help you."
                b "You think so?"
                mur "Sure.."
                scene day6-115
                mur "Now put your left foot ahead and right foot a little bit back."
                b "Let me try myself."
                scene day6-116
                mur "You look like a professional player."
                b "Thanks."
                b "Do you enjoy the view by the way?"
                mur "What do you think the answer is?"
                mur "{i} {color=#526168}She's a horny slut. Look how she's teasing me {/color} "
                mur "{i} {color=#526168}If I play my cards right, I'll be fucking her brains out right here on the billiards table. {/color} "
                mur "{i} {color=#526168}Tease me like that, slut. Tease me. I'll be pounding your married pussy in minutes. {/color} "
                mur "Let me fix your posture a little bit."
                scene day6-117
                mur "Put your left hand a bit ahead."
                mur "That is cool."
                b "{i} {color=#526168}I can definitely say that he wants to tease me. {/color} "
                mur "Bend forward more."
                b "{i} {color=#526168}I'll tease him a bit more, so I'll obey his request and bend further over.{/color}"


                b "{i} {color=#526168}Oh my god, his body is touching me. I'm so horny now. I'm not going to be able to control myself any longer. I need to leave immediately. {/color}"
                mur "{i} {color=#526168} I know she feels my hard cock now… her body is reacting to it… I can feel her shaking a bit. {/color} "

                mur "{i} {color=#526168} Now’s the time to make my move before she retreats. {/color} "

                scene day6-118
                "{i} {color=#526168}Murat grabbed her firmly and pressed her to his body so she couldn't move. {/color}"
                b "{i} {color=#526168}Oh my god, he's really doing it.{/color}"
                b "Murat, stop it."
                mur "No."
                b "Just stop it."
                b "{i} {color=#526168}I can feel his hard dick touching my belly. I need to leave right now. {/color}"
                b "{i} {color=#526168}He is holding me so tight. I can't move. {/color}"
                b "Murat..."
                scene day6-119
                "{i} {color=#526168}Murat didn't wait for her to finish her sentence and started kissing her passionately. {/color} "
                "{i} {color=#526168}She was unable to escape from his arms because she was lost in temptation. {/color}"
                "{i} {color=#526168}She couldn't stop herself from kissing him back. Her lips responded to Murat's hot kisses.{/color} "
                scene day6-120
                "{i} {color=#526168}His hands slowly went down and started squeezing her ass cheeks. {/color}"
                "{i} {color=#526168}She was super wet by now. {/color}"
                "{i} {color=#526168}She couldn't say a single word as Murat's lips were making her mouth busy. She was trying to reject Murat with her hands, but they were so weak and powerless. {/color} "
                b "{i} {color=#526168}No, this can't happen. I can't... {/color}"
                b "No, I need to go.."
                scene day6-121
                "{i} {color=#526168}She used all her remaining power and managed to escape from him at the last moment. {/color}"
                b "I’ll let myself out, so don’t follow me. This will never happen again. Goodbye."
                mur "{i} {color=#526168}Slut, you think you can tease me and escape, but you won’t get away with it. Sooner or later you will be in my bed... {/color} "

                scene day6-122
                "{i} {color=#526168}She couldn't believe what just happened. {/color}"
                b "{i} {color=#526168}How can I do such a thing? What about Kamil? Oh God... {/color} "
                "{i} {color=#526168}She left the room sad and devastated... {/color}"
                scene black with dissolve
                with Pause(2)
                stop music
            "How dare you say something like that?":


                $ banumuratdomme = True


                $ murattease = False
                $ renpy.block_rollback()
                scene day6-98
                mur "Look.."
                b "I'm asking you. How dare you? Who do you think you are?"
                scene day6-99
                mur "Look, I didn't mean to insult you.."
                b "Shut your fucking mouth up, you son of a bitch."
                b "How can you offer a married woman something like that?!"
                mur "Wait, listen to me. I will explain..."
                scene day6-100
                b "You will explain what? You don't respect yourself. You are just a piece of shit."
                mur "Hey, watch your mouth."
                scene day6-101 with hpunch
                "{i} {color=#526168}Without hesitation she spat on his face and watched her saliva drip down his face with satisfaction. {/color} "
                b "I could make you regret this in multiple ways, but I don't have time to spend on an asshole like you..."
                scene day6-102
                "{i} {color=#526168}He couldn't say a single word and watched her leave the room while cleaning the saliva from his face. {/color}"
                "..."
                "......"
                stop music
                scene black with dissolve
                with Pause(2)
            "Don't you feel ashamed of yourself?":


                $ banumuratdomme = False

                $ murattease = False
                $ renpy.block_rollback()
                scene day6-104
                b "No really, do you feel a little bit ashamed?"
                mur "Banu..."
                b "How can you talk to a married woman like that? I thought you were a gentleman, but I see you're not different from those creeps."
                mur "Look, I'm sorry..."
                b "No, I can't stay here any longer."
                scene day6-105
                mur "Banu, listen to me. I know that sounds crazy, but I'm really enchanted by you. All I think about is you from the first time I saw you."
                b "Please..."
                mur "I can give you anything you want, Banu, anything to make you happy."
                scene day6-106
                b "Please, stop it."
                b "You don't understand what you're saying. This was a mistake from the very beginning."
                b "I shouldn't have come here. I need to go now."
                mur "I want you to come again."
                b "I don't think it will happen again."
                "...."
                stop music
                scene black with dissolve
                with Pause(2)

        jump storycontinuation2
label storycontinuation2:


    scene day6-50 with fade
    play music3 "sfx/gym.mp3"
    r "{i} {color=#526168}26....27 {/color}"
    scene day6-51
    guy1 "Hey, look at that mama's boy."
    guy2 "He thinks he can easily get bigger muscles by working with just ten kilos."
    scene day6-52
    r "{i} {color=#526168}These assholes are just looking for trouble. They're going to interrupt my workout. {/color}"
    guy1 "Hey, dude, you're doing it wrong. You shouldn't put your elbow on your leg. And you're using momentum instead of brute strength."
    r "{i} {color=#526168}I'm just going to ignore them. {/color}"
    guy1 "Hey, I'm talking to you, fool."

    scene day6-53
    r "What's your problem with me?"
    guy1 "First, lower your voice. You're not talking to your little brother."
    guy1 "We know what type of a guy you are, so better shut your mouth."
    scene day6-54
    r "What do you mean exactly?"
    guy1 "Don't behave like you don't know anything. Some dude just fucked your sister. Everybody talks about that."
    guy1 "If I were you, I'd kill that guy, but I see it doesn't bother you. You chickenshit."
    r "That's not your business and you better leave me alone."
    guy1 "What will you do if I don't leave? Will you call your mama? She’s a HOT mama too! She wears a hijab and has a fine body. I should fuck her and send you the video."
    r "Fuck off!"
    guy1 "I see you didn't understand me."
    scene day6-55 with hpunch
    guy1 "Maybe this will help you."
    guy2 "Woah, that's enough, bro."
    scene day6-56
    guy1 "Behave appropriately, you son of a bitch."
    guy2 "Stop it man, he's had enough..."
    stop music3
    scene black with dissolve
    with Pause(2)



    scene day6-41 with fade
    play music3 "sfx/fastfood.mp3"
    b "You look amazing, just like you did in the university years. "
    hic "There's always a reason for a woman to keep looking good."
    b "And what's that reason?"
    hic "Maybe I can tell you later."
    scene day6-35
    b "Oh by the way, what about your husband? You didn't tell me anything about him yet."
    scene day6-36
    hic "Actually, it was the biggest mistake of my life. "
    scene day6-35
    b "What do you mean?"
    scene day6-36
    hic "My husband..."
    scene day6-35
    b "What about him?"
    scene day6-36
    hic "Banu, it was not my decision to marry him. It was my parents' decision. He is almost 30 years older than me. Can you imagine that?"
    b "If you didn't love him, why did your parents do such a thing?"
    hic "Are you serious? How can I love a man at almost the same age as my dad?"
    hic "My parents forced me to marry him. Do you know why? Because he's rich. He has villas, expensive cars and so on, and my dad wants to benefit from him."
    scene day6-38
    b "I’m so sorry for that, but you should accept the past and focus on the future."
    scene day6-39
    hic "What future? My future with that man? It's impossible."

    hic "I'll run away from here and live in another country."
    scene day6-37
    b "What? You should definitely rethink that. What about your parents? What will people think about you? You’re a married woman."

    hic "Listen, you don't understand. I can't waste the rest of my life with that old man."
    scene day6-40
    b "No, you're crazy."
    hic "Look, it's late. Should we leave already?"
    b "Sure. Let's go...."
    stop music3
    scene black with dissolve
    with Pause(2)
    scene day6-42 with wipeup
    play music "audio/chill.mp3"
    "{i} {color=#526168}They walked to the nearest bus stop. {/color}"
    "{i} {color=#526168}Hicran was walking quickly as if she were hurrying somewhere. {/color}"
    scene day6-43 with dissolve
    hic "Ohh, I forgot to tell you one thing, but before I tell you, promise me that it will stay between us."
    b "Of course.."
    hic "I’m hanging out with another guy. He has feelings for me."
    b "A.. are you cheating on your husband?"
    hic "No, I'm not cheating."
    b "I don't understand. You-"
    scene day6-44
    hic "Just one minute...."
    b "...."
    scene day6-45
    hic "Yeah..I'm here.."
    hic "Where are you?"
    b "{i} {color=#526168}Look how slutty she became. {/color}"
    b "{i} {color=#526168}People change...{/color} "
    scene day6-46
    hic "I’m sorry but I have to hurry, dear. See you. I'll message you."
    b "See you..."
    "{i} {color=#526168}Banu knew she was going to meet someone. {/color}"
    "{i} {color=#526168}The curiosity came over her and she decided to follow her. {/color}"
    scene day6-47
    b "{i} {color=#526168}No. That’s definitely not her husband. {/color}"
    b "..."
    scene day6-48 with dissolve
    b "{i} {color=#526168}I can't believe my eyes. They're kissing in public, and he's not even her husband.{/color}"
    b "{i} {color=#526168}They look so hot though... {/color}"
    scene day6-49
    b "{i} {color=#526168}Is it that easy to cheat on your husband? Could I do such a thing? {/color}"
    b "{i} {color=#526168}It's wrong and morally unacceptable. {/color}"
    b "{i} {color=#526168}But it is so hot.... {/color}"
    stop music
    scene black with dissolve
    with Pause(2)


    scene day6-57 with Dissolve(5)
    b "{i} {color=#526168}What a day... {/color}"
    b "{i} {color=#526168}I wouldn't have expected something like that from Hicran. {/color} "
    b "{i} {color=#526168}She's hanging out with another man. Maybe he's fucking her, and she comes back home and simply smiles at her husband's face. {/color} "
    b "{i} {color=#526168}I can't understand how she looks into her husband's eyes after sleeping with another man. {/color} "
    b "{i} {color=#526168}Maybe, they're not sleeping, just meeting.... I don't know. {/color}"
    if ahmedtease == True:
        b "{i} {color=#526168}And then there’s Ahmed. He told me a lot about his history with Kamil at the police station. {/color}"

        b "{i} {color=#526168}Actually, he described Kamil like a wimp. Why did he do that? Maybe he wanted to look like an alpha male in my eyes. It seems like he succeeded. {/color} "
        b "{i} {color=#526168}But I don't want to assume that he’s attracted to me... I needed his help and he rescued me. {/color} "

        b "{i} .... "
    if murattease == True:
        b "{i} {color=#526168}And then, Murat. I made a big mistake today. How could I let a guy kiss me? He groped my ass and kissed me for five minutes... {/color} "
        b "{i} {color=#526168}He turns me on so much. The way he eats me with his eyes… even thinking about him right now makes me wet. {/color} "

    scene day6-58
    b "{i} {color=#526168}My body is so fit. {/color}"
    b "{i} {color=#526168}How long will it last? I need to start taking advantage of being young and fresh, before it’s all gone. {/color} "

    scene day6-59
    b "{i} {color=#526168}I deserve some attention after all. {/color} "
    b "{i} {color=#526168}Kamil is so passive and resigns so quickly when I reject him. {/color} "
    scene day6-60
    b "{i} {color=#526168}If I were married to...Polad, for example, he would be using my body all day long. {/color} "
    b "{i} {color=#526168}My body would be all red from the slapping and squeezing... {/color} "
    b "{i} {color=#526168}God, Banu, why did that come to your mind now? {/color} "
    scene day6-61
    k "Banu, are you there?"
    b "Yeah, coming...."
    scene day6-62
    k "I can't find my phone. I'm sure it's around here. Just give me your phone so I can call myself."
    b "It's in the bedroom in front of the mirror."
    k "Okay...."
    k "...."
    menu:
        "She asks him for a favor":
            play music "audio/sexy.mp3"



            $ renpy.block_rollback()
            $ banu_kamil += 1
            $ lust += 1
            scene day6-63
            b "Wait, I think I need your help..."
            k "Sure, what is it?"
            b "Just come here..."
            scene day6-69
            "{i} {color=#526168}Kamil slowly entered the room and closed the door behind him. {/color}"
            "{i} {color=#526168}He didn't say anything, rather he followed Banu to see what she wanted from him. {/color}"
            scene day6-70
            "{i} {color=#526168}Banu also preferred not to talk, and she took her t-shirt off slowly. {/color}"
            k "{i} {color=#526168}She’s absolutely stunning... it’s too good to be true that I’m married to her. {/color}"
            scene day6-71
            b "Can you please help me to unhook my bra? It's stuck I guess."
            k "Sure, let me do it."
            scene day6-72
            "{i} {color=#526168}He started to unhook her bra while she stayed still... {/color}"
            "{i} {color=#526168}Suddenly he looked at Banu's eyes in the mirror and saw her sensually smiling. {/color} "
            scene day6-73
            b "{i} {color=#526168}Ohh, he's really doing it.{/color}"
            b "{i} {color=#526168}I didn't think he would go for it. {/color}"
            scene day6-74
            b "{i} {color=#526168}It feels so good teasing him. I want to touch myself so bad. He is not going to stop. {/color}"
            b "{i} {color=#526168}But, not now. The door is open. Our kids could come in and see us. I should stop it before it's too late...{/color}"
            stop music
            b "Kamil, stop it please."
            scene day6-75
            k "What? What now?"
            b "..."
            k "Don't tell me again it's because of him, your ex-husband."
            b "No...I..."
            scene day6-76
            "{i} {color=#526168}Kamil didn't wait for any reply and left with an expression of a mixture of sorrow and anger on his face. {/color}"
            b "{i} {color=#526168}He's tough sometimes, but sometimes he's so emotional. {/color}"
            stop music
        "She just closes the door":



            $ renpy.block_rollback()
            scene day6-64
            b "{i} {color=#526168}Here's the chance to enjoy some time alone... {/color}"
            scene day6-65 with dissolve
            b "{i} {color=#526168}I'm sweaty after this long day. {/color}"
            scene day6-66 with dissolve
            b "{i} {color=#526168}Tomorrow might be a stressful day at work. {/color}"
            b "{i} {color=#526168}I need to look fresh and beautiful. {/color}"
            scene day6-67 with dissolve
            b "{i} {color=#526168}Will I always be beautiful? {/color}"
            b "{i} .... "
            scene day6-68
            b "{i} {color=#526168}What matters is that I’m beautiful right now, and I’m still a sweet dream for a lot of men... {/color}"

            b "{i} .... "
            stop music




    jump v6
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
