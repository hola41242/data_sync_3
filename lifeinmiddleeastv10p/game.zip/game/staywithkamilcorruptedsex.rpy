



label muratfucksbanuafterfunsexscenestaywithkamil:



    scene v16-132 with fade
    play music "audio/sensual.mp3"

    b "Murat, I can't believe I'm agreeing to this, but okay. Just 5 minutes, and then I need to leave. No longer than that, okay?"

    mur "Deal! I promise you won't regret it. Let's go!"

    scene black with dissolve

    "..."

    scene v16-142 with dissolve

    b "Wait...you're such a liar, Murat."

    b "....mmmmp.."

    mur "Your lips taste so good. I can kiss you all day."

    b "You're going to choke me, maniac."

    b "Is it your fisrt time kissing?"

    mur "You're driving me crazy, Banu. I can't control myself with you."

    scene v16-143 with fade

    b "Mmmp...oh god...stop touching me there...ohh."

    mur "You like this, don't you?"

    b "We didn't agree on taking the clothes off, did we?"

    scene v16-144 with fade

    mur "Shhhh...just enjoy the moment. "

    b "Your dick....it's touching me..."

    mur "Damn Banu, you're kissing me so passionately. You must be craving this all the time you've been with me."

    scene v16-145

    b "Ahhh...you know what I need..."

    b "Right there...ahhhh.."

    b "Ummmmm...You got me so wet you tricky boy."

    scene v16-146

    "Murat was bending Banu backwards slightly and she was grabbing his neck not to fall off."

    "Using the opportunity, Murat started rubbing Banu's pussy furiously and talking dirty to her making her crazy."

    b "Ahhhhh...stop it...please, ahhh."

    mur "I'll make you feel so good that your husband never done that to you."

    mur "I'm going to make you feel like a real woman today. You'll scream and beg but I won't stop..."

    scene v16-147 with fade

    "After minutes Murat grabbed Banu taking her pants and bra off and sat on the sofa holding her on top of him. "

    "While invading her mouth, Murat run his hands all over Banu's body, caressing her thighs, belly and breasts. "

    "At this point, Banu could't help but reached her pussy with her hand stimulating her left out clit."

    scene v16-148

    b "Shit, I can't bear it anymore...Murat, please..."

    mur "Tell me. What you want me to do?"

    b "Please, make me feel good."

    mur "You want my cock, don't you?"

    b "My pussy is so wet now. I'm going to cum from your touches."

    b "Please, take my pussy. Make me yours!"

    scene v16-149 with hpunch

    b "Ahhh...yeah like that.."

    mur "You're such a lewd slutty wife, aren't you?"

    b "Yesss, I'm a despicable, bad wife who needs a good punishment."

    b "Call me whatever you want. I deserve that."

    mur "You're a bad bitch enjoying my fingers deep inside of your married cunt. "

    b "Ohhh...I can't take it anymore...I'm going to cummm....."

    scene v16-150

    mur "Look how slutty you are. You're cumming from a young man at your children's age fingering your pussy."

    b "Please, stop it..."

    b "Damn, you're so good at this. Fuck..."

    b "I've never let my husband touch me like that."

    mur "Go on, cum for me. I'm going to tease all of your slutty holes."

    mur "I'm going to tease the shit out of you. You'll beg me to fuck all of your holes."

    mur "Have you ever got your asshole fucked?"

    scene v16-151 with vpunch

    b "No! Don't touch me there. I warn you!"

    mur "What? You're rejecting me?"

    b "Shit, I'm serious, Murat. I've never let a man touch me there."

    "Banu squeezed her legs so hard to prevent Murat teasing her asshole with his middle finger. "

    scene v16-152 with fade

    b "Ahhh..."

    b "You're crazy...what are you doing?"

    mur "You see? I'm full of surprises."

    scene v16-153

    mur "Mmmm...it's so delicious. Do you like it?"

    b "Ohhh shit...stop it...it's so dirty..."

    b "Oh god...you're hitting my spot."

    b "You're eating it like your favorite breakfast...ufff.."

    mur "Mmmm..this is my favorite meal of the day."

    b "Oh my God...if you keep doing that....I won't be able to stop cumming."

    mur "Don't hold it. Cum all over my mouth. "

    b "Shit, you're so good with your tongue."

    mur "Are you ready for the main course?"

    scene v16-154 with fade

    "Murat suddenly raised Banu's legs and put his dick on top of her pussy grinding it back and forth."

    mur "You want this, don't you?"

    b "Stop teasing me, please..."

    mur "Shut up!"

    mur "Tell me how you want it."

    scene v16-155

    b "I want it inside of me..."

    "Murat continued teasing Banu's wet pussy with his fully erect curvy dick making her crazy."

    mur "I want you to ask it properly."

    b "Oh god...you're making me crazy..."

    b "Put that fucking dick inside of me!"

    mur "Tell me how bad you want it."

    b "I want it so bad...please, my pussy aches for your big curvy dick."

    b "Put it inside of my married unsatisfied pussy."

    b "Fuck the shit out of me..."

    scene v16-156 with hpunch

    b "Ahhh..."

    mur "That's it. I'm not gonna make you suffer any longer."
    stop music

    show muratfuckbanuafterfunanimation
    play music "voices/moaning.mp3"
    b "Fuck!...This feels so good..."

    mur "I know what you want, baby."

    mur "My dick fits so good inside of your wet pussy."

    mur "Your pussy is just made for my cock."



    show muratfuckbanuafterfunanimationangle

    b "Ohh fuck me...keep fucking me like that."

    mur "Your husband is weak man probably. Leaving a pussy unsatisfied like this huh?"

    b "Please, ahhh, stop talking about him..."

    b "Keep fucking me like that, ahhh.."


    show muratfuckbanuafterfunanimationfast

    b "Ohhhh shit..."

    b "It's hitting me so bad..."

    mur "Fuck...your pussy squeezes my cock so hard."



    show muratfuckbanuafterfunanimationanglefast

    b "Oh my god, keep fucking me like that...ahhh..."

    b "Your cock reaches my stomach...ohhh shit.."

    mur "I'm going to destroy belly..."

    mur "I can't believe you gave a birth from this pussy. It's so tight."
    stop music
    play sound "voices/moanfinish.mp3"
    b "Fuck....I'm cumming....shit...."


    scene v16-157 with hpunch

    b "Shit...that was so intense."
    stop sound
    mur "Your face tells it all."

    b "You're the devil."

    mur "I'm glad you liked that...but it's not over yet."

    scene v16-158

    mur "I have an idea. How about we try something new together?"

    b "Wait..what?"

    mur "It's something you've never done before, and I think it could be a fun and memorable experience."

    b "No!...no way..."

    scene v16-159

    mur "But why not trying?"

    b "I'm sorry, but I can't do that. It's just not something I'm comfortable with or ready for."

    mur "Let's give it a try, just this once. I'm sure you'll love it."

    scene v16-160

    b "No I can't do that. I'm not comfortable with this you know."

    mur "How do you know if you haven't tried it?"

    b "Please, don't push me. I'm afraid of that."

    scene v16-161

    b "Heyyyy...stop it!"

    mur "I promise you, it won't be painful."

    mur "I'll make sure you're comfortable and at ease throughout the experience."

    scene v16-162

    b "I just said stop it! What are you doing?"

    b "I can't do this!"

    mur "Shhhh...your ass will love it."

    scene v16-163

    b "Ahhhhhhhh...Ay mama....it hurts...stop it!"

    mur "Shhhh, I'll lubricate it good that you'll only feel the pleasure."

    scene v16-164

    b "Ahhhhhh..."

    mur "That's it..."

    b "It hurts so bad, please pull it out! Ahhhhh.."

    mur "Don't worry. Your ass will get used to it."

    show muratfucksbanuanalsideanimation
    play music "voices/moaning.mp3"
    b "Shit...Ahhhh..."

    b "It destroyes my ass."

    mur "You seem to like it."



    b "Ohh yeah, don't stop...keep fucking my dirty asshole..."

    mur "Your asshole is so tight. It squeezes my dick like hell."

    mur "But I'll stretch it a bit more."

    show muratfucksbanuanalsideanimationfast

    b "Ahhhhhh....yesss...pound my ass like that..."

    b "Shit, I can't hold it. I'm going to pee."





    mur "Your asshole belonges to me now. "

    mur "I'll stretch it whenever I want."

    stop music

    scene v16-165 with fade

    "Murat fucked Banu for hours in the ass hitting deep inside her with his long curvy dick."

    "Banu's initial pain was replaced by a mixture of pleasure and pain afterwards giving her the best pleasure in her life. "

    scene v16-166

    "At this point, she couldn't stop her eyes rolling back and moaning like a whore while accepting full length of Murat's swollen cock from her back door. "

    b "Ahhhh, it's hitting me right there..."

    scene v16-167

    b "Keep fucking me like that. Don't dare to pull it out now."

    b "Oh my god...I can't hold it any longer...."

    b "Shit, if you keep fucking..."

    scene v16-168 with vpunch
    play sound "voices/moanfinish.mp3"
    b "Oohhhhhh...."

    b "Damn...I'm..."

    mur "Fuck, look at that."

    scene v16-169
    stop sound
    b "Fuck...I'm so sorry...It was just..."

    mur "It's okay, Banu. You just enjoyed it a bit too much."

    b "I'm really sorry...it was just an accident."

    scene v16-170 with hpunch

    "Murat looked deeply into Banu's eyes, a glimmer of excitement and anticipation in his gaze."

    b "Murat, I have to go. It's late."

    mur "For the next few hours, I want us to have an incredible time together."

    b "But I really can't stay."

    mur "We're having such a great time together, and I don't want it to end so soon."

    mur "You belong to me for the next hours."

    "Banu couldn't say a word as she felt Murat's dick in the enterance of her asshole again."

    "It was too late to reject Murat again..."

    $ renpy.end_replay()
    $ persistent.muratfucksbanuafterfunsexscenestaywithkamil_unlocked = True

    jump muratfucksbanuafterfunsexscenestaywithkamil_continue














label banuteaseinterninhishome:



    scene v16-25 with fade
    play music "audio/sidesex.mp3"

    b "Well, don't you think it's late?"

    sam "Banu, please stay a little longer. I enjoy our conversations and your company. It would mean a lot to me."

    b "Well, Samir, since you asked so nicely, I suppose I can stay a little longer. But remember, I have other things to attend to, so don't get too used to it."

    scene v16-26

    "Banu, feeling a sense of comfort and playfulness in Samir's home, notices his bed and decides to playfully walk over and sit on it."

    "With a mischievous smile, she takes a few steps towards the bed, her movements light and carefree."

    "Banu approaches the bed, her fingers lightly grazing the edge as she lowers herself onto it, settling in with a playful bounce. The bed feels soft and inviting, adding a touch of spontaneity to their interaction."

    scene v16-27

    "Samir watches Banu's playful actions, a mix of surprise and delight on his face. He finds her spontaneity endearing, and it brings a sense of warmth to the atmosphere."

    sam "Banu, you certainly know how to make yourself at home!"

    b "Well, Samir, it's all about being comfortable, right? And your bed looked too inviting to resist."

    sam "I'm glad you feel comfortable here. It's nice to have someone who can bring a sense of lightness to this place."

    "Banu's playful gesture breaks the tension that may have lingered, allowing both of them to relax and enjoy the moment. The simple act of sitting on Samir's bed creates an intimacy that brings them closer together."

    b "So, Samir, since I'm staying a bit longer, how about we play a little game?"

    sam "A game?"

    b "Yeash, come and sit with me."

    scene v16-28

    "Banu, feeling a sense of adventure, suggests playing a game of truth or dare, wanting to delve deeper into their connection. She looks at Samir with a playful glint in her eyes and extends an invitation."

    b "Let's play a game of truth or dare. It's a great way to get to know each other better. What do you say?"

    sam "Um, truth or dare? That sounds... fun, I guess. Okay, let's do it!"

    "They face each other, their knees slightly touching, as the game begins. Banu starts by taking the first turn."

    scene v16-29

    "Banu notices Samir's nervousness and she starts to really enjoy it while slightly caressing his knee with her fingers."

    b "Alright, Samir, truth or dare?"

    sam "Um, let's start with... truth."

    b "Alright, Samir. Here's my question for you. What's the most adventurous thing you've ever done?"

    "Samir takes a moment to think, his face lighting up with a mix of excitement and nostalgia."

    sam "Well, a few years ago, I went skydiving with my friends. It was an adrenaline rush like no other, and I still remember the feeling of jumping out of the plane. It was both terrifying and exhilarating at the same time."

    scene v16-31

    sam "Alright, Banu, truth or dare?"

    b "I'm feeling brave today. Give me the truth, Samir."

    sam "Alright then, here's my question. What's the most embarrassing thing you've done with your husband?"

    scene v16-29

    "Banu's eyes widen, caught off guard by the question. She blushes, realizing she'll have to share a personal and potentially embarrassing moment from her own experiences."

    b "Well, if you wanna hear it, here it comes."

    b "A few years ago when we were having sex, he tried to do me from behind, you know what I mean? "

    b "He tried to enter me from the back door. I could never let that happen of course."

    b "Do you know what happened next? He slept that night on the sofa. I tought him a good lesson that night."

    b "Are you satisfied now?"

    scene v16-30

    "As the game of truth or dare continues, it's Banu's turn to ask Samir an embarrassing truth. She takes a moment to think, her playful eyes scanning Samir, searching for a question that will challenge him."

    b "Alright, Samir, truth or dare?"

    sam "Well, I've survived a few truths so far. Let's stick with truth again."

    b "Alright, Samir. Here's my question for you. Who do you think about when you masturbate?"

    sam "Well, I don't actually masturabte so much...just one or two times in a month..."

    b "Come on, I know that you maturbate every day. I sense it when I look at you but that is not important. Answer my question?"

    sam "Well since we're so open like this...here's the truth. I think about you, Banu!"

    b "Wow...I knew that."

    sam "Are you satisfied now?"

    b "I guess so."

    scene v16-31

    sam "Alright, Banu, truth or dare?"

    b "I'm up for a dare this time, Samir. Bring it on!"

    "Samir's eyes widen, realizing the daring nature of his dare. He takes a moment to gather his thoughts, wanting to push the boundaries just enough to create a playful and exciting moment."

    sam "Alright, Banu, for your dare... I dare you to take off one piece of clothing."

    scene v16-29

    "Banu's eyebrows raise in surprise, caught off guard by the audacity of Samir's dare. She giggles, a mischievous glint in her eyes."

    b "Oh, Samir, you're getting bolder, aren't you? Alright, challenge accepted!"

    scene v16-32 with hpunch

    "It took Samir by surprise that Banu actually started unbuttoning her shirt slowly from the bottom to the top."

    b "Do you think that I'll accept the defeat? Never!"

    sam "Banu...what are you doing?"

    b "What? Don't you want to see what is inside? "

    scene v16-33 with hpunch

    sam "Banu, you really did that..."

    b "Well, do you like what you see?"

    sam "I..I don't know...yeah of course I like it but...I just can't believe you did that..."

    b "This is only for you Samir. I know you wanted to see them so bad, didn't you?"

    sam "..."

    b "Do you want to touch it?"

    sam "Yeah, but..."

    b "Come on touch it already, I don't have much time."

    scene v16-34

    sam "It's so soft and warm, Banu."

    b "Do you like it?"

    sam "Of course I do."

    b "Feel free to play with it but don't squeeze it so hard."

    sam "No, I won't..."

    b "I see you're excited down there...Do you let me touch you?"

    sam "..."

    scene v16-35

    sam_ "Oh shit..."

    b "Wow, you're rock hard."

    b "I didn't know I make you excited like this."

    b "I should definitely be careful around you, big boy."

    scene v16-36 with hpunch
    stop music
    meta "Samir, what are you doing so long here?"

    "As Banu and Samir immerse themselves in the game, their playful banter is suddenly interrupted by the entrance of Samir's mother."

    scene v16-37

    "Banu quickly turned around to button her shirt while Samir confronted his mother."

    sam "Mom, why are you shouting again?"

    meta "What do you mean why I'm shouting? Why hasn't she left already? What is she doing there."

    sam "Mom, she's just picking the documents related to work."

    scene v16-38

    b "I'm sorry, I took a lot of your time. I'm just about to leave."

    "Metanet's disapproval towards Banu is palpable as she enters the room."



    scene v16-39

    "Her cold gaze and distant demeanor make it clear that she does not hold a favorable opinion of Banu."

    "Metanet's brows furrow, and her lips form a thin line, indicating her disapproval."

    meta " Samir, can I speak with you for a moment?"

    scene v16-40

    "As Samir follows his mother, Banu observes the interaction, noting the tension and the strained expressions on their faces. "

    "Banu's suspicions about Metanet's feelings are confirmed as she witnesses the whispered conversation between Samir and his mother."

    "Although unable to hear their words, Banu can sense the gravity of the situation by the disappointment etched on Samir's face."

    "Despite feeling the weight of Metanet's disliking, Banu remains composed, understanding that it's crucial not to escalate the tension."


    $ renpy.end_replay()
    $ persistent.banu_tease_samir_unlocked = True
    jump banuteaseinterninhishome_continue





label abdul_fucksbanu_nexttokamil:



    scene v16-62 with fade


    b "Alright, just finish it quick. Kamil can come any minute."

    ab "Finally...I knew you couldn't take it any longer, Banu. I always knew you had a dark side."

    b "Just stop talking and do what you want to do."

    scene v16-63

    ab "So if you ask me to put it in, I'll gladly do that."

    b "Just fuck me, what are you waiting for?"

    ab "I've been waiting for this moment for so long."

    ab "I knew I'd fuck you from the moment I saw you."

    ab "I could almost see your pussy from the pants."

    b_ "Shit..he's teasing my pussy so bad."

    ab "You did a good job marrying to that stupid Kamil. He wouldn't suspect if you grow my child in your belly."

    b "Don't talk about him..."

    ab "What? you feel sorry for him while leaning over and waiting for me to fuck you? "

    b "Ahhh.."

    b "Just fuck me you worthless piece of shit."

    ab "If you're so desperate like this..."

    scene v16-64 with hpunch

    b "Ahhhh.."

    b_ "Shit, he just put it in..."

    ab "Damn, you're flooding down there...Your're so excited about this, aren't you?"

    ab "It just slided in as put it there."

    b_ "He's thing is so meaty...it rubs my insides so good..."

    ab "Are you ready for more?"

    b "..."

    scene v16-65 with hpunch

    b "Ohhhh ...shit..slow down you animal."

    ab "It's time to go all the way with you."

    ab "Did you think I'd be easy on you?"

    scene v16-66
    play music "audio/tension.mp3"
    k "Banu, what was that? Did you break something?"

    b "Shit!"

    ab "Not now..."

    scene v16-67

    k "Banu, are you there?"

    b "Yeah...I just..."

    scene v16-68

    k "Hey, what's happening here? What are you two up to?"

    b "Oh, Kamil! We're just... uh, talking about real estate stuff."

    ab "Yeah, Banu has been enlightening me about the intricacies of the market. Turns out, she's a real estate prodigy in disguise!"

    k "You don't say! Banu, my dear, when did you become an expert in real estate? You've been hiding talents from me!"

    b "Well, it's news to me too, Kamil. But you know Abdul, always finding ways to make things interesting."

    ab "It's true, Kamil. I couldn't resist tapping into Banu's hidden real estate genius. She's a natural!"

    k "So you only talk about work, huh? I bet there's more to it than that. You two look awfully cozy. Mind if I join in?"

    b "Kamil, you're not in the right state of mind. It's better if you take a seat and relax. We can catch up later when you're feeling better."

    k "You two have a really friendly conversations in the kitchen. I know what's going on, you sly devils!"

    k "Do you think my wife is beautiful, Abdul? I bet you wish you had alone time with her. She's so pretty man. "

    b "Kamil, please, don't say things you might regret. We're just friends, and nothing inappropriate is happening here."

    k "I...."

    scene v16-69 with vpunch
    stop music

    b "Oh no, Kamil! He's collapsed! "

    ab "Man, he's always like this."

    scene v16-70 with fade

    b "Kamil! Kamil, can you hear me? Wake up, please!"

    "Kamil remains unconscious, slumped on the ground, unresponsive to Banu's pleas. Worried, Banu turns to Abdul, seeking his assistance."

    scene v16-71

    b "Abdul, we need to get him to the bedroom. He needs a comfortable place to rest. Can you help me carry him?"

    ab "Ugh, Banu, do I have to? Kamil's such a mess when he's drunk. Always causing trouble."

    b "Abdul, this is not the time for negative comments. Please, I can't do it alone. Help me carry him."

    ab "Fine, I'll do it. But don't expect me to enjoy it."

    scene v16-72

    "Banu watches in surprise as Abdul, without asking for her help, lifts Kamil's unconscious body effortlessly and carries him towards the bedroom."

    "Banu's mind races, processing the unexpected display of strength from Abdul. She couldn't help but admire his physical prowess, even in this challenging situation."

    scene v16-73 with fade

    b "I had no idea you were so strong, Abdul. It's impressive."

    ab "Well, there's a lot you don't know about me, Banu. I have some hidden talents, you know."

    "Banu's gaze lingers on Abdul's determined expression as he continues to carry Kamil with ease. She finds herself contemplating the complexities of their relationship, realizing there may be more to Abdul than meets the eye."

    scene v16-74

    "Abdul just roughly threw Kamil onto the bed. As they both observe Kamil sleeping, a sense of unease settles over Banu."

    b "Abdul, thank you for helping with Kamil. He seems to be sleeping now."

    ab "Yeah, well, he's had one too many, hasn't he? Let him rest it off."

    "Banu can't help but feel a growing discomfort in the room. The absence of others and the presence of Abdul alone with her begins to weigh on her."

    scene v16-75

    b "Abdul, I think you should leave now. It's not right for us to be alone in here."

    ab "Relax, Banu. We can stay here for a little while longer. Besides, we've got nothing to hide, right?"

    "Banu's unease intensifies, her instincts warning her of potential dangers that lie within this isolated moment."

    ab "Are you afraid of being alone with me, Banu? Don't tell me you've forgotten how good we used to be together."

    b "Please, just leave and forget about everything."

    ab "Let's enjoy this moment. He's sleeping like a dead. Your moanings won't wake him up for sure."

    scene v16-76

    b "What the fuck are you talking about? I demand you to leave my house immediately!"

    ab "I was inside of you a few minutes ago. Did you forget that?"

    scene v16-77

    ab "And now we're alone here. There's nobody at home except three of us. Do you think I will back up now?"

    b "Abdul, get out....If you come closer, I'll shout."

    ab "You won't shout. I know you also want to do this."

    scene v16-78

    b "Shit, just get off me, Asshole."

    b "How dare you?"

    b "Let go off me!"

    scene v16-79

    b "Ahhhh...stop that please..."

    ab "Mmmmmmm, you're so delicious, Banu."

    ab "I'll enjoy your body tonight no matter what."

    b "Please..."

    scene v16-80
    play music "audio/hardsex.mp3"
    b "Ahhhh....not here..."

    b "We can't do it here. Kamil is sleeping here..."

    ab "Shut up, bitch."

    b "Hey what are you doing...Put your clothes on. Are you mad?"

    b "Hey, let go off me."

    ab "Take that fucking jeans off. That's it. Take them off fast or I'll just rip them off."

    b "Be gentle you animal..."

    ab "The underwear too."

    b "Wait, not like that..."

    ab "Yeah, this is what I wanted. A fresh married pussy."

    scene v16-81

    b "Wait..where are you taking me?"

    b "Please, not here.."

    ab "Don't worry. We'll try not to wake him up."

    scene v16-82 with vpunch

    b "Ohhhh shit, your cock is so fat."

    ab "And your pussy is tight."

    ab "I'll stretch your hole good enough."

    b "You fuck me so good, keep going...don't stop.."

    scene v16-83

    b "Ahhhhhhh shit...I'm going to cum...."

    b "I'm going to cum over your fat dick....Ahhhhh..."

    ab "Take it, whore. You need a good fucking that Kamil's small dick can't give it to you."

    ab "You need a real man like me."

    ab "You're desperate for this."

    scene v16-84

    b "Ohhhh...You go all the way to my womb..."

    b "Please, slow down...I can't take it....You'll destroy my internal organs..."

    ab "Come on, come here..."

    scene v16-85
    stop music
    ab "Look at my eyes, bitch.."

    ab "Now tell me, who does it better Kamil or me?"

    b "You're so evil man...ahhh..."

    ab "Don't make me repeat myself, bitch...answer me!"

    scene v16-86

    b "Shit...stop it...you're going to kill me..."

    b "Damn...I can't take it..."

    scene v16-85

    b "You do it better, animal. You fuck me better than Kamil..."

    ab "That's a good girl."

    scene v16-87

    ab "I want you to look at his face while I fuck your twat."

    b "Fuck..I don't care...just put it inside of me...I want you cock inside of me..."

    scene v16-88

    b "Asshole...stop teasing my pussy...put it in."

    ab "Your religious pussy is aching for my uncircumcised dick..."

    ab "Doesn't it bother you getting fucked by a non religious dick."

    b "I don't care now..I just want that fucking dick...Please, give it to me."

    ab "You're just a fucking slut, you know that?"

    scene v16-89

    b "Ay mama...please, fuck me harder...Punish my hole...Ahhh"

    ab "Take it, slut..."

    show abdulfucksbanunexttokamilanimation
    play music "voices/moan3.mp3"

    b "Shit...it feels so good..."

    ab "Do you like getting fucked by your husband's friend's fat dick?"

    b_ "Shit...he's an asshole but...he makes me feel so good..."

    b_ "He make slow and halfway thursts but it's meltig me..."



    show abdulfucksbanunexttokamilanimationfast

    b_ "He's fat but so strong...He knows what I need and how to treat me..."

    b "Ohhh...Abdul, do it faster...I'm gonna cum again....Shit..."

    b "Faster, please....Ahhhhhhh..."
    stop music
    scene v16-90

    b "Ay mama...what are you doing to me, old bastart."

    ab "I'm not done yet...Soon Kamil will hear your moanings in his dream."

    scene v16-91

    b "Ay mama....Abdul, I beg you to stop this...I'm gonna pee on the bed..."

    ab "Spread your legs. Don't squeeze my hand."

    scene v16-92

    ab "Don't you hear me?"

    ab "I said spread your legs..."

    b "No...I'm not going to do that."

    scene v16-93

    ab "Now I will fuck the shit out of you slut and you'll understand your place."

    b "Put it in slow, please. It hurts like a hell when you put it suddenly."

    scene v16-94

    b "Ohhhh..it's so fat..."

    ab "Look at his face while I enter you. "

    ab "He's sleeping like a baby leaving you alone with me."

    ab "Will you forgive him for that?"

    scene v16-95

    b "I'm sorry Kamil for being a bad wife...but he's right...this is your fault...ahhh"

    b "Slowly, asshole..."

    ab "What did you call me?"

    scene v16-96

    b "Oh my god....AHHHHHHH....please, please, slowly...."

    ab "Take it, bitch..."

    ab "I'm going to cum deep inside your pussy."

    scene v16-97
    play sound "voices/moanfinish.mp3"

    b "AHHHHHHH.....I'm done, uhhhhhh...shit."

    ab "Take it slut..."
    stop sound
    scene v16-97 with hpunch

    ab "Ahhhhh."

    b "Ohhh...."

    scene v16-98 with fade

    ab "Phew...that was something."

    ab "You have a really high sex drive, bitch."

    scene v16-99 with fade

    ab "I have to admit that I really enjoyed Kamil's money and now his wife. "

    ab "I get really good benefits from him, don't you think?"

    b "You're so evil person, you know that."

    ab "I know that."

    ab "Don't forget to wash your cunt and take some pills because I just came into your womb."

    scene v16-100

    b "Asshole..."

    b "Who said you can cum inside?"

    ab "If you didn't like that I will cum on your face next time...but I'm sure you enjoyed it."

    b "Do you think there will be next time? Dream on you bastard."

    ab "Goodbye for now and say my thanks to Kamil for the night when he wakes up."

    ab "I will visit him often."


    $ renpy.end_replay()
    $ persistent.abdul_fucksbanu_nexttokamil_unlocked = True

    jump abdul_fucksbanu_nexttokamil_continue








label banu_reject_kamil_anal_corruptedroute:

    scene v17-1 with dissolve
    b "FFFuck...Kamil you're doing a fantastic job here."
    b "I've always wanted to do it with you."
    k "Mmmm...do you like it here?"
    scene v17-2 with dissolve
    b "I love it! You're the best pussy licker in the world, Kamil. I hope you don't get offended."
    k "No...I don't."
    scene v17-3
    b "Yessss! Bury your head between my asscheeks."
    b "Wow...You're getting intense. I bet you enjoy it the same I enjoy. "
    k "Yess, my love...I love licking every inch of your body."
    scene v17-4
    b "Yess...do it faster. Ahhhhhh! I'm gonna cum on your face, Kamil."
    b "Do you want your wife to cum on your face? "
    k "Yess, I'd like your juices on my face..."
    b "Fuck!"
    scene v17-4 with hpunch
    play sound "voices/moanfinish.mp3"
    b "I'm cumming, Kamil! AAAAAHHHHHHHH!"
    b "You're an asshole, Kamil, you know that?"
    stop sound
    b "Lay down on the floor! I'll make you eat my whole pussy."
    scene v17-5 with fade
    b "I never knew you're so eager to eat pussy."
    k "Mmmm, I'd do anything to make my wife happy."
    b "Fuck yeah!"
    b "Eat your wife's dirty pussy then.."
    scene v17-6
    k "But what about returning the favor?"
    b "Shut the fuck up and keep cleaning."
    b "You're not allowed to speak until you lick it clean. "
    b "That's it. My legs hurt. Let's move it to the bed."
    scene v17-7 with fade
    b "Holy shit!"
    b "You're so good at stimulating my clitoris. Keep doing that."
    b "If you do a good job down there, maybe I can let you use it as it's designed to be used."
    k "Do you think I'd ask a permission?"
    b "You have to, you little slave! Because I'm the queen of this house, remember?"
    scene v17-8
    k "But seriously, why don't you suck my dick? It's only fair, right?"
    b "We talked about it, Kamil. I can't do that."
    k "But why? I don't understand that."
    b "I love you Kamil, but I'm a religious woman and I visit mosque and you know that."
    b "I can't get into a dirty stuff like that make myself dirty. I hope you understand that and I believe you'd like your wife to be pure forever, wouldn't you?"
    k "That's true. But I hope it doesn't stop me taking you hard from behind!"
    scene v17-9 with vpunch
    b "AHHH!"
    b "Wow! You're so energetic today."
    k "Seems like I got you so wet down there."
    scene v17-10
    k "Now it's time to fuck!"
    b "Uuuuhhh, I like it when you're rough like this."
    b "Come on keep fucking me like that. Show me what you got."
    scene v17-11 with hpunch
    "As Banu was in the middle of a building orgasm, Kamil suddenly pulled his cock out and brought it closer to Banu's asshole."
    k "There's something I want to try tonight."
    b "What!"
    k "I want to try something new, something we've never done before. I want to explore a different side of our intimacy, something more adventurous."
    b "What the fuck, Kamil!"
    scene v17-12
    k "I understand it might be a bit out of our comfort zone, but I think it could be exciting, and it might bring us closer together."
    b "GET OFF ME, ASSHOLE!"
    scene v17-13 with hpunch
    b "How could you do that to me?!"
    k "Banu, I'm really sorry for making you uncomfortable. I shouldn't have brought it up like that."
    b "Brought it up like that? You just tried to put it in my ass, Kamil."
    k "Banu, I'm really sorry to make you upset. Let's just forget about it?"
    b "How could I forget about it, Kamil. You just tried to fuck your wife's ass."
    scene v17-14 with fade
    k "Look, Banu. I'm really sorry."
    b "How could you even consider something like that? Do you think I'm that kind of woman?"
    k "No, Banu, that's not what I meant! I didn't mean to offend you. It's just... I thought we could try something new and exciting together, something that could deepen our connection."
    scene v17-15
    b "But why would you think that I would be okay with it? Have I ever given you the impression that I'm interested in that sort of thing?"
    k "No, you haven't, and I shouldn't have assumed. I'm sorry for misjudging what you might be comfortable with."
    b "It's not just about misjudging, Kamil. It's about respecting me and our relationship. I never expected you to try something like that without even discussing it with me first."
    k "Banu!"
    b "That's it. Just leave me alone for some time."
    k "..."





    $ renpy.end_replay()
    $ persistent.banu_reject_kamil_anal_corruptedroute_unlocked = True

    jump banu_reject_kamil_anal_corruptedroute_continue








label turan_destroy_banu:

    scene v17-80 with Fade(0.5, 0.5, 5)
    b "AHHHHHH....."
    t "You're moaning so loud lately. Like an animal."
    t "Or is your husband's dick not good enough for you."
    b "Ahhh...I told you....not to talk about my family...you're breaking...the rules."
    t "Bitch, you're really way too fun. "
    t "I've never had this much fun bullying a woman sexually before."
    t "Are you ready to take my whole cock?"
    show turanfucbanustandinganimation
    play music "voices/softmoan.mp3"
    b "Oh fuck!"
    t "Your womb is so desperate to feel my cock, Banu. "
    b "Fuck...just stop talking."
    b_ "I think I realy like...."
    b_ "Ahh crap... I can't take it anymore..."
    t "Now I'l show you my full potential."
    b "Wait, this isn't your best?!"
    show turanfucbanustandinganimation_angle
    b "Hng...ooohhhhh.."
    b "Ahh...Mn...Argggnn."
    b_ "His cock reaching deep inside my womb."
    b_ "It's melting my brain..."
    b_ "Why sex with him feels this good."
    stop music
    scene v17-81
    b_ "He goes deeper with every thurst..."
    b_ "I can't help but feel pleasure."
    b_ "I've no power to reject him anymore..."
    b_ "He can do anything to me now."
    scene v17-82
    t "Our faces are so close right now..."
    t "Close enough for me to take your lips."
    b "Huh? Not a chance, idiot!"
    b "Stop it!"
    t "Come on, Banu. I know you want some love."
    b "I told you to stop it."
    scene v17-83
    t "Better hold on tight, Banu so you don't fall."
    b "Don't push it or you'll get..."
    scene v17-84
    b_ "Fuck! I can't do this anymore."
    b_ "I can't reject him while his fat cock is deep inside of my womb."
    scene v17-85
    b_ "But I can't let him kiss me. I can't break my own rule and let a man like him kiss me."
    b "Shit! What are you doing? Stay away from me!"
    b "Stop doing that or I'll..."
    b "Ahhhhhhhhh..."
    b_ "He's fucking me so hard...."
    b_ "I bet he's doing it on purpose."

    scene v17-86
    b "Please, don't do that...Ohhhhh..."
    t "Rejecting me like this huh?"
    b "Please, I can't do this. I don't want you to kiss me....I don't want you...AAHHHHH..."
    scene v17-87 with hpunch
    b "AAAAHHHHH!"
    b "What the hell are you doing?!"
    t "You'll love this, Banu."
    b "Take it out right now!"
    t "What? There's no way I'm doing that."
    scene v17-88
    "Banu was in a shock of penetration in both holes at the same time."
    "She kept telling Turan to let her go but he wasn't doing that."
    "Turan kept fucking Banu's pussy so hard while fingering her ass at the same time."
    "At this point, Banu's brain was melting as she lost control of herself and let the pleasure take over her."
    scene v17-89
    "Turan was so fast to take a chance to bring his head closer to Banu and started to kiss her."
    b "MMMppp..."
    b "MMmmmmmm"
    "At this point she had no power left but had to go with what Turan had in mind."
    scene v17-90
    "Turan started to kiss all over Banu and found her sensitive spot."
    "Banu unconsicuously wrapped her arms around him not to fall off."
    "Turan continued to go with his plan to make her submit to him completely."
    scene v17-91
    "He pulled Banu so hard to his body kissing her neck while occupying both her pussy and ass."
    "Banu had nothing to do left but moaning from the pleasure coming from all three holes. "
    scene v17-92
    b "AHHHHHH...please, Turan, please..."
    t "You see? Your ass got used to it."
    t "I'll stretch it good so my cock enters without any problem."
    t "I think it's ready to go...Turn around now and put your hands on the glass."
    scene v17-93 with hpunch
    b "AYYYY MAMA! "
    b "OOOOOHHH....it's tearing me apart...please, take it out!"
    scene v17-94
    t "Sorry, I couldn't hold myself. I thought you were ready for it. My bad."
    b "Please, take it out, your cock is so fat..."
    t "You're complimenting my cock a lot recently. Thank you."
    scene v17-95
    t "Fuck! Your ass is so tight, girl."
    t "I'll stretch it good."
    b "Oh my god, it's hitting me so bad inside..."
    b "Ohhhhh...I'm going to pee. Please, stop."
    scene v17-96
    t "Fuck, look at the gaping hole."
    t "I'd say your pussy is so tight like your ass."
    t "Look at the view. I have to take a video of this beauty and show it to you next time."
    b "Please, finish already. I can't stand anymore..."
    t "Your'e right. It's enough show for my neighbors."
    scene v17-97
    "Once Turan take it to the floor, he started to pound Banu's ass harder while he enjoyed to insult her."
    b "FUUUUUCKK! Please, be gentle..."
    t "I bet you never let your husband fuck you in the ass."
    scene v17-98
    t "It's because you need a real man."
    t "You can't go against me. "
    t "You reject me first but later you raise your ass enough so my cock enters deeper."
    scene v17-99
    t "You must accept the fact that from now on, your ass and pussy belong to me."
    t "Don't forget that I've the key to your back door. "
    scene v17-100 with vpunch
    b "AAAAHHHHHH!"
    t "Your hole squeezing me so hard that I'll fucking cum.."
    t "But first I need you to clean my cock..."
    scene v17-101 with vpunch
    b "What do you think you're doing?"
    t "I want you to clean it."
    b "Fuck off."
    scene v17-102
    t "Banu, don't get on my nerves."
    b "I said fuck off. Do you think I'm a cum dumb?"
    scene v17-103
    t "Come on, take it."
    t "I know that you want it."
    t "Your rejection doesn't change the fact that you love my cock."
    b "That's ridiculous."
    scene v17-104
    b "Will you take it from my face?"
    t "It depends on your choice."
    t "I have enough time, Banu."
    b_ "Damn, he won't let go of me..."
    scene v17-105
    b_ "The smell of his cock...that's...too hard."
    b_ "It's the first time I see it so close to my face and it's...so huge."
    b_ "I can't believe it was just in my ass..."
    b_ "It's morally wrong but...he won't let me go."
    b_ "I better make him cum faster."
    scene v17-106
    t "That's it, girl."
    t "I knew you were eager for this..."
    show banusuckingturananimation
    play music "voices/bj.mp3"
    t "Look at you...trying to make me cum huh?"
    t "Doesn't it bother you that it was just in your ass?"
    t "You're such a cock hungry whore."
    t "Keep going. Make daddy to cum deep in your throat."
    t "That's it...it's just there..."
    stop music
    scene v17-107 with vpunch
    t "OHHHHH....yeah..."
    t "Fuck! Take it all, bitch!"
    b "Ummm.."
    t "Fuck! Swallow it all, Banu. You'll get addicted to it."
    scene v17-108
    b "I hate you!"
    t "I don't care anyway."
    scene v17-109 with fade
    t "Wait a moment."
    b "What?"
    scene v17-110
    b "What is this?"
    t "Just a little something. A gift."
    b "A gift? You've got to be kidding me."
    scene v17-111
    t "It's more than just a gift, Banu. Think of it as a reminder."
    t "You will carry it with you. To be more clear you will carry in in your ass and won't take it out unless you are told so."
    t "That will remind you of me, your master."
    b "You're trying to play mind games with me again? "
    b "I'm not going to do that..."





    $ renpy.end_replay()
    $ persistent.turan_destroy_banu_unlocked = True

    jump turan_destroy_banu_continue



label polad_banu_forest:

    scene v17-144 with fade
    p "Whoa, Banu! Didn't know you were up for a little adventure."
    b "I knew that I shouldn't trust you. You liar."
    p "Do you miss me?"
    b "You know, Polad, there's something about moments like these that make you realize how much we miss in our busy lives."
    b "And being here, surrounded by nature, feeling the sun on my skin and the breeze in my hair, it's like I've been awakened."
    scene v17-145
    "Samir, still hidden behind the trees and grappling with his own emotions, can hardly believe his eyes as he witnesses the scene before him."
    "His shock intensifies as he sees Banu kneeling in front of Polad."
    "His heart races, and a mix of disbelief, confusion, and a twinge of pain washes over him. He struggles to process the sight before him – Banu, someone he's admired from afar, in a vulnerable position in front of Polad."
    scene v17-146
    "Samir's shock freezes him in place, his gaze locked on the unfolding scene."
    "He's torn between wanting to approach and understand the situation and the fear of confronting his own emotions and the potential complexities of Banu's relationships."
    scene v17-147 with fade
    p "Go deeper, baby."
    b "I can't...idiot...you're so big."
    p "Lick it good and clean...I know you missed this smell already."
    scene v17-148
    p "It's already better than the last time. You improved a lot."
    b "Well, thanks...ummmm.."
    p "You already got addicted to my cock. I bet yo think about it all day long."
    scene v17-149
    p "I have to admit, Banu...I missed this too. I missed you choking on my dick."
    p "Now I'm finally alone with you to give you what you want...to fuck you senseless."
    p "Now stand up. I'm gonna fuck your brains out."
    scene v17-150 with fade
    b "Ahhhhhh. Be careful, animal! You'll never be a gentleman."
    p "You're right. I can't be gentle with you. I just want to give it to you. I'm going to fuck the shit out of you."
    scene v17-151
    b "You're an animal!"
    p "You are driving me crazy, Banu. Your curves, your beautiful face, your lustful eyes and how you look at me with those eyes, it all make me crazy."
    show poladfuckbanuforestanimation
    play music "voices/softmoan.mp3"
    b "Ohhhh, fuck!"
    p "I'll give you what you want. "
    p "I'll give you what that idiot can't give it to you."
    b "Fuck! Fuck! Fuck!"

    show poladfuckbanuforestanimationfast
    p "I missed fucking you so much. I love how your pussy queezes my dick."
    p "You'll never forget about me, Banu."
    p "I'll always be the first man in your memory."
    b "Fuck...my pussy is going to break..."
    p "You'll be masturbating in your bed countless times thinking about me fucking you."
    stop music
    scene v17-152
    b_ "I can't reject this man."
    b_ "I know this is wrong but the way he makes me feel...I never felt that way before."
    b_ "His manliness, his muscles, how he talks to me...they all make me weak against him."
    b_ "I hate the fact that he was the best friend of my dead husband."
    b_ "How he could do something to his best friend. He's a tough but an evil man at the same time."
    scene v17-153
    "As Samir observes them, his initial shock and uncertainty have given way to a sense of excitement as he pulls down his shorts and grabs his hard cock. "
    "The way Banu and Polad fuck makes it impossible to believe it. It's not the same Banu he sees daily basis at work. She's different now..."
    scene v17-154
    p "What happened."
    b "Didn't hear the sound? There might be somebody here."
    p "Stop playing with me."
    b "No, I'm serious but....anyways I don't care if anybody catches us."
    b "But seriously let me just take my breath. You're so rough with me. At least give my pussy a little break."
    scene v17-155
    b "Do you know that we both will go to hell eventually?"
    b "You're betraying to your best friend and I betray to my husband. "
    b "Don't you feel like this – you fucking me – is a betrayal of his memory? He trusted you, and now... we're dishonoring that trust."
    scene v17-156
    p "I never intended to disrespect his memory."
    b "Every time I look around, I can't help but remember how close you both were. How he trusted you with everything."
    p "I can't believe you're trying to make me feel guilty for bringing you here."
    scene v17-157
    p "The reason we're here is that you want me."
    p "You're a slutty woman. You can't deny that. "
    p "You're not a regular woman. You need attention and most importantly...you need my cock."
    p "Now take off that head cover. I wanna touch your hair."
    scene v17-158 with fade
    b "Ahhhhhhhhh...Don't stop."
    b "Don't stop kissing me. You kiss me like you never see me again. I like that."
    b "And your cock...it's so hot."
    scene v17-159
    b "I can't help it...I want you, Polad. "
    b "I need you to punish me for being a bad wife...Fuck me, Polad! Take me!"
    scene v17-160 with hpunch
    b "Fuuuuuucckkkkk! It's so deep inside of me..."
    p "You'll never forget this day."
    b "Ahhhh..I love how you do it. I love it...I love you, Polad."
    scene v17-161
    "The connection between Polad and Banu is like an intricate dance, a rhythm that's uniquely their own."
    "It's a blend of history, shared experiences, and a magnetic pull that draws them together despite the complexities that surround them."
    "The passion that simmers beneath the surface is undeniable. It's not just about physical attraction, but an emotional intensity that's born from the challenges they've faced together. "
    "Their passions are mirrored in their eyes when they engage in sex, their gazes holding a depth that goes beyond words."
    scene v17-162
    "Banu finds herself pulled into a gravitational force she can't resist – a force that centers around Polad. "
    "Polad's presence makes Banu weak and feminine. She doesn't care about anything when he's deep inside her."
    scene v17-163
    "The pain she feels when Polad's fat, big cock is deep inside of her turns into sweet memories which will stay with her forever."
    "Polad's presence sparks a flutter in her heart, a warmth that spreads through her veins. It's not just his appearance."
    "It's the way he fucks her, truly listens when she speaks. It's the way he challenges her, pushes her beyond her comfort zone."
    scene v17-164
    "Banu discovers a newfound sense of liberation when she's around Polad – a freedom to be herself without reservation or pretense."
    "In his presence, the walls she once carefully constructed seem to crumble, allowing her true self to shine through without shame or hesitation."
    p "I didn't know you were this flexable."
    b "Shut up and fuck me!"
    scene v17-165
    "As Samir continues to observe Banu and Polad, he finds himself captivated by the dynamic unfolding before his eyes."
    "The initial shock and jealousy that gripped him have transformed into a sort of horniness and excitement – an excitement that's hard to ignore, even if he tries."
    "He started to stroke his cock faster as he obeserved that the show was going to end soon. "
    scene v17-166
    b "Oh my god! Your cock hits my deep spots..."
    b "If you continue this, you're going to knock me up...Ahhhhh"
    p "I'm not planning to cum inside you."
    b "Ahhh...what!?"
    p "Ohhhh shit, get on your knees!"
    scene v17-167
    p "I see you are excited about this."
    b "I've never done this...."
    scene v17-168 with vpunch
    p "Arrgggg..."
    b "Oh my god!"
    b "P-Polad..."
    p "Ohhhh shit...look at that...you look so dirty, Banu."
    scene v17-169 with vpunch
    "Samir's gaze lingers on Banu's messed up face, on the dirty way she talks with Polad. "
    "He couldn't hold any longer and ejaculated looking at the beautiful view in front of his eyes. "
    scene v17-170 with fade
    b "Asshole! You should've warned me about this."
    b "At least give me something to clean my face."
    p "There's a spring nearby so you can wash your face."
    p "Be quick, Banu. Pick up your clothes or I'm going to leave you here."





    $ renpy.end_replay()
    $ persistent.polad_banu_forest_unlocked = True

    jump polad_banu_forest_continue







label murat_threesome_2:


    scene v17-224 with fade

    b "A game?"

    mur "Yep, a classic spin-the-bottle game. We'll spin the bottle, and whoever it points to has to take off one piece of clothing."

    b "Murat, I think that might be taking things a bit too far."

    va "Yeah, I'm sure that's the best idea right now."

    mur "Oh, come on, Banu. It's just a bit of fun. We could use some laughs to break the tension, right?"

    b "Alright, fine. But just one round, and let's keep it lighthearted."

    scene v17-225

    mur "Alright, let's keep this game rolling."

    "With a flick of his wrist, Murat spun the bottle. The room seemed to hold its breath as the bottle twirled, its momentum gradually slowing down."

    scene v17-226

    "The suspense was palpable, and then, as if guided by fate, the bottle's neck came to a stop, pointing directly at Banu."

    b "Well, what are the odds?"

    mur "Fate has spoken, Banu. Your turn."

    "A lighthearted yet nervous laughter filled the room as Banu took a deep breath, her fingers moving to the delicate fabric of her hijab."

    scene v17-227

    "With a practiced grace, she carefully removed the hijab, revealing her hair that had been hidden beneath it."

    "The atmosphere seemed to shift, a mix of emotions lingering in the air – surprise, curiosity, and a touch of vulnerability."

    "Banu's expression remained composed, her gaze meeting the inquisitive looks of her friends."

    b "I hope this doesn't change your perception of me."

    va "Exactly. We appreciate your openness, Banu."

    scene v17-228 with fade

    mur "Well, it seems I'm next in line for a wardrobe adjustment."

    scene v17-229

    b "Well, Murat, I have to say, I never expected you to be the one leading our impromptu fashion show."

    mur "You know, Banu, I'm full of surprises. Besides, I couldn't let Vasif have all the fun, could I?"

    b "Oh, absolutely not. We can't have Vasif hogging the spotlight, can we?"

    scene v17-230

    b "Well, I have to say, you're certainly proving your expertise."

    mur "You haven't seen anything yet."

    "As Murat unbuttoned his shirt and began to remove it, Banu's gaze shifted subtly, her curiosity piqued by the unexpected turn of events."

    "Her eyes trailed over the exposed expanse of his chest with a sense of longing but quickly she took her eyes off."

    scene v17-231 with fade

    mur "It seems luck is on Vasif's side tonight."

    "The room was now filled with a mixture of anticipation and laughter, the game having taken on a life of its own."

    "The bottle twirled, the suspense building as it gradually slowed down, finally coming to a stop, its neck pointing directly at Vasif."

    va "Well, well, it looks like I'm the chosen one."

    b "Looks like the fashion show continues, Vasif."

    scene v17-232 with hpunch

    va "Here you have it."

    "As Vasif unbuttoned his shirt and removed it, Banu's gaze shifted, her eyes involuntarily tracing the contours of his body."

    "A mixture of surprise and admiration played across her features as she took in the sight of Vasif's burly frame, the muscles of his arms and chest clearly defined."

    scene v17-233

    b "Vasif, I have to say, I'm impressed. You've been hiding those muscles under that shirt all this time?"

    va "Well, I guess I don't usually have an excuse to show them off."

    b "You're definitely making a statement now. All that dancing and you're hiding this impressive physique?"

    va "I guess I've been keeping it my little secret."

    mur "Who knew you were the undercover bodybuilder, Vasif?"

    va "Okay, okay, enough with the teasing."

    scene v17-234

    b "Well, well, now that we've all taken turns shedding some layers, I have to say, you two are quite the unexpected duo. Vasif with his undercover muscles and Murat with his spontaneous strip show."

    va "Who would've thought our night would take this turn?"

    mur "Hey, I'm all about keeping things interesting."

    b "Oh, I can see that. First the dancing, then the fashion show – what's next on the agenda, gentlemen?"

    scene v17-235 with fade

    mur "Looks like the bottle is having a field day with Banu tonight."

    "With another spin of the bottle, the room was filled with a mix of anticipation and laughter. "

    "As the bottle slowed down and finally came to a stop, its neck pointed directly at Banu."

    b "Well, well, it seems I'm up next."

    va "The fashion show continues, Banu."

    "Banu's gaze moved to the bottle and then back to her friends, her expression a mix of amusement and a hint of excitement."

    scene v17-236 with fade

    "With a final flourish, Banu removed her shirt, exposing more of her skin and leaving her cute bra underneath."

    "Her expression remained composed, her eyes meeting the amused gazes of her friends."

    b "Well, someone has to keep the game interesting, right?"

    va "You're definitely succeeding in that."

    scene v17-237 with fade

    "As the bottle gradually slowed down and came to a stop, its neck pointed at Vasif once again, a chorus of laughter filled the room."

    mur "Vasif, it looks like you're the star of the show tonight."

    va "I'm starting to think this bottle has a thing for me."

    b "It certainly seems that way. Are you ready for your encore performance?"

    scene v17-238

    va "I guess it's my turn to keep the fashion show going."

    b "Seriously? You're going to do that?"

    va "Are you ready?"

    scene v17-239 with vpunch

    "As Vasif removed his pants, Banu's gaze naturally drifted to his exposed member."

    "A sense of shock and admiration played across her features as she took in the sight of his giant cock, particularly the shape and the girth of his cock which appeared notably big and heavy."

    scene v17-240

    va "Oh, Banu, I see I've managed to surprise you. Should I be worried that you're speechless?"

    b "Oh please, Vasif. It's not every day I see someone's cock take up half the room. It must be difficult to carry this weight everywhere you go."

    va "Well, you know, I have to make sure I'm always prepared for a beautiful woman like you."

    b "I can't help but think you'd have an unfair advantage..."

    scene v17-241

    "The next time as the bottle gradually slowed down and came to a stop, its neck pointed at Banu once more."

    va "Looks like the bottle is favoring Banu tonight."

    b "Round and round it goes, where it stops, only the bottle knows."

    va "It seems like it has a thing for you."

    scene v17-242

    b "Okay I guess I have to go with the rules but promise guys not to stare."

    b "I see those curious glances!"

    b "No staring, gentlemen. Haven't you heard that it's impolite to ogle a lady?"

    mur "My apologies, Banu. It's just hard not to be a little surprised."

    scene v17-243

    va "You know what Banu? That's enough teasing for us."

    b "Wait, what do you mean?"

    va "You've been torturing us since we met today. I think it's time for us to get a little closer."

    b "Vasif, please, don't make things complicated. Please, don't come closer."

    scene v17-244 with vpunch

    va "Throughout all these moments, all the laughter and conversations, I've realized that I want you even stronger. I can't help it anymore."

    va "You're desperate, Banu. I want to give it to you, the best sex in your life."

    b "You know....I didn't know things would go this far...I need to go. It's getting late already."

    scene v17-245

    va "Do you feel how hard you made me? Do you think it's fair if you leave now?"

    b "Oh Vasif...I'm sorry but I can't stay any longer...I'm not ready for this."

    va "You're not going anywhere until you get your reward. Now the fun part begins. We'll make sure that every hole of yours is filled and satisfied."

    b "Listen...Vasif, I understand that you are young and horny and energetic but...I have a life and you need to understand that."

    va "Fuck that! Right now the only thing you need is my big, fat dick."

    scene v17-246 with fade

    "While Vasif groped and talked dirty to Banu, Murat quickly got rid of his clothes and joined Vasif and Banu."

    b "Hey wait! wait! guys..."

    b "Listen...this is definitely not a good idea."

    mur "Come on Banu, just relax a bit. You're so tense right now."

    scene v17-247

    va "Come on take off these cute bra and pants so we can see what we're dealing with."

    b "Fuck, guys...you're not letting it go..."

    va "Come on, Banu. I'm sure you're wet right now. You can't keep your eyes off my cock since I removed my pants."

    b "You're an asshole, Vasif. You know that?"

    scene v17-248

    va "Wow look at here. Man, she's dripping wet down there."

    mur "I told you man. She won't stop until our balls are drained."

    b "Shut up, Murat!"

    scene v17-249 with fade

    "After a few minutes, the sense of connection and desire among them deepened."

    "They moved to the sofe with Vasif sucking on Banu's nipples and Murat grabbing her from behind kissing her neck."

    scene v17-250

    b "Ohh guys, you're so passionate about this...you definitely know how to please a lady."

    "With each passing moment, each kiss exchanged, Banu's body got more excited and her pussy felt more vulnerable. "

    scene v17-251

    "As they continued to engage in the various poses, Banu's moaning became lauder that motivated the two young men."

    "The room was full of moaning and slapping sounds which Banu won't forget for a long time."

    "Vasif and Murat exchanged a quick glance, winking at each other while Murat pounding her harder. "

    "Without a word, they both raised their hands and gave each other a high five."

    scene v17-252

    "Banu cought her breath and found herself stroking Vasif's giant cock while Murat fucking her pussy. "

    "As she got her logical thinking back for a moment, she was again shocked by the size of Vasif's horse cock."

    scene v17-253 with fade

    "After some time, their time around the billiards table was a continuation of the night's theme – full of hard sex."

    "Banu put her hands on the billiards table and raised her hips for Vasif."

    "He bent Banu over as his liking and came closer to put his giant cock into action. "

    scene v17-254 with hpunch

    b "AHHHHHHH..."

    va "Fuck! I've been waiting for this..."

    b "Hey careful, you're going to tear me apart."
    scene v17-255 with hpunch
    b "AHHHHHHHHH..."
    va "Fuck! This pussy is so tight for my dick."
    b "Please, slower...It's tearing me apart...Ohhhhh"
    va "I'm going to ruin your pussy."
    show blondefucksbanustandinganimation
    play music "voices/moan4.mp3"
    b "Ahhhhh...that's fucking deep..."
    b "Your cock is invading my womb...It's so different...Ummmm"
    va "Let's see how much your milf pusssy can take."
    va "This married pussy is not stretched enough."
    va "I'm going to ruin you for other dicks, Banu."
    show blondefucksbanustandinganimation_fast
    b "Fuck, Ay mama! you're so deep..."
    va "Fuck, Murat, her pussy is sucking my dick so bad."
    mur "Give it to her, man. She's a bad wife and needs to be punished bad."
    va "Fuck yes..."
    stop music
    scene v17-256 with fade
    b_ "Those guys were savages."
    b_ "They were not just fucking me...they were taking my breath, killing me."
    b_ "They fucked me in every corner of the room in various degrading positions."
    scene v17-257
    b_ "That night was not just about friends having fun."
    b_ "They were degrading me, punishing me and I can't deny the fact that I loved it."
    b_ "I loved being used by those young men and fuck in every hole. "
    b_ "Murat's young and curvy dick was giving my asshole the best pleasure I've ever experienced."
    b_ "I got addicted getting fucked in the ass. I like how the pain turned into a mind-blowing pleasure."
    scene v17-258
    b_ "Vasif was so hard on me. He violated my mouth with his horse cock while Murat fucking my ass."
    b_ "Vasif was turned into an animal. He enjoyed fucking me hard and degrading me. "
    scene v17-259
    b_ "Those two young men were so different from Kamil."
    b_ "As Kamil never made me feel at my limit, with those guys...it was so intense."
    scene v17-260
    b_ "They fucked me in all three holes making me crazy."
    b_ "My brain melted, my body was continuously shaking from hard orgasms."
    b_ "It was the first time I got two cocks inside me at the same time."
    scene v17-261
    b_ "They banged my holes for hours and hours senslessly."
    b_ "Murat was continuously hitting my g-spot while Vasif's dong was inside of my."
    b_ "I couldn't believe how a dick that size even fit inside of me. "
    scene v17-262
    b_ "At that time, I had only little power left from those powerful orgasms."
    b_ "My body was weak and sweating from the hard fucking session that continued for hours."
    b_ "Their stamina shocked me and I thought they would last forever."
    scene v17-263 with fade
    b_ "But it finally came to an end with those beautiful creampies."
    b_ "Those two men gave me some good memorable moments in my sex life."
    b_ "After I came to my senses the gentlemen helped me to move to sit on a sofa as I couldn't move by myself after that hard fuck."
    scene v17-264 with fade
    play music "audio/up.mp3"
    va "Fuck! That was the best. Did you enjoy it, Banu."
    b "I truly did. This evening turned out to be quite the unexpected adventure."
    scene v17-265
    mur "So, I guess we're officially your partners in spontaneous escapades now?"
    b "That seems to be the case. Who would've thought a night that started at a club would lead us here?"
    b "Vasif, I have to say, even after all these activities, your dick still deserves a round of applause."
    mur "Man, looks like your dick got her attention."
    va "Hey, I'll take all the attentions I can get."
    stop music
    scene v17-266
    "As the laughter and playful banter continued around her, Banu's expression shifted from amusement to something more introspective."
    "In that moment, the events of the night and the complexities of her emotions collided, leaving her feeling out of place."
    "Why am I even here? she thought to herself. I shouldn't have joined them. What was I thinking?"

    $ renpy.end_replay()
    $ persistent.murat_threesome_unlocked = True
    jump murat_threesome_2_continue



label gym_shower_fuck:

    scene v17-290 with fade
    b_ "The way he carries himself, his confidence – it's alluring. And those muscles… I can't help but admire the hard work he's put in."
    b_ "I wonder what he's like outside the gym. He's so approachable and supportive during our workouts. His smile is contagious, and his encouragement pushes me to challenge myself."
    b_ "But there's more to him than his physical strength. "
    b_ "Could there be something more between us? Or am I reading too much into this? After all, he's my gym instructor and a friend. Is there room for something beyond that?"
    scene v17-291 with fade
    b_ "Why do I find myself constantly stealing glances at him? It's like an involuntary reaction, and I can't help but wonder why."
    b_ "I can't help myself but peek him in the shower lately. Luckly he didn't catch me."
    b_ "Those muscles... they're hard to ignore. "
    scene v17-292
    b_ "The way they ripple and flex with every movement – it's captivating. I can't help but admire the results of his hard work, the dedication he puts into his fitness."
    b_ "It's not just the physical aspect that draws my attention. It's the strength they represent, the determination and discipline required to build and maintain them."
    scene v17-293
    b_ "There's an allure in his confidence, the way he carries himself, and those muscles are a visible reflection of that."
    b_ "But I need to remind myself that there's more to a person than just their physical appearance. Maybe his muscles are not the biggest thing he has. Who knows?"
    b_ "Maybe I can find out..."
    scene v17-294 with fade
    b_ "I peeked him several times in the past month. I feel shameless but it doesn't stop me doing it again."
    b_ "He's become more than just my gym instructor; he's someone I can't help but think about."
    scene v17-295
    b_ "But is this just a passing crush? Or is there something deeper here? I'm drawn to his energy, the way he challenges me during workouts, and the moments we share that feel like more than just casual conversations."
    b_ "These thoughts persist, making it difficult to focus on anything else. It's a mixture of excitement and uncertainty, and I'm not sure where this path might lead."
    scene v17-296
    b_ "Every time I see him, my heart skips a beat. "
    b_ "I can't deny this growing attraction, this pull that seems to get stronger each day."
    scene v17-297
    b_ "Thinking about Hasan, being drawn to him in this way... it feels like I'm betraying the commitment to Kamil."
    b_ "But I can't help it. I'm sorry, Kamil... but this have to happen one day."
    scene v17-298
    b_ "As he saw me there, he was surprised at first, but just a few seconds later, I was in his arms and we were kissing."
    b_ "He just took me as if he was already expecting me."
    scene v17-299 with dissolve
    "And in that simple, shared moment, Banu felt closer to Hasan than she had before."
    "Their exchange had moved beyond the realm of trainer and trainee."
    "Hasan pushed Banu against the wall admiring her beautiful naked body and pretty face."
    "Banu was looking at his eyes while feeling his growing cock on her belly."
    scene v17-300 with dissolve
    "Suddenly, Hasan bent Banu over with a forceful behavior and placed his dick at the entrance of her already wet pussy."
    "Banu felt Hasan's dick slowly entering her, stretching her pussy while feeling his heavy hands on her hips."
    show gym_fuck_animation
    play music "voices/softmoan.mp3"
    b "Ohhh fuck! Don't stop! Don't stop!"
    b "Keep fucking me like that!"
    ha "Fuck, you have a tight pussy, Banu."
    b "Keep fucking me, baby, I love it..."
    ha "Fuck! This feels so good."

    b "Don't stop, Hasan. Fuck me the way you want."
    b "I wanna be yours. Take my body...it's all yours."
    b "I love when you make my knees weak every time."
    b "Fuck me harder! Ahhhhhh...pound my pussy!"
    stop music
    scene v17-301 with fade
    b_ "The continuous fucking and Hasan's stamina made my legs weak that I couldn't stand on my feet anymore."
    b_ "He took me and raised me in the air and I landed on his still hard dick."
    scene v17-302
    ha "After the hard workout you've done today, you need to be treated well."
    ha "And your pussy needs a good fuck."
    b "Ahhhh, I...I can't stop cumming, Hasan. I can't take it anymore....please don't let me down...ahhhh."
    scene v17-303 with fade
    "The intensity of the sex was evident on her face as her breath quickened."
    "Sweat glistened on her forehead, and her breaths became heavier."
    "She could feel her heart racing between the hard orgasms she had."
    "As Hasan started groaning she felt warm cum filling her pussy."
    scene v17-304
    "Banu's legs still shaking from the hard orgasm she just had."
    "They both experienced the excitement of cumming at the same time."
    "At this time, Hasan's dick popped out and the load of cum started getting out of Banu's pussy."




    $ renpy.end_replay()
    $ persistent.gym_shower_fuck_unlocked = True
    jump gym_shower_fuck_continue
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
